﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;

// Token: 0x02000003 RID: 3
// (Invoke) Token: 0x0600000A RID: 10
[DebuggerDisplay("<generated method>", Type = "<generated method>")]
[CompilerGenerated]
internal delegate void VB$AnonymousDelegate_1<TArg0, TArg1>(TArg0 sender, TArg1 e);
