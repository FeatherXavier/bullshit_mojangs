﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;

// Token: 0x02000002 RID: 2
// (Invoke) Token: 0x06000005 RID: 5
[DebuggerDisplay("<generated method>", Type = "<generated method>")]
[CompilerGenerated]
internal delegate TResult VB$AnonymousDelegate_0<TArg0, TArg1, TResult>(TArg0 Left, TArg1 Right);
