﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;

// Token: 0x02000006 RID: 6
// (Invoke) Token: 0x06000019 RID: 25
[DebuggerDisplay("<generated method>", Type = "<generated method>")]
[CompilerGenerated]
internal delegate TResult VB$AnonymousDelegate_4<TResult>();
