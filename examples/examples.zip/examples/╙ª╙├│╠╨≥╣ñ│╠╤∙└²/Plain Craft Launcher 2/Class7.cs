﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Reflection;

// Token: 0x020001DF RID: 479
internal class Class7
{
	// Token: 0x0600153D RID: 5437 RVA: 0x0008BE5C File Offset: 0x0008A05C
	private static void smethod_0()
	{
		if (!Class7._EventAuthentication)
		{
			Class1.Class4 @class = new Class1.Class4(typeof(Class1).Assembly.GetManifestResourceStream("Server.Annotation"));
			@class.method_0().Position = 0L;
			byte[] array = new byte[0];
			byte[] array2 = @class.method_1((int)@class.method_0().Length);
			byte[] array3 = new byte[32];
			array3[0] = 102;
			array3[0] = 202;
			array3[0] = 88;
			array3[0] = 202;
			array3[1] = 136;
			array3[1] = 121;
			array3[1] = 83;
			array3[1] = 225;
			array3[2] = 159;
			array3[2] = 116;
			array3[2] = 94;
			array3[3] = 140;
			array3[3] = 166;
			array3[3] = 86;
			array3[3] = 210;
			array3[4] = 154;
			array3[4] = 94;
			array3[4] = 103;
			array3[5] = 128;
			array3[5] = 99;
			array3[5] = 166;
			array3[5] = 67;
			array3[6] = 133;
			array3[6] = 146;
			array3[6] = 148;
			array3[6] = 155;
			array3[6] = 95;
			array3[6] = 201;
			array3[7] = 110;
			array3[7] = 83;
			array3[7] = 134;
			array3[7] = 145;
			array3[7] = 27;
			array3[8] = 100;
			array3[8] = 192;
			array3[8] = 115;
			array3[8] = 156;
			array3[8] = 92;
			array3[9] = 133;
			array3[9] = 99;
			array3[9] = 131;
			array3[9] = 156;
			array3[9] = 124;
			array3[10] = 185;
			array3[10] = 64;
			array3[10] = 125;
			array3[10] = 57;
			array3[11] = 97;
			array3[11] = 125;
			array3[11] = 98;
			array3[11] = 151;
			array3[11] = 188;
			array3[11] = 171;
			array3[12] = 70;
			array3[12] = 136;
			array3[12] = 134;
			array3[12] = 141;
			array3[12] = 18;
			array3[13] = 116;
			array3[13] = 104;
			array3[13] = 134;
			array3[13] = 237;
			array3[14] = 108;
			array3[14] = 116;
			array3[14] = 136;
			array3[14] = 84;
			array3[14] = 131;
			array3[15] = 155;
			array3[15] = 98;
			array3[15] = 111;
			array3[15] = 175;
			array3[16] = 127;
			array3[16] = 85;
			array3[16] = 152;
			array3[17] = 152;
			array3[17] = 177;
			array3[17] = 45;
			array3[18] = 169;
			array3[18] = 146;
			array3[18] = 205;
			array3[18] = 82;
			array3[18] = 179;
			array3[19] = 152;
			array3[19] = 30;
			array3[19] = 168;
			array3[19] = 134;
			array3[19] = 236;
			array3[20] = 128;
			array3[20] = 106;
			array3[20] = 144;
			array3[20] = 176;
			array3[21] = 168;
			array3[21] = 196;
			array3[21] = 221;
			array3[21] = 87;
			array3[22] = 47;
			array3[22] = 150;
			array3[22] = 106;
			array3[22] = 201;
			array3[23] = 82;
			array3[23] = 59;
			array3[23] = 169;
			array3[23] = 52;
			array3[24] = 124;
			array3[24] = 227;
			array3[24] = 150;
			array3[24] = 104;
			array3[24] = 28;
			array3[25] = 134;
			array3[25] = 215;
			array3[25] = 201;
			array3[26] = 205;
			array3[26] = 147;
			array3[26] = 102;
			array3[26] = 95;
			array3[26] = 127;
			array3[26] = 173;
			array3[27] = 72;
			array3[27] = 152;
			array3[27] = 160;
			array3[27] = 20;
			array3[28] = 111;
			array3[28] = 118;
			array3[28] = 12;
			array3[29] = 62;
			array3[29] = 125;
			array3[29] = 150;
			array3[29] = 160;
			array3[29] = 152;
			array3[29] = 125;
			array3[30] = 56;
			array3[30] = 114;
			array3[30] = 104;
			array3[31] = 148;
			array3[31] = 142;
			array3[31] = 77;
			array3[31] = 135;
			byte[] array4 = array3;
			byte[] array5 = new byte[16];
			array5[0] = 102;
			array5[0] = 202;
			array5[0] = 88;
			array5[0] = 170;
			array5[0] = 138;
			array5[0] = 76;
			array5[1] = 103;
			array5[1] = 147;
			array5[1] = 132;
			array5[1] = 116;
			array5[1] = 125;
			array5[1] = 72;
			array5[2] = 6;
			array5[2] = 51;
			array5[2] = 92;
			array5[2] = 118;
			array5[2] = 47;
			array5[3] = 99;
			array5[3] = 126;
			array5[3] = 190;
			array5[4] = 164;
			array5[4] = 98;
			array5[4] = 117;
			array5[5] = 34;
			array5[5] = 31;
			array5[5] = 156;
			array5[5] = 236;
			array5[6] = 83;
			array5[6] = 88;
			array5[6] = 162;
			array5[6] = 144;
			array5[6] = 21;
			array5[7] = 150;
			array5[7] = 127;
			array5[7] = 112;
			array5[8] = 194;
			array5[8] = 114;
			array5[8] = 158;
			array5[9] = 117;
			array5[9] = 135;
			array5[9] = 150;
			array5[10] = 111;
			array5[10] = 130;
			array5[10] = 188;
			array5[11] = 107;
			array5[11] = 244;
			array5[11] = 97;
			array5[11] = 99;
			array5[12] = 147;
			array5[12] = 101;
			array5[12] = 148;
			array5[12] = 188;
			array5[12] = 11;
			array5[13] = 78;
			array5[13] = 107;
			array5[13] = 134;
			array5[13] = 124;
			array5[13] = 148;
			array5[13] = 12;
			array5[14] = 120;
			array5[14] = 102;
			array5[14] = 126;
			array5[14] = 87;
			array5[14] = 100;
			array5[14] = 193;
			array5[15] = 122;
			array5[15] = 95;
			array5[15] = 111;
			array5[15] = 94;
			array5[15] = 15;
			byte[] array6 = array5;
			int num = 1;
			for (int i = 0; i < array6.Length; i++)
			{
				array4[i] ^= array6[i];
			}
			byte[] array7 = array2;
			int num2 = array7.Length % 4;
			int num3 = array7.Length / 4;
			byte[] array8 = new byte[array7.Length];
			int num4 = array4.Length / 4;
			uint num5 = 0U;
			if (num2 > 0)
			{
				num3++;
			}
			for (int j = 0; j < num3; j++)
			{
				int num6 = j % num4;
				int num7 = j * 4;
				uint num8 = (uint)(num6 * 4);
				uint num9 = (uint)((int)array4[(int)((UIntPtr)(num8 + 3U))] << 24 | (int)array4[(int)((UIntPtr)(num8 + 2U))] << 16 | (int)array4[(int)((UIntPtr)(num8 + 1U))] << 8 | (int)array4[(int)((UIntPtr)num8)]);
				uint num10 = 255U;
				int num11 = 0;
				uint num12;
				if (j == num3 - 1 && num2 > 0)
				{
					num12 = 0U;
					num5 += num9;
					for (int k = 0; k < num2; k++)
					{
						if (k > 0)
						{
							num12 <<= 8;
						}
						num12 |= (uint)array7[array7.Length - (1 + k)];
					}
				}
				else
				{
					num8 = (uint)num7;
					num5 += num9;
					num12 = (uint)((int)array7[(int)((UIntPtr)(num8 + 3U))] << 24 | (int)array7[(int)((UIntPtr)(num8 + 2U))] << 16 | (int)array7[(int)((UIntPtr)(num8 + 1U))] << 8 | (int)array7[(int)((UIntPtr)num8)]);
				}
				uint num13 = num5;
				uint num14 = num13;
				uint num15 = num13;
				num15 ^= num15 << 25;
				num15 += 529777604U;
				num15 ^= num15 >> 27;
				num15 += 1981577986U;
				num15 ^= num15 << 5;
				num15 += 1110908134U;
				num15 = 244418234U + num15;
				num13 = num14 + (uint)num15;
				num5 = num13;
				if (j == num3 - 1 && num2 > 0)
				{
					uint num16 = num5 ^ num12;
					for (int l = 0; l < num2; l++)
					{
						if (l > 0)
						{
							num10 <<= 8;
							num11 += 8;
						}
						array8[num7 + l] = (byte)((num16 & num10) >> num11);
					}
				}
				else
				{
					uint num17 = num5 ^ num12;
					array8[num7] = (byte)(num17 & 255U);
					array8[num7 + 1] = (byte)((num17 & 65280U) >> 8);
					array8[num7 + 2] = (byte)((num17 & 16711680U) >> 16);
					array8[num7 + 3] = (byte)((num17 & 4278190080U) >> 24);
				}
			}
			array = array8;
			switch (num)
			{
			case 0:
				Class7.m_MapAuthentication = Class7.Class8.smethod_7(array);
				break;
			case 1:
			{
				MemoryStream memoryStream = new MemoryStream();
				using (DeflateStream deflateStream = new DeflateStream(new MemoryStream(array), CompressionMode.Decompress))
				{
					deflateStream.CopyTo(memoryStream);
				}
				Class7.m_MapAuthentication = Class7.Class8.smethod_7(memoryStream.ToArray());
				memoryStream.Dispose();
				break;
			}
			default:
				Class7.m_MapAuthentication = Class7.Class8.smethod_7(Class7.Class8.smethod_8(array, 0U));
				break;
			}
			Class7.m_DescriptorAuthentication = ((Assembly)Class7.m_MapAuthentication).GetManifestResourceNames();
			Class7._EventAuthentication = true;
		}
	}

	// Token: 0x0600153E RID: 5438 RVA: 0x0008CCD4 File Offset: 0x0008AED4
	internal static string[] smethod_1(Assembly assembly_0)
	{
		if (assembly_0 == typeof(Class7).Assembly)
		{
			if (!Class7._EventAuthentication)
			{
			}
			List<string> list = new List<string>();
			list.AddRange(assembly_0.GetManifestResourceNames());
			list.AddRange(((Assembly)Class7.m_MapAuthentication).GetManifestResourceNames());
			return list.ToArray();
		}
		return assembly_0.GetManifestResourceNames();
	}

	// Token: 0x0600153F RID: 5439 RVA: 0x0008CD38 File Offset: 0x0008AF38
	private static Assembly smethod_2(object object_0, ResolveEventArgs resolveEventArgs_0)
	{
		if (!Class7._EventAuthentication)
		{
		}
		string name = resolveEventArgs_0.Name;
		for (int i = 0; i < Class7.m_DescriptorAuthentication.Length; i++)
		{
			if (Class7.m_DescriptorAuthentication[i] == name)
			{
				return (Assembly)Class7.m_MapAuthentication;
			}
		}
		return null;
	}

	// Token: 0x06001540 RID: 5440 RVA: 0x0000C1C4 File Offset: 0x0000A3C4
	public Class7()
	{
		AppDomain.CurrentDomain.ResourceResolve += Class7.smethod_2;
	}

	// Token: 0x06001541 RID: 5441 RVA: 0x0000C1E3 File Offset: 0x0000A3E3
	internal static void ListServer()
	{
		if (!Class7.algoAuthentication)
		{
			Class7.algoAuthentication = true;
			new Class7();
		}
	}

	// Token: 0x06001543 RID: 5443 RVA: 0x0000BB8D File Offset: 0x00009D8D
	internal static Type RestartComposer(RuntimeTypeHandle runtimeTypeHandle_0)
	{
		return Type.GetTypeFromHandle(runtimeTypeHandle_0);
	}

	// Token: 0x06001544 RID: 5444 RVA: 0x0000BBCB File Offset: 0x00009DCB
	internal static object CallComposer(Assembly assembly_0, string string_0)
	{
		return assembly_0.GetManifestResourceStream(string_0);
	}

	// Token: 0x06001545 RID: 5445 RVA: 0x0000BBDA File Offset: 0x00009DDA
	internal static object ListComposer(Class1.Class4 class4_0)
	{
		return class4_0.method_0();
	}

	// Token: 0x06001546 RID: 5446 RVA: 0x0000BBE5 File Offset: 0x00009DE5
	internal static void AssetComposer(Stream stream_0, long long_0)
	{
		stream_0.Position = long_0;
	}

	// Token: 0x06001547 RID: 5447 RVA: 0x0000BBF4 File Offset: 0x00009DF4
	internal static long StartComposer(Stream stream_0)
	{
		return stream_0.Length;
	}

	// Token: 0x06001548 RID: 5448 RVA: 0x0000BBFF File Offset: 0x00009DFF
	internal static object RegisterComposer(Class1.Class4 class4_0, int int_0)
	{
		return class4_0.method_1(int_0);
	}

	// Token: 0x06001549 RID: 5449 RVA: 0x0000C217 File Offset: 0x0000A417
	internal static object FindComposer(byte[] byte_0)
	{
		return Class7.Class8.smethod_7(byte_0);
	}

	// Token: 0x0600154A RID: 5450 RVA: 0x0000C222 File Offset: 0x0000A422
	internal static void CloneComposer(Stream stream_0, Stream stream_1)
	{
		stream_0.CopyTo(stream_1);
	}

	// Token: 0x0600154B RID: 5451 RVA: 0x0000BF4C File Offset: 0x0000A14C
	internal static void InvokeComposer(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x0600154C RID: 5452 RVA: 0x0000BF96 File Offset: 0x0000A196
	internal static object ResolveComposer(MemoryStream memoryStream_0)
	{
		return memoryStream_0.ToArray();
	}

	// Token: 0x0600154D RID: 5453 RVA: 0x0000C231 File Offset: 0x0000A431
	internal static void LoginComposer(Stream stream_0)
	{
		stream_0.Dispose();
	}

	// Token: 0x0600154E RID: 5454 RVA: 0x0000C23C File Offset: 0x0000A43C
	internal static object InstantiateComposer(byte[] byte_0, uint uint_0)
	{
		return Class7.Class8.smethod_8(byte_0, uint_0);
	}

	// Token: 0x0600154F RID: 5455 RVA: 0x0000C24B File Offset: 0x0000A44B
	internal static object DisableComposer(Assembly assembly_0)
	{
		return assembly_0.GetManifestResourceNames();
	}

	// Token: 0x06001550 RID: 5456 RVA: 0x0000BDAA File Offset: 0x00009FAA
	internal static bool AddComposer()
	{
		return null == null;
	}

	// Token: 0x06001551 RID: 5457 RVA: 0x0000BDB0 File Offset: 0x00009FB0
	internal static object SetupComposer()
	{
		return null;
	}

	// Token: 0x04000A8A RID: 2698
	private static string[] m_DescriptorAuthentication = new string[0];

	// Token: 0x04000A8B RID: 2699
	private static object m_MapAuthentication = null;

	// Token: 0x04000A8C RID: 2700
	private static bool _EventAuthentication = false;

	// Token: 0x04000A8D RID: 2701
	private static bool algoAuthentication = false;

	// Token: 0x020001E0 RID: 480
	private enum Enum1
	{

	}

	// Token: 0x020001E1 RID: 481
	internal class Class8
	{
		// Token: 0x06001552 RID: 5458 RVA: 0x0008CD84 File Offset: 0x0008AF84
		private unsafe static uint smethod_0(void* pVoid_0, uint uint_0)
		{
			uint result = 0U;
			if (BitConverter.IsLittleEndian)
			{
				result = *(uint*)pVoid_0;
			}
			else
			{
				switch (uint_0)
				{
				case 1U:
					result = (uint)(*(byte*)pVoid_0);
					break;
				case 2U:
					result = (uint)((int)(*(byte*)pVoid_0) | (int)((byte*)pVoid_0)[1] << 8);
					break;
				case 3U:
					result = (uint)((int)(*(byte*)pVoid_0) | (int)((byte*)pVoid_0)[1] << 8 | (int)((byte*)pVoid_0)[2] << 16);
					break;
				case 4U:
					result = (uint)((int)(*(byte*)pVoid_0) | (int)((byte*)pVoid_0)[1] << 8 | (int)((byte*)pVoid_0)[2] << 16 | (int)((byte*)pVoid_0)[3] << 24);
					break;
				}
			}
			return result;
		}

		// Token: 0x06001553 RID: 5459 RVA: 0x0008CE04 File Offset: 0x0008B004
		private unsafe static bool smethod_1(void* pVoid_0, void* pVoid_1, uint uint_0)
		{
			bool flag = true;
			uint num = 0U;
			while (flag && num < uint_0)
			{
				flag = (((byte*)pVoid_0)[num] == ((byte*)pVoid_1)[num]);
				num += 1U;
			}
			return flag;
		}

		// Token: 0x06001554 RID: 5460 RVA: 0x0008CE30 File Offset: 0x0008B030
		private unsafe static void smethod_2(void* pVoid_0, byte byte_0, uint uint_0)
		{
			for (uint num = 0U; num < uint_0; num += 1U)
			{
				((byte*)pVoid_0)[num] = byte_0;
			}
		}

		// Token: 0x06001555 RID: 5461 RVA: 0x0008CE50 File Offset: 0x0008B050
		private unsafe static void smethod_3(void* pVoid_0, void* pVoid_1, uint uint_0)
		{
			for (uint num = 0U; num < uint_0; num += 1U)
			{
				((byte*)pVoid_0)[num] = ((byte*)pVoid_1)[num];
			}
		}

		// Token: 0x06001556 RID: 5462 RVA: 0x0008CE74 File Offset: 0x0008B074
		private unsafe static void smethod_4(byte* pByte_0, byte* pByte_1, uint uint_0)
		{
			if (BitConverter.IsLittleEndian)
			{
				if (uint_0 < 5U)
				{
					*(int*)pByte_0 = (int)(*(uint*)pByte_1);
					return;
				}
				byte* ptr = pByte_0 + uint_0;
				while (pByte_0 < ptr)
				{
					*(int*)pByte_0 = (int)(*(uint*)pByte_1);
					pByte_0 += 4;
					pByte_1 += 4;
				}
				return;
			}
			else
			{
				if (uint_0 > 8U && pByte_1 + uint_0 < pByte_0)
				{
					Class7.Class8.smethod_3((void*)pByte_0, (void*)pByte_1, uint_0);
					return;
				}
				byte* ptr2 = pByte_0 + uint_0;
				while (pByte_0 < ptr2)
				{
					*pByte_0 = *pByte_1;
					pByte_0++;
					pByte_1++;
				}
				return;
			}
		}

		// Token: 0x06001557 RID: 5463 RVA: 0x0008CEDC File Offset: 0x0008B0DC
		private unsafe static uint smethod_5(byte[] byte_0, uint uint_0, Class7.Enum1 enum1_0)
		{
			byte* ptr;
			if (byte_0 != null && byte_0.Length != 0)
			{
				fixed (byte* ptr = &byte_0[0])
				{
				}
			}
			else
			{
				ptr = null;
			}
			uint result = ((uint*)ptr + uint_0 / 4U)[(IntPtr)enum1_0];
			ptr = null;
			return result;
		}

		// Token: 0x06001559 RID: 5465 RVA: 0x0008CF14 File Offset: 0x0008B114
		private unsafe static uint smethod_6(byte[] byte_0, uint uint_0, byte[] byte_1)
		{
			byte* ptr;
			if (byte_0 != null && byte_0.Length != 0)
			{
				fixed (byte* ptr = &byte_0[0])
				{
				}
			}
			else
			{
				ptr = null;
			}
			byte* ptr2;
			if (byte_1 != null && byte_1.Length != 0)
			{
				fixed (byte* ptr2 = &byte_1[0])
				{
				}
			}
			else
			{
				ptr2 = null;
			}
			byte* ptr3 = ptr + uint_0;
			uint num = 32U;
			byte* ptr4 = ptr3 + 32;
			byte* ptr5 = ptr2;
			uint* ptr6 = (uint*)ptr3;
			byte* ptr7 = ptr2 + Class7.Class8.smethod_0((void*)(ptr6 + 3), 4U);
			uint num2 = 1U;
			uint[] array = new uint[]
			{
				4U,
				0U,
				1U,
				0U,
				2U,
				0U,
				1U,
				0U,
				3U,
				0U,
				1U,
				0U,
				2U,
				0U,
				1U,
				0U
			};
			byte* ptr8 = ptr7 - 4;
			uint result;
			if (Class7.Class8.smethod_0((void*)(ptr6 + 4), 4U) != 1U)
			{
				Class7.Class8.smethod_3((void*)ptr2, (void*)(ptr3 + num), Class7.Class8.smethod_0((void*)(ptr6 + 3), 4U));
				result = Class7.Class8.smethod_0((void*)(ptr6 + 3), 4U);
			}
			else if (ptr5 >= ptr8)
			{
				ptr4 += 4;
				while (ptr5 < ptr7)
				{
					*ptr5 = *ptr4;
					ptr5++;
					ptr4++;
				}
				result = (uint)((long)(ptr5 - ptr2));
			}
			else
			{
				for (;;)
				{
					if (num2 == 1U)
					{
						num2 = Class7.Class8.smethod_0((void*)ptr4, 4U);
						ptr4 += 4;
					}
					uint num3 = Class7.Class8.smethod_0((void*)ptr4, 4U);
					if ((num2 & 1U) == 1U)
					{
						num2 >>= 1;
						if ((num3 & 3U) == 0U)
						{
							uint num4 = (num3 & 255U) >> 2;
							Class7.Class8.smethod_4(ptr5, ptr5 - num4, 3U);
							ptr5 += 3;
							ptr4++;
						}
						else if ((num3 & 2U) == 0U)
						{
							uint num4 = (num3 & 65535U) >> 2;
							Class7.Class8.smethod_4(ptr5, ptr5 - num4, 3U);
							ptr5 += 3;
							ptr4 += 2;
						}
						else if ((num3 & 1U) == 0U)
						{
							uint num4 = (num3 & 65535U) >> 6;
							uint num5 = (num3 >> 2 & 15U) + 3U;
							Class7.Class8.smethod_4(ptr5, ptr5 - num4, num5);
							ptr5 += num5;
							ptr4 += 2;
						}
						else if ((num3 & 4U) == 0U)
						{
							uint num4 = (num3 & 16777215U) >> 8;
							uint num5 = (num3 >> 3 & 31U) + 3U;
							Class7.Class8.smethod_4(ptr5, ptr5 - num4, num5);
							ptr5 += num5;
							ptr4 += 3;
						}
						else if ((num3 & 8U) == 0U)
						{
							uint num4 = num3 >> 15;
							uint num5 = (num3 >> 4 & 2047U) + 3U;
							Class7.Class8.smethod_4(ptr5, ptr5 - num4, num5);
							ptr5 += num5;
							ptr4 += 4;
						}
						else
						{
							byte byte_2 = (byte)(num3 >> 16);
							uint num5 = num3 >> 4 & 4095U;
							Class7.Class8.smethod_2((void*)ptr5, byte_2, num5);
							ptr5 += num5;
							ptr4 += 3;
						}
					}
					else
					{
						Class7.Class8.smethod_4(ptr5, ptr4, 4U);
						ptr5 += array[(int)((UIntPtr)(num2 & 15U))];
						ptr4 += array[(int)((UIntPtr)(num2 & 15U))];
						num2 >>= (int)((byte)array[(int)((UIntPtr)(num2 & 15U))]);
						if (ptr5 >= ptr8)
						{
							break;
						}
					}
				}
				while (ptr5 < ptr7)
				{
					if (num2 == 1U)
					{
						ptr4 += 4;
						num2 = 2147483648U;
					}
					*ptr5 = *ptr4;
					ptr5++;
					ptr4++;
					num2 >>= 1;
				}
				result = (uint)((long)(ptr5 - ptr2));
			}
			return result;
		}

		// Token: 0x0600155A RID: 5466 RVA: 0x0008D21C File Offset: 0x0008B41C
		internal static object smethod_7(byte[] byte_0)
		{
			return typeof(Assembly).GetMethod("Load", new Type[]
			{
				typeof(byte[])
			}).Invoke(null, new object[]
			{
				byte_0
			});
		}

		// Token: 0x0600155B RID: 5467 RVA: 0x0008D268 File Offset: 0x0008B468
		public static byte[] smethod_8(byte[] byte_0, uint uint_0)
		{
			uint num = Class7.Class8.smethod_5(byte_0, uint_0, (Class7.Enum1)3);
			byte[] array = null;
			if (num != 0U)
			{
				array = new byte[num];
				Class7.Class8.smethod_6(byte_0, uint_0, array);
			}
			return array;
		}
	}
}
