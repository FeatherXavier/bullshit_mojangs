﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;

// Token: 0x02000005 RID: 5
// (Invoke) Token: 0x06000014 RID: 20
[CompilerGenerated]
[DebuggerDisplay("<generated method>", Type = "<generated method>")]
internal delegate TResult VB$AnonymousDelegate_3<TArg0, TResult>(TArg0 Value);
