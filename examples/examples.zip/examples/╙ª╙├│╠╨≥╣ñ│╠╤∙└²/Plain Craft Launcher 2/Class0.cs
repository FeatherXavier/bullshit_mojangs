﻿using System;
using System.Reflection;

// Token: 0x020001CB RID: 459
internal class Class0
{
	// Token: 0x0600143A RID: 5178 RVA: 0x00088AE8 File Offset: 0x00086CE8
	internal static void RemoveComposer(int typemdt)
	{
		Type type = Class0._ClassParameter.ResolveType(33554432 + typemdt);
		foreach (FieldInfo fieldInfo in type.GetFields())
		{
			MethodInfo method = (MethodInfo)Class0._ClassParameter.ResolveMethod(fieldInfo.MetadataToken + 100663296);
			fieldInfo.SetValue(null, (MulticastDelegate)Delegate.CreateDelegate(type, method));
		}
	}

	// Token: 0x04000A5E RID: 2654
	internal static Module _ClassParameter = typeof(Class0).Assembly.ManifestModule;

	// Token: 0x020001CC RID: 460
	// (Invoke) Token: 0x0600143E RID: 5182
	internal delegate void Delegate0(object o);
}
