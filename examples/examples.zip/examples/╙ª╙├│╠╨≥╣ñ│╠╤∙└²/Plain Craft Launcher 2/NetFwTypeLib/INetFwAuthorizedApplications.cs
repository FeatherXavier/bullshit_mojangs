﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace NetFwTypeLib
{
	// Token: 0x020001C3 RID: 451
	[TypeIdentifier]
	[Guid("644EFD52-CCF9-486C-97A2-39F352570B30")]
	[CompilerGenerated]
	[ComImport]
	public interface INetFwAuthorizedApplications : IEnumerable
	{
		// Token: 0x0600142B RID: 5163
		void _VtblGap1_1();

		// Token: 0x0600142C RID: 5164
		[DispId(2)]
		[MethodImpl(MethodImplOptions.InternalCall)]
		void Add([MarshalAs(UnmanagedType.Interface)] [In] INetFwAuthorizedApplication app);

		// Token: 0x0600142D RID: 5165
		void _VtblGap2_2();

		// Token: 0x0600142E RID: 5166
		[DispId(-4)]
		[MethodImpl(MethodImplOptions.InternalCall)]
		[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler)]
		IEnumerator GetEnumerator();
	}
}
