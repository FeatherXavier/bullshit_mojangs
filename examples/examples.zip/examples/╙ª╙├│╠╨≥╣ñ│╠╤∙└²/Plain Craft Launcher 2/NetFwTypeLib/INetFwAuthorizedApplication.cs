﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace NetFwTypeLib
{
	// Token: 0x020001C2 RID: 450
	[TypeIdentifier]
	[CompilerGenerated]
	[Guid("B5E64FFA-C2C5-444E-A301-FB5E00018050")]
	[ComImport]
	public interface INetFwAuthorizedApplication
	{
		// Token: 0x17000356 RID: 854
		// (get) Token: 0x0600141F RID: 5151
		// (set) Token: 0x06001420 RID: 5152
		[DispId(1)]
		string Name { [DispId(1)] [MethodImpl(MethodImplOptions.InternalCall)] [return: MarshalAs(UnmanagedType.BStr)] get; [DispId(1)] [MethodImpl(MethodImplOptions.InternalCall)] [param: MarshalAs(UnmanagedType.BStr)] [param: In] set; }

		// Token: 0x17000357 RID: 855
		// (get) Token: 0x06001421 RID: 5153
		// (set) Token: 0x06001422 RID: 5154
		[DispId(2)]
		string ProcessImageFileName { [DispId(2)] [MethodImpl(MethodImplOptions.InternalCall)] [return: MarshalAs(UnmanagedType.BStr)] get; [DispId(2)] [MethodImpl(MethodImplOptions.InternalCall)] [param: MarshalAs(UnmanagedType.BStr)] [param: In] set; }

		// Token: 0x17000358 RID: 856
		// (get) Token: 0x06001423 RID: 5155
		// (set) Token: 0x06001424 RID: 5156
		[DispId(3)]
		NET_FW_IP_VERSION_ IpVersion { [DispId(3)] [MethodImpl(MethodImplOptions.InternalCall)] get; [DispId(3)] [MethodImpl(MethodImplOptions.InternalCall)] [param: In] set; }

		// Token: 0x17000359 RID: 857
		// (get) Token: 0x06001425 RID: 5157
		// (set) Token: 0x06001426 RID: 5158
		[DispId(4)]
		NET_FW_SCOPE_ Scope { [DispId(4)] [MethodImpl(MethodImplOptions.InternalCall)] get; [DispId(4)] [MethodImpl(MethodImplOptions.InternalCall)] [param: In] set; }

		// Token: 0x1700035A RID: 858
		// (get) Token: 0x06001427 RID: 5159
		// (set) Token: 0x06001428 RID: 5160
		[DispId(5)]
		string RemoteAddresses { [DispId(5)] [MethodImpl(MethodImplOptions.InternalCall)] [return: MarshalAs(UnmanagedType.BStr)] get; [DispId(5)] [MethodImpl(MethodImplOptions.InternalCall)] [param: MarshalAs(UnmanagedType.BStr)] [param: In] set; }

		// Token: 0x1700035B RID: 859
		// (get) Token: 0x06001429 RID: 5161
		// (set) Token: 0x0600142A RID: 5162
		[DispId(6)]
		bool Enabled { [DispId(6)] [MethodImpl(MethodImplOptions.InternalCall)] get; [DispId(6)] [MethodImpl(MethodImplOptions.InternalCall)] [param: In] set; }
	}
}
