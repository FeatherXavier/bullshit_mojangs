﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace NetFwTypeLib
{
	// Token: 0x020001C8 RID: 456
	[CompilerGenerated]
	[TypeIdentifier("58fbcf7c-e7a9-467c-80b3-fc65e8fcca08", "NetFwTypeLib.NET_FW_PROFILE_TYPE_")]
	public enum NET_FW_PROFILE_TYPE_
	{
		// Token: 0x04000A55 RID: 2645
		NET_FW_PROFILE_DOMAIN,
		// Token: 0x04000A56 RID: 2646
		NET_FW_PROFILE_STANDARD,
		// Token: 0x04000A57 RID: 2647
		NET_FW_PROFILE_CURRENT,
		// Token: 0x04000A58 RID: 2648
		NET_FW_PROFILE_TYPE_MAX
	}
}
