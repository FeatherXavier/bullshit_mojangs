﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace NetFwTypeLib
{
	// Token: 0x020001C7 RID: 455
	[TypeIdentifier("58fbcf7c-e7a9-467c-80b3-fc65e8fcca08", "NetFwTypeLib.NET_FW_IP_VERSION_")]
	[CompilerGenerated]
	public enum NET_FW_IP_VERSION_
	{
		// Token: 0x04000A50 RID: 2640
		NET_FW_IP_VERSION_V4,
		// Token: 0x04000A51 RID: 2641
		NET_FW_IP_VERSION_V6,
		// Token: 0x04000A52 RID: 2642
		NET_FW_IP_VERSION_ANY,
		// Token: 0x04000A53 RID: 2643
		NET_FW_IP_VERSION_MAX
	}
}
