﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace NetFwTypeLib
{
	// Token: 0x020001C5 RID: 453
	[Guid("D46D2478-9AC9-4008-9DC7-5563CE5536CC")]
	[CompilerGenerated]
	[TypeIdentifier]
	[ComImport]
	public interface INetFwPolicy
	{
		// Token: 0x1700035D RID: 861
		// (get) Token: 0x06001430 RID: 5168
		[DispId(1)]
		INetFwProfile CurrentProfile { [DispId(1)] [MethodImpl(MethodImplOptions.InternalCall)] [return: MarshalAs(UnmanagedType.Interface)] get; }

		// Token: 0x06001431 RID: 5169
		[DispId(2)]
		[MethodImpl(MethodImplOptions.InternalCall)]
		[return: MarshalAs(UnmanagedType.Interface)]
		INetFwProfile GetProfileByType([In] NET_FW_PROFILE_TYPE_ profileType);
	}
}
