﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace NetFwTypeLib
{
	// Token: 0x020001C6 RID: 454
	[TypeIdentifier]
	[Guid("174A0DDA-E9F9-449D-993B-21AB667CA456")]
	[CompilerGenerated]
	[ComImport]
	public interface INetFwProfile
	{
		// Token: 0x06001432 RID: 5170
		void _VtblGap1_1();

		// Token: 0x1700035E RID: 862
		// (get) Token: 0x06001433 RID: 5171
		// (set) Token: 0x06001434 RID: 5172
		[DispId(2)]
		bool FirewallEnabled { [DispId(2)] [MethodImpl(MethodImplOptions.InternalCall)] get; [DispId(2)] [MethodImpl(MethodImplOptions.InternalCall)] [param: In] set; }

		// Token: 0x1700035F RID: 863
		// (get) Token: 0x06001435 RID: 5173
		// (set) Token: 0x06001436 RID: 5174
		[DispId(3)]
		bool ExceptionsNotAllowed { [DispId(3)] [MethodImpl(MethodImplOptions.InternalCall)] get; [DispId(3)] [MethodImpl(MethodImplOptions.InternalCall)] [param: In] set; }

		// Token: 0x06001437 RID: 5175
		void _VtblGap2_8();

		// Token: 0x17000360 RID: 864
		// (get) Token: 0x06001438 RID: 5176
		[DispId(10)]
		INetFwAuthorizedApplications AuthorizedApplications { [DispId(10)] [MethodImpl(MethodImplOptions.InternalCall)] [return: MarshalAs(UnmanagedType.Interface)] get; }
	}
}
