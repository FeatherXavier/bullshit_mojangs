﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace NetFwTypeLib
{
	// Token: 0x020001C9 RID: 457
	[TypeIdentifier("58fbcf7c-e7a9-467c-80b3-fc65e8fcca08", "NetFwTypeLib.NET_FW_SCOPE_")]
	[CompilerGenerated]
	public enum NET_FW_SCOPE_
	{
		// Token: 0x04000A5A RID: 2650
		NET_FW_SCOPE_ALL,
		// Token: 0x04000A5B RID: 2651
		NET_FW_SCOPE_LOCAL_SUBNET,
		// Token: 0x04000A5C RID: 2652
		NET_FW_SCOPE_CUSTOM,
		// Token: 0x04000A5D RID: 2653
		NET_FW_SCOPE_MAX
	}
}
