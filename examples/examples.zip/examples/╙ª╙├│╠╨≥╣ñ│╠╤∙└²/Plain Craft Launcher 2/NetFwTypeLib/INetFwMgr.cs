﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace NetFwTypeLib
{
	// Token: 0x020001C4 RID: 452
	[CompilerGenerated]
	[TypeIdentifier]
	[Guid("F7898AF5-CAC4-4632-A2EC-DA06E5111AF2")]
	[ComImport]
	public interface INetFwMgr
	{
		// Token: 0x1700035C RID: 860
		// (get) Token: 0x0600142F RID: 5167
		[DispId(1)]
		INetFwPolicy LocalPolicy { [DispId(1)] [MethodImpl(MethodImplOptions.InternalCall)] [return: MarshalAs(UnmanagedType.Interface)] get; }
	}
}
