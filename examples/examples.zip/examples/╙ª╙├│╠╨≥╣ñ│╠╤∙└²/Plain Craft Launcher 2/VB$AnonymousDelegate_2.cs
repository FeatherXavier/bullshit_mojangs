﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;

// Token: 0x02000004 RID: 4
// (Invoke) Token: 0x0600000F RID: 15
[CompilerGenerated]
[DebuggerDisplay("<generated method>", Type = "<generated method>")]
internal delegate void VB$AnonymousDelegate_2();
