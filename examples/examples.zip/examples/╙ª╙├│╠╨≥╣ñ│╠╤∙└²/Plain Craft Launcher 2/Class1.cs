﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

// Token: 0x020001CD RID: 461
internal class Class1
{
	// Token: 0x06001442 RID: 5186 RVA: 0x00088B54 File Offset: 0x00086D54
	static Class1()
	{
		Class1.producerParameter = typeof(Class1).Assembly;
		Class1.m_CandidateParameter = new uint[]
		{
			3614090360U,
			3905402710U,
			606105819U,
			3250441966U,
			4118548399U,
			1200080426U,
			2821735955U,
			4249261313U,
			1770035416U,
			2336552879U,
			4294925233U,
			2304563134U,
			1804603682U,
			4254626195U,
			2792965006U,
			1236535329U,
			4129170786U,
			3225465664U,
			643717713U,
			3921069994U,
			3593408605U,
			38016083U,
			3634488961U,
			3889429448U,
			568446438U,
			3275163606U,
			4107603335U,
			1163531501U,
			2850285829U,
			4243563512U,
			1735328473U,
			2368359562U,
			4294588738U,
			2272392833U,
			1839030562U,
			4259657740U,
			2763975236U,
			1272893353U,
			4139469664U,
			3200236656U,
			681279174U,
			3936430074U,
			3572445317U,
			76029189U,
			3654602809U,
			3873151461U,
			530742520U,
			3299628645U,
			4096336452U,
			1126891415U,
			2878612391U,
			4237533241U,
			1700485571U,
			2399980690U,
			4293915773U,
			2240044497U,
			1873313359U,
			4264355552U,
			2734768916U,
			1309151649U,
			4149444226U,
			3174756917U,
			718787259U,
			3951481745U
		};
		Class1.m_SetterParameter = false;
		Class1.m_MappingParameter = false;
		Class1.dispatcherParameter = new byte[0];
		Class1._MessageParameter = null;
		Class1._StatusParameter = null;
		Class1.procParameter = new object();
		Class1._ModelAuthentication = new byte[0];
		Class1.wrapperAuthentication = new byte[0];
		Class1._RepositoryAuthentication = IntPtr.Zero;
		Class1.resolverAuthentication = IntPtr.Zero;
		Class1.m_TagAuthentication = new string[0];
		Class1._ComparatorAuthentication = new int[0];
		Class1.m_PrototypeAuthentication = 1;
		Class1._IssuerAuthentication = false;
		Class1._RequestAuthentication = new SortedList();
		Class1._AccountAuthentication = 0;
		Class1.stateAuthentication = 0L;
		Class1.m_ProccesorAuthentication = null;
		Class1._ParameterAuthentication = null;
		Class1.authenticationAuthentication = 0L;
		Class1.reponseAuthentication = 0;
		Class1.m_ContainerAuthentication = false;
		Class1.codeAuthentication = false;
		Class1.tokenizerAuthentication = 0;
		Class1.definitionAuthentication = IntPtr.Zero;
		Class1._ParamsAuthentication = false;
		Class1.m_MockAuthentication = new Hashtable();
		Class1.m_AdapterAuthentication = null;
		Class1._InitializerAuthentication = null;
		Class1.systemAuthentication = null;
		Class1._WriterAuthentication = null;
		Class1._BroadcasterAuthentication = null;
		Class1.m_AttributeAuthentication = null;
		Class1.m_SpecificationAuthentication = IntPtr.Zero;
		try
		{
			RSACryptoServiceProvider.UseMachineKeyStore = true;
		}
		catch
		{
		}
	}

	// Token: 0x06001443 RID: 5187 RVA: 0x000050F7 File Offset: 0x000032F7
	private void DefineComposer()
	{
	}

	// Token: 0x06001444 RID: 5188 RVA: 0x00088CC0 File Offset: 0x00086EC0
	internal static byte[] smethod_0(byte[] byte_0)
	{
		uint[] array = new uint[16];
		int num = 448 - byte_0.Length * 8 % 512;
		uint num2 = (uint)((num + 512) % 512);
		if (num2 == 0U)
		{
			num2 = 512U;
		}
		uint num3 = (uint)((long)byte_0.Length + (long)((ulong)(num2 / 8U)) + 8L);
		ulong num4 = (ulong)((long)byte_0.Length * 8L);
		byte[] array2 = new byte[num3];
		for (int i = 0; i < byte_0.Length; i++)
		{
			array2[i] = byte_0[i];
		}
		byte[] array3 = array2;
		int num5 = byte_0.Length;
		array3[num5] |= 128;
		for (int j = 8; j > 0; j--)
		{
			array2[(int)(checked((IntPtr)(unchecked((ulong)num3 - (ulong)((long)j)))))] = (byte)(num4 >> (8 - j) * 8 & 255UL);
		}
		uint num6 = (uint)(array2.Length * 8 / 32);
		uint num7 = 1732584193U;
		uint num8 = 4023233417U;
		uint num9 = 2562383102U;
		uint num10 = 271733878U;
		for (uint num11 = 0U; num11 < num6 / 16U; num11 += 1U)
		{
			uint num12 = num11 << 6;
			for (uint num13 = 0U; num13 < 61U; num13 += 4U)
			{
				array[(int)((UIntPtr)(num13 >> 2))] = (uint)((int)array2[(int)((UIntPtr)(num12 + (num13 + 3U)))] << 24 | (int)array2[(int)((UIntPtr)(num12 + (num13 + 2U)))] << 16 | (int)array2[(int)((UIntPtr)(num12 + (num13 + 1U)))] << 8 | (int)array2[(int)((UIntPtr)(num12 + num13))]);
			}
			uint num14 = num7;
			uint num15 = num8;
			uint num16 = num9;
			uint num17 = num10;
			Class1.smethod_1(ref num7, num8, num9, num10, 0U, 7, 1U, array);
			Class1.smethod_1(ref num10, num7, num8, num9, 1U, 12, 2U, array);
			Class1.smethod_1(ref num9, num10, num7, num8, 2U, 17, 3U, array);
			Class1.smethod_1(ref num8, num9, num10, num7, 3U, 22, 4U, array);
			Class1.smethod_1(ref num7, num8, num9, num10, 4U, 7, 5U, array);
			Class1.smethod_1(ref num10, num7, num8, num9, 5U, 12, 6U, array);
			Class1.smethod_1(ref num9, num10, num7, num8, 6U, 17, 7U, array);
			Class1.smethod_1(ref num8, num9, num10, num7, 7U, 22, 8U, array);
			Class1.smethod_1(ref num7, num8, num9, num10, 8U, 7, 9U, array);
			Class1.smethod_1(ref num10, num7, num8, num9, 9U, 12, 10U, array);
			Class1.smethod_1(ref num9, num10, num7, num8, 10U, 17, 11U, array);
			Class1.smethod_1(ref num8, num9, num10, num7, 11U, 22, 12U, array);
			Class1.smethod_1(ref num7, num8, num9, num10, 12U, 7, 13U, array);
			Class1.smethod_1(ref num10, num7, num8, num9, 13U, 12, 14U, array);
			Class1.smethod_1(ref num9, num10, num7, num8, 14U, 17, 15U, array);
			Class1.smethod_1(ref num8, num9, num10, num7, 15U, 22, 16U, array);
			Class1.smethod_2(ref num7, num8, num9, num10, 1U, 5, 17U, array);
			Class1.smethod_2(ref num10, num7, num8, num9, 6U, 9, 18U, array);
			Class1.smethod_2(ref num9, num10, num7, num8, 11U, 14, 19U, array);
			Class1.smethod_2(ref num8, num9, num10, num7, 0U, 20, 20U, array);
			Class1.smethod_2(ref num7, num8, num9, num10, 5U, 5, 21U, array);
			Class1.smethod_2(ref num10, num7, num8, num9, 10U, 9, 22U, array);
			Class1.smethod_2(ref num9, num10, num7, num8, 15U, 14, 23U, array);
			Class1.smethod_2(ref num8, num9, num10, num7, 4U, 20, 24U, array);
			Class1.smethod_2(ref num7, num8, num9, num10, 9U, 5, 25U, array);
			Class1.smethod_2(ref num10, num7, num8, num9, 14U, 9, 26U, array);
			Class1.smethod_2(ref num9, num10, num7, num8, 3U, 14, 27U, array);
			Class1.smethod_2(ref num8, num9, num10, num7, 8U, 20, 28U, array);
			Class1.smethod_2(ref num7, num8, num9, num10, 13U, 5, 29U, array);
			Class1.smethod_2(ref num10, num7, num8, num9, 2U, 9, 30U, array);
			Class1.smethod_2(ref num9, num10, num7, num8, 7U, 14, 31U, array);
			Class1.smethod_2(ref num8, num9, num10, num7, 12U, 20, 32U, array);
			Class1.smethod_3(ref num7, num8, num9, num10, 5U, 4, 33U, array);
			Class1.smethod_3(ref num10, num7, num8, num9, 8U, 11, 34U, array);
			Class1.smethod_3(ref num9, num10, num7, num8, 11U, 16, 35U, array);
			Class1.smethod_3(ref num8, num9, num10, num7, 14U, 23, 36U, array);
			Class1.smethod_3(ref num7, num8, num9, num10, 1U, 4, 37U, array);
			Class1.smethod_3(ref num10, num7, num8, num9, 4U, 11, 38U, array);
			Class1.smethod_3(ref num9, num10, num7, num8, 7U, 16, 39U, array);
			Class1.smethod_3(ref num8, num9, num10, num7, 10U, 23, 40U, array);
			Class1.smethod_3(ref num7, num8, num9, num10, 13U, 4, 41U, array);
			Class1.smethod_3(ref num10, num7, num8, num9, 0U, 11, 42U, array);
			Class1.smethod_3(ref num9, num10, num7, num8, 3U, 16, 43U, array);
			Class1.smethod_3(ref num8, num9, num10, num7, 6U, 23, 44U, array);
			Class1.smethod_3(ref num7, num8, num9, num10, 9U, 4, 45U, array);
			Class1.smethod_3(ref num10, num7, num8, num9, 12U, 11, 46U, array);
			Class1.smethod_3(ref num9, num10, num7, num8, 15U, 16, 47U, array);
			Class1.smethod_3(ref num8, num9, num10, num7, 2U, 23, 48U, array);
			Class1.smethod_4(ref num7, num8, num9, num10, 0U, 6, 49U, array);
			Class1.smethod_4(ref num10, num7, num8, num9, 7U, 10, 50U, array);
			Class1.smethod_4(ref num9, num10, num7, num8, 14U, 15, 51U, array);
			Class1.smethod_4(ref num8, num9, num10, num7, 5U, 21, 52U, array);
			Class1.smethod_4(ref num7, num8, num9, num10, 12U, 6, 53U, array);
			Class1.smethod_4(ref num10, num7, num8, num9, 3U, 10, 54U, array);
			Class1.smethod_4(ref num9, num10, num7, num8, 10U, 15, 55U, array);
			Class1.smethod_4(ref num8, num9, num10, num7, 1U, 21, 56U, array);
			Class1.smethod_4(ref num7, num8, num9, num10, 8U, 6, 57U, array);
			Class1.smethod_4(ref num10, num7, num8, num9, 15U, 10, 58U, array);
			Class1.smethod_4(ref num9, num10, num7, num8, 6U, 15, 59U, array);
			Class1.smethod_4(ref num8, num9, num10, num7, 13U, 21, 60U, array);
			Class1.smethod_4(ref num7, num8, num9, num10, 4U, 6, 61U, array);
			Class1.smethod_4(ref num10, num7, num8, num9, 11U, 10, 62U, array);
			Class1.smethod_4(ref num9, num10, num7, num8, 2U, 15, 63U, array);
			Class1.smethod_4(ref num8, num9, num10, num7, 9U, 21, 64U, array);
			num7 += num14;
			num8 += num15;
			num9 += num16;
			num10 += num17;
		}
		byte[] array4 = new byte[16];
		Array.Copy(BitConverter.GetBytes(num7), 0, array4, 0, 4);
		Array.Copy(BitConverter.GetBytes(num8), 0, array4, 4, 4);
		Array.Copy(BitConverter.GetBytes(num9), 0, array4, 8, 4);
		Array.Copy(BitConverter.GetBytes(num10), 0, array4, 12, 4);
		return array4;
	}

	// Token: 0x06001445 RID: 5189 RVA: 0x0000BA2A File Offset: 0x00009C2A
	private static void smethod_1(ref uint uint_0, uint uint_1, uint uint_2, uint uint_3, uint uint_4, ushort ushort_0, uint uint_5, uint[] uint_6)
	{
		uint_0 = uint_1 + Class1.smethod_5(uint_0 + ((uint_1 & uint_2) | (~uint_1 & uint_3)) + uint_6[(int)((UIntPtr)uint_4)] + Class1.m_CandidateParameter[(int)((UIntPtr)(uint_5 - 1U))], ushort_0);
	}

	// Token: 0x06001446 RID: 5190 RVA: 0x0000BA55 File Offset: 0x00009C55
	private static void smethod_2(ref uint uint_0, uint uint_1, uint uint_2, uint uint_3, uint uint_4, ushort ushort_0, uint uint_5, uint[] uint_6)
	{
		uint_0 = uint_1 + Class1.smethod_5(uint_0 + ((uint_1 & uint_3) | (uint_2 & ~uint_3)) + uint_6[(int)((UIntPtr)uint_4)] + Class1.m_CandidateParameter[(int)((UIntPtr)(uint_5 - 1U))], ushort_0);
	}

	// Token: 0x06001447 RID: 5191 RVA: 0x0000BA80 File Offset: 0x00009C80
	private static void smethod_3(ref uint uint_0, uint uint_1, uint uint_2, uint uint_3, uint uint_4, ushort ushort_0, uint uint_5, uint[] uint_6)
	{
		uint_0 = uint_1 + Class1.smethod_5(uint_0 + (uint_1 ^ uint_2 ^ uint_3) + uint_6[(int)((UIntPtr)uint_4)] + Class1.m_CandidateParameter[(int)((UIntPtr)(uint_5 - 1U))], ushort_0);
	}

	// Token: 0x06001448 RID: 5192 RVA: 0x0000BAA8 File Offset: 0x00009CA8
	private static void smethod_4(ref uint uint_0, uint uint_1, uint uint_2, uint uint_3, uint uint_4, ushort ushort_0, uint uint_5, uint[] uint_6)
	{
		uint_0 = uint_1 + Class1.smethod_5(uint_0 + (uint_2 ^ (uint_1 | ~uint_3)) + uint_6[(int)((UIntPtr)uint_4)] + Class1.m_CandidateParameter[(int)((UIntPtr)(uint_5 - 1U))], ushort_0);
	}

	// Token: 0x06001449 RID: 5193 RVA: 0x0000BAD1 File Offset: 0x00009CD1
	private static uint smethod_5(uint uint_0, ushort ushort_0)
	{
		return uint_0 >> (int)(32 - ushort_0) | uint_0 << (int)ushort_0;
	}

	// Token: 0x0600144A RID: 5194 RVA: 0x0000BAE3 File Offset: 0x00009CE3
	internal static bool smethod_6()
	{
		if (!Class1.m_SetterParameter)
		{
			Class1.smethod_8();
			Class1.m_SetterParameter = true;
		}
		return Class1.m_MappingParameter;
	}

	// Token: 0x0600144B RID: 5195 RVA: 0x00089364 File Offset: 0x00087564
	internal static SymmetricAlgorithm smethod_7()
	{
		SymmetricAlgorithm result = null;
		if (Class1.smethod_6())
		{
			result = new AesCryptoServiceProvider();
		}
		else
		{
			try
			{
				result = new RijndaelManaged();
			}
			catch
			{
				result = (SymmetricAlgorithm)Activator.CreateInstance("System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089", "System.Security.Cryptography.AesCryptoServiceProvider").Unwrap();
			}
		}
		return result;
	}

	// Token: 0x0600144C RID: 5196 RVA: 0x000893B8 File Offset: 0x000875B8
	internal static void smethod_8()
	{
		try
		{
			Class1.m_MappingParameter = CryptoConfig.AllowOnlyFipsAlgorithms;
		}
		catch
		{
		}
	}

	// Token: 0x0600144D RID: 5197 RVA: 0x0000BAFC File Offset: 0x00009CFC
	internal static byte[] smethod_9(byte[] byte_0)
	{
		if (!Class1.smethod_6())
		{
			return new MD5CryptoServiceProvider().ComputeHash(byte_0);
		}
		return Class1.smethod_0(byte_0);
	}

	// Token: 0x0600144E RID: 5198 RVA: 0x000893E4 File Offset: 0x000875E4
	internal static void smethod_10(HashAlgorithm hashAlgorithm_0, Stream stream_0, uint uint_0, byte[] byte_0)
	{
		while (uint_0 > 0U)
		{
			int num = (uint_0 > (uint)byte_0.Length) ? byte_0.Length : ((int)uint_0);
			stream_0.Read(byte_0, 0, num);
			Class1.smethod_11(hashAlgorithm_0, byte_0, 0, num);
			uint_0 -= (uint)num;
		}
	}

	// Token: 0x0600144F RID: 5199 RVA: 0x0000BB17 File Offset: 0x00009D17
	internal static void smethod_11(HashAlgorithm hashAlgorithm_0, byte[] byte_0, int int_0, int int_1)
	{
		hashAlgorithm_0.TransformBlock(byte_0, int_0, int_1, byte_0, int_0);
	}

	// Token: 0x06001450 RID: 5200 RVA: 0x00089420 File Offset: 0x00087620
	internal static uint smethod_12(uint uint_0, int int_0, long long_0, BinaryReader binaryReader_0)
	{
		for (int i = 0; i < int_0; i++)
		{
			binaryReader_0.BaseStream.Position = long_0 + (long)(i * 40 + 8);
			uint num = binaryReader_0.ReadUInt32();
			uint num2 = binaryReader_0.ReadUInt32();
			binaryReader_0.ReadUInt32();
			uint num3 = binaryReader_0.ReadUInt32();
			if (num2 <= uint_0 && uint_0 < num2 + num)
			{
				return num3 + uint_0 - num2;
			}
		}
		return 0U;
	}

	// Token: 0x06001451 RID: 5201 RVA: 0x000050F7 File Offset: 0x000032F7
	[Class1.Attribute0(typeof(Class1.Attribute0.Class2<object>[]))]
	internal static void smethod_13()
	{
	}

	// Token: 0x06001452 RID: 5202 RVA: 0x0008947C File Offset: 0x0008767C
	public static void smethod_14(RuntimeTypeHandle runtimeTypeHandle_0)
	{
		try
		{
			Type typeFromHandle = Type.GetTypeFromHandle(runtimeTypeHandle_0);
			if (Class1._StatusParameter == null)
			{
				lock (Class1.procParameter)
				{
					Dictionary<int, int> dictionary = new Dictionary<int, int>();
					BinaryReader binaryReader = new BinaryReader(typeof(Class1).Assembly.GetManifestResourceStream("Manager.Connection"));
					binaryReader.BaseStream.Position = 0L;
					byte[] array = binaryReader.ReadBytes((int)binaryReader.BaseStream.Length);
					binaryReader.Close();
					if (array.Length > 0)
					{
						int num = array.Length % 4;
						int num2 = array.Length / 4;
						byte[] array2 = new byte[array.Length];
						uint num3 = 0U;
						if (num > 0)
						{
							num2++;
						}
						for (int i = 0; i < num2; i++)
						{
							int num4 = i * 4;
							uint num5 = 255U;
							int num6 = 0;
							uint num7;
							if (i == num2 - 1 && num > 0)
							{
								num7 = 0U;
								for (int j = 0; j < num; j++)
								{
									if (j > 0)
									{
										num7 <<= 8;
									}
									num7 |= (uint)array[array.Length - (1 + j)];
								}
							}
							else
							{
								uint num8 = (uint)num4;
								num7 = (uint)((int)array[(int)((UIntPtr)(num8 + 3U))] << 24 | (int)array[(int)((UIntPtr)(num8 + 2U))] << 16 | (int)array[(int)((UIntPtr)(num8 + 1U))] << 8 | (int)array[(int)((UIntPtr)num8)]);
							}
							num3 = num3;
							num3 += 0U;
							if (i == num2 - 1 && num > 0)
							{
								uint num9 = num3 ^ num7;
								for (int k = 0; k < num; k++)
								{
									if (k > 0)
									{
										num5 <<= 8;
										num6 += 8;
									}
									array2[num4 + k] = (byte)((num9 & num5) >> num6);
								}
							}
							else
							{
								uint num10 = num3 ^ num7;
								array2[num4] = (byte)(num10 & 255U);
								array2[num4 + 1] = (byte)((num10 & 65280U) >> 8);
								array2[num4 + 2] = (byte)((num10 & 16711680U) >> 16);
								array2[num4 + 3] = (byte)((num10 & 4278190080U) >> 24);
							}
						}
						array = array2;
						int num11 = array.Length / 8;
						Class1.Class4 @class = new Class1.Class4(new MemoryStream(array));
						for (int l = 0; l < num11; l++)
						{
							int key = @class.method_3();
							int value = @class.method_3();
							dictionary.Add(key, value);
						}
						@class.method_4();
					}
					Class1._StatusParameter = dictionary;
				}
			}
			foreach (FieldInfo fieldInfo in typeFromHandle.GetFields(BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.GetField))
			{
				int metadataToken = fieldInfo.MetadataToken;
				int num12 = Class1._StatusParameter[metadataToken];
				bool flag2 = (num12 & 1073741824) > 0;
				num12 &= 1073741823;
				MethodInfo methodInfo = (MethodInfo)typeof(Class1).Module.ResolveMethod(num12, typeFromHandle.GetGenericArguments(), new Type[0]);
				if (methodInfo.IsStatic)
				{
					fieldInfo.SetValue(null, Delegate.CreateDelegate(fieldInfo.FieldType, methodInfo));
				}
				else
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					int num13 = parameters.Length + 1;
					Type[] array3 = new Type[num13];
					if (methodInfo.DeclaringType.IsValueType)
					{
						array3[0] = methodInfo.DeclaringType.MakeByRefType();
					}
					else
					{
						array3[0] = typeof(object);
					}
					for (int n = 0; n < parameters.Length; n++)
					{
						array3[n + 1] = parameters[n].ParameterType;
					}
					DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, methodInfo.ReturnType, array3, typeFromHandle, true);
					ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
					for (int num14 = 0; num14 < num13; num14++)
					{
						switch (num14)
						{
						case 0:
							ilgenerator.Emit(OpCodes.Ldarg_0);
							break;
						case 1:
							ilgenerator.Emit(OpCodes.Ldarg_1);
							break;
						case 2:
							ilgenerator.Emit(OpCodes.Ldarg_2);
							break;
						case 3:
							ilgenerator.Emit(OpCodes.Ldarg_3);
							break;
						default:
							ilgenerator.Emit(OpCodes.Ldarg_S, num14);
							break;
						}
					}
					ilgenerator.Emit(OpCodes.Tailcall);
					ilgenerator.Emit(flag2 ? OpCodes.Callvirt : OpCodes.Call, methodInfo);
					ilgenerator.Emit(OpCodes.Ret);
					fieldInfo.SetValue(null, dynamicMethod.CreateDelegate(typeFromHandle));
				}
			}
		}
		catch (Exception)
		{
		}
	}

	// Token: 0x06001453 RID: 5203 RVA: 0x0000BB25 File Offset: 0x00009D25
	private static uint smethod_15(uint uint_0)
	{
		return (uint)"{11111-22222-10009-11111}".Length;
	}

	// Token: 0x06001454 RID: 5204 RVA: 0x0000B28D File Offset: 0x0000948D
	private static uint smethod_16(uint uint_0)
	{
		return 0U;
	}

	// Token: 0x06001455 RID: 5205 RVA: 0x000050F7 File Offset: 0x000032F7
	internal static void smethod_17()
	{
	}

	// Token: 0x06001456 RID: 5206 RVA: 0x000898EC File Offset: 0x00087AEC
	[Class1.Attribute0(typeof(Class1.Attribute0.Class2<object>[]))]
	internal static string smethod_18(string string_0)
	{
		"{11111-22222-50001-00000}".Trim();
		byte[] array = Convert.FromBase64String(string_0);
		return Encoding.Unicode.GetString(array, 0, array.Length);
	}

	// Token: 0x06001457 RID: 5207 RVA: 0x0008991C File Offset: 0x00087B1C
	internal static uint smethod_19(IntPtr intptr_0, IntPtr intptr_1, IntPtr intptr_2, [MarshalAs(UnmanagedType.U4)] uint uint_0, IntPtr intptr_3, ref uint uint_1)
	{
		IntPtr ptr = intptr_2;
		if (Class1._RegistryParameter)
		{
			ptr = intptr_1;
		}
		long num;
		if (IntPtr.Size == 4)
		{
			num = (long)Marshal.ReadInt32(ptr, IntPtr.Size * 2);
		}
		else
		{
			num = Marshal.ReadInt64(ptr, IntPtr.Size * 2);
		}
		object obj = Class1.m_MockAuthentication[num];
		if (obj == null)
		{
			return Class1.m_ProccesorAuthentication(intptr_0, intptr_1, intptr_2, uint_0, intptr_3, ref uint_1);
		}
		Class1.Struct10 @struct = (Class1.Struct10)obj;
		IntPtr intPtr = Marshal.AllocCoTaskMem(@struct.clientAuthentication.Length);
		Marshal.Copy(@struct.clientAuthentication, 0, intPtr, @struct.clientAuthentication.Length);
		if (@struct.predicateAuthentication)
		{
			intptr_3 = intPtr;
			uint_1 = (uint)@struct.clientAuthentication.Length;
			Class1.smethod_27(intptr_3, @struct.clientAuthentication.Length, 64, ref Class1.tokenizerAuthentication);
			return 0U;
		}
		Marshal.WriteIntPtr(ptr, IntPtr.Size * 2, intPtr);
		Marshal.WriteInt32(ptr, IntPtr.Size * 3, @struct.clientAuthentication.Length);
		uint result = 0U;
		if (uint_0 == 216669565U && !Class1._ParamsAuthentication)
		{
			Class1._ParamsAuthentication = true;
		}
		else
		{
			result = Class1.m_ProccesorAuthentication(intptr_0, intptr_1, intptr_2, uint_0, intptr_3, ref uint_1);
		}
		return result;
	}

	// Token: 0x06001458 RID: 5208 RVA: 0x0000BB31 File Offset: 0x00009D31
	private static int smethod_20()
	{
		return 5;
	}

	// Token: 0x06001459 RID: 5209 RVA: 0x00089A48 File Offset: 0x00087C48
	private static void smethod_21()
	{
		try
		{
			RSACryptoServiceProvider.UseMachineKeyStore = true;
		}
		catch
		{
		}
	}

	// Token: 0x0600145A RID: 5210 RVA: 0x00089A70 File Offset: 0x00087C70
	private static Delegate smethod_22(IntPtr intptr_0, Type type_0)
	{
		return (Delegate)typeof(Marshal).GetMethod("GetDelegateForFunctionPointer", new Type[]
		{
			typeof(IntPtr),
			typeof(Type)
		}).Invoke(null, new object[]
		{
			intptr_0,
			type_0
		});
	}

	// Token: 0x0600145B RID: 5211 RVA: 0x00089AD8 File Offset: 0x00087CD8
	internal unsafe static void smethod_23()
	{
		if (!Class1._IssuerAuthentication)
		{
			Class1._IssuerAuthentication = true;
			long num = 0L;
			Marshal.ReadIntPtr(new IntPtr((void*)(&num)), 0);
			Marshal.ReadInt32(new IntPtr((void*)(&num)), 0);
			Marshal.ReadInt64(new IntPtr((void*)(&num)), 0);
			Marshal.WriteIntPtr(new IntPtr((void*)(&num)), 0, IntPtr.Zero);
			Marshal.WriteInt32(new IntPtr((void*)(&num)), 0, 0);
			Marshal.WriteInt64(new IntPtr((void*)(&num)), 0, 0L);
			byte[] array = new byte[1];
			Marshal.Copy(array, 0, Marshal.AllocCoTaskMem(8), 1);
			Class1.smethod_21();
			if (IntPtr.Size == 4 && Type.GetType("System.Reflection.ReflectionContext", false) != null)
			{
				ProcessModuleCollection modules = Process.GetCurrentProcess().Modules;
				foreach (object obj in modules)
				{
					ProcessModule processModule = (ProcessModule)obj;
					if (processModule.ModuleName.ToLower() == "clrjit.dll")
					{
						Version v = new Version(processModule.FileVersionInfo.ProductMajorPart, processModule.FileVersionInfo.ProductMinorPart, processModule.FileVersionInfo.ProductBuildPart, processModule.FileVersionInfo.ProductPrivatePart);
						Version v2 = new Version(4, 0, 30319, 17020);
						Version v3 = new Version(4, 0, 30319, 17921);
						if (v >= v2 && v < v3)
						{
							Class1._RegistryParameter = true;
							break;
						}
					}
				}
			}
			Class1.Class4 @class = new Class1.Class4(Class1.producerParameter.GetManifestResourceStream("Iterator.Broadcaster"));
			@class.method_0().Position = 0L;
			byte[] array2 = @class.method_1((int)@class.method_0().Length);
			byte[] array3 = new byte[32];
			array3[0] = 160;
			array3[0] = 66;
			array3[0] = 110;
			array3[0] = 153;
			array3[0] = 243;
			array3[1] = 94;
			array3[1] = 133;
			array3[1] = 136;
			array3[1] = 120;
			array3[1] = 114;
			array3[1] = 61;
			array3[2] = 141;
			array3[2] = 189;
			array3[2] = 100;
			array3[2] = 82;
			array3[2] = 117;
			array3[2] = 0;
			array3[3] = 114;
			array3[3] = 168;
			array3[3] = 51;
			array3[3] = 213;
			array3[3] = 232;
			array3[4] = 181;
			array3[4] = 132;
			array3[4] = 41;
			array3[4] = 123;
			array3[4] = 186;
			array3[5] = 167;
			array3[5] = 81;
			array3[5] = 86;
			array3[5] = 151;
			array3[5] = 133;
			array3[5] = 56;
			array3[6] = 84;
			array3[6] = 67;
			array3[6] = 190;
			array3[6] = 81;
			array3[7] = 206;
			array3[7] = 101;
			array3[7] = 78;
			array3[7] = 193;
			array3[7] = 169;
			array3[8] = 166;
			array3[8] = 207;
			array3[8] = 23;
			array3[9] = 116;
			array3[9] = 136;
			array3[9] = 145;
			array3[10] = 167;
			array3[10] = 47;
			array3[10] = 165;
			array3[10] = 139;
			array3[11] = 74;
			array3[11] = 138;
			array3[11] = 122;
			array3[11] = 126;
			array3[12] = 37;
			array3[12] = 164;
			array3[12] = 132;
			array3[12] = 134;
			array3[12] = 148;
			array3[12] = 112;
			array3[13] = 148;
			array3[13] = 159;
			array3[13] = 176;
			array3[13] = 130;
			array3[13] = 168;
			array3[13] = 55;
			array3[14] = 102;
			array3[14] = 101;
			array3[14] = 161;
			array3[15] = 199;
			array3[15] = 105;
			array3[15] = 185;
			array3[16] = 140;
			array3[16] = 106;
			array3[16] = 164;
			array3[16] = 101;
			array3[16] = 86;
			array3[16] = 177;
			array3[17] = 38;
			array3[17] = 146;
			array3[17] = 139;
			array3[17] = 127;
			array3[18] = 163;
			array3[18] = 150;
			array3[18] = 150;
			array3[18] = 122;
			array3[18] = 141;
			array3[18] = 25;
			array3[19] = 96;
			array3[19] = 109;
			array3[19] = 156;
			array3[19] = 171;
			array3[20] = 103;
			array3[20] = 23;
			array3[20] = 164;
			array3[20] = 219;
			array3[21] = 112;
			array3[21] = 111;
			array3[21] = 100;
			array3[22] = 131;
			array3[22] = 48;
			array3[22] = 161;
			array3[22] = 162;
			array3[22] = 148;
			array3[22] = 116;
			array3[23] = 150;
			array3[23] = 100;
			array3[23] = 54;
			array3[24] = 101;
			array3[24] = 120;
			array3[24] = 71;
			array3[24] = 178;
			array3[24] = 91;
			array3[25] = 124;
			array3[25] = 100;
			array3[25] = 153;
			array3[25] = 104;
			array3[25] = 106;
			array3[25] = 240;
			array3[26] = 142;
			array3[26] = 86;
			array3[26] = 138;
			array3[26] = 133;
			array3[26] = 234;
			array3[27] = 86;
			array3[27] = 91;
			array3[27] = 161;
			array3[28] = 131;
			array3[28] = 180;
			array3[28] = 77;
			array3[28] = 109;
			array3[28] = 10;
			array3[28] = 86;
			array3[29] = 101;
			array3[29] = 162;
			array3[29] = 106;
			array3[29] = 208;
			array3[29] = 132;
			array3[29] = 133;
			array3[30] = 87;
			array3[30] = 120;
			array3[30] = 156;
			array3[30] = 156;
			array3[30] = 220;
			array3[31] = 129;
			array3[31] = 187;
			array3[31] = 188;
			array3[31] = 155;
			byte[] array4 = array3;
			byte[] array5 = new byte[16];
			array5[0] = 150;
			array5[0] = 136;
			array5[0] = 79;
			array5[0] = 134;
			array5[1] = 172;
			array5[1] = 196;
			array5[1] = 47;
			array5[1] = 91;
			array5[1] = 240;
			array5[2] = 150;
			array5[2] = 90;
			array5[2] = 214;
			array5[3] = 103;
			array5[3] = 174;
			array5[3] = 93;
			array5[3] = 169;
			array5[3] = 133;
			array5[3] = 227;
			array5[4] = 119;
			array5[4] = 95;
			array5[4] = 140;
			array5[4] = 224;
			array5[5] = 131;
			array5[5] = 122;
			array5[5] = 32;
			array5[6] = 97;
			array5[6] = 118;
			array5[6] = 85;
			array5[6] = 137;
			array5[6] = 92;
			array5[6] = 27;
			array5[7] = 214;
			array5[7] = 98;
			array5[7] = 91;
			array5[8] = 134;
			array5[8] = 179;
			array5[8] = 244;
			array5[9] = 148;
			array5[9] = 117;
			array5[9] = 156;
			array5[9] = 126;
			array5[10] = 124;
			array5[10] = 118;
			array5[10] = 94;
			array5[10] = 49;
			array5[11] = 151;
			array5[11] = 110;
			array5[11] = 142;
			array5[11] = 251;
			array5[12] = 172;
			array5[12] = 114;
			array5[12] = 137;
			array5[12] = 100;
			array5[12] = 120;
			array5[12] = 35;
			array5[13] = 197;
			array5[13] = 148;
			array5[13] = 211;
			array5[14] = 91;
			array5[14] = 161;
			array5[14] = 108;
			array5[14] = 143;
			array5[14] = 172;
			array5[15] = 192;
			array5[15] = 87;
			array5[15] = 73;
			array5[15] = 110;
			array5[15] = 24;
			byte[] array6 = array5;
			Array.Reverse(array6);
			byte[] publicKeyToken = Class1.producerParameter.GetName().GetPublicKeyToken();
			if (publicKeyToken != null && publicKeyToken.Length > 0)
			{
				array6[1] = publicKeyToken[0];
				array6[3] = publicKeyToken[1];
				array6[5] = publicKeyToken[2];
				array6[7] = publicKeyToken[3];
				array6[9] = publicKeyToken[4];
				array6[11] = publicKeyToken[5];
				array6[13] = publicKeyToken[6];
				array6[15] = publicKeyToken[7];
				Array.Clear(publicKeyToken, 0, publicKeyToken.Length);
			}
			for (int i = 0; i < array6.Length; i++)
			{
				array4[i] ^= array6[i];
			}
			byte[] array7 = array2;
			int num2 = array7.Length % 4;
			int num3 = array7.Length / 4;
			byte[] array8 = new byte[array7.Length];
			int num4 = array4.Length / 4;
			uint num5 = 0U;
			if (num2 > 0)
			{
				num3++;
			}
			for (int j = 0; j < num3; j++)
			{
				int num6 = j % num4;
				int num7 = j * 4;
				uint num8 = (uint)(num6 * 4);
				uint num9 = (uint)((int)array4[(int)((UIntPtr)(num8 + 3U))] << 24 | (int)array4[(int)((UIntPtr)(num8 + 2U))] << 16 | (int)array4[(int)((UIntPtr)(num8 + 1U))] << 8 | (int)array4[(int)((UIntPtr)num8)]);
				uint num10 = 255U;
				int num11 = 0;
				uint num12;
				if (j == num3 - 1 && num2 > 0)
				{
					num5 += num9;
					num12 = 0U;
					for (int k = 0; k < num2; k++)
					{
						if (k > 0)
						{
							num12 <<= 8;
						}
						num12 |= (uint)array7[array7.Length - (1 + k)];
					}
				}
				else
				{
					num8 = (uint)num7;
					num5 += num9;
					num12 = (uint)((int)array7[(int)((UIntPtr)(num8 + 3U))] << 24 | (int)array7[(int)((UIntPtr)(num8 + 2U))] << 16 | (int)array7[(int)((UIntPtr)(num8 + 1U))] << 8 | (int)array7[(int)((UIntPtr)num8)]);
				}
				num5 = num5;
				uint num13 = num5;
				uint num14 = num5;
				num14 ^= num14 << 25;
				num14 += 529777604U;
				num14 ^= num14 >> 27;
				num14 += 1981577986U;
				num14 ^= num14 << 5;
				num14 += 1110908134U;
				num14 = 244418234U + num14;
				num5 = num13 + (uint)num14;
				if (j == num3 - 1 && num2 > 0)
				{
					uint num15 = num5 ^ num12;
					for (int l = 0; l < num2; l++)
					{
						if (l > 0)
						{
							num10 <<= 8;
							num11 += 8;
						}
						array8[num7 + l] = (byte)((num15 & num10) >> num11);
					}
				}
				else
				{
					uint num16 = num5 ^ num12;
					array8[num7] = (byte)(num16 & 255U);
					array8[num7 + 1] = (byte)((num16 & 65280U) >> 8);
					array8[num7 + 2] = (byte)((num16 & 16711680U) >> 16);
					array8[num7 + 3] = (byte)((num16 & 4278190080U) >> 24);
				}
			}
			byte[] array9 = array8;
			int num17 = array9.Length / 8;
			byte* ptr;
			if ((array = array9) != null && array.Length != 0)
			{
				fixed (byte* ptr = &array[0])
				{
				}
			}
			else
			{
				ptr = null;
			}
			for (int m = 0; m < num17; m++)
			{
				((long*)ptr)[(IntPtr)m * 8] ^= 1232519835L;
			}
			ptr = null;
			@class = new Class1.Class4(new MemoryStream(array9));
			@class.method_0().Position = 0L;
			long num18 = Marshal.GetHINSTANCE(Class1.producerParameter.GetModules()[0]).ToInt64();
			int int_ = 0;
			int num19 = 0;
			if (Class1.producerParameter.Location == null || Class1.producerParameter.Location.Length == 0)
			{
				num19 = 7680;
			}
			int num20 = @class.method_3();
			int num21 = @class.method_3();
			if (num21 == 4)
			{
				SymmetricAlgorithm symmetricAlgorithm = Class1.smethod_7();
				symmetricAlgorithm.Mode = CipherMode.CBC;
				ICryptoTransform transform = symmetricAlgorithm.CreateDecryptor(array4, array6);
				Array.Clear(array4, 0, array4.Length);
				MemoryStream memoryStream = new MemoryStream();
				CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Write);
				cryptoStream.Write(array2, 0, array2.Length);
				cryptoStream.FlushFinalBlock();
				array9 = memoryStream.ToArray();
				Array.Clear(array6, 0, array6.Length);
				memoryStream.Close();
				cryptoStream.Close();
				@class.method_4();
				num20 = @class.method_3();
				num21 = @class.method_3();
			}
			if (num21 == 1)
			{
				IntPtr intptr_ = IntPtr.Zero;
				intptr_ = Class1.smethod_28(56U, 1, (uint)Process.GetCurrentProcess().Id);
				if (IntPtr.Size == 4)
				{
					Class1._AccountAuthentication = Marshal.GetHINSTANCE(Class1.producerParameter.GetModules()[0]).ToInt32();
				}
				Class1.stateAuthentication = Marshal.GetHINSTANCE(Class1.producerParameter.GetModules()[0]).ToInt64();
				IntPtr zero = IntPtr.Zero;
				for (int n = 0; n < num20; n++)
				{
					IntPtr intPtr = new IntPtr(Class1.stateAuthentication + (long)@class.method_3() - (long)num19);
					Class1.smethod_27(intPtr, 4, 4, ref int_);
					if (IntPtr.Size == 4)
					{
						Class1.smethod_26(intptr_, intPtr, BitConverter.GetBytes(@class.method_3()), 4U, out zero);
					}
					else
					{
						Class1.smethod_26(intptr_, intPtr, BitConverter.GetBytes(@class.method_3()), 4U, out zero);
					}
					Class1.smethod_27(intPtr, 4, int_, ref int_);
				}
				while (@class.method_0().Position < @class.method_0().Length - 1L)
				{
					int num22 = @class.method_3();
					IntPtr intptr_2 = new IntPtr(Class1.stateAuthentication + (long)num22 - (long)num19);
					int num23 = @class.method_3();
					Class1.smethod_27(intptr_2, num23 * 4, 4, ref int_);
					for (int num24 = 0; num24 < num23; num24++)
					{
						Marshal.WriteInt32(new IntPtr(intptr_2.ToInt64() + (long)(num24 * 4)), @class.method_3());
					}
					Class1.smethod_27(intptr_2, num23 * 4, int_, ref int_);
				}
				Class1.smethod_29(intptr_);
				return;
			}
			for (int num25 = 0; num25 < num20; num25++)
			{
				IntPtr intPtr2 = new IntPtr(num18 + (long)@class.method_3() - (long)num19);
				Class1.smethod_27(intPtr2, 4, 4, ref int_);
				Marshal.WriteInt32(intPtr2, @class.method_3());
				Class1.smethod_27(intPtr2, 4, int_, ref int_);
			}
			Class1.m_MockAuthentication = new Hashtable(@class.method_3() + 1);
			Class1.Struct10 @struct = default(Class1.Struct10);
			@struct.clientAuthentication = new byte[]
			{
				42
			};
			@struct.predicateAuthentication = false;
			Class1.m_MockAuthentication.Add(0L, @struct);
			while (@class.method_0().Position < @class.method_0().Length - 1L)
			{
				int num26 = @class.method_3() - num19;
				int num27 = @class.method_3();
				bool predicateAuthentication = false;
				if (num27 >= 1879048192)
				{
					predicateAuthentication = true;
				}
				int int_2 = @class.method_3();
				byte[] clientAuthentication = @class.method_1(int_2);
				Class1.Struct10 struct2 = default(Class1.Struct10);
				struct2.clientAuthentication = clientAuthentication;
				struct2.predicateAuthentication = predicateAuthentication;
				Class1.m_MockAuthentication.Add(num18 + (long)num26, struct2);
			}
			Class1.authenticationAuthentication = Marshal.GetHINSTANCE(typeof(Class1).Assembly.GetModules()[0]).ToInt64();
			if (IntPtr.Size == 4)
			{
				Class1.reponseAuthentication = Convert.ToInt32(Class1.authenticationAuthentication);
			}
			byte[] bytes = new byte[]
			{
				109,
				115,
				99,
				111,
				114,
				106,
				105,
				116,
				46,
				100,
				108,
				108
			};
			string @string = Encoding.UTF8.GetString(bytes);
			IntPtr intPtr3 = Class1.LoadLibrary(@string);
			if (intPtr3 == IntPtr.Zero)
			{
				bytes = new byte[]
				{
					99,
					108,
					114,
					106,
					105,
					116,
					46,
					100,
					108,
					108
				};
				@string = Encoding.UTF8.GetString(bytes);
				intPtr3 = Class1.LoadLibrary(@string);
			}
			byte[] bytes2 = new byte[]
			{
				103,
				101,
				116,
				74,
				105,
				116
			};
			string string2 = Encoding.UTF8.GetString(bytes2);
			IntPtr procAddress = Class1.GetProcAddress(intPtr3, string2);
			Class1.Delegate3 @delegate = (Class1.Delegate3)Class1.smethod_22(procAddress, typeof(Class1.Delegate3));
			IntPtr ptr2 = @delegate();
			long value = 0L;
			if (IntPtr.Size == 4)
			{
				value = (long)Marshal.ReadInt32(ptr2);
			}
			else
			{
				value = Marshal.ReadInt64(ptr2);
			}
			Marshal.ReadIntPtr(ptr2, 0);
			Class1._ParameterAuthentication = new Class1.Delegate2(Class1.smethod_19);
			IntPtr intPtr4 = IntPtr.Zero;
			intPtr4 = Marshal.GetFunctionPointerForDelegate(Class1._ParameterAuthentication);
			long num28 = 0L;
			if (IntPtr.Size == 4)
			{
				num28 = (long)Marshal.ReadInt32(new IntPtr(value));
			}
			else
			{
				num28 = Marshal.ReadInt64(new IntPtr(value));
			}
			Process currentProcess = Process.GetCurrentProcess();
			try
			{
				ProcessModuleCollection modules2 = currentProcess.Modules;
				foreach (object obj2 in modules2)
				{
					ProcessModule processModule2 = (ProcessModule)obj2;
					if (processModule2.ModuleName == @string && (num28 < processModule2.BaseAddress.ToInt64() || num28 > processModule2.BaseAddress.ToInt64() + (long)processModule2.ModuleMemorySize) && typeof(Class1).Assembly.EntryPoint != null)
					{
						return;
					}
				}
			}
			catch
			{
			}
			try
			{
				ProcessModuleCollection modules3 = currentProcess.Modules;
				foreach (object obj3 in modules3)
				{
					ProcessModule processModule3 = (ProcessModule)obj3;
					if (processModule3.BaseAddress.ToInt64() == Class1.authenticationAuthentication)
					{
						break;
					}
				}
			}
			catch
			{
			}
			Class1.m_ProccesorAuthentication = null;
			try
			{
				Class1.m_ProccesorAuthentication = (Class1.Delegate2)Class1.smethod_22(new IntPtr(num28), typeof(Class1.Delegate2));
			}
			catch
			{
				try
				{
					Delegate delegate2 = Class1.smethod_22(new IntPtr(num28), typeof(Class1.Delegate2));
					Class1.m_ProccesorAuthentication = (Class1.Delegate2)Delegate.CreateDelegate(typeof(Class1.Delegate2), delegate2.Method);
				}
				catch
				{
				}
			}
			int int_3 = 0;
			if (typeof(Class1).Assembly.EntryPoint != null)
			{
				if (typeof(Class1).Assembly.EntryPoint.GetParameters().Length == 2)
				{
					if (typeof(Class1).Assembly.Location != null)
					{
						if (typeof(Class1).Assembly.Location.Length > 0)
						{
							return;
						}
					}
				}
			}
			try
			{
				object value2 = typeof(Class1).Assembly.ManifestModule.ModuleHandle.GetType().GetField("m_ptr", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).GetValue(typeof(Class1).Assembly.ManifestModule.ModuleHandle);
				if (value2 is IntPtr)
				{
					Class1.definitionAuthentication = (IntPtr)value2;
				}
				if (value2.GetType().ToString() == "System.Reflection.RuntimeModule")
				{
					Class1.definitionAuthentication = (IntPtr)value2.GetType().GetField("m_pData", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).GetValue(value2);
				}
				MemoryStream memoryStream2 = new MemoryStream();
				memoryStream2.Write(new byte[IntPtr.Size], 0, IntPtr.Size);
				if (IntPtr.Size == 4)
				{
					memoryStream2.Write(BitConverter.GetBytes(Class1.definitionAuthentication.ToInt32()), 0, 4);
				}
				else
				{
					memoryStream2.Write(BitConverter.GetBytes(Class1.definitionAuthentication.ToInt64()), 0, 8);
				}
				memoryStream2.Write(new byte[IntPtr.Size], 0, IntPtr.Size);
				memoryStream2.Write(new byte[IntPtr.Size], 0, IntPtr.Size);
				memoryStream2.Position = 0L;
				byte[] array10 = memoryStream2.ToArray();
				memoryStream2.Close();
				uint num29 = 0U;
				try
				{
					byte* ptr3;
					if ((array = array10) != null && array.Length != 0)
					{
						fixed (byte* ptr3 = &array[0])
						{
						}
					}
					else
					{
						ptr3 = null;
					}
					Class1._ParameterAuthentication(new IntPtr((void*)ptr3), new IntPtr((void*)ptr3), new IntPtr((void*)ptr3), 216669565U, new IntPtr((void*)ptr3), ref num29);
				}
				finally
				{
					byte* ptr3 = null;
				}
			}
			catch
			{
			}
			RuntimeHelpers.PrepareDelegate(Class1.m_ProccesorAuthentication);
			RuntimeHelpers.PrepareMethod(Class1.m_ProccesorAuthentication.Method.MethodHandle);
			RuntimeHelpers.PrepareDelegate(Class1._ParameterAuthentication);
			RuntimeHelpers.PrepareMethod(Class1._ParameterAuthentication.Method.MethodHandle);
			byte[] array11;
			if (IntPtr.Size != 4)
			{
				array11 = new byte[]
				{
					72,
					184,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					73,
					57,
					64,
					8,
					116,
					12,
					72,
					184,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					byte.MaxValue,
					224,
					72,
					184,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					byte.MaxValue,
					224
				};
			}
			else
			{
				array11 = new byte[]
				{
					85,
					139,
					236,
					139,
					69,
					16,
					129,
					120,
					4,
					125,
					29,
					234,
					12,
					116,
					7,
					184,
					182,
					177,
					74,
					6,
					235,
					5,
					184,
					182,
					146,
					64,
					12,
					93,
					byte.MaxValue,
					224
				};
			}
			IntPtr intPtr5 = Class1.smethod_25(IntPtr.Zero, (uint)array11.Length, 4096U, 64U);
			byte[] array12 = array11;
			byte[] bytes3;
			byte[] bytes4;
			byte[] bytes5;
			if (IntPtr.Size == 4)
			{
				bytes3 = BitConverter.GetBytes(Class1.definitionAuthentication.ToInt32());
				bytes4 = BitConverter.GetBytes(intPtr4.ToInt32());
				bytes5 = BitConverter.GetBytes(Convert.ToInt32(num28));
			}
			else
			{
				bytes3 = BitConverter.GetBytes(Class1.definitionAuthentication.ToInt64());
				bytes4 = BitConverter.GetBytes(intPtr4.ToInt64());
				bytes5 = BitConverter.GetBytes(num28);
			}
			if (IntPtr.Size == 4)
			{
				array12[9] = bytes3[0];
				array12[10] = bytes3[1];
				array12[11] = bytes3[2];
				array12[12] = bytes3[3];
				array12[16] = bytes5[0];
				array12[17] = bytes5[1];
				array12[18] = bytes5[2];
				array12[19] = bytes5[3];
				array12[23] = bytes4[0];
				array12[24] = bytes4[1];
				array12[25] = bytes4[2];
				array12[26] = bytes4[3];
			}
			else
			{
				array12[2] = bytes3[0];
				array12[3] = bytes3[1];
				array12[4] = bytes3[2];
				array12[5] = bytes3[3];
				array12[6] = bytes3[4];
				array12[7] = bytes3[5];
				array12[8] = bytes3[6];
				array12[9] = bytes3[7];
				array12[18] = bytes5[0];
				array12[19] = bytes5[1];
				array12[20] = bytes5[2];
				array12[21] = bytes5[3];
				array12[22] = bytes5[4];
				array12[23] = bytes5[5];
				array12[24] = bytes5[6];
				array12[25] = bytes5[7];
				array12[30] = bytes4[0];
				array12[31] = bytes4[1];
				array12[32] = bytes4[2];
				array12[33] = bytes4[3];
				array12[34] = bytes4[4];
				array12[35] = bytes4[5];
				array12[36] = bytes4[6];
				array12[37] = bytes4[7];
			}
			Marshal.Copy(array12, 0, intPtr5, array12.Length);
			Class1.m_ContainerAuthentication = false;
			Class1.smethod_27(new IntPtr(value), IntPtr.Size, 64, ref int_3);
			Marshal.WriteIntPtr(new IntPtr(value), intPtr5);
			Class1.smethod_27(new IntPtr(value), IntPtr.Size, int_3, ref int_3);
			return;
		}
	}

	// Token: 0x0600145C RID: 5212 RVA: 0x0008B890 File Offset: 0x00089A90
	internal static object PvroikJllY(Assembly assembly_0)
	{
		try
		{
			if (File.Exists(((Assembly)assembly_0).Location))
			{
				return ((Assembly)assembly_0).Location;
			}
		}
		catch
		{
		}
		try
		{
			if (File.Exists(((Assembly)assembly_0).GetName().CodeBase.ToString().Replace("file:///", "")))
			{
				return ((Assembly)assembly_0).GetName().CodeBase.ToString().Replace("file:///", "");
			}
		}
		catch
		{
		}
		try
		{
			if (File.Exists(assembly_0.GetType().GetProperty("Location").GetValue(assembly_0, new object[0]).ToString()))
			{
				return assembly_0.GetType().GetProperty("Location").GetValue(assembly_0, new object[0]).ToString();
			}
		}
		catch
		{
		}
		return "";
	}

	// Token: 0x0600145D RID: 5213
	[DllImport("kernel32")]
	public static extern IntPtr LoadLibrary(string string_0);

	// Token: 0x0600145E RID: 5214
	[DllImport("kernel32", CharSet = CharSet.Ansi)]
	public static extern IntPtr GetProcAddress(IntPtr intptr_0, string string_0);

	// Token: 0x0600145F RID: 5215 RVA: 0x0008B99C File Offset: 0x00089B9C
	private static IntPtr smethod_24(IntPtr intptr_0, string string_0, uint uint_0)
	{
		if (Class1.m_AdapterAuthentication == null)
		{
			IntPtr procAddress = Class1.GetProcAddress(Class1.umLocehuEC(), "Find ".Trim() + "ResourceA");
			Class1.m_AdapterAuthentication = (Class1.Delegate4)Marshal.GetDelegateForFunctionPointer(procAddress, typeof(Class1.Delegate4));
		}
		return Class1.m_AdapterAuthentication(intptr_0, string_0, uint_0);
	}

	// Token: 0x06001460 RID: 5216 RVA: 0x0008B9F8 File Offset: 0x00089BF8
	private static IntPtr smethod_25(IntPtr intptr_0, uint uint_0, uint uint_1, uint uint_2)
	{
		if (Class1._InitializerAuthentication == null)
		{
			IntPtr procAddress = Class1.GetProcAddress(Class1.umLocehuEC(), "Virtual ".Trim() + "Alloc");
			Class1._InitializerAuthentication = (Class1.Delegate5)Marshal.GetDelegateForFunctionPointer(procAddress, typeof(Class1.Delegate5));
		}
		return Class1._InitializerAuthentication(intptr_0, uint_0, uint_1, uint_2);
	}

	// Token: 0x06001461 RID: 5217 RVA: 0x0008BA54 File Offset: 0x00089C54
	private static int smethod_26(IntPtr intptr_0, IntPtr intptr_1, [In] [Out] byte[] byte_0, uint uint_0, out IntPtr intptr_2)
	{
		if (Class1.systemAuthentication == null)
		{
			IntPtr procAddress = Class1.GetProcAddress(Class1.umLocehuEC(), "Write ".Trim() + "Process ".Trim() + "Memory");
			Class1.systemAuthentication = (Class1.Delegate6)Marshal.GetDelegateForFunctionPointer(procAddress, typeof(Class1.Delegate6));
		}
		return Class1.systemAuthentication(intptr_0, intptr_1, byte_0, uint_0, out intptr_2);
	}

	// Token: 0x06001462 RID: 5218 RVA: 0x0008BABC File Offset: 0x00089CBC
	private static int smethod_27(IntPtr intptr_0, int int_0, int int_1, ref int int_2)
	{
		if (Class1._WriterAuthentication == null)
		{
			IntPtr procAddress = Class1.GetProcAddress(Class1.umLocehuEC(), "Virtual ".Trim() + "Protect");
			Class1._WriterAuthentication = (Class1.Delegate7)Marshal.GetDelegateForFunctionPointer(procAddress, typeof(Class1.Delegate7));
		}
		return Class1._WriterAuthentication(intptr_0, int_0, int_1, ref int_2);
	}

	// Token: 0x06001463 RID: 5219 RVA: 0x0008BB18 File Offset: 0x00089D18
	private static IntPtr smethod_28(uint uint_0, int int_0, uint uint_1)
	{
		if (Class1._BroadcasterAuthentication == null)
		{
			IntPtr procAddress = Class1.GetProcAddress(Class1.umLocehuEC(), "Open ".Trim() + "Process");
			Class1._BroadcasterAuthentication = (Class1.Delegate8)Marshal.GetDelegateForFunctionPointer(procAddress, typeof(Class1.Delegate8));
		}
		return Class1._BroadcasterAuthentication(uint_0, int_0, uint_1);
	}

	// Token: 0x06001464 RID: 5220 RVA: 0x0008BB74 File Offset: 0x00089D74
	private static int smethod_29(IntPtr intptr_0)
	{
		if (Class1.m_AttributeAuthentication == null)
		{
			IntPtr procAddress = Class1.GetProcAddress(Class1.umLocehuEC(), "Close ".Trim() + "Handle");
			Class1.m_AttributeAuthentication = (Class1.Delegate9)Marshal.GetDelegateForFunctionPointer(procAddress, typeof(Class1.Delegate9));
		}
		return Class1.m_AttributeAuthentication(intptr_0);
	}

	// Token: 0x06001465 RID: 5221 RVA: 0x0000BB34 File Offset: 0x00009D34
	private static IntPtr umLocehuEC()
	{
		if (Class1.m_SpecificationAuthentication == IntPtr.Zero)
		{
			Class1.m_SpecificationAuthentication = Class1.LoadLibrary("kernel ".Trim() + "32.dll");
		}
		return Class1.m_SpecificationAuthentication;
	}

	// Token: 0x06001466 RID: 5222 RVA: 0x0008BBD0 File Offset: 0x00089DD0
	[Class1.Attribute0(typeof(Class1.Attribute0.Class2<object>[]))]
	private static byte[] smethod_30(string string_0)
	{
		byte[] array;
		using (FileStream fileStream = new FileStream(string_0, FileMode.Open, FileAccess.Read, FileShare.Read))
		{
			int num = 0;
			long length = fileStream.Length;
			int i = (int)length;
			array = new byte[i];
			while (i > 0)
			{
				int num2 = fileStream.Read(array, num, i);
				num += num2;
				i -= num2;
			}
		}
		return array;
	}

	// Token: 0x06001468 RID: 5224 RVA: 0x0000BB6A File Offset: 0x00009D6A
	internal static byte[] smethod_31(Stream stream_0)
	{
		return ((MemoryStream)stream_0).ToArray();
	}

	// Token: 0x06001469 RID: 5225 RVA: 0x0008BC38 File Offset: 0x00089E38
	[Class1.Attribute0(typeof(Class1.Attribute0.Class2<object>[]))]
	private static byte[] smethod_32(byte[] byte_0)
	{
		Stream stream = new MemoryStream();
		SymmetricAlgorithm symmetricAlgorithm = Class1.smethod_7();
		symmetricAlgorithm.Key = new byte[]
		{
			123,
			5,
			74,
			12,
			244,
			156,
			221,
			154,
			121,
			221,
			183,
			41,
			121,
			65,
			9,
			43,
			67,
			81,
			23,
			43,
			74,
			63,
			64,
			23,
			95,
			185,
			226,
			244,
			45,
			194,
			211,
			43
		};
		symmetricAlgorithm.IV = new byte[]
		{
			117,
			254,
			41,
			121,
			65,
			52,
			9,
			43,
			221,
			154,
			12,
			54,
			68,
			241,
			68,
			66
		};
		CryptoStream cryptoStream = new CryptoStream(stream, symmetricAlgorithm.CreateDecryptor(), CryptoStreamMode.Write);
		cryptoStream.Write(byte_0, 0, byte_0.Length);
		cryptoStream.Close();
		return Class1.smethod_31(stream);
	}

	// Token: 0x0600146A RID: 5226 RVA: 0x0008BCAC File Offset: 0x00089EAC
	private byte[] method_0()
	{
		string text = "{11111-22222-10001-00001}";
		if (text.Length > 0)
		{
			return new byte[]
			{
				1,
				2
			};
		}
		return new byte[]
		{
			1,
			2
		};
	}

	// Token: 0x0600146B RID: 5227 RVA: 0x0008BCEC File Offset: 0x00089EEC
	private byte[] method_1()
	{
		string text = "{11111-22222-10001-00002}";
		if (text.Length > 0)
		{
			return new byte[]
			{
				1,
				2
			};
		}
		return new byte[]
		{
			1,
			2
		};
	}

	// Token: 0x0600146C RID: 5228 RVA: 0x0008BD2C File Offset: 0x00089F2C
	private byte[] method_2()
	{
		return null;
	}

	// Token: 0x0600146D RID: 5229 RVA: 0x0008BD2C File Offset: 0x00089F2C
	private byte[] method_3()
	{
		return null;
	}

	// Token: 0x0600146E RID: 5230 RVA: 0x0008BD3C File Offset: 0x00089F3C
	private byte[] method_4()
	{
		return null;
	}

	// Token: 0x0600146F RID: 5231 RVA: 0x0008BD3C File Offset: 0x00089F3C
	private byte[] method_5()
	{
		return null;
	}

	// Token: 0x06001470 RID: 5232 RVA: 0x0008BD4C File Offset: 0x00089F4C
	internal byte[] method_6()
	{
		string text = "{11111-22222-40001-00001}";
		if (text.Length > 0)
		{
			return new byte[]
			{
				1,
				2
			};
		}
		return new byte[]
		{
			1,
			2
		};
	}

	// Token: 0x06001471 RID: 5233 RVA: 0x0008BD8C File Offset: 0x00089F8C
	internal byte[] method_7()
	{
		string text = "{11111-22222-40001-00002}";
		if (text.Length > 0)
		{
			return new byte[]
			{
				1,
				2
			};
		}
		return new byte[]
		{
			1,
			2
		};
	}

	// Token: 0x06001472 RID: 5234 RVA: 0x0008BD2C File Offset: 0x00089F2C
	internal byte[] method_8()
	{
		return null;
	}

	// Token: 0x06001473 RID: 5235 RVA: 0x0008BD2C File Offset: 0x00089F2C
	internal byte[] method_9()
	{
		return null;
	}

	// Token: 0x06001475 RID: 5237 RVA: 0x0000BB7F File Offset: 0x00009D7F
	internal static void ReadComposer()
	{
	}

	// Token: 0x06001476 RID: 5238 RVA: 0x0000BB82 File Offset: 0x00009D82
	internal static void ForgotComposer(bool bool_0)
	{
		RSACryptoServiceProvider.UseMachineKeyStore = bool_0;
	}

	// Token: 0x06001477 RID: 5239 RVA: 0x0000BB8D File Offset: 0x00009D8D
	internal static Type PrepareComposer(RuntimeTypeHandle runtimeTypeHandle_0)
	{
		return Type.GetTypeFromHandle(runtimeTypeHandle_0);
	}

	// Token: 0x06001478 RID: 5240 RVA: 0x0000BB98 File Offset: 0x00009D98
	internal static object ConnectComposer(Assembly assembly_0)
	{
		return assembly_0.Location;
	}

	// Token: 0x06001479 RID: 5241 RVA: 0x0000BBA3 File Offset: 0x00009DA3
	internal static int GetComposer(string string_0)
	{
		return string_0.Length;
	}

	// Token: 0x0600147A RID: 5242 RVA: 0x0000BBAE File Offset: 0x00009DAE
	internal static object CreateComposer()
	{
		return SHA1.Create();
	}

	// Token: 0x0600147B RID: 5243 RVA: 0x0000BBB5 File Offset: 0x00009DB5
	internal static object CalcComposer(string string_0)
	{
		return CryptoConfig.MapNameToOID(string_0);
	}

	// Token: 0x0600147C RID: 5244 RVA: 0x0000BBC0 File Offset: 0x00009DC0
	internal static bool CancelComposer(string string_0)
	{
		return File.Exists(string_0);
	}

	// Token: 0x0600147D RID: 5245 RVA: 0x0000BBCB File Offset: 0x00009DCB
	internal static object QueryComposer(Assembly assembly_0, string string_0)
	{
		return assembly_0.GetManifestResourceStream(string_0);
	}

	// Token: 0x0600147E RID: 5246 RVA: 0x0000BBDA File Offset: 0x00009DDA
	internal static object PrintComposer(Class1.Class4 class4_0)
	{
		return class4_0.method_0();
	}

	// Token: 0x0600147F RID: 5247 RVA: 0x0000BBE5 File Offset: 0x00009DE5
	internal static void PatchComposer(Stream stream_0, long long_0)
	{
		stream_0.Position = long_0;
	}

	// Token: 0x06001480 RID: 5248 RVA: 0x0000BBF4 File Offset: 0x00009DF4
	internal static long FillComposer(Stream stream_0)
	{
		return stream_0.Length;
	}

	// Token: 0x06001481 RID: 5249 RVA: 0x0000BBFF File Offset: 0x00009DFF
	internal static object StopComposer(Class1.Class4 class4_0, int int_0)
	{
		return class4_0.method_1(int_0);
	}

	// Token: 0x06001482 RID: 5250 RVA: 0x0000BC0E File Offset: 0x00009E0E
	internal static object ResetComposer()
	{
		return Class1.smethod_7();
	}

	// Token: 0x06001483 RID: 5251 RVA: 0x0000BC15 File Offset: 0x00009E15
	internal static void DestroyComposer(SymmetricAlgorithm symmetricAlgorithm_0, CipherMode cipherMode_0)
	{
		symmetricAlgorithm_0.Mode = cipherMode_0;
	}

	// Token: 0x06001484 RID: 5252 RVA: 0x0000BC24 File Offset: 0x00009E24
	internal static object MapComposer(SymmetricAlgorithm symmetricAlgorithm_0, byte[] byte_0, byte[] byte_1)
	{
		return symmetricAlgorithm_0.CreateDecryptor(byte_0, byte_1);
	}

	// Token: 0x06001485 RID: 5253 RVA: 0x0000BC37 File Offset: 0x00009E37
	internal static object VerifyComposer()
	{
		return new MemoryStream();
	}

	// Token: 0x06001486 RID: 5254 RVA: 0x0000BC3E File Offset: 0x00009E3E
	internal static void MoveComposer(Stream stream_0, byte[] byte_0, int int_0, int int_1)
	{
		stream_0.Write(byte_0, int_0, int_1);
	}

	// Token: 0x06001487 RID: 5255 RVA: 0x0000BC55 File Offset: 0x00009E55
	internal static void OrderComposer(CryptoStream cryptoStream_0)
	{
		cryptoStream_0.FlushFinalBlock();
	}

	// Token: 0x06001488 RID: 5256 RVA: 0x0000BC60 File Offset: 0x00009E60
	internal static object ViewComposer()
	{
		return Encoding.UTF8;
	}

	// Token: 0x06001489 RID: 5257 RVA: 0x0000BC67 File Offset: 0x00009E67
	internal static object SelectComposer(Stream stream_0)
	{
		return Class1.smethod_31(stream_0);
	}

	// Token: 0x0600148A RID: 5258 RVA: 0x0000BC72 File Offset: 0x00009E72
	internal static object SearchComposer(Encoding encoding_0, byte[] byte_0)
	{
		return encoding_0.GetString(byte_0);
	}

	// Token: 0x0600148B RID: 5259 RVA: 0x0000BC81 File Offset: 0x00009E81
	internal static void CollectComposer(AsymmetricAlgorithm asymmetricAlgorithm_0, string string_0)
	{
		asymmetricAlgorithm_0.FromXmlString(string_0);
	}

	// Token: 0x0600148C RID: 5260 RVA: 0x0000BC90 File Offset: 0x00009E90
	internal static void DeleteComposer(Stream stream_0)
	{
		stream_0.Close();
	}

	// Token: 0x0600148D RID: 5261 RVA: 0x0000BC9B File Offset: 0x00009E9B
	internal static void ComputeComposer(Class1.Class4 class4_0)
	{
		class4_0.method_4();
	}

	// Token: 0x0600148E RID: 5262 RVA: 0x0000BCA6 File Offset: 0x00009EA6
	internal static void ExcludeComposer(HashAlgorithm hashAlgorithm_0, Stream stream_0, uint uint_0, byte[] byte_0)
	{
		Class1.smethod_10(hashAlgorithm_0, stream_0, uint_0, byte_0);
	}

	// Token: 0x0600148F RID: 5263 RVA: 0x0000BCBD File Offset: 0x00009EBD
	internal static ushort TestComposer(BinaryReader binaryReader_0)
	{
		return binaryReader_0.ReadUInt16();
	}

	// Token: 0x06001490 RID: 5264 RVA: 0x0000BCC8 File Offset: 0x00009EC8
	internal static int PopComposer(Stream stream_0, byte[] byte_0, int int_0, int int_1)
	{
		return stream_0.Read(byte_0, int_0, int_1);
	}

	// Token: 0x06001491 RID: 5265 RVA: 0x0000BCDF File Offset: 0x00009EDF
	internal static void IncludeComposer(HashAlgorithm hashAlgorithm_0, byte[] byte_0, int int_0, int int_1)
	{
		Class1.smethod_11(hashAlgorithm_0, byte_0, int_0, int_1);
	}

	// Token: 0x06001492 RID: 5266 RVA: 0x0000BCF6 File Offset: 0x00009EF6
	internal static long PublishComposer(Stream stream_0)
	{
		return stream_0.Position;
	}

	// Token: 0x06001493 RID: 5267 RVA: 0x0000BD01 File Offset: 0x00009F01
	internal static uint PostComposer(BinaryReader binaryReader_0)
	{
		return binaryReader_0.ReadUInt32();
	}

	// Token: 0x06001494 RID: 5268 RVA: 0x0000BD0C File Offset: 0x00009F0C
	internal static uint ChangeComposer(uint uint_0, int int_0, long long_0, BinaryReader binaryReader_0)
	{
		return Class1.smethod_12(uint_0, int_0, long_0, binaryReader_0);
	}

	// Token: 0x06001495 RID: 5269 RVA: 0x0000BD23 File Offset: 0x00009F23
	internal static long NewComposer(long long_0, long long_1)
	{
		return Math.Min(long_0, long_1);
	}

	// Token: 0x06001496 RID: 5270 RVA: 0x0000BD32 File Offset: 0x00009F32
	internal static object WriteComposer(HashAlgorithm hashAlgorithm_0, byte[] byte_0, int int_0, int int_1)
	{
		return hashAlgorithm_0.TransformFinalBlock(byte_0, int_0, int_1);
	}

	// Token: 0x06001497 RID: 5271 RVA: 0x0000BD49 File Offset: 0x00009F49
	internal static object CalculateComposer(BinaryReader binaryReader_0, int int_0)
	{
		return binaryReader_0.ReadBytes(int_0);
	}

	// Token: 0x06001498 RID: 5272 RVA: 0x0000BD58 File Offset: 0x00009F58
	internal static void CompareComposer(Array array_0)
	{
		Array.Reverse(array_0);
	}

	// Token: 0x06001499 RID: 5273 RVA: 0x0000BD63 File Offset: 0x00009F63
	internal static object CountComposer(HashAlgorithm hashAlgorithm_0)
	{
		return hashAlgorithm_0.Hash;
	}

	// Token: 0x0600149A RID: 5274 RVA: 0x0000BD6E File Offset: 0x00009F6E
	internal static bool ValidateComposer(RSACryptoServiceProvider rsacryptoServiceProvider_0, byte[] byte_0, string string_0, byte[] byte_1)
	{
		return rsacryptoServiceProvider_0.VerifyHash(byte_0, string_0, byte_1);
	}

	// Token: 0x0600149B RID: 5275 RVA: 0x0000BD85 File Offset: 0x00009F85
	internal static object InsertComposer(Assembly assembly_0)
	{
		return assembly_0.GetName();
	}

	// Token: 0x0600149C RID: 5276 RVA: 0x0000BD90 File Offset: 0x00009F90
	internal static object UpdateComposer(AssemblyName assemblyName_0)
	{
		return assemblyName_0.Name;
	}

	// Token: 0x0600149D RID: 5277 RVA: 0x0000BD9B File Offset: 0x00009F9B
	internal static object ManageComposer(string string_0, string string_1)
	{
		return string_0 + string_1;
	}

	// Token: 0x0600149E RID: 5278 RVA: 0x0000BDAA File Offset: 0x00009FAA
	internal static bool ReflectComposer()
	{
		return null == null;
	}

	// Token: 0x0600149F RID: 5279 RVA: 0x0000BDB0 File Offset: 0x00009FB0
	internal static object VisitComposer()
	{
		return null;
	}

	// Token: 0x060014A0 RID: 5280 RVA: 0x0000BDB3 File Offset: 0x00009FB3
	internal static IntPtr CheckComposer(IntPtr intptr_0, int int_0)
	{
		return Marshal.ReadIntPtr(intptr_0, int_0);
	}

	// Token: 0x060014A1 RID: 5281 RVA: 0x0000BDC2 File Offset: 0x00009FC2
	internal static int SetComposer(IntPtr intptr_0, int int_0)
	{
		return Marshal.ReadInt32(intptr_0, int_0);
	}

	// Token: 0x060014A2 RID: 5282 RVA: 0x0000BDD1 File Offset: 0x00009FD1
	internal static long RateComposer(IntPtr intptr_0, int int_0)
	{
		return Marshal.ReadInt64(intptr_0, int_0);
	}

	// Token: 0x060014A3 RID: 5283 RVA: 0x0000BDE0 File Offset: 0x00009FE0
	internal static void ConcatComposer(IntPtr intptr_0, int int_0, IntPtr intptr_1)
	{
		Marshal.WriteIntPtr(intptr_0, int_0, intptr_1);
	}

	// Token: 0x060014A4 RID: 5284 RVA: 0x0000BDF3 File Offset: 0x00009FF3
	internal static void InitComposer(IntPtr intptr_0, int int_0, int int_1)
	{
		Marshal.WriteInt32(intptr_0, int_0, int_1);
	}

	// Token: 0x060014A5 RID: 5285 RVA: 0x0000BE06 File Offset: 0x0000A006
	internal static void FlushComposer(IntPtr intptr_0, int int_0, long long_0)
	{
		Marshal.WriteInt64(intptr_0, int_0, long_0);
	}

	// Token: 0x060014A6 RID: 5286 RVA: 0x0000BE19 File Offset: 0x0000A019
	internal static IntPtr EnableComposer(int int_0)
	{
		return Marshal.AllocCoTaskMem(int_0);
	}

	// Token: 0x060014A7 RID: 5287 RVA: 0x0000BE24 File Offset: 0x0000A024
	internal static void RunComposer(byte[] byte_0, int int_0, IntPtr intptr_0, int int_1)
	{
		Marshal.Copy(byte_0, int_0, intptr_0, int_1);
	}

	// Token: 0x060014A8 RID: 5288 RVA: 0x0000BE3B File Offset: 0x0000A03B
	internal static void SortComposer()
	{
		Class1.smethod_21();
	}

	// Token: 0x060014A9 RID: 5289 RVA: 0x0000BE42 File Offset: 0x0000A042
	internal static object RevertComposer()
	{
		return Process.GetCurrentProcess();
	}

	// Token: 0x060014AA RID: 5290 RVA: 0x0000BE49 File Offset: 0x0000A049
	internal static object AddClass(Process process_0)
	{
		return process_0.MainModule;
	}

	// Token: 0x060014AB RID: 5291 RVA: 0x0000BE54 File Offset: 0x0000A054
	internal static IntPtr SetupClass(ProcessModule processModule_0)
	{
		return processModule_0.BaseAddress;
	}

	// Token: 0x060014AC RID: 5292 RVA: 0x0000BE5F File Offset: 0x0000A05F
	internal static IntPtr RestartClass(IntPtr intptr_0, string string_0, uint uint_0)
	{
		return Class1.smethod_24(intptr_0, string_0, uint_0);
	}

	// Token: 0x060014AD RID: 5293 RVA: 0x0000BE72 File Offset: 0x0000A072
	internal static bool CallClass(IntPtr intptr_0, IntPtr intptr_1)
	{
		return intptr_0 != intptr_1;
	}

	// Token: 0x060014AE RID: 5294 RVA: 0x0000BB7F File Offset: 0x00009D7F
	internal static void ListClass()
	{
	}

	// Token: 0x060014AF RID: 5295 RVA: 0x0000BE81 File Offset: 0x0000A081
	internal static int AssetClass()
	{
		return IntPtr.Size;
	}

	// Token: 0x060014B0 RID: 5296 RVA: 0x0000BE88 File Offset: 0x0000A088
	internal static Type StartClass(string string_0, bool bool_0)
	{
		return Type.GetType(string_0, bool_0);
	}

	// Token: 0x060014B1 RID: 5297 RVA: 0x0000BE97 File Offset: 0x0000A097
	internal static bool RegisterClass(Type type_0, Type type_1)
	{
		return type_0 != type_1;
	}

	// Token: 0x060014B2 RID: 5298 RVA: 0x0000BEA6 File Offset: 0x0000A0A6
	internal static object FindClass(Process process_0)
	{
		return process_0.Modules;
	}

	// Token: 0x060014B3 RID: 5299 RVA: 0x0000BEB1 File Offset: 0x0000A0B1
	internal static object CloneClass(ReadOnlyCollectionBase readOnlyCollectionBase_0)
	{
		return readOnlyCollectionBase_0.GetEnumerator();
	}

	// Token: 0x060014B4 RID: 5300 RVA: 0x0000BEBC File Offset: 0x0000A0BC
	internal static object InvokeClass(IEnumerator ienumerator_0)
	{
		return ienumerator_0.Current;
	}

	// Token: 0x060014B5 RID: 5301 RVA: 0x0000BEC7 File Offset: 0x0000A0C7
	internal static object ResolveClass(ProcessModule processModule_0)
	{
		return processModule_0.ModuleName;
	}

	// Token: 0x060014B6 RID: 5302 RVA: 0x0000BED2 File Offset: 0x0000A0D2
	internal static object LoginClass(string string_0)
	{
		return string_0.ToLower();
	}

	// Token: 0x060014B7 RID: 5303 RVA: 0x0000BEDD File Offset: 0x0000A0DD
	internal static bool InstantiateClass(string string_0, string string_1)
	{
		return string_0 == string_1;
	}

	// Token: 0x060014B8 RID: 5304 RVA: 0x0000BEEC File Offset: 0x0000A0EC
	internal static object DisableClass(ProcessModule processModule_0)
	{
		return processModule_0.FileVersionInfo;
	}

	// Token: 0x060014B9 RID: 5305 RVA: 0x0000BEF7 File Offset: 0x0000A0F7
	internal static int ReflectClass(FileVersionInfo fileVersionInfo_0)
	{
		return fileVersionInfo_0.ProductMajorPart;
	}

	// Token: 0x060014BA RID: 5306 RVA: 0x0000BF02 File Offset: 0x0000A102
	internal static int VisitClass(FileVersionInfo fileVersionInfo_0)
	{
		return fileVersionInfo_0.ProductMinorPart;
	}

	// Token: 0x060014BB RID: 5307 RVA: 0x0000BF0D File Offset: 0x0000A10D
	internal static int ReadClass(FileVersionInfo fileVersionInfo_0)
	{
		return fileVersionInfo_0.ProductBuildPart;
	}

	// Token: 0x060014BC RID: 5308 RVA: 0x0000BF18 File Offset: 0x0000A118
	internal static int ForgotClass(FileVersionInfo fileVersionInfo_0)
	{
		return fileVersionInfo_0.ProductPrivatePart;
	}

	// Token: 0x060014BD RID: 5309 RVA: 0x0000BF23 File Offset: 0x0000A123
	internal static bool PrepareClass(Version version_0, Version version_1)
	{
		return version_0 >= version_1;
	}

	// Token: 0x060014BE RID: 5310 RVA: 0x0000BF32 File Offset: 0x0000A132
	internal static bool ConnectClass(Version version_0, Version version_1)
	{
		return version_0 < version_1;
	}

	// Token: 0x060014BF RID: 5311 RVA: 0x0000BF41 File Offset: 0x0000A141
	internal static bool GetClass(IEnumerator ienumerator_0)
	{
		return ienumerator_0.MoveNext();
	}

	// Token: 0x060014C0 RID: 5312 RVA: 0x0000BF4C File Offset: 0x0000A14C
	internal static void CreateClass(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x060014C1 RID: 5313 RVA: 0x0000BBCB File Offset: 0x00009DCB
	internal static object CalcClass(Assembly assembly_0, string string_0)
	{
		return assembly_0.GetManifestResourceStream(string_0);
	}

	// Token: 0x060014C2 RID: 5314 RVA: 0x0000BBDA File Offset: 0x00009DDA
	internal static object CancelClass(Class1.Class4 class4_0)
	{
		return class4_0.method_0();
	}

	// Token: 0x060014C3 RID: 5315 RVA: 0x0000BBE5 File Offset: 0x00009DE5
	internal static void QueryClass(Stream stream_0, long long_0)
	{
		stream_0.Position = long_0;
	}

	// Token: 0x060014C4 RID: 5316 RVA: 0x0000BBF4 File Offset: 0x00009DF4
	internal static long PrintClass(Stream stream_0)
	{
		return stream_0.Length;
	}

	// Token: 0x060014C5 RID: 5317 RVA: 0x0000BBFF File Offset: 0x00009DFF
	internal static object PatchClass(Class1.Class4 class4_0, int int_0)
	{
		return class4_0.method_1(int_0);
	}

	// Token: 0x060014C6 RID: 5318 RVA: 0x0000BD58 File Offset: 0x00009F58
	internal static void FillClass(Array array_0)
	{
		Array.Reverse(array_0);
	}

	// Token: 0x060014C7 RID: 5319 RVA: 0x0000BD85 File Offset: 0x00009F85
	internal static object StopClass(Assembly assembly_0)
	{
		return assembly_0.GetName();
	}

	// Token: 0x060014C8 RID: 5320 RVA: 0x0000BF57 File Offset: 0x0000A157
	internal static object ResetClass(AssemblyName assemblyName_0)
	{
		return assemblyName_0.GetPublicKeyToken();
	}

	// Token: 0x060014C9 RID: 5321 RVA: 0x0000BF62 File Offset: 0x0000A162
	internal static void DestroyClass(Array array_0, int int_0, int int_1)
	{
		Array.Clear(array_0, int_0, int_1);
	}

	// Token: 0x060014CA RID: 5322 RVA: 0x0000BF75 File Offset: 0x0000A175
	internal static object MapClass(Assembly assembly_0)
	{
		return assembly_0.GetModules();
	}

	// Token: 0x060014CB RID: 5323 RVA: 0x0000BF80 File Offset: 0x0000A180
	internal static IntPtr VerifyClass(Module module_0)
	{
		return Marshal.GetHINSTANCE(module_0);
	}

	// Token: 0x060014CC RID: 5324 RVA: 0x0000BB98 File Offset: 0x00009D98
	internal static object MoveClass(Assembly assembly_0)
	{
		return assembly_0.Location;
	}

	// Token: 0x060014CD RID: 5325 RVA: 0x0000BBA3 File Offset: 0x00009DA3
	internal static int OrderClass(string string_0)
	{
		return string_0.Length;
	}

	// Token: 0x060014CE RID: 5326 RVA: 0x0000BF8B File Offset: 0x0000A18B
	internal static int ViewClass(Class1.Class4 class4_0)
	{
		return class4_0.method_3();
	}

	// Token: 0x060014CF RID: 5327 RVA: 0x0000BC0E File Offset: 0x00009E0E
	internal static object SelectClass()
	{
		return Class1.smethod_7();
	}

	// Token: 0x060014D0 RID: 5328 RVA: 0x0000BC15 File Offset: 0x00009E15
	internal static void SearchClass(SymmetricAlgorithm symmetricAlgorithm_0, CipherMode cipherMode_0)
	{
		symmetricAlgorithm_0.Mode = cipherMode_0;
	}

	// Token: 0x060014D1 RID: 5329 RVA: 0x0000BC24 File Offset: 0x00009E24
	internal static object CollectClass(SymmetricAlgorithm symmetricAlgorithm_0, byte[] byte_0, byte[] byte_1)
	{
		return symmetricAlgorithm_0.CreateDecryptor(byte_0, byte_1);
	}

	// Token: 0x060014D2 RID: 5330 RVA: 0x0000BC3E File Offset: 0x00009E3E
	internal static void DeleteClass(Stream stream_0, byte[] byte_0, int int_0, int int_1)
	{
		stream_0.Write(byte_0, int_0, int_1);
	}

	// Token: 0x060014D3 RID: 5331 RVA: 0x0000BC55 File Offset: 0x00009E55
	internal static void ComputeClass(CryptoStream cryptoStream_0)
	{
		cryptoStream_0.FlushFinalBlock();
	}

	// Token: 0x060014D4 RID: 5332 RVA: 0x0000BF96 File Offset: 0x0000A196
	internal static object ExcludeClass(MemoryStream memoryStream_0)
	{
		return memoryStream_0.ToArray();
	}

	// Token: 0x060014D5 RID: 5333 RVA: 0x0000BC90 File Offset: 0x00009E90
	internal static void TestClass(Stream stream_0)
	{
		stream_0.Close();
	}

	// Token: 0x060014D6 RID: 5334 RVA: 0x0000BC9B File Offset: 0x00009E9B
	internal static void PopClass(Class1.Class4 class4_0)
	{
		class4_0.method_4();
	}

	// Token: 0x060014D7 RID: 5335 RVA: 0x0000BFA1 File Offset: 0x0000A1A1
	internal static int IncludeClass(Process process_0)
	{
		return process_0.Id;
	}

	// Token: 0x060014D8 RID: 5336 RVA: 0x0000BFAC File Offset: 0x0000A1AC
	internal static IntPtr PublishClass(uint uint_0, int int_0, uint uint_1)
	{
		return Class1.smethod_28(uint_0, int_0, uint_1);
	}

	// Token: 0x060014D9 RID: 5337 RVA: 0x0000BFBF File Offset: 0x0000A1BF
	internal static object PostClass(int int_0)
	{
		return BitConverter.GetBytes(int_0);
	}

	// Token: 0x060014DA RID: 5338 RVA: 0x0000BCF6 File Offset: 0x00009EF6
	internal static long ChangeClass(Stream stream_0)
	{
		return stream_0.Position;
	}

	// Token: 0x060014DB RID: 5339 RVA: 0x0000BFCA File Offset: 0x0000A1CA
	internal static void NewClass(IntPtr intptr_0, int int_0)
	{
		Marshal.WriteInt32(intptr_0, int_0);
	}

	// Token: 0x060014DC RID: 5340 RVA: 0x0000BFD9 File Offset: 0x0000A1D9
	internal static int WriteClass(IntPtr intptr_0)
	{
		return Class1.smethod_29(intptr_0);
	}

	// Token: 0x060014DD RID: 5341 RVA: 0x0000BFE4 File Offset: 0x0000A1E4
	internal static void CalculateClass(Hashtable hashtable_0, object object_0, object object_1)
	{
		hashtable_0.Add(object_0, object_1);
	}

	// Token: 0x060014DE RID: 5342 RVA: 0x0000BB8D File Offset: 0x00009D8D
	internal static Type CompareClass(RuntimeTypeHandle runtimeTypeHandle_0)
	{
		return Type.GetTypeFromHandle(runtimeTypeHandle_0);
	}

	// Token: 0x060014DF RID: 5343 RVA: 0x0000BFF7 File Offset: 0x0000A1F7
	internal static int CountClass(long long_0)
	{
		return Convert.ToInt32(long_0);
	}

	// Token: 0x060014E0 RID: 5344 RVA: 0x0000BC60 File Offset: 0x00009E60
	internal static object ValidateClass()
	{
		return Encoding.UTF8;
	}

	// Token: 0x060014E1 RID: 5345 RVA: 0x0000BC72 File Offset: 0x00009E72
	internal static object InsertClass(Encoding encoding_0, byte[] byte_0)
	{
		return encoding_0.GetString(byte_0);
	}

	// Token: 0x060014E2 RID: 5346 RVA: 0x0000C002 File Offset: 0x0000A202
	internal static bool UpdateClass(IntPtr intptr_0, IntPtr intptr_1)
	{
		return intptr_0 == intptr_1;
	}

	// Token: 0x060014E3 RID: 5347 RVA: 0x0000C011 File Offset: 0x0000A211
	internal static object ManageClass(IntPtr intptr_0, Type type_0)
	{
		return Class1.smethod_22(intptr_0, type_0);
	}

	// Token: 0x060014E4 RID: 5348 RVA: 0x0000C020 File Offset: 0x0000A220
	internal static IntPtr RemoveClass(Class1.Delegate3 delegate3_0)
	{
		return delegate3_0();
	}

	// Token: 0x060014E5 RID: 5349 RVA: 0x0000C02B File Offset: 0x0000A22B
	internal static int DefineClass(IntPtr intptr_0)
	{
		return Marshal.ReadInt32(intptr_0);
	}

	// Token: 0x060014E6 RID: 5350 RVA: 0x0000C036 File Offset: 0x0000A236
	internal static long LogoutClass(IntPtr intptr_0)
	{
		return Marshal.ReadInt64(intptr_0);
	}

	// Token: 0x060014E7 RID: 5351 RVA: 0x0000C041 File Offset: 0x0000A241
	internal static IntPtr CustomizeClass(Delegate delegate_0)
	{
		return Marshal.GetFunctionPointerForDelegate(delegate_0);
	}

	// Token: 0x060014E8 RID: 5352 RVA: 0x0000C04C File Offset: 0x0000A24C
	internal static int PushClass(ProcessModule processModule_0)
	{
		return processModule_0.ModuleMemorySize;
	}

	// Token: 0x060014E9 RID: 5353 RVA: 0x0000C057 File Offset: 0x0000A257
	internal static object InterruptClass(Assembly assembly_0)
	{
		return assembly_0.EntryPoint;
	}

	// Token: 0x060014EA RID: 5354 RVA: 0x0000C062 File Offset: 0x0000A262
	internal static bool AwakeClass(MethodInfo methodInfo_0, MethodInfo methodInfo_1)
	{
		return methodInfo_0 != methodInfo_1;
	}

	// Token: 0x060014EB RID: 5355 RVA: 0x0000C071 File Offset: 0x0000A271
	internal static object CheckClass(Delegate delegate_0)
	{
		return delegate_0.Method;
	}

	// Token: 0x060014EC RID: 5356 RVA: 0x0000C07C File Offset: 0x0000A27C
	internal static object SetClass(Type type_0, MethodInfo methodInfo_0)
	{
		return Delegate.CreateDelegate(type_0, methodInfo_0);
	}

	// Token: 0x060014ED RID: 5357 RVA: 0x0000C08B File Offset: 0x0000A28B
	internal static object RateClass(MethodBase methodBase_0)
	{
		return methodBase_0.GetParameters();
	}

	// Token: 0x060014EE RID: 5358 RVA: 0x0000C096 File Offset: 0x0000A296
	internal static object ConcatClass(Assembly assembly_0)
	{
		return assembly_0.ManifestModule;
	}

	// Token: 0x060014EF RID: 5359 RVA: 0x0000C0A1 File Offset: 0x0000A2A1
	internal static ModuleHandle InitClass(Module module_0)
	{
		return module_0.ModuleHandle;
	}

	// Token: 0x060014F0 RID: 5360 RVA: 0x0000C0AC File Offset: 0x0000A2AC
	internal static Type FlushClass(object object_0)
	{
		return object_0.GetType();
	}

	// Token: 0x060014F1 RID: 5361 RVA: 0x0000C0B7 File Offset: 0x0000A2B7
	internal static object EnableClass(FieldInfo fieldInfo_0, object object_0)
	{
		return fieldInfo_0.GetValue(object_0);
	}

	// Token: 0x060014F2 RID: 5362 RVA: 0x0000C0C6 File Offset: 0x0000A2C6
	internal static object RunClass(long long_0)
	{
		return BitConverter.GetBytes(long_0);
	}

	// Token: 0x060014F3 RID: 5363 RVA: 0x0000C0D1 File Offset: 0x0000A2D1
	internal static void SortClass(Delegate delegate_0)
	{
		RuntimeHelpers.PrepareDelegate(delegate_0);
	}

	// Token: 0x060014F4 RID: 5364 RVA: 0x0000C0DC File Offset: 0x0000A2DC
	internal static RuntimeMethodHandle RevertClass(MethodBase methodBase_0)
	{
		return methodBase_0.MethodHandle;
	}

	// Token: 0x060014F5 RID: 5365 RVA: 0x0000C0E7 File Offset: 0x0000A2E7
	internal static void AddServer(RuntimeMethodHandle runtimeMethodHandle_0)
	{
		RuntimeHelpers.PrepareMethod(runtimeMethodHandle_0);
	}

	// Token: 0x060014F6 RID: 5366 RVA: 0x0000C0F2 File Offset: 0x0000A2F2
	internal static void SetupServer(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
	{
		RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
	}

	// Token: 0x060014F7 RID: 5367 RVA: 0x0000C101 File Offset: 0x0000A301
	internal static IntPtr RestartServer(IntPtr intptr_0, uint uint_0, uint uint_1, uint uint_2)
	{
		return Class1.smethod_25(intptr_0, uint_0, uint_1, uint_2);
	}

	// Token: 0x060014F8 RID: 5368 RVA: 0x0000C118 File Offset: 0x0000A318
	internal static void CallServer(IntPtr intptr_0, IntPtr intptr_1)
	{
		Marshal.WriteIntPtr(intptr_0, intptr_1);
	}

	// Token: 0x060014F9 RID: 5369 RVA: 0x0000BDAA File Offset: 0x00009FAA
	internal static bool InterruptComposer()
	{
		return null == null;
	}

	// Token: 0x060014FA RID: 5370 RVA: 0x0000BDB0 File Offset: 0x00009FB0
	internal static object AwakeComposer()
	{
		return null;
	}

	// Token: 0x04000A5F RID: 2655
	internal static Assembly producerParameter;

	// Token: 0x04000A60 RID: 2656
	private static bool m_MappingParameter;

	// Token: 0x04000A61 RID: 2657
	private static int[] _ComparatorAuthentication;

	// Token: 0x04000A62 RID: 2658
	private static int tokenizerAuthentication;

	// Token: 0x04000A63 RID: 2659
	private static IntPtr definitionAuthentication;

	// Token: 0x04000A64 RID: 2660
	private static Class1.Delegate7 _WriterAuthentication;

	// Token: 0x04000A65 RID: 2661
	private static IntPtr m_SpecificationAuthentication;

	// Token: 0x04000A66 RID: 2662
	private static bool _IssuerAuthentication;

	// Token: 0x04000A67 RID: 2663
	private static Class1.Delegate4 m_AdapterAuthentication;

	// Token: 0x04000A68 RID: 2664
	internal static Hashtable m_MockAuthentication;

	// Token: 0x04000A69 RID: 2665
	private static uint[] m_CandidateParameter;

	// Token: 0x04000A6A RID: 2666
	private static int _AccountAuthentication;

	// Token: 0x04000A6B RID: 2667
	private static bool codeAuthentication;

	// Token: 0x04000A6C RID: 2668
	private static IntPtr resolverAuthentication;

	// Token: 0x04000A6D RID: 2669
	private static int reponseAuthentication;

	// Token: 0x04000A6E RID: 2670
	private static int m_PrototypeAuthentication;

	// Token: 0x04000A6F RID: 2671
	[Class1.Attribute0(typeof(Class1.Attribute0.Class2<object>[]))]
	private static bool _ParamsAuthentication;

	// Token: 0x04000A70 RID: 2672
	private static long stateAuthentication;

	// Token: 0x04000A71 RID: 2673
	private static bool m_ContainerAuthentication;

	// Token: 0x04000A72 RID: 2674
	internal static Class1.Delegate2 _ParameterAuthentication;

	// Token: 0x04000A73 RID: 2675
	private static Class1.Delegate8 _BroadcasterAuthentication;

	// Token: 0x04000A74 RID: 2676
	private static Class1.Delegate6 systemAuthentication;

	// Token: 0x04000A75 RID: 2677
	private static SortedList _RequestAuthentication;

	// Token: 0x04000A76 RID: 2678
	private static byte[] dispatcherParameter;

	// Token: 0x04000A77 RID: 2679
	private static long authenticationAuthentication;

	// Token: 0x04000A78 RID: 2680
	internal static RSACryptoServiceProvider _MessageParameter;

	// Token: 0x04000A79 RID: 2681
	private static bool _RegistryParameter = false;

	// Token: 0x04000A7A RID: 2682
	private static Dictionary<int, int> _StatusParameter;

	// Token: 0x04000A7B RID: 2683
	private static byte[] _ModelAuthentication;

	// Token: 0x04000A7C RID: 2684
	private static byte[] wrapperAuthentication;

	// Token: 0x04000A7D RID: 2685
	private static string[] m_TagAuthentication;

	// Token: 0x04000A7E RID: 2686
	private static bool m_SetterParameter;

	// Token: 0x04000A7F RID: 2687
	private static Class1.Delegate9 m_AttributeAuthentication;

	// Token: 0x04000A80 RID: 2688
	private static Class1.Delegate5 _InitializerAuthentication;

	// Token: 0x04000A81 RID: 2689
	internal static Class1.Delegate2 m_ProccesorAuthentication;

	// Token: 0x04000A82 RID: 2690
	private static object procParameter;

	// Token: 0x04000A83 RID: 2691
	private static IntPtr _RepositoryAuthentication;

	// Token: 0x020001CE RID: 462
	// (Invoke) Token: 0x060014FC RID: 5372
	private delegate void Delegate1(object o);

	// Token: 0x020001CF RID: 463
	internal class Attribute0 : Attribute
	{
		// Token: 0x06001500 RID: 5376 RVA: 0x0000C127 File Offset: 0x0000A327
		[Class1.Attribute0(typeof(Class1.Attribute0.Class2<object>[]))]
		public Attribute0(object object_0)
		{
		}

		// Token: 0x020001D0 RID: 464
		internal class Class2<T>
		{
		}
	}

	// Token: 0x020001D1 RID: 465
	internal class Class3
	{
		// Token: 0x06001504 RID: 5380 RVA: 0x0008BDCC File Offset: 0x00089FCC
		[Class1.Attribute0(typeof(Class1.Attribute0.Class2<object>[]))]
		internal static string smethod_0(string string_0, string string_1)
		{
			byte[] bytes = Encoding.Unicode.GetBytes(string_0);
			byte[] array = bytes;
			byte[] key = new byte[]
			{
				82,
				102,
				104,
				110,
				32,
				77,
				24,
				34,
				118,
				181,
				51,
				17,
				18,
				51,
				12,
				109,
				10,
				32,
				77,
				24,
				34,
				158,
				161,
				41,
				97,
				28,
				118,
				181,
				5,
				25,
				1,
				88
			};
			byte[] iv = Class1.smethod_9(Encoding.Unicode.GetBytes(string_1));
			MemoryStream memoryStream = new MemoryStream();
			SymmetricAlgorithm symmetricAlgorithm = Class1.smethod_7();
			symmetricAlgorithm.Key = key;
			symmetricAlgorithm.IV = iv;
			CryptoStream cryptoStream = new CryptoStream(memoryStream, symmetricAlgorithm.CreateEncryptor(), CryptoStreamMode.Write);
			cryptoStream.Write(array, 0, array.Length);
			cryptoStream.Close();
			return Convert.ToBase64String(memoryStream.ToArray());
		}
	}

	// Token: 0x020001D2 RID: 466
	// (Invoke) Token: 0x06001508 RID: 5384
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	internal delegate uint Delegate2(IntPtr classthis, IntPtr comp, IntPtr info, [MarshalAs(UnmanagedType.U4)] uint flags, IntPtr nativeEntry, ref uint nativeSizeOfCode);

	// Token: 0x020001D3 RID: 467
	// (Invoke) Token: 0x0600150D RID: 5389
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	private delegate IntPtr Delegate3();

	// Token: 0x020001D4 RID: 468
	internal struct Struct10
	{
		// Token: 0x04000A84 RID: 2692
		internal bool predicateAuthentication;

		// Token: 0x04000A85 RID: 2693
		internal byte[] clientAuthentication;
	}

	// Token: 0x020001D5 RID: 469
	internal class Class4
	{
		// Token: 0x06001511 RID: 5393 RVA: 0x0000C12F File Offset: 0x0000A32F
		public Class4(Stream stream_0)
		{
			this.infoAuthentication = new BinaryReader(stream_0);
		}

		// Token: 0x06001512 RID: 5394 RVA: 0x0000C143 File Offset: 0x0000A343
		internal Stream method_0()
		{
			return this.infoAuthentication.BaseStream;
		}

		// Token: 0x06001513 RID: 5395 RVA: 0x0000C150 File Offset: 0x0000A350
		internal byte[] method_1(int int_0)
		{
			return this.infoAuthentication.ReadBytes(int_0);
		}

		// Token: 0x06001514 RID: 5396 RVA: 0x0000C15E File Offset: 0x0000A35E
		internal int method_2(byte[] byte_0, int int_0, int int_1)
		{
			return this.infoAuthentication.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06001515 RID: 5397 RVA: 0x0000C16E File Offset: 0x0000A36E
		internal int method_3()
		{
			return this.infoAuthentication.ReadInt32();
		}

		// Token: 0x06001516 RID: 5398 RVA: 0x0000C17B File Offset: 0x0000A37B
		internal void method_4()
		{
			this.infoAuthentication.Close();
		}

		// Token: 0x04000A86 RID: 2694
		private BinaryReader infoAuthentication;
	}

	// Token: 0x020001D6 RID: 470
	// (Invoke) Token: 0x06001519 RID: 5401
	[UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Ansi)]
	private delegate IntPtr Delegate4(IntPtr hModule, string lpName, uint lpType);

	// Token: 0x020001D7 RID: 471
	// (Invoke) Token: 0x0600151E RID: 5406
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	private delegate IntPtr Delegate5(IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

	// Token: 0x020001D8 RID: 472
	// (Invoke) Token: 0x06001523 RID: 5411
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	private delegate int Delegate6(IntPtr hProcess, IntPtr lpBaseAddress, [In] [Out] byte[] buffer, uint size, out IntPtr lpNumberOfBytesWritten);

	// Token: 0x020001D9 RID: 473
	// (Invoke) Token: 0x06001528 RID: 5416
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	private delegate int Delegate7(IntPtr lpAddress, int dwSize, int flNewProtect, ref int lpflOldProtect);

	// Token: 0x020001DA RID: 474
	// (Invoke) Token: 0x0600152D RID: 5421
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	private delegate IntPtr Delegate8(uint dwDesiredAccess, int bInheritHandle, uint dwProcessId);

	// Token: 0x020001DB RID: 475
	// (Invoke) Token: 0x06001532 RID: 5426
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	private delegate int Delegate9(IntPtr ptr);

	// Token: 0x020001DC RID: 476
	[Flags]
	private enum Enum0
	{

	}
}
