﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Controls;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic.FileIO;
using NAudio.Wave;
using PCL.My;

namespace PCL
{
	// Token: 0x02000067 RID: 103
	[StandardModule]
	public sealed class ModMusic
	{
		// Token: 0x06000318 RID: 792 RVA: 0x0001BC48 File Offset: 0x00019E48
		private static void MusicListInit(bool ForceReload, string IgnoreFirst = "")
		{
			if (ForceReload)
			{
				ModMusic.m_RegWrapper = null;
			}
			try
			{
				if (ModMusic.m_RegWrapper == null)
				{
					ModMusic.m_RegWrapper = new List<string>();
					Directory.CreateDirectory(ModBase.Path + "PCL\\Musics\\");
					try
					{
						foreach (string text in MyWpfExtension.FindModel().FileSystem.GetFiles(ModBase.Path + "PCL\\Musics\\", Microsoft.VisualBasic.FileIO.SearchOption.SearchAllSubDirectories, new string[]
						{
							"*.*"
						}))
						{
							string left = text.Split(new char[]
							{
								'.'
							}).Last<string>().ToLower();
							if (Operators.CompareString(left, "ini", true) != 0 && Operators.CompareString(left, "jpg", true) != 0 && Operators.CompareString(left, "txt", true) != 0 && Operators.CompareString(left, "cfg", true) != 0 && Operators.CompareString(left, "png", true) != 0)
							{
								ModMusic.m_RegWrapper.Add(text);
							}
						}
					}
					finally
					{
						IEnumerator<string> enumerator;
						if (enumerator != null)
						{
							enumerator.Dispose();
						}
					}
				}
				ModMusic.m_ObjectWrapper = (List<string>)ModBase.RandomChaos<string>(new List<string>(ModMusic.m_RegWrapper));
				if (Operators.CompareString(IgnoreFirst, "", true) != 0 && ModMusic.m_ObjectWrapper.Count != 0 && Operators.CompareString(ModMusic.m_ObjectWrapper[0], IgnoreFirst, true) == 0)
				{
					ModMusic.m_ObjectWrapper.RemoveAt(0);
					ModMusic.m_ObjectWrapper.Add(IgnoreFirst);
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "初始化音乐列表失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000319 RID: 793 RVA: 0x0001BDF8 File Offset: 0x00019FF8
		private static string DequeueNextMusicAddress()
		{
			if (ModMusic.m_RegWrapper == null)
			{
				ModMusic.MusicListInit(false, "");
			}
			if (ModMusic.m_RegWrapper.Count == 0)
			{
				throw new Exception("在没有音乐时尝试获取音乐路径");
			}
			string text = ModMusic.m_ObjectWrapper[0];
			ModMusic.m_ObjectWrapper.RemoveAt(0);
			if (ModMusic.m_ObjectWrapper.Count == 0)
			{
				ModMusic.MusicListInit(false, text);
			}
			return text;
		}

		// Token: 0x0600031A RID: 794 RVA: 0x00003B64 File Offset: 0x00001D64
		private static void MusicRefreshUI()
		{
			ModBase.RunInUi((ModMusic._Closure$__.$I5-0 == null) ? (ModMusic._Closure$__.$I5-0 = delegate()
			{
				try
				{
					if (ModMusic.m_RegWrapper.Count == 0)
					{
						ModMain.m_CollectionAccount.BtnExtraMusic.Show = false;
					}
					else
					{
						ModMain.m_CollectionAccount.BtnExtraMusic.Show = true;
						string text = "正在播放：" + ModBase.GetFileNameWithoutExtentionFromPath(ModMusic._ComposerWrapper);
						if (ModMusic.AwakeRepository() == ModMusic.MusicStates.Pause)
						{
							ModMain.m_CollectionAccount.BtnExtraMusic.Logo = "M803.904 463.936a55.168 55.168 0 0 1 0 96.128l-463.616 264.448C302.848 845.888 256 819.136 256 776.448V247.616c0-42.752 46.848-69.44 84.288-48.064l463.616 264.384z";
							ModMain.m_CollectionAccount.BtnExtraMusic.RegisterModel(0.8);
							if (ModMusic.m_RegWrapper.Count > 1)
							{
								text += "\r\n左键播放，右键播放下一曲。";
							}
						}
						else
						{
							ModMain.m_CollectionAccount.BtnExtraMusic.Logo = "M348.293565 716.53287V254.797913c0-41.672348 28.004174-78.358261 68.919652-90.37913L815.994435 40.826435c62.775652-18.610087 125.907478 26.579478 125.907478 89.933913v539.158261c8.013913 42.25113-8.94887 89.177043-47.014956 127.109565a232.848696 232.848696 0 0 1-170.785392 65.758609c-61.885217-2.938435-111.081739-33.435826-129.113043-80.050087-18.031304-46.614261-2.137043-102.177391 41.672348-145.853218a232.848696 232.848696 0 0 1 170.785391-65.80313c21.014261 1.024 40.514783 5.164522 57.878261 12.065391V233.338435c0-12.109913-10.551652-20.034783-20.569044-20.034783a24.620522 24.620522 0 0 0-5.787826 0.934957L439.785739 338.18713a19.545043 19.545043 0 0 0-14.825739 19.144348v438.984348H423.846957c11.53113 43.987478-5.164522 94.208-45.412174 134.322087a232.848696 232.848696 0 0 1-170.785392 65.758609c-61.885217-2.938435-111.081739-33.435826-129.113043-80.050087-18.031304-46.614261-2.137043-102.177391 41.672348-145.853218a232.848696 232.848696 0 0 1 170.785391-65.80313c20.791652 1.024 40.069565 5.075478 57.299478 11.842783z";
							ModMain.m_CollectionAccount.BtnExtraMusic.RegisterModel(1.0);
							if (ModMusic.m_RegWrapper.Count > 1)
							{
								text += "\r\n左键暂停，右键播放下一曲。";
							}
						}
						ModMain.m_CollectionAccount.BtnExtraMusic.ToolTip = text;
						ToolTipService.SetVerticalOffset(ModMain.m_CollectionAccount.BtnExtraMusic, (double)(text.Contains("\n") ? 10 : 16));
					}
					if (ModMain.m_ExporterAccount != null)
					{
						ModMain.m_ExporterAccount.MusicRefreshUI();
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "刷新背景音乐 UI 失败", ModBase.LogLevel.Feedback, "出现错误");
				}
			}) : ModMusic._Closure$__.$I5-0, false);
		}

		// Token: 0x0600031B RID: 795 RVA: 0x0001BE5C File Offset: 0x0001A05C
		public static void MusicControlPause()
		{
			if (ModMusic._InvocationWrapper == null)
			{
				ModMain.Hint("音乐播放尚未开始！", ModMain.HintType.Critical, true);
				return;
			}
			ModMusic.MusicStates musicStates = ModMusic.AwakeRepository();
			if (musicStates == ModMusic.MusicStates.Play)
			{
				ModMusic.MusicPause();
				return;
			}
			if (musicStates == ModMusic.MusicStates.Pause)
			{
				ModMusic.MusicResume();
				return;
			}
			ModMain.Hint("音乐目前为停止状态！", ModMain.HintType.Critical, true);
		}

		// Token: 0x0600031C RID: 796 RVA: 0x0001BEA8 File Offset: 0x0001A0A8
		public static void MusicControlNext()
		{
			if (ModMusic.m_RegWrapper.Count == 1)
			{
				ModMain.Hint("播放列表中仅有一首歌曲！", ModMain.HintType.Info, true);
				return;
			}
			string text = ModMusic.DequeueNextMusicAddress();
			ModMusic.MusicStartPlay(text, false);
			ModMain.Hint("正在播放：" + ModBase.GetFileNameFromPath(text), ModMain.HintType.Finish, true);
			ModMusic.MusicRefreshUI();
		}

		// Token: 0x0600031D RID: 797 RVA: 0x0001BEF8 File Offset: 0x0001A0F8
		public static ModMusic.MusicStates AwakeRepository()
		{
			ModMusic.MusicStates result;
			if (ModMusic._InvocationWrapper == null)
			{
				result = ModMusic.MusicStates.Stop;
			}
			else
			{
				object left = NewLateBinding.LateGet(ModMusic._InvocationWrapper, null, "PlaybackState", new object[0], null, null, null);
				if (Operators.ConditionalCompareObjectEqual(left, 0, true))
				{
					result = ModMusic.MusicStates.Stop;
				}
				else if (Operators.ConditionalCompareObjectEqual(left, 2, true))
				{
					result = ModMusic.MusicStates.Pause;
				}
				else
				{
					result = ModMusic.MusicStates.Play;
				}
			}
			return result;
		}

		// Token: 0x0600031E RID: 798 RVA: 0x0001BF54 File Offset: 0x0001A154
		public static void MusicRefreshPlay(bool ShowHint, bool IsFirstLoad = false)
		{
			try
			{
				ModMusic.MusicListInit(true, "");
				if (ModMusic.m_RegWrapper.Count == 0)
				{
					if (ModMusic._InvocationWrapper == null)
					{
						if (ShowHint)
						{
							ModMain.Hint("未检测到可用的背景音乐！", ModMain.HintType.Critical, true);
						}
					}
					else
					{
						ModMusic._InvocationWrapper = null;
						if (ShowHint)
						{
							ModMain.Hint("背景音乐已清除！", ModMain.HintType.Finish, true);
						}
					}
				}
				else
				{
					string text = ModMusic.DequeueNextMusicAddress();
					try
					{
						ModMusic.MusicStartPlay(text, IsFirstLoad);
						if (ShowHint)
						{
							ModMain.Hint("背景音乐已刷新：" + ModBase.GetFileNameFromPath(text), ModMain.HintType.Finish, false);
						}
					}
					catch (Exception ex)
					{
					}
				}
				ModMusic.MusicRefreshUI();
			}
			catch (Exception ex2)
			{
				ModBase.Log(ex2, "刷新背景音乐播放失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x0600031F RID: 799 RVA: 0x0001C020 File Offset: 0x0001A220
		private static void MusicStartPlay(string Address, bool IsFirstLoad = false)
		{
			ModBase.Log("[Music] 播放开始：" + Address, ModBase.LogLevel.Normal, "出现错误");
			ModBase.RunInNewThread(delegate
			{
				ModMusic.MusicLoop(Address, IsFirstLoad);
			}, "Music", ThreadPriority.BelowNormal);
		}

		// Token: 0x06000320 RID: 800 RVA: 0x0001C074 File Offset: 0x0001A274
		public static bool MusicPause()
		{
			bool result;
			if (ModMusic.AwakeRepository() == ModMusic.MusicStates.Play)
			{
				ModBase.RunInThread((ModMusic._Closure$__.$I13-0 == null) ? (ModMusic._Closure$__.$I13-0 = delegate()
				{
					NewLateBinding.LateCall(ModMusic._InvocationWrapper, null, "Pause", new object[0], null, null, null, true);
					ModMusic.MusicRefreshUI();
				}) : ModMusic._Closure$__.$I13-0);
				result = true;
			}
			else
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000321 RID: 801 RVA: 0x0001C0BC File Offset: 0x0001A2BC
		public static bool MusicResume()
		{
			bool result;
			if (ModMusic.AwakeRepository() == ModMusic.MusicStates.Pause)
			{
				ModBase.RunInThread((ModMusic._Closure$__.$I14-0 == null) ? (ModMusic._Closure$__.$I14-0 = delegate()
				{
					NewLateBinding.LateCall(ModMusic._InvocationWrapper, null, "Play", new object[0], null, null, null, true);
					ModMusic.MusicRefreshUI();
				}) : ModMusic._Closure$__.$I14-0);
				result = true;
			}
			else
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000322 RID: 802 RVA: 0x0001C104 File Offset: 0x0001A304
		private static void MusicLoop(string Address, bool IsFirstLoad = false)
		{
			ModMusic._ComposerWrapper = Address;
			WaveOut waveOut = null;
			WaveStream waveStream = null;
			try
			{
				waveOut = new WaveOut();
				ModMusic._InvocationWrapper = waveOut;
				waveStream = new AudioFileReader(Address);
				waveOut.Init(waveStream);
				waveOut.Play();
				if (Conversions.ToBoolean(IsFirstLoad && Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiMusicAuto", null)))))
				{
					waveOut.Pause();
				}
				ModMusic.MusicRefreshUI();
				while (waveOut.Equals(RuntimeHelpers.GetObjectValue(ModMusic._InvocationWrapper)) && waveOut.PlaybackState != null)
				{
					waveOut.Volume = Conversions.ToSingle(Operators.DivideObject(ModBase._ParamsState.Get("UiMusicVolume", null), 1000));
					Thread.Sleep(50);
				}
				if (waveOut.PlaybackState == null && ModMusic.m_RegWrapper.Count > 0)
				{
					ModMusic.MusicStartPlay(ModMusic.DequeueNextMusicAddress(), false);
				}
			}
			catch (Exception ex)
			{
				if (!ex.Message.Contains("Got a frame at sample rate") && !ex.Message.Contains("does not support changes to"))
				{
					if (!Address.ToLower().EndsWith(".wav") && !Address.ToLower().EndsWith(".mp3") && !Address.ToLower().EndsWith(".flac"))
					{
						ModMain.Hint("播放音乐失败（" + ModBase.GetFileNameFromPath(Address) + "）：PCL2 可能不支持此音乐格式，请将格式转换为 .wav、.mp3 或 .flac 后再试", ModMain.HintType.Critical, true);
					}
					else
					{
						ModBase.Log(ex, "播放音乐失败（" + ModBase.GetFileNameFromPath(Address) + "）", ModBase.LogLevel.Hint, "出现错误");
					}
				}
				else
				{
					ModMain.Hint("播放音乐失败（" + ModBase.GetFileNameFromPath(Address) + "）：PCL2 不支持播放音频属性在中途发生变化的音乐", ModMain.HintType.Critical, true);
				}
				ModBase.Log(ex, "播放音乐失败（" + Address + "）", ModBase.LogLevel.Developer, "出现错误");
				if (ModMusic.m_RegWrapper.Count > 1)
				{
					Thread.Sleep(1000);
					ModMusic.MusicStartPlay(ModMusic.DequeueNextMusicAddress(), false);
				}
			}
			finally
			{
				if (waveOut != null)
				{
					waveOut.Dispose();
				}
				if (waveStream != null)
				{
					waveStream.Dispose();
				}
				ModMusic.MusicRefreshUI();
			}
		}

		// Token: 0x0400016E RID: 366
		public static List<string> m_ObjectWrapper = null;

		// Token: 0x0400016F RID: 367
		public static List<string> m_RegWrapper = null;

		// Token: 0x04000170 RID: 368
		public static WaveOut _InvocationWrapper = null;

		// Token: 0x04000171 RID: 369
		private static string _ComposerWrapper = "";

		// Token: 0x02000068 RID: 104
		public enum MusicStates
		{
			// Token: 0x04000173 RID: 371
			Stop,
			// Token: 0x04000174 RID: 372
			Play,
			// Token: 0x04000175 RID: 373
			Pause
		}
	}
}
