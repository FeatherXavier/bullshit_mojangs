﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000096 RID: 150
	[DesignerGenerated]
	public class PageDownloadPack : MyPageRight, IComponentConnector
	{
		// Token: 0x0600054D RID: 1357 RVA: 0x00004CCD File Offset: 0x00002ECD
		public PageDownloadPack()
		{
			base.Initialized += this.PageDownloadMod_Inited;
			this.InitializeComponent();
		}

		// Token: 0x0600054E RID: 1358 RVA: 0x0002AC4C File Offset: 0x00028E4C
		private void PageDownloadMod_Inited(object sender, EventArgs e)
		{
			base.PageLoaderInit(this.Load, this.PanLoad, this.CardProjects, this.PanAlways, PageDownloadPack._RegRepository, delegate(ModLoader.LoaderBase a0)
			{
				this.Load_OnFinish();
			}, new Func<object>(PageDownloadPack.LoaderInput), true);
		}

		// Token: 0x0600054F RID: 1359 RVA: 0x00004CEE File Offset: 0x00002EEE
		private static ModDownload.DlCfProjectRequest LoaderInput()
		{
			return new ModDownload.DlCfProjectRequest
			{
				identifierProccesor = true
			};
		}

		// Token: 0x06000550 RID: 1360 RVA: 0x0002AC98 File Offset: 0x00028E98
		private void Load_OnFinish()
		{
			try
			{
				this.PanProjects.Children.Clear();
				if (Operators.CompareString(PageDownloadPack._RegRepository.Input.m_ObjectProccesor, "", true) == 0)
				{
					this.CardProjects.Title = "热门整合包";
				}
				else
				{
					this.CardProjects.Title = "搜索结果 (" + Conversions.ToString(PageDownloadPack._RegRepository.Output.m_CallbackProccesor.Count) + (((long)PageDownloadPack._RegRepository.Output.m_CallbackProccesor.Count < PageDownloadPack._RegRepository.Output._ObserverProccesor) ? "+" : "") + ")";
				}
				try
				{
					foreach (ModDownload.DlCfProject dlCfProject in PageDownloadPack._RegRepository.Output.m_CallbackProccesor)
					{
						this.PanProjects.Children.Add(dlCfProject.ToCfItem(delegate(object sender, MouseButtonEventArgs e)
						{
							this.ProjectClick((MyCfItem)sender, e);
						}));
					}
				}
				finally
				{
					List<ModDownload.DlCfProject>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "可视化整合包列表出错", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000551 RID: 1361 RVA: 0x0002ADFC File Offset: 0x00028FFC
		private void Load_State(object sender, MyLoading.MyLoadingState state, MyLoading.MyLoadingState oldState)
		{
			ModBase.LoadState state2 = PageDownloadPack._RegRepository.State;
			if (state2 == ModBase.LoadState.Failed)
			{
				string text = "";
				if (ModDownload.m_ProductTag.Error != null)
				{
					text = ModDownload.m_ProductTag.Error.Message;
				}
				if (text.Contains("不是有效的 Json 文件"))
				{
					ModBase.Log("[Download] 下载的整合包列表 Json 文件损坏，已自动重试", ModBase.LogLevel.Debug, "出现错误");
					base.PageLoaderRestart(null, true);
				}
			}
		}

		// Token: 0x06000552 RID: 1362 RVA: 0x0002AE60 File Offset: 0x00029060
		private void Load_OnStart()
		{
			this.PanLoad.Visibility = Visibility.Visible;
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaOpacity(this.PanLoad, 1.0 - this.PanLoad.Opacity, 150, 0, null, false),
				ModAnimation.AaOpacity(this.CardProjects, -this.CardProjects.Opacity, 150, 0, null, false),
				ModAnimation.AaCode(delegate
				{
					this.CardProjects.Visibility = Visibility.Collapsed;
					this.PanProjects.Children.Clear();
				}, 0, true)
			}, "FrmDownloadPack Load Switch", false);
		}

		// Token: 0x06000553 RID: 1363 RVA: 0x000041BA File Offset: 0x000023BA
		public void ProjectClick(MyCfItem sender, EventArgs e)
		{
			ModMain.m_CollectionAccount.PageChange(new FormMain.PageStackData
			{
				m_CreatorParameter = FormMain.PageType.CfDetail,
				m_ObjectParameter = RuntimeHelpers.GetObjectValue(sender.Tag)
			}, FormMain.PageSubType.Default);
		}

		// Token: 0x06000554 RID: 1364 RVA: 0x00004CFC File Offset: 0x00002EFC
		private void TextSearchName_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Return)
			{
				PageDownloadPack.StartSearch();
			}
		}

		// Token: 0x06000555 RID: 1365 RVA: 0x0002AEFC File Offset: 0x000290FC
		private static void StartSearch()
		{
			ModDownload.DlCfProjectRequest input;
			if (ModMain.managerAccount == null)
			{
				input = PageDownloadPack.LoaderInput();
			}
			else
			{
				string text = ModMain.managerAccount.TextSearchName.Text;
				ModBase.Log("[Control] 整合包搜索请求输入文本：" + text, ModBase.LogLevel.Normal, "出现错误");
				input = new ModDownload.DlCfProjectRequest
				{
					m_ObjectProccesor = text,
					_InstanceProccesor = ModMain.managerAccount.TextSearchVersion.Text.Replace("全部", ""),
					_ListenerProccesor = checked((int)Math.Round(ModBase.Val(RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(ModMain.managerAccount.ComboSearchTag.SelectedItem, null, "Tag", new object[0], null, null, null))))),
					identifierProccesor = true
				};
			}
			PageDownloadPack._RegRepository.Start(input, false);
		}

		// Token: 0x06000556 RID: 1366 RVA: 0x0002AFC0 File Offset: 0x000291C0
		private void BtnSearchReset_Click(object sender, EventArgs e)
		{
			this.TextSearchName.Text = "";
			this.TextSearchVersion.SelectedIndex = 0;
			this.TextSearchVersion.Text = "全部";
			this.ComboSearchTag.SelectedIndex = 0;
			PageDownloadPack._RegRepository.LastFinishedTime = 0L;
		}

		// Token: 0x06000557 RID: 1367 RVA: 0x00004D0C File Offset: 0x00002F0C
		private void BtnSearchInstall_Click(object sender, EventArgs e)
		{
			ModModpack.ModpackInstall();
		}

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x06000558 RID: 1368 RVA: 0x00004D13 File Offset: 0x00002F13
		// (set) Token: 0x06000559 RID: 1369 RVA: 0x00004D1B File Offset: 0x00002F1B
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x0600055A RID: 1370 RVA: 0x00004D24 File Offset: 0x00002F24
		// (set) Token: 0x0600055B RID: 1371 RVA: 0x00004D2C File Offset: 0x00002F2C
		internal virtual MyCard PanAlways { get; set; }

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x0600055C RID: 1372 RVA: 0x00004D35 File Offset: 0x00002F35
		// (set) Token: 0x0600055D RID: 1373 RVA: 0x0002B018 File Offset: 0x00029218
		internal virtual MyTextBox TextSearchName
		{
			[CompilerGenerated]
			get
			{
				return this.itemRepository;
			}
			[CompilerGenerated]
			set
			{
				KeyEventHandler value2 = new KeyEventHandler(this.TextSearchName_KeyUp);
				MyTextBox myTextBox = this.itemRepository;
				if (myTextBox != null)
				{
					myTextBox.KeyUp -= value2;
				}
				this.itemRepository = value;
				myTextBox = this.itemRepository;
				if (myTextBox != null)
				{
					myTextBox.KeyUp += value2;
				}
			}
		}

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x0600055E RID: 1374 RVA: 0x00004D3D File Offset: 0x00002F3D
		// (set) Token: 0x0600055F RID: 1375 RVA: 0x00004D45 File Offset: 0x00002F45
		internal virtual MyComboBox ComboSearchTag { get; set; }

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x06000560 RID: 1376 RVA: 0x00004D4E File Offset: 0x00002F4E
		// (set) Token: 0x06000561 RID: 1377 RVA: 0x0002B05C File Offset: 0x0002925C
		internal virtual MyComboBox TextSearchVersion
		{
			[CompilerGenerated]
			get
			{
				return this.m_FactoryRepository;
			}
			[CompilerGenerated]
			set
			{
				KeyEventHandler value2 = new KeyEventHandler(this.TextSearchName_KeyUp);
				MyComboBox factoryRepository = this.m_FactoryRepository;
				if (factoryRepository != null)
				{
					factoryRepository.KeyUp -= value2;
				}
				this.m_FactoryRepository = value;
				factoryRepository = this.m_FactoryRepository;
				if (factoryRepository != null)
				{
					factoryRepository.KeyUp += value2;
				}
			}
		}

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x06000562 RID: 1378 RVA: 0x00004D56 File Offset: 0x00002F56
		// (set) Token: 0x06000563 RID: 1379 RVA: 0x0002B0A0 File Offset: 0x000292A0
		internal virtual MyButton BtnSearchRun
		{
			[CompilerGenerated]
			get
			{
				return this.m_ProcessRepository;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = (PageDownloadPack._Closure$__.$IR35-3 == null) ? (PageDownloadPack._Closure$__.$IR35-3 = delegate(object sender, EventArgs e)
				{
					PageDownloadPack.StartSearch();
				}) : PageDownloadPack._Closure$__.$IR35-3;
				MyButton processRepository = this.m_ProcessRepository;
				if (processRepository != null)
				{
					processRepository.RevertResolver(obj);
				}
				this.m_ProcessRepository = value;
				processRepository = this.m_ProcessRepository;
				if (processRepository != null)
				{
					processRepository.PostResolver(obj);
				}
			}
		}

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x06000564 RID: 1380 RVA: 0x00004D5E File Offset: 0x00002F5E
		// (set) Token: 0x06000565 RID: 1381 RVA: 0x0002B0FC File Offset: 0x000292FC
		internal virtual MyButton BtnSearchReset
		{
			[CompilerGenerated]
			get
			{
				return this._ValRepository;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnSearchReset_Click);
				MyButton valRepository = this._ValRepository;
				if (valRepository != null)
				{
					valRepository.RevertResolver(obj);
				}
				this._ValRepository = value;
				valRepository = this._ValRepository;
				if (valRepository != null)
				{
					valRepository.PostResolver(obj);
				}
			}
		}

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x06000566 RID: 1382 RVA: 0x00004D66 File Offset: 0x00002F66
		// (set) Token: 0x06000567 RID: 1383 RVA: 0x0002B140 File Offset: 0x00029340
		internal virtual MyButton BtnSearchInstall
		{
			[CompilerGenerated]
			get
			{
				return this.m_UtilsRepository;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnSearchInstall_Click);
				MyButton utilsRepository = this.m_UtilsRepository;
				if (utilsRepository != null)
				{
					utilsRepository.RevertResolver(obj);
				}
				this.m_UtilsRepository = value;
				utilsRepository = this.m_UtilsRepository;
				if (utilsRepository != null)
				{
					utilsRepository.PostResolver(obj);
				}
			}
		}

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x06000568 RID: 1384 RVA: 0x00004D6E File Offset: 0x00002F6E
		// (set) Token: 0x06000569 RID: 1385 RVA: 0x00004D76 File Offset: 0x00002F76
		internal virtual MyCard CardProjects { get; set; }

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x0600056A RID: 1386 RVA: 0x00004D7F File Offset: 0x00002F7F
		// (set) Token: 0x0600056B RID: 1387 RVA: 0x00004D87 File Offset: 0x00002F87
		internal virtual StackPanel PanProjects { get; set; }

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x0600056C RID: 1388 RVA: 0x00004D90 File Offset: 0x00002F90
		// (set) Token: 0x0600056D RID: 1389 RVA: 0x00004D98 File Offset: 0x00002F98
		internal virtual MyCard PanLoad { get; set; }

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x0600056E RID: 1390 RVA: 0x00004DA1 File Offset: 0x00002FA1
		// (set) Token: 0x0600056F RID: 1391 RVA: 0x0002B184 File Offset: 0x00029384
		internal virtual MyLoading Load
		{
			[CompilerGenerated]
			get
			{
				return this.m_ConnectionRepository;
			}
			[CompilerGenerated]
			set
			{
				MyLoading.StateChangedEventHandler obj = new MyLoading.StateChangedEventHandler(this.Load_State);
				MyLoading connectionRepository = this.m_ConnectionRepository;
				if (connectionRepository != null)
				{
					connectionRepository.RemoveWrapper(obj);
				}
				this.m_ConnectionRepository = value;
				connectionRepository = this.m_ConnectionRepository;
				if (connectionRepository != null)
				{
					connectionRepository.InstantiateWrapper(obj);
				}
			}
		}

		// Token: 0x06000570 RID: 1392 RVA: 0x0002B1C8 File Offset: 0x000293C8
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_CustomerRepository)
			{
				this.m_CustomerRepository = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagedownload/pagedownloadpack.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000571 RID: 1393 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000572 RID: 1394 RVA: 0x0002B1F8 File Offset: 0x000293F8
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanAlways = (MyCard)target;
				return;
			}
			if (connectionId == 3)
			{
				this.TextSearchName = (MyTextBox)target;
				return;
			}
			if (connectionId == 4)
			{
				this.ComboSearchTag = (MyComboBox)target;
				return;
			}
			if (connectionId == 5)
			{
				this.TextSearchVersion = (MyComboBox)target;
				return;
			}
			if (connectionId == 6)
			{
				this.BtnSearchRun = (MyButton)target;
				return;
			}
			if (connectionId == 7)
			{
				this.BtnSearchReset = (MyButton)target;
				return;
			}
			if (connectionId == 8)
			{
				this.BtnSearchInstall = (MyButton)target;
				return;
			}
			if (connectionId == 9)
			{
				this.CardProjects = (MyCard)target;
				return;
			}
			if (connectionId == 10)
			{
				this.PanProjects = (StackPanel)target;
				return;
			}
			if (connectionId == 11)
			{
				this.PanLoad = (MyCard)target;
				return;
			}
			if (connectionId == 12)
			{
				this.Load = (MyLoading)target;
				return;
			}
			this.m_CustomerRepository = true;
		}

		// Token: 0x0400027F RID: 639
		private static ModLoader.LoaderTask<ModDownload.DlCfProjectRequest, ModDownload.DlCfProjectResult> _RegRepository = new ModLoader.LoaderTask<ModDownload.DlCfProjectRequest, ModDownload.DlCfProjectResult>("DlCfProject ModPack", new Action<ModLoader.LoaderTask<ModDownload.DlCfProjectRequest, ModDownload.DlCfProjectResult>>(ModDownload.DlCfProjectSub), new Func<ModDownload.DlCfProjectRequest>(PageDownloadPack.LoaderInput), ThreadPriority.Normal)
		{
			ReloadTimeout = 60000
		};

		// Token: 0x04000280 RID: 640
		[CompilerGenerated]
		[AccessedThroughProperty("PanBack")]
		private MyScrollViewer _InvocationRepository;

		// Token: 0x04000281 RID: 641
		[CompilerGenerated]
		[AccessedThroughProperty("PanAlways")]
		private MyCard m_ComposerRepository;

		// Token: 0x04000282 RID: 642
		[AccessedThroughProperty("TextSearchName")]
		[CompilerGenerated]
		private MyTextBox itemRepository;

		// Token: 0x04000283 RID: 643
		[AccessedThroughProperty("ComboSearchTag")]
		[CompilerGenerated]
		private MyComboBox mapperRepository;

		// Token: 0x04000284 RID: 644
		[AccessedThroughProperty("TextSearchVersion")]
		[CompilerGenerated]
		private MyComboBox m_FactoryRepository;

		// Token: 0x04000285 RID: 645
		[AccessedThroughProperty("BtnSearchRun")]
		[CompilerGenerated]
		private MyButton m_ProcessRepository;

		// Token: 0x04000286 RID: 646
		[AccessedThroughProperty("BtnSearchReset")]
		[CompilerGenerated]
		private MyButton _ValRepository;

		// Token: 0x04000287 RID: 647
		[AccessedThroughProperty("BtnSearchInstall")]
		[CompilerGenerated]
		private MyButton m_UtilsRepository;

		// Token: 0x04000288 RID: 648
		[AccessedThroughProperty("CardProjects")]
		[CompilerGenerated]
		private MyCard orderRepository;

		// Token: 0x04000289 RID: 649
		[AccessedThroughProperty("PanProjects")]
		[CompilerGenerated]
		private StackPanel policyRepository;

		// Token: 0x0400028A RID: 650
		[CompilerGenerated]
		[AccessedThroughProperty("PanLoad")]
		private MyCard _ThreadRepository;

		// Token: 0x0400028B RID: 651
		[CompilerGenerated]
		[AccessedThroughProperty("Load")]
		private MyLoading m_ConnectionRepository;

		// Token: 0x0400028C RID: 652
		private bool m_CustomerRepository;
	}
}
