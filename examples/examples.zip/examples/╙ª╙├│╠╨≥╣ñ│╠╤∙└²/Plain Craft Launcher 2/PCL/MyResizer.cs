﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.VisualBasic;

namespace PCL
{
	// Token: 0x0200017E RID: 382
	public class MyResizer
	{
		// Token: 0x060011C0 RID: 4544 RVA: 0x00077AD0 File Offset: 0x00075CD0
		public MyResizer(Window target)
		{
			this.filterRequest = null;
			this._ReaderRequest = false;
			this.m_FieldRequest = false;
			this._PageRequest = false;
			this.printerRequest = false;
			this.tokenRequest = new Dictionary<UIElement, short>();
			this.m_InterpreterRequest = new Dictionary<UIElement, short>();
			this._ParserRequest = new Dictionary<UIElement, short>();
			this.m_StubRequest = new Dictionary<UIElement, short>();
			this.m_ErrorRequest = default(MyResizer.PointAPI);
			this.m_ExceptionRequest = default(Size);
			this.m_TestsRequest = default(MyResizer.POINT);
			this.filterRequest = target;
			if (Information.IsNothing(target))
			{
				throw new Exception("Invalid Window handle");
			}
			target.SourceInitialized += this.MyMacClass_SourceInitialized;
		}

		// Token: 0x060011C1 RID: 4545 RVA: 0x0000A67F File Offset: 0x0000887F
		private void MyMacClass_SourceInitialized(object sender, EventArgs e)
		{
			this.m_RulesRequest = (PresentationSource.FromVisual((Visual)sender) as HwndSource);
			this.m_RulesRequest.AddHook(new HwndSourceHook(this.WndProc));
		}

		// Token: 0x060011C2 RID: 4546 RVA: 0x0000A6AE File Offset: 0x000088AE
		private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
		{
			if (msg == 36)
			{
				MyResizer.WmGetMinMaxInfo(hwnd, lParam);
				handled = true;
			}
			return (IntPtr)0;
		}

		// Token: 0x060011C3 RID: 4547 RVA: 0x00077B84 File Offset: 0x00075D84
		private static void WmGetMinMaxInfo(IntPtr hwnd, IntPtr lParam)
		{
			object obj = Marshal.PtrToStructure(lParam, typeof(MyResizer.MINMAXINFO));
			MyResizer.MINMAXINFO minmaxinfo = (obj != null) ? ((MyResizer.MINMAXINFO)obj) : default(MyResizer.MINMAXINFO);
			IntPtr intPtr = MyResizer.MonitorFromWindow(hwnd, 2);
			checked
			{
				if (intPtr != IntPtr.Zero)
				{
					MyResizer.MONITORINFO monitorinfo = new MyResizer.MONITORINFO();
					MyResizer.GetMonitorInfo(intPtr, monitorinfo);
					MyResizer.RECT identifierParameter = monitorinfo.m_IdentifierParameter;
					MyResizer.RECT listenerParameter = monitorinfo.m_ListenerParameter;
					minmaxinfo.productParameter.m_VisitorParameter = Math.Abs(identifierParameter.bridgeParameter - listenerParameter.bridgeParameter);
					minmaxinfo.productParameter.helperParameter = Math.Abs(identifierParameter._StructParameter - listenerParameter._StructParameter);
					minmaxinfo.m_BaseParameter.helperParameter = Math.Abs(identifierParameter.templateParameter - identifierParameter._StructParameter);
					MyResizer.strategyRequest = minmaxinfo.m_BaseParameter.helperParameter;
					if (identifierParameter.Height == listenerParameter.Height)
					{
						ref int ptr = ref minmaxinfo.m_BaseParameter.helperParameter;
						minmaxinfo.m_BaseParameter.helperParameter = ptr - 2;
					}
				}
				Marshal.StructureToPtr<MyResizer.MINMAXINFO>(minmaxinfo, lParam, true);
			}
		}

		// Token: 0x060011C4 RID: 4548
		[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		private static extern bool GetMonitorInfo(IntPtr hMonitor, MyResizer.MONITORINFO lpmi);

		// Token: 0x060011C5 RID: 4549
		[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		internal static extern IntPtr MonitorFromWindow(IntPtr handle, int flags);

		// Token: 0x060011C6 RID: 4550 RVA: 0x0000A6C7 File Offset: 0x000088C7
		private void connectMouseHandlers(UIElement element)
		{
			element.MouseLeftButtonDown += this.element_MouseLeftButtonDown;
		}

		// Token: 0x060011C7 RID: 4551 RVA: 0x0000A6DB File Offset: 0x000088DB
		public void addResizerRight(UIElement element)
		{
			this.connectMouseHandlers(element);
			this.m_InterpreterRequest.Add(element, 0);
		}

		// Token: 0x060011C8 RID: 4552 RVA: 0x0000A6F1 File Offset: 0x000088F1
		public void addResizerLeft(UIElement element)
		{
			this.connectMouseHandlers(element);
			this.tokenRequest.Add(element, 0);
		}

		// Token: 0x060011C9 RID: 4553 RVA: 0x0000A707 File Offset: 0x00008907
		public void addResizerUp(UIElement element)
		{
			this.connectMouseHandlers(element);
			this._ParserRequest.Add(element, 0);
		}

		// Token: 0x060011CA RID: 4554 RVA: 0x0000A71D File Offset: 0x0000891D
		public void addResizerDown(UIElement element)
		{
			this.connectMouseHandlers(element);
			this.m_StubRequest.Add(element, 0);
		}

		// Token: 0x060011CB RID: 4555 RVA: 0x0000A733 File Offset: 0x00008933
		public void addResizerRightDown(UIElement element)
		{
			this.connectMouseHandlers(element);
			this.m_InterpreterRequest.Add(element, 0);
			this.m_StubRequest.Add(element, 0);
		}

		// Token: 0x060011CC RID: 4556 RVA: 0x0000A756 File Offset: 0x00008956
		public void addResizerLeftDown(UIElement element)
		{
			this.connectMouseHandlers(element);
			this.tokenRequest.Add(element, 0);
			this.m_StubRequest.Add(element, 0);
		}

		// Token: 0x060011CD RID: 4557 RVA: 0x0000A779 File Offset: 0x00008979
		public void addResizerRightUp(UIElement element)
		{
			this.connectMouseHandlers(element);
			this.m_InterpreterRequest.Add(element, 0);
			this._ParserRequest.Add(element, 0);
		}

		// Token: 0x060011CE RID: 4558 RVA: 0x0000A79C File Offset: 0x0000899C
		public void addResizerLeftUp(UIElement element)
		{
			this.connectMouseHandlers(element);
			this.tokenRequest.Add(element, 0);
			this._ParserRequest.Add(element, 0);
		}

		// Token: 0x060011CF RID: 4559 RVA: 0x00077C90 File Offset: 0x00075E90
		private void element_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			MyResizer.GetCursorPos(out this.m_ErrorRequest);
			checked
			{
				this.m_ErrorRequest.X = (int)Math.Round(ModBase.smethod_4((double)this.m_ErrorRequest.X));
				this.m_ErrorRequest.Y = (int)Math.Round(ModBase.smethod_4((double)this.m_ErrorRequest.Y));
				this.m_ExceptionRequest = new Size(this.filterRequest.Width, this.filterRequest.Height);
				this.m_TestsRequest = new MyResizer.POINT((int)Math.Round(this.filterRequest.Left), (int)Math.Round(this.filterRequest.Top));
				UIElement key = (UIElement)sender;
				if (this.tokenRequest.ContainsKey(key))
				{
					this.m_FieldRequest = true;
				}
				if (this.m_InterpreterRequest.ContainsKey(key))
				{
					this._ReaderRequest = true;
				}
				if (this._ParserRequest.ContainsKey(key))
				{
					this._PageRequest = true;
				}
				if (this.m_StubRequest.ContainsKey(key))
				{
					this.printerRequest = true;
				}
				ModBase.RunInNewThread(new Action(this.updateSizeLoop), "窗口大小调整检测", ThreadPriority.Normal);
			}
		}

		// Token: 0x060011D0 RID: 4560 RVA: 0x00077DB0 File Offset: 0x00075FB0
		private void updateSizeLoop()
		{
			try
			{
				while (this.printerRequest || this.m_FieldRequest || this._ReaderRequest || this._PageRequest)
				{
					this.filterRequest.Dispatcher.Invoke(new Action(this.updateSize), DispatcherPriority.Render);
					this.filterRequest.Dispatcher.Invoke(new Action(this.updateMouseDown), DispatcherPriority.Render);
					Thread.Sleep(0);
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060011D1 RID: 4561 RVA: 0x00077E48 File Offset: 0x00076048
		private void updateSize()
		{
			MyResizer.PointAPI pointAPI = default(MyResizer.PointAPI);
			MyResizer.GetCursorPos(out pointAPI);
			checked
			{
				pointAPI.X = (int)Math.Round(ModBase.smethod_4((double)pointAPI.X));
				pointAPI.Y = (int)Math.Round(ModBase.smethod_4((double)pointAPI.Y));
			}
			try
			{
				double num = -1.0;
				double num2 = -1.0;
				double num3 = -10000.0;
				double num4 = -10000.0;
				if (this._ReaderRequest)
				{
					if (this.filterRequest.Width == this.filterRequest.MinWidth)
					{
						if (this.m_ErrorRequest.X < pointAPI.X)
						{
							num = this.m_ExceptionRequest.Width - (double)(checked(this.m_ErrorRequest.X - pointAPI.X));
						}
					}
					else if (this.m_ExceptionRequest.Width - (double)(checked(this.m_ErrorRequest.X - pointAPI.X)) >= this.filterRequest.MinWidth)
					{
						num = this.m_ExceptionRequest.Width - (double)(checked(this.m_ErrorRequest.X - pointAPI.X));
					}
					else
					{
						num = this.filterRequest.MinWidth;
					}
				}
				if (this.printerRequest)
				{
					if (this.filterRequest.Height == this.filterRequest.MinHeight)
					{
						if (this.m_ErrorRequest.Y < pointAPI.Y)
						{
							if (MyResizer.strategyRequest > 0)
							{
								num2 = ((this.m_ExceptionRequest.Height - (double)(checked(this.m_ErrorRequest.Y - pointAPI.Y)) + this.filterRequest.Top <= (double)MyResizer.strategyRequest) ? (this.m_ExceptionRequest.Height - (double)(checked(this.m_ErrorRequest.Y - pointAPI.Y))) : ((double)MyResizer.strategyRequest - this.filterRequest.Top));
							}
							else
							{
								num2 = this.m_ExceptionRequest.Height - (double)(checked(this.m_ErrorRequest.Y - pointAPI.Y));
							}
						}
					}
					else if (this.m_ExceptionRequest.Height - (double)(checked(this.m_ErrorRequest.Y - pointAPI.Y)) >= this.filterRequest.MinHeight)
					{
						if (MyResizer.strategyRequest > 0)
						{
							num2 = ((this.m_ExceptionRequest.Height - (double)(checked(this.m_ErrorRequest.Y - pointAPI.Y)) + this.filterRequest.Top <= (double)MyResizer.strategyRequest) ? (this.m_ExceptionRequest.Height - (double)(checked(this.m_ErrorRequest.Y - pointAPI.Y))) : ((double)MyResizer.strategyRequest - this.filterRequest.Top));
						}
						else
						{
							num2 = this.m_ExceptionRequest.Height - (double)(checked(this.m_ErrorRequest.Y - pointAPI.Y));
						}
					}
					else
					{
						num2 = this.filterRequest.MinHeight;
					}
				}
				if (this.m_FieldRequest)
				{
					if (this.filterRequest.Width == this.filterRequest.MinWidth)
					{
						if (this.m_ErrorRequest.X > pointAPI.X)
						{
							num = this.m_ExceptionRequest.Width + (double)this.m_ErrorRequest.X - (double)pointAPI.X;
							num3 = (double)(checked(this.m_TestsRequest.m_VisitorParameter - (this.m_ErrorRequest.X - pointAPI.X)));
						}
						else
						{
							num = this.filterRequest.MinWidth;
							num3 = (double)this.m_TestsRequest.m_VisitorParameter + this.m_ExceptionRequest.Width - this.filterRequest.Width;
						}
					}
					else if (this.m_ExceptionRequest.Width + (double)(checked(this.m_ErrorRequest.X - pointAPI.X)) >= this.filterRequest.MinWidth)
					{
						num = this.m_ExceptionRequest.Width + (double)(checked(this.m_ErrorRequest.X - pointAPI.X));
						num3 = (double)(checked(this.m_TestsRequest.m_VisitorParameter - (this.m_ErrorRequest.X - pointAPI.X)));
					}
					else
					{
						num = this.filterRequest.MinWidth;
						num3 = (double)this.m_TestsRequest.m_VisitorParameter + this.m_ExceptionRequest.Width - this.filterRequest.Width;
					}
				}
				if (this._PageRequest)
				{
					if (this.filterRequest.Height == this.filterRequest.MinHeight)
					{
						if (this.m_ErrorRequest.Y > pointAPI.Y)
						{
							num2 = this.m_ExceptionRequest.Height + (double)this.m_ErrorRequest.Y - (double)pointAPI.Y;
							num4 = (double)(checked(this.m_TestsRequest.helperParameter - (this.m_ErrorRequest.Y - pointAPI.Y)));
						}
						else
						{
							num2 = this.filterRequest.MinHeight;
							num4 = (double)this.m_TestsRequest.helperParameter + this.m_ExceptionRequest.Height - this.filterRequest.Height;
						}
					}
					else if (this.m_ExceptionRequest.Height + (double)(checked(this.m_ErrorRequest.Y - pointAPI.Y)) >= this.filterRequest.MinHeight)
					{
						num2 = this.m_ExceptionRequest.Height + (double)this.m_ErrorRequest.Y - (double)pointAPI.Y;
						num4 = (double)(checked(this.m_TestsRequest.helperParameter - (this.m_ErrorRequest.Y - pointAPI.Y)));
					}
					else
					{
						num2 = this.filterRequest.MinHeight;
						num4 = (double)this.m_TestsRequest.helperParameter + this.m_ExceptionRequest.Height - this.filterRequest.Height;
					}
				}
				if (num > 10.0 && Math.Abs(num - this.filterRequest.Width) > 0.7)
				{
					this.filterRequest.Width = num;
				}
				if (num2 > 10.0 && Math.Abs(num2 - this.filterRequest.Height) > 0.7)
				{
					this.filterRequest.Height = num2;
				}
				if (num3 > -9999.0 && Math.Abs(num3 - this.filterRequest.Left) > 0.7)
				{
					this.filterRequest.Left = num3;
				}
				if (num4 > -9999.0 && Math.Abs(num4 - this.filterRequest.Top) > 0.7)
				{
					this.filterRequest.Top = num4;
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060011D2 RID: 4562 RVA: 0x0000A7BF File Offset: 0x000089BF
		private void updateMouseDown()
		{
			if (Mouse.LeftButton == MouseButtonState.Released)
			{
				this._ReaderRequest = false;
				this.m_FieldRequest = false;
				this._PageRequest = false;
				this.printerRequest = false;
			}
		}

		// Token: 0x060011D3 RID: 4563
		[DllImport("user32.dll", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		private static extern bool GetCursorPos(out MyResizer.PointAPI lpPoint);

		// Token: 0x040008A9 RID: 2217
		private readonly Window filterRequest;

		// Token: 0x040008AA RID: 2218
		private bool _ReaderRequest;

		// Token: 0x040008AB RID: 2219
		private bool m_FieldRequest;

		// Token: 0x040008AC RID: 2220
		private bool _PageRequest;

		// Token: 0x040008AD RID: 2221
		private bool printerRequest;

		// Token: 0x040008AE RID: 2222
		private readonly Dictionary<UIElement, short> tokenRequest;

		// Token: 0x040008AF RID: 2223
		private readonly Dictionary<UIElement, short> m_InterpreterRequest;

		// Token: 0x040008B0 RID: 2224
		private readonly Dictionary<UIElement, short> _ParserRequest;

		// Token: 0x040008B1 RID: 2225
		private readonly Dictionary<UIElement, short> m_StubRequest;

		// Token: 0x040008B2 RID: 2226
		private MyResizer.PointAPI m_ErrorRequest;

		// Token: 0x040008B3 RID: 2227
		private Size m_ExceptionRequest;

		// Token: 0x040008B4 RID: 2228
		private MyResizer.POINT m_TestsRequest;

		// Token: 0x040008B5 RID: 2229
		private static int strategyRequest = -1;

		// Token: 0x040008B6 RID: 2230
		private HwndSource m_RulesRequest;

		// Token: 0x0200017F RID: 383
		// (Invoke) Token: 0x060011D7 RID: 4567
		private delegate void RefreshDelegate();

		// Token: 0x02000180 RID: 384
		private struct POINT
		{
			// Token: 0x060011D9 RID: 4569 RVA: 0x0000A7E7 File Offset: 0x000089E7
			public POINT(int x, int y)
			{
				this = default(MyResizer.POINT);
				this.m_VisitorParameter = x;
				this.helperParameter = y;
			}

			// Token: 0x040008B7 RID: 2231
			public int m_VisitorParameter;

			// Token: 0x040008B8 RID: 2232
			public int helperParameter;
		}

		// Token: 0x02000181 RID: 385
		private struct MINMAXINFO
		{
			// Token: 0x040008B9 RID: 2233
			public MyResizer.POINT paramParameter;

			// Token: 0x040008BA RID: 2234
			public MyResizer.POINT m_BaseParameter;

			// Token: 0x040008BB RID: 2235
			public MyResizer.POINT productParameter;

			// Token: 0x040008BC RID: 2236
			public MyResizer.POINT attrParameter;

			// Token: 0x040008BD RID: 2237
			public MyResizer.POINT facadeParameter;
		}

		// Token: 0x02000182 RID: 386
		private struct RECT
		{
			// Token: 0x17000310 RID: 784
			// (get) Token: 0x060011DC RID: 4572 RVA: 0x0000A80F File Offset: 0x00008A0F
			public int Width
			{
				get
				{
					return Math.Abs(checked(this.m_IndexerParameter - this.bridgeParameter));
				}
			}

			// Token: 0x17000311 RID: 785
			// (get) Token: 0x060011DD RID: 4573 RVA: 0x0000A823 File Offset: 0x00008A23
			public int Height
			{
				get
				{
					return checked(this.templateParameter - this._StructParameter);
				}
			}

			// Token: 0x060011DE RID: 4574 RVA: 0x0000A832 File Offset: 0x00008A32
			public RECT(int left, int top, int right, int bottom)
			{
				this = default(MyResizer.RECT);
				this.bridgeParameter = left;
				this._StructParameter = top;
				this.m_IndexerParameter = right;
				this.templateParameter = bottom;
			}

			// Token: 0x060011DF RID: 4575 RVA: 0x0000A859 File Offset: 0x00008A59
			public RECT(MyResizer.RECT rcSrc)
			{
				this = default(MyResizer.RECT);
				this.bridgeParameter = rcSrc.bridgeParameter;
				this._StructParameter = rcSrc._StructParameter;
				this.m_IndexerParameter = rcSrc.m_IndexerParameter;
				this.templateParameter = rcSrc.templateParameter;
			}

			// Token: 0x040008BE RID: 2238
			public int bridgeParameter;

			// Token: 0x040008BF RID: 2239
			public int _StructParameter;

			// Token: 0x040008C0 RID: 2240
			public int m_IndexerParameter;

			// Token: 0x040008C1 RID: 2241
			public int templateParameter;

			// Token: 0x040008C2 RID: 2242
			public static MyResizer.RECT expressionParameter = default(MyResizer.RECT);
		}

		// Token: 0x02000183 RID: 387
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
		private class MONITORINFO
		{
			// Token: 0x060011E0 RID: 4576 RVA: 0x0000A893 File Offset: 0x00008A93
			public MONITORINFO()
			{
				this.getterParameter = Marshal.SizeOf(typeof(MyResizer.MONITORINFO));
				this.m_ListenerParameter = default(MyResizer.RECT);
				this.m_IdentifierParameter = default(MyResizer.RECT);
				this._InstanceParameter = 0;
			}

			// Token: 0x040008C3 RID: 2243
			public int getterParameter;

			// Token: 0x040008C4 RID: 2244
			public MyResizer.RECT m_ListenerParameter;

			// Token: 0x040008C5 RID: 2245
			public MyResizer.RECT m_IdentifierParameter;

			// Token: 0x040008C6 RID: 2246
			public int _InstanceParameter;
		}

		// Token: 0x02000184 RID: 388
		private struct PointAPI
		{
			// Token: 0x040008C7 RID: 2247
			public int X;

			// Token: 0x040008C8 RID: 2248
			public int Y;
		}
	}
}
