﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000151 RID: 337
	[DesignerGenerated]
	public class PageOtherLeft : MyPageLeft, IComponentConnector
	{
		// Token: 0x06000DAB RID: 3499 RVA: 0x00065410 File Offset: 0x00063610
		private void PageOtherLeft_Loaded(object sender, RoutedEventArgs e)
		{
			bool flag = false;
			if (Conversions.ToBoolean(this.ItemHelp.Checked && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherHelp", null))))
			{
				flag = true;
			}
			if (Conversions.ToBoolean(this.ItemFeedback.Checked && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherFeedback", null))))
			{
				flag = true;
			}
			if (Conversions.ToBoolean(this.ItemAbout.Checked && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherAbout", null))))
			{
				flag = true;
			}
			if (Conversions.ToBoolean(this.ItemTest.Checked && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherTest", null))))
			{
				flag = true;
			}
			if (PageSetupUI.AwakeResolver())
			{
				flag = false;
			}
			if (!this._PublisherPrototype || flag)
			{
				this._PublisherPrototype = true;
				PageSetupUI.HiddenRefresh();
				if (!this.watcherPrototype)
				{
					if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenOtherHelp", null))))
					{
						this.ItemHelp.SetChecked(true, false, false);
						return;
					}
					if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenOtherAbout", null))))
					{
						this.ItemAbout.SetChecked(true, false, false);
						return;
					}
					if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenOtherTest", null))))
					{
						this.ItemTest.SetChecked(true, false, false);
						return;
					}
					this.ItemFeedback.SetChecked(true, false, false);
				}
			}
		}

		// Token: 0x06000DAC RID: 3500 RVA: 0x00008CB8 File Offset: 0x00006EB8
		private void PageOtherLeft_Unloaded(object sender, RoutedEventArgs e)
		{
			this.watcherPrototype = false;
		}

		// Token: 0x06000DAD RID: 3501 RVA: 0x000655A8 File Offset: 0x000637A8
		public PageOtherLeft()
		{
			base.Loaded += this.PageOtherLeft_Loaded;
			base.Unloaded += this.PageOtherLeft_Unloaded;
			this._PublisherPrototype = false;
			this.watcherPrototype = false;
			this.InitializeComponent();
			if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenOtherHelp", null))))
			{
				this._TestPrototype = FormMain.PageSubType.Default;
				return;
			}
			if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenOtherAbout", null))))
			{
				this._TestPrototype = FormMain.PageSubType.DownloadInstall;
				return;
			}
			if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenOtherTest", null))))
			{
				this._TestPrototype = FormMain.PageSubType.SetupSystem;
				return;
			}
			this._TestPrototype = FormMain.PageSubType.SetupLink;
		}

		// Token: 0x06000DAE RID: 3502 RVA: 0x00008CC1 File Offset: 0x00006EC1
		private void PageCheck(MyListItem sender, ModBase.RouteEventArgs e)
		{
			if (sender.Tag != null)
			{
				this.PageChange(checked((FormMain.PageSubType)Math.Round(ModBase.Val(RuntimeHelpers.GetObjectValue(sender.Tag)))));
			}
		}

		// Token: 0x06000DAF RID: 3503 RVA: 0x00065668 File Offset: 0x00063868
		public object PageGet(FormMain.PageSubType ID = (FormMain.PageSubType)(-1))
		{
			if (ID == (FormMain.PageSubType)(-1))
			{
				ID = this._TestPrototype;
			}
			object result;
			switch (ID)
			{
			case FormMain.PageSubType.Default:
				if (ModMain.m_MethodAccount == null)
				{
					ModMain.m_MethodAccount = new PageOtherHelp();
				}
				result = ModMain.m_MethodAccount;
				break;
			case FormMain.PageSubType.DownloadInstall:
				if (ModMain.m_AnnotationAccount == null)
				{
					ModMain.m_AnnotationAccount = new PageOtherAbout();
				}
				result = ModMain.m_AnnotationAccount;
				break;
			case FormMain.PageSubType.SetupSystem:
				if (ModMain.m_RefAccount == null)
				{
					ModMain.m_RefAccount = new PageOtherTest();
				}
				result = ModMain.m_RefAccount;
				break;
			case FormMain.PageSubType.SetupLink:
				if (ModMain.interceptorAccount == null)
				{
					ModMain.interceptorAccount = new PageOtherFeedback();
				}
				result = ModMain.interceptorAccount;
				break;
			default:
				throw new Exception("未知的更多子页面种类：" + Conversions.ToString((int)ID));
			}
			return result;
		}

		// Token: 0x06000DB0 RID: 3504 RVA: 0x00065714 File Offset: 0x00063914
		public void PageChange(FormMain.PageSubType ID)
		{
			checked
			{
				if (this._TestPrototype != ID)
				{
					ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
					this.watcherPrototype = true;
					try
					{
						PageOtherLeft.PageChangeRun((MyPageRight)this.PageGet(ID));
						this._TestPrototype = ID;
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "切换设置分页面失败（ID " + Conversions.ToString((int)ID) + "）", ModBase.LogLevel.Feedback, "出现错误");
					}
					finally
					{
						ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
					}
				}
			}
		}

		// Token: 0x06000DB1 RID: 3505 RVA: 0x000657B0 File Offset: 0x000639B0
		private static void PageChangeRun(MyPageRight Target)
		{
			if (Target.Parent != null)
			{
				Target.SetValue(ContentPresenter.ContentProperty, null);
			}
			ModMain.m_CollectionAccount.m_RequestAccount = Target;
			((MyPageRight)ModMain.m_CollectionAccount.PanMainRight.Child).PageOnExit();
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaCode((PageOtherLeft._Closure$__.$I9-0 == null) ? (PageOtherLeft._Closure$__.$I9-0 = delegate()
				{
					((MyPageRight)ModMain.m_CollectionAccount.PanMainRight.Child).PageOnForceExit();
					ModMain.m_CollectionAccount.PanMainRight.Child = ModMain.m_CollectionAccount.m_RequestAccount;
					ModMain.m_CollectionAccount.m_RequestAccount.Opacity = 0.0;
				}) : PageOtherLeft._Closure$__.$I9-0, 130, false),
				ModAnimation.AaCode((PageOtherLeft._Closure$__.$I9-1 == null) ? (PageOtherLeft._Closure$__.$I9-1 = delegate()
				{
					ModMain.m_CollectionAccount.m_RequestAccount.Opacity = 1.0;
					ModMain.m_CollectionAccount.m_RequestAccount.PageOnEnter();
				}) : PageOtherLeft._Closure$__.$I9-1, 30, true)
			}, "PageLeft PageChange", false);
		}

		// Token: 0x06000DB2 RID: 3506 RVA: 0x00065870 File Offset: 0x00063A70
		public void Refresh(object sender, EventArgs e)
		{
			double num = ModBase.Val(RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(sender, null, "Tag", new object[0], null, null, null)));
			if (num == 0.0)
			{
				PageOtherLeft.RefreshHelp();
				return;
			}
			if (num == 3.0)
			{
				if (ModMain.interceptorAccount != null)
				{
					ModMain.interceptorAccount.PageLoaderRestart(null, true);
					ModMain.interceptorAccount.SearchBox.Text = "";
					return;
				}
				ModMain.wrapperState.Start(null, false);
			}
		}

		// Token: 0x06000DB3 RID: 3507 RVA: 0x00008CE7 File Offset: 0x00006EE7
		public static void RefreshHelp()
		{
			ModBase._ParamsState.Set("SystemHelpVersion", 0, false, null);
			ModMain.m_MethodAccount.PageLoaderRestart(null, true);
			ModMain.m_MethodAccount.SearchBox.Text = "";
		}

		// Token: 0x1700021D RID: 541
		// (get) Token: 0x06000DB4 RID: 3508 RVA: 0x00008D20 File Offset: 0x00006F20
		// (set) Token: 0x06000DB5 RID: 3509 RVA: 0x00008D28 File Offset: 0x00006F28
		internal virtual StackPanel PanItem { get; set; }

		// Token: 0x1700021E RID: 542
		// (get) Token: 0x06000DB6 RID: 3510 RVA: 0x00008D31 File Offset: 0x00006F31
		// (set) Token: 0x06000DB7 RID: 3511 RVA: 0x000658F0 File Offset: 0x00063AF0
		internal virtual MyListItem ItemHelp
		{
			[CompilerGenerated]
			get
			{
				return this.iteratorPrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem myListItem = this.iteratorPrototype;
				if (myListItem != null)
				{
					myListItem.Check -= value2;
				}
				this.iteratorPrototype = value;
				myListItem = this.iteratorPrototype;
				if (myListItem != null)
				{
					myListItem.Check += value2;
				}
			}
		}

		// Token: 0x1700021F RID: 543
		// (get) Token: 0x06000DB8 RID: 3512 RVA: 0x00008D39 File Offset: 0x00006F39
		// (set) Token: 0x06000DB9 RID: 3513 RVA: 0x00065934 File Offset: 0x00063B34
		internal virtual MyListItem ItemAbout
		{
			[CompilerGenerated]
			get
			{
				return this.m_SerializerPrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem serializerPrototype = this.m_SerializerPrototype;
				if (serializerPrototype != null)
				{
					serializerPrototype.Check -= value2;
				}
				this.m_SerializerPrototype = value;
				serializerPrototype = this.m_SerializerPrototype;
				if (serializerPrototype != null)
				{
					serializerPrototype.Check += value2;
				}
			}
		}

		// Token: 0x17000220 RID: 544
		// (get) Token: 0x06000DBA RID: 3514 RVA: 0x00008D41 File Offset: 0x00006F41
		// (set) Token: 0x06000DBB RID: 3515 RVA: 0x00065978 File Offset: 0x00063B78
		internal virtual MyListItem ItemTest
		{
			[CompilerGenerated]
			get
			{
				return this.m_RolePrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem rolePrototype = this.m_RolePrototype;
				if (rolePrototype != null)
				{
					rolePrototype.Check -= value2;
				}
				this.m_RolePrototype = value;
				rolePrototype = this.m_RolePrototype;
				if (rolePrototype != null)
				{
					rolePrototype.Check += value2;
				}
			}
		}

		// Token: 0x17000221 RID: 545
		// (get) Token: 0x06000DBC RID: 3516 RVA: 0x00008D49 File Offset: 0x00006F49
		// (set) Token: 0x06000DBD RID: 3517 RVA: 0x000659BC File Offset: 0x00063BBC
		internal virtual MyListItem ItemFeedback
		{
			[CompilerGenerated]
			get
			{
				return this._ValuePrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem valuePrototype = this._ValuePrototype;
				if (valuePrototype != null)
				{
					valuePrototype.Check -= value2;
				}
				this._ValuePrototype = value;
				valuePrototype = this._ValuePrototype;
				if (valuePrototype != null)
				{
					valuePrototype.Check += value2;
				}
			}
		}

		// Token: 0x06000DBE RID: 3518 RVA: 0x00065A00 File Offset: 0x00063C00
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_RecordPrototype)
			{
				this.m_RecordPrototype = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pageother/pageotherleft.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000DBF RID: 3519 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000DC0 RID: 3520 RVA: 0x00065A30 File Offset: 0x00063C30
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanItem = (StackPanel)target;
				return;
			}
			if (connectionId == 2)
			{
				this.ItemHelp = (MyListItem)target;
				return;
			}
			if (connectionId == 3)
			{
				this.ItemAbout = (MyListItem)target;
				return;
			}
			if (connectionId == 4)
			{
				this.ItemTest = (MyListItem)target;
				return;
			}
			if (connectionId == 5)
			{
				this.ItemFeedback = (MyListItem)target;
				return;
			}
			this.m_RecordPrototype = true;
		}

		// Token: 0x040006D3 RID: 1747
		private bool _PublisherPrototype;

		// Token: 0x040006D4 RID: 1748
		private bool watcherPrototype;

		// Token: 0x040006D5 RID: 1749
		public FormMain.PageSubType _TestPrototype;

		// Token: 0x040006D6 RID: 1750
		[CompilerGenerated]
		[AccessedThroughProperty("PanItem")]
		private StackPanel taskPrototype;

		// Token: 0x040006D7 RID: 1751
		[CompilerGenerated]
		[AccessedThroughProperty("ItemHelp")]
		private MyListItem iteratorPrototype;

		// Token: 0x040006D8 RID: 1752
		[AccessedThroughProperty("ItemAbout")]
		[CompilerGenerated]
		private MyListItem m_SerializerPrototype;

		// Token: 0x040006D9 RID: 1753
		[CompilerGenerated]
		[AccessedThroughProperty("ItemTest")]
		private MyListItem m_RolePrototype;

		// Token: 0x040006DA RID: 1754
		[AccessedThroughProperty("ItemFeedback")]
		[CompilerGenerated]
		private MyListItem _ValuePrototype;

		// Token: 0x040006DB RID: 1755
		private bool m_RecordPrototype;
	}
}
