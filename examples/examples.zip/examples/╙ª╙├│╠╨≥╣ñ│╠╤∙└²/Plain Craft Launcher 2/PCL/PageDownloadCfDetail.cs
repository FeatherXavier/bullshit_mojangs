﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000093 RID: 147
	[DesignerGenerated]
	public class PageDownloadCfDetail : MyPageRight, IComponentConnector
	{
		// Token: 0x06000523 RID: 1315 RVA: 0x00004B2F File Offset: 0x00002D2F
		public PageDownloadCfDetail()
		{
			base.Initialized += this.PageDownloadCfDetail_Inited;
			base.CountModel(new MyPageRight.OnPageEnterEventHandler(this.Init));
			this._AttrRepository = null;
			this.InitializeComponent();
		}

		// Token: 0x06000524 RID: 1316 RVA: 0x00029E84 File Offset: 0x00028084
		private void PageDownloadCfDetail_Inited(object sender, EventArgs e)
		{
			this._FacadeRepository = (ModDownload.DlCfProject)ModMain.m_CollectionAccount.comparatorAccount.m_ObjectParameter;
			base.PageLoaderInit(this.Load, this.PanLoad, this.PanMain, this.CardIntro, ModDownload.m_ProductTag, delegate(ModLoader.LoaderBase a0)
			{
				this.Load_OnFinish();
			}, () => this.LoaderInput(), true);
		}

		// Token: 0x06000525 RID: 1317 RVA: 0x00004B69 File Offset: 0x00002D69
		private KeyValuePair<int, bool> LoaderInput()
		{
			return new KeyValuePair<int, bool>(this._FacadeRepository.composerProccesor, this._FacadeRepository.threadProccesor);
		}

		// Token: 0x06000526 RID: 1318 RVA: 0x00029EE8 File Offset: 0x000280E8
		private void Load_State(object sender, MyLoading.MyLoadingState state, MyLoading.MyLoadingState oldState)
		{
			ModBase.LoadState state2 = ModDownload.m_ProductTag.State;
			if (state2 == ModBase.LoadState.Failed)
			{
				string text = "";
				if (ModDownload.m_ProductTag.Error != null)
				{
					text = ModDownload.m_ProductTag.Error.Message;
				}
				if (text.Contains("不是有效的 Json 文件"))
				{
					ModBase.Log("[Download] 下载的 Mod 列表 Json 文件损坏，已自动重试", ModBase.LogLevel.Debug, "出现错误");
					base.PageLoaderRestart(null, true);
				}
			}
		}

		// Token: 0x06000527 RID: 1319 RVA: 0x00029F4C File Offset: 0x0002814C
		private void Load_OnFinish()
		{
			SortedDictionary<string, List<ModDownload.DlCfFile>> sortedDictionary = new SortedDictionary<string, List<ModDownload.DlCfFile>>(new ModMinecraft.VersionSorter(true));
			try
			{
				sortedDictionary.Add("未知版本", new List<ModDownload.DlCfFile>());
				try
				{
					foreach (ModDownload.DlCfFile dlCfFile in ModDownload.m_ProductTag.Output)
					{
						foreach (string text in dlCfFile._FilterProccesor)
						{
							string key;
							if (text != null && text.Split(new char[]
							{
								'.'
							}).Count<string>() >= 2)
							{
								key = text;
							}
							else
							{
								key = "未知版本";
							}
							if (!sortedDictionary.ContainsKey(key))
							{
								sortedDictionary.Add(key, new List<ModDownload.DlCfFile>());
							}
							if (!sortedDictionary[key].Contains(dlCfFile))
							{
								sortedDictionary[key].Add(dlCfFile);
							}
						}
					}
				}
				finally
				{
					List<ModDownload.DlCfFile>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "准备工程下载列表出错", ModBase.LogLevel.Feedback, "出现错误");
			}
			try
			{
				this.PanMain.Children.Clear();
				try
				{
					foreach (KeyValuePair<string, List<ModDownload.DlCfFile>> keyValuePair in sortedDictionary)
					{
						if (keyValuePair.Value.Count != 0)
						{
							MyCard myCard = new MyCard();
							myCard.Title = keyValuePair.Key;
							myCard.Margin = new Thickness(0.0, 0.0, 0.0, 15.0);
							myCard.CustomizeModel(this._FacadeRepository.threadProccesor ? 9 : 8);
							MyCard myCard2 = myCard;
							StackPanel stackPanel = new StackPanel
							{
								Margin = new Thickness(20.0, 40.0, 18.0, 0.0),
								VerticalAlignment = VerticalAlignment.Top,
								RenderTransform = new TranslateTransform(0.0, 0.0),
								Tag = keyValuePair.Value
							};
							myCard2.Children.Add(stackPanel);
							myCard2.m_Decorator = stackPanel;
							myCard2.IsSwaped = true;
							this.PanMain.Children.Add(myCard2);
							if (Operators.CompareString(keyValuePair.Key, "未知版本", true) == 0)
							{
								stackPanel.Children.Add(new MyHint
								{
									Text = "由于 API 的版本信息更新缓慢，可能无法识别刚更新不久的 MC 版本，只需等待几天即可自动恢复正常。",
									IsWarn = false,
									Margin = new Thickness(0.0, 0.0, 0.0, 7.0)
								});
							}
						}
					}
				}
				finally
				{
					SortedDictionary<string, List<ModDownload.DlCfFile>>.Enumerator enumerator2;
					((IDisposable)enumerator2).Dispose();
				}
				if (this.PanMain.Children.Count == 1)
				{
					((MyCard)this.PanMain.Children[0]).IsSwaped = false;
				}
			}
			catch (Exception ex2)
			{
				ModBase.Log(ex2, "可视化工程下载列表出错", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000528 RID: 1320 RVA: 0x0002A2B8 File Offset: 0x000284B8
		public void Init()
		{
			checked
			{
				ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
				this._FacadeRepository = (ModDownload.DlCfProject)ModMain.m_CollectionAccount.comparatorAccount.m_ObjectParameter;
				this.PanBack.ScrollToHome();
				base.PageLoaderRestart(null, false);
				if (this._AttrRepository != null)
				{
					this.PanIntro.Children.Remove(this._AttrRepository);
				}
				this._AttrRepository = this._FacadeRepository.ToCfItem(null);
				this._AttrRepository.Margin = new Thickness(-7.0, -7.0, 0.0, 8.0);
				this.PanIntro.Children.Insert(0, this._AttrRepository);
				this.BtnIntroWiki.Visibility = ((this._FacadeRepository.itemProccesor == 0) ? Visibility.Collapsed : Visibility.Visible);
				this.BtnIntroMCBBS.Visibility = ((this._FacadeRepository.CheckComparator() == null) ? Visibility.Collapsed : Visibility.Visible);
				ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
			}
		}

		// Token: 0x06000529 RID: 1321 RVA: 0x0002A3C0 File Offset: 0x000285C0
		public void Install_Click(MyListItem sender, EventArgs e)
		{
			try
			{
				ModDownload.DlCfFile dlCfFile = (ModDownload.DlCfFile)sender.Tag;
				string name = "CurseForge 整合包下载：" + this._FacadeRepository.FlushComparator() + " ";
				string text = this._FacadeRepository.FlushComparator().Replace(".zip", "").Replace(".rar", "").Replace("\\", "＼").Replace("/", "／").Replace("|", "｜").Replace(":", "：").Replace("<", "＜").Replace(">", "＞").Replace("*", "＊").Replace("?", "？").Replace("\"", "").Replace("： ", "：");
				ValidateFolderName validateFolderName = new ValidateFolderName(ModMinecraft._MapperTag + "versions", true, true);
				if (Operators.CompareString(validateFolderName.Validate(text), "", true) != 0)
				{
					text = "";
				}
				string VersionName = ModMain.MyMsgBoxInput(text, new Collection<Validate>
				{
					validateFolderName
				}, "", "输入版本名", "确定", "取消", false);
				if (!string.IsNullOrEmpty(VersionName))
				{
					List<ModLoader.LoaderBase> list = new List<ModLoader.LoaderBase>();
					string Target = ModMinecraft._MapperTag + "versions\\" + VersionName + "\\原始整合包.rar";
					list.Add(new ModNet.LoaderDownload("下载整合包文件", new List<ModNet.NetFile>
					{
						dlCfFile.GetDownloadFile(Target, true)
					})
					{
						ProgressWeight = 10.0,
						Block = true
					});
					list.Add(new ModLoader.LoaderTask<int, int>("准备安装整合包", delegate(ModLoader.LoaderTask<int, int> a0)
					{
						base._Lambda$__0();
					}, null, ThreadPriority.Normal)
					{
						ProgressWeight = 0.1
					});
					ModLoader.LoaderCombo<string> loaderCombo = new ModLoader.LoaderCombo<string>(name, list);
					loaderCombo.OnStateChanged = ((PageDownloadCfDetail._Closure$__.$I9-1 == null) ? (PageDownloadCfDetail._Closure$__.$I9-1 = delegate(ModLoader.LoaderBase MyLoader)
					{
						switch (MyLoader.State)
						{
						case ModBase.LoadState.Loading:
							return;
						case ModBase.LoadState.Failed:
							ModMain.Hint(MyLoader.Name + "失败：" + ModBase.GetString(MyLoader.Error, true, false), ModMain.HintType.Critical, true);
							break;
						case ModBase.LoadState.Aborted:
							ModMain.Hint(MyLoader.Name + "已取消！", ModMain.HintType.Info, true);
							break;
						}
						ModDownloadLib.McInstallFailedClearFolder(MyLoader);
					}) : PageDownloadCfDetail._Closure$__.$I9-1);
					loaderCombo.Start(ModMinecraft._MapperTag + "versions\\" + VersionName + "\\", false);
					ModLoader.LoaderTaskbarAdd(loaderCombo);
					ModMain.m_CollectionAccount.BtnExtraDownload.ShowRefresh();
					ModMain.m_CollectionAccount.BtnExtraDownload.Ribble();
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "下载 CurseForge 整合包失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x0600052A RID: 1322 RVA: 0x0002A678 File Offset: 0x00028878
		public void Save_Click(object sender, EventArgs e)
		{
			try
			{
				string str = this._FacadeRepository.threadProccesor ? "整合包" : "Mod ";
				string text = null;
				if (!this._FacadeRepository.threadProccesor)
				{
					text = Conversions.ToString(PageDownloadCfDetail._BridgeRepository);
					if (ModMinecraft.SetupResolver() != null)
					{
						if (!ModMinecraft.SetupResolver()._WrapperParameter)
						{
							ModMinecraft.SetupResolver().Load();
						}
						if (ModMinecraft.SetupResolver().Version.CalculatePrototype())
						{
							text = ModMinecraft.SetupResolver().CreateComparator() + "mods\\";
							Directory.CreateDirectory(text);
						}
					}
					if (string.IsNullOrEmpty(text))
					{
						text = null;
					}
				}
				ModDownload.DlCfFile dlCfFile = (ModDownload.DlCfFile)NewLateBinding.LateGet((sender is MyListItem) ? sender : NewLateBinding.LateGet(sender, null, "Parent", new object[0], null, null, null), null, "Tag", new object[0], null, null, null);
				string fileName = ((Operators.CompareString(this._FacadeRepository.FlushComparator(), this._FacadeRepository.Name, true) == 0) ? "" : ("[" + this._FacadeRepository.FlushComparator().Replace(" (", "Å").Split(new char[]
				{
					'Å'
				}).First<string>().Replace("\\", "＼").Replace("/", "／").Replace("|", "｜").Replace(":", "：").Replace("<", "＜").Replace(">", "＞").Replace("*", "＊").Replace("?", "？").Replace("\"", "").Replace("： ", "：") + "] ")) + dlCfFile.m_FieldProccesor;
				string text2;
				if (dlCfFile.m_FieldProccesor.EndsWith(".litemod"))
				{
					text2 = ModBase.SelectAs("选择保存位置", fileName, str + "文件|" + (this._FacadeRepository.threadProccesor ? "*.zip" : "*.litemod"), text);
				}
				else
				{
					text2 = ModBase.SelectAs("选择保存位置", fileName, str + "文件|" + (this._FacadeRepository.threadProccesor ? "*.zip" : "*.jar"), text);
				}
				if (text2.Contains("\\"))
				{
					string name = str + "下载：" + dlCfFile.m_CollectionProccesor + " ";
					if (Operators.CompareString(text2, text, true) != 0 && !this._FacadeRepository.threadProccesor)
					{
						PageDownloadCfDetail._BridgeRepository = ModBase.GetPathFromFullPath(text2);
					}
					ModLoader.LoaderCombo<int> loaderCombo = new ModLoader.LoaderCombo<int>(name, new List<ModLoader.LoaderBase>
					{
						new ModNet.LoaderDownload("下载文件", new List<ModNet.NetFile>
						{
							dlCfFile.GetDownloadFile(text2, true)
						})
						{
							ProgressWeight = 6.0,
							Block = true
						}
					});
					loaderCombo.OnStateChanged = new Action<ModLoader.LoaderBase>(ModDownloadLib.DownloadStateSave);
					loaderCombo.Start(1, false);
					ModLoader.LoaderTaskbarAdd(loaderCombo);
					ModMain.m_CollectionAccount.BtnExtraDownload.ShowRefresh();
					ModMain.m_CollectionAccount.BtnExtraDownload.Ribble();
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "保存 CurseForge 文件失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x0600052B RID: 1323 RVA: 0x00004B86 File Offset: 0x00002D86
		private void BtnIntroCf_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite(this._FacadeRepository.m_FactoryProccesor);
		}

		// Token: 0x0600052C RID: 1324 RVA: 0x00004B98 File Offset: 0x00002D98
		private void BtnIntroWiki_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://www.mcmod.cn/class/" + Conversions.ToString(this._FacadeRepository.itemProccesor) + ".html");
		}

		// Token: 0x0600052D RID: 1325 RVA: 0x00004BBE File Offset: 0x00002DBE
		private void BtnIntroMCBBS_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://www.mcbbs.net/thread-" + this._FacadeRepository.CheckComparator() + "-1-1.html");
		}

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x0600052E RID: 1326 RVA: 0x00004BDF File Offset: 0x00002DDF
		// (set) Token: 0x0600052F RID: 1327 RVA: 0x00004BE7 File Offset: 0x00002DE7
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x06000530 RID: 1328 RVA: 0x00004BF0 File Offset: 0x00002DF0
		// (set) Token: 0x06000531 RID: 1329 RVA: 0x00004BF8 File Offset: 0x00002DF8
		internal virtual MyCard CardIntro { get; set; }

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x06000532 RID: 1330 RVA: 0x00004C01 File Offset: 0x00002E01
		// (set) Token: 0x06000533 RID: 1331 RVA: 0x00004C09 File Offset: 0x00002E09
		internal virtual StackPanel PanIntro { get; set; }

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x06000534 RID: 1332 RVA: 0x00004C12 File Offset: 0x00002E12
		// (set) Token: 0x06000535 RID: 1333 RVA: 0x0002A9E8 File Offset: 0x00028BE8
		internal virtual MyButton BtnIntroCf
		{
			[CompilerGenerated]
			get
			{
				return this.expressionRepository;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnIntroCf_Click);
				MyButton myButton = this.expressionRepository;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.expressionRepository = value;
				myButton = this.expressionRepository;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x06000536 RID: 1334 RVA: 0x00004C1A File Offset: 0x00002E1A
		// (set) Token: 0x06000537 RID: 1335 RVA: 0x0002AA2C File Offset: 0x00028C2C
		internal virtual MyButton BtnIntroWiki
		{
			[CompilerGenerated]
			get
			{
				return this._GetterRepository;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnIntroWiki_Click);
				MyButton getterRepository = this._GetterRepository;
				if (getterRepository != null)
				{
					getterRepository.RevertResolver(obj);
				}
				this._GetterRepository = value;
				getterRepository = this._GetterRepository;
				if (getterRepository != null)
				{
					getterRepository.PostResolver(obj);
				}
			}
		}

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x06000538 RID: 1336 RVA: 0x00004C22 File Offset: 0x00002E22
		// (set) Token: 0x06000539 RID: 1337 RVA: 0x0002AA70 File Offset: 0x00028C70
		internal virtual MyButton BtnIntroMCBBS
		{
			[CompilerGenerated]
			get
			{
				return this.listenerRepository;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnIntroMCBBS_Click);
				MyButton myButton = this.listenerRepository;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.listenerRepository = value;
				myButton = this.listenerRepository;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x0600053A RID: 1338 RVA: 0x00004C2A File Offset: 0x00002E2A
		// (set) Token: 0x0600053B RID: 1339 RVA: 0x00004C32 File Offset: 0x00002E32
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x0600053C RID: 1340 RVA: 0x00004C3B File Offset: 0x00002E3B
		// (set) Token: 0x0600053D RID: 1341 RVA: 0x00004C43 File Offset: 0x00002E43
		internal virtual MyCard PanLoad { get; set; }

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x0600053E RID: 1342 RVA: 0x00004C4C File Offset: 0x00002E4C
		// (set) Token: 0x0600053F RID: 1343 RVA: 0x0002AAB4 File Offset: 0x00028CB4
		internal virtual MyLoading Load
		{
			[CompilerGenerated]
			get
			{
				return this.creatorRepository;
			}
			[CompilerGenerated]
			set
			{
				MyLoading.StateChangedEventHandler obj = new MyLoading.StateChangedEventHandler(this.Load_State);
				MyLoading myLoading = this.creatorRepository;
				if (myLoading != null)
				{
					myLoading.RemoveWrapper(obj);
				}
				this.creatorRepository = value;
				myLoading = this.creatorRepository;
				if (myLoading != null)
				{
					myLoading.InstantiateWrapper(obj);
				}
			}
		}

		// Token: 0x06000540 RID: 1344 RVA: 0x0002AAF8 File Offset: 0x00028CF8
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.objectRepository)
			{
				this.objectRepository = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagedownload/pagedownloadcfdetail.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000541 RID: 1345 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000542 RID: 1346 RVA: 0x0002AB28 File Offset: 0x00028D28
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.CardIntro = (MyCard)target;
				return;
			}
			if (connectionId == 3)
			{
				this.PanIntro = (StackPanel)target;
				return;
			}
			if (connectionId == 4)
			{
				this.BtnIntroCf = (MyButton)target;
				return;
			}
			if (connectionId == 5)
			{
				this.BtnIntroWiki = (MyButton)target;
				return;
			}
			if (connectionId == 6)
			{
				this.BtnIntroMCBBS = (MyButton)target;
				return;
			}
			if (connectionId == 7)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			if (connectionId == 8)
			{
				this.PanLoad = (MyCard)target;
				return;
			}
			if (connectionId == 9)
			{
				this.Load = (MyLoading)target;
				return;
			}
			this.objectRepository = true;
		}

		// Token: 0x0400026E RID: 622
		private MyCfItem _AttrRepository;

		// Token: 0x0400026F RID: 623
		private ModDownload.DlCfProject _FacadeRepository;

		// Token: 0x04000270 RID: 624
		public static string _BridgeRepository = null;

		// Token: 0x04000271 RID: 625
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyScrollViewer _StructRepository;

		// Token: 0x04000272 RID: 626
		[AccessedThroughProperty("CardIntro")]
		[CompilerGenerated]
		private MyCard m_IndexerRepository;

		// Token: 0x04000273 RID: 627
		[AccessedThroughProperty("PanIntro")]
		[CompilerGenerated]
		private StackPanel m_TemplateRepository;

		// Token: 0x04000274 RID: 628
		[AccessedThroughProperty("BtnIntroCf")]
		[CompilerGenerated]
		private MyButton expressionRepository;

		// Token: 0x04000275 RID: 629
		[CompilerGenerated]
		[AccessedThroughProperty("BtnIntroWiki")]
		private MyButton _GetterRepository;

		// Token: 0x04000276 RID: 630
		[CompilerGenerated]
		[AccessedThroughProperty("BtnIntroMCBBS")]
		private MyButton listenerRepository;

		// Token: 0x04000277 RID: 631
		[CompilerGenerated]
		[AccessedThroughProperty("PanMain")]
		private StackPanel m_IdentifierRepository;

		// Token: 0x04000278 RID: 632
		[AccessedThroughProperty("PanLoad")]
		[CompilerGenerated]
		private MyCard m_InstanceRepository;

		// Token: 0x04000279 RID: 633
		[AccessedThroughProperty("Load")]
		[CompilerGenerated]
		private MyLoading creatorRepository;

		// Token: 0x0400027A RID: 634
		private bool objectRepository;
	}
}
