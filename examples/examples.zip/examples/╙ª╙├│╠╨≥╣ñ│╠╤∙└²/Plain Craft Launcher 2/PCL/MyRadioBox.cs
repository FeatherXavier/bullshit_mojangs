﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200017A RID: 378
	[DesignerGenerated]
	public class MyRadioBox : Grid, IMyRadio, IComponentConnector
	{
		// Token: 0x0600118E RID: 4494 RVA: 0x00076C10 File Offset: 0x00074E10
		public MyRadioBox()
		{
			base.MouseLeftButtonUp += delegate(object sender, MouseButtonEventArgs e)
			{
				this.Radiobox_MouseUp();
			};
			base.MouseLeftButtonDown += delegate(object sender, MouseButtonEventArgs e)
			{
				this.Radiobox_MouseDown();
			};
			base.MouseLeave += delegate(object sender, MouseEventArgs e)
			{
				this.Radiobox_MouseLeave();
			};
			base.IsEnabledChanged += delegate(object sender, DependencyPropertyChangedEventArgs e)
			{
				this.Radiobox_IsEnabledChanged();
			};
			base.MouseEnter += delegate(object sender, MouseEventArgs e)
			{
				this.Radiobox_MouseEnterAnimation();
			};
			base.MouseLeave += delegate(object sender, MouseEventArgs e)
			{
				this.Radiobox_MouseLeaveAnimation();
			};
			this.orderRequest = ModBase.GetUuid();
			this._SchemaRequest = false;
			this.callbackRequest = false;
			this._AdvisorRequest = true;
			this.InitializeComponent();
		}

		// Token: 0x0600118F RID: 4495 RVA: 0x00076CB8 File Offset: 0x00074EB8
		[CompilerGenerated]
		public void ConnectTag(MyRadioBox.PreviewCheckEventHandler obj)
		{
			MyRadioBox.PreviewCheckEventHandler previewCheckEventHandler = this.policyRequest;
			MyRadioBox.PreviewCheckEventHandler previewCheckEventHandler2;
			do
			{
				previewCheckEventHandler2 = previewCheckEventHandler;
				MyRadioBox.PreviewCheckEventHandler value = (MyRadioBox.PreviewCheckEventHandler)Delegate.Combine(previewCheckEventHandler2, obj);
				previewCheckEventHandler = Interlocked.CompareExchange<MyRadioBox.PreviewCheckEventHandler>(ref this.policyRequest, value, previewCheckEventHandler2);
			}
			while (previewCheckEventHandler != previewCheckEventHandler2);
		}

		// Token: 0x06001190 RID: 4496 RVA: 0x00076CF0 File Offset: 0x00074EF0
		[CompilerGenerated]
		public void NewTag(MyRadioBox.PreviewCheckEventHandler obj)
		{
			MyRadioBox.PreviewCheckEventHandler previewCheckEventHandler = this.policyRequest;
			MyRadioBox.PreviewCheckEventHandler previewCheckEventHandler2;
			do
			{
				previewCheckEventHandler2 = previewCheckEventHandler;
				MyRadioBox.PreviewCheckEventHandler value = (MyRadioBox.PreviewCheckEventHandler)Delegate.Remove(previewCheckEventHandler2, obj);
				previewCheckEventHandler = Interlocked.CompareExchange<MyRadioBox.PreviewCheckEventHandler>(ref this.policyRequest, value, previewCheckEventHandler2);
			}
			while (previewCheckEventHandler != previewCheckEventHandler2);
		}

		// Token: 0x06001191 RID: 4497 RVA: 0x00076D28 File Offset: 0x00074F28
		[CompilerGenerated]
		public void VisitTag(MyRadioBox.PreviewChangeEventHandler obj)
		{
			MyRadioBox.PreviewChangeEventHandler previewChangeEventHandler = this.threadRequest;
			MyRadioBox.PreviewChangeEventHandler previewChangeEventHandler2;
			do
			{
				previewChangeEventHandler2 = previewChangeEventHandler;
				MyRadioBox.PreviewChangeEventHandler value = (MyRadioBox.PreviewChangeEventHandler)Delegate.Combine(previewChangeEventHandler2, obj);
				previewChangeEventHandler = Interlocked.CompareExchange<MyRadioBox.PreviewChangeEventHandler>(ref this.threadRequest, value, previewChangeEventHandler2);
			}
			while (previewChangeEventHandler != previewChangeEventHandler2);
		}

		// Token: 0x06001192 RID: 4498 RVA: 0x00076D60 File Offset: 0x00074F60
		[CompilerGenerated]
		public void IncludeTag(MyRadioBox.PreviewChangeEventHandler obj)
		{
			MyRadioBox.PreviewChangeEventHandler previewChangeEventHandler = this.threadRequest;
			MyRadioBox.PreviewChangeEventHandler previewChangeEventHandler2;
			do
			{
				previewChangeEventHandler2 = previewChangeEventHandler;
				MyRadioBox.PreviewChangeEventHandler value = (MyRadioBox.PreviewChangeEventHandler)Delegate.Remove(previewChangeEventHandler2, obj);
				previewChangeEventHandler = Interlocked.CompareExchange<MyRadioBox.PreviewChangeEventHandler>(ref this.threadRequest, value, previewChangeEventHandler2);
			}
			while (previewChangeEventHandler != previewChangeEventHandler2);
		}

		// Token: 0x1400000C RID: 12
		// (add) Token: 0x06001193 RID: 4499 RVA: 0x00076D98 File Offset: 0x00074F98
		// (remove) Token: 0x06001194 RID: 4500 RVA: 0x00076DD0 File Offset: 0x00074FD0
		public event IMyRadio.CheckEventHandler Check
		{
			[CompilerGenerated]
			add
			{
				IMyRadio.CheckEventHandler checkEventHandler = this.connectionRequest;
				IMyRadio.CheckEventHandler checkEventHandler2;
				do
				{
					checkEventHandler2 = checkEventHandler;
					IMyRadio.CheckEventHandler value2 = (IMyRadio.CheckEventHandler)Delegate.Combine(checkEventHandler2, value);
					checkEventHandler = Interlocked.CompareExchange<IMyRadio.CheckEventHandler>(ref this.connectionRequest, value2, checkEventHandler2);
				}
				while (checkEventHandler != checkEventHandler2);
			}
			[CompilerGenerated]
			remove
			{
				IMyRadio.CheckEventHandler checkEventHandler = this.connectionRequest;
				IMyRadio.CheckEventHandler checkEventHandler2;
				do
				{
					checkEventHandler2 = checkEventHandler;
					IMyRadio.CheckEventHandler value2 = (IMyRadio.CheckEventHandler)Delegate.Remove(checkEventHandler2, value);
					checkEventHandler = Interlocked.CompareExchange<IMyRadio.CheckEventHandler>(ref this.connectionRequest, value2, checkEventHandler2);
				}
				while (checkEventHandler != checkEventHandler2);
			}
		}

		// Token: 0x1400000D RID: 13
		// (add) Token: 0x06001195 RID: 4501 RVA: 0x00076E08 File Offset: 0x00075008
		// (remove) Token: 0x06001196 RID: 4502 RVA: 0x00076E40 File Offset: 0x00075040
		public event IMyRadio.ChangedEventHandler Changed
		{
			[CompilerGenerated]
			add
			{
				IMyRadio.ChangedEventHandler changedEventHandler = this.m_CustomerRequest;
				IMyRadio.ChangedEventHandler changedEventHandler2;
				do
				{
					changedEventHandler2 = changedEventHandler;
					IMyRadio.ChangedEventHandler value2 = (IMyRadio.ChangedEventHandler)Delegate.Combine(changedEventHandler2, value);
					changedEventHandler = Interlocked.CompareExchange<IMyRadio.ChangedEventHandler>(ref this.m_CustomerRequest, value2, changedEventHandler2);
				}
				while (changedEventHandler != changedEventHandler2);
			}
			[CompilerGenerated]
			remove
			{
				IMyRadio.ChangedEventHandler changedEventHandler = this.m_CustomerRequest;
				IMyRadio.ChangedEventHandler changedEventHandler2;
				do
				{
					changedEventHandler2 = changedEventHandler;
					IMyRadio.ChangedEventHandler value2 = (IMyRadio.ChangedEventHandler)Delegate.Remove(changedEventHandler2, value);
					changedEventHandler = Interlocked.CompareExchange<IMyRadio.ChangedEventHandler>(ref this.m_CustomerRequest, value2, changedEventHandler2);
				}
				while (changedEventHandler != changedEventHandler2);
			}
		}

		// Token: 0x1700030A RID: 778
		// (get) Token: 0x06001197 RID: 4503 RVA: 0x0000A598 File Offset: 0x00008798
		// (set) Token: 0x06001198 RID: 4504 RVA: 0x0000A5A0 File Offset: 0x000087A0
		public bool Checked
		{
			get
			{
				return this._SchemaRequest;
			}
			set
			{
				this.SetChecked(value, false, true);
			}
		}

		// Token: 0x06001199 RID: 4505 RVA: 0x00076E78 File Offset: 0x00075078
		public void SetChecked(bool value, bool user, bool anime)
		{
			try
			{
				if (value && user)
				{
					ModBase.RouteEventArgs routeEventArgs = new ModBase.RouteEventArgs(user);
					MyRadioBox.PreviewCheckEventHandler previewCheckEventHandler = this.policyRequest;
					if (previewCheckEventHandler != null)
					{
						previewCheckEventHandler(this, routeEventArgs);
					}
					if (routeEventArgs.proxyParameter)
					{
						this.Radiobox_MouseLeave();
						return;
					}
				}
				bool flag = false;
				if (base.IsLoaded && value != this._SchemaRequest)
				{
					MyRadioBox.PreviewChangeEventHandler previewChangeEventHandler = this.threadRequest;
					if (previewChangeEventHandler != null)
					{
						previewChangeEventHandler(this, new ModBase.RouteEventArgs(user));
					}
				}
				if (value != this._SchemaRequest)
				{
					this._SchemaRequest = value;
					flag = true;
				}
				if (base.Parent != null)
				{
					List<MyRadioBox> list = new List<MyRadioBox>();
					int num = 0;
					checked
					{
						try
						{
							foreach (object obj in ((IEnumerable)NewLateBinding.LateGet(base.Parent, null, "Children", new object[0], null, null, null)))
							{
								object objectValue = RuntimeHelpers.GetObjectValue(obj);
								if (objectValue is MyRadioBox)
								{
									list.Add((MyRadioBox)objectValue);
									if (Conversions.ToBoolean(NewLateBinding.LateGet(objectValue, null, "Checked", new object[0], null, null, null)))
									{
										num++;
									}
								}
							}
						}
						finally
						{
							IEnumerator enumerator;
							if (enumerator is IDisposable)
							{
								(enumerator as IDisposable).Dispose();
							}
						}
						int num2 = num;
						if (num2 == 0)
						{
							list[0].Checked = true;
						}
						else if (num2 > 1)
						{
							if (this.Checked)
							{
								try
								{
									foreach (MyRadioBox myRadioBox in list)
									{
										if (myRadioBox.Checked && !myRadioBox.Equals(this))
										{
											myRadioBox.Checked = false;
										}
									}
									goto IL_1D0;
								}
								finally
								{
									List<MyRadioBox>.Enumerator enumerator2;
									((IDisposable)enumerator2).Dispose();
								}
							}
							bool flag2 = false;
							try
							{
								foreach (MyRadioBox myRadioBox2 in list)
								{
									if (myRadioBox2.Checked)
									{
										if (flag2)
										{
											myRadioBox2.Checked = false;
										}
										else
										{
											flag2 = true;
										}
									}
								}
							}
							finally
							{
								List<MyRadioBox>.Enumerator enumerator3;
								((IDisposable)enumerator3).Dispose();
							}
						}
						IL_1D0:;
					}
					if (flag)
					{
						if (base.IsLoaded && ModAnimation.DefineModel() == 0 && anime)
						{
							if (this.Checked)
							{
								if (this.ShapeDot.Opacity < 0.01)
								{
									this.ShapeDot.Opacity = 1.0;
								}
								ModAnimation.AniStart(new ModAnimation.AniData[]
								{
									ModAnimation.AaScale(this.ShapeBorder, 10.0 - this.ShapeBorder.Width, 150, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Weak), false, true),
									ModAnimation.AaScale(this.ShapeBorder, 8.0, 300, 90, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Middle), false, true)
								}, "MyRadioBox Border " + Conversions.ToString(this.orderRequest), false);
								ModAnimation.AniStart(new ModAnimation.AniData[]
								{
									ModAnimation.AaScale(this.ShapeDot, 9.0 - this.ShapeDot.Width, 390, 0, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Weak), false, true),
									ModAnimation.AaOpacity(this.ShapeDot, 1.0 - this.ShapeDot.Opacity, 75, 90, null, false)
								}, "MyRadioBox Dot " + Conversions.ToString(this.orderRequest), false);
								ModAnimation.AniStart(new ModAnimation.AniData[]
								{
									ModAnimation.AaColor(this.ShapeBorder, Shape.StrokeProperty, base.IsMouseOver ? "ColorBrush3" : (base.IsEnabled ? "ColorBrush2" : "ColorBrushGray4"), 150, 0, null, false)
								}, "MyRadioBox BorderColor " + Conversions.ToString(this.orderRequest), false);
							}
							else
							{
								ModAnimation.AniStart(new ModAnimation.AniData[]
								{
									ModAnimation.AaScale(this.ShapeBorder, 18.0 - this.ShapeBorder.Width, 150, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false, true)
								}, "MyRadioBox Border " + Conversions.ToString(this.orderRequest), false);
								ModAnimation.AniStart(new ModAnimation.AniData[]
								{
									ModAnimation.AaScale(this.ShapeDot, -this.ShapeDot.Width, 150, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false, true),
									ModAnimation.AaOpacity(this.ShapeDot, -this.ShapeDot.Opacity, 75, 30, null, false)
								}, "MyRadioBox Dot " + Conversions.ToString(this.orderRequest), false);
								ModAnimation.AniStart(new ModAnimation.AniData[]
								{
									ModAnimation.AaColor(this.ShapeBorder, Shape.StrokeProperty, base.IsMouseOver ? "ColorBrush3" : (base.IsEnabled ? "ColorBrush1" : "ColorBrushGray4"), 150, 0, null, false)
								}, "MyRadioBox BorderColor " + Conversions.ToString(this.orderRequest), false);
							}
						}
						else
						{
							ModAnimation.AniStop("MyRadioBox Border " + Conversions.ToString(this.orderRequest));
							ModAnimation.AniStop("MyRadioBox Dot " + Conversions.ToString(this.orderRequest));
							ModAnimation.AniStop("MyRadioBox BorderColor " + Conversions.ToString(this.orderRequest));
							if (this.Checked)
							{
								this.ShapeDot.Width = 9.0;
								this.ShapeDot.Height = 9.0;
								this.ShapeDot.Opacity = 1.0;
								this.ShapeDot.Margin = new Thickness(5.5, 0.0, 0.0, 0.0);
								this.ShapeBorder.SetResourceReference(Shape.StrokeProperty, base.IsEnabled ? "ColorBrush2" : "ColorBrushGray4");
							}
							else
							{
								this.ShapeDot.Width = 0.0;
								this.ShapeDot.Height = 0.0;
								this.ShapeDot.Opacity = 0.0;
								this.ShapeDot.Margin = new Thickness(10.0, 0.0, 0.0, 0.0);
								this.ShapeBorder.SetResourceReference(Shape.StrokeProperty, base.IsEnabled ? "ColorBrush1" : "ColorBrushGray4");
							}
						}
						if (this.Checked)
						{
							IMyRadio.CheckEventHandler checkEventHandler = this.connectionRequest;
							if (checkEventHandler != null)
							{
								checkEventHandler(this, new ModBase.RouteEventArgs(user));
							}
						}
						IMyRadio.ChangedEventHandler customerRequest = this.m_CustomerRequest;
						if (customerRequest != null)
						{
							customerRequest(this, new ModBase.RouteEventArgs(user));
						}
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "单选框勾选改变错误", ModBase.LogLevel.Hint, "出现错误");
			}
		}

		// Token: 0x1700030B RID: 779
		// (get) Token: 0x0600119A RID: 4506 RVA: 0x0000A5AB File Offset: 0x000087AB
		// (set) Token: 0x0600119B RID: 4507 RVA: 0x0000A5BD File Offset: 0x000087BD
		public string Text
		{
			get
			{
				return Conversions.ToString(base.GetValue(MyRadioBox._DatabaseRequest));
			}
			set
			{
				base.SetValue(MyRadioBox._DatabaseRequest, value);
			}
		}

		// Token: 0x0600119C RID: 4508 RVA: 0x00077590 File Offset: 0x00075790
		private void Radiobox_MouseUp()
		{
			if (this.callbackRequest)
			{
				this.callbackRequest = false;
				ModBase.Log("[Control] 按下单选框：" + this.Text, ModBase.LogLevel.Normal, "出现错误");
				this.SetChecked(true, true, true);
				ModAnimation.AniStart(ModAnimation.AaColor(this.ShapeBorder, Shape.FillProperty, "ColorBrushHalfWhite", 100, 0, null, false), "MyRadioBox Background " + Conversions.ToString(this.orderRequest), false);
			}
		}

		// Token: 0x0600119D RID: 4509 RVA: 0x00077608 File Offset: 0x00075808
		private void Radiobox_MouseDown()
		{
			this.callbackRequest = true;
			base.Focus();
			ModAnimation.AniStart(ModAnimation.AaColor(this.ShapeBorder, Shape.FillProperty, "ColorBrush9", 100, 0, null, false), "MyRadioBox Background " + Conversions.ToString(this.orderRequest), false);
			if (!this.Checked)
			{
				ModAnimation.AniStart(ModAnimation.AaScale(this.ShapeBorder, 16.5 - this.ShapeBorder.Width, 1000, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false, true), "MyRadioBox Border " + Conversions.ToString(this.orderRequest), false);
			}
		}

		// Token: 0x0600119E RID: 4510 RVA: 0x000776AC File Offset: 0x000758AC
		private void Radiobox_MouseLeave()
		{
			if (this.callbackRequest)
			{
				this.callbackRequest = false;
				ModAnimation.AniStart(ModAnimation.AaColor(this.ShapeBorder, Shape.FillProperty, "ColorBrushHalfWhite", 100, 0, null, false), "MyRadioBox Background " + Conversions.ToString(this.orderRequest), false);
				if (!this.Checked)
				{
					ModAnimation.AniStart(ModAnimation.AaScale(this.ShapeBorder, 18.0 - this.ShapeBorder.Width, 400, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false, true), "MyRadioBox Border " + Conversions.ToString(this.orderRequest), false);
				}
			}
		}

		// Token: 0x0600119F RID: 4511 RVA: 0x00077754 File Offset: 0x00075954
		private void Radiobox_IsEnabledChanged()
		{
			if (!base.IsLoaded || ModAnimation.DefineModel() != 0)
			{
				ModAnimation.AniStop("MyRadioBox BorderColor " + Conversions.ToString(this.orderRequest));
				ModAnimation.AniStop("MyRadioBox TextColor " + Conversions.ToString(this.orderRequest));
				this.LabText.SetResourceReference(TextBlock.ForegroundProperty, base.IsEnabled ? "ColorBrush1" : "ColorBrushGray4");
				this.ShapeBorder.SetResourceReference(Shape.StrokeProperty, base.IsEnabled ? (this.Checked ? "ColorBrush2" : "ColorBrush1") : "ColorBrushGray4");
				return;
			}
			if (base.IsEnabled)
			{
				this.Radiobox_MouseLeaveAnimation();
				return;
			}
			ModAnimation.AniStart(ModAnimation.AaColor(this.ShapeBorder, Shape.StrokeProperty, ModMain._ValAccount - this.ShapeBorder.Stroke, 200, 0, null, false), "MyRadioBox BorderColor " + Conversions.ToString(this.orderRequest), false);
			ModAnimation.AniStart(ModAnimation.AaColor(this.LabText, TextBlock.ForegroundProperty, ModMain._ValAccount - this.LabText.Foreground, 200, 0, null, false), "MyRadioBox TextColor " + Conversions.ToString(this.orderRequest), false);
		}

		// Token: 0x060011A0 RID: 4512 RVA: 0x000778AC File Offset: 0x00075AAC
		private void Radiobox_MouseEnterAnimation()
		{
			ModAnimation.AniStart(ModAnimation.AaColor(this.ShapeBorder, Shape.StrokeProperty, "ColorBrush3", 100, 0, null, false), "MyRadioBox BorderColor " + Conversions.ToString(this.orderRequest), false);
			ModAnimation.AniStart(ModAnimation.AaColor(this.LabText, TextBlock.ForegroundProperty, "ColorBrush3", 100, 0, null, false), "MyRadioBox TextColor " + Conversions.ToString(this.orderRequest), false);
		}

		// Token: 0x060011A1 RID: 4513 RVA: 0x00077924 File Offset: 0x00075B24
		private void Radiobox_MouseLeaveAnimation()
		{
			if (base.IsEnabled)
			{
				if (base.IsLoaded && ModAnimation.DefineModel() == 0)
				{
					ModAnimation.AniStart(ModAnimation.AaColor(this.ShapeBorder, Shape.StrokeProperty, base.IsEnabled ? (this.Checked ? "ColorBrush2" : "ColorBrush1") : "ColorBrushGray4", 200, 0, null, false), "MyRadioBox BorderColor " + Conversions.ToString(this.orderRequest), false);
					ModAnimation.AniStart(ModAnimation.AaColor(this.LabText, TextBlock.ForegroundProperty, base.IsEnabled ? "ColorBrush1" : "ColorBrushGray4", 200, 0, null, false), "MyRadioBox TextColor " + Conversions.ToString(this.orderRequest), false);
					return;
				}
				this.ShapeBorder.SetResourceReference(Shape.StrokeProperty, base.IsEnabled ? (this.Checked ? "ColorBrush2" : "ColorBrush1") : "ColorBrushGray4");
				this.LabText.SetResourceReference(TextBlock.ForegroundProperty, base.IsEnabled ? "ColorBrush1" : "ColorBrushGray4");
			}
		}

		// Token: 0x1700030C RID: 780
		// (get) Token: 0x060011A2 RID: 4514 RVA: 0x0000A5CB File Offset: 0x000087CB
		// (set) Token: 0x060011A3 RID: 4515 RVA: 0x0000A5D3 File Offset: 0x000087D3
		internal virtual MyRadioBox PanBack { get; set; }

		// Token: 0x1700030D RID: 781
		// (get) Token: 0x060011A4 RID: 4516 RVA: 0x0000A5DC File Offset: 0x000087DC
		// (set) Token: 0x060011A5 RID: 4517 RVA: 0x0000A5E4 File Offset: 0x000087E4
		internal virtual TextBlock LabText { get; set; }

		// Token: 0x1700030E RID: 782
		// (get) Token: 0x060011A6 RID: 4518 RVA: 0x0000A5ED File Offset: 0x000087ED
		// (set) Token: 0x060011A7 RID: 4519 RVA: 0x0000A5F5 File Offset: 0x000087F5
		internal virtual Ellipse ShapeBorder { get; set; }

		// Token: 0x1700030F RID: 783
		// (get) Token: 0x060011A8 RID: 4520 RVA: 0x0000A5FE File Offset: 0x000087FE
		// (set) Token: 0x060011A9 RID: 4521 RVA: 0x0000A606 File Offset: 0x00008806
		internal virtual Ellipse ShapeDot { get; set; }

		// Token: 0x060011AA RID: 4522 RVA: 0x00077A48 File Offset: 0x00075C48
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_ConsumerRequest)
			{
				this.m_ConsumerRequest = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/controls/myradiobox.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x060011AB RID: 4523 RVA: 0x00077A78 File Offset: 0x00075C78
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyRadioBox)target;
				return;
			}
			if (connectionId == 2)
			{
				this.LabText = (TextBlock)target;
				return;
			}
			if (connectionId == 3)
			{
				this.ShapeBorder = (Ellipse)target;
				return;
			}
			if (connectionId == 4)
			{
				this.ShapeDot = (Ellipse)target;
				return;
			}
			this.m_ConsumerRequest = true;
		}

		// Token: 0x0400089A RID: 2202
		public int orderRequest;

		// Token: 0x0400089B RID: 2203
		[CompilerGenerated]
		private MyRadioBox.PreviewCheckEventHandler policyRequest;

		// Token: 0x0400089C RID: 2204
		[CompilerGenerated]
		private MyRadioBox.PreviewChangeEventHandler threadRequest;

		// Token: 0x0400089D RID: 2205
		[CompilerGenerated]
		private IMyRadio.CheckEventHandler connectionRequest;

		// Token: 0x0400089E RID: 2206
		[CompilerGenerated]
		private IMyRadio.ChangedEventHandler m_CustomerRequest;

		// Token: 0x0400089F RID: 2207
		private bool _SchemaRequest;

		// Token: 0x040008A0 RID: 2208
		public static readonly DependencyProperty _DatabaseRequest = DependencyProperty.Register("Text", typeof(string), typeof(MyRadioBox), new PropertyMetadata(delegate(DependencyObject sender, DependencyPropertyChangedEventArgs e)
		{
			if (!Information.IsNothing(sender))
			{
				((MyRadioBox)sender).LabText.Text = Conversions.ToString(e.NewValue);
			}
		}));

		// Token: 0x040008A1 RID: 2209
		private bool callbackRequest;

		// Token: 0x040008A2 RID: 2210
		private bool _AdvisorRequest;

		// Token: 0x040008A3 RID: 2211
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyRadioBox m_ObserverRequest;

		// Token: 0x040008A4 RID: 2212
		[AccessedThroughProperty("LabText")]
		[CompilerGenerated]
		private TextBlock _SingletonRequest;

		// Token: 0x040008A5 RID: 2213
		[AccessedThroughProperty("ShapeBorder")]
		[CompilerGenerated]
		private Ellipse m_ContextRequest;

		// Token: 0x040008A6 RID: 2214
		[AccessedThroughProperty("ShapeDot")]
		[CompilerGenerated]
		private Ellipse _CollectionRequest;

		// Token: 0x040008A7 RID: 2215
		private bool m_ConsumerRequest;

		// Token: 0x0200017B RID: 379
		// (Invoke) Token: 0x060011B5 RID: 4533
		public delegate void PreviewCheckEventHandler(object sender, ModBase.RouteEventArgs e);

		// Token: 0x0200017C RID: 380
		// (Invoke) Token: 0x060011BA RID: 4538
		public delegate void PreviewChangeEventHandler(object sender, ModBase.RouteEventArgs e);
	}
}
