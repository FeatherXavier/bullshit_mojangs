﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000176 RID: 374
	[DesignerGenerated]
	public class MyIconButton : Border, IComponentConnector
	{
		// Token: 0x06001146 RID: 4422 RVA: 0x000756F8 File Offset: 0x000738F8
		public MyIconButton()
		{
			base.MouseLeftButtonUp += this.Button_MouseUp;
			base.MouseLeftButtonDown += this.Button_MouseDown;
			base.MouseLeftButtonUp += delegate(object sender, MouseButtonEventArgs e)
			{
				this.Button_MouseUp();
			};
			base.MouseLeave += delegate(object sender, MouseEventArgs e)
			{
				this.Button_MouseLeave();
			};
			base.MouseEnter += delegate(object sender, MouseEventArgs e)
			{
				this.RefreshAnim();
			};
			base.MouseLeave += delegate(object sender, MouseEventArgs e)
			{
				this.RefreshAnim();
			};
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.RefreshAnim();
			};
			this.attrRequest = ModBase.GetUuid();
			this.m_FacadeRequest = 1.0;
			this.Theme = MyIconButton.Themes.Color;
			this.structRequest = new SolidColorBrush(Color.FromRgb(128, 128, 128));
			this.indexerRequest = false;
			this.InitializeComponent();
		}

		// Token: 0x1400000B RID: 11
		// (add) Token: 0x06001147 RID: 4423 RVA: 0x000757D8 File Offset: 0x000739D8
		// (remove) Token: 0x06001148 RID: 4424 RVA: 0x00075810 File Offset: 0x00073A10
		public event MyIconButton.ClickEventHandler Click
		{
			[CompilerGenerated]
			add
			{
				MyIconButton.ClickEventHandler clickEventHandler = this.m_ProductRequest;
				MyIconButton.ClickEventHandler clickEventHandler2;
				do
				{
					clickEventHandler2 = clickEventHandler;
					MyIconButton.ClickEventHandler value2 = (MyIconButton.ClickEventHandler)Delegate.Combine(clickEventHandler2, value);
					clickEventHandler = Interlocked.CompareExchange<MyIconButton.ClickEventHandler>(ref this.m_ProductRequest, value2, clickEventHandler2);
				}
				while (clickEventHandler != clickEventHandler2);
			}
			[CompilerGenerated]
			remove
			{
				MyIconButton.ClickEventHandler clickEventHandler = this.m_ProductRequest;
				MyIconButton.ClickEventHandler clickEventHandler2;
				do
				{
					clickEventHandler2 = clickEventHandler;
					MyIconButton.ClickEventHandler value2 = (MyIconButton.ClickEventHandler)Delegate.Remove(clickEventHandler2, value);
					clickEventHandler = Interlocked.CompareExchange<MyIconButton.ClickEventHandler>(ref this.m_ProductRequest, value2, clickEventHandler2);
				}
				while (clickEventHandler != clickEventHandler2);
			}
		}

		// Token: 0x170002F9 RID: 761
		// (get) Token: 0x06001149 RID: 4425 RVA: 0x0000A303 File Offset: 0x00008503
		// (set) Token: 0x0600114A RID: 4426 RVA: 0x0000A315 File Offset: 0x00008515
		public string Logo
		{
			get
			{
				return this.Path.Data.ToString();
			}
			set
			{
				this.Path.Data = (Geometry)new GeometryConverter().ConvertFromString(value);
			}
		}

		// Token: 0x170002FA RID: 762
		// (get) Token: 0x0600114B RID: 4427 RVA: 0x0000A332 File Offset: 0x00008532
		// (set) Token: 0x0600114C RID: 4428 RVA: 0x0000A33A File Offset: 0x0000853A
		public double LogoScale
		{
			get
			{
				return this.m_FacadeRequest;
			}
			set
			{
				this.m_FacadeRequest = value;
				if (!Information.IsNothing(this.Path))
				{
					this.Path.RenderTransform = new ScaleTransform
					{
						ScaleX = this.LogoScale,
						ScaleY = this.LogoScale
					};
				}
			}
		}

		// Token: 0x170002FB RID: 763
		// (get) Token: 0x0600114D RID: 4429 RVA: 0x0000A378 File Offset: 0x00008578
		// (set) Token: 0x0600114E RID: 4430 RVA: 0x0000A380 File Offset: 0x00008580
		public MyIconButton.Themes Theme { get; set; }

		// Token: 0x170002FC RID: 764
		// (get) Token: 0x0600114F RID: 4431 RVA: 0x0000A389 File Offset: 0x00008589
		// (set) Token: 0x06001150 RID: 4432 RVA: 0x0000A391 File Offset: 0x00008591
		public SolidColorBrush Foreground
		{
			get
			{
				return this.structRequest;
			}
			set
			{
				this.structRequest = value;
				checked
				{
					ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
					this.RefreshAnim();
					ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
				}
			}
		}

		// Token: 0x06001151 RID: 4433 RVA: 0x00075848 File Offset: 0x00073A48
		private void Button_MouseUp(object sender, MouseButtonEventArgs e)
		{
			if (this.indexerRequest)
			{
				ModBase.Log("[Control] 按下图标按钮" + (string.IsNullOrEmpty(base.Name) ? "" : ("：" + base.Name)), ModBase.LogLevel.Normal, "出现错误");
				MyIconButton.ClickEventHandler productRequest = this.m_ProductRequest;
				if (productRequest != null)
				{
					productRequest(RuntimeHelpers.GetObjectValue(sender), e);
				}
				e.Handled = true;
				this.Button_MouseUp();
			}
		}

		// Token: 0x06001152 RID: 4434 RVA: 0x000758BC File Offset: 0x00073ABC
		private void Button_MouseDown(object sender, MouseButtonEventArgs e)
		{
			this.indexerRequest = true;
			base.Focus();
			ModAnimation.AniStart(ModAnimation.AaScaleTransform(this.PanBack, 0.8 - ((ScaleTransform)this.PanBack.RenderTransform).ScaleX, 400, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false), "MyIconButton Scale " + Conversions.ToString(this.attrRequest), false);
		}

		// Token: 0x06001153 RID: 4435 RVA: 0x0007592C File Offset: 0x00073B2C
		private void Button_MouseUp()
		{
			if (this.indexerRequest)
			{
				this.indexerRequest = false;
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaScaleTransform(this.PanBack, 1.05 - ((ScaleTransform)this.PanBack.RenderTransform).ScaleX, 250, 0, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Weak), false),
					ModAnimation.AaScaleTransform(this.PanBack, -0.05, 250, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false)
				}, "MyIconButton Scale " + Conversions.ToString(this.attrRequest), false);
			}
			this.RefreshAnim();
		}

		// Token: 0x06001154 RID: 4436 RVA: 0x000759D8 File Offset: 0x00073BD8
		private void Button_MouseLeave()
		{
			this.indexerRequest = false;
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaScaleTransform(this.PanBack, 1.0 - ((ScaleTransform)this.PanBack.RenderTransform).ScaleX, 250, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false)
			}, "MyIconButton Scale " + Conversions.ToString(this.attrRequest), false);
			this.RefreshAnim();
		}

		// Token: 0x06001155 RID: 4437 RVA: 0x00075A54 File Offset: 0x00073C54
		public void RefreshAnim()
		{
			try
			{
				if (base.IsLoaded && ModAnimation.DefineModel() == 0)
				{
					if (this.PanBack.Background == null)
					{
						this.PanBack.Background = new ModBase.MyColor(0.0, 255.0, 255.0, 255.0);
					}
					if (this.Path.Fill == null && this.Theme == MyIconButton.Themes.Black)
					{
						this.Path.Fill = new ModBase.MyColor(140.0, 0.0, 0.0, 0.0);
					}
					if (base.IsMouseOver)
					{
						List<ModAnimation.AniData> list = new List<ModAnimation.AniData>();
						switch (this.Theme)
						{
						case MyIconButton.Themes.Color:
							list.Add(ModAnimation.AaColor(this.Path, Shape.FillProperty, "ColorBrush2", 120, 0, null, false));
							break;
						case MyIconButton.Themes.White:
							list.Add(ModAnimation.AaColor(this.PanBack, Border.BackgroundProperty, new ModBase.MyColor(50.0, 255.0, 255.0, 255.0) - this.PanBack.Background, 120, 0, null, false));
							break;
						case MyIconButton.Themes.Black:
							list.Add(ModAnimation.AaColor(this.Path, Shape.FillProperty, new ModBase.MyColor(230.0, 0.0, 0.0, 0.0) - this.Path.Fill, 120, 0, null, false));
							break;
						case MyIconButton.Themes.Custom:
							list.Add(ModAnimation.AaColor(this.Path, Shape.FillProperty, new ModBase.MyColor(255.0, this.Foreground) - this.Path.Fill, 120, 0, null, false));
							break;
						}
						ModAnimation.AniStart(list, "MyIconButton Color " + Conversions.ToString(this.attrRequest), false);
					}
					else
					{
						List<ModAnimation.AniData> list2 = new List<ModAnimation.AniData>();
						switch (this.Theme)
						{
						case MyIconButton.Themes.Color:
							list2.Add(ModAnimation.AaColor(this.Path, Shape.FillProperty, "ColorBrush4", 150, 0, null, false));
							this.PanBack.Background = new ModBase.MyColor(0.0, 255.0, 255.0, 255.0);
							break;
						case MyIconButton.Themes.White:
							list2.Add(ModAnimation.AaColor(this.Path, Shape.FillProperty, "ColorBrush8", 150, 0, null, false));
							list2.Add(ModAnimation.AaColor(this.PanBack, Border.BackgroundProperty, new ModBase.MyColor(0.0, 255.0, 255.0, 255.0) - this.PanBack.Background, 150, 0, null, false));
							break;
						case MyIconButton.Themes.Black:
							list2.Add(ModAnimation.AaColor(this.Path, Shape.FillProperty, new ModBase.MyColor(160.0, 0.0, 0.0, 0.0) - this.Path.Fill, 150, 0, null, false));
							this.PanBack.Background = new ModBase.MyColor(0.0, 255.0, 255.0, 255.0);
							break;
						case MyIconButton.Themes.Custom:
							list2.Add(ModAnimation.AaColor(this.Path, Shape.FillProperty, new ModBase.MyColor(160.0, this.Foreground) - this.Path.Fill, 150, 0, null, false));
							this.PanBack.Background = new ModBase.MyColor(0.0, 255.0, 255.0, 255.0);
							break;
						}
						ModAnimation.AniStart(list2, "MyIconButton Color " + Conversions.ToString(this.attrRequest), false);
					}
				}
				else
				{
					ModAnimation.AniStop("MyIconButton Color " + Conversions.ToString(this.attrRequest));
					switch (this.Theme)
					{
					case MyIconButton.Themes.Color:
						this.Path.SetResourceReference(Shape.FillProperty, "ColorBrush5");
						break;
					case MyIconButton.Themes.White:
						this.Path.SetResourceReference(Shape.FillProperty, "ColorBrush8");
						break;
					case MyIconButton.Themes.Black:
						this.Path.Fill = new ModBase.MyColor(160.0, 0.0, 0.0, 0.0);
						break;
					case MyIconButton.Themes.Custom:
						this.Path.Fill = new ModBase.MyColor(160.0, this.Foreground);
						break;
					}
					this.PanBack.Background = new ModBase.MyColor(0.0, 255.0, 255.0, 255.0);
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "刷新图标按钮动画状态出错", ModBase.LogLevel.Debug, "出现错误");
			}
		}

		// Token: 0x170002FD RID: 765
		// (get) Token: 0x06001156 RID: 4438 RVA: 0x0000A3B8 File Offset: 0x000085B8
		// (set) Token: 0x06001157 RID: 4439 RVA: 0x0000A3C0 File Offset: 0x000085C0
		internal virtual Border PanBack { get; set; }

		// Token: 0x170002FE RID: 766
		// (get) Token: 0x06001158 RID: 4440 RVA: 0x0000A3C9 File Offset: 0x000085C9
		// (set) Token: 0x06001159 RID: 4441 RVA: 0x0000A3D1 File Offset: 0x000085D1
		internal virtual Path Path { get; set; }

		// Token: 0x0600115A RID: 4442 RVA: 0x00076020 File Offset: 0x00074220
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.getterRequest)
			{
				this.getterRequest = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/controls/myiconbutton.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x0600115B RID: 4443 RVA: 0x0000A3DA File Offset: 0x000085DA
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (Border)target;
				return;
			}
			if (connectionId == 2)
			{
				this.Path = (Path)target;
				return;
			}
			this.getterRequest = true;
		}

		// Token: 0x0400087E RID: 2174
		[CompilerGenerated]
		private MyIconButton.ClickEventHandler m_ProductRequest;

		// Token: 0x0400087F RID: 2175
		public int attrRequest;

		// Token: 0x04000880 RID: 2176
		private double m_FacadeRequest;

		// Token: 0x04000881 RID: 2177
		[CompilerGenerated]
		private MyIconButton.Themes bridgeRequest;

		// Token: 0x04000882 RID: 2178
		private SolidColorBrush structRequest;

		// Token: 0x04000883 RID: 2179
		private bool indexerRequest;

		// Token: 0x04000884 RID: 2180
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private Border _TemplateRequest;

		// Token: 0x04000885 RID: 2181
		[CompilerGenerated]
		[AccessedThroughProperty("Path")]
		private Path _ExpressionRequest;

		// Token: 0x04000886 RID: 2182
		private bool getterRequest;

		// Token: 0x02000177 RID: 375
		// (Invoke) Token: 0x06001165 RID: 4453
		public delegate void ClickEventHandler(object sender, EventArgs e);

		// Token: 0x02000178 RID: 376
		public enum Themes
		{
			// Token: 0x04000888 RID: 2184
			Color,
			// Token: 0x04000889 RID: 2185
			White,
			// Token: 0x0400088A RID: 2186
			Black,
			// Token: 0x0400088B RID: 2187
			Custom
		}
	}
}
