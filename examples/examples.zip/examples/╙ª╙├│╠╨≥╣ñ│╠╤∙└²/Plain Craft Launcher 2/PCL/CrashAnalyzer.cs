﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000063 RID: 99
	public class CrashAnalyzer
	{
		// Token: 0x06000305 RID: 773 RVA: 0x00018E58 File Offset: 0x00017058
		public CrashAnalyzer(int UUID)
		{
			this.templateWrapper = new List<KeyValuePair<string, string[]>>();
			this._ExpressionWrapper = null;
			this.getterWrapper = null;
			this._ListenerWrapper = null;
			this.instanceWrapper = new Dictionary<CrashAnalyzer.CrashReason, List<string>>();
			this._CreatorWrapper = new List<string>();
			object structWrapper = CrashAnalyzer._StructWrapper;
			ObjectFlowControl.CheckForSyncLockOnValueType(structWrapper);
			lock (structWrapper)
			{
				if (!CrashAnalyzer.m_BridgeWrapper)
				{
					try
					{
						ModBase.DeleteDirectory(ModBase.attributeState + "CrashAnalyzer", false);
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "清理崩溃分析缓存失败", ModBase.LogLevel.Debug, "出现错误");
					}
					CrashAnalyzer.m_BridgeWrapper = true;
				}
			}
			this._IndexerWrapper = string.Concat(new string[]
			{
				ModBase.attributeState,
				"CrashAnalyzer\\",
				Conversions.ToString(UUID),
				Conversions.ToString(ModBase.RandomInteger(0, 99999999)),
				"\\"
			});
			ModBase.DeleteDirectory(this._IndexerWrapper, false);
			Directory.CreateDirectory(this._IndexerWrapper + "Temp\\");
			Directory.CreateDirectory(this._IndexerWrapper + "Report\\");
			ModBase.Log("[Crash] 崩溃分析暂存文件夹：" + this._IndexerWrapper, ModBase.LogLevel.Normal, "出现错误");
		}

		// Token: 0x06000306 RID: 774 RVA: 0x00018FBC File Offset: 0x000171BC
		public void Collect(string VersionPathIndie, IList<string> LatestLog = null)
		{
			ModBase.Log("[Crash] 步骤 1：收集日志文件", ModBase.LogLevel.Normal, "出现错误");
			List<string> list = new List<string>();
			try
			{
				DirectoryInfo directoryInfo = new DirectoryInfo(VersionPathIndie + "crash-reports\\");
				if (directoryInfo.Exists)
				{
					try
					{
						foreach (FileInfo fileInfo in directoryInfo.EnumerateFiles())
						{
							list.Add(fileInfo.FullName);
						}
					}
					finally
					{
						IEnumerator<FileInfo> enumerator;
						if (enumerator != null)
						{
							enumerator.Dispose();
						}
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "收集 Minecraft 崩溃日志文件夹下的日志失败", ModBase.LogLevel.Debug, "出现错误");
			}
			try
			{
				try
				{
					foreach (FileInfo fileInfo2 in new DirectoryInfo(VersionPathIndie).Parent.Parent.EnumerateFiles())
					{
						if (Operators.CompareString(fileInfo2.Extension ?? "", ".log", true) == 0)
						{
							list.Add(fileInfo2.FullName);
						}
					}
				}
				finally
				{
					IEnumerator<FileInfo> enumerator2;
					if (enumerator2 != null)
					{
						enumerator2.Dispose();
					}
				}
			}
			catch (Exception ex2)
			{
				ModBase.Log(ex2, "收集 Minecraft 主文件夹下的日志失败", ModBase.LogLevel.Debug, "出现错误");
			}
			try
			{
				try
				{
					foreach (FileInfo fileInfo3 in new DirectoryInfo(VersionPathIndie).EnumerateFiles())
					{
						if (Operators.CompareString(fileInfo3.Extension ?? "", ".log", true) == 0)
						{
							list.Add(fileInfo3.FullName);
						}
					}
				}
				finally
				{
					IEnumerator<FileInfo> enumerator3;
					if (enumerator3 != null)
					{
						enumerator3.Dispose();
					}
				}
			}
			catch (Exception ex3)
			{
				ModBase.Log(ex3, "收集 Minecraft 隔离文件夹下的日志失败", ModBase.LogLevel.Debug, "出现错误");
			}
			list.Add(VersionPathIndie + "logs\\latest.log");
			list.Add(VersionPathIndie + "logs\\debug.log");
			list = ModBase.ArrayNoDouble<string>(list, null);
			List<string> list2 = new List<string>();
			try
			{
				foreach (string text in list)
				{
					try
					{
						FileInfo fileInfo4 = new FileInfo(text);
						if (fileInfo4.Exists)
						{
							double num = Math.Abs((fileInfo4.LastWriteTime - DateTime.Now).TotalMinutes);
							if (num < 5.0 && fileInfo4.Length > 0L)
							{
								list2.Add(text);
								ModBase.Log(string.Concat(new string[]
								{
									"[Crash] 可能可用的日志文件：",
									text,
									"（",
									Conversions.ToString(Math.Round(num, 1)),
									" 分钟）"
								}), ModBase.LogLevel.Normal, "出现错误");
							}
						}
					}
					catch (Exception ex4)
					{
						ModBase.Log(ex4, "确认崩溃日志时间失败（" + text + "）", ModBase.LogLevel.Debug, "出现错误");
					}
				}
			}
			finally
			{
				List<string>.Enumerator enumerator4;
				((IDisposable)enumerator4).Dispose();
			}
			if (list2.Count == 0)
			{
				ModBase.Log("[Crash] 未发现可能可用的日志文件", ModBase.LogLevel.Normal, "出现错误");
			}
			try
			{
				foreach (string text2 in list2)
				{
					try
					{
						if (text2.Contains("crash-"))
						{
							this.templateWrapper.Add(new KeyValuePair<string, string[]>(text2, ModBase.ReadFile(text2).Replace("\r\n", "\r").Replace("\n", "\r").Split(new char[]
							{
								'\r'
							})));
						}
						else
						{
							this.templateWrapper.Add(new KeyValuePair<string, string[]>(text2, File.ReadAllLines(text2, Encoding.UTF8)));
						}
					}
					catch (Exception ex5)
					{
						ModBase.Log(ex5, "读取可能的崩溃日志文件失败（" + text2 + "）", ModBase.LogLevel.Debug, "出现错误");
					}
				}
			}
			finally
			{
				List<string>.Enumerator enumerator5;
				((IDisposable)enumerator5).Dispose();
			}
			if (LatestLog != null && LatestLog.Count > 0)
			{
				string text3 = ModBase.Join((ICollection)LatestLog, "\r\n");
				ModBase.Log("[Crash] 以下为游戏输出的最后一段内容：\r\n" + text3, ModBase.LogLevel.Normal, "出现错误");
				ModBase.WriteFile(this._IndexerWrapper + "RawOutput.log", text3, false, null);
				this.templateWrapper.Add(new KeyValuePair<string, string[]>(this._IndexerWrapper + "RawOutput.log", LatestLog.ToArray<string>()));
				LatestLog.Clear();
			}
			ModBase.Log("[Crash] 步骤 1：收集日志文件完成，收集到 " + Conversions.ToString(this.templateWrapper.Count) + " 个文件", ModBase.LogLevel.Normal, "出现错误");
		}

		// Token: 0x06000307 RID: 775 RVA: 0x000194A4 File Offset: 0x000176A4
		public void Import(string FilePath)
		{
			ModBase.Log("[Crash] 步骤 1：自主导入日志文件", ModBase.LogLevel.Normal, "出现错误");
			try
			{
				FileInfo fileInfo = new FileInfo(FilePath);
				if (fileInfo.Exists && fileInfo.Length != 0L)
				{
					if (ModBase.ExtractFile(FilePath, this._IndexerWrapper + "Temp\\", null))
					{
						ModBase.Log("[Crash] 已解压导入的日志文件：" + FilePath, ModBase.LogLevel.Normal, "出现错误");
					}
					else
					{
						File.Copy(FilePath, this._IndexerWrapper + "Temp\\" + ModBase.GetFileNameFromPath(FilePath));
						ModBase.Log("[Crash] 已复制导入的日志文件：" + FilePath, ModBase.LogLevel.Normal, "出现错误");
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "解压导入文件中的压缩包失败", ModBase.LogLevel.Debug, "出现错误");
			}
			try
			{
				foreach (FileInfo fileInfo2 in new DirectoryInfo(this._IndexerWrapper + "Temp\\").EnumerateFiles())
				{
					try
					{
						if (fileInfo2.Exists && fileInfo2.Length != 0L)
						{
							string left = fileInfo2.Extension.ToLower();
							if (Operators.CompareString(left, ".log", true) == 0 || Operators.CompareString(left, ".txt", true) == 0)
							{
								if (fileInfo2.Name.StartsWith("crash-"))
								{
									this.templateWrapper.Add(new KeyValuePair<string, string[]>(fileInfo2.FullName, ModBase.ReadFile(fileInfo2.FullName).Replace("\r\n", "\r").Replace("\n", "\r").Split(new char[]
									{
										'\r'
									})));
								}
								else
								{
									this.templateWrapper.Add(new KeyValuePair<string, string[]>(fileInfo2.FullName, File.ReadAllLines(fileInfo2.FullName, Encoding.UTF8)));
								}
							}
						}
					}
					catch (Exception ex2)
					{
						ModBase.Log(ex2, "导入单个日志文件失败", ModBase.LogLevel.Debug, "出现错误");
					}
				}
			}
			finally
			{
				IEnumerator<FileInfo> enumerator;
				if (enumerator != null)
				{
					enumerator.Dispose();
				}
			}
			ModBase.Log("[Crash] 步骤 1：自主导入日志文件，收集到 " + Conversions.ToString(this.templateWrapper.Count) + " 个文件", ModBase.LogLevel.Normal, "出现错误");
		}

		// Token: 0x06000308 RID: 776 RVA: 0x0001970C File Offset: 0x0001790C
		public int Prepare()
		{
			ModBase.Log("[Crash] 步骤 2：准备日志文本", ModBase.LogLevel.Normal, "出现错误");
			List<KeyValuePair<CrashAnalyzer.AnalyzeFileType, KeyValuePair<string, string[]>>> list = new List<KeyValuePair<CrashAnalyzer.AnalyzeFileType, KeyValuePair<string, string[]>>>();
			try
			{
				foreach (KeyValuePair<string, string[]> value in this.templateWrapper)
				{
					string fileNameFromPath = ModBase.GetFileNameFromPath(value.Key);
					CrashAnalyzer.AnalyzeFileType analyzeFileType;
					if (fileNameFromPath.StartsWith("hs_err"))
					{
						analyzeFileType = CrashAnalyzer.AnalyzeFileType.HsErr;
					}
					else if (fileNameFromPath.StartsWith("crash-"))
					{
						analyzeFileType = CrashAnalyzer.AnalyzeFileType.CrashReport;
					}
					else if (Operators.CompareString(fileNameFromPath, "latest.log", true) != 0 && Operators.CompareString(fileNameFromPath, "latest log.txt", true) != 0 && Operators.CompareString(fileNameFromPath, "debug.log", true) != 0 && Operators.CompareString(fileNameFromPath, "debug log.txt", true) != 0 && Operators.CompareString(fileNameFromPath, "rawoutput.log", true) != 0 && Operators.CompareString(fileNameFromPath, "启动器日志.txt", true) != 0 && Operators.CompareString(fileNameFromPath, "log1.txt", true) != 0)
					{
						if (!fileNameFromPath.EndsWith(".log") && !fileNameFromPath.EndsWith(".txt"))
						{
							ModBase.Log("[Crash] " + fileNameFromPath + " 分类为 Ignore", ModBase.LogLevel.Normal, "出现错误");
							continue;
						}
						analyzeFileType = CrashAnalyzer.AnalyzeFileType.ExtraLog;
					}
					else
					{
						analyzeFileType = CrashAnalyzer.AnalyzeFileType.MinecraftLog;
					}
					if (value.Value.Count<string>() == 0)
					{
						ModBase.Log("[Crash] " + fileNameFromPath + " 由于内容为空跳过", ModBase.LogLevel.Normal, "出现错误");
					}
					else
					{
						list.Add(new KeyValuePair<CrashAnalyzer.AnalyzeFileType, KeyValuePair<string, string[]>>(analyzeFileType, value));
						ModBase.Log("[Crash] " + fileNameFromPath + " 分类为 " + ModBase.GetStringFromEnum(analyzeFileType), ModBase.LogLevel.Normal, "出现错误");
					}
				}
			}
			finally
			{
				List<KeyValuePair<string, string[]>>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			checked
			{
				foreach (CrashAnalyzer.AnalyzeFileType analyzeFileType2 in new CrashAnalyzer.AnalyzeFileType[]
				{
					CrashAnalyzer.AnalyzeFileType.MinecraftLog,
					CrashAnalyzer.AnalyzeFileType.HsErr,
					CrashAnalyzer.AnalyzeFileType.ExtraLog,
					CrashAnalyzer.AnalyzeFileType.CrashReport
				})
				{
					List<KeyValuePair<string, string[]>> list2 = new List<KeyValuePair<string, string[]>>();
					try
					{
						foreach (KeyValuePair<CrashAnalyzer.AnalyzeFileType, KeyValuePair<string, string[]>> keyValuePair in list)
						{
							if (analyzeFileType2 == keyValuePair.Key)
							{
								list2.Add(keyValuePair.Value);
							}
						}
					}
					finally
					{
						List<KeyValuePair<CrashAnalyzer.AnalyzeFileType, KeyValuePair<string, string[]>>>.Enumerator enumerator2;
						((IDisposable)enumerator2).Dispose();
					}
					if (list2.Count != 0)
					{
						try
						{
							switch (analyzeFileType2)
							{
							case CrashAnalyzer.AnalyzeFileType.HsErr:
							case CrashAnalyzer.AnalyzeFileType.CrashReport:
								break;
							case CrashAnalyzer.AnalyzeFileType.MinecraftLog:
							{
								this._ExpressionWrapper = "";
								Dictionary<string, KeyValuePair<string, string[]>> dictionary = new Dictionary<string, KeyValuePair<string, string[]>>();
								try
								{
									foreach (KeyValuePair<string, string[]> value2 in list2)
									{
										ModBase.DictionaryAdd<string, KeyValuePair<string, string[]>>(ref dictionary, ModBase.GetFileNameFromPath(value2.Key).ToLower(), value2);
										this._CreatorWrapper.Add(value2.Key);
										ModBase.Log("[Crash] 输出报告：" + value2.Key + "，作为 Minecraft 或启动器日志", ModBase.LogLevel.Normal, "出现错误");
									}
								}
								finally
								{
									List<KeyValuePair<string, string[]>>.Enumerator enumerator3;
									((IDisposable)enumerator3).Dispose();
								}
								foreach (string key in new string[]
								{
									"rawoutput.log",
									"启动器日志.txt",
									"log1.txt"
								})
								{
									if (dictionary.ContainsKey(key))
									{
										KeyValuePair<string, string[]> keyValuePair2 = dictionary[key];
										bool flag = false;
										foreach (string text in keyValuePair2.Value)
										{
											if (flag)
											{
												ref string ptr = ref this._ExpressionWrapper;
												this._ExpressionWrapper = ptr + text + "\r\n";
											}
											else if (text.Contains("以下为游戏输出的最后一段内容"))
											{
												flag = true;
												ModBase.Log("[Crash] 找到 PCL2 输出的游戏实时日志头", ModBase.LogLevel.Normal, "出现错误");
											}
										}
										if (!flag)
										{
											ref string ptr = ref this._ExpressionWrapper;
											this._ExpressionWrapper = ptr + this.GetHeadTailLines(keyValuePair2.Value, 0, 200);
										}
										this._ExpressionWrapper = this._ExpressionWrapper.TrimEnd("\r\n".ToCharArray()) + "\r\n[";
										ModBase.Log("[Crash] 导入分析：" + keyValuePair2.Key + "，作为启动器日志", ModBase.LogLevel.Normal, "出现错误");
										IL_3ED:
										string[] array3 = new string[]
										{
											"latest.log",
											"latest log.txt",
											"debug.log",
											"debug log.txt"
										};
										int l = 0;
										while (l < array3.Length)
										{
											string key2 = array3[l];
											if (!dictionary.ContainsKey(key2))
											{
												l++;
											}
											else
											{
												KeyValuePair<string, string[]> keyValuePair3 = dictionary[key2];
												ref string ptr = ref this._ExpressionWrapper;
												this._ExpressionWrapper = ptr + this.GetHeadTailLines(keyValuePair3.Value, 250, 500) + "\r\n[";
												ModBase.Log("[Crash] 导入分析：" + keyValuePair3.Key + "，作为 Minecraft 日志", ModBase.LogLevel.Normal, "出现错误");
												IL_497:
												if (Operators.CompareString(this._ExpressionWrapper, "", true) == 0)
												{
													this._ExpressionWrapper = null;
													throw new Exception("无法找到匹配的 Minecraft Log");
												}
												goto IL_68E;
											}
										}
										goto IL_497;
									}
								}
								goto IL_3ED;
							}
							case CrashAnalyzer.AnalyzeFileType.ExtraLog:
								try
								{
									foreach (KeyValuePair<string, string[]> keyValuePair4 in list2)
									{
										this._CreatorWrapper.Add(keyValuePair4.Key);
										ModBase.Log("[Crash] 输出报告：" + keyValuePair4.Key + "，作为额外日志", ModBase.LogLevel.Normal, "出现错误");
									}
									goto IL_68E;
								}
								finally
								{
									List<KeyValuePair<string, string[]>>.Enumerator enumerator4;
									((IDisposable)enumerator4).Dispose();
								}
								break;
							default:
								goto IL_68E;
							}
							SortedList<DateTime, KeyValuePair<string, string[]>> sortedList = new SortedList<DateTime, KeyValuePair<string, string[]>>();
							try
							{
								foreach (KeyValuePair<string, string[]> value4 in list2)
								{
									try
									{
										sortedList.Add(new FileInfo(value4.Key).LastWriteTime, value4);
									}
									catch (Exception ex)
									{
										ModBase.Log(ex, "获取日志文件修改时间失败", ModBase.LogLevel.Debug, "出现错误");
										sortedList.Add(new DateTime(1900, 1, 1), value4);
									}
								}
							}
							finally
							{
								List<KeyValuePair<string, string[]>>.Enumerator enumerator5;
								((IDisposable)enumerator5).Dispose();
							}
							KeyValuePair<string, string[]> value5 = sortedList.Last<KeyValuePair<DateTime, KeyValuePair<string, string[]>>>().Value;
							this._CreatorWrapper.Add(value5.Key);
							if (analyzeFileType2 == CrashAnalyzer.AnalyzeFileType.HsErr)
							{
								this.getterWrapper = this.GetHeadTailLines(value5.Value, 200, 100);
								ModBase.Log("[Crash] 输出报告：" + value5.Key + "，作为虚拟机错误信息", ModBase.LogLevel.Normal, "出现错误");
								ModBase.Log("[Crash] 导入分析：" + value5.Key + "，作为虚拟机错误信息", ModBase.LogLevel.Normal, "出现错误");
							}
							else
							{
								this._ListenerWrapper = this.GetHeadTailLines(value5.Value, 300, 700);
								ModBase.Log("[Crash] 输出报告：" + value5.Key + "，作为 Minecraft 崩溃报告", ModBase.LogLevel.Normal, "出现错误");
								ModBase.Log("[Crash] 导入分析：" + value5.Key + "，作为 Minecraft 崩溃报告", ModBase.LogLevel.Normal, "出现错误");
							}
							IL_68E:;
						}
						catch (Exception ex2)
						{
							ModBase.Log(ex2, "分类处理日志文件时出错", ModBase.LogLevel.Debug, "出现错误");
						}
					}
				}
				int num = ((this._ExpressionWrapper == null) ? 0 : 1) + ((this.getterWrapper == null) ? 0 : 1) + ((this._ListenerWrapper == null) ? 0 : 1);
				if (num == 0)
				{
					ModBase.Log("[Crash] 步骤 2：准备日志文本完成，没有任何可供分析的日志", ModBase.LogLevel.Normal, "出现错误");
				}
				else
				{
					ModBase.Log(("[Crash] 步骤 2：准备日志文本完成，找到" + ((this._ExpressionWrapper == null) ? "" : "游戏日志、") + ((this.getterWrapper == null) ? "" : "虚拟机日志、") + ((this._ListenerWrapper == null) ? "" : "崩溃日志、")).TrimEnd(new char[]
					{
						'、'
					}) + "用作分析", ModBase.LogLevel.Normal, "出现错误");
				}
				return num;
			}
		}

		// Token: 0x06000309 RID: 777 RVA: 0x00019F2C File Offset: 0x0001812C
		private string GetHeadTailLines(string[] Raw, int HeadLines, int TailLines)
		{
			checked
			{
				string result;
				if (Raw.Length <= HeadLines + TailLines)
				{
					result = ModBase.Join(Raw, "\r\n");
				}
				else
				{
					StringBuilder stringBuilder = new StringBuilder();
					int num = Raw.Count<string>() - 1;
					for (int i = 0; i <= num; i++)
					{
						if ((i < HeadLines || Raw.Count<string>() - i < TailLines) && Operators.CompareString(Raw[i], "", true) != 0)
						{
							stringBuilder.Append(Raw[i] + "\r\n");
						}
					}
					result = stringBuilder.ToString();
				}
				return result;
			}
		}

		// Token: 0x0600030A RID: 778 RVA: 0x00019FA8 File Offset: 0x000181A8
		public void Analyze(ModMinecraft.McVersion Version = null)
		{
			ModBase.Log("[Crash] 步骤 3：分析崩溃原因", ModBase.LogLevel.Normal, "出现错误");
			this.identifierWrapper = (this._ExpressionWrapper + this.getterWrapper + this._ListenerWrapper).ToLower();
			this.AnalyzeCrit1();
			if (this.instanceWrapper.Count <= 0)
			{
				if (!this.identifierWrapper.Contains("forge") && !this.identifierWrapper.Contains("fabric") && !this.identifierWrapper.Contains("liteloader"))
				{
					ModBase.Log("[Crash] 可能并未安装 Mod，不进行堆栈分析", ModBase.LogLevel.Normal, "出现错误");
				}
				else
				{
					if (this._ListenerWrapper != null)
					{
						ModBase.Log("[Crash] 开始进行崩溃日志堆栈分析", ModBase.LogLevel.Normal, "出现错误");
						List<string> list = this.AnalyzeStackKeyword(this._ListenerWrapper.Replace("A detailed walkthrough of the error", "¨").Split(new char[]
						{
							'¨'
						}).First<string>());
						if (list.Count > 0)
						{
							List<string> list2 = this.AnalyzeModName(list);
							if (list2 == null)
							{
								this.AppendReason(CrashAnalyzer.CrashReason.崩溃日志堆栈分析发现关键字, list);
								goto IL_1BB;
							}
							this.AppendReason(CrashAnalyzer.CrashReason.崩溃日志堆栈分析发现Mod名称, list2);
							goto IL_1BB;
						}
					}
					if (this._ExpressionWrapper != null)
					{
						List<string> list3 = ModBase.RegexSearch(this._ExpressionWrapper, "/FATAL] [\\w\\W]+?(?=[\\n\\r]+\\[)", RegexOptions.None);
						ModBase.Log("[Crash] 开始进行 Minecraft 日志堆栈分析，发现 " + Conversions.ToString(list3.Count) + " 个报错项", ModBase.LogLevel.Normal, "出现错误");
						if (list3.Count > 0)
						{
							List<string> list4 = new List<string>();
							try
							{
								foreach (string errorStack in list3)
								{
									list4.AddRange(this.AnalyzeStackKeyword(errorStack));
								}
							}
							finally
							{
								List<string>.Enumerator enumerator;
								((IDisposable)enumerator).Dispose();
							}
							if (list4.Count > 0)
							{
								this.AppendReason(CrashAnalyzer.CrashReason.MC日志堆栈分析发现关键字, ModBase.ArrayNoDouble<string>(list4, null));
								goto IL_1BB;
							}
						}
					}
				}
				this.AnalyzeCrit2();
			}
			IL_1BB:
			if (this.instanceWrapper.Count == 0)
			{
				ModBase.Log("[Crash] 步骤 3：分析崩溃原因完成，未找到可能的原因", ModBase.LogLevel.Normal, "出现错误");
				return;
			}
			ModBase.Log("[Crash] 步骤 3：分析崩溃原因完成，找到 " + Conversions.ToString(this.instanceWrapper.Count) + " 条可能的原因", ModBase.LogLevel.Normal, "出现错误");
			try
			{
				foreach (KeyValuePair<CrashAnalyzer.CrashReason, List<string>> keyValuePair in this.instanceWrapper)
				{
					ModBase.Log("[Crash]  - " + ModBase.GetStringFromEnum(keyValuePair.Key) + ((keyValuePair.Value.Count > 0) ? ("（" + ModBase.Join(keyValuePair.Value, "；") + "）") : ""), ModBase.LogLevel.Normal, "出现错误");
				}
			}
			finally
			{
				Dictionary<CrashAnalyzer.CrashReason, List<string>>.Enumerator enumerator2;
				((IDisposable)enumerator2).Dispose();
			}
		}

		// Token: 0x0600030B RID: 779 RVA: 0x0001A264 File Offset: 0x00018464
		private void AppendReason(CrashAnalyzer.CrashReason Reason, ICollection<string> Additional = null)
		{
			if (this.instanceWrapper.ContainsKey(Reason))
			{
				if (Additional != null)
				{
					this.instanceWrapper[Reason].AddRange(Additional);
					this.instanceWrapper[Reason] = ModBase.ArrayNoDouble<string>(this.instanceWrapper[Reason], null);
				}
			}
			else
			{
				this.instanceWrapper.Add(Reason, new List<string>(Additional ?? new string[0]));
			}
			ModBase.Log("[Crash] 可能的崩溃原因：" + ModBase.GetStringFromEnum(Reason) + ((Additional == null || Additional.Count <= 0) ? "" : ("（" + ModBase.Join((ICollection)Additional, "；") + "）")), ModBase.LogLevel.Normal, "出现错误");
		}

		// Token: 0x0600030C RID: 780 RVA: 0x00003B0B File Offset: 0x00001D0B
		private void AppendReason(CrashAnalyzer.CrashReason Reason, string Additional)
		{
			List<string> additional;
			if (!string.IsNullOrEmpty(Additional))
			{
				(additional = new List<string>()).Add(Additional);
			}
			else
			{
				additional = null;
			}
			this.AppendReason(Reason, additional);
		}

		// Token: 0x0600030D RID: 781 RVA: 0x0001A324 File Offset: 0x00018524
		private void AnalyzeCrit1()
		{
			if (this._ExpressionWrapper == null && this.getterWrapper == null && this._ListenerWrapper == null)
			{
				this.AppendReason(CrashAnalyzer.CrashReason.没有可用的分析文件, null);
				return;
			}
			if (this._ExpressionWrapper != null)
			{
				if (this._ExpressionWrapper.Contains("The driver does not appear to support OpenGL"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.显卡不支持OpenGL, null);
				}
				if (this._ExpressionWrapper.Contains("java.lang.ClassCastException: java.base/jdk"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.使用JDK, null);
				}
				if (this._ExpressionWrapper.Contains("java.lang.ClassCastException: class jdk."))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.使用JDK, null);
				}
				if (this._ExpressionWrapper.Contains("Open J9 is not supported") || this._ExpressionWrapper.Contains("OpenJ9 is incompatible") || this._ExpressionWrapper.Contains(".J9VMInternals."))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.使用OpenJ9, null);
				}
				if (this._ExpressionWrapper.Contains("because module java.base does not export"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.Java版本过高, null);
				}
				if (this._ExpressionWrapper.Contains("java.lang.ClassNotFoundException: java.lang.invoke.LambdaMetafactory"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.Java版本过高, null);
				}
				if (this._ExpressionWrapper.Contains("compiled by a more recent version of the Java Runtime"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.Java版本过低, null);
				}
				if (this._ExpressionWrapper.Contains("The directories below appear to be extracted jar files. Fix this before you continue."))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.Mod文件被解压, null);
				}
				if (this._ExpressionWrapper.Contains("Extracted mod jars found, loading will NOT continue"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.Mod文件被解压, null);
				}
				if (this._ExpressionWrapper.Contains("Couldn't set pixel format"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.显卡驱动不支持导致无法设置像素格式, null);
				}
				if (this._ExpressionWrapper.Contains("java.lang.OutOfMemoryError"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.内存不足, null);
				}
				if (this._ExpressionWrapper.Contains("1282: Invalid operation"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.光影或资源包导致OpenGL1282错误, null);
				}
				if (this._ExpressionWrapper.Contains("signer information does not match signer information of other classes in the same package"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.文件或内容校验失败, (ModBase.RegexSeek(this._ExpressionWrapper, "(?<=class \")[^']+(?=\"'s signer information)", RegexOptions.None) ?? "").TrimEnd(new char[]
					{
						'\r'
					}));
				}
				if (this._ExpressionWrapper.Contains("An exception was thrown, the game will display an error screen and halt."))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.Forge报错, (ModBase.RegexSeek(this._ExpressionWrapper, "(?<=the game will display an error screen and halt[\\s\\S]+?Exception: )[\\s\\S]+?(?=\\n\\tat)", RegexOptions.None) ?? "").TrimEnd(new char[]
					{
						'\r'
					}));
				}
				if (this._ExpressionWrapper.Contains("Maybe try a lower resolution resourcepack?"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.材质过大或显卡配置不足, null);
				}
				if (this._ExpressionWrapper.Contains("java.lang.NoSuchMethodError: net.minecraft.world.server.ChunkManager$ProxyTicketManager.shouldForceTicks(J)Z") && this._ExpressionWrapper.Contains("OptiFine"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.OptiFine导致无法加载世界, null);
				}
				if (this._ExpressionWrapper.Contains("Could not reserve enough space"))
				{
					if (this._ExpressionWrapper.Contains("for 1048576KB object heap"))
					{
						this.AppendReason(CrashAnalyzer.CrashReason.使用32位Java导致JVM无法分配足够多的内存, null);
					}
					else
					{
						this.AppendReason(CrashAnalyzer.CrashReason.内存不足, null);
					}
				}
				if (this._ExpressionWrapper.Contains("DuplicateModsFoundException"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.Mod重复安装, ModBase.RegexSearch(this._ExpressionWrapper, "(?<=\\n\\t[\\w]+ : [A-Z]{1}:[^\\n]+(/|\\\\))[^/\\\\\\n]+?.jar", RegexOptions.IgnoreCase));
				}
				if (this._ExpressionWrapper.Contains("Found a duplicate mod"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.Mod重复安装, ModBase.RegexSearch(ModBase.RegexSeek(this._ExpressionWrapper, "Found a duplicate mod[^\\n]+", RegexOptions.None) ?? "", "[^\\\\/]+.jar", RegexOptions.IgnoreCase));
				}
				if (this._ExpressionWrapper.Contains("ModResolutionException: Duplicate"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.Mod重复安装, ModBase.RegexSearch(ModBase.RegexSeek(this._ExpressionWrapper, "ModResolutionException: Duplicate[^\\n]+", RegexOptions.None) ?? "", "[^\\\\/]+.jar", RegexOptions.IgnoreCase));
				}
				if ((ModBase.RegexCheck(this._ExpressionWrapper, "^[^\\n.]+.\\w+.[^\\n]+\\n\\[$", RegexOptions.None) || ModBase.RegexCheck(this._ExpressionWrapper, "^\\[[^\\]]+\\] [^\\n.]+.\\w+.[^\\n]+\\n\\[", RegexOptions.None)) && !this._ExpressionWrapper.Contains("at net.") && !this._ExpressionWrapper.Contains("/INFO]") && this.getterWrapper == null && this._ListenerWrapper == null)
				{
					this.AppendReason(CrashAnalyzer.CrashReason.路径包含中文且存在编码问题导致找不到或无法加载主类, null);
				}
				if (this._ExpressionWrapper.Contains("Mixin prepare failed "))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.确定Mod导致游戏崩溃, this.TryAnalyzeModName((ModBase.RegexSeek(this._ExpressionWrapper, "(?<=in )[^. ]+(?=.mixins.json)", RegexOptions.None) ?? "").TrimEnd("\r\n ".ToCharArray())));
				}
				if (this._ExpressionWrapper.Contains("Caught exception from "))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.确定Mod导致游戏崩溃, this.TryAnalyzeModName((ModBase.RegexSeek(this._ExpressionWrapper, "(?<=Caught exception from )[^\\n]+", RegexOptions.None) ?? "").TrimEnd("\r\n ".ToCharArray())));
				}
				if (this._ExpressionWrapper.Contains("Failed to create Mod instance."))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.Mod初始化失败, this.TryAnalyzeModName((ModBase.RegexSeek(this._ExpressionWrapper, "(?<=Failed to create mod instance. ModID: )[^,]+", RegexOptions.None) ?? "").TrimEnd(new char[]
					{
						'\r'
					})));
				}
			}
			if (this.getterWrapper != null)
			{
				if (this.getterWrapper.Contains("The system is out of physical RAM or swap space"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.内存不足, null);
				}
				if (this.getterWrapper.Contains("Out of Memory Error"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.内存不足, null);
				}
				if (this.getterWrapper.Contains("EXCEPTION_ACCESS_VIOLATION"))
				{
					if (this.getterWrapper.Contains("# C  [ig"))
					{
						this.AppendReason(CrashAnalyzer.CrashReason.Intel驱动不兼容导致EXCEPTION_ACCESS_VIOLATION, null);
					}
					if (this.getterWrapper.Contains("# C  [atio"))
					{
						this.AppendReason(CrashAnalyzer.CrashReason.AMD驱动不兼容导致EXCEPTION_ACCESS_VIOLATION, null);
					}
					if (this.getterWrapper.Contains("# C  [nvoglv"))
					{
						this.AppendReason(CrashAnalyzer.CrashReason.Nvidia驱动不兼容导致EXCEPTION_ACCESS_VIOLATION, null);
					}
				}
			}
			if (this._ListenerWrapper != null)
			{
				if (this._ListenerWrapper.Contains("Entity being rendered") && this._ListenerWrapper.Contains("\tEntity's Exact location: "))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.特定实体导致崩溃, ModBase.RegexSeek(this._ListenerWrapper, "(?<=\\tEntity Type: )[^\\n]+(?= \\()", RegexOptions.None) + " (" + (ModBase.RegexSeek(this._ListenerWrapper, "(?<=\\tEntity's Exact location: )[^\\n]+", RegexOptions.None) ?? "").TrimEnd("\r\n".ToCharArray()) + ")");
				}
				if (this._ListenerWrapper.Contains("java.lang.OutOfMemoryError"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.内存不足, null);
				}
				if (this._ListenerWrapper.Contains("Pixel format not accelerated"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.显卡驱动不支持导致无法设置像素格式, null);
				}
				if (this._ListenerWrapper.Contains("Manually triggered debug crash"))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.玩家手动触发调试崩溃, null);
				}
				if (this._ListenerWrapper.Contains("Multiple entries with same key: "))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.确定Mod导致游戏崩溃, this.TryAnalyzeModName((ModBase.RegexSeek(this._ListenerWrapper, "(?<=Multiple entries with same key: )[^=]+", RegexOptions.None) ?? "").TrimEnd("\r\n ".ToCharArray())));
				}
				if (this._ListenerWrapper.Contains("LoaderExceptionModCrash: Caught exception from "))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.确定Mod导致游戏崩溃, this.TryAnalyzeModName((ModBase.RegexSeek(this._ListenerWrapper, "(?<=LoaderExceptionModCrash: Caught exception from )[^\\n]+", RegexOptions.None) ?? "").TrimEnd("\r\n ".ToCharArray())));
				}
				if (this._ListenerWrapper.Contains("Failed loading config file "))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.Mod配置文件导致游戏崩溃, new string[]
					{
						this.TryAnalyzeModName((ModBase.RegexSeek(this._ListenerWrapper, "(?<=Failed loading config file .+ for modid )[^\\n]+", RegexOptions.None) ?? "").TrimEnd(new char[]
						{
							'\r'
						})).First<string>(),
						(ModBase.RegexSeek(this._ListenerWrapper, "(?<=Failed loading config file ).+(?= of type)", RegexOptions.None) ?? "").TrimEnd(new char[]
						{
							'\r'
						})
					});
				}
			}
		}

		// Token: 0x0600030E RID: 782 RVA: 0x0001AA34 File Offset: 0x00018C34
		private void AnalyzeCrit2()
		{
			if (this._ExpressionWrapper != null && this._ExpressionWrapper.Contains("]: Warnings were found!"))
			{
				this.AppendReason(CrashAnalyzer.CrashReason.Fabric报错, (ModBase.RegexSeek(this._ExpressionWrapper, "(?<=\\]: Warnings were found! ?[\\n\\r]+)[\\w\\W]+?(?=[\\n\\r]+\\[)", RegexOptions.None) ?? "").Trim("\r\n".ToCharArray()));
			}
			if (this._ListenerWrapper != null)
			{
				if (this._ListenerWrapper.Contains("\tBlock location: World: "))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.特定方块导致崩溃, ModBase.RegexSeek(this._ListenerWrapper, "(?<=\\tBlock: Block\\{)[^\\}]+", RegexOptions.None) + " " + ModBase.RegexSeek(this._ListenerWrapper, "(?<=\\tBlock location: World: )\\([^\\)]+\\)", RegexOptions.None));
				}
				if (this._ListenerWrapper.Contains("\tEntity's Exact location: "))
				{
					this.AppendReason(CrashAnalyzer.CrashReason.特定实体导致崩溃, ModBase.RegexSeek(this._ListenerWrapper, "(?<=\\tEntity Type: )[^\\n]+(?= \\()", RegexOptions.None) + " (" + (ModBase.RegexSeek(this._ListenerWrapper, "(?<=\\tEntity's Exact location: )[^\\n]+", RegexOptions.None) ?? "").TrimEnd("\r\n".ToCharArray()) + ")");
				}
			}
		}

		// Token: 0x0600030F RID: 783 RVA: 0x0001AB40 File Offset: 0x00018D40
		private List<string> AnalyzeStackKeyword(string ErrorStack)
		{
			List<string> list = ModBase.RegexSearch(ErrorStack + "\r\n", "(?<=\\n[^{]+)[a-zA-Z]+\\w+\\.[a-zA-Z]+[\\w\\.]+(?=\\.[\\w\\.$]+\\.)", RegexOptions.None);
			List<string> list2 = new List<string>();
			try
			{
				List<string>.Enumerator enumerator = list.GetEnumerator();
				IL_FE:
				while (enumerator.MoveNext())
				{
					string text = enumerator.Current;
					foreach (string value in new string[]
					{
						"java",
						"sun",
						"javax",
						"jdk",
						"org.lwjgl",
						"com.sun",
						"net.minecraftforge",
						"com.mojang",
						"net.minecraft",
						"cpw.mods",
						"com.google",
						"org.apache",
						"org.spongepowered",
						"net.fabricmc",
						"com.mumfrey",
						"com.electronwill.nightconfig",
						"MojangTricksIntelDriversForPerformance_javaw"
					})
					{
						if (text.StartsWith(value))
						{
							goto IL_FE;
						}
					}
					list2.Add(text.Trim());
				}
			}
			finally
			{
				List<string>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			list2 = ModBase.ArrayNoDouble<string>(list2, null);
			ModBase.Log("[Crash] 找到 " + Conversions.ToString(list2.Count) + " 条可能的堆栈信息", ModBase.LogLevel.Normal, "出现错误");
			checked
			{
				List<string> result;
				if (list2.Count == 0)
				{
					result = new List<string>();
				}
				else
				{
					try
					{
						foreach (string str in list2)
						{
							ModBase.Log("[Crash]  - " + str, ModBase.LogLevel.Normal, "出现错误");
						}
					}
					finally
					{
						List<string>.Enumerator enumerator2;
						((IDisposable)enumerator2).Dispose();
					}
					List<string> list3 = new List<string>();
					try
					{
						foreach (string text2 in list2)
						{
							string[] array2 = text2.Split(new char[]
							{
								'.'
							});
							int num = Math.Min(3, array2.Count<string>() - 1);
							for (int j = 0; j <= num; j++)
							{
								string text3 = array2[j];
								if (text3.Length > 2 && !text3.StartsWith("func_") && !new string[]
								{
									"com",
									"org",
									"net",
									"asm",
									"fml",
									"mod",
									"jar",
									"sun",
									"lib",
									"map",
									"gui",
									"dev",
									"nio",
									"api",
									"core",
									"init",
									"mods",
									"main",
									"file",
									"game",
									"load",
									"read",
									"done",
									"util",
									"tile",
									"item",
									"forge",
									"setup",
									"block",
									"model",
									"mixin",
									"event",
									"common",
									"server",
									"config",
									"loader",
									"launch",
									"entity",
									"assist",
									"client",
									"modapi",
									"mojang",
									"shader",
									"events",
									"github",
									"preinit",
									"preload",
									"machine",
									"reflect",
									"channel",
									"general",
									"optifine",
									"minecraft",
									"transformers",
									"universal",
									"internal"
								}.Contains(text3.ToLower()))
								{
									list3.Add(text3.Trim());
								}
							}
						}
					}
					finally
					{
						List<string>.Enumerator enumerator3;
						((IDisposable)enumerator3).Dispose();
					}
					list3 = ModBase.ArrayNoDouble<string>(list3, null);
					ModBase.Log("[Crash] 从堆栈信息中找到 " + Conversions.ToString(list3.Count) + " 个可能的 Mod ID 关键词", ModBase.LogLevel.Normal, "出现错误");
					if (list3.Count > 0)
					{
						ModBase.Log("[Crash]  - " + ModBase.Join(list3, ", "), ModBase.LogLevel.Normal, "出现错误");
					}
					if (list3.Count > 10)
					{
						ModBase.Log("[Crash] 关键词过多，考虑匹配出错，不纳入考虑", ModBase.LogLevel.Normal, "出现错误");
						result = new List<string>();
					}
					else
					{
						result = list3;
					}
				}
				return result;
			}
		}

		// Token: 0x06000310 RID: 784 RVA: 0x0001B058 File Offset: 0x00019258
		private List<string> AnalyzeModName(List<string> Keywords)
		{
			List<string> list = new List<string>();
			List<string> list2 = new List<string>();
			try
			{
				foreach (string text in Keywords)
				{
					foreach (string text2 in text.Split(new char[]
					{
						'('
					}))
					{
						list2.Add(text2.Trim(" )".ToCharArray()));
					}
				}
			}
			finally
			{
				List<string>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			Keywords = list2;
			List<string> result;
			if (this._ListenerWrapper == null)
			{
				result = null;
			}
			else if (!this._ListenerWrapper.Contains("A detailed walkthrough of the error"))
			{
				result = null;
			}
			else
			{
				string text3 = this._ListenerWrapper.Replace("A detailed walkthrough of the error", "¨");
				bool flag;
				if (flag = text3.Contains("Fabric Mods"))
				{
					text3 = text3.Replace("Fabric Mods", "¨");
					ModBase.Log("[Crash] 检测到 Fabric Mod 信息格式", ModBase.LogLevel.Normal, "出现错误");
				}
				text3 = text3.Split(new char[]
				{
					'¨'
				}).Last<string>();
				List<string> list3 = new List<string>();
				foreach (string text4 in text3.Replace("\r\n", "\r").Split(new char[]
				{
					'\r'
				}))
				{
					if (text4.ToLower().Contains(".jar") || (flag && text4.StartsWith("\t\t") && !ModBase.RegexCheck(text4, "\\t\\tfabric[\\w-]*: Fabric", RegexOptions.None)))
					{
						list3.Add(text4);
					}
				}
				ModBase.Log("[Crash] 找到 " + Conversions.ToString(list3.Count) + " 个可能的 Mod 项目行", ModBase.LogLevel.Normal, "出现错误");
				List<string> list4 = new List<string>();
				try
				{
					foreach (string text5 in Keywords)
					{
						try
						{
							foreach (string text6 in list3)
							{
								string text7 = text6.ToLower().Replace("_", "");
								if (text7.Contains(text5.ToLower().Replace("_", "")) && !text7.Contains("minecraft.jar") && !text7.Contains(" forge-"))
								{
									list4.Add(text6.Trim("\r\n".ToCharArray()));
									break;
								}
							}
						}
						finally
						{
							List<string>.Enumerator enumerator3;
							((IDisposable)enumerator3).Dispose();
						}
					}
				}
				finally
				{
					List<string>.Enumerator enumerator2;
					((IDisposable)enumerator2).Dispose();
				}
				list4 = ModBase.ArrayNoDouble<string>(list4, null);
				ModBase.Log("[Crash] 找到 " + Conversions.ToString(list4.Count) + " 个可能的崩溃 Mod 匹配行", ModBase.LogLevel.Normal, "出现错误");
				try
				{
					foreach (string str in list4)
					{
						ModBase.Log("[Crash]  - " + str, ModBase.LogLevel.Normal, "出现错误");
					}
				}
				finally
				{
					List<string>.Enumerator enumerator4;
					((IDisposable)enumerator4).Dispose();
				}
				try
				{
					foreach (string str2 in list4)
					{
						string text8;
						if (flag)
						{
							text8 = ModBase.RegexSeek(str2, "(?<=: )[^\\n]+(?= [^\\n]+)", RegexOptions.None);
						}
						else
						{
							text8 = ModBase.RegexSeek(str2, "(?<=\\()[^\\t]+.jar(?=\\))|(?<=(\\t\\t)|(\\| ))[^\\t\\|]+.jar", RegexOptions.IgnoreCase);
						}
						if (text8 != null)
						{
							list.Add(text8);
						}
					}
				}
				finally
				{
					List<string>.Enumerator enumerator5;
					((IDisposable)enumerator5).Dispose();
				}
				list = ModBase.ArrayNoDouble<string>(list, null);
				ModBase.Log("[Crash] 找到 " + Conversions.ToString(list.Count) + " 个可能的崩溃 Mod 文件名", ModBase.LogLevel.Normal, "出现错误");
				try
				{
					foreach (string str3 in list)
					{
						ModBase.Log("[Crash]  - " + str3, ModBase.LogLevel.Normal, "出现错误");
					}
				}
				finally
				{
					List<string>.Enumerator enumerator6;
					((IDisposable)enumerator6).Dispose();
				}
				result = ((list.Count == 0) ? null : list);
			}
			return result;
		}

		// Token: 0x06000311 RID: 785 RVA: 0x0001B480 File Offset: 0x00019680
		private List<string> TryAnalyzeModName(string Keywords)
		{
			List<string> list = new List<string>
			{
				Keywords
			};
			List<string> result;
			if (string.IsNullOrEmpty(Keywords))
			{
				result = list;
			}
			else
			{
				result = (this.AnalyzeModName(list) ?? list);
			}
			return result;
		}

		// Token: 0x06000312 RID: 786 RVA: 0x0001B4B4 File Offset: 0x000196B4
		public void Output(bool IsHandAnalyze, List<string> ExtraFiles = null)
		{
			ModMain.m_CollectionAccount.ShowWindowToTop();
			int num = ModMain.MyMsgBox(this.GetAnalyzeResult(IsHandAnalyze), IsHandAnalyze ? "错误报告分析结果" : "Minecraft 出现错误", "确定", IsHandAnalyze ? "" : "导出错误报告", "", false, true, false);
			if (num == 2)
			{
				CrashAnalyzer._Closure$__26-0 CS$<>8__locals1 = new CrashAnalyzer._Closure$__26-0(CS$<>8__locals1);
				CS$<>8__locals1.$VB$Local_FileAddress = null;
				try
				{
					ModBase.RunInUiWait(delegate
					{
						CS$<>8__locals1.$VB$Local_FileAddress = ModBase.SelectAs("选择保存位置", "错误报告-" + DateTime.Now.ToString("G").Replace("/", "-").Replace(":", ".").Replace(" ", "_") + ".zip", "Minecraft 错误报告(*.zip)|*.zip", null);
					});
					if (string.IsNullOrEmpty(CS$<>8__locals1.$VB$Local_FileAddress))
					{
						return;
					}
					if (File.Exists(CS$<>8__locals1.$VB$Local_FileAddress))
					{
						File.Delete(CS$<>8__locals1.$VB$Local_FileAddress);
					}
					ModBase.FeedbackInfo();
					ModBase.LogFlush();
					if (ExtraFiles != null)
					{
						this._CreatorWrapper.AddRange(ExtraFiles);
					}
					try
					{
						foreach (string text in this._CreatorWrapper)
						{
							try
							{
								string text2 = ModBase.GetFileNameFromPath(text);
								string left = text2;
								if (Operators.CompareString(left, "LatestLaunch.bat", true) == 0)
								{
									text2 = "启动脚本.bat";
								}
								else if (Operators.CompareString(left, "Log1.txt", true) == 0)
								{
									text2 = "PCL2 启动器日志.txt";
								}
								else if (Operators.CompareString(left, "RawOutput.log", true) == 0)
								{
									text2 = "游戏崩溃前的输出.txt";
								}
								File.Copy(text, this._IndexerWrapper + "Report\\" + text2, true);
							}
							catch (Exception ex)
							{
								ModBase.Log(ex, "复制错误报告文件失败（" + text + "）", ModBase.LogLevel.Debug, "出现错误");
							}
						}
					}
					finally
					{
						List<string>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
					ZipFile.CreateFromDirectory(this._IndexerWrapper + "Report\\", CS$<>8__locals1.$VB$Local_FileAddress);
					ModBase.DeleteDirectory(this._IndexerWrapper + "Report\\", false);
					ModMain.Hint("错误报告已导出！", ModMain.HintType.Finish, true);
				}
				catch (Exception ex2)
				{
					ModBase.Log(ex2, "导出错误报告失败", ModBase.LogLevel.Feedback, "出现错误");
					return;
				}
				try
				{
					Process.Start("explorer", "/select," + CS$<>8__locals1.$VB$Local_FileAddress);
				}
				catch (Exception ex3)
				{
					ModBase.Log(ex3, "打开错误报告的存放文件夹失败", ModBase.LogLevel.Debug, "出现错误");
				}
			}
		}

		// Token: 0x06000313 RID: 787 RVA: 0x0001B740 File Offset: 0x00019940
		private string GetAnalyzeResult(bool IsHandAnalyze)
		{
			string result;
			if (this.instanceWrapper.Count == 0)
			{
				if (IsHandAnalyze)
				{
					result = "很抱歉，PCL2 无法确定错误原因。";
				}
				else
				{
					result = "很抱歉，你的游戏出现了一些问题……\r\n如果要寻求帮助，请向他人发送错误报告文件，而不是发送这个窗口的截图。\r\n你也可以查看错误报告，其中可能会有出错的原因。";
				}
			}
			else
			{
				if (this.instanceWrapper.Count >= 2)
				{
					ModMain.Hint("错误分析时发现数个可能的原因，窗口中仅显示了第一条，你可以在启动器日志中检查更多可能的原因！", ModMain.HintType.Finish, true);
				}
				List<string> value = this.instanceWrapper.First<KeyValuePair<CrashAnalyzer.CrashReason, List<string>>>().Value;
				string text;
				switch (this.instanceWrapper.First<KeyValuePair<CrashAnalyzer.CrashReason, List<string>>>().Key)
				{
				case CrashAnalyzer.CrashReason.Mod文件被解压:
					text = "由于 Mod 文件被解压了，导致游戏无法继续运行。\\n直接把整个 Mod 文件放进 Mod 文件夹中即可，若解压就会导致游戏出错。\\n\\n请删除 Mod 文件夹中已被解压的 Mod，然后再启动游戏。";
					break;
				case CrashAnalyzer.CrashReason.内存不足:
					text = "Minecraft 内存不足，导致其无法继续运行。\\n这很可能是由于你为游戏分配的内存不足，或是游戏的配置要求过高。\\n\\n你可以在启动设置中增加为游戏分配的内存，删除配置要求较高的材质、Mod、光影。\\n如果这依然不奏效，请在开始游戏前尽量关闭其他软件，或者……换台电脑？\\h";
					break;
				case CrashAnalyzer.CrashReason.使用JDK:
					text = "游戏似乎因为使用 JDK，或 Java 版本过高而崩溃了。\\n请在启动设置的 Java 选择一项中改用 JRE 8（Java 8），然后再启动游戏。\\n如果你没有安装 JRE 8，你可以从网络中下载、安装一个。";
					break;
				case CrashAnalyzer.CrashReason.显卡不支持OpenGL:
				case CrashAnalyzer.CrashReason.显卡驱动不支持导致无法设置像素格式:
				case CrashAnalyzer.CrashReason.Intel驱动不兼容导致EXCEPTION_ACCESS_VIOLATION:
				case CrashAnalyzer.CrashReason.AMD驱动不兼容导致EXCEPTION_ACCESS_VIOLATION:
				case CrashAnalyzer.CrashReason.Nvidia驱动不兼容导致EXCEPTION_ACCESS_VIOLATION:
					if (this.identifierWrapper.Contains("hd graphics "))
					{
						text = "你的显卡驱动存在问题，或未使用独立显卡，导致游戏无法正常运行。\\n\\n如果你的电脑存在独立显卡，请使用独立显卡而非 Intel 核显启动 PCL2 与 Minecraft。\\n如果问题依然存在，请尝试升级你的显卡驱动到最新版本，或回退到出厂版本。\\h";
					}
					else
					{
						text = "你的显卡驱动存在问题，导致游戏无法正常运行。\\n\\n请尝试升级你的显卡驱动到最新版本，或回退到出厂版本，然后再启动游戏。\\n如果问题依然存在，那么你可能需要换个更好的显卡……\\h";
					}
					break;
				case CrashAnalyzer.CrashReason.使用OpenJ9:
					text = "游戏因为使用 Open J9 而崩溃了。\\n请在启动设置的 Java 选择一项中改用非 OpenJ9 的 Java 8，然后再启动游戏。\\n如果你没有安装 JRE 8，你可以从网络中下载、安装一个。";
					break;
				case CrashAnalyzer.CrashReason.Java版本过高:
					text = "游戏似乎因为你所使用的 Java 版本过高而崩溃了。\\n请在启动设置的 Java 选择一项中改用 JRE 8（Java 8），然后再启动游戏。\\n如果你没有安装 JRE 8，你可以从网络中下载、安装一个。";
					break;
				case CrashAnalyzer.CrashReason.Java版本过低:
					text = "游戏因为你所使用的 Java 版本过低而崩溃了。\\n请在启动设置的 Java 选择一项中改用适宜版本的 Java，然后再启动游戏。";
					break;
				case CrashAnalyzer.CrashReason.路径包含中文且存在编码问题导致找不到或无法加载主类:
					text = "由于游戏路径含有中文字符，且 Java 或系统编码存在错误，导致游戏无法运行。\\n\\n解决这一问题的最简单方法是检查游戏的完整路径，并删除各个文件夹名中的中文字符。\\n这包括了游戏的版本名、它所处的 .minecraft 文件夹及其之前的文件夹名。\\h";
					break;
				case CrashAnalyzer.CrashReason.玩家手动触发调试崩溃:
					text = "* 事实上，你的游戏没有任何问题，这是你自己触发的崩溃。\\n* 你难道没有更重要的事要做吗？";
					break;
				case CrashAnalyzer.CrashReason.光影或资源包导致OpenGL1282错误:
					text = "你所使用的光影或材质导致游戏出现了一些问题……\\n\\n请尝试删除你所添加的这些额外资源。\\h";
					break;
				case CrashAnalyzer.CrashReason.文件或内容校验失败:
					text = "部分文件或内容校验失败，导致游戏出现了问题。\\n\\n请尝试删除游戏（包括 Mod）并重新下载，或尝试在重新下载时使用 VPN。\\h";
					break;
				case CrashAnalyzer.CrashReason.确定Mod导致游戏崩溃:
					if (value.Count == 1)
					{
						text = "名称或 ID 为 " + value.First<string>() + " 的 Mod 导致了游戏出错。\\n\\e\\h";
					}
					else
					{
						text = "以下 Mod 导致了游戏出错：\\n - " + ModBase.Join(value, "\\n - ") + "\\n\\e\\h";
					}
					break;
				case CrashAnalyzer.CrashReason.Mod配置文件导致游戏崩溃:
					if (value[1] == null)
					{
						text = "名称或 ID 为 " + value.First<string>() + " 的 Mod 导致了游戏出错。\\n\\e\\h";
					}
					else
					{
						text = string.Concat(new string[]
						{
							"名称或 ID 为 ",
							value.First<string>(),
							" 的 Mod 导致了游戏出错：\\n其配置文件 ",
							value[1],
							" 存在异常，无法读取。"
						});
					}
					break;
				case CrashAnalyzer.CrashReason.Mod初始化失败:
					if (value.Count == 1)
					{
						text = "名为 " + value.First<string>() + " 的 Mod 初始化失败，导致游戏无法继续加载。\\n\\e\\h";
					}
					else
					{
						text = "以下 Mod 初始化失败，导致游戏无法继续加载：\\n - " + ModBase.Join(value, "\\n - ") + "\\n\\e\\h";
					}
					break;
				case CrashAnalyzer.CrashReason.崩溃日志堆栈分析发现关键字:
				case CrashAnalyzer.CrashReason.MC日志堆栈分析发现关键字:
					if (value.Count == 1)
					{
						text = "你的游戏遇到了一些问题，这可能是某些 Mod 所引起的，PCL2 找到了一个可疑的关键词：" + value.First<string>() + "。\\n\\n如果你知道它对应的 Mod，那么有可能就是它引起的错误，你也可以查看错误报告获取详情。\\h";
					}
					else
					{
						text = "你的游戏遇到了一些问题，这可能是某些 Mod 所引起的，PCL2 找到了以下可疑的关键词：\\n - " + ModBase.Join(value, ", ") + "\\n\\n如果你知道这些关键词对应的 Mod，那么有可能就是它引起的错误，你也可以查看错误报告获取详情。\\h";
					}
					break;
				case CrashAnalyzer.CrashReason.崩溃日志堆栈分析发现Mod名称:
					if (value.Count == 1)
					{
						text = "名为 " + value.First<string>() + " 的 Mod 可能导致了游戏出错。\\n\\e\\h";
					}
					else
					{
						text = "可能是以下 Mod 导致了游戏出错：\\n - " + ModBase.Join(value, "\\n - ") + "\\n\\e\\h";
					}
					break;
				case CrashAnalyzer.CrashReason.OptiFine导致无法加载世界:
					text = "你所使用的 OptiFine 可能导致了你的游戏出现问题。\\n\\n该问题只在特定 OptiFine 版本中出现，你可以尝试更换 OptiFine 的版本。\\h";
					break;
				case CrashAnalyzer.CrashReason.特定方块导致崩溃:
					if (value.Count == 1)
					{
						text = "游戏似乎因为方块 " + value.First<string>() + " 出现了问题。\\n\\n你可以创建一个新世界，并观察游戏的运行情况：\\n - 若正常运行，则是该方块导致出错，你或许需要使用一些方式删除此方块。\\n - 若仍然出错，问题就可能来自其他原因……\\h";
					}
					else
					{
						text = "游戏似乎因为世界中的某些方块出现了问题。\\n\\n你可以创建一个新世界，并观察游戏的运行情况：\\n - 若正常运行，则是某些方块导致出错，你或许需要删除该世界。\\n - 若仍然出错，问题就可能来自其他原因……\\h";
					}
					break;
				case CrashAnalyzer.CrashReason.特定实体导致崩溃:
					if (value.Count == 1)
					{
						text = "游戏似乎因为实体 " + value.First<string>() + " 出现了问题。\\n\\n你可以创建一个新世界，并生成一个该实体，然后观察游戏的运行情况：\\n - 若正常运行，则是该实体导致出错，你或许需要使用一些方式删除此实体。\\n - 若仍然出错，问题就可能来自其他原因……\\h";
					}
					else
					{
						text = "游戏似乎因为世界中的某些实体出现了问题。\\n\\n你可以创建一个新世界，并生成各种实体，观察游戏的运行情况：\\n - 若正常运行，则是某些实体导致出错，你或许需要删除该世界。\\n - 若仍然出错，问题就可能来自其他原因……\\h";
					}
					break;
				case CrashAnalyzer.CrashReason.材质过大或显卡配置不足:
					text = "你所使用的材质分辨率过高，或显卡配置不足，导致游戏无法继续运行。\\n\\n如果你正在使用高清材质，请将它移除。\\n如果你没有使用材质，那么你可能需要更新显卡驱动，或者换个更好的显卡……\\h";
					break;
				case CrashAnalyzer.CrashReason.没有可用的分析文件:
					text = "你的游戏出现了一些问题，但 PCL2 未能找到相关记录文件，因此无法进行分析。\\h";
					break;
				case CrashAnalyzer.CrashReason.使用32位Java导致JVM无法分配足够多的内存:
					if (Environment.Is64BitOperatingSystem)
					{
						text = "你似乎正在使用 32 位 Java，这会导致 Minecraft 无法使用 1GB 以上的内存，进而造成崩溃。\\n\\n请在启动设置的 Java 选择一项中改用 64 位的 Java 再启动游戏，然后再启动游戏。\\n如果你没有安装 64 位的 Java，你可以从网络中下载、安装一个。";
					}
					else
					{
						text = "你正在使用 32 位的操作系统，这会导致 Minecraft 无法使用 1GB 以上的内存，进而造成崩溃。\\n\\n你或许只能重装 64 位的操作系统来解决此问题。\\n如果你的电脑内存在 2GB 以内，那或许只能换台电脑了……\\h";
					}
					break;
				case CrashAnalyzer.CrashReason.Mod重复安装:
					if (value.Count >= 2)
					{
						text = "你重复安装了多个相同的 Mod：\\n - " + ModBase.Join(value, "\\n - ") + "\\n\\n每个 Mod 只能出现一次，请删除重复的 Mod，然后再启动游戏。";
					}
					else
					{
						text = "你可能重复安装了多个相同的 Mod，导致游戏无法继续加载。\\n\\n每个 Mod 只能出现一次，请删除重复的 Mod，然后再启动游戏。\\e\\h";
					}
					break;
				case CrashAnalyzer.CrashReason.Fabric报错:
					if (value.Count == 1)
					{
						text = "Fabric 提供了以下错误信息：\\n" + value.First<string>() + "\\n\\n请根据上述信息进行对应处理，如果看不懂英文可以使用翻译软件。";
					}
					else
					{
						text = "Fabric 可能已经提供了报错信息，请根据信息进行对应处理，如果看不懂英文可以使用翻译软件。\\n如果没有看到报错信息，可以查看错误报告了解错误具体是如何发生的。\\h";
					}
					break;
				case CrashAnalyzer.CrashReason.Forge报错:
					if (value.Count == 1)
					{
						text = "Forge 提供了以下错误信息：\\n" + value.First<string>() + "\\n\\n请根据上述信息进行对应处理，如果看不懂英文可以使用翻译软件。";
					}
					else
					{
						text = "Forge 可能已经提供了报错信息，请根据信息进行对应处理，如果看不懂英文可以使用翻译软件。\\n如果没有看到报错信息，可以查看错误报告了解错误具体是如何发生的。\\h";
					}
					break;
				default:
					text = "PCL2 获取到了没有详细信息的错误原因（" + Conversions.ToString((int)this.instanceWrapper.First<KeyValuePair<CrashAnalyzer.CrashReason, List<string>>>().Key) + "），请向 PCL2 作者提交反馈以获取详情。\\h";
					break;
				}
				text = text.Replace("\\n", "\r\n").Replace("\\h", IsHandAnalyze ? "" : "\r\n如果要寻求帮助，请向他人发送错误报告文件，而不是发送这个窗口的截图。").Replace("\\e", IsHandAnalyze ? "" : "\r\n你可以查看错误报告了解错误具体是如何发生的。");
				result = text.Trim("\r\n".ToCharArray());
			}
			return result;
		}

		// Token: 0x0400013F RID: 319
		private static bool m_BridgeWrapper = false;

		// Token: 0x04000140 RID: 320
		private static object _StructWrapper = RuntimeHelpers.GetObjectValue(new object());

		// Token: 0x04000141 RID: 321
		private string _IndexerWrapper;

		// Token: 0x04000142 RID: 322
		private List<KeyValuePair<string, string[]>> templateWrapper;

		// Token: 0x04000143 RID: 323
		private string _ExpressionWrapper;

		// Token: 0x04000144 RID: 324
		private string getterWrapper;

		// Token: 0x04000145 RID: 325
		private string _ListenerWrapper;

		// Token: 0x04000146 RID: 326
		private string identifierWrapper;

		// Token: 0x04000147 RID: 327
		private Dictionary<CrashAnalyzer.CrashReason, List<string>> instanceWrapper;

		// Token: 0x04000148 RID: 328
		private List<string> _CreatorWrapper;

		// Token: 0x02000064 RID: 100
		private enum AnalyzeFileType
		{
			// Token: 0x0400014A RID: 330
			HsErr,
			// Token: 0x0400014B RID: 331
			MinecraftLog,
			// Token: 0x0400014C RID: 332
			ExtraLog,
			// Token: 0x0400014D RID: 333
			CrashReport
		}

		// Token: 0x02000065 RID: 101
		private enum CrashReason
		{
			// Token: 0x0400014F RID: 335
			Mod文件被解压,
			// Token: 0x04000150 RID: 336
			内存不足,
			// Token: 0x04000151 RID: 337
			使用JDK,
			// Token: 0x04000152 RID: 338
			显卡不支持OpenGL,
			// Token: 0x04000153 RID: 339
			使用OpenJ9,
			// Token: 0x04000154 RID: 340
			Java版本过高,
			// Token: 0x04000155 RID: 341
			Java版本过低,
			// Token: 0x04000156 RID: 342
			显卡驱动不支持导致无法设置像素格式,
			// Token: 0x04000157 RID: 343
			路径包含中文且存在编码问题导致找不到或无法加载主类,
			// Token: 0x04000158 RID: 344
			Intel驱动不兼容导致EXCEPTION_ACCESS_VIOLATION,
			// Token: 0x04000159 RID: 345
			AMD驱动不兼容导致EXCEPTION_ACCESS_VIOLATION,
			// Token: 0x0400015A RID: 346
			Nvidia驱动不兼容导致EXCEPTION_ACCESS_VIOLATION,
			// Token: 0x0400015B RID: 347
			玩家手动触发调试崩溃,
			// Token: 0x0400015C RID: 348
			光影或资源包导致OpenGL1282错误,
			// Token: 0x0400015D RID: 349
			文件或内容校验失败,
			// Token: 0x0400015E RID: 350
			确定Mod导致游戏崩溃,
			// Token: 0x0400015F RID: 351
			Mod配置文件导致游戏崩溃,
			// Token: 0x04000160 RID: 352
			Mod初始化失败,
			// Token: 0x04000161 RID: 353
			崩溃日志堆栈分析发现关键字,
			// Token: 0x04000162 RID: 354
			崩溃日志堆栈分析发现Mod名称,
			// Token: 0x04000163 RID: 355
			MC日志堆栈分析发现关键字,
			// Token: 0x04000164 RID: 356
			OptiFine导致无法加载世界,
			// Token: 0x04000165 RID: 357
			特定方块导致崩溃,
			// Token: 0x04000166 RID: 358
			特定实体导致崩溃,
			// Token: 0x04000167 RID: 359
			材质过大或显卡配置不足,
			// Token: 0x04000168 RID: 360
			没有可用的分析文件,
			// Token: 0x04000169 RID: 361
			使用32位Java导致JVM无法分配足够多的内存,
			// Token: 0x0400016A RID: 362
			Mod重复安装,
			// Token: 0x0400016B RID: 363
			Fabric报错,
			// Token: 0x0400016C RID: 364
			Forge报错
		}
	}
}
