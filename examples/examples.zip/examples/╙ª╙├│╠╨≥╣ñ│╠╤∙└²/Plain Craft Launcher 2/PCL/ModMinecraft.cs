﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Controls;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PCL.My;

namespace PCL
{
	// Token: 0x0200010F RID: 271
	[StandardModule]
	public sealed class ModMinecraft
	{
		// Token: 0x060009E6 RID: 2534 RVA: 0x0004B54C File Offset: 0x0004974C
		public static void JavaListInit()
		{
			ModMinecraft._RegTag = new List<ModMinecraft.JavaEntry>();
			try
			{
				if (Operators.ConditionalCompareObjectLess(ModBase._ParamsState.Get("CacheJavaListVersion", null), ModMinecraft.m_ObjectTag, true))
				{
					ModBase.Log("[Java] 要求 Java 列表缓存更新", ModBase.LogLevel.Normal, "出现错误");
					ModBase._ParamsState.Set("CacheJavaListVersion", ModMinecraft.m_ObjectTag, false, null);
				}
				else
				{
					try
					{
						foreach (object obj in ((IEnumerable)ModBase.GetJson(Conversions.ToString(ModBase._ParamsState.Get("LaunchArgumentJavaAll", null)))))
						{
							object objectValue = RuntimeHelpers.GetObjectValue(obj);
							ModMinecraft._RegTag.Add(ModMinecraft.JavaEntry.FromJson((JObject)objectValue));
						}
					}
					finally
					{
						IEnumerator enumerator;
						if (enumerator is IDisposable)
						{
							(enumerator as IDisposable).Dispose();
						}
					}
				}
				if (ModMinecraft._RegTag.Count == 0)
				{
					ModBase.Log("[Java] 初始化未找到可用的 Java，将自动触发搜索", ModBase.LogLevel.Developer, "出现错误");
					ModMinecraft.composerTag.Start(0, false);
				}
				else
				{
					ModBase.Log("[Java] 缓存中有 " + Conversions.ToString(ModMinecraft._RegTag.Count) + " 个可用的 Java", ModBase.LogLevel.Normal, "出现错误");
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "初始化 Java 列表失败", ModBase.LogLevel.Feedback, "出现错误");
				ModBase._ParamsState.Set("LaunchArgumentJavaAll", "[]", false, null);
			}
		}

		// Token: 0x060009E7 RID: 2535 RVA: 0x00006CF8 File Offset: 0x00004EF8
		private static string RevertRepository()
		{
			if (ModMinecraft._InvocationTag == null)
			{
				ModMinecraft._InvocationTag = Environment.GetEnvironmentVariable("Path");
			}
			return ModMinecraft._InvocationTag;
		}

		// Token: 0x060009E8 RID: 2536 RVA: 0x0004B6DC File Offset: 0x000498DC
		private static void JavaSearchLoaderSub(ModLoader.LoaderTask<int, int> Loader)
		{
			if (ModMain.m_MerchantAccount != null)
			{
				ModBase.RunInUiWait((ModMinecraft._Closure$__.$I9-0 == null) ? (ModMinecraft._Closure$__.$I9-0 = delegate()
				{
					ModMain.m_MerchantAccount.ComboArgumentJava.Items.Clear();
					ModMain.m_MerchantAccount.ComboArgumentJava.Items.Add(new ComboBoxItem
					{
						Content = "加载中……",
						IsSelected = true
					});
				}) : ModMinecraft._Closure$__.$I9-0);
			}
			if (ModMain._ProcAccount != null)
			{
				ModBase.RunInUiWait((ModMinecraft._Closure$__.$I9-1 == null) ? (ModMinecraft._Closure$__.$I9-1 = delegate()
				{
					ModMain._ProcAccount.ComboArgumentJava.Items.Clear();
					ModMain._ProcAccount.ComboArgumentJava.Items.Add(new ComboBoxItem
					{
						Content = "加载中……",
						IsSelected = true
					});
				}) : ModMinecraft._Closure$__.$I9-1);
			}
			checked
			{
				try
				{
					Dictionary<string, bool> dictionary = new Dictionary<string, bool>();
					foreach (string text in Strings.Split(ModMinecraft.RevertRepository().Replace("\\\\", "\\").Replace("/", "\\"), ";", -1, CompareMethod.Text))
					{
						text = text.Trim(" \"".ToCharArray());
						if (!text.EndsWith("\\"))
						{
							text += "\\";
						}
						if (File.Exists(text + "javaw.exe"))
						{
							ModBase.DictionaryAdd<string, bool>(ref dictionary, text, false);
						}
					}
					DriveInfo[] drives = DriveInfo.GetDrives();
					for (int j = 0; j < drives.Length; j++)
					{
						ModMinecraft.JavaSearchFolder(drives[j].Name, ref dictionary, false, false);
					}
					ModMinecraft.JavaSearchFolder(ModMinecraft._ItemTag, ref dictionary, false, false);
					ModMinecraft.JavaSearchFolder(ModBase.Path, ref dictionary, false, true);
					if (!string.IsNullOrWhiteSpace(ModMinecraft._MapperTag) && Operators.CompareString(ModBase.Path, ModMinecraft._MapperTag, true) != 0)
					{
						ModMinecraft.JavaSearchFolder(ModMinecraft._MapperTag, ref dictionary, false, true);
					}
					Dictionary<string, bool> dictionary2 = new Dictionary<string, bool>();
					try
					{
						Dictionary<string, bool>.Enumerator enumerator = dictionary.GetEnumerator();
						IL_25F:
						while (enumerator.MoveNext())
						{
							KeyValuePair<string, bool> keyValuePair = enumerator.Current;
							string text2 = keyValuePair.Key.Replace("\\\\", "\\").Replace("/", "\\");
							FileSystemInfo fileSystemInfo = new FileInfo(text2 + "javaw.exe");
							while (!fileSystemInfo.Attributes.HasFlag(FileAttributes.ReparsePoint))
							{
								fileSystemInfo = ((fileSystemInfo is FileInfo) ? ((FileInfo)fileSystemInfo).Directory : ((DirectoryInfo)fileSystemInfo).Parent);
								if (fileSystemInfo == null)
								{
									ModBase.Log("[Java] 位于 " + text2 + " 的 Java 不含符号链接", ModBase.LogLevel.Normal, "出现错误");
									dictionary2.Add(keyValuePair.Key, keyValuePair.Value);
									goto IL_25F;
								}
							}
							ModBase.Log("[Java] 位于 " + text2 + " 的 Java 包含符号链接", ModBase.LogLevel.Normal, "出现错误");
						}
					}
					finally
					{
						Dictionary<string, bool>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
					if (dictionary2.Count > 0)
					{
						dictionary = dictionary2;
					}
					Dictionary<string, bool> dictionary3 = new Dictionary<string, bool>();
					try
					{
						foreach (KeyValuePair<string, bool> keyValuePair2 in dictionary)
						{
							if (keyValuePair2.Key.Contains("javapath_target_"))
							{
								ModBase.Log("[Java] 位于 " + keyValuePair2.Key + " 的 Java 包含二重引用", ModBase.LogLevel.Normal, "出现错误");
							}
							else
							{
								ModBase.Log("[Java] 位于 " + keyValuePair2.Key + " 的 Java 不含二重引用", ModBase.LogLevel.Normal, "出现错误");
								dictionary3.Add(keyValuePair2.Key, keyValuePair2.Value);
							}
						}
					}
					finally
					{
						Dictionary<string, bool>.Enumerator enumerator2;
						((IDisposable)enumerator2).Dispose();
					}
					if (dictionary3.Count > 0)
					{
						dictionary = dictionary3;
					}
					string data = Conversions.ToString(ModBase._ParamsState.Get("LaunchArgumentJavaAll", null));
					try
					{
						try
						{
							foreach (object obj in ((IEnumerable)ModBase.GetJson(data)))
							{
								ModMinecraft.JavaEntry javaEntry = ModMinecraft.JavaEntry.FromJson((JObject)RuntimeHelpers.GetObjectValue(obj));
								if (javaEntry._MethodProccesor)
								{
									ModBase.DictionaryAdd<string, bool>(ref dictionary, javaEntry.m_ListProccesor, true);
								}
							}
						}
						finally
						{
							IEnumerator enumerator3;
							if (enumerator3 is IDisposable)
							{
								(enumerator3 as IDisposable).Dispose();
							}
						}
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "Java 列表已损坏", ModBase.LogLevel.Feedback, "出现错误");
						ModBase._ParamsState.Set("LaunchArgumentJavaAll", "[]", false, null);
					}
					List<ModMinecraft.JavaEntry> list = new List<ModMinecraft.JavaEntry>();
					try
					{
						foreach (KeyValuePair<string, bool> keyValuePair3 in dictionary)
						{
							list.Add(new ModMinecraft.JavaEntry(keyValuePair3.Key, keyValuePair3.Value));
						}
					}
					finally
					{
						Dictionary<string, bool>.Enumerator enumerator4;
						((IDisposable)enumerator4).Dispose();
					}
					list = ModBase.Sort<ModMinecraft.JavaEntry>(ModMinecraft.JavaCheckList(list), (ModMinecraft._Closure$__.$IR9-2 == null) ? (ModMinecraft._Closure$__.$IR9-2 = ((object a0, object a1) => ModMinecraft.JavaSorter((ModMinecraft.JavaEntry)a0, (ModMinecraft.JavaEntry)a1))) : ModMinecraft._Closure$__.$IR9-2);
					JArray jarray = new JArray();
					try
					{
						foreach (ModMinecraft.JavaEntry javaEntry2 in list)
						{
							jarray.Add(javaEntry2.ToJson());
						}
					}
					finally
					{
						List<ModMinecraft.JavaEntry>.Enumerator enumerator5;
						((IDisposable)enumerator5).Dispose();
					}
					ModBase._ParamsState.Set("LaunchArgumentJavaAll", jarray.ToString(0, new JsonConverter[0]), false, null);
					ModMinecraft._RegTag = list;
				}
				catch (Exception ex2)
				{
					ModBase.Log(ex2, "搜索 Java 时出错", ModBase.LogLevel.Feedback, "出现错误");
					ModMinecraft._RegTag = new List<ModMinecraft.JavaEntry>();
				}
				ModBase.Log("[Java] Java 搜索完成，发现 " + Conversions.ToString(ModMinecraft._RegTag.Count) + " 个 Java", ModBase.LogLevel.Normal, "出现错误");
				if (ModMain.m_MerchantAccount != null)
				{
					ModBase.RunInUi((ModMinecraft._Closure$__.$I9-2 == null) ? (ModMinecraft._Closure$__.$I9-2 = delegate()
					{
						ModMain.m_MerchantAccount.RefreshJavaComboBox();
					}) : ModMinecraft._Closure$__.$I9-2, false);
				}
				if (ModMain._ProcAccount != null)
				{
					ModBase.RunInUi((ModMinecraft._Closure$__.$I9-3 == null) ? (ModMinecraft._Closure$__.$I9-3 = delegate()
					{
						ModMain._ProcAccount.RefreshJavaComboBox();
					}) : ModMinecraft._Closure$__.$I9-3, false);
				}
			}
		}

		// Token: 0x060009E9 RID: 2537 RVA: 0x0004BD18 File Offset: 0x00049F18
		private static List<ModMinecraft.JavaEntry> JavaCheckList(List<ModMinecraft.JavaEntry> JavaEntries)
		{
			ModMinecraft._Closure$__10-1 CS$<>8__locals1 = new ModMinecraft._Closure$__10-1(CS$<>8__locals1);
			ModBase.Log("[Java] 开始确认列表 Java 状态，共 " + Conversions.ToString(JavaEntries.Count) + " 项", ModBase.LogLevel.Normal, "出现错误");
			CS$<>8__locals1.$VB$Local_JavaCheckList = new List<ModMinecraft.JavaEntry>();
			CS$<>8__locals1.$VB$Local_ListLock = RuntimeHelpers.GetObjectValue(new object());
			List<Thread> list = new List<Thread>();
			try
			{
				List<ModMinecraft.JavaEntry>.Enumerator enumerator = JavaEntries.GetEnumerator();
				while (enumerator.MoveNext())
				{
					ModMinecraft._Closure$__10-0 CS$<>8__locals2 = new ModMinecraft._Closure$__10-0(CS$<>8__locals2);
					CS$<>8__locals2.$VB$NonLocal_$VB$Closure_2 = CS$<>8__locals1;
					CS$<>8__locals2.$VB$Local_Entry = enumerator.Current;
					Thread thread = new Thread(delegate()
					{
						try
						{
							CS$<>8__locals2.$VB$Local_Entry.Check();
							ModBase.Log("[Java] " + CS$<>8__locals2.$VB$Local_Entry.ToString(), ModBase.LogLevel.Normal, "出现错误");
							object $VB$Local_ListLock = CS$<>8__locals2.$VB$NonLocal_$VB$Closure_2.$VB$Local_ListLock;
							ObjectFlowControl.CheckForSyncLockOnValueType($VB$Local_ListLock);
							lock ($VB$Local_ListLock)
							{
								CS$<>8__locals2.$VB$NonLocal_$VB$Closure_2.$VB$Local_JavaCheckList.Add(CS$<>8__locals2.$VB$Local_Entry);
							}
						}
						catch (Exception ex)
						{
							if (CS$<>8__locals2.$VB$Local_Entry._MethodProccesor)
							{
								ModBase.Log(ex, "位于 " + CS$<>8__locals2.$VB$Local_Entry.m_ListProccesor + " 的 Java 存在异常，将被自动移除", ModBase.LogLevel.Hint, "出现错误");
							}
							else
							{
								ModBase.Log(ex, "位于 " + CS$<>8__locals2.$VB$Local_Entry.m_ListProccesor + " 的 Java 存在异常", ModBase.LogLevel.Debug, "出现错误");
							}
						}
					});
					list.Add(thread);
					thread.Start();
				}
				goto IL_DF;
			}
			finally
			{
				List<ModMinecraft.JavaEntry>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			try
			{
				IL_AC:
				List<Thread>.Enumerator enumerator2 = list.GetEnumerator();
				while (enumerator2.MoveNext())
				{
					if (enumerator2.Current.IsAlive)
					{
						goto IL_DF;
					}
				}
				goto IL_E8;
			}
			finally
			{
				List<Thread>.Enumerator enumerator2;
				((IDisposable)enumerator2).Dispose();
			}
			goto IL_DF;
			IL_E8:
			return CS$<>8__locals1.$VB$Local_JavaCheckList;
			IL_DF:
			Thread.Sleep(10);
			goto IL_AC;
		}

		// Token: 0x060009EA RID: 2538 RVA: 0x0004BE30 File Offset: 0x0004A030
		private static void JavaSearchFolder(string OriginalPath, ref Dictionary<string, bool> Results, bool Source, bool IsFullSearch = false)
		{
			try
			{
				ModBase.Log("[Java] 开始" + (IsFullSearch ? "完全" : "部分") + "遍历查找：" + OriginalPath, ModBase.LogLevel.Normal, "出现错误");
				ModMinecraft.JavaSearchFolder(new DirectoryInfo(OriginalPath), ref Results, Source, IsFullSearch);
			}
			catch (UnauthorizedAccessException ex)
			{
				ModBase.Log("[Java] 遍历查找 Java 时遭遇无权限的文件夹：" + OriginalPath, ModBase.LogLevel.Normal, "出现错误");
			}
			catch (Exception ex2)
			{
				ModBase.Log(ex2, "遍历查找 Java 时出错（" + OriginalPath + "）", ModBase.LogLevel.Debug, "出现错误");
			}
		}

		// Token: 0x060009EB RID: 2539 RVA: 0x0004BEE4 File Offset: 0x0004A0E4
		private static void JavaSearchFolder(DirectoryInfo OriginalPath, ref Dictionary<string, bool> Results, bool Source, bool IsFullSearch = false)
		{
			try
			{
				if (OriginalPath.Exists)
				{
					string text = OriginalPath.FullName.Replace("\\\\", "\\");
					if (!text.EndsWith("\\"))
					{
						text += "\\";
					}
					if (File.Exists(text + "javaw.exe"))
					{
						ModBase.DictionaryAdd<string, bool>(ref Results, text, Source);
					}
					try
					{
						foreach (DirectoryInfo directoryInfo in OriginalPath.EnumerateDirectories())
						{
							if (!directoryInfo.Attributes.HasFlag(FileAttributes.ReparsePoint))
							{
								string text2 = ModBase.GetFolderNameFromPath(directoryInfo.Name).ToLower();
								if (IsFullSearch || text2.Contains("java") || text2.Contains("jdk") || text2.Contains("env") || text2.Contains("环境") || text2.Contains("run") || text2.Contains("软件") || text2.Contains("jre") || Operators.CompareString(text2, "bin", true) == 0 || text2.Contains("mc") || text2.Contains("software") || text2.Contains("cache") || text2.Contains("temp") || text2.Contains("minecraft") || text2.Contains("roaming") || text2.Contains("users") || text2.Contains("craft") || text2.Contains("program") || text2.Contains("世界") || text2.Contains("net") || text2.Contains("游戏") || text2.Contains("oracle") || text2.Contains("game") || text2.Contains("file") || text2.Contains("data") || text2.Contains("jvm") || text2.Contains("服务") || text2.Contains("server") || text2.Contains("客户") || text2.Contains("client") || text2.Contains("整合") || text2.Contains("应用") || text2.Contains("运行") || text2.Contains("前置") || text2.Contains("mojang") || text2.Contains("官启") || text2.Contains("新建文件夹") || text2.Contains("eclipse") || text2.Contains("runtime") || text2.Contains("x86") || text2.Contains("x64") || text2.Contains("forge") || text2.Contains("原版") || text2.Contains("optifine") || text2.Contains("官方") || text2.Contains("启动") || text2.Contains("hmcl") || text2.Contains("mod") || text2.Contains("高清") || text2.Contains("download") || text2.Contains("launch") || text2.Contains("程序") || text2.Contains("path") || text2.Contains("国服") || text2.Contains("网易") || text2.Contains("ext") || text2.Contains("netease") || text2.Contains("1.") || text2.Contains("启动"))
								{
									ModMinecraft.JavaSearchFolder(directoryInfo, ref Results, Source, false);
								}
							}
						}
					}
					finally
					{
						IEnumerator<DirectoryInfo> enumerator;
						if (enumerator != null)
						{
							enumerator.Dispose();
						}
					}
				}
			}
			catch (UnauthorizedAccessException ex)
			{
				ModBase.Log("[Java] 遍历查找 Java 时遭遇无权限的文件夹：" + OriginalPath.FullName, ModBase.LogLevel.Normal, "出现错误");
			}
			catch (Exception ex2)
			{
				ModBase.Log(ex2, "遍历查找 Java 时出错（" + OriginalPath.FullName + "）", ModBase.LogLevel.Debug, "出现错误");
			}
		}

		// Token: 0x060009EC RID: 2540 RVA: 0x0004C3E4 File Offset: 0x0004A5E4
		public static ModMinecraft.JavaEntry JavaSelect(Version MinVersion = null, Version MaxVersion = null, ModMinecraft.McVersion RelatedVersion = null)
		{
			ModMinecraft.JavaEntry result;
			try
			{
				List<ModMinecraft.JavaEntry> list = new List<ModMinecraft.JavaEntry>();
				Dictionary<string, bool> dictionary = new Dictionary<string, bool>();
				if (ModMinecraft._MapperTag.Split(new char[]
				{
					'\\'
				}).Count<string>() > 3)
				{
					ModMinecraft.JavaSearchFolder(ModBase.GetPathFromFullPath(ModMinecraft._MapperTag), ref dictionary, false, true);
				}
				ModMinecraft.JavaSearchFolder(ModMinecraft._MapperTag, ref dictionary, false, true);
				if (RelatedVersion != null)
				{
					ModMinecraft.JavaSearchFolder(RelatedVersion.Path, ref dictionary, false, true);
				}
				List<ModMinecraft.JavaEntry> list2 = new List<ModMinecraft.JavaEntry>();
				try
				{
					foreach (KeyValuePair<string, bool> keyValuePair in dictionary)
					{
						list2.Add(new ModMinecraft.JavaEntry(keyValuePair.Key, keyValuePair.Value));
					}
				}
				finally
				{
					Dictionary<string, bool>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				list2 = ModMinecraft.JavaCheckList(list2);
				ModBase.Log("[Java] 检查后找到 " + Conversions.ToString(list2.Count) + " 个特定目录下的 Java", ModBase.LogLevel.Normal, "出现错误");
				ModMinecraft.JavaEntry javaEntry3;
				for (;;)
				{
					if (ModMinecraft.composerTag.State == ModBase.LoadState.Loading)
					{
						goto IL_3CE;
					}
					IL_E6:
					List<ModMinecraft.JavaEntry> list3 = new List<ModMinecraft.JavaEntry>();
					list3.AddRange(list2);
					list3.AddRange(ModMinecraft._RegTag);
					try
					{
						foreach (ModMinecraft.JavaEntry javaEntry in list3)
						{
							if ((MinVersion == null || !(javaEntry.m_AnnotationProccesor < MinVersion)) && (MaxVersion == null || !(javaEntry.m_AnnotationProccesor > MaxVersion)) && (!javaEntry._RefProccesor || !ModBase.m_WriterState))
							{
								list.Add(javaEntry);
							}
						}
					}
					finally
					{
						List<ModMinecraft.JavaEntry>.Enumerator enumerator2;
						((IDisposable)enumerator2).Dispose();
					}
					if (list.Count == 0 && ModMinecraft.composerTag.State == ModBase.LoadState.Waiting)
					{
						ModBase.Log("[Java] 未找到满足条件的 Java，尝试进行搜索", ModBase.LogLevel.Normal, "出现错误");
						ModMinecraft.composerTag.Start(null, false);
						continue;
					}
					if (list.Count != 0)
					{
						string text = Conversions.ToString(ModBase._ParamsState.Get("LaunchArgumentJavaSelect", null));
						if (RelatedVersion != null)
						{
							string text2 = Conversions.ToString(ModBase._ParamsState.Get("VersionArgumentJavaSelect", RelatedVersion));
							if (Operators.CompareString(text2, "使用全局设置", true) != 0)
							{
								text = text2;
							}
						}
						if (Operators.CompareString(text, "", true) == 0)
						{
							goto IL_2FF;
						}
						ModMinecraft.JavaEntry javaEntry2;
						try
						{
							javaEntry2 = ModMinecraft.JavaEntry.FromJson((JObject)ModBase.GetJson(text));
						}
						catch (Exception ex)
						{
							ModBase._ParamsState.Set("LaunchArgumentJavaSelect", "", false, null);
							ModBase.Log(ex, "获取储存的 Java 失败", ModBase.LogLevel.Debug, "出现错误");
							goto IL_362;
						}
						try
						{
							List<ModMinecraft.JavaEntry>.Enumerator enumerator3 = list.GetEnumerator();
							while (enumerator3.MoveNext())
							{
								if (Operators.CompareString(enumerator3.Current.m_ListProccesor, javaEntry2.m_ListProccesor, true) == 0)
								{
									list = new List<ModMinecraft.JavaEntry>
									{
										javaEntry2
									};
									goto IL_362;
								}
							}
						}
						finally
						{
							List<ModMinecraft.JavaEntry>.Enumerator enumerator3;
							((IDisposable)enumerator3).Dispose();
						}
						ModBase.Log("[Java] 发现用户指定的不兼容 Java：" + javaEntry2.ToString(), ModBase.LogLevel.Normal, "出现错误");
						if (ModMain.MyMsgBox("你在设置中指定的 Java 可能不兼容当前环境，这可能会导致出错。\r\n是否要继续使用设置中强制指定的 Java？", "Java 兼容性警告", "取消，让 PCL2 自动选择", "继续", "", false, true, false) == 2)
						{
							ModBase.Log("[Java] 已强制使用用户指定的不兼容 Java", ModBase.LogLevel.Normal, "出现错误");
							list = new List<ModMinecraft.JavaEntry>
							{
								javaEntry2
							};
							goto IL_2FF;
						}
						goto IL_2FF;
						IL_362:
						list = ModBase.Sort<ModMinecraft.JavaEntry>(list, (ModMinecraft._Closure$__.$IR14-3 == null) ? (ModMinecraft._Closure$__.$IR14-3 = ((object a0, object a1) => ModMinecraft.JavaSorter((ModMinecraft.JavaEntry)a0, (ModMinecraft.JavaEntry)a1))) : ModMinecraft._Closure$__.$IR14-3);
						javaEntry3 = list.First<ModMinecraft.JavaEntry>();
						try
						{
							javaEntry3.Check();
							break;
						}
						catch (Exception ex2)
						{
							ModBase.Log(ex2, "找到的 Java 已无法使用，尝试进行搜索", ModBase.LogLevel.Debug, "出现错误");
							ModMinecraft.composerTag.Start(null, true);
							continue;
						}
						goto IL_3CE;
						IL_2FF:
						try
						{
							foreach (ModMinecraft.JavaEntry javaEntry4 in list)
							{
								if (list2.Contains(javaEntry4))
								{
									list = new List<ModMinecraft.JavaEntry>
									{
										javaEntry4
									};
									ModBase.Log("[Java] 使用特定目录下的 Java：" + javaEntry4.ToString(), ModBase.LogLevel.Normal, "出现错误");
									break;
								}
							}
						}
						finally
						{
							List<ModMinecraft.JavaEntry>.Enumerator enumerator4;
							((IDisposable)enumerator4).Dispose();
						}
						goto IL_362;
					}
					goto IL_401;
					IL_3CE:
					ModMinecraft.composerTag.WaitForExit(null, null, false);
					goto IL_E6;
				}
				ModBase.Log("[Java] 选定的 Java：" + javaEntry3.ToString(), ModBase.LogLevel.Normal, "出现错误");
				return javaEntry3;
				IL_401:
				result = null;
			}
			catch (Exception ex3)
			{
				ModBase.Log(ex3, "查找符合条件的 Java 失败", ModBase.LogLevel.Feedback, "出现错误");
				result = null;
			}
			return result;
		}

		// Token: 0x060009ED RID: 2541 RVA: 0x0004C8C8 File Offset: 0x0004AAC8
		public static bool JavaUse64Bit(ModMinecraft.McVersion RelatedVersion = null)
		{
			bool result;
			try
			{
				string text = Conversions.ToString(ModBase._ParamsState.Get("LaunchArgumentJavaSelect", null));
				if (RelatedVersion != null)
				{
					string text2 = Conversions.ToString(ModBase._ParamsState.Get("VersionArgumentJavaSelect", RelatedVersion));
					if (Operators.CompareString(text2, "使用全局设置", true) != 0)
					{
						text = text2;
					}
				}
				if (Operators.CompareString(text, "", true) != 0)
				{
					ModMinecraft.JavaEntry javaEntry = ModMinecraft.JavaEntry.FromJson((JObject)ModBase.GetJson(text));
					try
					{
						List<ModMinecraft.JavaEntry>.Enumerator enumerator = ModMinecraft._RegTag.GetEnumerator();
						while (enumerator.MoveNext())
						{
							if (Operators.CompareString(enumerator.Current.m_ListProccesor, javaEntry.m_ListProccesor, true) == 0)
							{
								return javaEntry._RefProccesor;
							}
						}
					}
					finally
					{
						List<ModMinecraft.JavaEntry>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
				}
				try
				{
					List<ModMinecraft.JavaEntry>.Enumerator enumerator2 = ModMinecraft._RegTag.GetEnumerator();
					while (enumerator2.MoveNext())
					{
						if (enumerator2.Current._RefProccesor)
						{
							return true;
						}
					}
				}
				finally
				{
					List<ModMinecraft.JavaEntry>.Enumerator enumerator2;
					((IDisposable)enumerator2).Dispose();
				}
				result = false;
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "检查 Java 类别时出错", ModBase.LogLevel.Feedback, "出现错误");
				ModBase._ParamsState.Set("LaunchArgumentJavaSelect", "", false, null);
				ModBase._ParamsState.Set("VersionArgumentJavaSelect", "", false, RelatedVersion);
				result = true;
			}
			return result;
		}

		// Token: 0x060009EE RID: 2542 RVA: 0x0004CA38 File Offset: 0x0004AC38
		public static bool JavaSorter(ModMinecraft.JavaEntry Left, ModMinecraft.JavaEntry Right)
		{
			string value = "";
			string fullName = (new DirectoryInfo(ModBase.Path).Parent ?? new DirectoryInfo(ModBase.Path)).FullName;
			if (Operators.CompareString(ModMinecraft._MapperTag, "", true) != 0)
			{
				value = (new DirectoryInfo(ModMinecraft._MapperTag).Parent ?? new DirectoryInfo(ModMinecraft._MapperTag)).FullName;
			}
			bool result;
			if (Left.m_ListProccesor.StartsWith(fullName) && !Right.m_ListProccesor.StartsWith(fullName))
			{
				result = true;
			}
			else if (!Left.m_ListProccesor.StartsWith(fullName) && Right.m_ListProccesor.StartsWith(fullName))
			{
				result = false;
			}
			else
			{
				if (Operators.CompareString(ModMinecraft._MapperTag, "", true) != 0)
				{
					if (Left.m_ListProccesor.StartsWith(value) && !Right.m_ListProccesor.StartsWith(value))
					{
						return true;
					}
					if (!Left.m_ListProccesor.StartsWith(value) && Right.m_ListProccesor.StartsWith(value))
					{
						return false;
					}
				}
				if (Left._RefProccesor && !Right._RefProccesor)
				{
					result = true;
				}
				else if (!Left._RefProccesor && Right._RefProccesor)
				{
					result = false;
				}
				else if (Left.m_InterceptorProccesor && !Right.m_InterceptorProccesor)
				{
					result = true;
				}
				else if (!Left.m_InterceptorProccesor && Right.m_InterceptorProccesor)
				{
					result = false;
				}
				else if (Left.DeleteComparator() != Right.DeleteComparator())
				{
					int[] source = new int[]
					{
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						18,
						19,
						13,
						12,
						11,
						10,
						9,
						8,
						7,
						17,
						16,
						15,
						14
					};
					result = (source.ElementAtOrDefault(Left.DeleteComparator()) >= source.ElementAtOrDefault(Right.DeleteComparator()));
				}
				else
				{
					result = checked(Math.Abs(Left.m_AnnotationProccesor.Revision - 51) <= Math.Abs(Right.m_AnnotationProccesor.Revision - 51));
				}
			}
			return result;
		}

		// Token: 0x060009EF RID: 2543 RVA: 0x0004CC08 File Offset: 0x0004AE08
		public static void JavaMissing(int VersionCode)
		{
			if (VersionCode == 7)
			{
				ModMain.MyMsgBox("PCL2 未找到 Java 7。\r\n请自行百度安装 Java 7，安装后在 PCL2 的 设置 → 启动设置 → 游戏 Java 中通过搜索或导入，确保安装的 Java 已列入 Java 列表。", "未找到 Java", "确定", "", "", false, true, false);
				return;
			}
			if (VersionCode == 8)
			{
				if (ModBase.m_WriterState)
				{
					ModBase.OpenWebsite("https://wwa.lanzoui.com/i7RyXq0jbub");
				}
				else
				{
					ModBase.OpenWebsite("https://wwa.lanzoui.com/i2UyMq0jaqb");
				}
				ModMain.MyMsgBox("PCL2 未找到版本适宜的 Java 8。\r\n请在打开的网页中下载安装包并安装，安装后在 PCL2 的 设置 → 启动设置 → 游戏 Java 中通过搜索或导入，确保安装的 Java 已列入 Java 列表。", "未找到 Java", "确定", "", "", false, true, false);
				return;
			}
			if (VersionCode - 16 > 1)
			{
				return;
			}
			if (ModBase.m_WriterState)
			{
				ModMain.MyMsgBox("该版本已不支持 32 位操作系统。你必须增加内存并重装为 64 位系统才能继续。", "系统兼容性提示", "确定", "", "", false, true, false);
				return;
			}
			ModBase.OpenWebsite("https://www.oracle.com/java/technologies/downloads/#jdk17-windows");
			ModMain.MyMsgBox("PCL2 未找到 Java " + Conversions.ToString(VersionCode) + "。\r\n请在打开的网页中选择 x64 Installer，下载并安装。\r\n安装后在 PCL2 的 设置 → 启动设置 → 游戏 Java 中通过搜索或导入，确保安装的 Java 已列入 Java 列表。", "未找到 Java", "确定", "", "", false, true, false);
		}

		// Token: 0x060009F0 RID: 2544 RVA: 0x0004CCF4 File Offset: 0x0004AEF4
		private static void McFolderListLoadSub()
		{
			checked
			{
				try
				{
					List<ModMinecraft.McFolder> list = new List<ModMinecraft.McFolder>();
					if (ModBase.CheckPermission(ModBase.Path) && Directory.Exists(ModBase.Path + "versions\\"))
					{
						list.Add(new ModMinecraft.McFolder
						{
							Name = "当前文件夹",
							Path = ModBase.Path,
							Type = ModMinecraft.McFolderType.Original
						});
					}
					foreach (DirectoryInfo directoryInfo in new DirectoryInfo(ModBase.Path).GetDirectories())
					{
						if ((ModBase.CheckPermission(directoryInfo.FullName) && Directory.Exists(directoryInfo.FullName + "versions\\")) || Operators.CompareString(directoryInfo.Name, ".minecraft", true) == 0)
						{
							list.Add(new ModMinecraft.McFolder
							{
								Name = "当前文件夹",
								Path = directoryInfo.FullName + "\\",
								Type = ModMinecraft.McFolderType.Original
							});
						}
					}
					string text = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\.minecraft\\";
					if ((list.Count == 0 || Operators.CompareString(text, list[0].Path, true) != 0) && ModBase.CheckPermission(text) && Directory.Exists(text + "versions\\"))
					{
						list.Add(new ModMinecraft.McFolder
						{
							Name = "官方启动器文件夹",
							Path = text,
							Type = ModMinecraft.McFolderType.Original
						});
					}
					try
					{
						foreach (object value in ((IEnumerable)NewLateBinding.LateGet(ModBase._ParamsState.Get("LaunchFolders", null), null, "Split", new object[]
						{
							"|"
						}, null, null, null)))
						{
							string text2 = Conversions.ToString(value);
							if (Operators.CompareString(text2, "", true) != 0)
							{
								if (text2.Contains(">") && text2.EndsWith("\\"))
								{
									string name = text2.Split(new char[]
									{
										'>'
									})[0];
									string text3 = text2.Split(new char[]
									{
										'>'
									})[1];
									if (ModBase.CheckPermission(text3))
									{
										bool flag = false;
										try
										{
											foreach (ModMinecraft.McFolder mcFolder in list)
											{
												if (Operators.CompareString(mcFolder.Path, text3, true) == 0)
												{
													mcFolder.Name = name;
													mcFolder.Type = ModMinecraft.McFolderType.RenamedOriginal;
													flag = true;
												}
											}
										}
										finally
										{
											List<ModMinecraft.McFolder>.Enumerator enumerator2;
											((IDisposable)enumerator2).Dispose();
										}
										if (!flag)
										{
											list.Add(new ModMinecraft.McFolder
											{
												Name = name,
												Path = text3,
												Type = ModMinecraft.McFolderType.Custom
											});
										}
									}
									else
									{
										ModMain.Hint("无效的 Minecraft 文件夹：" + text3, ModMain.HintType.Critical, true);
									}
								}
								else
								{
									ModMain.Hint("无效的 Minecraft 文件夹：" + text2, ModMain.HintType.Critical, true);
								}
							}
						}
					}
					finally
					{
						IEnumerator enumerator;
						if (enumerator is IDisposable)
						{
							(enumerator as IDisposable).Dispose();
						}
					}
					List<string> list2 = new List<string>();
					try
					{
						foreach (ModMinecraft.McFolder mcFolder2 in list)
						{
							if (mcFolder2.Type != ModMinecraft.McFolderType.Original)
							{
								list2.Add(mcFolder2.Name + ">" + mcFolder2.Path);
							}
						}
					}
					finally
					{
						List<ModMinecraft.McFolder>.Enumerator enumerator3;
						((IDisposable)enumerator3).Dispose();
					}
					if (list2.Count == 0)
					{
						list2.Add("");
					}
					ModBase._ParamsState.Set("LaunchFolders", ModBase.Join(list2, "|"), false, null);
					if (list.Count == 0)
					{
						Directory.CreateDirectory(ModBase.Path + ".minecraft\\versions\\");
						list.Add(new ModMinecraft.McFolder
						{
							Name = "当前文件夹",
							Path = ModBase.Path + ".minecraft\\",
							Type = ModMinecraft.McFolderType.Original
						});
					}
					try
					{
						foreach (ModMinecraft.McFolder mcFolder3 in list)
						{
							if (Directory.Exists(mcFolder3.Path + "versions\\"))
							{
								mcFolder3.serverProccesor = new DirectoryInfo(mcFolder3.Path + "versions\\").GetDirectories().Count<DirectoryInfo>();
								DirectoryInfo[] directories2 = new DirectoryInfo(mcFolder3.Path + "versions\\").GetDirectories();
								for (int j = 0; j < directories2.Length; j++)
								{
									if (Conversions.ToBoolean(ModBase.ReadIni(directories2[j].FullName + "\\PCL\\Setup.ini", "Hide", "False")))
									{
										ModMinecraft.McFolder mcFolder4 = mcFolder3;
										ref int ptr = ref mcFolder4.serverProccesor;
										mcFolder4.serverProccesor = ptr - 1;
									}
								}
							}
							ModMinecraft.McFolderLauncherProfilesJsonCreate(mcFolder3.Path);
						}
					}
					finally
					{
						List<ModMinecraft.McFolder>.Enumerator enumerator4;
						((IDisposable)enumerator4).Dispose();
					}
					if (Conversions.ToBoolean(ModBase._ParamsState.Get("SystemDebugDelay", null)))
					{
						Thread.Sleep(ModBase.RandomInteger(200, 2000));
					}
					ModMinecraft._FactoryTag = list;
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "加载 Minecraft 文件夹列表失败", ModBase.LogLevel.Feedback, "出现错误");
				}
			}
		}

		// Token: 0x060009F1 RID: 2545 RVA: 0x0004D268 File Offset: 0x0004B468
		public static void McFolderLauncherProfilesJsonCreate(string Folder)
		{
			try
			{
				if (!File.Exists(Folder + "launcher_profiles.json"))
				{
					string text = string.Concat(new string[]
					{
						"{\r\n    \"profiles\":  {\r\n        \"PCL2\": {\r\n            \"icon\": \"Grass\",\r\n            \"name\": \"PCL2\",\r\n            \"lastVersionId\": \"latest-release\",\r\n            \"type\": \"latest-release\",\r\n            \"lastUsed\": \"",
						DateTime.Now.ToString("yyyy-MM-dd"),
						"T",
						DateTime.Now.ToString("HH:mm:ss"),
						".0000Z\"\r\n        }\r\n    },\r\n    \"selectedProfile\": \"PCL2\",\r\n    \"clientToken\": \"23323323323323323323323323323333\"\r\n}"
					});
					ModBase.WriteFile(Folder + "launcher_profiles.json", text, false, Encoding.Default);
					ModBase.Log("[Minecraft] 已创建 launcher_profiles.json：" + Folder, ModBase.LogLevel.Normal, "出现错误");
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "创建 launcher_profiles.json 失败（" + Folder + "）", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x060009F2 RID: 2546 RVA: 0x00006D15 File Offset: 0x00004F15
		public static ModMinecraft.McVersion SetupResolver()
		{
			return ModMinecraft._ValTag;
		}

		// Token: 0x060009F3 RID: 2547 RVA: 0x0004D344 File Offset: 0x0004B544
		public static void FindResolver(ModMinecraft.McVersion value)
		{
			if (!object.ReferenceEquals(RuntimeHelpers.GetObjectValue(ModMinecraft.m_UtilsTag), value))
			{
				ModMinecraft._ValTag = value;
				ModMinecraft.m_UtilsTag = value;
				if (value != null)
				{
					if (ModAnimation.DefineModel() == 0 && Operators.ConditionalCompareObjectNotEqual(ModBase._ParamsState.Get("VersionServerNide", value), ModBase._ParamsState.Get("CacheNideServer", null), true) && Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("VersionServerLogin", value), 3, true))
					{
						ModBase._ParamsState.Set("CacheNideAccess", "", false, null);
						ModBase.Log("[Launch] 服务器改变，要求重新登录统一通行证", ModBase.LogLevel.Normal, "出现错误");
					}
					if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("VersionServerLogin", value), 3, true))
					{
						ModBase._ParamsState.Set("CacheNideServer", RuntimeHelpers.GetObjectValue(ModBase._ParamsState.Get("VersionServerNide", value)), false, null);
					}
					if (ModAnimation.DefineModel() == 0 && Operators.ConditionalCompareObjectNotEqual(ModBase._ParamsState.Get("VersionServerAuthServer", value), ModBase._ParamsState.Get("CacheAuthServerServer", null), true) && Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("VersionServerLogin", value), 4, true))
					{
						ModBase._ParamsState.Set("CacheNideServer", "", false, null);
						ModBase.Log("[Launch] 服务器改变，要求重新登录 Authlib-Injector", ModBase.LogLevel.Normal, "出现错误");
					}
					if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("VersionServerLogin", value), 4, true))
					{
						ModBase._ParamsState.Set("CacheAuthServerServer", RuntimeHelpers.GetObjectValue(ModBase._ParamsState.Get("VersionServerAuthServer", value)), false, null);
						ModBase._ParamsState.Set("CacheAuthServerName", RuntimeHelpers.GetObjectValue(ModBase._ParamsState.Get("VersionServerAuthName", value)), false, null);
						ModBase._ParamsState.Set("CacheAuthServerRegister", RuntimeHelpers.GetObjectValue(ModBase._ParamsState.Get("VersionServerAuthRegister", value)), false, null);
					}
				}
			}
		}

		// Token: 0x060009F4 RID: 2548 RVA: 0x0004D534 File Offset: 0x0004B734
		public static string GetMcFoolName(string Name)
		{
			Name = Name.ToLower();
			string result;
			if (Name.StartsWith("2.0"))
			{
				result = "这个秘密计划了两年的更新将游戏推向了一个新高度！";
			}
			else if (!Name.StartsWith("20w14inf") && Operators.CompareString(Name, "20w14∞", true) != 0)
			{
				if (Operators.CompareString(Name, "15w14a", true) == 0)
				{
					result = "作为一款全年龄向的游戏，我们需要和平，需要爱与拥抱。";
				}
				else if (Operators.CompareString(Name, "1.rv-pre1", true) == 0)
				{
					result = "是时候将现代科技带入 Minecraft 了！";
				}
				else if (Operators.CompareString(Name, "3d shareware v1.34", true) == 0)
				{
					result = "我们从地下室的废墟里找到了这个开发于 1994 年的杰作！";
				}
				else
				{
					result = "";
				}
			}
			else
			{
				result = "我们加入了 20 亿个新的世界，让无限的想象变成了现实！";
			}
			return result;
		}

		// Token: 0x060009F5 RID: 2549 RVA: 0x0004D5CC File Offset: 0x0004B7CC
		private static void McVersionListLoad(ModLoader.LoaderTask<string, int> Loader)
		{
			string input = Loader.Input;
			try
			{
				ModMinecraft._OrderTag.Clear();
				List<string> list = new List<string>();
				if (Directory.Exists(input + "versions"))
				{
					try
					{
						foreach (DirectoryInfo directoryInfo in new DirectoryInfo(input + "versions").GetDirectories())
						{
							list.Add(directoryInfo.Name);
						}
					}
					catch (Exception innerException)
					{
						throw new Exception("无法读取版本文件夹，可能是由于没有权限（" + input + "versions）", innerException);
					}
				}
				if (list.Count == 0)
				{
					ModBase.WriteIni(input + "PCL.ini", "VersionCache", "");
				}
				else
				{
					int num = Convert.ToInt32(decimal.Remainder(new decimal(ModBase.GetHash(Conversions.ToString(22) + "#" + ModBase.Join(list.ToArray(), "#"))), 2147483646m));
					if (!ModMinecraft._PolicyTag && ModBase.Val(ModBase.ReadIni(input + "PCL.ini", "VersionCache", "")) == (double)num)
					{
						Dictionary<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>> dictionary = ModMinecraft.McVersionListLoadCache(input);
						if (dictionary != null)
						{
							ModMinecraft._OrderTag = dictionary;
							goto IL_16C;
						}
					}
					ModMinecraft._PolicyTag = false;
					ModBase.Log("[Minecraft] 文件夹列表变更，重载所有版本", ModBase.LogLevel.Normal, "出现错误");
					ModBase.WriteIni(input + "PCL.ini", "VersionCache", Conversions.ToString(num));
					ModMinecraft._OrderTag = ModMinecraft.McVersionListLoadNoCache(input);
					IL_16C:
					if (Loader.IsAborted)
					{
						return;
					}
				}
				if (ModMinecraft._OrderTag.Count == 0)
				{
					ModMinecraft.FindResolver(null);
					ModBase._ParamsState.Set("LaunchVersionSelect", "", false, null);
					ModBase.Log("[Minecraft] 未找到可用 Minecraft 版本", ModBase.LogLevel.Normal, "出现错误");
				}
				else
				{
					string text = ModBase.ReadIni(input + "PCL.ini", "Version", "");
					if (Operators.CompareString(text, "", true) != 0)
					{
						try
						{
							foreach (KeyValuePair<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>> keyValuePair in ModMinecraft._OrderTag)
							{
								try
								{
									foreach (ModMinecraft.McVersion mcVersion in keyValuePair.Value)
									{
										if (Operators.CompareString(mcVersion.Name, text, true) == 0 && mcVersion._ClassProccesor != ModMinecraft.McVersionState.Error)
										{
											ModMinecraft.FindResolver(mcVersion);
											ModBase._ParamsState.Set("LaunchVersionSelect", ModMinecraft._ValTag.Name, false, null);
											ModBase.Log("[Minecraft] 选择该文件夹储存的 Minecraft 版本：" + ModMinecraft._ValTag.Path, ModBase.LogLevel.Normal, "出现错误");
											return;
										}
									}
								}
								finally
								{
									List<ModMinecraft.McVersion>.Enumerator enumerator2;
									((IDisposable)enumerator2).Dispose();
								}
							}
						}
						finally
						{
							Dictionary<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>>.Enumerator enumerator;
							((IDisposable)enumerator).Dispose();
						}
					}
					if (ModMinecraft._OrderTag.First<KeyValuePair<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>>>().Value[0]._ClassProccesor != ModMinecraft.McVersionState.Error)
					{
						ModMinecraft.FindResolver(ModMinecraft._OrderTag.First<KeyValuePair<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>>>().Value[0]);
						ModBase._ParamsState.Set("LaunchVersionSelect", ModMinecraft._ValTag.Name, false, null);
						ModBase.Log("[Launch] 自动选择 Minecraft 版本：" + ModMinecraft._ValTag.Path, ModBase.LogLevel.Normal, "出现错误");
					}
				}
				if (Conversions.ToBoolean(ModBase._ParamsState.Get("SystemDebugDelay", null)))
				{
					Thread.Sleep(ModBase.RandomInteger(200, 3000));
				}
			}
			catch (ThreadInterruptedException ex)
			{
			}
			catch (Exception ex2)
			{
				ModBase.WriteIni(input + "PCL.ini", "VersionCache", "");
				ModBase.Log(ex2, "加载 .minecraft 版本列表失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x060009F6 RID: 2550 RVA: 0x0004D9F0 File Offset: 0x0004BBF0
		private static Dictionary<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>> McVersionListLoadCache(string Path)
		{
			Dictionary<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>> dictionary = new Dictionary<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>>();
			checked
			{
				Dictionary<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>> result;
				try
				{
					int num = Conversions.ToInteger(ModBase.ReadIni(Path + "PCL.ini", "CardCount", Conversions.ToString(-1)));
					if (num == -1)
					{
						result = null;
					}
					else
					{
						int num2 = num - 1;
						for (int i = 0; i <= num2; i++)
						{
							ModMinecraft.McVersionCardType key = (ModMinecraft.McVersionCardType)Conversions.ToInteger(ModBase.ReadIni(Path + "PCL.ini", "CardKey" + Conversions.ToString(i + 1), ":"));
							List<ModMinecraft.McVersion> list = new List<ModMinecraft.McVersion>();
							foreach (string text in ModBase.ReadIni(Path + "PCL.ini", "CardValue" + Conversions.ToString(i + 1), ":").Split(new char[]
							{
								':'
							}))
							{
								if (Operators.CompareString(text, "", true) != 0)
								{
									try
									{
										ModMinecraft.McVersion mcVersion = new ModMinecraft.McVersion(Path + "versions\\" + text + "\\");
										list.Add(mcVersion);
										mcVersion.proxyProccesor = ModBase.ReadIni(mcVersion.Path + "PCL\\Setup.ini", "CustomInfo", "");
										if (Operators.CompareString(mcVersion.proxyProccesor, "", true) == 0)
										{
											mcVersion.proxyProccesor = ModBase.ReadIni(mcVersion.Path + "PCL\\Setup.ini", "Info", mcVersion.proxyProccesor);
										}
										mcVersion.registryProccesor = ModBase.ReadIni(mcVersion.Path + "PCL\\Setup.ini", "Logo", mcVersion.registryProccesor);
										mcVersion.m_MappingProccesor = Conversions.ToDate(ModBase.ReadIni(mcVersion.Path + "PCL\\Setup.ini", "ReleaseTime", Conversions.ToString(mcVersion.m_MappingProccesor)));
										mcVersion._ClassProccesor = (ModMinecraft.McVersionState)Conversions.ToInteger(ModBase.ReadIni(mcVersion.Path + "PCL\\Setup.ini", "State", Conversions.ToString((int)mcVersion._ClassProccesor)));
										mcVersion._ProducerProccesor = Conversions.ToBoolean(ModBase.ReadIni(mcVersion.Path + "PCL\\Setup.ini", "IsStar", Conversions.ToString(false)));
										mcVersion.m_CandidateProccesor = (ModMinecraft.McVersionCardType)Conversions.ToInteger(ModBase.ReadIni(Path + "PCL\\Setup.ini", "DisplayType", Conversions.ToString(0)));
										if (mcVersion._ClassProccesor != ModMinecraft.McVersionState.Error)
										{
											ModMinecraft.McVersionInfo mcVersionInfo = new ModMinecraft.McVersionInfo();
											mcVersionInfo.m_ProccesorParameter = ModBase.ReadIni(mcVersion.Path + "PCL\\Setup.ini", "VersionFabric", "");
											mcVersionInfo.m_AccountParameter = ModBase.ReadIni(mcVersion.Path + "PCL\\Setup.ini", "VersionForge", "");
											mcVersionInfo.m_IssuerParameter = ModBase.ReadIni(mcVersion.Path + "PCL\\Setup.ini", "VersionOptiFine", "");
											mcVersionInfo._ParameterParameter = Conversions.ToBoolean(ModBase.ReadIni(mcVersion.Path + "PCL\\Setup.ini", "VersionLiteLoader", Conversions.ToString(false)));
											mcVersionInfo.LoginPrototype(Conversions.ToInteger(ModBase.ReadIni(mcVersion.Path + "PCL\\Setup.ini", "VersionApiCode", Conversions.ToString(-1))));
											mcVersionInfo._ResolverParameter = ModBase.ReadIni(mcVersion.Path + "PCL\\Setup.ini", "VersionOriginal", "Unknown");
											mcVersionInfo.tagParameter = Conversions.ToInteger(ModBase.ReadIni(mcVersion.Path + "PCL\\Setup.ini", "VersionOriginalMain", Conversions.ToString(-1)));
											mcVersionInfo.m_ComparatorParameter = Conversions.ToInteger(ModBase.ReadIni(mcVersion.Path + "PCL\\Setup.ini", "VersionOriginalSub", Conversions.ToString(-1)));
											mcVersionInfo._RepositoryParameter = true;
											ModMinecraft.McVersionInfo mcVersionInfo2 = mcVersionInfo;
											mcVersionInfo2.stateParameter = (mcVersionInfo2.m_ProccesorParameter.Count<char>() > 1);
											mcVersionInfo2.requestParameter = (mcVersionInfo2.m_AccountParameter.Count<char>() > 1);
											mcVersionInfo2.m_PrototypeParameter = (mcVersionInfo2.m_IssuerParameter.Count<char>() > 1);
											mcVersion.Version = mcVersionInfo2;
										}
										if (mcVersion._ClassProccesor == ModMinecraft.McVersionState.Error)
										{
											string proxyProccesor = mcVersion.proxyProccesor;
											mcVersion._ClassProccesor = ModMinecraft.McVersionState.Original;
											mcVersion.Check();
											string left = ModBase.ReadIni(mcVersion.Path + "PCL\\Setup.ini", "CustomInfo", "");
											if (mcVersion._ClassProccesor == ModMinecraft.McVersionState.Original || (Operators.CompareString(left, "", true) == 0 && Operators.CompareString(proxyProccesor, mcVersion.proxyProccesor, true) != 0))
											{
												ModBase.Log("[Minecraft] 版本 " + mcVersion.Name + " 的错误状态已变更，新的状态为：" + mcVersion.proxyProccesor, ModBase.LogLevel.Normal, "出现错误");
												return null;
											}
										}
										if (Operators.CompareString(mcVersion.registryProccesor, "", true) == 0)
										{
											ModBase.Log("[Minecraft] 版本 " + mcVersion.Name + " 未被加载", ModBase.LogLevel.Normal, "出现错误");
											return null;
										}
									}
									catch (Exception ex)
									{
										ModBase.Log(ex, "读取版本加载缓存失败（" + text + "）", ModBase.LogLevel.Debug, "出现错误");
										return null;
									}
								}
							}
							dictionary.Add(key, list);
						}
						result = dictionary;
					}
				}
				catch (Exception ex2)
				{
					ModBase.Log(ex2, "读取版本缓存失败", ModBase.LogLevel.Debug, "出现错误");
					result = null;
				}
				return result;
			}
		}

		// Token: 0x060009F7 RID: 2551 RVA: 0x0004DF78 File Offset: 0x0004C178
		private static Dictionary<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>> McVersionListLoadNoCache(string Path)
		{
			List<ModMinecraft.McVersion> list = new List<ModMinecraft.McVersion>();
			Dictionary<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>> dictionary = new Dictionary<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>>();
			foreach (DirectoryInfo directoryInfo in new DirectoryInfo(Path + "versions").GetDirectories())
			{
				if (Operators.CompareString(directoryInfo.Name, "cache", true) == 0 && !File.Exists(directoryInfo.FullName + "\\cache.json"))
				{
					ModBase.Log("[Minecraft] 跳过可能的缓存目录：" + directoryInfo.FullName, ModBase.LogLevel.Normal, "出现错误");
				}
				else
				{
					ModMinecraft.McVersion mcVersion = new ModMinecraft.McVersion(directoryInfo.FullName + "\\");
					list.Add(mcVersion);
					mcVersion.Load();
				}
			}
			try
			{
				Dictionary<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>> dictionary2 = new Dictionary<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>>();
				List<ModMinecraft.McVersion> list2 = new List<ModMinecraft.McVersion>();
				try
				{
					foreach (ModMinecraft.McVersion mcVersion2 in list)
					{
						if (mcVersion2._ProducerProccesor && mcVersion2.m_CandidateProccesor != ModMinecraft.McVersionCardType.Hidden)
						{
							list2.Add(mcVersion2);
						}
					}
				}
				finally
				{
					List<ModMinecraft.McVersion>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				if (list2.Count > 0)
				{
					dictionary2.Add(ModMinecraft.McVersionCardType.Star, list2);
				}
				ModMinecraft.McVersionFilter(ref list, ref dictionary2, new ModMinecraft.McVersionState[1], ModMinecraft.McVersionCardType.Error);
				ModMinecraft.McVersionFilter(ref list, ref dictionary2, new ModMinecraft.McVersionState[]
				{
					ModMinecraft.McVersionState.Fool
				}, ModMinecraft.McVersionCardType.Fool);
				ModMinecraft.McVersionFilter(ref list, ref dictionary2, new ModMinecraft.McVersionState[]
				{
					ModMinecraft.McVersionState.Forge,
					ModMinecraft.McVersionState.LiteLoader,
					ModMinecraft.McVersionState.Fabric
				}, ModMinecraft.McVersionCardType.API);
				List<ModMinecraft.McVersion> list3 = new List<ModMinecraft.McVersion>();
				List<ModMinecraft.McVersion> list4 = new List<ModMinecraft.McVersion>();
				ModMinecraft.McVersionFilter(ref list, new ModMinecraft.McVersionState[]
				{
					ModMinecraft.McVersionState.Old
				}, ref list4);
				ModMinecraft.McVersion mcVersion3 = null;
				try
				{
					foreach (ModMinecraft.McVersion mcVersion4 in list)
					{
						if ((mcVersion4._ClassProccesor == ModMinecraft.McVersionState.Original || mcVersion4._ClassProccesor == ModMinecraft.McVersionState.Snapshot) && (mcVersion3 == null || DateTime.Compare(mcVersion4.m_MappingProccesor, mcVersion3.m_MappingProccesor) > 0))
						{
							mcVersion3 = mcVersion4;
						}
					}
				}
				finally
				{
					List<ModMinecraft.McVersion>.Enumerator enumerator2;
					((IDisposable)enumerator2).Dispose();
				}
				if (mcVersion3 != null && mcVersion3._ClassProccesor == ModMinecraft.McVersionState.Snapshot)
				{
					list3.Add(mcVersion3);
					list.Remove(mcVersion3);
				}
				ModMinecraft.McVersionFilter(ref list, new ModMinecraft.McVersionState[]
				{
					ModMinecraft.McVersionState.Snapshot
				}, ref list4);
				Dictionary<string, ModMinecraft.McVersion> dictionary3 = new Dictionary<string, ModMinecraft.McVersion>();
				List<int> list5 = new List<int>();
				try
				{
					foreach (ModMinecraft.McVersion mcVersion5 in list)
					{
						if (mcVersion5.Version.tagParameter >= 2)
						{
							if (!list5.Contains(mcVersion5.Version.tagParameter))
							{
								list5.Add(mcVersion5.Version.tagParameter);
							}
							if (dictionary3.ContainsKey(Conversions.ToString(mcVersion5.Version.tagParameter) + "-" + Conversions.ToString((int)mcVersion5._ClassProccesor)))
							{
								if (mcVersion5.Version.m_PrototypeParameter)
								{
									if (mcVersion5.Version.ReadPrototype() > dictionary3[Conversions.ToString(mcVersion5.Version.tagParameter) + "-" + Conversions.ToString((int)mcVersion5._ClassProccesor)].Version.ReadPrototype())
									{
										dictionary3[Conversions.ToString(mcVersion5.Version.tagParameter) + "-" + Conversions.ToString((int)mcVersion5._ClassProccesor)] = mcVersion5;
									}
								}
								else if (DateTime.Compare(mcVersion5.m_MappingProccesor, dictionary3[Conversions.ToString(mcVersion5.Version.tagParameter) + "-" + Conversions.ToString((int)mcVersion5._ClassProccesor)].m_MappingProccesor) > 0)
								{
									dictionary3[Conversions.ToString(mcVersion5.Version.tagParameter) + "-" + Conversions.ToString((int)mcVersion5._ClassProccesor)] = mcVersion5;
								}
							}
							else
							{
								dictionary3.Add(Conversions.ToString(mcVersion5.Version.tagParameter) + "-" + Conversions.ToString((int)mcVersion5._ClassProccesor), mcVersion5);
							}
						}
					}
				}
				finally
				{
					List<ModMinecraft.McVersion>.Enumerator enumerator3;
					((IDisposable)enumerator3).Dispose();
				}
				try
				{
					foreach (int value in list5)
					{
						if (dictionary3.ContainsKey(Conversions.ToString(value) + "-" + Conversions.ToString(4)))
						{
							ModMinecraft.McVersion mcVersion6 = dictionary3[Conversions.ToString(value) + "-" + Conversions.ToString(4)];
							if (dictionary3.ContainsKey(Conversions.ToString(value) + "-" + Conversions.ToString(1)) && Operators.CompareString(dictionary3[Conversions.ToString(value) + "-" + Conversions.ToString(1)].Version._ResolverParameter, mcVersion6.PrintPrototype(), true) != 0)
							{
								list3.Add(dictionary3[Conversions.ToString(value) + "-" + Conversions.ToString(1)]);
								list.Remove(dictionary3[Conversions.ToString(value) + "-" + Conversions.ToString(1)]);
							}
							list3.Add(mcVersion6);
							list.Remove(mcVersion6);
						}
						else
						{
							list3.Add(dictionary3[Conversions.ToString(value) + "-" + Conversions.ToString(1)]);
							list.Remove(dictionary3[Conversions.ToString(value) + "-" + Conversions.ToString(1)]);
						}
					}
				}
				finally
				{
					List<int>.Enumerator enumerator4;
					((IDisposable)enumerator4).Dispose();
				}
				list4.AddRange(list);
				if (list3.Count > 0)
				{
					dictionary2.Add(ModMinecraft.McVersionCardType.OriginalLike, list3);
				}
				if (list4.Count > 0)
				{
					dictionary2.Add(ModMinecraft.McVersionCardType.Rubbish, list4);
				}
				try
				{
					foreach (KeyValuePair<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>> keyValuePair in dictionary2)
					{
						try
						{
							foreach (ModMinecraft.McVersion mcVersion7 in keyValuePair.Value)
							{
								ModMinecraft.McVersionCardType key = (mcVersion7.m_CandidateProccesor == ModMinecraft.McVersionCardType.Auto || keyValuePair.Key == ModMinecraft.McVersionCardType.Star) ? keyValuePair.Key : mcVersion7.m_CandidateProccesor;
								if (!dictionary.ContainsKey(key))
								{
									dictionary.Add(key, new List<ModMinecraft.McVersion>());
								}
								dictionary[key].Add(mcVersion7);
							}
						}
						finally
						{
							List<ModMinecraft.McVersion>.Enumerator enumerator6;
							((IDisposable)enumerator6).Dispose();
						}
					}
				}
				finally
				{
					Dictionary<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>>.Enumerator enumerator5;
					((IDisposable)enumerator5).Dispose();
				}
			}
			catch (Exception ex)
			{
				dictionary.Clear();
				ModBase.Log(ex, "分类版本列表失败", ModBase.LogLevel.Feedback, "出现错误");
			}
			Dictionary<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>> dictionary4 = new Dictionary<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>>();
			ModMinecraft.McVersionCardType[] array = new ModMinecraft.McVersionCardType[]
			{
				ModMinecraft.McVersionCardType.Star,
				ModMinecraft.McVersionCardType.API,
				ModMinecraft.McVersionCardType.OriginalLike,
				ModMinecraft.McVersionCardType.Rubbish,
				ModMinecraft.McVersionCardType.Fool,
				ModMinecraft.McVersionCardType.Error,
				ModMinecraft.McVersionCardType.Hidden
			};
			checked
			{
				for (int j = 0; j < array.Length; j++)
				{
					string value2 = Conversions.ToString((int)array[j]);
					if (dictionary.ContainsKey((ModMinecraft.McVersionCardType)Conversions.ToInteger(value2)))
					{
						dictionary4.Add((ModMinecraft.McVersionCardType)Conversions.ToInteger(value2), dictionary[(ModMinecraft.McVersionCardType)Conversions.ToInteger(value2)]);
					}
				}
				dictionary = dictionary4;
				if (dictionary.ContainsKey(ModMinecraft.McVersionCardType.OriginalLike))
				{
					List<ModMinecraft.McVersion> list6 = dictionary[ModMinecraft.McVersionCardType.OriginalLike];
					ModMinecraft.McVersion mcVersion8 = null;
					try
					{
						foreach (ModMinecraft.McVersion mcVersion9 in list6)
						{
							if (mcVersion9._ClassProccesor == ModMinecraft.McVersionState.Snapshot)
							{
								mcVersion8 = mcVersion9;
								break;
							}
						}
					}
					finally
					{
						List<ModMinecraft.McVersion>.Enumerator enumerator7;
						((IDisposable)enumerator7).Dispose();
					}
					if (!Information.IsNothing(mcVersion8))
					{
						list6.Remove(mcVersion8);
					}
					List<ModMinecraft.McVersion> list7 = ModBase.Sort<ModMinecraft.McVersion>(list6, (ModMinecraft._Closure$__.$IR40-4 == null) ? (ModMinecraft._Closure$__.$IR40-4 = ((object a0, object a1) => ((ModMinecraft._Closure$__.$I40-0 == null) ? (ModMinecraft._Closure$__.$I40-0 = ((ModMinecraft.McVersion Left, ModMinecraft.McVersion Right) => Left.Version.tagParameter > Right.Version.tagParameter)) : ModMinecraft._Closure$__.$I40-0)((ModMinecraft.McVersion)a0, (ModMinecraft.McVersion)a1))) : ModMinecraft._Closure$__.$IR40-4);
					if (!Information.IsNothing(mcVersion8))
					{
						list7.Insert(0, mcVersion8);
					}
					dictionary[ModMinecraft.McVersionCardType.OriginalLike] = list7;
				}
				if (dictionary.ContainsKey(ModMinecraft.McVersionCardType.Rubbish))
				{
					dictionary[ModMinecraft.McVersionCardType.Rubbish] = ModBase.Sort<ModMinecraft.McVersion>(dictionary[ModMinecraft.McVersionCardType.Rubbish], (ModMinecraft._Closure$__.$IR40-5 == null) ? (ModMinecraft._Closure$__.$IR40-5 = ((object a0, object a1) => ((ModMinecraft._Closure$__.$I40-1 == null) ? (ModMinecraft._Closure$__.$I40-1 = delegate(ModMinecraft.McVersion Left, ModMinecraft.McVersion Right)
					{
						int year = Left.m_MappingProccesor.Year;
						int year2 = Right.m_MappingProccesor.Year;
						bool result;
						if (year > 2000 && year2 > 2000)
						{
							if (year != year2)
							{
								result = (year > year2);
							}
							else
							{
								result = (DateTime.Compare(Left.m_MappingProccesor, Right.m_MappingProccesor) > 0);
							}
						}
						else
						{
							result = ((year > 2000 && year2 < 2000) || ((year >= 2000 || year2 <= 2000) && Operators.CompareString(Left.Name, Right.Name, true) > 0));
						}
						return result;
					}) : ModMinecraft._Closure$__.$I40-1)((ModMinecraft.McVersion)a0, (ModMinecraft.McVersion)a1))) : ModMinecraft._Closure$__.$IR40-5);
				}
				if (dictionary.ContainsKey(ModMinecraft.McVersionCardType.API))
				{
					dictionary[ModMinecraft.McVersionCardType.API] = ModBase.Sort<ModMinecraft.McVersion>(dictionary[ModMinecraft.McVersionCardType.API], (ModMinecraft._Closure$__.$IR40-6 == null) ? (ModMinecraft._Closure$__.$IR40-6 = ((object a0, object a1) => ((ModMinecraft._Closure$__.$I40-2 == null) ? (ModMinecraft._Closure$__.$I40-2 = delegate(ModMinecraft.McVersion Left, ModMinecraft.McVersion Right)
					{
						int num2 = ModMinecraft.VersionSortInteger(Left.Version._ResolverParameter, Right.Version._ResolverParameter);
						bool result;
						if (num2 != 0)
						{
							result = (num2 > 0);
						}
						else if (Left.Version.stateParameter ^ Right.Version.stateParameter)
						{
							result = Left.Version.stateParameter;
						}
						else if (Left.Version.requestParameter ^ Right.Version.requestParameter)
						{
							result = Left.Version.requestParameter;
						}
						else if (Left.Version.ReadPrototype() == Right.Version.ReadPrototype())
						{
							result = (Left.Version.ReadPrototype() > Right.Version.ReadPrototype());
						}
						else
						{
							result = (Operators.CompareString(Left.Name, Right.Name, true) > 0);
						}
						return result;
					}) : ModMinecraft._Closure$__.$I40-2)((ModMinecraft.McVersion)a0, (ModMinecraft.McVersion)a1))) : ModMinecraft._Closure$__.$IR40-6);
				}
				ModBase.WriteIni(Path + "PCL.ini", "CardCount", Conversions.ToString(dictionary.Count));
				int num = dictionary.Count - 1;
				for (int k = 0; k <= num; k++)
				{
					ModBase.WriteIni(Path + "PCL.ini", "CardKey" + Conversions.ToString(k + 1), Conversions.ToString((int)dictionary.Keys.ElementAtOrDefault(k)));
					string text = "";
					try
					{
						foreach (ModMinecraft.McVersion mcVersion10 in dictionary.Values.ElementAtOrDefault(k))
						{
							text = text + mcVersion10.Name + ":";
						}
					}
					finally
					{
						List<ModMinecraft.McVersion>.Enumerator enumerator8;
						((IDisposable)enumerator8).Dispose();
					}
					ModBase.WriteIni(Path + "PCL.ini", "CardValue" + Conversions.ToString(k + 1), text);
				}
				return dictionary;
			}
		}

		// Token: 0x060009F8 RID: 2552 RVA: 0x0004E958 File Offset: 0x0004CB58
		private static void McVersionFilter(ref List<ModMinecraft.McVersion> VersionList, ref Dictionary<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>> Target, ModMinecraft.McVersionState[] Formula, ModMinecraft.McVersionCardType CardType)
		{
			List<ModMinecraft.McVersion> list = new List<ModMinecraft.McVersion>();
			checked
			{
				try
				{
					foreach (ModMinecraft.McVersion mcVersion in VersionList)
					{
						for (int i = 0; i < Formula.Length; i++)
						{
							if (Formula[i] == mcVersion._ClassProccesor)
							{
								list.Add(mcVersion);
								break;
							}
						}
					}
				}
				finally
				{
					List<ModMinecraft.McVersion>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				if (list.Count > 0)
				{
					Target.Add(CardType, list);
					try
					{
						foreach (ModMinecraft.McVersion item in list)
						{
							VersionList.Remove(item);
						}
					}
					finally
					{
						List<ModMinecraft.McVersion>.Enumerator enumerator2;
						((IDisposable)enumerator2).Dispose();
					}
				}
			}
		}

		// Token: 0x060009F9 RID: 2553 RVA: 0x0004EA28 File Offset: 0x0004CC28
		private static void McVersionFilter(ref List<ModMinecraft.McVersion> VersionList, ModMinecraft.McVersionState[] Formula, ref List<ModMinecraft.McVersion> KeepList)
		{
			checked
			{
				try
				{
					foreach (ModMinecraft.McVersion mcVersion in VersionList)
					{
						for (int i = 0; i < Formula.Length; i++)
						{
							if (Formula[i] == mcVersion._ClassProccesor)
							{
								KeepList.Add(mcVersion);
								break;
							}
						}
					}
				}
				finally
				{
					List<ModMinecraft.McVersion>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				if (KeepList.Count > 0)
				{
					try
					{
						foreach (ModMinecraft.McVersion item in KeepList)
						{
							VersionList.Remove(item);
						}
					}
					finally
					{
						List<ModMinecraft.McVersion>.Enumerator enumerator2;
						((IDisposable)enumerator2).Dispose();
					}
				}
			}
		}

		// Token: 0x060009FA RID: 2554 RVA: 0x0004EAE8 File Offset: 0x0004CCE8
		public static ModMinecraft.McSkinInfo McSkinSelect(bool MustHaveTwoLayers)
		{
			string text = ModBase.SelectFile("皮肤文件(*.png)|*.png", "选择皮肤文件");
			ModMinecraft.McSkinInfo result;
			if (Operators.CompareString(text, "", true) == 0)
			{
				result = new ModMinecraft.McSkinInfo
				{
					_CodeParameter = false
				};
			}
			else
			{
				try
				{
					MyBitmap myBitmap = new MyBitmap(text);
					if (!MustHaveTwoLayers)
					{
						if (myBitmap.templateAccount.Width == 64)
						{
							if (myBitmap.templateAccount.Height == 32 || myBitmap.templateAccount.Height == 64)
							{
								goto IL_100;
							}
						}
						ModMain.Hint("皮肤图片大小应为 64x32 像素或 64x64 像素！", ModMain.HintType.Critical, true);
						return new ModMinecraft.McSkinInfo
						{
							_CodeParameter = false
						};
					}
					if (myBitmap.templateAccount.Width == 64 && myBitmap.templateAccount.Height == 32)
					{
						ModMain.Hint("自定义离线皮肤只支持 64x64 像素的双层皮肤！", ModMain.HintType.Critical, true);
						return new ModMinecraft.McSkinInfo
						{
							_CodeParameter = false
						};
					}
					if (myBitmap.templateAccount.Width != 64 || myBitmap.templateAccount.Height != 64)
					{
						ModMain.Hint("自定义离线皮肤图片大小应为 64x64 像素！", ModMain.HintType.Critical, true);
						return new ModMinecraft.McSkinInfo
						{
							_CodeParameter = false
						};
					}
					IL_100:
					FileInfo fileInfo = new FileInfo(text);
					if (fileInfo.Length > 24576L)
					{
						ModMain.Hint("皮肤文件大小需小于 24 KB，而所选文件大小为 " + Conversions.ToString(Math.Round((double)fileInfo.Length / 1024.0, 2)) + " KB", ModMain.HintType.Critical, true);
						return new ModMinecraft.McSkinInfo
						{
							_CodeParameter = false
						};
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "皮肤文件存在错误", ModBase.LogLevel.Hint, "出现错误");
					return new ModMinecraft.McSkinInfo
					{
						_CodeParameter = false
					};
				}
				int num = ModMain.MyMsgBox("此皮肤为 Steve 模型（粗手臂）还是 Alex 模型（细手臂）？", "选择皮肤种类", "Steve 模型", "Alex 模型", "我不知道", false, false, false);
				if (num == 3)
				{
					ModMain.Hint("请在皮肤下载页面确认皮肤种类后再使用此皮肤！", ModMain.HintType.Info, true);
					result = new ModMinecraft.McSkinInfo
					{
						_CodeParameter = false
					};
				}
				else
				{
					result = new ModMinecraft.McSkinInfo
					{
						_CodeParameter = true,
						m_ReponseParameter = (num == 2),
						m_ContainerParameter = text
					};
				}
			}
			return result;
		}

		// Token: 0x060009FB RID: 2555 RVA: 0x0004ED3C File Offset: 0x0004CF3C
		public static string McSkinGetAddress(string Uuid, string Type)
		{
			if (Operators.CompareString(Uuid, "", true) == 0)
			{
				throw new Exception("Uuid 为空。");
			}
			if (Uuid.StartsWith("000000"))
			{
				throw new Exception("离线 Uuid 无正版皮肤文件。");
			}
			string text = ModBase.ReadIni(ModBase.attributeState + "Cache\\Skin\\Index" + Type + ".ini", Uuid, "");
			string result;
			if (Operators.CompareString(text, "", true) != 0)
			{
				result = text;
			}
			else
			{
				string str;
				if (Operators.CompareString(Type, "Mojang", true) != 0 && Operators.CompareString(Type, "Ms", true) != 0)
				{
					if (Operators.CompareString(Type, "Nide", true) == 0)
					{
						str = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("https://auth2.nide8.com:233/", (ModMinecraft._ValTag == null) ? ModBase._ParamsState.Get("CacheNideServer", null) : ModBase._ParamsState.Get("VersionServerNide", ModMinecraft._ValTag)), "/sessionserver/session/minecraft/profile/"));
					}
					else
					{
						if (Operators.CompareString(Type, "Auth", true) != 0)
						{
							throw new ArgumentException("皮肤地址种类无效：" + (Type ?? "null"));
						}
						str = Conversions.ToString(Operators.ConcatenateObject((ModMinecraft._ValTag == null) ? ModBase._ParamsState.Get("CacheAuthServerServer", null) : ModBase._ParamsState.Get("VersionServerAuthServer", ModMinecraft._ValTag), "/sessionserver/session/minecraft/profile/"));
					}
				}
				else
				{
					str = "https://sessionserver.mojang.com/session/minecraft/profile/";
				}
				object obj = RuntimeHelpers.GetObjectValue(ModNet.NetGetCodeByRequestRetry(str + Uuid, null, "", false));
				if (Operators.ConditionalCompareObjectEqual(obj, "", true))
				{
					throw new Exception("皮肤返回值为空，可能是未设置自定义皮肤的用户");
				}
				string text2;
				try
				{
					JObject jobject = (JObject)ModBase.GetJson(Conversions.ToString(obj));
					try
					{
						foreach (JToken jtoken in jobject["properties"])
						{
							if ((string)jtoken["name"] == "textures")
							{
								text2 = (string)jtoken["value"];
								goto IL_23D;
							}
						}
					}
					finally
					{
						IEnumerator<JToken> enumerator;
						if (enumerator != null)
						{
							enumerator.Dispose();
						}
					}
					throw new Exception("未从皮肤返回值中找到符合条件的 Property");
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, Conversions.ToString(Operators.ConcatenateObject("无法完成解析的皮肤返回值，可能是未设置自定义皮肤的用户：", obj)), ModBase.LogLevel.Developer, "出现错误");
					throw new Exception("皮肤返回值中不包含皮肤数据项，可能是未设置自定义皮肤的用户", ex);
				}
				IL_23D:
				obj = Encoding.GetEncoding("utf-8").GetString(Convert.FromBase64String(text2));
				try
				{
					text2 = ((JObject)ModBase.GetJson(Conversions.ToString(NewLateBinding.LateGet(obj, null, "ToLower", new object[0], null, null, null))))["textures"]["skin"]["url"].ToString();
				}
				catch (Exception ex2)
				{
					ModBase.Log(ex2, Conversions.ToString(Operators.ConcatenateObject("无法完成解析的皮肤解析值，可能是未设置自定义皮肤的用户：", obj)), ModBase.LogLevel.Developer, "出现错误");
					throw new Exception("皮肤解析值中不包含皮肤数据项，可能是未设置自定义皮肤的用户", ex2);
				}
				ModBase.WriteIni(ModBase.attributeState + "Cache\\Skin\\Index" + Type + ".ini", Uuid, text2);
				ModBase.Log("[Skin] UUID " + Uuid + " 对应的皮肤文件为 " + text2, ModBase.LogLevel.Normal, "出现错误");
				result = text2;
			}
			return result;
		}

		// Token: 0x060009FC RID: 2556 RVA: 0x0004F080 File Offset: 0x0004D280
		public static string McSkinDownload(string Address)
		{
			ModBase.GetFileNameFromPath(Address);
			string text = ModBase.attributeState + "Cache\\Skin\\" + Conversions.ToString(ModBase.GetHash(Address)) + ".png";
			object connectionTag = ModMinecraft.m_ConnectionTag;
			ObjectFlowControl.CheckForSyncLockOnValueType(connectionTag);
			string result;
			lock (connectionTag)
			{
				if (!File.Exists(text))
				{
					ModNet.NetDownload(Address, text + ".PCLDownloading");
					File.Delete(text);
					FileSystem.Rename(text + ".PCLDownloading", text);
					ModBase.Log("[Minecraft] 皮肤下载成功：" + text, ModBase.LogLevel.Normal, "出现错误");
				}
				result = text;
			}
			return result;
		}

		// Token: 0x060009FD RID: 2557 RVA: 0x0004F130 File Offset: 0x0004D330
		public static string McSkinSex(string Uuid)
		{
			string result;
			if (Uuid.Length != 32)
			{
				result = "Steve";
			}
			else
			{
				int num = int.Parse(Conversions.ToString(Uuid[7]), NumberStyles.AllowHexSpecifier);
				int num2 = int.Parse(Conversions.ToString(Uuid[15]), NumberStyles.AllowHexSpecifier);
				int num3 = int.Parse(Conversions.ToString(Uuid[23]), NumberStyles.AllowHexSpecifier);
				int num4 = int.Parse(Conversions.ToString(Uuid[31]), NumberStyles.AllowHexSpecifier);
				result = (((num ^ num2 ^ num3 ^ num4) % 2 != 0) ? "Alex" : "Steve");
			}
			return result;
		}

		// Token: 0x060009FE RID: 2558 RVA: 0x0004F1C8 File Offset: 0x0004D3C8
		public static bool McJsonRuleCheck(JToken RuleToken)
		{
			bool result;
			if (RuleToken == null)
			{
				result = true;
			}
			else
			{
				bool flag = false;
				try
				{
					foreach (JToken jtoken in RuleToken)
					{
						bool flag2 = true;
						if (jtoken["os"] != null)
						{
							if (jtoken["os"]["name"] != null)
							{
								string left = jtoken["os"]["name"].ToString();
								if (Operators.CompareString(left, "unknown", true) != 0)
								{
									if (Operators.CompareString(left, "windows", true) == 0)
									{
										if (jtoken["os"]["version"] != null)
										{
											string regex = jtoken["os"]["version"].ToString();
											flag2 = (flag2 && ModBase.RegexCheck(ModMinecraft.m_CustomerTag, regex, RegexOptions.None));
										}
									}
									else
									{
										flag2 = false;
									}
								}
							}
							if (jtoken["os"]["arch"] != null)
							{
								flag2 = (flag2 && Operators.CompareString(jtoken["os"]["arch"].ToString(), "x86", true) == 0 == ModBase.m_WriterState);
							}
						}
						if (!Information.IsNothing(jtoken["features"]))
						{
							flag2 = (flag2 && Information.IsNothing(jtoken["features"]["is_demo_user"]));
						}
						if (Operators.CompareString(jtoken["action"].ToString(), "allow", true) == 0)
						{
							if (flag2)
							{
								flag = true;
							}
						}
						else if (flag2)
						{
							flag = false;
						}
					}
				}
				finally
				{
					IEnumerator<JToken> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				result = flag;
			}
			return result;
		}

		// Token: 0x060009FF RID: 2559 RVA: 0x0004F390 File Offset: 0x0004D590
		public static List<ModMinecraft.McLibToken> McLibListGet(ModMinecraft.McVersion Version, bool IncludeVersionJar)
		{
			ModBase.Log("[Minecraft] 获取支持库列表：" + Version.Name, ModBase.LogLevel.Normal, "出现错误");
			List<ModMinecraft.McLibToken> list = ModMinecraft.McLibListGetWithJson(Version.DestroyPrototype(), false, null, Version.CreateComparator() + ".jumploader\\");
			if (IncludeVersionJar)
			{
				JToken jtoken = Version.DestroyPrototype()["jar"];
				string text = (jtoken != null) ? jtoken.ToString() : null;
				ModMinecraft.McVersion mcVersion;
				if (!Version.VerifyPrototype() && text != null)
				{
					mcVersion = new ModMinecraft.McVersion(text);
				}
				else
				{
					ModMinecraft.McVersion mcVersion2 = Version;
					while (Operators.CompareString(mcVersion2.PrintPrototype(), "", true) != 0 && Operators.CompareString(mcVersion2.PrintPrototype(), mcVersion2.Name, true) != 0)
					{
						mcVersion2 = new ModMinecraft.McVersion(ModMinecraft._MapperTag + "versions\\" + mcVersion2.PrintPrototype() + "\\");
					}
					mcVersion = new ModMinecraft.McVersion(mcVersion2.Path);
				}
				if (!File.Exists(mcVersion.Path + mcVersion.Name + ".json"))
				{
					mcVersion = Version;
					ModBase.Log("[Minecraft] 可能缺少前置版本 " + mcVersion.Name + "，找不到对应的 Json 文件", ModBase.LogLevel.Debug, "出现错误");
				}
				string value;
				string mockParameter;
				if (mcVersion.DestroyPrototype()["downloads"] != null && mcVersion.DestroyPrototype()["downloads"]["client"] != null)
				{
					value = (string)mcVersion.DestroyPrototype()["downloads"]["client"]["url"];
					mockParameter = (string)mcVersion.DestroyPrototype()["downloads"]["client"]["sha1"];
				}
				else
				{
					value = null;
					mockParameter = null;
				}
				List<ModMinecraft.McLibToken> list2 = list;
				ModMinecraft.McLibToken mcLibToken = new ModMinecraft.McLibToken();
				mcLibToken.tokenizerParameter = mcVersion.Path + mcVersion.Name + ".jar";
				mcLibToken._DefinitionParameter = 0L;
				mcLibToken.m_ParamsParameter = false;
				mcLibToken.MovePrototype(value);
				mcLibToken.m_MockParameter = mockParameter;
				list2.Add(mcLibToken);
			}
			return list;
		}

		// Token: 0x06000A00 RID: 2560 RVA: 0x0004F584 File Offset: 0x0004D784
		public static List<ModMinecraft.McLibToken> McLibListGetWithJson(JObject JsonObject, bool KeepSameNameDifferentVersionResult = false, string CustomMcFolder = null, string JumpLoaderFolder = null)
		{
			CustomMcFolder = (CustomMcFolder ?? ModMinecraft._MapperTag);
			List<ModMinecraft.McLibToken> list = new List<ModMinecraft.McLibToken>();
			JArray jarray = (JArray)JsonObject["libraries"];
			if (JsonObject["jumploader"] != null && JsonObject["jumploader"]["jars"] != null && JsonObject["jumploader"]["jars"]["maven"] != null)
			{
				try
				{
					foreach (JToken jtoken in JsonObject["jumploader"]["jars"]["maven"])
					{
						jarray.Add(jtoken);
					}
				}
				finally
				{
					IEnumerator<JToken> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
			}
			checked
			{
				try
				{
					foreach (JToken jtoken2 in jarray.Children())
					{
						JObject jobject = (JObject)jtoken2;
						if (ModMinecraft.McJsonRuleCheck(jobject["rules"]))
						{
							bool flag = false;
							if (jobject["mavenPath"] != null)
							{
								flag = true;
								if (jobject["name"] == null)
								{
									jobject.Add("name", jobject["mavenPath"]);
								}
								if (jobject["repoUrl"] != null && jobject["url"] == null)
								{
									jobject.Add("url", jobject["repoUrl"]);
								}
							}
							string text = (string)jobject["url"];
							if (text != null)
							{
								text += ModMinecraft.McLibGet((string)jobject["name"], false, true, CustomMcFolder).Replace("\\", "/");
							}
							if (jobject["natives"] == null)
							{
								string tokenizerParameter;
								if (flag)
								{
									tokenizerParameter = ModMinecraft.McLibGet((string)jobject["name"], true, false, JumpLoaderFolder ?? CustomMcFolder);
								}
								else
								{
									tokenizerParameter = ModMinecraft.McLibGet((string)jobject["name"], true, false, CustomMcFolder);
								}
								try
								{
									if (jobject["downloads"] != null && jobject["downloads"]["artifact"] != null)
									{
										List<ModMinecraft.McLibToken> list2 = list;
										ModMinecraft.McLibToken mcLibToken = new ModMinecraft.McLibToken();
										mcLibToken._SystemParameter = flag;
										mcLibToken.m_InitializerParameter = (string)jobject["name"];
										mcLibToken.MovePrototype((string)((text != null) ? text : jobject["downloads"]["artifact"]["url"]));
										mcLibToken.tokenizerParameter = ((jobject["downloads"]["artifact"]["path"] == null) ? ModMinecraft.McLibGet((string)jobject["name"], true, false, CustomMcFolder) : (CustomMcFolder + "libraries\\" + jobject["downloads"]["artifact"]["path"].ToString().Replace("/", "\\")));
										mcLibToken._DefinitionParameter = (long)Math.Round(ModBase.Val(jobject["downloads"]["artifact"]["size"].ToString()));
										mcLibToken.m_ParamsParameter = false;
										ModMinecraft.McLibToken mcLibToken2 = mcLibToken;
										JToken jtoken3 = jobject["downloads"]["artifact"]["sha1"];
										mcLibToken2.m_MockParameter = ((jtoken3 != null) ? jtoken3.ToString() : null);
										list2.Add(mcLibToken);
									}
									else
									{
										List<ModMinecraft.McLibToken> list3 = list;
										ModMinecraft.McLibToken mcLibToken3 = new ModMinecraft.McLibToken();
										mcLibToken3._SystemParameter = flag;
										mcLibToken3.m_InitializerParameter = (string)jobject["name"];
										mcLibToken3.MovePrototype(text);
										mcLibToken3.tokenizerParameter = tokenizerParameter;
										mcLibToken3._DefinitionParameter = 0L;
										mcLibToken3.m_ParamsParameter = false;
										mcLibToken3.m_MockParameter = null;
										list3.Add(mcLibToken3);
									}
									continue;
								}
								catch (Exception ex)
								{
									ModBase.Log(ex, "处理实际支持库列表失败（无 Natives，" + (jobject["name"] ?? "Nothing").ToString() + "）", ModBase.LogLevel.Debug, "出现错误");
									List<ModMinecraft.McLibToken> list4 = list;
									ModMinecraft.McLibToken mcLibToken4 = new ModMinecraft.McLibToken();
									mcLibToken4._SystemParameter = flag;
									mcLibToken4.m_InitializerParameter = (string)jobject["name"];
									mcLibToken4.MovePrototype(text);
									mcLibToken4.tokenizerParameter = tokenizerParameter;
									mcLibToken4._DefinitionParameter = 0L;
									mcLibToken4.m_ParamsParameter = false;
									mcLibToken4.m_MockParameter = null;
									list4.Add(mcLibToken4);
									continue;
								}
							}
							if (jobject["natives"]["windows"] != null)
							{
								try
								{
									if (jobject["downloads"] != null && jobject["downloads"]["classifiers"] != null && jobject["downloads"]["classifiers"]["natives-windows"] != null)
									{
										List<ModMinecraft.McLibToken> list5 = list;
										ModMinecraft.McLibToken mcLibToken5 = new ModMinecraft.McLibToken();
										mcLibToken5._SystemParameter = flag;
										mcLibToken5.m_InitializerParameter = (string)jobject["name"];
										mcLibToken5.MovePrototype((string)((text != null) ? text : jobject["downloads"]["classifiers"]["natives-windows"]["url"]));
										mcLibToken5.tokenizerParameter = ((jobject["downloads"]["classifiers"]["natives-windows"]["path"] == null) ? ModMinecraft.McLibGet((string)jobject["name"], true, false, CustomMcFolder).Replace(".jar", "-" + jobject["natives"]["windows"].ToString() + ".jar").Replace("${arch}", Environment.Is64BitOperatingSystem ? "64" : "32") : (CustomMcFolder + "libraries\\" + jobject["downloads"]["classifiers"]["natives-windows"]["path"].ToString().Replace("/", "\\")));
										mcLibToken5._DefinitionParameter = (long)Math.Round(ModBase.Val(jobject["downloads"]["classifiers"]["natives-windows"]["size"].ToString()));
										mcLibToken5.m_ParamsParameter = true;
										mcLibToken5.m_MockParameter = jobject["downloads"]["classifiers"]["natives-windows"]["sha1"].ToString();
										list5.Add(mcLibToken5);
									}
									else
									{
										List<ModMinecraft.McLibToken> list6 = list;
										ModMinecraft.McLibToken mcLibToken6 = new ModMinecraft.McLibToken();
										mcLibToken6._SystemParameter = flag;
										mcLibToken6.m_InitializerParameter = (string)jobject["name"];
										mcLibToken6.MovePrototype(text);
										mcLibToken6.tokenizerParameter = ModMinecraft.McLibGet((string)jobject["name"], true, false, CustomMcFolder).Replace(".jar", "-" + jobject["natives"]["windows"].ToString() + ".jar").Replace("${arch}", Environment.Is64BitOperatingSystem ? "64" : "32");
										mcLibToken6._DefinitionParameter = 0L;
										mcLibToken6.m_ParamsParameter = true;
										mcLibToken6.m_MockParameter = null;
										list6.Add(mcLibToken6);
									}
								}
								catch (Exception ex2)
								{
									ModBase.Log(ex2, "处理实际支持库列表失败（有 Natives，" + (jobject["name"] ?? "Nothing").ToString() + "）", ModBase.LogLevel.Debug, "出现错误");
									List<ModMinecraft.McLibToken> list7 = list;
									ModMinecraft.McLibToken mcLibToken7 = new ModMinecraft.McLibToken();
									mcLibToken7._SystemParameter = flag;
									mcLibToken7.m_InitializerParameter = (string)jobject["name"];
									mcLibToken7.MovePrototype(text);
									mcLibToken7.tokenizerParameter = ModMinecraft.McLibGet((string)jobject["name"], true, false, CustomMcFolder).Replace(".jar", "-" + jobject["natives"]["windows"].ToString() + ".jar").Replace("${arch}", Environment.Is64BitOperatingSystem ? "64" : "32");
									mcLibToken7._DefinitionParameter = 0L;
									mcLibToken7.m_ParamsParameter = true;
									mcLibToken7.m_MockParameter = null;
									list7.Add(mcLibToken7);
								}
							}
						}
					}
				}
				finally
				{
					IEnumerator<JToken> enumerator2;
					if (enumerator2 != null)
					{
						enumerator2.Dispose();
					}
				}
				Dictionary<string, ModMinecraft.McLibToken> dictionary = new Dictionary<string, ModMinecraft.McLibToken>();
				int num = list.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					string text2 = list[i].Name + list[i].m_ParamsParameter.ToString() + list[i]._SystemParameter.ToString();
					if (dictionary.ContainsKey(text2))
					{
						if (Operators.CompareString(list[i].Version, dictionary[text2].Version, true) != 0 && KeepSameNameDifferentVersionResult)
						{
							dictionary.Add(text2 + Conversions.ToString(ModBase.GetUuid()), list[i]);
						}
						else if (ModMinecraft.VersionSortBoolean(list[i].Version, dictionary[text2].Version))
						{
							dictionary[text2] = list[i];
						}
					}
					else
					{
						dictionary.Add(text2, list[i]);
					}
				}
				return dictionary.Values.ToList<ModMinecraft.McLibToken>();
			}
		}

		// Token: 0x06000A01 RID: 2561 RVA: 0x0004FFA0 File Offset: 0x0004E1A0
		public static List<ModNet.NetFile> McLibFix(ModMinecraft.McVersion Version, bool CoreJarOnly = false)
		{
			if (!Version._WrapperParameter)
			{
				Version.Load();
			}
			List<ModNet.NetFile> list = new List<ModNet.NetFile>();
			try
			{
				ModNet.NetFile netFile = ModDownload.DlClientJarGet(Version, true);
				if (netFile != null)
				{
					list.Add(netFile);
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "版本缺失主 Jar 文件所必须的信息", ModBase.LogLevel.Developer, "出现错误");
			}
			List<ModNet.NetFile> result;
			if (CoreJarOnly)
			{
				result = list;
			}
			else
			{
				bool flag = Conversions.ToBoolean(ModBase._ParamsState.Get("LaunchAdvanceAssets", null));
				object left = ModBase._ParamsState.Get("VersionAdvanceAssets", Version);
				if (!Operators.ConditionalCompareObjectEqual(left, 0, true))
				{
					if (Operators.ConditionalCompareObjectEqual(left, 1, true))
					{
						flag = false;
					}
					else if (Operators.ConditionalCompareObjectEqual(left, 2, true))
					{
						flag = true;
					}
				}
				list.AddRange(ModMinecraft.McLibFixFromLibToken(ModMinecraft.McLibListGet(Version, false), null, Version.CreateComparator() + ".jumploader\\", flag));
				if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("VersionServerLogin", Version), 3, true))
				{
					string text = Version.CreateComparator() + "nide8auth.jar";
					ModBase.FileChecker fileChecker = new ModBase.FileChecker(173000L, -1L, null, true, false);
					if ((flag && File.Exists(text)) || fileChecker.Check(text) != null)
					{
						list.Add(new ModNet.NetFile(new string[]
						{
							"https://login2.nide8.com:233/index/jar"
						}, text, fileChecker));
					}
				}
				if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("VersionServerLogin", Version), 4, true))
				{
					string text2 = Version.CreateComparator() + "authlib-injector.jar";
					ModBase.FileChecker fileChecker2 = new ModBase.FileChecker(250000L, -1L, null, true, false);
					if ((flag && File.Exists(text2)) || fileChecker2.Check(text2) != null)
					{
						string text3 = "https://bmclapi2.bangbang93.com/mirrors/authlib-injector/artifact/38/authlib-injector-1.1.38.jar";
						try
						{
							ModBase.Log("[Minecraft] 开始获取 Authlib-Injector 下载地址", ModBase.LogLevel.Normal, "出现错误");
							text3 = (((JObject)ModBase.GetJson(ModNet.NetGetCodeByDownload(new string[]
							{
								"https://download.mcbbs.net/mirrors/authlib-injector/artifact/latest.json",
								"https://bmclapi2.bangbang93.com/mirrors/authlib-injector/artifact/latest.json"
							}, 45000, true)))["download_url"] ?? text3).ToString();
							ModBase.Log("[Minecraft] 最新版 Authlib-Injector 下载地址：" + text3, ModBase.LogLevel.Normal, "出现错误");
						}
						catch (Exception ex2)
						{
							ModBase.Log("获取 Authlib-Injector 下载地址失败", ModBase.LogLevel.Hint, "出现错误");
						}
						list.Add(new ModNet.NetFile(new string[]
						{
							text3.Replace("bmclapi2.bangbang93.com", "download.mcbbs.net"),
							text3
						}, text2, new ModBase.FileChecker(250000L, -1L, null, true, false)));
					}
				}
				result = list;
			}
			return result;
		}

		// Token: 0x06000A02 RID: 2562 RVA: 0x00050268 File Offset: 0x0004E468
		public static List<ModNet.NetFile> McLibFixFromLibToken(List<ModMinecraft.McLibToken> Libs, string CustomMcFolder = null, string JumpLoaderFolder = null, bool AllowUnsameFile = false)
		{
			CustomMcFolder = (CustomMcFolder ?? ModMinecraft._MapperTag);
			List<ModNet.NetFile> list = new List<ModNet.NetFile>();
			try
			{
				foreach (ModMinecraft.McLibToken mcLibToken in Libs)
				{
					ModBase.FileChecker fileChecker;
					if (AllowUnsameFile)
					{
						fileChecker = new ModBase.FileChecker(1L, -1L, null, true, false);
					}
					else
					{
						fileChecker = new ModBase.FileChecker(-1L, (mcLibToken._DefinitionParameter == 0L) ? -1L : mcLibToken._DefinitionParameter, mcLibToken.m_MockParameter, true, false);
					}
					if (fileChecker.Check(mcLibToken.tokenizerParameter) != null)
					{
						List<string> list2 = new List<string>();
						if (mcLibToken.CallPrototype() != null)
						{
							string text = mcLibToken.CallPrototype();
							text = text.Replace("https://files.minecraftforge.net", "http://files.minecraftforge.net");
							list2.Add(text);
							if (mcLibToken.CallPrototype().Contains("launcher.mojang.com/v1/objects"))
							{
								list2 = ModDownload.DlSourceLauncherOrMetaGet(mcLibToken.CallPrototype(), true).ToList<string>();
							}
							if (mcLibToken.CallPrototype().Contains("maven"))
							{
								list2.Insert(0, mcLibToken.CallPrototype().Replace(Strings.Mid(mcLibToken.CallPrototype(), 1, mcLibToken.CallPrototype().IndexOf("maven")), "https://download.mcbbs.net/").Replace("maven.fabricmc.net", "maven").Replace("maven.minecraftforge.net", "maven"));
							}
						}
						if (mcLibToken.tokenizerParameter.Contains("transformer-discovery-service"))
						{
							if (!File.Exists(mcLibToken.tokenizerParameter))
							{
								ModBase.WriteFile(mcLibToken.tokenizerParameter, ModBase.GetResources("Transformer"), false);
							}
							ModBase.Log("[Download] 已自动释放 Transformer Discovery Service", ModBase.LogLevel.Developer, "出现错误");
						}
						else
						{
							if (mcLibToken.tokenizerParameter.Contains("optifine\\OptiFine"))
							{
								string text2 = mcLibToken.tokenizerParameter.Replace((mcLibToken._SystemParameter ? JumpLoaderFolder : CustomMcFolder) + "libraries\\optifine\\OptiFine\\", "").Split(new char[]
								{
									'_'
								})[0] + "/" + ModBase.GetFileNameFromPath(mcLibToken.tokenizerParameter).Replace("-", "_");
								text2 = "/maven/com/optifine/" + text2;
								if (text2.Contains("_pre"))
								{
									text2 = text2.Replace("com/optifine/", "com/optifine/preview_");
								}
								list2.Add("http://download.mcbbs.net" + text2);
								list2.Add("http://bmclapi2.bangbang93.com" + text2);
							}
							else if (list2.Count <= 2)
							{
								list2.AddRange(ModDownload.DlSourceLibraryGet("https://libraries.minecraft.net" + mcLibToken.tokenizerParameter.Replace((mcLibToken._SystemParameter ? JumpLoaderFolder : CustomMcFolder) + "libraries", "").Replace("\\", "/")));
							}
							list.Add(new ModNet.NetFile(ModBase.ArrayNoDouble<string>(list2.ToArray(), null), mcLibToken.tokenizerParameter, fileChecker));
						}
					}
				}
			}
			finally
			{
				List<ModMinecraft.McLibToken>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			return ModBase.ArrayNoDouble<ModNet.NetFile>(list, (ModMinecraft._Closure$__.$IR56-7 == null) ? (ModMinecraft._Closure$__.$IR56-7 = ((object a0, object a1) => ((ModMinecraft._Closure$__.$I56-0 == null) ? (ModMinecraft._Closure$__.$I56-0 = ((ModNet.NetFile Left, ModNet.NetFile Right) => Operators.CompareString(Left.m_ModelProccesor, Right.m_ModelProccesor, true) == 0)) : ModMinecraft._Closure$__.$I56-0)((ModNet.NetFile)a0, (ModNet.NetFile)a1))) : ModMinecraft._Closure$__.$IR56-7);
		}

		// Token: 0x06000A03 RID: 2563 RVA: 0x000505A8 File Offset: 0x0004E7A8
		public static string McLibGet(string Original, bool WithHead = true, bool IgnoreLiteLoader = false, string CustomMcFolder = null)
		{
			CustomMcFolder = (CustomMcFolder ?? ModMinecraft._MapperTag);
			string[] array = Original.Split(new char[]
			{
				':'
			});
			string text = string.Concat(new string[]
			{
				WithHead ? (CustomMcFolder + "libraries\\") : "",
				array[0].Replace(".", "\\"),
				"\\",
				array[1],
				"\\",
				array[2],
				"\\",
				array[1],
				"-",
				array[2],
				".jar"
			});
			if (text.Contains("optifine\\OptiFine\\1.12") && File.Exists(string.Concat(new string[]
			{
				CustomMcFolder,
				"libraries\\",
				array[0].Replace(".", "\\"),
				"\\",
				array[1],
				"\\",
				array[2],
				"\\",
				array[1],
				"-",
				array[2],
				"-installer.jar"
			})))
			{
				ModBase.Log("[Launch] 已将 " + Original + " 特判替换为对应的 Installer 文件", ModBase.LogLevel.Debug, "出现错误");
				text = text.Replace(".jar", "-installer.jar");
			}
			return text;
		}

		// Token: 0x06000A04 RID: 2564 RVA: 0x00050704 File Offset: 0x0004E904
		public static JToken McAssetsGetIndex(ModMinecraft.McVersion Version, bool ReturnLegacyOnError = false, bool CheckURLEmpty = false)
		{
			try
			{
				JToken jtoken;
				for (;;)
				{
					jtoken = Version.DestroyPrototype()["assetIndex"];
					if (jtoken != null && jtoken["id"] != null)
					{
						break;
					}
					if (Version.DestroyPrototype()["assets"] != null)
					{
						Version.DestroyPrototype()["assets"].ToString();
					}
					if (CheckURLEmpty && jtoken["url"] != null)
					{
						goto IL_8E;
					}
					if (Operators.CompareString(Version.PrintPrototype(), "", true) == 0)
					{
						goto IL_92;
					}
					Version = new ModMinecraft.McVersion(ModMinecraft._MapperTag + "versions\\" + Version.PrintPrototype());
				}
				return jtoken;
				IL_8E:
				return jtoken;
				IL_92:;
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "获取资源文件索引下载地址失败", ModBase.LogLevel.Debug, "出现错误");
			}
			if (!ReturnLegacyOnError)
			{
				throw new Exception("该版本不存在资源文件索引信息");
			}
			ModBase.Log("[Minecraft] 无法获取资源文件索引下载地址，使用缺省的 legacy 下载地址", ModBase.LogLevel.Normal, "出现错误");
			return (JToken)ModBase.GetJson("\r\n                    {\r\n                        \"id\": \"legacy\",\r\n                        \"sha1\": \"c0fd82e8ce9fbc93119e40d96d5a4e62cfa3f729\",\r\n                        \"size\": 134284,\r\n                        \"url\": \"https://launchermeta.mojang.com/mc-staging/assets/legacy/c0fd82e8ce9fbc93119e40d96d5a4e62cfa3f729/legacy.json\",\r\n                        \"totalSize\": 111220701\r\n                    }");
		}

		// Token: 0x06000A05 RID: 2565 RVA: 0x00050808 File Offset: 0x0004EA08
		public static string McAssetsGetIndexName(ModMinecraft.McVersion Version)
		{
			try
			{
				while (Version.DestroyPrototype()["assetIndex"] == null || Version.DestroyPrototype()["assetIndex"]["id"] == null)
				{
					if (Version.DestroyPrototype()["assets"] != null)
					{
						return Version.DestroyPrototype()["assets"].ToString();
					}
					if (Operators.CompareString(Version.PrintPrototype(), "", true) == 0)
					{
						goto IL_CC;
					}
					Version = new ModMinecraft.McVersion(ModMinecraft._MapperTag + "versions\\" + Version.PrintPrototype());
				}
				return Version.DestroyPrototype()["assetIndex"]["id"].ToString();
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "获取资源文件索引名失败", ModBase.LogLevel.Debug, "出现错误");
			}
			IL_CC:
			return "legacy";
		}

		// Token: 0x06000A06 RID: 2566 RVA: 0x000508F8 File Offset: 0x0004EAF8
		private static List<ModMinecraft.McAssetsToken> McAssetsListGet(string Name)
		{
			List<ModMinecraft.McAssetsToken> list;
			try
			{
				if (!File.Exists(ModMinecraft._MapperTag + "assets\\indexes\\" + Name + ".json"))
				{
					throw new FileNotFoundException("Assets 索引文件未找到", ModMinecraft._MapperTag + "assets\\indexes\\" + Name + ".json");
				}
				list = new List<ModMinecraft.McAssetsToken>();
				object objectValue = RuntimeHelpers.GetObjectValue(ModBase.GetJson(ModBase.ReadFile(ModMinecraft._MapperTag + "assets\\indexes\\" + Name + ".json")));
				bool flag = false;
				if (NewLateBinding.LateIndexGet(objectValue, new object[]
				{
					"virtual"
				}, null) != null)
				{
					flag = Conversions.ToBoolean(NewLateBinding.LateIndexGet(objectValue, new object[]
					{
						"virtual"
					}, null).ToString());
				}
				bool flag2 = false;
				if (NewLateBinding.LateIndexGet(objectValue, new object[]
				{
					"map_to_resources"
				}, null) != null)
				{
					flag2 = Conversions.ToBoolean(NewLateBinding.LateIndexGet(objectValue, new object[]
					{
						"map_to_resources"
					}, null).ToString());
				}
				if (!flag && !flag2)
				{
					try
					{
						foreach (object obj in ((IEnumerable)NewLateBinding.LateGet(NewLateBinding.LateIndexGet(objectValue, new object[]
						{
							"objects"
						}, null), null, "Children", new object[0], null, null, null)))
						{
							JProperty jproperty = (JProperty)obj;
							list.Add(new ModMinecraft.McAssetsToken
							{
								specificationParameter = false,
								m_WriterParameter = string.Concat(new string[]
								{
									ModMinecraft._MapperTag,
									"assets\\objects\\",
									Strings.Left(jproperty.Value["hash"].ToString(), 2),
									"\\",
									jproperty.Value["hash"].ToString()
								}),
								_BroadcasterParameter = jproperty.Name,
								_PredicateParameter = jproperty.Value["hash"].ToString(),
								m_AttributeParameter = Conversions.ToLong(jproperty.Value["size"].ToString())
							});
						}
						goto IL_31A;
					}
					finally
					{
						IEnumerator enumerator;
						if (enumerator is IDisposable)
						{
							(enumerator as IDisposable).Dispose();
						}
					}
				}
				try
				{
					foreach (object obj2 in ((IEnumerable)NewLateBinding.LateGet(NewLateBinding.LateIndexGet(objectValue, new object[]
					{
						"objects"
					}, null), null, "Children", new object[0], null, null, null)))
					{
						JProperty jproperty2 = (JProperty)obj2;
						list.Add(new ModMinecraft.McAssetsToken
						{
							specificationParameter = true,
							m_WriterParameter = ModMinecraft._MapperTag + "assets\\virtual\\legacy\\" + jproperty2.Name.Replace("/", "\\"),
							_BroadcasterParameter = jproperty2.Name,
							_PredicateParameter = jproperty2.Value["hash"].ToString(),
							m_AttributeParameter = Conversions.ToLong(jproperty2.Value["size"].ToString())
						});
					}
				}
				finally
				{
					IEnumerator enumerator2;
					if (enumerator2 is IDisposable)
					{
						(enumerator2 as IDisposable).Dispose();
					}
				}
				IL_31A:;
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "获取资源文件列表失败：" + Name, ModBase.LogLevel.Debug, "出现错误");
				throw;
			}
			return list;
		}

		// Token: 0x06000A07 RID: 2567 RVA: 0x00050C90 File Offset: 0x0004EE90
		public static List<ModNet.NetFile> McAssetsFixList(string IndexAddress, bool CheckHash, ref ModLoader.LoaderBase ProgressFeed = null)
		{
			List<ModNet.NetFile> list = new List<ModNet.NetFile>();
			checked
			{
				try
				{
					List<ModMinecraft.McAssetsToken> list2 = ModMinecraft.McAssetsListGet(IndexAddress);
					if (ProgressFeed != null)
					{
						ProgressFeed.Progress = 0.04;
					}
					int num = list2.Count - 1;
					for (int i = 0; i <= num; i++)
					{
						ModMinecraft.McAssetsToken mcAssetsToken = list2[i];
						if (ProgressFeed != null)
						{
							ProgressFeed.Progress = unchecked(0.05 + 0.94 * (double)i / (double)list2.Count);
						}
						FileInfo fileInfo = new FileInfo(mcAssetsToken.m_WriterParameter);
						if (!fileInfo.Exists || (mcAssetsToken.m_AttributeParameter != 0L && mcAssetsToken.m_AttributeParameter != fileInfo.Length) || (CheckHash && mcAssetsToken._PredicateParameter != null && Operators.CompareString(mcAssetsToken._PredicateParameter, ModBase.smethod_1(mcAssetsToken.m_WriterParameter), true) != 0))
						{
							list.Add(new ModNet.NetFile(ModDownload.DlSourceResourceGet("http://resources.download.minecraft.net/" + Strings.Left(mcAssetsToken._PredicateParameter, 2) + "/" + mcAssetsToken._PredicateParameter), mcAssetsToken.m_WriterParameter, new ModBase.FileChecker(-1L, (mcAssetsToken.m_AttributeParameter == 0L) ? -1L : mcAssetsToken.m_AttributeParameter, mcAssetsToken._PredicateParameter, true, false)));
						}
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "获取版本缺失的资源文件下载列表失败", ModBase.LogLevel.Debug, "出现错误");
				}
				if (ProgressFeed != null)
				{
					ProgressFeed.Progress = 0.99;
				}
				return list;
			}
		}

		// Token: 0x06000A08 RID: 2568 RVA: 0x00050E20 File Offset: 0x0004F020
		private static void McModLoad(ModLoader.LoaderTask<string, List<ModMinecraft.McMod>> Loader)
		{
			try
			{
				ModBase.RunInUiWait((ModMinecraft._Closure$__.$I65-0 == null) ? (ModMinecraft._Closure$__.$I65-0 = delegate()
				{
					if (ModMain.m_MessageAccount != null)
					{
						ModMain.m_MessageAccount.Load.ShowProgress = false;
					}
				}) : ModMinecraft._Closure$__.$I65-0);
				List<FileInfo> list = new List<FileInfo>();
				if (Directory.Exists(Loader.Input))
				{
					try
					{
						foreach (FileInfo fileInfo in new DirectoryInfo(Loader.Input).EnumerateFiles("*.*", SearchOption.AllDirectories))
						{
							string text = fileInfo.DirectoryName.ToLower();
							if (!text.StartsWith(Loader.Input + "memory_repo") && (Operators.CompareString(text + "\\", Loader.Input, true) == 0 || !text.Contains("voxel")) && Conversions.ToBoolean(ModMinecraft.McMod.IsModFile(fileInfo.FullName)))
							{
								list.Add(fileInfo);
							}
						}
					}
					finally
					{
						IEnumerator<FileInfo> enumerator;
						if (enumerator != null)
						{
							enumerator.Dispose();
						}
					}
				}
				Loader.Progress = 0.03;
				if (list.Count > 100)
				{
					ModBase.RunInUi((ModMinecraft._Closure$__.$I65-1 == null) ? (ModMinecraft._Closure$__.$I65-1 = delegate()
					{
						if (ModMain.m_MessageAccount != null)
						{
							ModMain.m_MessageAccount.Load.ShowProgress = true;
						}
					}) : ModMinecraft._Closure$__.$I65-1, false);
				}
				List<ModMinecraft.McMod> list2 = new List<ModMinecraft.McMod>();
				try
				{
					foreach (FileInfo fileInfo2 in list)
					{
						ModMinecraft.McMod mcMod = new ModMinecraft.McMod(fileInfo2.FullName);
						mcMod.Load(false);
						list2.Add(mcMod);
						Loader.Progress += 0.9 / (double)list.Count;
					}
				}
				finally
				{
					List<FileInfo>.Enumerator enumerator2;
					((IDisposable)enumerator2).Dispose();
				}
				Loader.Progress = 0.93;
				list2 = ModBase.Sort<ModMinecraft.McMod>(list2, (ModMinecraft._Closure$__.$IR65-8 == null) ? (ModMinecraft._Closure$__.$IR65-8 = ((object a0, object a1) => ((ModMinecraft._Closure$__.$I65-2 == null) ? (ModMinecraft._Closure$__.$I65-2 = delegate(ModMinecraft.McMod Left, ModMinecraft.McMod Right)
				{
					bool result;
					if (Left.State == ModMinecraft.McMod.McModState.Unavaliable != (Right.State == ModMinecraft.McMod.McModState.Unavaliable))
					{
						result = (Left.State == ModMinecraft.McMod.McModState.Unavaliable);
					}
					else
					{
						result = (Operators.CompareString(Left.GetPrototype(), Right.GetPrototype(), true) < 0);
					}
					return result;
				}) : ModMinecraft._Closure$__.$I65-2)((ModMinecraft.McMod)a0, (ModMinecraft.McMod)a1))) : ModMinecraft._Closure$__.$IR65-8);
				Loader.Progress = 0.98;
				if (!Loader.IsAborted)
				{
					Loader.Output = list2;
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "Mod 列表加载失败", ModBase.LogLevel.Debug, "出现错误");
				throw;
			}
		}

		// Token: 0x06000A09 RID: 2569 RVA: 0x00051088 File Offset: 0x0004F288
		public static void McDownloadClientUpdateHint(string VersionName, JObject Json)
		{
			try
			{
				JToken jtoken = null;
				try
				{
					foreach (JToken jtoken2 in Json["versions"])
					{
						if (jtoken2["id"] != null && Operators.CompareString(jtoken2["id"].ToString(), VersionName, true) == 0)
						{
							jtoken = jtoken2;
							break;
						}
					}
				}
				finally
				{
					IEnumerator<JToken> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				if (jtoken != null)
				{
					DateTime dateTime = (DateTime)jtoken["releaseTime"];
					int num;
					if ((DateTime.Now - dateTime).TotalDays > 1.0)
					{
						num = ModMain.MyMsgBox("新版本：" + VersionName + "\r\n更新时间：" + dateTime.ToString(), "Minecraft 更新提示", "下载", "更新日志", "取消", false, true, false);
					}
					else if ((DateTime.Now - dateTime).TotalHours > 3.0)
					{
						num = ModMain.MyMsgBox("新版本：" + VersionName + "\r\n更新于：" + ModBase.GetTimeSpanString(dateTime - DateTime.Now), "Minecraft 更新提示", "下载", "更新日志", "取消", false, true, false);
					}
					else
					{
						num = ModMain.MyMsgBox("新版本：" + VersionName + "\r\n更新于：" + ModBase.GetTimeSpanString(dateTime - DateTime.Now), "Minecraft 更新提示", "下载", "取消", "", false, true, false);
						if (num == 2)
						{
							num = 3;
						}
					}
					if (num != 1)
					{
						if (num == 2)
						{
							ModDownloadLib.McUpdateLogShow(jtoken);
						}
					}
					else
					{
						ModDownloadLib.McDownloadClient(ModNet.NetPreDownloadBehaviour.HintWhileExists, VersionName, jtoken["url"].ToString());
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "Minecraft 更新提示发送失败（" + (VersionName ?? "Nothing") + "）", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000A0A RID: 2570 RVA: 0x00006D1C File Offset: 0x00004F1C
		public static bool VersionSortBoolean(string Left, string Right)
		{
			return ModMinecraft.VersionSortInteger(Left, Right) >= 0;
		}

		// Token: 0x06000A0B RID: 2571 RVA: 0x0005129C File Offset: 0x0004F49C
		public static int VersionSortInteger(string Left, string Right)
		{
			if (Operators.CompareString(Left, "未知版本", true) == 0 || Operators.CompareString(Right, "未知版本", true) == 0)
			{
				if (Operators.CompareString(Left, "未知版本", true) == 0 && Operators.CompareString(Right, "未知版本", true) != 0)
				{
					return 1;
				}
				if (Operators.CompareString(Left, "未知版本", true) == 0 && Operators.CompareString(Right, "未知版本", true) == 0)
				{
					return 0;
				}
				if (Operators.CompareString(Left, "未知版本", true) != 0 && Operators.CompareString(Right, "未知版本", true) == 0)
				{
					return -1;
				}
			}
			List<string> list = ModBase.RegexSearch(Left.ToLower(), "[a-z]+|[0-9]+", RegexOptions.None);
			List<string> list2 = ModBase.RegexSearch(Right.ToLower(), "[a-z]+|[0-9]+", RegexOptions.None);
			int num = 0;
			checked
			{
				while (list.Count - 1 >= num || list2.Count - 1 >= num)
				{
					string text = (list.Count - 1 < num) ? "-1" : list[num];
					string text2 = (list2.Count - 1 < num) ? "-1" : list2[num];
					if (Operators.CompareString(text, text2, true) != 0)
					{
						if (Operators.CompareString(text, "pre", true) == 0 || Operators.CompareString(text, "snapshot", true) == 0)
						{
							text = "-3";
						}
						if (Operators.CompareString(text, "rc", true) == 0)
						{
							text = "-2";
						}
						if (Operators.CompareString(text, "experimental", true) == 0)
						{
							text = "-4";
						}
						double num2 = ModBase.Val(text);
						if (Operators.CompareString(text2, "pre", true) == 0 || Operators.CompareString(text2, "snapshot", true) == 0)
						{
							text2 = "-3";
						}
						if (Operators.CompareString(text2, "rc", true) == 0)
						{
							text2 = "-2";
						}
						if (Operators.CompareString(text2, "experimental", true) == 0)
						{
							text2 = "-4";
						}
						double num3 = ModBase.Val(text2);
						if (num2 == 0.0 && num3 == 0.0)
						{
							if (Operators.CompareString(text, text2, true) > 0)
							{
								return 1;
							}
							if (Operators.CompareString(text, text2, true) < 0)
							{
								return -1;
							}
						}
						else
						{
							if (num2 > num3)
							{
								return 1;
							}
							if (num2 < num3)
							{
								return -1;
							}
						}
					}
					num++;
				}
				int result;
				if (Operators.CompareString(Left, Right, true) > 0)
				{
					result = 1;
				}
				else if (Operators.CompareString(Left, Right, true) < 0)
				{
					result = -1;
				}
				else
				{
					result = 0;
				}
				return result;
			}
		}

		// Token: 0x06000A0C RID: 2572 RVA: 0x000514F0 File Offset: 0x0004F6F0
		public static string AccountFilter(string Account)
		{
			string result;
			if (Account.Contains("@"))
			{
				string[] array = Account.Split(new char[]
				{
					'@'
				});
				result = "".PadLeft(array[0].Count<char>(), '*') + "@" + array[1];
			}
			else if (Account.Count<char>() >= 6)
			{
				result = Strings.Mid(Account, 1, checked(Account.Count<char>() - 4)) + "****";
			}
			else
			{
				result = "".PadLeft(Account.Count<char>(), '*');
			}
			return result;
		}

		// Token: 0x06000A0D RID: 2573 RVA: 0x0005157C File Offset: 0x0004F77C
		public static string ArgumentReplace(string Raw)
		{
			string result;
			if (Raw == null)
			{
				result = null;
			}
			else
			{
				Raw = Raw.Replace("{user}", Information.IsNothing(ModLaunch.m_IndexerTag.Output) ? "尚未登录" : ModLaunch.m_IndexerTag.Output.Name);
				if (Information.IsNothing(ModLaunch.m_IndexerTag.Input))
				{
					Raw = Raw.Replace("{login}", "尚未登录");
				}
				else
				{
					switch (ModLaunch.m_IndexerTag.Input.Type)
					{
					case ModLaunch.McLoginType.Legacy:
						Raw = Raw.Replace("{login}", "离线");
						break;
					case ModLaunch.McLoginType.Mojang:
						Raw = Raw.Replace("{login}", "Mojang 正版");
						break;
					case ModLaunch.McLoginType.Nide:
						Raw = Raw.Replace("{login}", "统一通行证");
						break;
					case ModLaunch.McLoginType.Auth:
						Raw = Raw.Replace("{login}", "Authlib-Injector");
						break;
					case ModLaunch.McLoginType.Ms:
						Raw = Raw.Replace("{login}", "微软正版");
						break;
					}
				}
				if (ModMinecraft._ValTag == null)
				{
					Raw = Raw.Replace("{name}", "无可用版本");
					Raw = Raw.Replace("{version}", "无可用版本");
				}
				else
				{
					Raw = Raw.Replace("{name}", ModMinecraft._ValTag.Name);
					if (!ModMinecraft._ValTag._WrapperParameter)
					{
						ModMinecraft._ValTag.Load();
					}
					Raw = Raw.Replace("{version}", ModMinecraft._ValTag.Version._ResolverParameter);
				}
				Raw = Raw.Replace("{path}", ModBase.Path);
				result = Raw;
			}
			return result;
		}

		// Token: 0x0400051B RID: 1307
		public static int m_ObjectTag = 1;

		// Token: 0x0400051C RID: 1308
		public static List<ModMinecraft.JavaEntry> _RegTag;

		// Token: 0x0400051D RID: 1309
		private static string _InvocationTag = null;

		// Token: 0x0400051E RID: 1310
		public static ModLoader.LoaderTask<int, int> composerTag = new ModLoader.LoaderTask<int, int>("Java Search Loader", new Action<ModLoader.LoaderTask<int, int>>(ModMinecraft.JavaSearchLoaderSub), null, ThreadPriority.Normal);

		// Token: 0x0400051F RID: 1311
		public static string _ItemTag = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\";

		// Token: 0x04000520 RID: 1312
		public static string _MapperTag;

		// Token: 0x04000521 RID: 1313
		public static List<ModMinecraft.McFolder> _FactoryTag = new List<ModMinecraft.McFolder>();

		// Token: 0x04000522 RID: 1314
		public static ModLoader.LoaderTask<int, int> _ProcessTag = new ModLoader.LoaderTask<int, int>("Minecraft Folder List", delegate(ModLoader.LoaderTask<int, int> a0)
		{
			ModMinecraft.McFolderListLoadSub();
		}, null, ThreadPriority.AboveNormal);

		// Token: 0x04000523 RID: 1315
		private static ModMinecraft.McVersion _ValTag;

		// Token: 0x04000524 RID: 1316
		private static ModMinecraft.McVersion m_UtilsTag = 0;

		// Token: 0x04000525 RID: 1317
		public static Dictionary<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>> _OrderTag = new Dictionary<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>>();

		// Token: 0x04000526 RID: 1318
		public static bool _PolicyTag = false;

		// Token: 0x04000527 RID: 1319
		public static ModLoader.LoaderTask<string, int> threadTag = new ModLoader.LoaderTask<string, int>("Minecraft Version List", new Action<ModLoader.LoaderTask<string, int>>(ModMinecraft.McVersionListLoad), null, ThreadPriority.Normal)
		{
			ReloadTimeout = 1
		};

		// Token: 0x04000528 RID: 1320
		private static readonly object m_ConnectionTag = RuntimeHelpers.GetObjectValue(new object());

		// Token: 0x04000529 RID: 1321
		private static string m_CustomerTag = MyWpfExtension.FindModel().Info.OSVersion;

		// Token: 0x0400052A RID: 1322
		public static ModLoader.LoaderTask<string, List<ModMinecraft.McMod>> schemaTag = new ModLoader.LoaderTask<string, List<ModMinecraft.McMod>>("Mod List Loader", new Action<ModLoader.LoaderTask<string, List<ModMinecraft.McMod>>>(ModMinecraft.McModLoad), null, ThreadPriority.Normal);

		// Token: 0x02000110 RID: 272
		public class JavaEntry
		{
			// Token: 0x06000A0E RID: 2574 RVA: 0x00006D2B File Offset: 0x00004F2B
			public string StartComparator()
			{
				return this.m_ListProccesor + "java.exe";
			}

			// Token: 0x06000A0F RID: 2575 RVA: 0x00006D3D File Offset: 0x00004F3D
			public string RegisterComparator()
			{
				return this.m_ListProccesor + "javaw.exe";
			}

			// Token: 0x06000A10 RID: 2576 RVA: 0x00006D4F File Offset: 0x00004F4F
			public int DeleteComparator()
			{
				return this.m_AnnotationProccesor.Minor;
			}

			// Token: 0x06000A11 RID: 2577 RVA: 0x00051714 File Offset: 0x0004F914
			public bool InitComparator()
			{
				return this.m_ListProccesor != null && ModMinecraft.RevertRepository() != null && ModMinecraft.RevertRepository().Replace("\\", "").Replace("/", "").ToLower().Contains(this.m_ListProccesor.Replace("\\", "").ToLower());
			}

			// Token: 0x06000A12 RID: 2578 RVA: 0x00051780 File Offset: 0x0004F980
			public JObject ToJson()
			{
				return new JObject(new object[]
				{
					new JProperty("Path", this.m_ListProccesor),
					new JProperty("VersionString", this.m_AnnotationProccesor.ToString()),
					new JProperty("IsJre", this.m_InterceptorProccesor),
					new JProperty("Is64Bit", this._RefProccesor),
					new JProperty("IsUserImport", this._MethodProccesor)
				});
			}

			// Token: 0x06000A13 RID: 2579 RVA: 0x0005180C File Offset: 0x0004FA0C
			public static ModMinecraft.JavaEntry FromJson(JObject Data)
			{
				return new ModMinecraft.JavaEntry((string)Data["Path"], (bool)Data["IsUserImport"])
				{
					m_AnnotationProccesor = new Version((string)Data["VersionString"]),
					m_InterceptorProccesor = (bool)Data["IsJre"],
					_RefProccesor = (bool)Data["Is64Bit"]
				};
			}

			// Token: 0x06000A14 RID: 2580 RVA: 0x00051888 File Offset: 0x0004FA88
			public override string ToString()
			{
				string text = this.m_AnnotationProccesor.ToString();
				if (text.StartsWith("1."))
				{
					text = Strings.Mid(text, 3);
				}
				return string.Concat(new string[]
				{
					this.m_InterceptorProccesor ? "Java " : "JDK ",
					Conversions.ToString(this.DeleteComparator()),
					" (",
					text,
					")，",
					this._RefProccesor ? "64" : "32",
					" 位",
					this._MethodProccesor ? "，手动导入" : "",
					"：",
					this.m_ListProccesor
				});
			}

			// Token: 0x06000A15 RID: 2581 RVA: 0x00051944 File Offset: 0x0004FB44
			public JavaEntry(string Folder, bool IsUserImport)
			{
				this.IsChecked = false;
				if (!Folder.EndsWith("\\"))
				{
					Folder += "\\";
				}
				this.m_ListProccesor = Folder.Replace("/", "\\");
				this._MethodProccesor = IsUserImport;
			}

			// Token: 0x06000A16 RID: 2582 RVA: 0x00051998 File Offset: 0x0004FB98
			public void Check()
			{
				if (!this.IsChecked)
				{
					string text = null;
					try
					{
						if (!File.Exists(this.RegisterComparator()))
						{
							throw new FileNotFoundException("未找到 javaw.exe 文件", this.RegisterComparator());
						}
						if (!File.Exists(this.m_ListProccesor + "java.exe"))
						{
							throw new FileNotFoundException("未找到 java.exe 文件", this.m_ListProccesor + "java.exe");
						}
						this.m_InterceptorProccesor = !File.Exists(this.m_ListProccesor + "javac.exe");
						text = ModBase.ShellAndGetOutput(this.m_ListProccesor + "java.exe", "-version", 8000, null).ToLower();
						if (ModBase._EventState)
						{
							ModBase.Log("[Java] Java 检查输出：" + this.m_ListProccesor + "java.exe\r\n" + text, ModBase.LogLevel.Normal, "出现错误");
						}
						string text2;
						if ((text2 = ModBase.RegexSeek(text, "(?<=version \")[^\"]+", RegexOptions.None)) == null)
						{
							text2 = (ModBase.RegexSeek(text, "(?<=openjdk )[0-9]+", RegexOptions.None) ?? "");
						}
						string text3 = text2.Replace("_", ".").Split(new char[]
						{
							'-'
						}).First<string>();
						while (text3.Split(new char[]
						{
							'.'
						}).Count<string>() < 4)
						{
							if (text3.StartsWith("1."))
							{
								text3 += ".0";
							}
							else
							{
								text3 = "1." + text3;
							}
						}
						this.m_AnnotationProccesor = new Version(text3);
						if (this.m_AnnotationProccesor.Minor == 0)
						{
							ModBase.Log("[Java] 疑似 X.0.X.X 格式版本号：" + this.m_AnnotationProccesor.ToString(), ModBase.LogLevel.Normal, "出现错误");
							this.m_AnnotationProccesor = new Version(1, this.m_AnnotationProccesor.Major, this.m_AnnotationProccesor.Build, this.m_AnnotationProccesor.Revision);
						}
						this._RefProccesor = text.Contains("64-bit");
						if (this.m_AnnotationProccesor.Minor <= 6 || this.m_AnnotationProccesor.Minor >= 25)
						{
							throw new Exception("分析详细信息失败，获取的版本为 " + this.m_AnnotationProccesor.ToString());
						}
					}
					catch (Exception ex)
					{
						ModBase.Log("[Java] 检查失败的 Java 输出：" + this.m_ListProccesor + "java.exe\r\n" + (text ?? "无程序输出"), ModBase.LogLevel.Normal, "出现错误");
						ex = new Exception("检查 Java 详细信息失败（" + (this.RegisterComparator() ?? "Nothing") + "）", ex);
						throw ex;
					}
					this.IsChecked = true;
				}
			}

			// Token: 0x0400052B RID: 1323
			public string m_ListProccesor;

			// Token: 0x0400052C RID: 1324
			public bool _MethodProccesor;

			// Token: 0x0400052D RID: 1325
			public Version m_AnnotationProccesor;

			// Token: 0x0400052E RID: 1326
			public bool m_InterceptorProccesor;

			// Token: 0x0400052F RID: 1327
			public bool _RefProccesor;

			// Token: 0x04000530 RID: 1328
			private bool IsChecked;
		}

		// Token: 0x02000111 RID: 273
		public class McFolder
		{
			// Token: 0x06000A19 RID: 2585 RVA: 0x00051C28 File Offset: 0x0004FE28
			public override bool Equals(object obj)
			{
				bool result;
				if (!(obj is ModMinecraft.McFolder))
				{
					result = false;
				}
				else
				{
					ModMinecraft.McFolder mcFolder = (ModMinecraft.McFolder)obj;
					result = (Operators.CompareString(this.Name, mcFolder.Name, true) == 0 && Operators.CompareString(this.Path, mcFolder.Path, true) == 0 && this.Type == mcFolder.Type && this.serverProccesor == mcFolder.serverProccesor);
				}
				return result;
			}

			// Token: 0x06000A1A RID: 2586 RVA: 0x00006D5C File Offset: 0x00004F5C
			public override string ToString()
			{
				return this.Path;
			}

			// Token: 0x04000531 RID: 1329
			public string Name;

			// Token: 0x04000532 RID: 1330
			public string Path;

			// Token: 0x04000533 RID: 1331
			public ModMinecraft.McFolderType Type;

			// Token: 0x04000534 RID: 1332
			public int serverProccesor;
		}

		// Token: 0x02000112 RID: 274
		public enum McFolderType
		{
			// Token: 0x04000536 RID: 1334
			Original,
			// Token: 0x04000537 RID: 1335
			RenamedOriginal,
			// Token: 0x04000538 RID: 1336
			Custom
		}

		// Token: 0x02000113 RID: 275
		public class McVersion
		{
			// Token: 0x17000165 RID: 357
			// (get) Token: 0x06000A1C RID: 2588 RVA: 0x00006D64 File Offset: 0x00004F64
			public string Path { get; }

			// Token: 0x06000A1D RID: 2589 RVA: 0x00006D6C File Offset: 0x00004F6C
			public string CreateComparator()
			{
				return this.GetPathIndie(this.Version.CalculatePrototype());
			}

			// Token: 0x06000A1E RID: 2590 RVA: 0x00051C94 File Offset: 0x0004FE94
			public string GetPathIndie(bool Modable)
			{
				int num = Conversions.ToInteger(ModBase._ParamsState.Get("LaunchArgumentIndie", null));
				object left = ModBase._ParamsState.Get("VersionArgumentIndie", this);
				if (Operators.ConditionalCompareObjectEqual(left, -1, true))
				{
					DirectoryInfo directoryInfo = new DirectoryInfo(this.Path + "mods\\");
					DirectoryInfo directoryInfo2 = new DirectoryInfo(this.Path + "saves\\");
					if ((directoryInfo.Exists && directoryInfo.EnumerateFiles().Count<FileInfo>() > 0) || (directoryInfo2.Exists && directoryInfo2.EnumerateFiles().Count<FileInfo>() > 0))
					{
						ModBase._ParamsState.Set("VersionArgumentIndie", 1, false, this);
						ModBase.Log("[Setup] 已自动开启单版本隔离：" + this.Name, ModBase.LogLevel.Normal, "出现错误");
						goto IL_1C1;
					}
					ModBase._ParamsState.Set("VersionArgumentIndie", 0, false, this);
					ModBase.Log("[Setup] 版本隔离使用全局设置：" + this.Name, ModBase.LogLevel.Normal, "出现错误");
				}
				else if (!Operators.ConditionalCompareObjectEqual(left, 0, true))
				{
					if (Operators.ConditionalCompareObjectEqual(left, 1, true))
					{
						goto IL_1C1;
					}
					if (Operators.ConditionalCompareObjectEqual(left, 2, true))
					{
						goto IL_1B0;
					}
				}
				switch (num)
				{
				case 1:
					if (Modable)
					{
						return this.Path;
					}
					break;
				case 2:
					if (this._ClassProccesor == ModMinecraft.McVersionState.Fool || this._ClassProccesor == ModMinecraft.McVersionState.Old || this._ClassProccesor == ModMinecraft.McVersionState.Snapshot)
					{
						return this.Path;
					}
					break;
				case 3:
					if (Modable)
					{
						return this.Path;
					}
					if (this._ClassProccesor != ModMinecraft.McVersionState.Fool && this._ClassProccesor != ModMinecraft.McVersionState.Old)
					{
						if (this._ClassProccesor != ModMinecraft.McVersionState.Snapshot)
						{
							break;
						}
					}
					return this.Path;
				case 4:
					IL_1C1:
					return this.Path;
				}
				IL_1B0:
				return ModMinecraft._MapperTag;
			}

			// Token: 0x17000166 RID: 358
			// (get) Token: 0x06000A1F RID: 2591 RVA: 0x00006D7F File Offset: 0x00004F7F
			public string Name
			{
				get
				{
					if (this._ImporterProccesor == null && Operators.CompareString(this.Path, "", true) != 0)
					{
						this._ImporterProccesor = ModBase.GetFolderNameFromPath(this.Path);
					}
					return this._ImporterProccesor;
				}
			}

			// Token: 0x17000167 RID: 359
			// (get) Token: 0x06000A20 RID: 2592 RVA: 0x00051E6C File Offset: 0x0005006C
			// (set) Token: 0x06000A21 RID: 2593 RVA: 0x00006DB3 File Offset: 0x00004FB3
			public ModMinecraft.McVersionInfo Version
			{
				get
				{
					if (this.setterProccesor == null)
					{
						this.setterProccesor = new ModMinecraft.McVersionInfo();
						try
						{
							try
							{
								if (this.DestroyPrototype()["releaseTime"] == null)
								{
									this.m_MappingProccesor = new DateTime(1970, 1, 1, 15, 0, 0);
								}
								else
								{
									this.m_MappingProccesor = this.DestroyPrototype()["releaseTime"].ToObject<DateTime>();
								}
								if (this.m_MappingProccesor.Year > 2000 && this.m_MappingProccesor.Year < 2013)
								{
									this.setterProccesor._ResolverParameter = "Old";
									goto IL_3B7;
								}
							}
							catch (Exception ex)
							{
								this.m_MappingProccesor = new DateTime(1970, 1, 1, 15, 0, 0);
							}
							if ((string)(this.DestroyPrototype()["type"] ?? "") == "pending")
							{
								this.setterProccesor._ResolverParameter = "pending";
							}
							else
							{
								if (this.AwakePrototype())
								{
									try
									{
										this.setterProccesor._ResolverParameter = (string)this.DestroyPrototype()["jumploader"]["jars"]["minecraft"][0]["gameVersion"];
										goto IL_3B7;
									}
									catch (Exception ex2)
									{
									}
								}
								if (this.DestroyPrototype()["clientVersion"] != null)
								{
									this.setterProccesor._ResolverParameter = (string)this.DestroyPrototype()["clientVersion"];
								}
								else if (Operators.CompareString(this.PrintPrototype(), "", true) != 0)
								{
									this.setterProccesor._ResolverParameter = (this.DestroyPrototype()["jar"] ?? "").ToString();
									if (Operators.CompareString(this.setterProccesor._ResolverParameter, "", true) == 0)
									{
										this.setterProccesor._ResolverParameter = this.PrintPrototype();
									}
								}
								else
								{
									List<string> list = ModBase.RegexSearch((this.DestroyPrototype()["downloads"] ?? "").ToString(), "(?<=launcher.mojang.com/mc/game/)[^/]*", RegexOptions.None);
									if (list.Count != 0)
									{
										this.setterProccesor._ResolverParameter = list[0];
									}
									else
									{
										string str = this.DestroyPrototype()["libraries"].ToString();
										list = ModBase.RegexSearch(str, "(?<=net.minecraftforge:forge:)[^-]*", RegexOptions.None);
										if (list.Count != 0)
										{
											this.setterProccesor._ResolverParameter = list[0];
										}
										else
										{
											list = ModBase.RegexSearch(str, "(?<=((fabricmc)|(quiltmc)):intermediary:)[^\"]*", RegexOptions.None);
											if (list.Count != 0)
											{
												this.setterProccesor._ResolverParameter = list[0];
											}
											else
											{
												ModBase.Log("[Minecraft] 无法完全确认 MC 版本号的版本：" + this.Name, ModBase.LogLevel.Normal, "出现错误");
												list = ModBase.RegexSearch(this.Name, "([0-9w]{5}[a-z]{1})|(1\\.[0-9]+(\\.[0-9]+)?(-(pre|rc)[1-9]?| Pre-Release( [1-9]{1})?)?)", RegexOptions.None);
												if (list.Count != 0)
												{
													this.setterProccesor._ResolverParameter = list[0];
												}
												else
												{
													JObject jobject = (JObject)this.DestroyPrototype().DeepClone();
													jobject.Remove("libraries");
													list = ModBase.RegexSearch(jobject.ToString(), "([0-9w]{5}[a-z]{1})|(1\\.[0-9]+(\\.[0-9]+)?(-(pre|rc)[1-9]?| Pre-Release( [1-9]{1})?)?)", RegexOptions.None);
													if (list.Count != 0)
													{
														this.setterProccesor._ResolverParameter = list[0];
													}
													else
													{
														this.setterProccesor._ResolverParameter = "Unknown";
														this.proxyProccesor = "PCL 无法识别该版本，请向作者反馈此问题";
													}
												}
											}
										}
									}
								}
							}
						}
						catch (Exception ex3)
						{
							ModBase.Log(ex3, "识别 Minecraft 版本时出错", ModBase.LogLevel.Debug, "出现错误");
							this.setterProccesor._ResolverParameter = "Unknown";
							this.proxyProccesor = "无法识别：" + ex3.Message;
						}
						IL_3B7:
						if (this.setterProccesor._ResolverParameter.StartsWith("1."))
						{
							string[] array = this.setterProccesor._ResolverParameter.Split(new char[]
							{
								' ',
								'_',
								'-',
								'.'
							});
							string text = (array.Count<string>() >= 2) ? array[1] : "0";
							this.setterProccesor.tagParameter = Conversions.ToInteger((text.Length <= 2) ? ModBase.Val(text) : "0");
							text = ((array.Count<string>() >= 3) ? array[2] : "0");
							this.setterProccesor.m_ComparatorParameter = Conversions.ToInteger((text.Length <= 2) ? ModBase.Val(text) : "0");
						}
						else if (this.setterProccesor._ResolverParameter.Contains("w") || Operators.CompareString(this.setterProccesor._ResolverParameter, "pending", true) == 0)
						{
							this.setterProccesor.tagParameter = 99;
							this.setterProccesor.m_ComparatorParameter = 99;
						}
					}
					return this.setterProccesor;
				}
				set
				{
					this.setterProccesor = value;
				}
			}

			// Token: 0x06000A22 RID: 2594 RVA: 0x00052390 File Offset: 0x00050590
			public string SetupPrototype()
			{
				if (this.m_DispatcherProccesor == null)
				{
					if (!File.Exists(this.Path + this.Name + ".json"))
					{
						throw new Exception("未找到版本 Json 文件");
					}
					this.m_DispatcherProccesor = ModBase.ReadFile(this.Path + this.Name + ".json");
					if (this.m_DispatcherProccesor.Length == 0)
					{
						if (ModBase.RunInUi())
						{
							ModBase.Log("[Minecraft] 版本 Json 文件为空或读取失败，由于代码在主线程运行，将不再进行重试", ModBase.LogLevel.Debug, "出现错误");
							throw new Exception("版本 Json 文件为空或读取失败");
						}
						ModBase.Log("[Minecraft] 版本 Json 文件为空或读取失败，将在 1s 后重试读取（" + this.Path + this.Name + ".json）", ModBase.LogLevel.Debug, "出现错误");
						Thread.Sleep(1000);
						this.m_DispatcherProccesor = ModBase.ReadFile(this.Path + this.Name + ".json");
						if (this.m_DispatcherProccesor.Length == 0)
						{
							throw new Exception("版本 Json 文件为空或读取失败");
						}
					}
					if (this.m_DispatcherProccesor.Length < 100)
					{
						throw new Exception("版本 Json 文件有误，内容为：" + this.m_DispatcherProccesor);
					}
				}
				return this.m_DispatcherProccesor;
			}

			// Token: 0x06000A23 RID: 2595 RVA: 0x00006DBC File Offset: 0x00004FBC
			public void FindPrototype(string value)
			{
				this.m_DispatcherProccesor = value;
			}

			// Token: 0x06000A24 RID: 2596 RVA: 0x000524B8 File Offset: 0x000506B8
			public JObject DestroyPrototype()
			{
				if (this.messageProccesor == null)
				{
					string text = this.SetupPrototype();
					try
					{
						this.messageProccesor = (JObject)ModBase.GetJson(text);
						if (this.messageProccesor.ContainsKey("patches") && !this.messageProccesor.ContainsKey("time"))
						{
							this.ResolvePrototype(true);
							JObject jobject = null;
							List<JObject> list = new List<JObject>();
							try
							{
								foreach (JToken jtoken in this.messageProccesor["patches"])
								{
									JObject item = (JObject)jtoken;
									list.Add(item);
								}
							}
							finally
							{
								IEnumerator<JToken> enumerator;
								if (enumerator != null)
								{
									enumerator.Dispose();
								}
							}
							list = ModBase.Sort<JObject>(list, (ModMinecraft.McVersion._Closure$__.$IR24-1 == null) ? (ModMinecraft.McVersion._Closure$__.$IR24-1 = ((object a0, object a1) => ((ModMinecraft.McVersion._Closure$__.$I24-0 == null) ? (ModMinecraft.McVersion._Closure$__.$I24-0 = ((JObject Left, JObject Right) => ModBase.Val((Left["priority"] ?? "0").ToString()) < ModBase.Val((Right["priority"] ?? "0").ToString()))) : ModMinecraft.McVersion._Closure$__.$I24-0)((JObject)a0, (JObject)a1))) : ModMinecraft.McVersion._Closure$__.$IR24-1);
							try
							{
								foreach (JObject jobject2 in list)
								{
									string text2 = (string)jobject2["id"];
									if (text2 != null)
									{
										ModBase.Log("[Minecraft] 合并 HMCL 分支项：" + text2, ModBase.LogLevel.Normal, "出现错误");
										if (jobject != null)
										{
											jobject.Merge(jobject2);
										}
										else
										{
											jobject = jobject2;
										}
									}
									else
									{
										ModBase.Log("[Minecraft] 存在为空的 HMCL 分支项", ModBase.LogLevel.Normal, "出现错误");
									}
								}
							}
							finally
							{
								List<JObject>.Enumerator enumerator2;
								((IDisposable)enumerator2).Dispose();
							}
							this.messageProccesor = jobject;
							this.messageProccesor["id"] = this.Name;
							if (this.messageProccesor.ContainsKey("inheritsFrom"))
							{
								this.messageProccesor.Remove("inheritsFrom");
							}
						}
						object obj = null;
						try
						{
							obj = ((this.messageProccesor["inheritsFrom"] == null) ? "" : this.messageProccesor["inheritsFrom"].ToString());
							if (Operators.ConditionalCompareObjectEqual(obj, this.Name, true))
							{
								ModBase.Log("[Minecraft] 自引用的继承版本：" + this.Name, ModBase.LogLevel.Debug, "出现错误");
								obj = "";
							}
							else
							{
								while (Operators.ConditionalCompareObjectNotEqual(obj, "", true))
								{
									ModMinecraft.McVersion mcVersion = new ModMinecraft.McVersion(Conversions.ToString(obj));
									if (Operators.ConditionalCompareObjectEqual(mcVersion.PrintPrototype(), obj, true))
									{
										throw new Exception(Conversions.ToString(Operators.ConcatenateObject("版本依赖项出现嵌套：", obj)));
									}
									obj = mcVersion.PrintPrototype();
									mcVersion.DestroyPrototype().Merge(this.messageProccesor);
									this.messageProccesor = mcVersion.DestroyPrototype();
								}
							}
						}
						catch (Exception ex)
						{
							ModBase.Log(ex, "合并版本依赖项 Json 失败（" + (obj ?? "null").ToString() + "）", ModBase.LogLevel.Debug, "出现错误");
						}
					}
					catch (Exception innerException)
					{
						throw new Exception("版本 Json 不规范（" + (this.Name ?? "null") + "）", innerException);
					}
					try
					{
						if (text.Contains("minecraftforge") && File.Exists(this.CreateComparator() + "config\\jumploader.json"))
						{
							try
							{
								foreach (string filePath in Directory.EnumerateFiles(this.CreateComparator() + "mods"))
								{
									string text3 = ModBase.GetFileNameFromPath(filePath).ToLower();
									if (text3.EndsWith(".jar") && text3.Contains("jumploader"))
									{
										ModBase.Log("[Minecraft] 发现 JumpLoader 分支项：" + text3, ModBase.LogLevel.Normal, "出现错误");
										this.SortPrototype(true);
										break;
									}
								}
							}
							finally
							{
								IEnumerator<string> enumerator3;
								if (enumerator3 != null)
								{
									enumerator3.Dispose();
								}
							}
						}
						if (this.AwakePrototype())
						{
							this.messageProccesor.Remove("jumploader");
							this.messageProccesor.Add("jumploader", (JToken)ModBase.GetJson(ModBase.ReadFile(this.CreateComparator() + "config\\jumploader.json")));
						}
					}
					catch (Exception ex2)
					{
						ModBase.Log(ex2, "处理 JumpLoader 失败", ModBase.LogLevel.Debug, "出现错误");
					}
				}
				return this.messageProccesor;
			}

			// Token: 0x06000A25 RID: 2597 RVA: 0x00006DC5 File Offset: 0x00004FC5
			public void ClonePrototype(JObject value)
			{
				this.messageProccesor = value;
			}

			// Token: 0x06000A26 RID: 2598 RVA: 0x00006DCE File Offset: 0x00004FCE
			public bool PopPrototype()
			{
				return this.DestroyPrototype()["minecraftArguments"] != null;
			}

			// Token: 0x06000A27 RID: 2599 RVA: 0x00006DE3 File Offset: 0x00004FE3
			[CompilerGenerated]
			public bool VerifyPrototype()
			{
				return this.statusProccesor;
			}

			// Token: 0x06000A28 RID: 2600 RVA: 0x00006DEB File Offset: 0x00004FEB
			[CompilerGenerated]
			public void ResolvePrototype(bool AutoPropertyValue)
			{
				this.statusProccesor = AutoPropertyValue;
			}

			// Token: 0x06000A29 RID: 2601 RVA: 0x00006DF4 File Offset: 0x00004FF4
			[CompilerGenerated]
			public bool AwakePrototype()
			{
				return this.procProccesor;
			}

			// Token: 0x06000A2A RID: 2602 RVA: 0x00006DFC File Offset: 0x00004FFC
			[CompilerGenerated]
			public void SortPrototype(bool AutoPropertyValue)
			{
				this.procProccesor = AutoPropertyValue;
			}

			// Token: 0x06000A2B RID: 2603 RVA: 0x00052948 File Offset: 0x00050B48
			public string PrintPrototype()
			{
				if (this.modelParameter == null)
				{
					this.modelParameter = (this.DestroyPrototype()["inheritsFrom"] ?? "").ToString();
					if (this.SetupPrototype().Contains("liteloader") && Operators.CompareString(this.Version._ResolverParameter, this.Name, true) != 0 && !this.SetupPrototype().Contains("logging") && Operators.CompareString((this.DestroyPrototype()["jar"] ?? this.Version._ResolverParameter).ToString(), this.Version._ResolverParameter, true) == 0)
					{
						this.modelParameter = this.Version._ResolverParameter;
					}
					if (this.VerifyPrototype())
					{
						this.modelParameter = "";
					}
				}
				return this.modelParameter;
			}

			// Token: 0x06000A2C RID: 2604 RVA: 0x00052A2C File Offset: 0x00050C2C
			public McVersion(string Path)
			{
				this._ImporterProccesor = null;
				this.proxyProccesor = "该版本未被加载，请向作者反馈此问题";
				this._ClassProccesor = ModMinecraft.McVersionState.Error;
				this._ProducerProccesor = false;
				this.m_CandidateProccesor = ModMinecraft.McVersionCardType.Auto;
				this.setterProccesor = null;
				this.m_MappingProccesor = new DateTime(1970, 1, 1, 15, 0, 0);
				this.m_DispatcherProccesor = null;
				this.messageProccesor = null;
				this.ResolvePrototype(false);
				this.SortPrototype(false);
				this.modelParameter = null;
				this._WrapperParameter = false;
				this.Path = (Path.Contains(":") ? "" : (ModMinecraft._MapperTag + "versions\\")) + Path + (Path.EndsWith("\\") ? "" : "\\");
			}

			// Token: 0x06000A2D RID: 2605 RVA: 0x00052AF8 File Offset: 0x00050CF8
			public bool Check()
			{
				bool result;
				if (!Directory.Exists(this.Path))
				{
					this._ClassProccesor = ModMinecraft.McVersionState.Error;
					this.proxyProccesor = "该文件夹不存在";
					result = false;
				}
				else
				{
					try
					{
						Directory.CreateDirectory(this.Path + "PCL\\");
						ModBase.CheckPermissionWithException(this.Path + "PCL\\");
					}
					catch (Exception ex)
					{
						this._ClassProccesor = ModMinecraft.McVersionState.Error;
						this.proxyProccesor = "PCL2 没有对该文件夹的访问权限，请右键以管理员身份运行 PCL2";
						ModBase.Log(ex, "没有访问版本文件夹的权限", ModBase.LogLevel.Debug, "出现错误");
						return false;
					}
					try
					{
						this.DestroyPrototype();
					}
					catch (Exception ex2)
					{
						ModBase.Log(ex2, "版本 Json 可用性检查失败（" + this.Name + "）", ModBase.LogLevel.Debug, "出现错误");
						this.FindPrototype("");
						this.ClonePrototype(null);
						this.proxyProccesor = ex2.Message;
						this._ClassProccesor = ModMinecraft.McVersionState.Error;
						return false;
					}
					try
					{
						if (Operators.CompareString(this.PrintPrototype(), "", true) != 0 && !File.Exists(string.Concat(new string[]
						{
							ModBase.GetPathFromFullPath(this.Path),
							this.PrintPrototype(),
							"\\",
							this.PrintPrototype(),
							".json"
						})))
						{
							this._ClassProccesor = ModMinecraft.McVersionState.Error;
							this.proxyProccesor = "需要安装 " + this.PrintPrototype() + " 作为前置版本";
							return false;
						}
					}
					catch (Exception ex3)
					{
						ModBase.Log(ex3, "依赖版本检查出错（" + this.Name + "）", ModBase.LogLevel.Debug, "出现错误");
						this._ClassProccesor = ModMinecraft.McVersionState.Error;
						this.proxyProccesor = "未知错误：" + ModBase.GetString(ex3, true, false);
						return false;
					}
					this._ClassProccesor = ModMinecraft.McVersionState.Original;
					result = true;
				}
				return result;
			}

			// Token: 0x06000A2E RID: 2606 RVA: 0x00052CF4 File Offset: 0x00050EF4
			public ModMinecraft.McVersion Load()
			{
				try
				{
					Directory.CreateDirectory(this.Path + "PCL");
					if (this.Check())
					{
						string resolverParameter = this.Version._ResolverParameter;
						if (Operators.CompareString(resolverParameter, "Unknown", true) == 0)
						{
							this._ClassProccesor = ModMinecraft.McVersionState.Error;
						}
						else if (Operators.CompareString(resolverParameter, "Old", true) == 0)
						{
							this._ClassProccesor = ModMinecraft.McVersionState.Old;
						}
						else
						{
							string text = (this.DestroyPrototype() ?? this.SetupPrototype()).ToString();
							if (Operators.CompareString((this.DestroyPrototype()["type"] ?? "").ToString(), "fool", true) != 0 && Operators.CompareString(ModMinecraft.GetMcFoolName(this.Name), "", true) == 0)
							{
								if (this.Version._ResolverParameter.ToLower().Contains("w") || this.Name.ToLower().Contains("combat") || this.Version._ResolverParameter.ToLower().Contains("rc") || this.Version._ResolverParameter.ToLower().Contains("pre") || this.Version._ResolverParameter.Contains("experimental") || Operators.CompareString((this.DestroyPrototype()["type"] ?? "").ToString(), "snapshot", true) == 0 || Operators.CompareString((this.DestroyPrototype()["type"] ?? "").ToString(), "pending", true) == 0)
								{
									this._ClassProccesor = ModMinecraft.McVersionState.Snapshot;
								}
							}
							else
							{
								this._ClassProccesor = ModMinecraft.McVersionState.Fool;
							}
							if (text.Contains("optifine"))
							{
								this._ClassProccesor = ModMinecraft.McVersionState.OptiFine;
								this.Version.m_IssuerParameter = (ModBase.RegexSeek(text, "(?<=HD_U_)[^\":/]+", RegexOptions.None) ?? "未知版本");
								this.Version.m_PrototypeParameter = true;
							}
							if (text.Contains("liteloader"))
							{
								this._ClassProccesor = ModMinecraft.McVersionState.LiteLoader;
								this.Version._ParameterParameter = true;
							}
							if (!text.Contains("net.fabricmc:fabric-loader") && !text.Contains("org.quiltmc:quilt-loader"))
							{
								if (text.Contains("minecraftforge"))
								{
									this._ClassProccesor = ModMinecraft.McVersionState.Forge;
									this.Version.m_AccountParameter = ModBase.RegexSeek(text, "(?<=forge:[0-9\\.]+(_pre[0-9]*)?\\-)[0-9\\.]+", RegexOptions.None);
									if (this.Version.m_AccountParameter == null)
									{
										this.Version.m_AccountParameter = ModBase.RegexSeek(text, "(?<=net\\.minecraftforge:minecraftforge:)[0-9\\.]+", RegexOptions.None);
									}
									if (this.Version.m_AccountParameter == null)
									{
										this.Version.m_AccountParameter = (ModBase.RegexSeek(text, "(?<=net\\.minecraftforge:fmlloader:[0-9\\.]+-)[0-9\\.]+", RegexOptions.None) ?? "未知版本");
									}
									this.Version.requestParameter = true;
								}
							}
							else
							{
								this._ClassProccesor = ModMinecraft.McVersionState.Fabric;
								this.Version.m_ProccesorParameter = (ModBase.RegexSeek(text, "(?<=(net.fabricmc:fabric-loader:)|(org.quiltmc:quilt-loader:))[0-9\\.]+(\\+build.[0-9]+)?", RegexOptions.None) ?? "未知版本").Replace("+build", "");
								this.Version.stateParameter = true;
							}
							this.Version._RepositoryParameter = true;
						}
					}
					this.registryProccesor = ModBase.ReadIni(this.Path + "PCL\\Setup.ini", "Logo", "");
					if (Operators.CompareString(this.registryProccesor, "", true) == 0 || Operators.CompareString(ModBase.ReadIni(this.Path + "PCL\\Setup.ini", "LogoCustom", "False"), "False", true) == 0)
					{
						switch (this._ClassProccesor)
						{
						case ModMinecraft.McVersionState.Original:
							this.registryProccesor = "pack://application:,,,/images/Blocks/Grass.png";
							break;
						case ModMinecraft.McVersionState.Snapshot:
							this.registryProccesor = "pack://application:,,,/images/Blocks/CommandBlock.png";
							break;
						case ModMinecraft.McVersionState.Fool:
							this.registryProccesor = "pack://application:,,,/images/Blocks/GoldBlock.png";
							break;
						case ModMinecraft.McVersionState.OptiFine:
							this.registryProccesor = "pack://application:,,,/images/Blocks/GrassPath.png";
							break;
						case ModMinecraft.McVersionState.Old:
							this.registryProccesor = "pack://application:,,,/images/Blocks/CobbleStone.png";
							break;
						case ModMinecraft.McVersionState.Forge:
							this.registryProccesor = "pack://application:,,,/images/Blocks/Anvil.png";
							break;
						case ModMinecraft.McVersionState.LiteLoader:
							this.registryProccesor = "pack://application:,,,/images/Blocks/Egg.png";
							break;
						case ModMinecraft.McVersionState.Fabric:
							this.registryProccesor = "pack://application:,,,/images/Blocks/Fabric.png";
							break;
						default:
							this.registryProccesor = "pack://application:,,,/images/Blocks/RedstoneBlock.png";
							break;
						}
					}
					string left = ModBase.ReadIni(this.Path + "PCL\\Setup.ini", "CustomInfo", "");
					if (Operators.CompareString(left, "", true) == 0)
					{
						switch (this._ClassProccesor)
						{
						case ModMinecraft.McVersionState.Error:
							break;
						case ModMinecraft.McVersionState.Original:
						case ModMinecraft.McVersionState.OptiFine:
						case ModMinecraft.McVersionState.Forge:
						case ModMinecraft.McVersionState.LiteLoader:
						case ModMinecraft.McVersionState.Fabric:
							this.proxyProccesor = this.Version.ToString();
							break;
						case ModMinecraft.McVersionState.Snapshot:
							if (!this.Version._ResolverParameter.ToLower().Contains("pre") && !this.Version._ResolverParameter.ToLower().Contains("rc"))
							{
								if (!this.Version._ResolverParameter.Contains("experimental") && Operators.CompareString(this.Version._ResolverParameter, "pending", true) != 0)
								{
									this.proxyProccesor = "快照 " + this.Version._ResolverParameter;
								}
								else
								{
									this.proxyProccesor = "实验性快照";
								}
							}
							else
							{
								this.proxyProccesor = "预发布版 " + this.Version._ResolverParameter;
							}
							break;
						case ModMinecraft.McVersionState.Fool:
							this.proxyProccesor = ModMinecraft.GetMcFoolName(this.Name);
							break;
						case ModMinecraft.McVersionState.Old:
							this.proxyProccesor = "远古版本";
							break;
						default:
							this.proxyProccesor = "发生了未知错误，请向作者反馈此问题";
							break;
						}
						if (this._ClassProccesor != ModMinecraft.McVersionState.Error)
						{
							if (this.AwakePrototype())
							{
								ref string ptr = ref this.proxyProccesor;
								this.proxyProccesor = ptr + ", JumpLoader";
							}
							if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("VersionServerLogin", this), 3, true))
							{
								ref string ptr = ref this.proxyProccesor;
								this.proxyProccesor = ptr + ", 统一通行证验证";
							}
							if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("VersionServerLogin", this), 4, true))
							{
								ref string ptr = ref this.proxyProccesor;
								this.proxyProccesor = ptr + ", Authlib 验证";
							}
						}
					}
					else
					{
						this.proxyProccesor = left;
					}
					this._ProducerProccesor = Conversions.ToBoolean(ModBase.ReadIni(this.Path + "PCL\\Setup.ini", "IsStar", Conversions.ToString(false)));
					this.m_CandidateProccesor = (ModMinecraft.McVersionCardType)Conversions.ToInteger(ModBase.ReadIni(this.Path + "PCL\\Setup.ini", "DisplayType", Conversions.ToString(0)));
					ModBase.WriteIni(this.Path + "PCL\\Setup.ini", "State", Conversions.ToString((int)this._ClassProccesor));
					ModBase.WriteIni(this.Path + "PCL\\Setup.ini", "Info", this.proxyProccesor);
					ModBase.WriteIni(this.Path + "PCL\\Setup.ini", "Logo", this.registryProccesor);
					if (this._ClassProccesor != ModMinecraft.McVersionState.Error)
					{
						ModBase.WriteIni(this.Path + "PCL\\Setup.ini", "ReleaseTime", this.m_MappingProccesor.ToString("yyyy-MM-dd HH:mm:ss"));
						ModBase.WriteIni(this.Path + "PCL\\Setup.ini", "VersionFabric", this.Version.m_ProccesorParameter);
						ModBase.WriteIni(this.Path + "PCL\\Setup.ini", "VersionOptiFine", this.Version.m_IssuerParameter);
						ModBase.WriteIni(this.Path + "PCL\\Setup.ini", "VersionLiteLoader", Conversions.ToString(this.Version._ParameterParameter));
						ModBase.WriteIni(this.Path + "PCL\\Setup.ini", "VersionForge", this.Version.m_AccountParameter);
						ModBase.WriteIni(this.Path + "PCL\\Setup.ini", "VersionApiCode", Conversions.ToString(this.Version.ReadPrototype()));
						ModBase.WriteIni(this.Path + "PCL\\Setup.ini", "VersionOriginal", this.Version._ResolverParameter);
						ModBase.WriteIni(this.Path + "PCL\\Setup.ini", "VersionOriginalMain", Conversions.ToString(this.Version.tagParameter));
						ModBase.WriteIni(this.Path + "PCL\\Setup.ini", "VersionOriginalSub", Conversions.ToString(this.Version.m_ComparatorParameter));
					}
				}
				catch (Exception ex)
				{
					this.proxyProccesor = "未知错误：" + ModBase.GetString(ex, true, false);
					this.registryProccesor = "pack://application:,,,/images/Blocks/RedstoneBlock.png";
					this._ClassProccesor = ModMinecraft.McVersionState.Error;
					ModBase.Log(ex, "加载版本失败（" + this.Name + "）", ModBase.LogLevel.Feedback, "出现错误");
				}
				finally
				{
					this._WrapperParameter = true;
				}
				return this;
			}

			// Token: 0x06000A2F RID: 2607 RVA: 0x000535DC File Offset: 0x000517DC
			public override bool Equals(object obj)
			{
				ModMinecraft.McVersion mcVersion = obj as ModMinecraft.McVersion;
				return mcVersion != null && Operators.CompareString(this.Path, mcVersion.Path, true) == 0;
			}

			// Token: 0x04000539 RID: 1337
			[CompilerGenerated]
			private string _ServiceProccesor;

			// Token: 0x0400053A RID: 1338
			private string _ImporterProccesor;

			// Token: 0x0400053B RID: 1339
			public string proxyProccesor;

			// Token: 0x0400053C RID: 1340
			public ModMinecraft.McVersionState _ClassProccesor;

			// Token: 0x0400053D RID: 1341
			public string registryProccesor;

			// Token: 0x0400053E RID: 1342
			public bool _ProducerProccesor;

			// Token: 0x0400053F RID: 1343
			public ModMinecraft.McVersionCardType m_CandidateProccesor;

			// Token: 0x04000540 RID: 1344
			private ModMinecraft.McVersionInfo setterProccesor;

			// Token: 0x04000541 RID: 1345
			public DateTime m_MappingProccesor;

			// Token: 0x04000542 RID: 1346
			private string m_DispatcherProccesor;

			// Token: 0x04000543 RID: 1347
			private JObject messageProccesor;

			// Token: 0x04000544 RID: 1348
			[CompilerGenerated]
			private bool statusProccesor;

			// Token: 0x04000545 RID: 1349
			[CompilerGenerated]
			private bool procProccesor;

			// Token: 0x04000546 RID: 1350
			private string modelParameter;

			// Token: 0x04000547 RID: 1351
			public bool _WrapperParameter;
		}

		// Token: 0x02000115 RID: 277
		public enum McVersionState
		{
			// Token: 0x0400054C RID: 1356
			Error,
			// Token: 0x0400054D RID: 1357
			Original,
			// Token: 0x0400054E RID: 1358
			Snapshot,
			// Token: 0x0400054F RID: 1359
			Fool,
			// Token: 0x04000550 RID: 1360
			OptiFine,
			// Token: 0x04000551 RID: 1361
			Old,
			// Token: 0x04000552 RID: 1362
			Forge,
			// Token: 0x04000553 RID: 1363
			LiteLoader,
			// Token: 0x04000554 RID: 1364
			Fabric
		}

		// Token: 0x02000116 RID: 278
		public class McVersionInfo
		{
			// Token: 0x06000A35 RID: 2613 RVA: 0x00053664 File Offset: 0x00051864
			public McVersionInfo()
			{
				this._RepositoryParameter = false;
				this.tagParameter = -1;
				this.m_ComparatorParameter = -1;
				this.m_PrototypeParameter = false;
				this.m_IssuerParameter = "";
				this.requestParameter = false;
				this.m_AccountParameter = "";
				this.stateParameter = false;
				this.m_ProccesorParameter = "";
				this._ParameterParameter = false;
				this.m_AuthenticationParameter = -2;
			}

			// Token: 0x06000A36 RID: 2614 RVA: 0x00006E4B File Offset: 0x0000504B
			public bool CalculatePrototype()
			{
				return this.stateParameter || this.requestParameter || this._ParameterParameter;
			}

			// Token: 0x06000A37 RID: 2615 RVA: 0x000536D4 File Offset: 0x000518D4
			public override string ToString()
			{
				string text = "";
				if (this.requestParameter)
				{
					text = text + ", Forge" + ((Operators.CompareString(this.m_AccountParameter, "未知版本", true) == 0) ? "" : (" " + this.m_AccountParameter));
				}
				if (this.stateParameter)
				{
					text = text + ", Fabric" + ((Operators.CompareString(this.m_ProccesorParameter, "未知版本", true) == 0) ? "" : (" " + this.m_ProccesorParameter));
				}
				if (this.m_PrototypeParameter)
				{
					text = text + ", OptiFine" + ((Operators.CompareString(this.m_IssuerParameter, "未知版本", true) == 0) ? "" : (" " + this.m_IssuerParameter));
				}
				if (this._ParameterParameter)
				{
					text += ", LiteLoader";
				}
				if (Operators.CompareString(text, "", true) == 0)
				{
					text = "原版 " + this._ResolverParameter;
				}
				else
				{
					text = this._ResolverParameter + text + (ModBase._EventState ? (" (" + Conversions.ToString(this.ReadPrototype()) + "#)") : "");
				}
				return text;
			}

			// Token: 0x06000A38 RID: 2616 RVA: 0x0005380C File Offset: 0x00051A0C
			public int ReadPrototype()
			{
				checked
				{
					if (this.m_AuthenticationParameter == -2)
					{
						try
						{
							if (this.stateParameter)
							{
								if (Operators.CompareString(this.m_ProccesorParameter, "未知版本", true) == 0)
								{
									return 0;
								}
								string[] array = this.m_ProccesorParameter.Split(new char[]
								{
									'.'
								});
								if (array.Length < 3)
								{
									throw new Exception("无效的 Fabric 版本：" + this.m_AccountParameter);
								}
								this.m_AuthenticationParameter = (int)Math.Round(unchecked(ModBase.Val(array[0]) * 10000.0 + ModBase.Val(array[1]) * 100.0 + ModBase.Val(array[2])));
							}
							else if (this.requestParameter)
							{
								if (Operators.CompareString(this.m_AccountParameter, "未知版本", true) == 0)
								{
									return 0;
								}
								string[] array2 = this.m_AccountParameter.Split(new char[]
								{
									'.'
								});
								if (array2.Length == 4)
								{
									this.m_AuthenticationParameter = (int)Math.Round(unchecked(ModBase.Val(array2[0]) * 1000000.0 + ModBase.Val(array2[1]) * 10000.0 + ModBase.Val(array2[3])));
								}
								else
								{
									if (array2.Length != 3)
									{
										throw new Exception("无效的 Forge 版本：" + this.m_AccountParameter);
									}
									this.m_AuthenticationParameter = (int)Math.Round(unchecked(ModBase.Val(array2[0]) * 1000000.0 + ModBase.Val(array2[1]) * 10000.0 + ModBase.Val(array2[2])));
								}
							}
							else if (this.m_PrototypeParameter)
							{
								if (Operators.CompareString(this.m_IssuerParameter, "未知版本", true) == 0)
								{
									return 0;
								}
								this.m_AuthenticationParameter = (int)Math.Round(unchecked((double)(checked(((this.m_ComparatorParameter >= 0) ? this.m_ComparatorParameter : 0) * 1000000 + (Strings.Asc(Conversions.ToChar(Strings.Left(this.m_IssuerParameter.ToUpper(), 1))) - 65 + 1) * 10000)) + ModBase.Val(ModBase.RegexSeek(Strings.Right(this.m_IssuerParameter, checked(this.m_IssuerParameter.Length - 1)), "[0-9]+", RegexOptions.None)) * 100.0));
								if (this.m_IssuerParameter.ToLower().Contains("pre"))
								{
									ref int ptr = ref this.m_AuthenticationParameter;
									this.m_AuthenticationParameter = ptr + 50;
								}
								if (!this.m_IssuerParameter.ToLower().Contains("pre") && !this.m_IssuerParameter.ToLower().Contains("beta"))
								{
									ref int ptr = ref this.m_AuthenticationParameter;
									this.m_AuthenticationParameter = ptr + 99;
								}
								else if (ModBase.Val(Strings.Right(this.m_IssuerParameter, 1)) == 0.0 && Operators.CompareString(Strings.Right(this.m_IssuerParameter, 1), "0", true) != 0)
								{
									ref int ptr = ref this.m_AuthenticationParameter;
									this.m_AuthenticationParameter = ptr + 1;
								}
								else
								{
									ref int ptr = ref this.m_AuthenticationParameter;
									this.m_AuthenticationParameter = (int)Math.Round(unchecked((double)ptr + ModBase.Val(ModBase.RegexSeek(this.m_IssuerParameter.ToLower(), "(?<=((pre)|(beta)))[0-9]+", RegexOptions.None))));
								}
							}
							else
							{
								this.m_AuthenticationParameter = -1;
							}
						}
						catch (Exception ex)
						{
							this.m_AuthenticationParameter = -1;
							ModBase.Log(ex, "获取 API 版本信息失败：" + this.ToString(), ModBase.LogLevel.Debug, "出现错误");
						}
					}
					return this.m_AuthenticationParameter;
				}
			}

			// Token: 0x06000A39 RID: 2617 RVA: 0x00006E65 File Offset: 0x00005065
			public void LoginPrototype(int value)
			{
				this.m_AuthenticationParameter = value;
			}

			// Token: 0x04000555 RID: 1365
			public bool _RepositoryParameter;

			// Token: 0x04000556 RID: 1366
			public string _ResolverParameter;

			// Token: 0x04000557 RID: 1367
			public int tagParameter;

			// Token: 0x04000558 RID: 1368
			public int m_ComparatorParameter;

			// Token: 0x04000559 RID: 1369
			public bool m_PrototypeParameter;

			// Token: 0x0400055A RID: 1370
			public string m_IssuerParameter;

			// Token: 0x0400055B RID: 1371
			public bool requestParameter;

			// Token: 0x0400055C RID: 1372
			public string m_AccountParameter;

			// Token: 0x0400055D RID: 1373
			public bool stateParameter;

			// Token: 0x0400055E RID: 1374
			public string m_ProccesorParameter;

			// Token: 0x0400055F RID: 1375
			public bool _ParameterParameter;

			// Token: 0x04000560 RID: 1376
			private int m_AuthenticationParameter;
		}

		// Token: 0x02000117 RID: 279
		public enum McVersionCardType
		{
			// Token: 0x04000562 RID: 1378
			Star = -1,
			// Token: 0x04000563 RID: 1379
			Auto,
			// Token: 0x04000564 RID: 1380
			Hidden,
			// Token: 0x04000565 RID: 1381
			API,
			// Token: 0x04000566 RID: 1382
			OriginalLike,
			// Token: 0x04000567 RID: 1383
			Rubbish,
			// Token: 0x04000568 RID: 1384
			Fool,
			// Token: 0x04000569 RID: 1385
			Error
		}

		// Token: 0x02000118 RID: 280
		public struct McSkinInfo
		{
			// Token: 0x0400056A RID: 1386
			public bool m_ReponseParameter;

			// Token: 0x0400056B RID: 1387
			public string m_ContainerParameter;

			// Token: 0x0400056C RID: 1388
			public bool _CodeParameter;
		}

		// Token: 0x02000119 RID: 281
		public class McLibToken
		{
			// Token: 0x06000A3B RID: 2619 RVA: 0x00006E6E File Offset: 0x0000506E
			public McLibToken()
			{
				this._DefinitionParameter = 0L;
				this.m_ParamsParameter = false;
				this.m_MockParameter = null;
				this._SystemParameter = false;
			}

			// Token: 0x06000A3C RID: 2620 RVA: 0x00006E9B File Offset: 0x0000509B
			public string CallPrototype()
			{
				return this.adapterParameter;
			}

			// Token: 0x06000A3D RID: 2621 RVA: 0x00006EA3 File Offset: 0x000050A3
			public void MovePrototype(string value)
			{
				this.adapterParameter = (string.IsNullOrWhiteSpace(value) ? null : value);
			}

			// Token: 0x17000168 RID: 360
			// (get) Token: 0x06000A3E RID: 2622 RVA: 0x00053B74 File Offset: 0x00051D74
			public string Name
			{
				get
				{
					string result;
					if (this.m_InitializerParameter == null)
					{
						result = null;
					}
					else
					{
						List<string> list = new List<string>(this.m_InitializerParameter.Split(new char[]
						{
							':'
						}));
						list.RemoveAt(checked(list.Count - 1));
						result = ModBase.Join(list, ":");
					}
					return result;
				}
			}

			// Token: 0x17000169 RID: 361
			// (get) Token: 0x06000A3F RID: 2623 RVA: 0x00006EB7 File Offset: 0x000050B7
			public string Version
			{
				get
				{
					string[] array = this.m_InitializerParameter.Split(new char[]
					{
						':'
					});
					return array[checked(array.Count<string>() - 1)];
				}
			}

			// Token: 0x06000A40 RID: 2624 RVA: 0x00006ED8 File Offset: 0x000050D8
			public override string ToString()
			{
				return (this.m_ParamsParameter ? "[Native] " : "") + ModBase.GetString(this._DefinitionParameter) + " | " + this.tokenizerParameter;
			}

			// Token: 0x0400056D RID: 1389
			public string tokenizerParameter;

			// Token: 0x0400056E RID: 1390
			public long _DefinitionParameter;

			// Token: 0x0400056F RID: 1391
			public bool m_ParamsParameter;

			// Token: 0x04000570 RID: 1392
			public string m_MockParameter;

			// Token: 0x04000571 RID: 1393
			private string adapterParameter;

			// Token: 0x04000572 RID: 1394
			public string m_InitializerParameter;

			// Token: 0x04000573 RID: 1395
			public bool _SystemParameter;
		}

		// Token: 0x0200011A RID: 282
		private struct McAssetsToken
		{
			// Token: 0x06000A42 RID: 2626 RVA: 0x00006F09 File Offset: 0x00005109
			public override string ToString()
			{
				return (this.specificationParameter ? "[Virtual] " : "") + ModBase.GetString(this.m_AttributeParameter) + " | " + this.m_WriterParameter;
			}

			// Token: 0x04000574 RID: 1396
			public string m_WriterParameter;

			// Token: 0x04000575 RID: 1397
			public string _BroadcasterParameter;

			// Token: 0x04000576 RID: 1398
			public long m_AttributeParameter;

			// Token: 0x04000577 RID: 1399
			public bool specificationParameter;

			// Token: 0x04000578 RID: 1400
			public string _PredicateParameter;
		}

		// Token: 0x0200011B RID: 283
		public class McMod
		{
			// Token: 0x06000A44 RID: 2628 RVA: 0x00053BC4 File Offset: 0x00051DC4
			public McMod(string Path)
			{
				this._ClientParameter = null;
				this._InfoParameter = null;
				this._DecoratorParameter = null;
				this._PropertyParameter = null;
				this.descriptorParameter = new List<string>();
				this.mapParameter = null;
				this.m_EventParameter = null;
				this.algoParameter = new Dictionary<string, string>();
				this.m_PoolParameter = false;
				this.publisherParameter = null;
				this.watcherParameter = false;
				this.testParameter = false;
				this.taskParameter = false;
				this.Path = (Path ?? "");
			}

			// Token: 0x06000A45 RID: 2629 RVA: 0x00006F3A File Offset: 0x0000513A
			public string GetPrototype()
			{
				return ModBase.GetFileNameFromPath(this.Path);
			}

			// Token: 0x1700016A RID: 362
			// (get) Token: 0x06000A46 RID: 2630 RVA: 0x00053C4C File Offset: 0x00051E4C
			public ModMinecraft.McMod.McModState State
			{
				get
				{
					this.Load(false);
					ModMinecraft.McMod.McModState result;
					if (!this.DefinePrototype())
					{
						result = ModMinecraft.McMod.McModState.Unavaliable;
					}
					else if (this.Path.EndsWith(".disabled"))
					{
						result = ModMinecraft.McMod.McModState.Disabled;
					}
					else
					{
						result = ModMinecraft.McMod.McModState.Fine;
					}
					return result;
				}
			}

			// Token: 0x1700016B RID: 363
			// (get) Token: 0x06000A47 RID: 2631 RVA: 0x00053C88 File Offset: 0x00051E88
			// (set) Token: 0x06000A48 RID: 2632 RVA: 0x00053CD8 File Offset: 0x00051ED8
			public string Name
			{
				get
				{
					if (this._ClientParameter == null)
					{
						this.Load(false);
					}
					if (this._ClientParameter == null)
					{
						this._ClientParameter = this._PropertyParameter;
					}
					if (this._ClientParameter == null)
					{
						this._ClientParameter = ModBase.GetFileNameWithoutExtentionFromPath(this.Path);
					}
					return this._ClientParameter;
				}
				set
				{
					if (this._ClientParameter == null && value != null && Operators.CompareString(value.ToLower(), "name", true) != 0 && value.Count<char>() > 1 && Operators.CompareString(ModBase.Val(value).ToString(), value, true) != 0)
					{
						this._ClientParameter = value;
					}
				}
			}

			// Token: 0x1700016C RID: 364
			// (get) Token: 0x06000A49 RID: 2633 RVA: 0x00006F47 File Offset: 0x00005147
			// (set) Token: 0x06000A4A RID: 2634 RVA: 0x00053D2C File Offset: 0x00051F2C
			public string Description
			{
				get
				{
					if (this._InfoParameter == null)
					{
						this.Load(false);
					}
					if (this._InfoParameter == null && this.WritePrototype() != null)
					{
						this._InfoParameter = this.WritePrototype().Message;
					}
					return this._InfoParameter;
				}
				set
				{
					if (this._InfoParameter == null && value != null && value.Count<char>() > 2)
					{
						this._InfoParameter = value.ToString().Trim(new char[]
						{
							'\n'
						});
						if (this._InfoParameter.ToLower().LastIndexOfAny(Conversions.ToCharArrayRankOne("qwertyuiopasdfghjklzxcvbnm0123456789")) == checked(this._InfoParameter.Count<char>() - 1))
						{
							ref string ptr = ref this._InfoParameter;
							this._InfoParameter = ptr + ".";
						}
					}
				}
			}

			// Token: 0x1700016D RID: 365
			// (get) Token: 0x06000A4B RID: 2635 RVA: 0x00006F7F File Offset: 0x0000517F
			// (set) Token: 0x06000A4C RID: 2636 RVA: 0x00053DA8 File Offset: 0x00051FA8
			public string Version
			{
				get
				{
					if (this._DecoratorParameter == null)
					{
						this.Load(false);
					}
					return this._DecoratorParameter;
				}
				set
				{
					if (this._DecoratorParameter == null || (!this._DecoratorParameter.Contains(".") && !this._DecoratorParameter.Contains("-")))
					{
						if (value != null && value.ToLower().Contains("version"))
						{
							value = "version";
						}
						this._DecoratorParameter = value;
					}
				}
			}

			// Token: 0x06000A4D RID: 2637 RVA: 0x00006F96 File Offset: 0x00005196
			public string PublishPrototype()
			{
				if (this._PropertyParameter == null)
				{
					this.Load(false);
				}
				return this._PropertyParameter;
			}

			// Token: 0x06000A4E RID: 2638 RVA: 0x00053E04 File Offset: 0x00052004
			public void UpdatePrototype(string value)
			{
				if (value != null)
				{
					value = ModBase.RegexSeek(value.ToLower(), "[0-9a-z_]+", RegexOptions.None);
					if (value != null && Operators.CompareString(value.ToLower(), "name", true) != 0 && value.Count<char>() > 1 && Operators.CompareString(ModBase.Val(value).ToString(), value, true) != 0)
					{
						if (!this.descriptorParameter.Contains(value))
						{
							this.descriptorParameter.Add(value);
						}
						if (this._PropertyParameter == null)
						{
							this._PropertyParameter = value;
						}
					}
				}
			}

			// Token: 0x06000A4F RID: 2639 RVA: 0x00006FAD File Offset: 0x000051AD
			public string InsertPrototype()
			{
				if (this.mapParameter == null)
				{
					this.Load(false);
				}
				return this.mapParameter;
			}

			// Token: 0x06000A50 RID: 2640 RVA: 0x00006FC4 File Offset: 0x000051C4
			public void InstantiatePrototype(string value)
			{
				if (this.mapParameter == null && value != null && value.StartsWith("http"))
				{
					this.mapParameter = value;
				}
			}

			// Token: 0x06000A51 RID: 2641 RVA: 0x00006FE5 File Offset: 0x000051E5
			public string LogoutPrototype()
			{
				if (this.m_EventParameter == null)
				{
					this.Load(false);
				}
				return this.m_EventParameter;
			}

			// Token: 0x06000A52 RID: 2642 RVA: 0x00006FFC File Offset: 0x000051FC
			public void PatchPrototype(string value)
			{
				if (this.m_EventParameter == null && !string.IsNullOrWhiteSpace(value))
				{
					this.m_EventParameter = value;
				}
			}

			// Token: 0x06000A53 RID: 2643 RVA: 0x00007015 File Offset: 0x00005215
			public Dictionary<string, string> ForgotPrototype()
			{
				this.Load(false);
				return this.algoParameter;
			}

			// Token: 0x06000A54 RID: 2644 RVA: 0x00053E88 File Offset: 0x00052088
			private void AddDependency(string ModID, string VersionRequirement = null)
			{
				if (ModID != null && ModID.Count<char>() >= 2)
				{
					ModID = ModID.ToLower();
					if (Operators.CompareString(ModID, "name", true) != 0 && Operators.CompareString(ModBase.Val(ModID).ToString(), ModID, true) != 0)
					{
						if (VersionRequirement != null && (VersionRequirement.Contains(".") || VersionRequirement.Contains("-")) && !VersionRequirement.Contains("$"))
						{
							if (!VersionRequirement.StartsWith("[") && !VersionRequirement.StartsWith("(") && !VersionRequirement.EndsWith("]") && !VersionRequirement.EndsWith(")"))
							{
								VersionRequirement = "[" + VersionRequirement + ",)";
							}
						}
						else
						{
							VersionRequirement = null;
						}
						if (this.algoParameter.ContainsKey(ModID))
						{
							if (this.algoParameter[ModID] == null)
							{
								this.algoParameter[ModID] = VersionRequirement;
								return;
							}
						}
						else
						{
							this.algoParameter.Add(ModID, VersionRequirement);
						}
					}
				}
			}

			// Token: 0x06000A55 RID: 2645 RVA: 0x00007024 File Offset: 0x00005224
			public bool DefinePrototype()
			{
				this.Load(false);
				return this.WritePrototype() == null;
			}

			// Token: 0x06000A56 RID: 2646 RVA: 0x00007036 File Offset: 0x00005236
			public Exception WritePrototype()
			{
				this.Load(false);
				return this.publisherParameter;
			}

			// Token: 0x06000A57 RID: 2647 RVA: 0x00053F88 File Offset: 0x00052188
			private void Init()
			{
				this._ClientParameter = null;
				this._InfoParameter = null;
				this._DecoratorParameter = null;
				this._PropertyParameter = null;
				this.descriptorParameter = new List<string>();
				this.algoParameter = new Dictionary<string, string>();
				this.m_PoolParameter = false;
				this.publisherParameter = null;
				this.watcherParameter = false;
				this.testParameter = false;
				this.taskParameter = false;
			}

			// Token: 0x06000A58 RID: 2648 RVA: 0x00053FEC File Offset: 0x000521EC
			public void Load(bool ForceReload = false)
			{
				if (!this.m_PoolParameter || ForceReload)
				{
					this.Init();
					ZipArchive zipArchive;
					try
					{
						if (this.Path.Length < 2)
						{
							throw new FileNotFoundException("错误的 Mod 文件路径（" + (this.Path ?? "null") + "）");
						}
						if (!File.Exists(this.Path))
						{
							throw new FileNotFoundException("未找到 Mod 文件（" + this.Path + "）");
						}
						zipArchive = new ZipArchive(new FileStream(this.Path, FileMode.Open));
						if (zipArchive.Entries.Count == 0)
						{
							throw new FileFormatException("文件内容为空");
						}
					}
					catch (UnauthorizedAccessException ex)
					{
						ModBase.Log(ex, "Mod 文件由于无权限无法打开（" + this.Path + "）", ModBase.LogLevel.Developer, "出现错误");
						this.publisherParameter = new UnauthorizedAccessException("没有读取此文件的权限，请尝试右键以管理员身份运行 PCL2", ex);
						zipArchive = null;
					}
					catch (Exception ex2)
					{
						ModBase.Log(ex2, "Mod 文件无法打开（" + this.Path + "）", ModBase.LogLevel.Developer, "出现错误");
						this.publisherParameter = ex2;
						zipArchive = null;
					}
					if (zipArchive != null)
					{
						this.LoadWithoutClass(zipArchive);
					}
					if (zipArchive != null && !this.watcherParameter)
					{
						this.LoadWithClass(zipArchive);
					}
					try
					{
						if (zipArchive != null)
						{
							zipArchive.Dispose();
						}
					}
					catch (Exception ex3)
					{
					}
					this.m_PoolParameter = true;
				}
			}

			// Token: 0x06000A59 RID: 2649 RVA: 0x00054170 File Offset: 0x00052370
			private void LoadWithoutClass(ZipArchive Jar)
			{
				checked
				{
					try
					{
						ZipArchiveEntry entry = Jar.GetEntry("mcmod.info");
						string text = null;
						if (entry != null)
						{
							text = ModBase.ReadFile(entry.Open(), null);
							if (text.Length < 15)
							{
								text = null;
							}
						}
						if (text != null)
						{
							object objectValue = RuntimeHelpers.GetObjectValue(ModBase.GetJson(text));
							JObject jobject;
							if (Operators.ConditionalCompareObjectEqual(NewLateBinding.LateGet(objectValue, null, "Type", new object[0], null, null, null), 2, true))
							{
								jobject = (JObject)NewLateBinding.LateIndexGet(objectValue, new object[]
								{
									0
								}, null);
							}
							else
							{
								jobject = (JObject)NewLateBinding.LateIndexGet(NewLateBinding.LateIndexGet(objectValue, new object[]
								{
									"modList"
								}, null), new object[]
								{
									0
								}, null);
							}
							this.Name = (string)jobject["name"];
							this.Description = (string)jobject["description"];
							this.Version = (string)jobject["version"];
							this.InstantiatePrototype((string)jobject["url"]);
							this.UpdatePrototype((string)jobject["modid"]);
							JArray jarray = (JArray)jobject["authorList"];
							if (jarray != null)
							{
								List<string> list = new List<string>();
								try
								{
									foreach (JToken jtoken in jarray)
									{
										list.Add(jtoken.ToString());
									}
								}
								finally
								{
									IEnumerator<JToken> enumerator;
									if (enumerator != null)
									{
										enumerator.Dispose();
									}
								}
								if (list.Count > 0)
								{
									this.PatchPrototype(ModBase.Join(list, ", "));
								}
							}
							JArray jarray2 = (JArray)jobject["requiredMods"];
							if (jarray2 != null)
							{
								try
								{
									foreach (JToken jtoken2 in jarray2)
									{
										string text2 = (string)jtoken2;
										if (!string.IsNullOrEmpty(text2))
										{
											text2 = text2.Substring(text2.IndexOf(":") + 1);
											if (text2.Contains("@"))
											{
												this.AddDependency(text2.Split(new char[]
												{
													'@'
												})[0], text2.Split(new char[]
												{
													'@'
												})[1]);
											}
											else
											{
												this.AddDependency(text2, null);
											}
										}
									}
								}
								finally
								{
									IEnumerator<JToken> enumerator2;
									if (enumerator2 != null)
									{
										enumerator2.Dispose();
									}
								}
							}
							jarray2 = (JArray)jobject["dependancies"];
							if (jarray2 != null)
							{
								try
								{
									foreach (JToken jtoken3 in jarray2)
									{
										string text3 = (string)jtoken3;
										if (!string.IsNullOrEmpty(text3))
										{
											text3 = text3.Substring(text3.IndexOf(":") + 1);
											if (text3.Contains("@"))
											{
												this.AddDependency(text3.Split(new char[]
												{
													'@'
												})[0], text3.Split(new char[]
												{
													'@'
												})[1]);
											}
											else
											{
												this.AddDependency(text3, null);
											}
										}
									}
								}
								finally
								{
									IEnumerator<JToken> enumerator3;
									if (enumerator3 != null)
									{
										enumerator3.Dispose();
									}
								}
							}
						}
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "读取 mcmod.info 时出现未知错误（" + this.Path + "）", ModBase.LogLevel.Developer, "出现错误");
					}
					try
					{
						ZipArchiveEntry entry2 = Jar.GetEntry("META-INF/mods.toml");
						string text4 = null;
						if (entry2 != null)
						{
							text4 = ModBase.ReadFile(entry2.Open(), null);
							if (text4.Length < 15)
							{
								text4 = null;
							}
						}
						if (text4 != null)
						{
							List<string> list2 = new List<string>();
							foreach (string text5 in text4.Replace("\r\n", "\n").Replace("\r", "\n").Split(new char[]
							{
								'\n'
							}))
							{
								if (!text5.StartsWith("#"))
								{
									if (text5.Contains("#"))
									{
										text5 = text5.Substring(0, text5.IndexOf("#"));
									}
									text5 = text5.Trim(new char[]
									{
										' ',
										'\t',
										'\u3000'
									});
									if (text5.Count<char>() > 0)
									{
										list2.Add(text5);
									}
								}
							}
							List<KeyValuePair<string, Dictionary<string, object>>> list3 = new List<KeyValuePair<string, Dictionary<string, object>>>
							{
								new KeyValuePair<string, Dictionary<string, object>>("", new Dictionary<string, object>())
							};
							int num = list2.Count - 1;
							for (int j = 0; j <= num; j++)
							{
								string text6 = list2[j];
								if (text6.StartsWith("[[") && text6.EndsWith("]]"))
								{
									string key = text6.Replace("[", "").Replace("]", "");
									list3.Add(new KeyValuePair<string, Dictionary<string, object>>(key, new Dictionary<string, object>()));
								}
								else
								{
									if (!text6.Contains("="))
									{
										goto IL_951;
									}
									string key2 = text6.Substring(0, text6.IndexOf("=")).TrimEnd(new char[]
									{
										' ',
										'\t',
										'\u3000'
									});
									string text7 = text6.Substring(text6.IndexOf("=") + 1).TrimStart(new char[]
									{
										' ',
										'\t',
										'\u3000'
									});
									object obj;
									if (text7.StartsWith("\"") && text7.EndsWith("\""))
									{
										obj = text7.Trim(new char[]
										{
											'"'
										});
									}
									else
									{
										if (text7.StartsWith("'''"))
										{
											List<string> list4 = new List<string>
											{
												text7.TrimStart(new char[]
												{
													'\''
												})
											};
											while (j < list2.Count - 1)
											{
												j++;
												string text8 = list2[j];
												if (text8.EndsWith("'''"))
												{
													list4.Add(text8.TrimEnd(new char[]
													{
														'\''
													}));
													IL_5C6:
													obj = ModBase.Join(list4, "\n").Trim(new char[]
													{
														'\n'
													}).Replace("\n", "\r\n");
													goto IL_669;
												}
												list4.Add(text8);
											}
											goto IL_5C6;
										}
										if (Operators.CompareString(text7.ToLower(), "true", true) != 0 && Operators.CompareString(text7.ToLower(), "false", true) != 0)
										{
											if (Operators.CompareString(ModBase.Val(text7).ToString(), text7, true) == 0)
											{
												obj = ModBase.Val(text7);
											}
											else
											{
												obj = text7;
											}
										}
										else
										{
											obj = (Operators.CompareString(text7.ToLower(), "true", true) == 0);
										}
									}
									IL_669:
									Dictionary<string, object> value = list3.Last<KeyValuePair<string, Dictionary<string, object>>>().Value;
									ModBase.DictionaryAdd<string, object>(ref value, key2, RuntimeHelpers.GetObjectValue(obj));
								}
							}
							Dictionary<string, object> dictionary = null;
							try
							{
								foreach (KeyValuePair<string, Dictionary<string, object>> keyValuePair in list3)
								{
									if (Operators.CompareString(keyValuePair.Key, "mods", true) == 0)
									{
										dictionary = keyValuePair.Value;
										break;
									}
								}
							}
							finally
							{
								List<KeyValuePair<string, Dictionary<string, object>>>.Enumerator enumerator4;
								((IDisposable)enumerator4).Dispose();
							}
							if (dictionary != null && dictionary.ContainsKey("modId"))
							{
								this.UpdatePrototype(Conversions.ToString(dictionary["modId"]));
								if (this._PropertyParameter != null)
								{
									if (dictionary.ContainsKey("displayName"))
									{
										this.Name = Conversions.ToString(dictionary["displayName"]);
									}
									if (dictionary.ContainsKey("description"))
									{
										this.Description = Conversions.ToString(dictionary["description"]);
									}
									if (dictionary.ContainsKey("version"))
									{
										this.Version = Conversions.ToString(dictionary["version"]);
									}
									if (list3[0].Value.ContainsKey("displayURL"))
									{
										this.InstantiatePrototype(Conversions.ToString(list3[0].Value["displayURL"]));
									}
									if (list3[0].Value.ContainsKey("authors"))
									{
										this.PatchPrototype(Conversions.ToString(list3[0].Value["authors"]));
									}
									try
									{
										foreach (KeyValuePair<string, Dictionary<string, object>> keyValuePair2 in list3)
										{
											if (keyValuePair2.Key.StartsWith("dependencies"))
											{
												Dictionary<string, object> value2 = keyValuePair2.Value;
												if (Conversions.ToBoolean(value2.ContainsKey("modId") && value2.ContainsKey("mandatory") && Conversions.ToBoolean(value2["mandatory"]) && value2.ContainsKey("side") && Operators.CompareString(value2["side"].ToString().ToLower(), "server", true) != 0))
												{
													this.AddDependency(Conversions.ToString(value2["modId"]), Conversions.ToString(value2.ContainsKey("versionRange") ? value2["versionRange"] : null));
												}
											}
										}
									}
									finally
									{
										List<KeyValuePair<string, Dictionary<string, object>>>.Enumerator enumerator5;
										((IDisposable)enumerator5).Dispose();
									}
									goto IL_F6F;
								}
							}
						}
					}
					catch (Exception ex2)
					{
						ModBase.Log(ex2, "读取 mods.toml 时出现未知错误（" + this.Path + "）", ModBase.LogLevel.Developer, "出现错误");
					}
					IL_951:
					try
					{
						ZipArchiveEntry entry3 = Jar.GetEntry("fabric.mod.json");
						string text9 = null;
						if (entry3 != null)
						{
							text9 = ModBase.ReadFile(entry3.Open(), Encoding.UTF8);
							if (!text9.Contains("schemaVersion"))
							{
								text9 = null;
							}
						}
						if (text9 != null)
						{
							JObject jobject2 = (JObject)ModBase.GetJson(text9);
							if (jobject2.ContainsKey("name"))
							{
								this.Name = (string)jobject2["name"];
							}
							if (jobject2.ContainsKey("version"))
							{
								this.Version = (string)jobject2["version"];
							}
							if (jobject2.ContainsKey("description"))
							{
								this.Description = (string)jobject2["description"];
							}
							if (jobject2.ContainsKey("id"))
							{
								this.UpdatePrototype((string)jobject2["id"]);
							}
							if (jobject2.ContainsKey("contact"))
							{
								this.InstantiatePrototype((string)(jobject2["contact"]["homepage"] ?? ""));
							}
							JArray jarray3 = (JArray)jobject2["authors"];
							if (jarray3 != null)
							{
								List<string> list5 = new List<string>();
								try
								{
									foreach (JToken jtoken4 in jarray3)
									{
										list5.Add(jtoken4.ToString());
									}
								}
								finally
								{
									IEnumerator<JToken> enumerator6;
									if (enumerator6 != null)
									{
										enumerator6.Dispose();
									}
								}
								if (list5.Count > 0)
								{
									this.PatchPrototype(ModBase.Join(list5, ", "));
								}
							}
							goto IL_F6F;
						}
					}
					catch (Exception ex3)
					{
						ModBase.Log(ex3, "读取 fabric.mod.json 时出现未知错误（" + this.Path + "）", ModBase.LogLevel.Developer, "出现错误");
					}
					try
					{
						ZipArchiveEntry entry4 = Jar.GetEntry("META-INF/fml_cache_annotation.json");
						string text10 = null;
						if (entry4 != null)
						{
							text10 = ModBase.ReadFile(entry4.Open(), Encoding.UTF8);
							if (!text10.Contains("Lnet/minecraftforge/fml/common/Mod;"))
							{
								text10 = null;
							}
						}
						if (text10 != null)
						{
							JObject jobject3 = (JObject)ModBase.GetJson(text10);
							JObject jobject4 = null;
							try
							{
								foreach (KeyValuePair<string, JToken> keyValuePair3 in jobject3)
								{
									JArray jarray4 = (JArray)keyValuePair3.Value["annotations"];
									if (jarray4 != null)
									{
										try
										{
											foreach (JToken jtoken5 in jarray4)
											{
												if (Operators.CompareString((string)(jtoken5["name"] ?? ""), "Lnet/minecraftforge/fml/common/Mod;", true) == 0)
												{
													jobject4 = (JObject)jtoken5["values"];
													goto IL_C2C;
												}
											}
										}
										finally
										{
											IEnumerator<JToken> enumerator8;
											if (enumerator8 != null)
											{
												enumerator8.Dispose();
											}
										}
									}
								}
							}
							finally
							{
								IEnumerator<KeyValuePair<string, JToken>> enumerator7;
								if (enumerator7 != null)
								{
									enumerator7.Dispose();
								}
							}
							goto IL_F6F;
							IL_C2C:
							if (jobject4.ContainsKey("useMetadata") && Operators.CompareString((jobject4["useMetadata"]["value"] ?? "").ToString().ToLower(), "true", true) == 0)
							{
								string text11 = (string)jobject4["modid"]["value"];
								if (text11 != null)
								{
									text11 = ModBase.RegexSeek(text11.ToLower(), "[0-9a-z_]+", RegexOptions.None);
									if (text11 != null && Operators.CompareString(text11.ToLower(), "name", true) != 0 && text11.Count<char>() > 1 && Operators.CompareString(ModBase.Val(text11).ToString(), text11, true) != 0 && !this.descriptorParameter.Contains(text11))
									{
										this.descriptorParameter.Add(text11);
									}
								}
							}
							else
							{
								if (jobject4.ContainsKey("name"))
								{
									this.Name = (string)jobject4["name"]["value"];
								}
								if (jobject4.ContainsKey("version"))
								{
									this.Version = (string)jobject4["version"]["value"];
								}
								if (jobject4.ContainsKey("modid"))
								{
									this.UpdatePrototype((string)jobject4["modid"]["value"]);
								}
								if (!jobject4.ContainsKey("serverSideOnly") || !jobject4["serverSideOnly"]["value"].ToObject<bool>())
								{
									JToken jtoken6;
									if (jobject4["acceptedMinecraftVersions"] == null)
									{
										if ((jtoken6 = "") != null)
										{
											goto IL_E0F;
										}
									}
									else if ((jtoken6 = jobject4["acceptedMinecraftVersions"]["value"]) != null)
									{
										goto IL_E0F;
									}
									jtoken6 = "";
									IL_E0F:
									string text12 = (string)jtoken6;
									if (Operators.CompareString(text12, "", true) != 0)
									{
										this.AddDependency("minecraft", text12);
									}
									JToken jtoken7;
									if (jobject4["dependencies"] == null)
									{
										if ((jtoken7 = "") != null)
										{
											goto IL_E74;
										}
									}
									else if ((jtoken7 = jobject4["dependencies"]["value"]) != null)
									{
										goto IL_E74;
									}
									jtoken7 = "";
									IL_E74:
									string text13 = (string)jtoken7;
									if (Operators.CompareString(text13, "", true) != 0)
									{
										foreach (string text14 in text13.Split(new char[]
										{
											';'
										}))
										{
											if (Operators.CompareString(text14, "", true) != 0 && text14.StartsWith("required-"))
											{
												text14 = text14.Substring(text14.IndexOf(":") + 1);
												if (text14.Contains("@"))
												{
													this.AddDependency(text14.Split(new char[]
													{
														'@'
													})[0], text14.Split(new char[]
													{
														'@'
													})[1]);
												}
												else
												{
													this.AddDependency(text14, null);
												}
											}
										}
									}
								}
							}
						}
					}
					catch (Exception ex4)
					{
						ModBase.Log(ex4, "读取 fml_cache_annotation.json 时出现未知错误（" + this.Path + "）", ModBase.LogLevel.Developer, "出现错误");
					}
					IL_F6F:
					if (Operators.CompareString(this._DecoratorParameter, "version", true) == 0)
					{
						try
						{
							ZipArchiveEntry entry5 = Jar.GetEntry("META-INF/MANIFEST.MF");
							if (entry5 != null)
							{
								string text15 = ModBase.ReadFile(entry5.Open(), null).Replace(" :", ":").Replace(": ", ":");
								if (text15.Contains("Implementation-Version:"))
								{
									text15 = text15.Substring(text15.IndexOf("Implementation-Version:") + "Implementation-Version:".Count<char>());
									text15 = text15.Substring(0, text15.IndexOfAny("\r\n".ToCharArray())).Trim();
									this.Version = text15;
								}
							}
						}
						catch (Exception ex5)
						{
							ModBase.Log("获取 META-INF 中的版本信息失败（" + this.Path + "）", ModBase.LogLevel.Developer, "出现错误");
							this.Version = null;
						}
					}
					if (this._DecoratorParameter != null && !this._DecoratorParameter.Contains(".") && !this._DecoratorParameter.Contains("-"))
					{
						this.Version = null;
					}
					this.watcherParameter = (this._PropertyParameter != null && this._DecoratorParameter != null);
				}
			}

			// Token: 0x06000A5A RID: 2650 RVA: 0x0005535C File Offset: 0x0005355C
			private void LoadWithClass(ZipArchive Jar)
			{
				checked
				{
					try
					{
						string text = null;
						string text2 = null;
						try
						{
							foreach (ZipArchiveEntry zipArchiveEntry in Jar.Entries)
							{
								if (zipArchiveEntry.Name.EndsWith(".class"))
								{
									string text3 = ModBase.ReadFile(zipArchiveEntry.Open(), null).ToLower();
									if (text3.Contains("#lnet/minecraftforge/fml/common/mod;"))
									{
										text = text3;
										break;
									}
									if (text3.Contains("modid"))
									{
										text2 = text3;
									}
								}
							}
						}
						finally
						{
							IEnumerator<ZipArchiveEntry> enumerator;
							if (enumerator != null)
							{
								enumerator.Dispose();
							}
						}
						if (text == null)
						{
							text = text2;
						}
						if (text == null)
						{
							throw new FileNotFoundException("未找到 Mod 入口点");
						}
						text = text.Replace("ljava/lang/string;", "");
						if (text.Count<char>() > 3000)
						{
							text = text.Substring(0, 3000);
						}
						int num;
						if (this._PropertyParameter == null)
						{
							num = text.IndexOf("modid") + "modid".Length + 1;
							int num2 = 0;
							while (Convert.ToInt32(text[num]) < 32)
							{
								num++;
								num2++;
								if (num2 > 10)
								{
									throw new Exception("ModID 头匹配失败");
								}
							}
							int num3 = num + 1;
							num2 = 0;
							while (Convert.ToInt32(text[num3]) >= 32)
							{
								num3++;
								num2++;
								if (num2 > 50)
								{
									throw new Exception("ModID 尾匹配失败");
								}
							}
							this.UpdatePrototype(text.Substring(num, num3 - num));
						}
						if (this._DecoratorParameter == null && text.Contains("version"))
						{
							num = text.IndexOf("version") + "version".Length + 1;
							int num2 = 0;
							while (Convert.ToInt32(text[num]) < 32)
							{
								num++;
								num2++;
								if (num2 > 10)
								{
									goto IL_227;
								}
							}
							int num3 = num + 1;
							num2 = 0;
							for (;;)
							{
								if (text[num3] != '.' && text[num3] != '-' && (text[num3] < '0' || text[num3] > '9'))
								{
									if (text[num3] < 'a')
									{
										break;
									}
									if (text[num3] > 'z')
									{
										break;
									}
								}
								num3++;
								num2++;
								if (num2 > 50)
								{
									goto IL_227;
								}
							}
							this._DecoratorParameter = text.Substring(num, num3 - num);
						}
						IL_227:
						num = text.IndexOf("dependencies");
						if (num > 0)
						{
							if (text.Count<char>() >= num + 300)
							{
								text = text.Substring(num, 299);
							}
							List<string> list = ModBase.RegexSearch(text, "(?<=required-((before|after|before-client|after-client)?):)[0-9a-z]+(@[\\(\\[]{1}[0-9.,]+[\\)\\]]{1})?", RegexOptions.None);
							try
							{
								foreach (string text4 in list)
								{
									if (!string.IsNullOrEmpty(text4))
									{
										if (text4.Contains("@"))
										{
											this.AddDependency(text4.Split(new char[]
											{
												'@'
											})[0], text4.Split(new char[]
											{
												'@'
											})[1]);
										}
										else
										{
											this.AddDependency(text4, null);
										}
									}
								}
							}
							finally
							{
								List<string>.Enumerator enumerator2;
								((IDisposable)enumerator2).Dispose();
							}
						}
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "Mod Class 信息不可用（" + (this.Path ?? "null") + "）", ModBase.LogLevel.Normal, "出现错误");
					}
					this.taskParameter = (this._PropertyParameter != null && this._DecoratorParameter != null);
				}
			}

			// Token: 0x06000A5B RID: 2651 RVA: 0x000556EC File Offset: 0x000538EC
			public bool IsPresetMod()
			{
				return this.ForgotPrototype().Count == 0 && this.Name != null && (this.Name.ToLower().Contains("core") || this.Name.ToLower().Contains("lib"));
			}

			// Token: 0x06000A5C RID: 2652 RVA: 0x00055740 File Offset: 0x00053940
			public static object IsModFile(string Path)
			{
				object result;
				if (Path != null && Path.Contains("."))
				{
					Path = Path.ToLower();
					if (!Path.EndsWith(".jar") && !Path.EndsWith(".zip") && !Path.EndsWith(".litemod") && !Path.EndsWith(".jar.disabled") && !Path.EndsWith(".zip.disabled") && !Path.EndsWith(".litemod.disabled"))
					{
						result = false;
					}
					else
					{
						result = true;
					}
				}
				else
				{
					result = false;
				}
				return result;
			}

			// Token: 0x04000579 RID: 1401
			public readonly string Path;

			// Token: 0x0400057A RID: 1402
			private string _ClientParameter;

			// Token: 0x0400057B RID: 1403
			private string _InfoParameter;

			// Token: 0x0400057C RID: 1404
			private string _DecoratorParameter;

			// Token: 0x0400057D RID: 1405
			private string _PropertyParameter;

			// Token: 0x0400057E RID: 1406
			public List<string> descriptorParameter;

			// Token: 0x0400057F RID: 1407
			private string mapParameter;

			// Token: 0x04000580 RID: 1408
			private string m_EventParameter;

			// Token: 0x04000581 RID: 1409
			private Dictionary<string, string> algoParameter;

			// Token: 0x04000582 RID: 1410
			private bool m_PoolParameter;

			// Token: 0x04000583 RID: 1411
			private Exception publisherParameter;

			// Token: 0x04000584 RID: 1412
			private bool watcherParameter;

			// Token: 0x04000585 RID: 1413
			private bool testParameter;

			// Token: 0x04000586 RID: 1414
			private bool taskParameter;

			// Token: 0x0200011C RID: 284
			public enum McModState
			{
				// Token: 0x04000588 RID: 1416
				Fine,
				// Token: 0x04000589 RID: 1417
				Disabled,
				// Token: 0x0400058A RID: 1418
				Unavaliable
			}
		}

		// Token: 0x0200011D RID: 285
		public class VersionSorter : IComparer<string>
		{
			// Token: 0x06000A5E RID: 2654 RVA: 0x00007045 File Offset: 0x00005245
			public int Compare(string x, string y)
			{
				return checked(ModMinecraft.VersionSortInteger(x, y) * (this.m_IteratorParameter ? -1 : 1));
			}

			// Token: 0x06000A5F RID: 2655 RVA: 0x0000705B File Offset: 0x0000525B
			public VersionSorter(bool IsDecreased = true)
			{
				this.m_IteratorParameter = true;
				this.m_IteratorParameter = IsDecreased;
			}

			// Token: 0x0400058B RID: 1419
			public bool m_IteratorParameter;
		}
	}
}
