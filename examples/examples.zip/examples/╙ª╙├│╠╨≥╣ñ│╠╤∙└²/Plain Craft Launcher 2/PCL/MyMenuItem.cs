﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000054 RID: 84
	public class MyMenuItem : MenuItem
	{
		// Token: 0x06000235 RID: 565 RVA: 0x00016198 File Offset: 0x00014398
		public MyMenuItem()
		{
			base.Loaded += this.MyMenuItem_Loaded;
			base.MouseEnter += delegate(object sender, MouseEventArgs e)
			{
				this.RefreshColor();
			};
			base.MouseLeave += delegate(object sender, MouseEventArgs e)
			{
				this.RefreshColor();
			};
			base.IsEnabledChanged += delegate(object sender, DependencyPropertyChangedEventArgs e)
			{
				this.RefreshColor();
			};
			this._Mapping = ModBase.GetUuid();
		}

		// Token: 0x06000236 RID: 566 RVA: 0x00016200 File Offset: 0x00014400
		private void MyMenuItem_Loaded(object sender, RoutedEventArgs e)
		{
			if (base.Icon != null)
			{
				Path path = (Path)base.GetTemplateChild("Icon");
				if (path != null)
				{
					path.Data = (Geometry)new GeometryConverter().ConvertFromString(Conversions.ToString(base.Icon));
				}
			}
		}

		// Token: 0x06000237 RID: 567 RVA: 0x0001624C File Offset: 0x0001444C
		private void RefreshColor()
		{
			string text;
			string text2;
			int time;
			if (!base.IsEnabled)
			{
				text = "ColorBrushTransparent";
				text2 = "ColorBrushGray5";
				time = 200;
			}
			else if (base.IsMouseOver)
			{
				text = "ColorBrush6";
				text2 = "ColorBrush2";
				time = 100;
			}
			else
			{
				text = "ColorBrushTransparent";
				text2 = "ColorBrush1";
				time = 200;
			}
			if (Operators.CompareString(this.m_Dispatcher, text, true) != 0)
			{
				this.m_Dispatcher = text;
				if (base.IsLoaded && ModAnimation.DefineModel() == 0)
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaColor(this, Control.BackgroundProperty, text, time, 0, null, false),
						ModAnimation.AaColor(this, Control.ForegroundProperty, text2, time, 0, null, false)
					}, "MyMenuItem Color " + Conversions.ToString(this._Mapping), false);
					return;
				}
				ModAnimation.AniStop("MyMenuItem Color " + Conversions.ToString(this._Mapping));
				base.SetResourceReference(Control.BackgroundProperty, text);
				base.SetResourceReference(Control.ForegroundProperty, text2);
			}
		}

		// Token: 0x040000FD RID: 253
		public int _Mapping;

		// Token: 0x040000FE RID: 254
		private string m_Dispatcher;
	}
}
