﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Newtonsoft.Json.Linq;

namespace PCL
{
	// Token: 0x02000013 RID: 19
	public class MyCard : Grid
	{
		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06000076 RID: 118 RVA: 0x0000272E File Offset: 0x0000092E
		// (set) Token: 0x06000077 RID: 119 RVA: 0x00002740 File Offset: 0x00000940
		public string Title
		{
			get
			{
				return Conversions.ToString(base.GetValue(MyCard.writer));
			}
			set
			{
				base.SetValue(MyCard.writer, value);
				if (this._Adapter != null)
				{
					this._Adapter.Text = value;
				}
			}
		}

		// Token: 0x06000078 RID: 120 RVA: 0x0000CA40 File Offset: 0x0000AC40
		public MyCard()
		{
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.MyCard_Loaded();
			};
			base.MouseEnter += this.MyCard_MouseEnter;
			base.MouseLeave += this.MyCard_MouseLeave;
			base.SizeChanged += this.MySizeChanged;
			base.MouseLeftButtonDown += this.MyCard_MouseLeftButtonDown;
			base.MouseLeftButtonUp += this.MyCard_MouseLeftButtonUp;
			base.MouseLeave += this.MyCard_MouseLeave_Swap;
			this._System = ModBase.GetUuid();
			this._Attribute = false;
			this.UseAnimation = true;
			this.predicate = false;
			this.CanSwap = false;
			this._Event = false;
			this.SwapLogoRight = false;
			this.pool = false;
			this._Params = new SystemDropShadowChrome
			{
				Margin = new Thickness(-9.5, -9.0, 0.5, -0.5),
				Opacity = 0.1,
				CornerRadius = new CornerRadius(6.0)
			};
			this._Params.SetResourceReference(SystemDropShadowChrome.m_ModelTag, "ColorObject1");
			base.Children.Add(this._Params);
			this._Mock = new Border
			{
				Background = new SolidColorBrush(Color.FromArgb(205, byte.MaxValue, byte.MaxValue, byte.MaxValue)),
				CornerRadius = new CornerRadius(6.0),
				IsHitTestVisible = false
			};
			base.Children.Add(this._Mock);
			this.definition = new Grid();
			base.Children.Add(this.definition);
		}

		// Token: 0x06000079 RID: 121 RVA: 0x0000CC0C File Offset: 0x0000AE0C
		private void MyCard_Loaded()
		{
			if (!this._Attribute)
			{
				if (Operators.CompareString(this.Title, "", true) != 0 && Information.IsNothing(this._Adapter))
				{
					this._Adapter = new TextBlock
					{
						HorizontalAlignment = HorizontalAlignment.Left,
						VerticalAlignment = VerticalAlignment.Top,
						Margin = new Thickness(15.0, 12.0, 0.0, 0.0),
						FontWeight = FontWeights.Bold,
						FontSize = 13.0,
						IsHitTestVisible = false
					};
					this._Adapter.SetResourceReference(TextBlock.ForegroundProperty, "ColorBrush1");
					this._Adapter.SetBinding(TextBlock.TextProperty, new Binding("Title")
					{
						Source = this,
						Mode = BindingMode.OneWay
					});
					this.definition.Children.Add(this._Adapter);
				}
				if (this.CanSwap || this.m_Decorator != null)
				{
					if (this.m_Decorator == null && base.Children.Count > 3)
					{
						this.m_Decorator = base.Children[3];
					}
					this.initializer = new Path
					{
						HorizontalAlignment = HorizontalAlignment.Right,
						Stretch = Stretch.Uniform,
						Height = 6.0,
						Width = 10.0,
						VerticalAlignment = VerticalAlignment.Top,
						Margin = new Thickness(0.0, 17.0, 16.0, 0.0),
						Data = (Geometry)new GeometryConverter().ConvertFromString("M2,4 l-2,2 10,10 10,-10 -2,-2 -8,8 -8,-8 z"),
						RenderTransform = new RotateTransform(180.0),
						RenderTransformOrigin = new Point(0.5, 0.5)
					};
					this.initializer.SetResourceReference(Shape.FillProperty, "ColorBrush1");
					this.definition.Children.Add(this.initializer);
				}
				this._Attribute = true;
				if (this.IsSwaped && this.m_Decorator != null)
				{
					this.initializer.RenderTransform = new RotateTransform((double)(this.SwapLogoRight ? 270 : 0));
					bool RawUseAnimation = this.UseAnimation;
					this.UseAnimation = false;
					base.Height = 40.0;
					ModAnimation.AniStop("MyCard Height " + Conversions.ToString(this._System));
					this.predicate = false;
					ModBase.RunInUi(delegate()
					{
						this.UseAnimation = RawUseAnimation;
					}, true);
				}
			}
		}

		// Token: 0x0600007A RID: 122 RVA: 0x0000CEC8 File Offset: 0x0000B0C8
		public void StackInstall()
		{
			StackPanel stackPanel = (StackPanel)this.m_Decorator;
			MyCard.StackInstall(ref stackPanel, this.ConcatModel(), this.Title);
			this.m_Decorator = stackPanel;
			this.TriggerForceResize();
		}

		// Token: 0x0600007B RID: 123 RVA: 0x0000CF00 File Offset: 0x0000B100
		public static void StackInstall(ref StackPanel Stack, int Type, string CardTitle = "")
		{
			if (!Information.IsNothing(RuntimeHelpers.GetObjectValue(Stack.Tag)))
			{
				switch (Type)
				{
				case 3:
					Stack.Tag = ModBase.Sort<ModDownload.DlOptiFineListEntry>((List<ModDownload.DlOptiFineListEntry>)Stack.Tag, (MyCard._Closure$__.$IR15-8 == null) ? (MyCard._Closure$__.$IR15-8 = ((object a0, object a1) => ((MyCard._Closure$__.$I15-0 == null) ? (MyCard._Closure$__.$I15-0 = ((ModDownload.DlOptiFineListEntry Left, ModDownload.DlOptiFineListEntry Right) => ModMinecraft.VersionSortBoolean(Left.m_SerializerProccesor, Right.m_SerializerProccesor))) : MyCard._Closure$__.$I15-0)((ModDownload.DlOptiFineListEntry)a0, (ModDownload.DlOptiFineListEntry)a1))) : MyCard._Closure$__.$IR15-8);
					break;
				case 4:
				case 10:
					Stack.Tag = ModBase.Sort<ModDownload.DlLiteLoaderListEntry>((List<ModDownload.DlLiteLoaderListEntry>)Stack.Tag, (MyCard._Closure$__.$IR15-9 == null) ? (MyCard._Closure$__.$IR15-9 = ((object a0, object a1) => ((MyCard._Closure$__.$I15-1 == null) ? (MyCard._Closure$__.$I15-1 = ((ModDownload.DlLiteLoaderListEntry Left, ModDownload.DlLiteLoaderListEntry Right) => ModMinecraft.VersionSortBoolean(Left.Inherit, Right.Inherit))) : MyCard._Closure$__.$I15-1)((ModDownload.DlLiteLoaderListEntry)a0, (ModDownload.DlLiteLoaderListEntry)a1))) : MyCard._Closure$__.$IR15-9);
					break;
				case 6:
					Stack.Tag = ModBase.Sort<ModDownload.DlForgeVersionEntry>((List<ModDownload.DlForgeVersionEntry>)Stack.Tag, (MyCard._Closure$__.$IR15-10 == null) ? (MyCard._Closure$__.$IR15-10 = ((object a0, object a1) => ((MyCard._Closure$__.$I15-2 == null) ? (MyCard._Closure$__.$I15-2 = ((ModDownload.DlForgeVersionEntry Left, ModDownload.DlForgeVersionEntry Right) => ModMinecraft.VersionSortBoolean(Left.productProccesor, Right.productProccesor))) : MyCard._Closure$__.$I15-2)((ModDownload.DlForgeVersionEntry)a0, (ModDownload.DlForgeVersionEntry)a1))) : MyCard._Closure$__.$IR15-10);
					break;
				case 8:
				case 9:
					Stack.Tag = ModBase.Sort<ModDownload.DlCfFile>((List<ModDownload.DlCfFile>)Stack.Tag, (MyCard._Closure$__.$IR15-11 == null) ? (MyCard._Closure$__.$IR15-11 = ((object a0, object a1) => ((MyCard._Closure$__.$I15-3 == null) ? (MyCard._Closure$__.$I15-3 = ((ModDownload.DlCfFile Left, ModDownload.DlCfFile Right) => DateTime.Compare(Left.m_ConsumerProccesor, Right.m_ConsumerProccesor) > 0)) : MyCard._Closure$__.$I15-3)((ModDownload.DlCfFile)a0, (ModDownload.DlCfFile)a1))) : MyCard._Closure$__.$IR15-11);
					break;
				}
				switch (Type)
				{
				case 5:
				{
					MyLoading myLoading = new MyLoading
					{
						Text = "正在获取版本列表",
						Margin = new Thickness(5.0)
					};
					ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>> loaderTask = new ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>("DlForgeVersion Main", new Action<ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>>(ModDownload.DlForgeVersionMain), null, ThreadPriority.Normal);
					myLoading.State = loaderTask;
					loaderTask.Start(RuntimeHelpers.GetObjectValue(Stack.Tag), false);
					MyLoading myLoading2 = myLoading;
					MyCard._Closure$__R15-1 CS$<>8__locals1 = new MyCard._Closure$__R15-1(CS$<>8__locals1);
					CS$<>8__locals1.$VB$NonLocal_2 = ModMain._DicAccount;
					myLoading2.InstantiateWrapper(delegate(object a0, MyLoading.MyLoadingState a1, MyLoading.MyLoadingState a2)
					{
						CS$<>8__locals1.$VB$NonLocal_2.Forge_StateChanged((MyLoading)a0, a1, a2);
					});
					MyLoading myLoading3 = myLoading;
					MyCard._Closure$__R15-2 CS$<>8__locals2 = new MyCard._Closure$__R15-2(CS$<>8__locals2);
					CS$<>8__locals2.$VB$NonLocal_3 = ModMain._DicAccount;
					myLoading3.PatchWrapper(delegate(object sender, MouseButtonEventArgs e)
					{
						CS$<>8__locals2.$VB$NonLocal_3.Forge_Click((MyLoading)sender, e);
					});
					Stack.Children.Add(myLoading);
					break;
				}
				case 6:
					ModDownloadLib.ForgeDownloadListItemPreload(Stack, (List<ModDownload.DlForgeVersionEntry>)Stack.Tag, new MyListItem.ClickEventHandler(ModDownloadLib.ForgeSave_Click), true);
					break;
				case 8:
				{
					StackPanel stack = Stack;
					List<ModDownload.DlCfFile> entrys = (List<ModDownload.DlCfFile>)Stack.Tag;
					MyCard._Closure$__R15-3 CS$<>8__locals3 = new MyCard._Closure$__R15-3(CS$<>8__locals3);
					CS$<>8__locals3.$VB$NonLocal_4 = ModMain.m_ConfigAccount;
					ModDownload.DlCfFilesPreload(stack, entrys, delegate(object sender, MouseButtonEventArgs e)
					{
						CS$<>8__locals3.$VB$NonLocal_4.ProjectClick((MyCfItem)sender, e);
					});
					break;
				}
				}
				try
				{
					foreach (object obj in ((IEnumerable)Stack.Tag))
					{
						object objectValue = RuntimeHelpers.GetObjectValue(obj);
						switch (Type)
						{
						case 0:
							Stack.Children.Add(PageSelectRight.McVersionListItem((ModMinecraft.McVersion)objectValue));
							break;
						case 1:
						{
							UIElementCollection children = Stack.Children;
							object obj2 = objectValue;
							children.Add(PageOtherFeedback.FeedbackListItem((obj2 != null) ? ((ModMain.FeedbackEntry)obj2) : default(ModMain.FeedbackEntry), CardTitle));
							break;
						}
						case 2:
							Stack.Children.Add(ModDownloadLib.McDownloadListItem((JObject)objectValue, new MyListItem.ClickEventHandler(ModDownloadLib.McDownloadMenuSave), true));
							break;
						case 3:
							Stack.Children.Add(ModDownloadLib.OptiFineDownloadListItem((ModDownload.DlOptiFineListEntry)objectValue, new MyListItem.ClickEventHandler(ModDownloadLib.OptiFineSave_Click), true));
							break;
						case 4:
						{
							UIElementCollection children2 = Stack.Children;
							ModDownload.DlLiteLoaderListEntry entry = (ModDownload.DlLiteLoaderListEntry)objectValue;
							MyCard._Closure$__R15-4 CS$<>8__locals4 = new MyCard._Closure$__R15-4(CS$<>8__locals4);
							CS$<>8__locals4.$VB$NonLocal_5 = ModMain._WorkerAccount;
							children2.Add(ModDownloadLib.LiteLoaderDownloadListItem(entry, delegate(object sender, MouseButtonEventArgs e)
							{
								CS$<>8__locals4.$VB$NonLocal_5.DownloadStart((MyListItem)sender, e);
							}, false));
							break;
						}
						case 5:
							break;
						case 6:
							Stack.Children.Add(ModDownloadLib.ForgeDownloadListItem((ModDownload.DlForgeVersionEntry)objectValue, new MyListItem.ClickEventHandler(ModDownloadLib.ForgeSave_Click), true));
							break;
						case 7:
						{
							UIElementCollection children3 = Stack.Children;
							JObject entry2 = (JObject)objectValue;
							MyCard._Closure$__R15-5 CS$<>8__locals5 = new MyCard._Closure$__R15-5(CS$<>8__locals5);
							CS$<>8__locals5.$VB$NonLocal_6 = ModMain._TestsAccount;
							children3.Add(ModDownloadLib.McDownloadListItem(entry2, delegate(object sender, MouseButtonEventArgs e)
							{
								CS$<>8__locals5.$VB$NonLocal_6.MinecraftSelected((MyListItem)sender, e);
							}, false));
							break;
						}
						case 8:
							Stack.Children.Add(((ModDownload.DlCfFile)objectValue).ToListItem(new MyListItem.ClickEventHandler(ModMain.modelState.Save_Click), null));
							break;
						case 9:
						{
							UIElementCollection children4 = Stack.Children;
							ModDownload.DlCfFile dlCfFile = (ModDownload.DlCfFile)objectValue;
							MyCard._Closure$__R15-6 CS$<>8__locals6 = new MyCard._Closure$__R15-6(CS$<>8__locals6);
							CS$<>8__locals6.$VB$NonLocal_7 = ModMain.modelState;
							children4.Add(dlCfFile.ToListItem(delegate(object sender, MouseButtonEventArgs e)
							{
								CS$<>8__locals6.$VB$NonLocal_7.Install_Click((MyListItem)sender, e);
							}, new MyIconButton.ClickEventHandler(ModMain.modelState.Save_Click)));
							break;
						}
						case 10:
							Stack.Children.Add(ModDownloadLib.LiteLoaderDownloadListItem((ModDownload.DlLiteLoaderListEntry)objectValue, new MyListItem.ClickEventHandler(ModDownloadLib.LiteLoaderSave_Click), true));
							break;
						case 11:
							Stack.Children.Add(((ModMain.HelpEntry)objectValue).ToListItem());
							break;
						default:
							ModBase.Log("未知的虚拟化种类：" + Conversions.ToString(Type), ModBase.LogLevel.Feedback, "出现错误");
							break;
						}
					}
				}
				finally
				{
					IEnumerator enumerator;
					if (enumerator is IDisposable)
					{
						(enumerator as IDisposable).Dispose();
					}
				}
				Stack.Children.Add(new FrameworkElement
				{
					Height = 18.0
				});
				Stack.Tag = null;
			}
		}

		// Token: 0x0600007C RID: 124 RVA: 0x0000D474 File Offset: 0x0000B674
		private void MyCard_MouseEnter(object sender, MouseEventArgs e)
		{
			List<ModAnimation.AniData> list = new List<ModAnimation.AniData>();
			if (!Information.IsNothing(this._Adapter))
			{
				list.Add(ModAnimation.AaColor(this._Adapter, TextBlock.ForegroundProperty, "ColorBrush2", 150, 0, null, false));
			}
			if (!Information.IsNothing(this.initializer))
			{
				list.Add(ModAnimation.AaColor(this.initializer, Shape.FillProperty, "ColorBrush2", 150, 0, null, false));
			}
			list.AddRange(new ModAnimation.AniData[]
			{
				ModAnimation.AaColor(this._Params, SystemDropShadowChrome.m_ModelTag, "ColorObject2", 180, 0, null, false),
				ModAnimation.AaColor(this._Mock, Border.BackgroundProperty, new ModBase.MyColor(230.0, 255.0, 255.0, 255.0) - this._Mock.Background, 180, 0, null, false),
				ModAnimation.AaOpacity(this._Params, 0.3 - this._Params.Opacity, 180, 0, null, false)
			});
			ModAnimation.AniStart(list, "MyCard Mouse " + Conversions.ToString(this._System), false);
		}

		// Token: 0x0600007D RID: 125 RVA: 0x0000D5C0 File Offset: 0x0000B7C0
		private void MyCard_MouseLeave(object sender, MouseEventArgs e)
		{
			List<ModAnimation.AniData> list = new List<ModAnimation.AniData>();
			if (!Information.IsNothing(this._Adapter))
			{
				list.Add(ModAnimation.AaColor(this._Adapter, TextBlock.ForegroundProperty, "ColorBrush1", 250, 0, null, false));
			}
			if (!Information.IsNothing(this.initializer))
			{
				list.Add(ModAnimation.AaColor(this.initializer, Shape.FillProperty, "ColorBrush1", 250, 0, null, false));
			}
			list.AddRange(new ModAnimation.AniData[]
			{
				ModAnimation.AaColor(this._Params, SystemDropShadowChrome.m_ModelTag, "ColorObject1", 300, 0, null, false),
				ModAnimation.AaColor(this._Mock, Border.BackgroundProperty, new ModBase.MyColor(205.0, 255.0, 255.0, 255.0) - this._Mock.Background, 300, 0, null, false),
				ModAnimation.AaOpacity(this._Params, 0.1 - this._Params.Opacity, 300, 0, null, false)
			});
			ModAnimation.AniStart(list, "MyCard Mouse " + Conversions.ToString(this._System), false);
		}

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x0600007E RID: 126 RVA: 0x00002762 File Offset: 0x00000962
		// (set) Token: 0x0600007F RID: 127 RVA: 0x0000276A File Offset: 0x0000096A
		public bool UseAnimation { get; set; }

		// Token: 0x06000080 RID: 128 RVA: 0x0000D70C File Offset: 0x0000B90C
		private void MySizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (this.UseAnimation)
			{
				double num = (this.IsSwaped ? 40.0 : e.NewSize.Height) - e.PreviousSize.Height;
				if (e.PreviousSize.Height != 0.0 && !this.predicate && Math.Abs(num) >= 1.0 && base.ActualHeight != 0.0)
				{
					this.StartHeightAnimation(num, e.PreviousSize.Height, false);
				}
			}
		}

		// Token: 0x06000081 RID: 129 RVA: 0x0000D7B0 File Offset: 0x0000B9B0
		private void StartHeightAnimation(double DeltaHeight, double PreviousHeight, bool IsLoadAnimation)
		{
			if (!this.predicate && ModMain.m_CollectionAccount != null)
			{
				List<ModAnimation.AniData> list = new List<ModAnimation.AniData>();
				if (DeltaHeight <= 10.0 && (DeltaHeight >= -10.0 || Information.IsNothing(RuntimeHelpers.GetObjectValue(this.m_Decorator))))
				{
					list.AddRange(new ModAnimation.AniData[]
					{
						ModAnimation.AaHeight(this, DeltaHeight, checked((int)Math.Round(ModBase.MathRange(unchecked(Math.Abs(DeltaHeight) * 4.0), 150.0, 250.0))), 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false)
					});
				}
				else
				{
					double num = ModBase.MathRange(Math.Abs(DeltaHeight) * 0.05, 3.0, 10.0) * (double)Math.Sign(DeltaHeight);
					list.AddRange(new ModAnimation.AniData[]
					{
						ModAnimation.AaHeight(this, DeltaHeight + num, 300, IsLoadAnimation ? 30 : 0, (ModAnimation.AniEase)((DeltaHeight > ModMain.m_CollectionAccount.Height) ? new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.ExtraStrong) : new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.ExtraStrong)), false),
						ModAnimation.AaHeight(this, -num, 150, 260, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false)
					});
				}
				list.Add(ModAnimation.AaCode(delegate
				{
					this.predicate = false;
					base.Height = this.client;
					if (this.IsSwaped)
					{
						NewLateBinding.LateSet(this.m_Decorator, null, "Visibility", new object[]
						{
							Visibility.Collapsed
						}, null, null);
					}
				}, 0, true));
				ModAnimation.AniStart(list, "MyCard Height " + Conversions.ToString(this._System), false);
				this.predicate = true;
				this.client = (this.IsSwaped ? 40.0 : base.Height);
				base.Height = PreviousHeight;
			}
		}

		// Token: 0x06000082 RID: 130 RVA: 0x0000D954 File Offset: 0x0000BB54
		public void TriggerForceResize()
		{
			base.Height = (this.IsSwaped ? 40.0 : double.NaN);
			ModAnimation.AniStop("MyCard Height " + Conversions.ToString(this._System));
			this.predicate = false;
		}

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x06000083 RID: 131 RVA: 0x00002773 File Offset: 0x00000973
		// (set) Token: 0x06000084 RID: 132 RVA: 0x0000277B File Offset: 0x0000097B
		public bool CanSwap { get; set; }

		// Token: 0x06000085 RID: 133 RVA: 0x00002784 File Offset: 0x00000984
		[CompilerGenerated]
		public int ConcatModel()
		{
			return this.map;
		}

		// Token: 0x06000086 RID: 134 RVA: 0x0000278C File Offset: 0x0000098C
		[CompilerGenerated]
		public void CustomizeModel(int AutoPropertyValue)
		{
			this.map = AutoPropertyValue;
		}

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x06000087 RID: 135 RVA: 0x00002795 File Offset: 0x00000995
		// (set) Token: 0x06000088 RID: 136 RVA: 0x0000D9A4 File Offset: 0x0000BBA4
		public bool IsSwaped
		{
			get
			{
				return this._Event;
			}
			set
			{
				if (this._Event != value)
				{
					this._Event = value;
					if (this.m_Decorator != null)
					{
						if (!this.IsSwaped && this.m_Decorator is StackPanel)
						{
							StackPanel stackPanel = (StackPanel)this.m_Decorator;
							MyCard.StackInstall(ref stackPanel, this.ConcatModel(), this.Title);
							this.m_Decorator = stackPanel;
						}
						if (base.IsLoaded)
						{
							NewLateBinding.LateSet(this.m_Decorator, null, "Visibility", new object[]
							{
								Visibility.Visible
							}, null, null);
							this.TriggerForceResize();
							ModAnimation.AniStart(ModAnimation.AaRotateTransform(this.initializer, (double)(this._Event ? (this.SwapLogoRight ? 270 : 0) : 180) - ((RotateTransform)this.initializer.RenderTransform).Angle, 400, 0, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Weak), false), "MyCard Swap " + Conversions.ToString(this._System), true);
						}
					}
				}
			}
		}

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x06000089 RID: 137 RVA: 0x0000279D File Offset: 0x0000099D
		// (set) Token: 0x0600008A RID: 138 RVA: 0x000027A5 File Offset: 0x000009A5
		public bool SwapLogoRight { get; set; }

		// Token: 0x0600008B RID: 139 RVA: 0x0000DAA4 File Offset: 0x0000BCA4
		[CompilerGenerated]
		public void RemoveModel(MyCard.PreviewSwapEventHandler obj)
		{
			MyCard.PreviewSwapEventHandler previewSwapEventHandler = this.publisher;
			MyCard.PreviewSwapEventHandler previewSwapEventHandler2;
			do
			{
				previewSwapEventHandler2 = previewSwapEventHandler;
				MyCard.PreviewSwapEventHandler value = (MyCard.PreviewSwapEventHandler)Delegate.Combine(previewSwapEventHandler2, obj);
				previewSwapEventHandler = Interlocked.CompareExchange<MyCard.PreviewSwapEventHandler>(ref this.publisher, value, previewSwapEventHandler2);
			}
			while (previewSwapEventHandler != previewSwapEventHandler2);
		}

		// Token: 0x0600008C RID: 140 RVA: 0x0000DADC File Offset: 0x0000BCDC
		[CompilerGenerated]
		public void LogoutModel(MyCard.PreviewSwapEventHandler obj)
		{
			MyCard.PreviewSwapEventHandler previewSwapEventHandler = this.publisher;
			MyCard.PreviewSwapEventHandler previewSwapEventHandler2;
			do
			{
				previewSwapEventHandler2 = previewSwapEventHandler;
				MyCard.PreviewSwapEventHandler value = (MyCard.PreviewSwapEventHandler)Delegate.Remove(previewSwapEventHandler2, obj);
				previewSwapEventHandler = Interlocked.CompareExchange<MyCard.PreviewSwapEventHandler>(ref this.publisher, value, previewSwapEventHandler2);
			}
			while (previewSwapEventHandler != previewSwapEventHandler2);
		}

		// Token: 0x0600008D RID: 141 RVA: 0x0000DB14 File Offset: 0x0000BD14
		[CompilerGenerated]
		public void ReflectModel(MyCard.SwapEventHandler obj)
		{
			MyCard.SwapEventHandler swapEventHandler = this.watcher;
			MyCard.SwapEventHandler swapEventHandler2;
			do
			{
				swapEventHandler2 = swapEventHandler;
				MyCard.SwapEventHandler value = (MyCard.SwapEventHandler)Delegate.Combine(swapEventHandler2, obj);
				swapEventHandler = Interlocked.CompareExchange<MyCard.SwapEventHandler>(ref this.watcher, value, swapEventHandler2);
			}
			while (swapEventHandler != swapEventHandler2);
		}

		// Token: 0x0600008E RID: 142 RVA: 0x0000DB4C File Offset: 0x0000BD4C
		[CompilerGenerated]
		public void ForgotModel(MyCard.SwapEventHandler obj)
		{
			MyCard.SwapEventHandler swapEventHandler = this.watcher;
			MyCard.SwapEventHandler swapEventHandler2;
			do
			{
				swapEventHandler2 = swapEventHandler;
				MyCard.SwapEventHandler value = (MyCard.SwapEventHandler)Delegate.Remove(swapEventHandler2, obj);
				swapEventHandler = Interlocked.CompareExchange<MyCard.SwapEventHandler>(ref this.watcher, value, swapEventHandler2);
			}
			while (swapEventHandler != swapEventHandler2);
		}

		// Token: 0x0600008F RID: 143 RVA: 0x0000DB84 File Offset: 0x0000BD84
		private void MyCard_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			double y = Mouse.GetPosition(this).Y;
			if (this.IsSwaped || (!Information.IsNothing(RuntimeHelpers.GetObjectValue(this.m_Decorator)) && y <= 40.0 && (y != 0.0 || base.IsMouseDirectlyOver)))
			{
				this.pool = true;
			}
		}

		// Token: 0x06000090 RID: 144 RVA: 0x0000DBE4 File Offset: 0x0000BDE4
		private void MyCard_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.pool)
			{
				this.pool = false;
				double y = Mouse.GetPosition(this).Y;
				if (this.IsSwaped || (!Information.IsNothing(RuntimeHelpers.GetObjectValue(this.m_Decorator)) && y <= 40.0 && (y != 0.0 || base.IsMouseDirectlyOver)))
				{
					ModBase.RouteEventArgs routeEventArgs = new ModBase.RouteEventArgs(true);
					MyCard.PreviewSwapEventHandler previewSwapEventHandler = this.publisher;
					if (previewSwapEventHandler != null)
					{
						previewSwapEventHandler(this, routeEventArgs);
					}
					if (routeEventArgs.proxyParameter)
					{
						this.pool = false;
						return;
					}
					this.IsSwaped = !this.IsSwaped;
					ModBase.Log("[Control] " + (this.IsSwaped ? "折叠卡片" : "展开卡片") + ((this.Title == null) ? "" : ("：" + this.Title)), ModBase.LogLevel.Normal, "出现错误");
					MyCard.SwapEventHandler swapEventHandler = this.watcher;
					if (swapEventHandler != null)
					{
						swapEventHandler(this, routeEventArgs);
					}
				}
			}
		}

		// Token: 0x06000091 RID: 145 RVA: 0x000027AE File Offset: 0x000009AE
		private void MyCard_MouseLeave_Swap(object sender, MouseEventArgs e)
		{
			this.pool = false;
		}

		// Token: 0x04000016 RID: 22
		private readonly Grid definition;

		// Token: 0x04000017 RID: 23
		private readonly SystemDropShadowChrome _Params;

		// Token: 0x04000018 RID: 24
		private readonly Border _Mock;

		// Token: 0x04000019 RID: 25
		public TextBlock _Adapter;

		// Token: 0x0400001A RID: 26
		public Path initializer;

		// Token: 0x0400001B RID: 27
		public int _System;

		// Token: 0x0400001C RID: 28
		public static readonly DependencyProperty writer = DependencyProperty.Register("Title", typeof(string), typeof(MyCard), new PropertyMetadata(""));

		// Token: 0x0400001D RID: 29
		private bool _Attribute;

		// Token: 0x0400001E RID: 30
		[CompilerGenerated]
		private bool m_Specification;

		// Token: 0x0400001F RID: 31
		private bool predicate;

		// Token: 0x04000020 RID: 32
		private double client;

		// Token: 0x04000021 RID: 33
		public object m_Decorator;

		// Token: 0x04000022 RID: 34
		[CompilerGenerated]
		private bool descriptor;

		// Token: 0x04000023 RID: 35
		[CompilerGenerated]
		private int map;

		// Token: 0x04000024 RID: 36
		private bool _Event;

		// Token: 0x04000025 RID: 37
		[CompilerGenerated]
		private bool algo;

		// Token: 0x04000026 RID: 38
		private bool pool;

		// Token: 0x04000027 RID: 39
		[CompilerGenerated]
		private MyCard.PreviewSwapEventHandler publisher;

		// Token: 0x04000028 RID: 40
		[CompilerGenerated]
		private MyCard.SwapEventHandler watcher;

		// Token: 0x02000014 RID: 20
		// (Invoke) Token: 0x06000097 RID: 151
		public delegate void PreviewSwapEventHandler(object sender, ModBase.RouteEventArgs e);

		// Token: 0x02000015 RID: 21
		// (Invoke) Token: 0x0600009C RID: 156
		public delegate void SwapEventHandler(object sender, ModBase.RouteEventArgs e);
	}
}
