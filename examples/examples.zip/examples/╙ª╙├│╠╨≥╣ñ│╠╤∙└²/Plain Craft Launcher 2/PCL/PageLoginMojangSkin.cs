﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000131 RID: 305
	[DesignerGenerated]
	public class PageLoginMojangSkin : Grid, IComponentConnector
	{
		// Token: 0x06000BC1 RID: 3009 RVA: 0x00007D28 File Offset: 0x00005F28
		public PageLoginMojangSkin()
		{
			base.Loaded += this.PageLoginLegacy_Loaded;
			this.InitializeComponent();
			this.Skin.m_RepositoryComparator = PageLaunchLeft.facadeComparator;
		}

		// Token: 0x06000BC2 RID: 3010 RVA: 0x00007D59 File Offset: 0x00005F59
		private void PageLoginLegacy_Loaded(object sender, RoutedEventArgs e)
		{
			this.Skin.m_RepositoryComparator.Start(null, false);
		}

		// Token: 0x06000BC3 RID: 3011 RVA: 0x0005C17C File Offset: 0x0005A37C
		public void Reload(bool KeepInput)
		{
			this.TextName.Text = Conversions.ToString(ModBase._ParamsState.Get("CacheMojangName", null));
			this.TextEmail.Text = Conversions.ToString(ModBase._ParamsState.Get("CacheMojangUsername", null));
			this.TextEmail.Visibility = (Conversions.ToBoolean(ModBase._ParamsState.Get("UiLauncherEmail", null)) ? Visibility.Collapsed : Visibility.Visible);
		}

		// Token: 0x06000BC4 RID: 3012 RVA: 0x0005C1F0 File Offset: 0x0005A3F0
		public static ModLaunch.McLoginServer GetLoginData()
		{
			return new ModLaunch.McLoginServer(ModLaunch.McLoginType.Mojang)
			{
				_StubProccesor = "https://authserver.mojang.com",
				m_ErrorProccesor = "Mojang",
				m_InterpreterProccesor = Conversions.ToString(ModBase._ParamsState.Get("CacheMojangUsername", null)),
				_ParserProccesor = Conversions.ToString(ModBase._ParamsState.Get("CacheMojangPass", null)),
				_ExceptionProccesor = "Mojang 正版",
				Type = ModLaunch.McLoginType.Mojang
			};
		}

		// Token: 0x06000BC5 RID: 3013 RVA: 0x0005C264 File Offset: 0x0005A464
		private void PageLoginMojangSkin_MouseEnter(object sender, MouseEventArgs e)
		{
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaOpacity(this.BtnEdit, 1.0 - this.BtnEdit.Opacity, 80, 0, null, false),
				ModAnimation.AaHeight(this.BtnEdit, 25.5 - this.BtnEdit.Height, 140, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaHeight(this.BtnEdit, -1.5, 50, 140, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaOpacity(this.BtnExit, 1.0 - this.BtnExit.Opacity, 80, 0, null, false),
				ModAnimation.AaHeight(this.BtnExit, 25.5 - this.BtnExit.Height, 140, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaHeight(this.BtnExit, -1.5, 50, 140, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false)
			}, "PageLoginMojangSkin Button", false);
		}

		// Token: 0x06000BC6 RID: 3014 RVA: 0x0005C394 File Offset: 0x0005A594
		private void PageLoginMojangSkin_MouseLeave(object sender, MouseEventArgs e)
		{
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaOpacity(this.BtnEdit, -this.BtnEdit.Opacity, 120, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaHeight(this.BtnEdit, 14.0 - this.BtnEdit.Height, 120, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaOpacity(this.BtnExit, -this.BtnExit.Opacity, 120, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaHeight(this.BtnExit, 14.0 - this.BtnExit.Height, 120, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false)
			}, "PageLoginMojangSkin Button", false);
		}

		// Token: 0x06000BC7 RID: 3015 RVA: 0x0005C464 File Offset: 0x0005A664
		private void BtnEdit_Click(object sender, EventArgs e)
		{
			switch (ModMain.MyMsgBox("你希望通过哪种途径更改密码？\r\n首次通过个人档案修改密码可能需要验证你的密保问题。", "更改密码", "个人档案", "密保邮箱", "取消", false, true, false))
			{
			case 1:
				ModBase.OpenWebsite("https://www.minecraft.net/zh-hans/profile/");
				return;
			case 2:
				ModBase.OpenWebsite("https://account.mojang.com/password");
				break;
			case 3:
				break;
			default:
				return;
			}
		}

		// Token: 0x06000BC8 RID: 3016 RVA: 0x00007D6D File Offset: 0x00005F6D
		private void BtnExit_Click()
		{
			ModBase._ParamsState.Set("CacheMojangAccess", "", false, null);
			ModMain._FilterAccount.RefreshPage(false, true);
		}

		// Token: 0x06000BC9 RID: 3017 RVA: 0x0005C4C0 File Offset: 0x0005A6C0
		private void Skin_Click(object sender, MouseButtonEventArgs e)
		{
			if (ModLaunch.m_IndexerTag.State == ModBase.LoadState.Failed)
			{
				ModMain.Hint("登录失败，无法更改皮肤！", ModMain.HintType.Critical, true);
				return;
			}
			ModMinecraft.McSkinInfo SkinInfo = ModMinecraft.McSkinSelect(false);
			if (SkinInfo._CodeParameter)
			{
				ModMain.Hint("正在更改皮肤……", ModMain.HintType.Info, true);
				ModBase.RunInNewThread(async delegate
				{
					try
					{
						if (ModLaunch.m_IndexerTag.State == ModBase.LoadState.Loading)
						{
							ModLaunch.m_IndexerTag.WaitForExit(null, null, false);
						}
						string parameter = Conversions.ToString(RuntimeHelpers.GetObjectValue(ModBase._ParamsState.Get("CacheMojangAccess", null)));
						string str = Conversions.ToString(RuntimeHelpers.GetObjectValue(ModBase._ParamsState.Get("CacheMojangUuid", null)));
						HttpClient httpClient = new HttpClient();
						httpClient.Timeout = new TimeSpan(0, 0, 10);
						httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", parameter);
						httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("*/*"));
						httpClient.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue("MojangSharp", "0.1"));
						MultipartFormDataContent content = new MultipartFormDataContent
						{
							{
								new StringContent(SkinInfo.m_ReponseParameter ? "slim" : ""),
								"model"
							},
							{
								new ByteArrayContent(File.ReadAllBytes(SkinInfo.m_ContainerParameter)),
								"file",
								ModBase.GetFileNameFromPath(SkinInfo.m_ContainerParameter)
							}
						};
						TaskAwaiter<string> taskAwaiter = (await httpClient.PutAsync(new Uri("https://api.mojang.com/user/profile/" + str + "/skin"), content)).Content.ReadAsStringAsync().GetAwaiter();
						if (!taskAwaiter.IsCompleted)
						{
							await taskAwaiter;
							TaskAwaiter<string> taskAwaiter2;
							taskAwaiter = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter<string>);
						}
						string result = taskAwaiter.GetResult();
						taskAwaiter = default(TaskAwaiter<string>);
						string text = result;
						if (ModBase.RegexCheck(text, "^[0-9a-f]{59,64}$", RegexOptions.None))
						{
							MySkin.ReloadCache("http://textures.minecraft.net/texture/" + text, false);
						}
						else if (text.ToLower().Contains("ip not secured"))
						{
							if (ModMain.MyMsgBox("首次操作需要在官网验证密保问题。\r\n验证完成后，你即可使用 PCL 更改皮肤，且无需再次验证。", "验证密保问题", "开始验证", "取消", "", false, true, false) == 1)
							{
								ModBase.OpenWebsite("https://www.minecraft.net/zh-hans/profile/skin");
							}
						}
						else if (text.Contains("request requires user authentication"))
						{
							ModMain.Hint("正在重新登录，请稍后再次尝试更改皮肤！", ModMain.HintType.Info, true);
							ModBase.RunInUi(delegate()
							{
								this.BtnExit_Click();
								if (string.IsNullOrEmpty(ModLaunch.McLoginAble()))
								{
									ModLaunch.m_IndexerTag.Start(null, false);
								}
							}, false);
						}
						else
						{
							if (!text.Contains("\"errorMessage\""))
							{
								throw new Exception("未知错误（" + text + "）");
							}
							ModMain.Hint(Conversions.ToString(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject("更改皮肤失败：", NewLateBinding.LateIndexGet(ModBase.GetJson(text), new object[]
							{
								"errorMessage"
							}, null)))), ModMain.HintType.Critical, true);
						}
					}
					catch (Exception ex)
					{
						if (ex.GetType().Equals(typeof(TaskCanceledException)))
						{
							ModMain.Hint("更改皮肤失败：与 Mojang 皮肤服务器的连接超时，请检查你的网络是否通畅！", ModMain.HintType.Critical, true);
						}
						else
						{
							ModBase.Log(ex, "更改皮肤失败", ModBase.LogLevel.Hint, "出现错误");
						}
					}
				}, "Mojang Skin Upload", ThreadPriority.Normal);
			}
		}

		// Token: 0x170001B2 RID: 434
		// (get) Token: 0x06000BCA RID: 3018 RVA: 0x00007D91 File Offset: 0x00005F91
		// (set) Token: 0x06000BCB RID: 3019 RVA: 0x0005C534 File Offset: 0x0005A734
		internal virtual Grid PanData
		{
			[CompilerGenerated]
			get
			{
				return this._PredicateComparator;
			}
			[CompilerGenerated]
			set
			{
				MouseEventHandler value2 = new MouseEventHandler(this.PageLoginMojangSkin_MouseEnter);
				MouseEventHandler value3 = new MouseEventHandler(this.PageLoginMojangSkin_MouseLeave);
				Grid predicateComparator = this._PredicateComparator;
				if (predicateComparator != null)
				{
					predicateComparator.MouseEnter -= value2;
					predicateComparator.MouseLeave -= value3;
				}
				this._PredicateComparator = value;
				predicateComparator = this._PredicateComparator;
				if (predicateComparator != null)
				{
					predicateComparator.MouseEnter += value2;
					predicateComparator.MouseLeave += value3;
				}
			}
		}

		// Token: 0x170001B3 RID: 435
		// (get) Token: 0x06000BCC RID: 3020 RVA: 0x00007D99 File Offset: 0x00005F99
		// (set) Token: 0x06000BCD RID: 3021 RVA: 0x00007DA1 File Offset: 0x00005FA1
		internal virtual TextBlock TextName { get; set; }

		// Token: 0x170001B4 RID: 436
		// (get) Token: 0x06000BCE RID: 3022 RVA: 0x00007DAA File Offset: 0x00005FAA
		// (set) Token: 0x06000BCF RID: 3023 RVA: 0x00007DB2 File Offset: 0x00005FB2
		internal virtual TextBlock TextEmail { get; set; }

		// Token: 0x170001B5 RID: 437
		// (get) Token: 0x06000BD0 RID: 3024 RVA: 0x00007DBB File Offset: 0x00005FBB
		// (set) Token: 0x06000BD1 RID: 3025 RVA: 0x0005C594 File Offset: 0x0005A794
		internal virtual MyIconButton BtnEdit
		{
			[CompilerGenerated]
			get
			{
				return this.m_DecoratorComparator;
			}
			[CompilerGenerated]
			set
			{
				MyIconButton.ClickEventHandler value2 = new MyIconButton.ClickEventHandler(this.BtnEdit_Click);
				MyIconButton decoratorComparator = this.m_DecoratorComparator;
				if (decoratorComparator != null)
				{
					decoratorComparator.Click -= value2;
				}
				this.m_DecoratorComparator = value;
				decoratorComparator = this.m_DecoratorComparator;
				if (decoratorComparator != null)
				{
					decoratorComparator.Click += value2;
				}
			}
		}

		// Token: 0x170001B6 RID: 438
		// (get) Token: 0x06000BD2 RID: 3026 RVA: 0x00007DC3 File Offset: 0x00005FC3
		// (set) Token: 0x06000BD3 RID: 3027 RVA: 0x0005C5D8 File Offset: 0x0005A7D8
		internal virtual MyIconButton BtnExit
		{
			[CompilerGenerated]
			get
			{
				return this.m_PropertyComparator;
			}
			[CompilerGenerated]
			set
			{
				MyIconButton.ClickEventHandler value2 = delegate(object sender, EventArgs e)
				{
					this.BtnExit_Click();
				};
				MyIconButton propertyComparator = this.m_PropertyComparator;
				if (propertyComparator != null)
				{
					propertyComparator.Click -= value2;
				}
				this.m_PropertyComparator = value;
				propertyComparator = this.m_PropertyComparator;
				if (propertyComparator != null)
				{
					propertyComparator.Click += value2;
				}
			}
		}

		// Token: 0x170001B7 RID: 439
		// (get) Token: 0x06000BD4 RID: 3028 RVA: 0x00007DCB File Offset: 0x00005FCB
		// (set) Token: 0x06000BD5 RID: 3029 RVA: 0x0005C61C File Offset: 0x0005A81C
		internal virtual MySkin Skin
		{
			[CompilerGenerated]
			get
			{
				return this.descriptorComparator;
			}
			[CompilerGenerated]
			set
			{
				MySkin.ClickEventHandler obj = new MySkin.ClickEventHandler(this.Skin_Click);
				MySkin mySkin = this.descriptorComparator;
				if (mySkin != null)
				{
					mySkin.ResolveResolver(obj);
				}
				this.descriptorComparator = value;
				mySkin = this.descriptorComparator;
				if (mySkin != null)
				{
					mySkin.VerifyResolver(obj);
				}
			}
		}

		// Token: 0x06000BD6 RID: 3030 RVA: 0x0005C660 File Offset: 0x0005A860
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.mapComparator)
			{
				this.mapComparator = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagelaunch/pageloginmojangskin.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000BD7 RID: 3031 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000BD8 RID: 3032 RVA: 0x0005C690 File Offset: 0x0005A890
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanData = (Grid)target;
				return;
			}
			if (connectionId == 2)
			{
				this.TextName = (TextBlock)target;
				return;
			}
			if (connectionId == 3)
			{
				this.TextEmail = (TextBlock)target;
				return;
			}
			if (connectionId == 4)
			{
				this.BtnEdit = (MyIconButton)target;
				return;
			}
			if (connectionId == 5)
			{
				this.BtnExit = (MyIconButton)target;
				return;
			}
			if (connectionId == 6)
			{
				this.Skin = (MySkin)target;
				return;
			}
			this.mapComparator = true;
		}

		// Token: 0x04000606 RID: 1542
		[AccessedThroughProperty("PanData")]
		[CompilerGenerated]
		private Grid _PredicateComparator;

		// Token: 0x04000607 RID: 1543
		[CompilerGenerated]
		[AccessedThroughProperty("TextName")]
		private TextBlock clientComparator;

		// Token: 0x04000608 RID: 1544
		[CompilerGenerated]
		[AccessedThroughProperty("TextEmail")]
		private TextBlock _InfoComparator;

		// Token: 0x04000609 RID: 1545
		[CompilerGenerated]
		[AccessedThroughProperty("BtnEdit")]
		private MyIconButton m_DecoratorComparator;

		// Token: 0x0400060A RID: 1546
		[CompilerGenerated]
		[AccessedThroughProperty("BtnExit")]
		private MyIconButton m_PropertyComparator;

		// Token: 0x0400060B RID: 1547
		[CompilerGenerated]
		[AccessedThroughProperty("Skin")]
		private MySkin descriptorComparator;

		// Token: 0x0400060C RID: 1548
		private bool mapComparator;
	}
}
