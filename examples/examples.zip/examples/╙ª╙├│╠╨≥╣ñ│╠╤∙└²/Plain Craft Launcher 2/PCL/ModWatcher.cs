﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200006C RID: 108
	[StandardModule]
	public sealed class ModWatcher
	{
		// Token: 0x0600032D RID: 813 RVA: 0x0001C500 File Offset: 0x0001A700
		private static void WatcherStateChanged()
		{
			bool flag = false;
			bool hasMinecraftCrashed = false;
			try
			{
				foreach (ModWatcher.Watcher watcher in ModWatcher._ItemWrapper)
				{
					if (watcher.State != ModWatcher.Watcher.MinecraftState.Loading)
					{
						if (watcher.State != ModWatcher.Watcher.MinecraftState.Running)
						{
							if (watcher.State == ModWatcher.Watcher.MinecraftState.Crashed)
							{
								hasMinecraftCrashed = true;
								continue;
							}
							continue;
						}
					}
					flag = true;
					break;
				}
			}
			finally
			{
				List<ModWatcher.Watcher>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			if (ModWatcher.m_MapperWrapper != flag)
			{
				ModWatcher.m_MapperWrapper = flag;
				if (ModWatcher.m_MapperWrapper)
				{
					ModWatcher.MinecraftStart();
					return;
				}
				ModWatcher.MinecraftStop(hasMinecraftCrashed);
			}
		}

		// Token: 0x0600032E RID: 814 RVA: 0x00003BCD File Offset: 0x00001DCD
		private static void MinecraftStart()
		{
			ModLaunch.McLaunchLog("[全局] 出现运行中的 Minecraft");
			ModWatcher.factoryWrapper = true;
			ModMain.m_CollectionAccount.BtnExtraShutdown.ShowRefresh();
		}

		// Token: 0x0600032F RID: 815 RVA: 0x0001C594 File Offset: 0x0001A794
		private static void MinecraftStop(bool HasMinecraftCrashed)
		{
			ModLaunch.McLaunchLog("[全局] 已无运行中的 Minecraft");
			ModWatcher.factoryWrapper = false;
			ModMain.m_CollectionAccount.BtnExtraShutdown.ShowRefresh();
			if (Conversions.ToBoolean(ModBase._ParamsState.Get("UiMusicStop", null)))
			{
				ModBase.RunInUi((ModWatcher._Closure$__.$I6-0 == null) ? (ModWatcher._Closure$__.$I6-0 = delegate()
				{
					if (ModMusic.MusicResume())
					{
						ModBase.Log("[Music] 已根据设置，在结束后开始音乐播放", ModBase.LogLevel.Normal, "出现错误");
					}
				}) : ModWatcher._Closure$__.$I6-0, false);
			}
			else if (Conversions.ToBoolean(ModBase._ParamsState.Get("UiMusicStart", null)))
			{
				ModBase.RunInUi((ModWatcher._Closure$__.$I6-1 == null) ? (ModWatcher._Closure$__.$I6-1 = delegate()
				{
					if (ModMusic.MusicPause())
					{
						ModBase.Log("[Music] 已根据设置，在结束后暂停音乐播放", ModBase.LogLevel.Normal, "出现错误");
					}
				}) : ModWatcher._Closure$__.$I6-1, false);
			}
			object left = ModBase._ParamsState.Get("LaunchArgumentVisible", null);
			if (!Operators.ConditionalCompareObjectEqual(left, 2, true))
			{
				if (Operators.ConditionalCompareObjectEqual(left, 3, true))
				{
					ModBase.RunInUi((ModWatcher._Closure$__.$I6-4 == null) ? (ModWatcher._Closure$__.$I6-4 = delegate()
					{
						ModMain.m_CollectionAccount.Hidden = false;
					}) : ModWatcher._Closure$__.$I6-4, false);
				}
				return;
			}
			if (HasMinecraftCrashed)
			{
				ModBase.RunInUi((ModWatcher._Closure$__.$I6-2 == null) ? (ModWatcher._Closure$__.$I6-2 = delegate()
				{
					ModMain.m_CollectionAccount.Hidden = false;
				}) : ModWatcher._Closure$__.$I6-2, false);
				return;
			}
			ModBase.RunInUi((ModWatcher._Closure$__.$I6-3 == null) ? (ModWatcher._Closure$__.$I6-3 = delegate()
			{
				ModMain.m_CollectionAccount.EndProgram(false);
			}) : ModWatcher._Closure$__.$I6-3, false);
		}

		// Token: 0x0400017C RID: 380
		public static List<ModWatcher.Watcher> _ItemWrapper = new List<ModWatcher.Watcher>();

		// Token: 0x0400017D RID: 381
		private static bool m_MapperWrapper = false;

		// Token: 0x0400017E RID: 382
		public static bool factoryWrapper = false;

		// Token: 0x0200006D RID: 109
		public class Watcher
		{
			// Token: 0x06000330 RID: 816 RVA: 0x0001C6F8 File Offset: 0x0001A8F8
			public Watcher(ModLoader.LoaderTask<Process, int> Loader, ModMinecraft.McVersion Version, string WindowTitle)
			{
				ModWatcher.Watcher._Closure$__5-0 CS$<>8__locals1 = new ModWatcher.Watcher._Closure$__5-0(CS$<>8__locals1);
				CS$<>8__locals1.$VB$Local_Loader = Loader;
				CS$<>8__locals1.$VB$Local_WindowTitle = WindowTitle;
				base..ctor();
				CS$<>8__locals1.$VB$Me = this;
				this.m_RegState = "";
				this._ItemState = ModWatcher.Watcher.MinecraftState.Loading;
				this._MapperState = new List<string>(1000);
				this._FactoryState = RuntimeHelpers.GetObjectValue(new object());
				this._ProcessState = new Queue<string>();
				this.valState = 0;
				this.utilsState = false;
				this.orderState = false;
				this.composerState = CS$<>8__locals1.$VB$Local_Loader;
				this._ObjectState = Version;
				this.m_RegState = CS$<>8__locals1.$VB$Local_WindowTitle;
				this._InvocationState = CS$<>8__locals1.$VB$Local_Loader.Input.Id;
				this.WatcherLog("开始 Minecraft 日志监控");
				if (Operators.CompareString(this.m_RegState, "", true) != 0)
				{
					this.WatcherLog("要求窗口标题：" + CS$<>8__locals1.$VB$Local_WindowTitle);
				}
				List<ModWatcher.Watcher> list = new List<ModWatcher.Watcher>();
				try
				{
					foreach (ModWatcher.Watcher watcher in ModWatcher._ItemWrapper)
					{
						if (watcher.State != ModWatcher.Watcher.MinecraftState.Crashed && watcher.State != ModWatcher.Watcher.MinecraftState.Ended)
						{
							list.Add(watcher);
						}
					}
				}
				finally
				{
					List<ModWatcher.Watcher>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				list.Add(this);
				ModWatcher._ItemWrapper = list;
				ModWatcher.WatcherStateChanged();
				this._CreatorState = CS$<>8__locals1.$VB$Local_Loader.Input;
				this._CreatorState.BeginOutputReadLine();
				this._CreatorState.BeginErrorReadLine();
				this._CreatorState.OutputDataReceived += this.LogReceived;
				this._CreatorState.ErrorDataReceived += this.LogReceived;
				ModBase.RunInNewThread(checked(delegate
				{
					try
					{
						CS$<>8__locals1.$VB$Me.m_ThreadState = CS$<>8__locals1.$VB$Me.GetAllMinecraftWindowHandle(false).Keys.ToList<IntPtr>();
						while (CS$<>8__locals1.$VB$Me.State != ModWatcher.Watcher.MinecraftState.Ended && CS$<>8__locals1.$VB$Me.State != ModWatcher.Watcher.MinecraftState.Crashed)
						{
							if (CS$<>8__locals1.$VB$Local_Loader.State == ModBase.LoadState.Aborted)
							{
								break;
							}
							CS$<>8__locals1.$VB$Me.TimerWindow();
							CS$<>8__locals1.$VB$Me.TimerLog();
							if (CS$<>8__locals1.$VB$Me.State == ModWatcher.Watcher.MinecraftState.Loading)
							{
								CS$<>8__locals1.$VB$Me.ProgressUpdate();
							}
							int num = 1;
							do
							{
								if (CS$<>8__locals1.$VB$Me.orderState && Operators.CompareString(CS$<>8__locals1.$VB$Local_WindowTitle, "", true) != 0 && CS$<>8__locals1.$VB$Me.State == ModWatcher.Watcher.MinecraftState.Running && !CS$<>8__locals1.$VB$Me._CreatorState.HasExited)
								{
									string text = CS$<>8__locals1.$VB$Local_WindowTitle.Replace("{time}", DateTime.Now.ToShortTimeString());
									int hWnd = (int)CS$<>8__locals1.$VB$Me._PolicyState;
									string text2 = new string(text.ToCharArray());
									ModWatcher.Watcher.SetWindowTextA(hWnd, ref text2);
								}
								Thread.Sleep(64);
								num++;
							}
							while (num <= 3);
						}
						CS$<>8__locals1.$VB$Me.WatcherLog("Minecraft 日志监控已退出");
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "Minecraft 日志监控主循环出错", ModBase.LogLevel.Feedback, "出现错误");
						CS$<>8__locals1.$VB$Me.State = ModWatcher.Watcher.MinecraftState.Ended;
					}
				}), "Minecraft Watcher PID " + Conversions.ToString(this._InvocationState), ThreadPriority.Normal);
			}

			// Token: 0x1700005C RID: 92
			// (get) Token: 0x06000331 RID: 817 RVA: 0x00003BEE File Offset: 0x00001DEE
			// (set) Token: 0x06000332 RID: 818 RVA: 0x00003BF6 File Offset: 0x00001DF6
			public ModWatcher.Watcher.MinecraftState State
			{
				get
				{
					return this._ItemState;
				}
				set
				{
					if (this._ItemState != value)
					{
						this._ItemState = value;
						ModWatcher.WatcherStateChanged();
					}
				}
			}

			// Token: 0x06000333 RID: 819 RVA: 0x0001C8D0 File Offset: 0x0001AAD0
			private void LogReceived(object sender, DataReceivedEventArgs e)
			{
				object factoryState = this._FactoryState;
				ObjectFlowControl.CheckForSyncLockOnValueType(factoryState);
				lock (factoryState)
				{
					this._MapperState.Add(e.Data);
				}
			}

			// Token: 0x06000334 RID: 820 RVA: 0x0001C924 File Offset: 0x0001AB24
			private void TimerLog()
			{
				try
				{
					List<string> list = new List<string>();
					object factoryState = this._FactoryState;
					ObjectFlowControl.CheckForSyncLockOnValueType(factoryState);
					lock (factoryState)
					{
						if (this._MapperState.Count == 0)
						{
							return;
						}
						list = this._MapperState;
						this._MapperState = new List<string>(1000);
					}
					try
					{
						foreach (string text in list)
						{
							this.GameLog(text);
						}
					}
					finally
					{
						List<string>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
					if (this._CreatorState.HasExited)
					{
						this.WatcherLog("Minecraft 已退出，返回值：" + Conversions.ToString(this._CreatorState.ExitCode));
						if (this.State == ModWatcher.Watcher.MinecraftState.Loading)
						{
							this.WatcherLog("Minecraft 尚未加载完成，可能已崩溃");
							this.Crashed();
						}
						else if (this._CreatorState.ExitCode != 0 && this.State == ModWatcher.Watcher.MinecraftState.Running && this._ObjectState.m_MappingProccesor.Year >= 2012)
						{
							this.WatcherLog("Minecraft 返回值异常，可能已崩溃");
							this.Crashed();
						}
						else
						{
							this.State = ModWatcher.Watcher.MinecraftState.Ended;
						}
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "输出 Minecraft 日志失败", ModBase.LogLevel.Feedback, "出现错误");
				}
			}

			// Token: 0x06000335 RID: 821 RVA: 0x0001CAB8 File Offset: 0x0001ACB8
			private void GameLog(string Text)
			{
				if (Text != null)
				{
					Text = Text.Replace("\r\n", "\r").Replace("\n", "\r").Replace("\r", "\r\n");
					this._ProcessState.Enqueue(Text);
					if (this._ProcessState.Count >= 201)
					{
						this._ProcessState.Dequeue();
					}
					if (this.valState < 1)
					{
						this.WatcherLog("日志 1/5：已出现日志输出");
						this.valState = 1;
					}
					if (this.valState < 2 && Text.Contains("Setting user:"))
					{
						this.WatcherLog("日志 2/5：游戏用户已设置");
						this.valState = 2;
					}
					else if (this.valState < 3 && Text.ToLower().Contains("lwjgl version"))
					{
						this.WatcherLog("日志 3/5：LWJGL 版本已确认");
						this.valState = 3;
					}
					else if (this.valState < 4 && (Text.Contains("OpenAL initialized") || Text.Contains("Starting up SoundSystem")))
					{
						this.WatcherLog("日志 4/5：OpenAL 已加载");
						this.valState = 4;
					}
					else if (this.valState < 5 && ((Text.Contains("Created") && Text.Contains("textures") && Text.Contains("-atlas")) || Text.Contains("Found animation info")))
					{
						this.WatcherLog("日志 5/5：材质已加载");
						this.valState = 5;
					}
					if (!Text.Contains("[CHAT]"))
					{
						if (Text.Contains("Someone is closing me!"))
						{
							this.WatcherLog("识别为关闭的 Log：" + Text);
							this.State = ModWatcher.Watcher.MinecraftState.Ended;
							return;
						}
						if (Text.Contains("Game crashed! Crash report saved to:") || Text.Contains("This crash report has been saved to:"))
						{
							this.WatcherLog("识别为崩溃的 Log：" + Text);
							this.Crashed();
							return;
						}
						if (Text.Contains("Could not save crash report to"))
						{
							this.WatcherLog("识别为崩溃的 Log：" + Text);
							this.Crashed();
							return;
						}
						if (Text.Contains("/ERROR]: Unable to launch") || Text.Contains("An exception was thrown, the game will display an error screen and halt."))
						{
							this.WatcherLog("识别为崩溃的 Log：" + Text);
							this.Crashed();
						}
					}
				}
			}

			// Token: 0x06000336 RID: 822 RVA: 0x00003C0D File Offset: 0x00001E0D
			private void WatcherLog(string Text)
			{
				ModLaunch.McLaunchLog("[" + Conversions.ToString(this._InvocationState) + "] " + Text);
			}

			// Token: 0x06000337 RID: 823 RVA: 0x0001CCE8 File Offset: 0x0001AEE8
			private void ProgressUpdate()
			{
				double progress;
				if (!this.utilsState)
				{
					if (this.valState != 5)
					{
						progress = (double)Math.Min(this.valState, 3) / 3.0 * 0.9;
						goto IL_54;
					}
				}
				progress = 0.95;
				this.WatcherLog("Minecraft 加载已完成");
				this.State = ModWatcher.Watcher.MinecraftState.Running;
				IL_54:
				this.composerState.Progress = progress;
			}

			// Token: 0x06000338 RID: 824 RVA: 0x0001CD58 File Offset: 0x0001AF58
			private void TimerWindow()
			{
				try
				{
					if (!this._CreatorState.HasExited)
					{
						if (!this.orderState)
						{
							Dictionary<IntPtr, bool> allMinecraftWindowHandle = this.GetAllMinecraftWindowHandle(true);
							try
							{
								foreach (IntPtr key in this.m_ThreadState)
								{
									if (allMinecraftWindowHandle.ContainsKey(key))
									{
										allMinecraftWindowHandle.Remove(key);
									}
								}
							}
							finally
							{
								List<IntPtr>.Enumerator enumerator;
								((IDisposable)enumerator).Dispose();
							}
							if (allMinecraftWindowHandle.Count != 0)
							{
								if (allMinecraftWindowHandle.Values.ElementAtOrDefault(0))
								{
									this._PolicyState = allMinecraftWindowHandle.Keys.ElementAtOrDefault(0);
									this.WatcherLog("Minecraft 窗口已加载：" + Conversions.ToString(this._PolicyState.ToInt64()));
									this.orderState = true;
									Thread.Sleep(3000);
									if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LaunchArgumentWindowType", null), 4, true))
									{
										ModWatcher.Watcher.ShowWindow(this._PolicyState, 3U);
									}
								}
								else if (!this.utilsState)
								{
									this.WatcherLog("FML 窗口已加载：" + Conversions.ToString(allMinecraftWindowHandle.Keys.ElementAtOrDefault(0).ToInt64()));
								}
								this.utilsState = true;
							}
						}
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "检查 Minecraft 窗口失败", ModBase.LogLevel.Feedback, "出现错误");
				}
			}

			// Token: 0x06000339 RID: 825 RVA: 0x00003C2F File Offset: 0x00001E2F
			private Dictionary<IntPtr, bool> GetAllMinecraftWindowHandle(bool CanUseFml)
			{
				Dictionary<IntPtr, bool> AllList = new Dictionary<IntPtr, bool>();
				ModWatcher.Watcher.EnumWindows(delegate(IntPtr hwnd, int lParam)
				{
					StringBuilder stringBuilder = new StringBuilder(512);
					ModWatcher.Watcher.GetClassNameA((int)hwnd, stringBuilder, stringBuilder.Capacity);
					string left = stringBuilder.ToString();
					if (Operators.CompareString(left, "GLFW30", true) == 0 || Operators.CompareString(left, "LWJGL", true) == 0 || Operators.CompareString(left, "SunAwtFrame", true) == 0)
					{
						stringBuilder = new StringBuilder(512);
						ModWatcher.Watcher.GetWindowTextA((int)hwnd, stringBuilder, stringBuilder.Capacity);
						string text = stringBuilder.ToString();
						if (CanUseFml && text.StartsWith("FML"))
						{
							AllList.Add(hwnd, false);
							return;
						}
						if (!text.StartsWith("GLFW") && Operators.CompareString(text, "PopupMessageWindow", true) != 0)
						{
							AllList.Add(hwnd, true);
						}
					}
				}, 0);
				return AllList;
			}

			// Token: 0x0600033A RID: 826
			[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
			private static extern bool EnumWindows(ModWatcher.Watcher.EnumWindowsSub hWnd, int lParam);

			// Token: 0x0600033B RID: 827
			[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
			private static extern int GetClassNameA(int hWnd, StringBuilder str, int maxCount);

			// Token: 0x0600033C RID: 828
			[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
			private static extern int GetWindowTextA(int hWnd, StringBuilder str, int maxCount);

			// Token: 0x0600033D RID: 829
			[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
			private static extern bool SetWindowTextA(int hWnd, [MarshalAs(UnmanagedType.VBByRefStr)] ref string str);

			// Token: 0x0600033E RID: 830
			[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
			private static extern bool ShowWindow(IntPtr hWnd, uint cmdWindow);

			// Token: 0x0600033F RID: 831 RVA: 0x0001CEE4 File Offset: 0x0001B0E4
			private void Crashed()
			{
				if (this.State != ModWatcher.Watcher.MinecraftState.Crashed && this.State != ModWatcher.Watcher.MinecraftState.Ended)
				{
					this.State = ModWatcher.Watcher.MinecraftState.Crashed;
					this.WatcherLog("Minecraft 已崩溃，将在 2 秒后开始崩溃分析");
					ModMain.Hint("检测到 Minecraft 出现错误，错误分析已开始……", ModMain.HintType.Info, true);
					ModBase.RunInNewThread(delegate
					{
						try
						{
							Thread.Sleep(2000);
							this.WatcherLog("崩溃分析开始");
							CrashAnalyzer crashAnalyzer = new CrashAnalyzer(this._InvocationState);
							crashAnalyzer.Collect(this._ObjectState.CreateComparator(), this._ProcessState.ToList<string>());
							crashAnalyzer.Prepare();
							crashAnalyzer.Analyze(this._ObjectState);
							crashAnalyzer.Output(false, new List<string>
							{
								this._ObjectState.Path + this._ObjectState.Name + ".json",
								ModBase.Path + "PCL\\Log1.txt",
								ModBase.Path + "PCL\\LatestLaunch.bat"
							});
						}
						catch (Exception ex)
						{
							ModBase.Log(ex, "崩溃分析失败", ModBase.LogLevel.Feedback, "出现错误");
						}
					}, "Crash Analyzer", ThreadPriority.Normal);
				}
			}

			// Token: 0x06000340 RID: 832 RVA: 0x0001CF3C File Offset: 0x0001B13C
			public void Kill()
			{
				this.State = ModWatcher.Watcher.MinecraftState.Ended;
				this.WatcherLog("尝试强制结束 Minecraft 进程");
				try
				{
					if (!this._CreatorState.HasExited)
					{
						this._CreatorState.Kill();
					}
					this.WatcherLog("已强制结束 Minecraft 进程");
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "强制结束 Minecraft 进程失败", ModBase.LogLevel.Hint, "出现错误");
				}
			}

			// Token: 0x0400017F RID: 383
			public Process _CreatorState;

			// Token: 0x04000180 RID: 384
			public ModMinecraft.McVersion _ObjectState;

			// Token: 0x04000181 RID: 385
			private string m_RegState;

			// Token: 0x04000182 RID: 386
			private int _InvocationState;

			// Token: 0x04000183 RID: 387
			public ModLoader.LoaderTask<Process, int> composerState;

			// Token: 0x04000184 RID: 388
			private ModWatcher.Watcher.MinecraftState _ItemState;

			// Token: 0x04000185 RID: 389
			public List<string> _MapperState;

			// Token: 0x04000186 RID: 390
			private readonly object _FactoryState;

			// Token: 0x04000187 RID: 391
			public Queue<string> _ProcessState;

			// Token: 0x04000188 RID: 392
			private int valState;

			// Token: 0x04000189 RID: 393
			private bool utilsState;

			// Token: 0x0400018A RID: 394
			private bool orderState;

			// Token: 0x0400018B RID: 395
			private IntPtr _PolicyState;

			// Token: 0x0400018C RID: 396
			private List<IntPtr> m_ThreadState;

			// Token: 0x0200006E RID: 110
			public enum MinecraftState
			{
				// Token: 0x0400018E RID: 398
				Loading,
				// Token: 0x0400018F RID: 399
				Running,
				// Token: 0x04000190 RID: 400
				Crashed,
				// Token: 0x04000191 RID: 401
				Ended
			}

			// Token: 0x0200006F RID: 111
			// (Invoke) Token: 0x06000346 RID: 838
			private delegate void EnumWindowsSub(IntPtr hwnd, int lParam);
		}
	}
}
