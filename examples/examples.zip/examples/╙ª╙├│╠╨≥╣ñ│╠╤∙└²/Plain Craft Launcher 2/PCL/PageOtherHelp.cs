﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000149 RID: 329
	[DesignerGenerated]
	public class PageOtherHelp : MyPageRight, IComponentConnector
	{
		// Token: 0x06000D33 RID: 3379 RVA: 0x000088F3 File Offset: 0x00006AF3
		public PageOtherHelp()
		{
			base.Loaded += this.PageOther_Loaded;
			base.Initialized += this.PageOther_Inited;
			this.InitializeComponent();
		}

		// Token: 0x06000D34 RID: 3380 RVA: 0x00008926 File Offset: 0x00006B26
		private void PageOther_Loaded(object sender, RoutedEventArgs e)
		{
			this.PanBack.ScrollToHome();
		}

		// Token: 0x06000D35 RID: 3381 RVA: 0x000638B8 File Offset: 0x00061AB8
		private void PageOther_Inited(object sender, EventArgs e)
		{
			base.PageLoaderInit(this.Load, this.PanLoad, this.PanBack, null, ModMain.m_RepositoryState, delegate(ModLoader.LoaderBase a0)
			{
				this.HelpListLoad((ModLoader.LoaderTask<int, List<ModMain.HelpEntry>>)a0);
			}, null, true);
		}

		// Token: 0x06000D36 RID: 3382 RVA: 0x000638F4 File Offset: 0x00061AF4
		private void HelpListLoad(ModLoader.LoaderTask<int, List<ModMain.HelpEntry>> Loader)
		{
			try
			{
				this.PanList.Children.Clear();
				this.PanBack.ScrollToHome();
				List<ModMain.HelpEntry> output = Loader.Output;
				List<string> list = new List<string>();
				try
				{
					foreach (ModMain.HelpEntry helpEntry in output)
					{
						if ((ModBase.Val("50") != 50.0 || helpEntry._InterpreterParameter) && (ModBase.Val("50") == 50.0 || helpEntry.m_ParserParameter))
						{
							try
							{
								foreach (string item in helpEntry.m_PageParameter)
								{
									if (!list.Contains(item))
									{
										list.Add(item);
									}
								}
							}
							finally
							{
								List<string>.Enumerator enumerator2;
								((IDisposable)enumerator2).Dispose();
							}
						}
					}
				}
				finally
				{
					List<ModMain.HelpEntry>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				if (list.Contains("指南"))
				{
					list.Remove("指南");
					list.Insert(0, "指南");
				}
				try
				{
					foreach (string text in list)
					{
						List<ModMain.HelpEntry> list2 = new List<ModMain.HelpEntry>();
						try
						{
							foreach (ModMain.HelpEntry helpEntry2 in output)
							{
								if ((ModBase.Val("50") != 50.0 || helpEntry2._InterpreterParameter) && (ModBase.Val("50") == 50.0 || helpEntry2.m_ParserParameter) && helpEntry2.m_PageParameter.Contains(text))
								{
									list2.Add(helpEntry2);
								}
							}
						}
						finally
						{
							List<ModMain.HelpEntry>.Enumerator enumerator4;
							((IDisposable)enumerator4).Dispose();
						}
						MyCard myCard = new MyCard();
						myCard.Title = text;
						myCard.Margin = new Thickness(0.0, 0.0, 0.0, 15.0);
						myCard.CustomizeModel(11);
						MyCard myCard2 = myCard;
						StackPanel stackPanel = new StackPanel
						{
							Margin = new Thickness(20.0, 40.0, 18.0, 0.0),
							VerticalAlignment = VerticalAlignment.Top,
							RenderTransform = new TranslateTransform(0.0, 0.0),
							Tag = list2
						};
						myCard2.Children.Add(stackPanel);
						myCard2.m_Decorator = stackPanel;
						if (Operators.CompareString(text, "指南", true) == 0)
						{
							MyCard.StackInstall(ref stackPanel, 11, "指南");
						}
						else
						{
							myCard2.IsSwaped = true;
						}
						this.PanList.Children.Add(myCard2);
					}
				}
				finally
				{
					List<string>.Enumerator enumerator3;
					((IDisposable)enumerator3).Dispose();
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "加载帮助列表 UI 失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000D37 RID: 3383 RVA: 0x00063C50 File Offset: 0x00061E50
		public static void OnItemClick(ModMain.HelpEntry Entry)
		{
			try
			{
				if (Entry.m_StubParameter)
				{
					ModEvent.TryStartEvent(Entry._ErrorParameter, Entry._ExceptionParameter);
				}
				else
				{
					PageOtherHelp.EnterHelpPage(Entry);
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "处理帮助项目点击时发生意外错误", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000D38 RID: 3384 RVA: 0x00008933 File Offset: 0x00006B33
		public static void EnterHelpPage(string Location)
		{
			ModBase.RunInThread(delegate
			{
				if (ModMain.m_RepositoryState.State != ModBase.LoadState.Finished)
				{
					ModMain.m_RepositoryState.WaitForExit(ModBase.GetUuid(), null, false);
				}
				ModMain.HelpEntry Entry = new ModMain.HelpEntry(Location);
				ModBase.RunInUi(delegate()
				{
					PageOtherHelpDetail pageOtherHelpDetail = new PageOtherHelpDetail();
					if (pageOtherHelpDetail.Init(Entry))
					{
						ModMain.m_CollectionAccount.PageChange(new FormMain.PageStackData
						{
							m_CreatorParameter = FormMain.PageType.HelpDetail,
							m_ObjectParameter = new object[]
							{
								Entry,
								pageOtherHelpDetail
							}
						}, FormMain.PageSubType.Default);
						return;
					}
					ModBase.Log("[Help] 已取消进入帮助项目，这一般是由于 xaml 初始化失败，且用户在弹窗中手动放弃", ModBase.LogLevel.Debug, "出现错误");
				}, false);
			});
		}

		// Token: 0x06000D39 RID: 3385 RVA: 0x00008951 File Offset: 0x00006B51
		public static void EnterHelpPage(ModMain.HelpEntry Entry)
		{
			Action $I1;
			ModBase.RunInThread(delegate
			{
				if (ModMain.m_RepositoryState.State != ModBase.LoadState.Finished)
				{
					ModMain.m_RepositoryState.WaitForExit(ModBase.GetUuid(), null, false);
				}
				ModBase.RunInUi(($I1 == null) ? ($I1 = delegate()
				{
					PageOtherHelpDetail pageOtherHelpDetail = new PageOtherHelpDetail();
					if (pageOtherHelpDetail.Init(Entry))
					{
						ModMain.m_CollectionAccount.PageChange(new FormMain.PageStackData
						{
							m_CreatorParameter = FormMain.PageType.HelpDetail,
							m_ObjectParameter = new object[]
							{
								Entry,
								pageOtherHelpDetail
							}
						}, FormMain.PageSubType.Default);
						return;
					}
					ModBase.Log("[Help] 已取消进入帮助项目，这一般是由于 xaml 初始化失败，且用户在弹窗中手动放弃", ModBase.LogLevel.Debug, "出现错误");
				}) : $I1, false);
			});
		}

		// Token: 0x06000D3A RID: 3386 RVA: 0x00063CB0 File Offset: 0x00061EB0
		public static PageOtherHelpDetail GetHelpPage(string Location)
		{
			if (ModMain.m_RepositoryState.State != ModBase.LoadState.Finished)
			{
				ModMain.m_RepositoryState.WaitForExit(ModBase.GetUuid(), null, false);
			}
			PageOtherHelpDetail pageOtherHelpDetail = new PageOtherHelpDetail();
			if (!pageOtherHelpDetail.Init(new ModMain.HelpEntry(Location)))
			{
				throw new Exception("已取消进入帮助项目，这一般是由于 xaml 初始化失败，且用户在弹窗中手动放弃");
			}
			return pageOtherHelpDetail;
		}

		// Token: 0x06000D3B RID: 3387 RVA: 0x00063D04 File Offset: 0x00061F04
		public void SearchRun()
		{
			if (string.IsNullOrWhiteSpace(this.SearchBox.Text))
			{
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaOpacity(this.PanSearch, -this.PanSearch.Opacity, 100, 0, null, false),
					ModAnimation.AaCode(delegate
					{
						this.PanSearch.Height = 0.0;
						this.PanSearch.Visibility = Visibility.Collapsed;
						this.PanList.Visibility = Visibility.Visible;
					}, 0, true),
					ModAnimation.AaOpacity(this.PanList, 1.0 - this.PanList.Opacity, 150, 30, null, false)
				}, "FrmOtherHelp Search Switch", false);
				return;
			}
			List<ModBase.SearchEntry<ModMain.HelpEntry>> list = new List<ModBase.SearchEntry<ModMain.HelpEntry>>();
			try
			{
				foreach (ModMain.HelpEntry helpEntry in ModMain.m_RepositoryState.Output)
				{
					if (helpEntry.tokenParameter && (ModBase.Val("50") != 50.0 || helpEntry._InterpreterParameter) && helpEntry.tokenParameter && (ModBase.Val("50") == 50.0 || helpEntry.m_ParserParameter))
					{
						list.Add(new ModBase.SearchEntry<ModMain.HelpEntry>
						{
							interceptorParameter = helpEntry,
							m_RefParameter = new List<KeyValuePair<string, double>>
							{
								new KeyValuePair<string, double>(helpEntry.Title, 1.0),
								new KeyValuePair<string, double>(helpEntry.m_ReaderParameter, 0.5),
								new KeyValuePair<string, double>(helpEntry._FieldParameter, 1.5)
							}
						});
					}
				}
			}
			finally
			{
				List<ModMain.HelpEntry>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			List<ModBase.SearchEntry<ModMain.HelpEntry>> list2 = ModBase.Search<ModMain.HelpEntry>(list, this.SearchBox.Text, 5, 0.08);
			this.PanSearchList.Children.Clear();
			if (list2.Count == 0)
			{
				this.PanSearch.Title = "无搜索结果";
				this.PanSearchList.Visibility = Visibility.Collapsed;
			}
			else
			{
				this.PanSearch.Title = "搜索结果";
				try
				{
					foreach (ModBase.SearchEntry<ModMain.HelpEntry> searchEntry in list2)
					{
						MyListItem myListItem = searchEntry.interceptorParameter.ToListItem();
						if (ModBase._EventState)
						{
							myListItem.Info = string.Concat(new string[]
							{
								searchEntry.serviceParameter ? "完全匹配，" : "",
								"相似度：",
								Conversions.ToString(Math.Round(searchEntry.serverParameter, 3)),
								"，",
								myListItem.Info
							});
						}
						this.PanSearchList.Children.Add(myListItem);
					}
				}
				finally
				{
					List<ModBase.SearchEntry<ModMain.HelpEntry>>.Enumerator enumerator2;
					((IDisposable)enumerator2).Dispose();
				}
				this.PanSearchList.Visibility = Visibility.Visible;
			}
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaOpacity(this.PanList, -this.PanList.Opacity, 100, 0, null, false),
				ModAnimation.AaCode(delegate
				{
					this.PanList.Visibility = Visibility.Collapsed;
					this.PanSearch.Visibility = Visibility.Visible;
					this.PanSearch.TriggerForceResize();
				}, 0, true),
				ModAnimation.AaOpacity(this.PanSearch, 1.0 - this.PanSearch.Opacity, 150, 30, null, false)
			}, "FrmOtherHelp Search Switch", false);
		}

		// Token: 0x17000205 RID: 517
		// (get) Token: 0x06000D3C RID: 3388 RVA: 0x0000896F File Offset: 0x00006B6F
		// (set) Token: 0x06000D3D RID: 3389 RVA: 0x00008977 File Offset: 0x00006B77
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x17000206 RID: 518
		// (get) Token: 0x06000D3E RID: 3390 RVA: 0x00008980 File Offset: 0x00006B80
		// (set) Token: 0x06000D3F RID: 3391 RVA: 0x00008988 File Offset: 0x00006B88
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x17000207 RID: 519
		// (get) Token: 0x06000D40 RID: 3392 RVA: 0x00008991 File Offset: 0x00006B91
		// (set) Token: 0x06000D41 RID: 3393 RVA: 0x00064060 File Offset: 0x00062260
		internal virtual MySearchBox SearchBox
		{
			[CompilerGenerated]
			get
			{
				return this.m_ParameterPrototype;
			}
			[CompilerGenerated]
			set
			{
				MySearchBox.TextChangedEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.SearchRun();
				};
				MySearchBox parameterPrototype = this.m_ParameterPrototype;
				if (parameterPrototype != null)
				{
					parameterPrototype.PushWrapper(obj);
				}
				this.m_ParameterPrototype = value;
				parameterPrototype = this.m_ParameterPrototype;
				if (parameterPrototype != null)
				{
					parameterPrototype.RunWrapper(obj);
				}
			}
		}

		// Token: 0x17000208 RID: 520
		// (get) Token: 0x06000D42 RID: 3394 RVA: 0x00008999 File Offset: 0x00006B99
		// (set) Token: 0x06000D43 RID: 3395 RVA: 0x000089A1 File Offset: 0x00006BA1
		internal virtual MyCard PanSearch { get; set; }

		// Token: 0x17000209 RID: 521
		// (get) Token: 0x06000D44 RID: 3396 RVA: 0x000089AA File Offset: 0x00006BAA
		// (set) Token: 0x06000D45 RID: 3397 RVA: 0x000089B2 File Offset: 0x00006BB2
		internal virtual StackPanel PanSearchList { get; set; }

		// Token: 0x1700020A RID: 522
		// (get) Token: 0x06000D46 RID: 3398 RVA: 0x000089BB File Offset: 0x00006BBB
		// (set) Token: 0x06000D47 RID: 3399 RVA: 0x000089C3 File Offset: 0x00006BC3
		internal virtual StackPanel PanList { get; set; }

		// Token: 0x1700020B RID: 523
		// (get) Token: 0x06000D48 RID: 3400 RVA: 0x000089CC File Offset: 0x00006BCC
		// (set) Token: 0x06000D49 RID: 3401 RVA: 0x000089D4 File Offset: 0x00006BD4
		internal virtual MyCard PanLoad { get; set; }

		// Token: 0x1700020C RID: 524
		// (get) Token: 0x06000D4A RID: 3402 RVA: 0x000089DD File Offset: 0x00006BDD
		// (set) Token: 0x06000D4B RID: 3403 RVA: 0x000089E5 File Offset: 0x00006BE5
		internal virtual MyLoading Load { get; set; }

		// Token: 0x06000D4C RID: 3404 RVA: 0x000640A4 File Offset: 0x000622A4
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this._DefinitionPrototype)
			{
				this._DefinitionPrototype = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pageother/pageotherhelp.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000D4D RID: 3405 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000D4E RID: 3406 RVA: 0x000640D4 File Offset: 0x000622D4
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			if (connectionId == 3)
			{
				this.SearchBox = (MySearchBox)target;
				return;
			}
			if (connectionId == 4)
			{
				this.PanSearch = (MyCard)target;
				return;
			}
			if (connectionId == 5)
			{
				this.PanSearchList = (StackPanel)target;
				return;
			}
			if (connectionId == 6)
			{
				this.PanList = (StackPanel)target;
				return;
			}
			if (connectionId == 7)
			{
				this.PanLoad = (MyCard)target;
				return;
			}
			if (connectionId == 8)
			{
				this.Load = (MyLoading)target;
				return;
			}
			this._DefinitionPrototype = true;
		}

		// Token: 0x040006AD RID: 1709
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyScrollViewer statePrototype;

		// Token: 0x040006AE RID: 1710
		[AccessedThroughProperty("PanMain")]
		[CompilerGenerated]
		private StackPanel m_ProccesorPrototype;

		// Token: 0x040006AF RID: 1711
		[AccessedThroughProperty("SearchBox")]
		[CompilerGenerated]
		private MySearchBox m_ParameterPrototype;

		// Token: 0x040006B0 RID: 1712
		[AccessedThroughProperty("PanSearch")]
		[CompilerGenerated]
		private MyCard authenticationPrototype;

		// Token: 0x040006B1 RID: 1713
		[AccessedThroughProperty("PanSearchList")]
		[CompilerGenerated]
		private StackPanel m_ReponsePrototype;

		// Token: 0x040006B2 RID: 1714
		[CompilerGenerated]
		[AccessedThroughProperty("PanList")]
		private StackPanel _ContainerPrototype;

		// Token: 0x040006B3 RID: 1715
		[AccessedThroughProperty("PanLoad")]
		[CompilerGenerated]
		private MyCard m_CodePrototype;

		// Token: 0x040006B4 RID: 1716
		[CompilerGenerated]
		[AccessedThroughProperty("Load")]
		private MyLoading tokenizerPrototype;

		// Token: 0x040006B5 RID: 1717
		private bool _DefinitionPrototype;
	}
}
