﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000172 RID: 370
	[DesignerGenerated]
	public class MyCheckBox : Grid, IComponentConnector
	{
		// Token: 0x06001116 RID: 4374 RVA: 0x00074A18 File Offset: 0x00072C18
		public MyCheckBox()
		{
			base.MouseLeftButtonUp += delegate(object sender, MouseButtonEventArgs e)
			{
				this.Checkbox_MouseUp();
			};
			base.MouseLeftButtonDown += delegate(object sender, MouseButtonEventArgs e)
			{
				this.Checkbox_MouseDown();
			};
			base.MouseLeave += delegate(object sender, MouseEventArgs e)
			{
				this.Checkbox_MouseLeave();
			};
			base.IsEnabledChanged += delegate(object sender, DependencyPropertyChangedEventArgs e)
			{
				this.Checkbox_IsEnabledChanged();
			};
			base.MouseEnter += delegate(object sender, MouseEventArgs e)
			{
				this.Checkbox_MouseEnterAnimation();
			};
			base.MouseLeave += delegate(object sender, MouseEventArgs e)
			{
				this.Checkbox_MouseLeaveAnimation();
			};
			this._WatcherRequest = ModBase.GetUuid();
			this._IteratorRequest = false;
			this.roleRequest = false;
			this.valueRequest = true;
			this.InitializeComponent();
		}

		// Token: 0x06001117 RID: 4375 RVA: 0x00074AC0 File Offset: 0x00072CC0
		[CompilerGenerated]
		public void CloneTag(MyCheckBox.ChangeEventHandler obj)
		{
			MyCheckBox.ChangeEventHandler changeEventHandler = this.m_TestRequest;
			MyCheckBox.ChangeEventHandler changeEventHandler2;
			do
			{
				changeEventHandler2 = changeEventHandler;
				MyCheckBox.ChangeEventHandler value = (MyCheckBox.ChangeEventHandler)Delegate.Combine(changeEventHandler2, obj);
				changeEventHandler = Interlocked.CompareExchange<MyCheckBox.ChangeEventHandler>(ref this.m_TestRequest, value, changeEventHandler2);
			}
			while (changeEventHandler != changeEventHandler2);
		}

		// Token: 0x06001118 RID: 4376 RVA: 0x00074AF8 File Offset: 0x00072CF8
		[CompilerGenerated]
		public void StopTag(MyCheckBox.ChangeEventHandler obj)
		{
			MyCheckBox.ChangeEventHandler changeEventHandler = this.m_TestRequest;
			MyCheckBox.ChangeEventHandler changeEventHandler2;
			do
			{
				changeEventHandler2 = changeEventHandler;
				MyCheckBox.ChangeEventHandler value = (MyCheckBox.ChangeEventHandler)Delegate.Remove(changeEventHandler2, obj);
				changeEventHandler = Interlocked.CompareExchange<MyCheckBox.ChangeEventHandler>(ref this.m_TestRequest, value, changeEventHandler2);
			}
			while (changeEventHandler != changeEventHandler2);
		}

		// Token: 0x06001119 RID: 4377 RVA: 0x00074B30 File Offset: 0x00072D30
		[CompilerGenerated]
		public void DisableTag(MyCheckBox.PreviewChangeEventHandler obj)
		{
			MyCheckBox.PreviewChangeEventHandler previewChangeEventHandler = this.taskRequest;
			MyCheckBox.PreviewChangeEventHandler previewChangeEventHandler2;
			do
			{
				previewChangeEventHandler2 = previewChangeEventHandler;
				MyCheckBox.PreviewChangeEventHandler value = (MyCheckBox.PreviewChangeEventHandler)Delegate.Combine(previewChangeEventHandler2, obj);
				previewChangeEventHandler = Interlocked.CompareExchange<MyCheckBox.PreviewChangeEventHandler>(ref this.taskRequest, value, previewChangeEventHandler2);
			}
			while (previewChangeEventHandler != previewChangeEventHandler2);
		}

		// Token: 0x0600111A RID: 4378 RVA: 0x00074B68 File Offset: 0x00072D68
		[CompilerGenerated]
		public void VerifyTag(MyCheckBox.PreviewChangeEventHandler obj)
		{
			MyCheckBox.PreviewChangeEventHandler previewChangeEventHandler = this.taskRequest;
			MyCheckBox.PreviewChangeEventHandler previewChangeEventHandler2;
			do
			{
				previewChangeEventHandler2 = previewChangeEventHandler;
				MyCheckBox.PreviewChangeEventHandler value = (MyCheckBox.PreviewChangeEventHandler)Delegate.Remove(previewChangeEventHandler2, obj);
				previewChangeEventHandler = Interlocked.CompareExchange<MyCheckBox.PreviewChangeEventHandler>(ref this.taskRequest, value, previewChangeEventHandler2);
			}
			while (previewChangeEventHandler != previewChangeEventHandler2);
		}

		// Token: 0x0600111B RID: 4379 RVA: 0x00074BA0 File Offset: 0x00072DA0
		public void RaiseChange()
		{
			MyCheckBox.ChangeEventHandler testRequest = this.m_TestRequest;
			if (testRequest != null)
			{
				testRequest(this, false);
			}
		}

		// Token: 0x170002F3 RID: 755
		// (get) Token: 0x0600111C RID: 4380 RVA: 0x0000A21E File Offset: 0x0000841E
		// (set) Token: 0x0600111D RID: 4381 RVA: 0x0000A226 File Offset: 0x00008426
		public bool Checked
		{
			get
			{
				return this._IteratorRequest;
			}
			set
			{
				this.SetChecked(value, false, true);
			}
		}

		// Token: 0x0600111E RID: 4382 RVA: 0x00074BC0 File Offset: 0x00072DC0
		public void SetChecked(bool value, bool user, bool anime)
		{
			try
			{
				if (value != this._IteratorRequest)
				{
					if (value && user)
					{
						ModBase.RouteEventArgs routeEventArgs = new ModBase.RouteEventArgs(user);
						MyCheckBox.PreviewChangeEventHandler previewChangeEventHandler = this.taskRequest;
						if (previewChangeEventHandler != null)
						{
							previewChangeEventHandler(this, routeEventArgs);
						}
						if (routeEventArgs.proxyParameter)
						{
							this.roleRequest = true;
							this.Checkbox_MouseLeave();
							this.roleRequest = false;
							return;
						}
					}
					this._IteratorRequest = value;
					if (base.IsLoaded)
					{
						MyCheckBox.ChangeEventHandler testRequest = this.m_TestRequest;
						if (testRequest != null)
						{
							testRequest(this, user);
						}
					}
					if (base.IsLoaded && ModAnimation.DefineModel() == 0 && anime)
					{
						this.valueRequest = false;
						if (this.Checked)
						{
							ModAnimation.AniStart(new ModAnimation.AniData[]
							{
								ModAnimation.AaScale(this.ShapeBorder, 12.0 - this.ShapeBorder.Width, 150, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false, true),
								ModAnimation.AaScaleTransform(this.ShapeCheck, 1.0 - ((ScaleTransform)this.ShapeCheck.RenderTransform).ScaleX, 300, 105, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Weak), false),
								ModAnimation.AaScale(this.ShapeBorder, 6.0, 300, 105, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Middle), false, true)
							}, "MyCheckBox Scale " + Conversions.ToString(this._WatcherRequest), false);
							ModAnimation.AniStart(new ModAnimation.AniData[]
							{
								ModAnimation.AaColor(this.ShapeBorder, Border.BorderBrushProperty, base.IsEnabled ? (base.IsMouseOver ? "ColorBrush3" : "ColorBrush2") : "ColorBrushGray4", 150, 0, null, false)
							}, "MyCheckBox BorderColor " + Conversions.ToString(this._WatcherRequest), false);
							ModAnimation.AniStart(new ModAnimation.AniData[]
							{
								ModAnimation.AaCode(delegate
								{
									this.valueRequest = true;
								}, 300, false)
							}, "MyCheckBox AllowMouseDown " + Conversions.ToString(this._WatcherRequest), false);
						}
						else
						{
							ModAnimation.AniStart(new ModAnimation.AniData[]
							{
								ModAnimation.AaScale(this.ShapeBorder, 12.0 - this.ShapeBorder.Width, 150, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false, true),
								ModAnimation.AaScaleTransform(this.ShapeCheck, -((ScaleTransform)this.ShapeCheck.RenderTransform).ScaleX, 135, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Weak), false),
								ModAnimation.AaScale(this.ShapeBorder, 6.0, 300, 105, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Middle), false, true)
							}, "MyCheckBox Scale " + Conversions.ToString(this._WatcherRequest), false);
							ModAnimation.AniStart(new ModAnimation.AniData[]
							{
								ModAnimation.AaColor(this.ShapeBorder, Border.BorderBrushProperty, base.IsEnabled ? (base.IsMouseOver ? "ColorBrush3" : "ColorBrush1") : "ColorBrushGray4", 150, 0, null, false)
							}, "MyCheckBox BorderColor " + Conversions.ToString(this._WatcherRequest), false);
							ModAnimation.AniStart(new ModAnimation.AniData[]
							{
								ModAnimation.AaCode(delegate
								{
									this.valueRequest = true;
								}, 300, false)
							}, "MyCheckBox AllowMouseDown " + Conversions.ToString(this._WatcherRequest), false);
						}
					}
					else
					{
						ModAnimation.AniStop("MyCheckBox Scale " + Conversions.ToString(this._WatcherRequest));
						ModAnimation.AniStop("MyCheckBox BorderColor " + Conversions.ToString(this._WatcherRequest));
						ModAnimation.AniStop("MyCheckBox AllowMouseDown " + Conversions.ToString(this._WatcherRequest));
						if (this.Checked)
						{
							((ScaleTransform)this.ShapeCheck.RenderTransform).ScaleX = 1.0;
							((ScaleTransform)this.ShapeCheck.RenderTransform).ScaleY = 1.0;
							this.ShapeBorder.SetResourceReference(Border.BorderBrushProperty, base.IsEnabled ? "ColorBrush2" : "ColorBrushGray4");
						}
						else
						{
							((ScaleTransform)this.ShapeCheck.RenderTransform).ScaleX = 0.0;
							((ScaleTransform)this.ShapeCheck.RenderTransform).ScaleY = 0.0;
							this.ShapeBorder.SetResourceReference(Border.BorderBrushProperty, base.IsEnabled ? "ColorBrush1" : "ColorBrushGray4");
						}
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "设置 Checked 失败", ModBase.LogLevel.Debug, "出现错误");
			}
		}

		// Token: 0x170002F4 RID: 756
		// (get) Token: 0x0600111F RID: 4383 RVA: 0x0000A231 File Offset: 0x00008431
		// (set) Token: 0x06001120 RID: 4384 RVA: 0x0000A243 File Offset: 0x00008443
		public string Text
		{
			get
			{
				return Conversions.ToString(base.GetValue(MyCheckBox._SerializerRequest));
			}
			set
			{
				base.SetValue(MyCheckBox._SerializerRequest, value);
			}
		}

		// Token: 0x06001121 RID: 4385 RVA: 0x00075080 File Offset: 0x00073280
		private void Checkbox_MouseUp()
		{
			if (this.roleRequest)
			{
				ModBase.Log("[Control] 按下复选框（" + (!this.Checked).ToString() + "）：" + this.Text, ModBase.LogLevel.Normal, "出现错误");
				this.roleRequest = false;
				this.SetChecked(!this.Checked, true, true);
				ModAnimation.AniStart(ModAnimation.AaColor(this.ShapeBorder, Border.BackgroundProperty, "ColorBrushHalfWhite", 100, 0, null, false), "MyCheckBox Background " + Conversions.ToString(this._WatcherRequest), false);
			}
		}

		// Token: 0x06001122 RID: 4386 RVA: 0x00075114 File Offset: 0x00073314
		private void Checkbox_MouseDown()
		{
			if (this.valueRequest)
			{
				this.roleRequest = true;
				base.Focus();
				ModAnimation.AniStart(ModAnimation.AaColor(this.ShapeBorder, Border.BackgroundProperty, "ColorBrush9", 100, 0, null, false), "MyCheckBox Background " + Conversions.ToString(this._WatcherRequest), false);
				if (this.Checked)
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaScale(this.ShapeBorder, 16.5 - this.ShapeBorder.Width, 1000, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false, true),
						ModAnimation.AaScaleTransform(this.ShapeCheck, 0.9 - ((ScaleTransform)this.ShapeCheck.RenderTransform).ScaleX, 1000, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false)
					}, "MyCheckBox Scale " + Conversions.ToString(this._WatcherRequest), false);
					return;
				}
				ModAnimation.AniStart(ModAnimation.AaScale(this.ShapeBorder, 16.5 - this.ShapeBorder.Width, 1000, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false, true), "MyCheckBox Scale " + Conversions.ToString(this._WatcherRequest), false);
			}
		}

		// Token: 0x06001123 RID: 4387 RVA: 0x00075258 File Offset: 0x00073458
		private void Checkbox_MouseLeave()
		{
			if (this.roleRequest)
			{
				this.roleRequest = false;
				ModAnimation.AniStart(ModAnimation.AaColor(this.ShapeBorder, Border.BackgroundProperty, "ColorBrushHalfWhite", 100, 0, null, false), "MyCheckBox Background " + Conversions.ToString(this._WatcherRequest), false);
				if (this.Checked)
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaScale(this.ShapeBorder, 18.0 - this.ShapeBorder.Width, 400, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false, true),
						ModAnimation.AaScaleTransform(this.ShapeCheck, 1.0 - ((ScaleTransform)this.ShapeCheck.RenderTransform).ScaleX, 500, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false)
					}, "MyCheckBox Scale " + Conversions.ToString(this._WatcherRequest), false);
					return;
				}
				ModAnimation.AniStart(ModAnimation.AaScale(this.ShapeBorder, 18.0 - this.ShapeBorder.Width, 400, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false, true), "MyCheckBox Scale " + Conversions.ToString(this._WatcherRequest), false);
			}
		}

		// Token: 0x06001124 RID: 4388 RVA: 0x00075398 File Offset: 0x00073598
		private void Checkbox_IsEnabledChanged()
		{
			if (!base.IsLoaded || ModAnimation.DefineModel() != 0)
			{
				ModAnimation.AniStop("MyCheckBox TextColor " + Conversions.ToString(this._WatcherRequest));
				ModAnimation.AniStop("MyCheckBox BorderColor " + Conversions.ToString(this._WatcherRequest));
				this.LabText.SetResourceReference(TextBlock.ForegroundProperty, base.IsEnabled ? "ColorBrush1" : "ColorBrushGray4");
				this.ShapeBorder.SetResourceReference(Border.BorderBrushProperty, base.IsEnabled ? (this.Checked ? "ColorBrush2" : "ColorBrush1") : "ColorBrushGray4");
				return;
			}
			if (base.IsEnabled)
			{
				this.Checkbox_MouseLeaveAnimation();
				return;
			}
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaColor(this.ShapeBorder, Border.BorderBrushProperty, ModMain._ValAccount - this.ShapeBorder.BorderBrush, 200, 0, null, false)
			}, "MyCheckBox BorderColor " + Conversions.ToString(this._WatcherRequest), false);
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaColor(this.LabText, TextBlock.ForegroundProperty, ModMain._ValAccount - this.LabText.Foreground, 200, 0, null, false)
			}, "MyCheckBox TextColor " + Conversions.ToString(this._WatcherRequest), false);
		}

		// Token: 0x06001125 RID: 4389 RVA: 0x0007550C File Offset: 0x0007370C
		private void Checkbox_MouseEnterAnimation()
		{
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaColor(this.LabText, TextBlock.ForegroundProperty, "ColorBrush3", 100, 0, null, false)
			}, "MyCheckBox TextColor " + Conversions.ToString(this._WatcherRequest), false);
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaColor(this.ShapeBorder, Border.BorderBrushProperty, "ColorBrush3", 100, 0, null, false)
			}, "MyCheckBox BorderColor " + Conversions.ToString(this._WatcherRequest), false);
		}

		// Token: 0x06001126 RID: 4390 RVA: 0x000755A0 File Offset: 0x000737A0
		private void Checkbox_MouseLeaveAnimation()
		{
			if (base.IsEnabled)
			{
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaColor(this.LabText, TextBlock.ForegroundProperty, base.IsEnabled ? "ColorBrush1" : "ColorBrushGray4", 200, 0, null, false)
				}, "MyCheckBox TextColor " + Conversions.ToString(this._WatcherRequest), false);
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaColor(this.ShapeBorder, Border.BorderBrushProperty, base.IsEnabled ? (this.Checked ? "ColorBrush2" : "ColorBrush1") : "ColorBrushGray4", 200, 0, null, false)
				}, "MyCheckBox BorderColor " + Conversions.ToString(this._WatcherRequest), false);
			}
		}

		// Token: 0x170002F5 RID: 757
		// (get) Token: 0x06001127 RID: 4391 RVA: 0x0000A251 File Offset: 0x00008451
		// (set) Token: 0x06001128 RID: 4392 RVA: 0x0000A259 File Offset: 0x00008459
		internal virtual MyCheckBox PanBack { get; set; }

		// Token: 0x170002F6 RID: 758
		// (get) Token: 0x06001129 RID: 4393 RVA: 0x0000A262 File Offset: 0x00008462
		// (set) Token: 0x0600112A RID: 4394 RVA: 0x0000A26A File Offset: 0x0000846A
		internal virtual TextBlock LabText { get; set; }

		// Token: 0x170002F7 RID: 759
		// (get) Token: 0x0600112B RID: 4395 RVA: 0x0000A273 File Offset: 0x00008473
		// (set) Token: 0x0600112C RID: 4396 RVA: 0x0000A27B File Offset: 0x0000847B
		internal virtual Border ShapeBorder { get; set; }

		// Token: 0x170002F8 RID: 760
		// (get) Token: 0x0600112D RID: 4397 RVA: 0x0000A284 File Offset: 0x00008484
		// (set) Token: 0x0600112E RID: 4398 RVA: 0x0000A28C File Offset: 0x0000848C
		internal virtual Path ShapeCheck { get; set; }

		// Token: 0x0600112F RID: 4399 RVA: 0x00075670 File Offset: 0x00073870
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.baseRequest)
			{
				this.baseRequest = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/controls/mycheckbox.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06001130 RID: 4400 RVA: 0x000756A0 File Offset: 0x000738A0
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyCheckBox)target;
				return;
			}
			if (connectionId == 2)
			{
				this.LabText = (TextBlock)target;
				return;
			}
			if (connectionId == 3)
			{
				this.ShapeBorder = (Border)target;
				return;
			}
			if (connectionId == 4)
			{
				this.ShapeCheck = (Path)target;
				return;
			}
			this.baseRequest = true;
		}

		// Token: 0x04000871 RID: 2161
		public int _WatcherRequest;

		// Token: 0x04000872 RID: 2162
		[CompilerGenerated]
		private MyCheckBox.ChangeEventHandler m_TestRequest;

		// Token: 0x04000873 RID: 2163
		[CompilerGenerated]
		private MyCheckBox.PreviewChangeEventHandler taskRequest;

		// Token: 0x04000874 RID: 2164
		private bool _IteratorRequest;

		// Token: 0x04000875 RID: 2165
		public static readonly DependencyProperty _SerializerRequest = DependencyProperty.Register("Text", typeof(string), typeof(MyCheckBox), new PropertyMetadata(delegate(DependencyObject sender, DependencyPropertyChangedEventArgs e)
		{
			if (!Information.IsNothing(sender))
			{
				((MyCheckBox)sender).LabText.Text = Conversions.ToString(e.NewValue);
			}
		}));

		// Token: 0x04000876 RID: 2166
		private bool roleRequest;

		// Token: 0x04000877 RID: 2167
		private bool valueRequest;

		// Token: 0x04000878 RID: 2168
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyCheckBox _RecordRequest;

		// Token: 0x04000879 RID: 2169
		[CompilerGenerated]
		[AccessedThroughProperty("LabText")]
		private TextBlock _VisitorRequest;

		// Token: 0x0400087A RID: 2170
		[AccessedThroughProperty("ShapeBorder")]
		[CompilerGenerated]
		private Border _HelperRequest;

		// Token: 0x0400087B RID: 2171
		[CompilerGenerated]
		[AccessedThroughProperty("ShapeCheck")]
		private Path m_ParamRequest;

		// Token: 0x0400087C RID: 2172
		private bool baseRequest;

		// Token: 0x02000173 RID: 371
		// (Invoke) Token: 0x0600113C RID: 4412
		public delegate void ChangeEventHandler(object sender, bool user);

		// Token: 0x02000174 RID: 372
		// (Invoke) Token: 0x06001141 RID: 4417
		public delegate void PreviewChangeEventHandler(object sender, ModBase.RouteEventArgs e);
	}
}
