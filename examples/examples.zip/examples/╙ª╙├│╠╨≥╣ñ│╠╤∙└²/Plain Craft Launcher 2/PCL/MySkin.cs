﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using Microsoft.VisualBasic.CompilerServices;
using Newtonsoft.Json.Linq;

namespace PCL
{
	// Token: 0x02000129 RID: 297
	[DesignerGenerated]
	public class MySkin : Grid, IComponentConnector
	{
		// Token: 0x06000B46 RID: 2886 RVA: 0x0005A358 File Offset: 0x00058558
		public MySkin()
		{
			base.MouseEnter += this.PanSkin_MouseEnter;
			base.MouseLeave += this.PanSkin_MouseLeave;
			base.MouseLeftButtonDown += this.PanSkin_MouseLeftButtonDown;
			base.MouseLeftButtonUp += this.PanSkin_MouseLeftButtonUp;
			this.resolverComparator = false;
			this.m_TagComparator = false;
			this.InitializeComponent();
		}

		// Token: 0x06000B47 RID: 2887 RVA: 0x0005A3C8 File Offset: 0x000585C8
		[CompilerGenerated]
		public void VerifyResolver(MySkin.ClickEventHandler obj)
		{
			MySkin.ClickEventHandler clickEventHandler = this._ModelComparator;
			MySkin.ClickEventHandler clickEventHandler2;
			do
			{
				clickEventHandler2 = clickEventHandler;
				MySkin.ClickEventHandler value = (MySkin.ClickEventHandler)Delegate.Combine(clickEventHandler2, obj);
				clickEventHandler = Interlocked.CompareExchange<MySkin.ClickEventHandler>(ref this._ModelComparator, value, clickEventHandler2);
			}
			while (clickEventHandler != clickEventHandler2);
		}

		// Token: 0x06000B48 RID: 2888 RVA: 0x0005A400 File Offset: 0x00058600
		[CompilerGenerated]
		public void ResolveResolver(MySkin.ClickEventHandler obj)
		{
			MySkin.ClickEventHandler clickEventHandler = this._ModelComparator;
			MySkin.ClickEventHandler clickEventHandler2;
			do
			{
				clickEventHandler2 = clickEventHandler;
				MySkin.ClickEventHandler value = (MySkin.ClickEventHandler)Delegate.Remove(clickEventHandler2, obj);
				clickEventHandler = Interlocked.CompareExchange<MySkin.ClickEventHandler>(ref this._ModelComparator, value, clickEventHandler2);
			}
			while (clickEventHandler != clickEventHandler2);
		}

		// Token: 0x06000B49 RID: 2889 RVA: 0x000078ED File Offset: 0x00005AED
		public string DestroyResolver()
		{
			return this._WrapperComparator;
		}

		// Token: 0x06000B4A RID: 2890 RVA: 0x000078F5 File Offset: 0x00005AF5
		public void CloneResolver(string value)
		{
			this._WrapperComparator = value;
			base.ToolTip = ((Operators.CompareString(this._WrapperComparator, "", true) == 0) ? "加载中" : "点击更换皮肤（右键查看更多选项）");
		}

		// Token: 0x06000B4B RID: 2891 RVA: 0x00007923 File Offset: 0x00005B23
		private void PanSkin_MouseEnter(object sender, MouseEventArgs e)
		{
			ModAnimation.AniStart(ModAnimation.AaOpacity(this.ShadowSkin, 0.8 - this.ShadowSkin.Opacity, 200, 100, null, false), "Skin Shadow", false);
		}

		// Token: 0x06000B4C RID: 2892 RVA: 0x0005A438 File Offset: 0x00058638
		private void PanSkin_MouseLeave(object sender, MouseEventArgs e)
		{
			ModAnimation.AniStart(ModAnimation.AaOpacity(this.ShadowSkin, 0.2 - this.ShadowSkin.Opacity, 200, 0, null, false), "Skin Shadow", false);
			this.resolverComparator = false;
			ModAnimation.AniStart(ModAnimation.AaScaleTransform(this, 1.0 - ((ScaleTransform)base.RenderTransform).ScaleX, 60, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false), "Skin Scale", false);
		}

		// Token: 0x06000B4D RID: 2893 RVA: 0x00007959 File Offset: 0x00005B59
		private void PanSkin_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			this.resolverComparator = true;
			ModAnimation.AniStart(ModAnimation.AaScaleTransform(this, 0.9 - ((ScaleTransform)base.RenderTransform).ScaleX, 60, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false), "Skin Scale", false);
		}

		// Token: 0x06000B4E RID: 2894 RVA: 0x0005A4B4 File Offset: 0x000586B4
		private void PanSkin_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			ModAnimation.AniStart(ModAnimation.AaScaleTransform(this, 1.0 - ((ScaleTransform)base.RenderTransform).ScaleX, 60, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false), "Skin Scale", false);
			if (this.resolverComparator)
			{
				this.resolverComparator = false;
				MySkin.ClickEventHandler modelComparator = this._ModelComparator;
				if (modelComparator != null)
				{
					modelComparator(RuntimeHelpers.GetObjectValue(sender), e);
				}
			}
		}

		// Token: 0x06000B4F RID: 2895 RVA: 0x00007997 File Offset: 0x00005B97
		private void BtnSkinSave_Click(object sender, RoutedEventArgs e)
		{
			MySkin.Save(this.m_RepositoryComparator);
		}

		// Token: 0x06000B50 RID: 2896 RVA: 0x0005A51C File Offset: 0x0005871C
		public static void Save(ModLoader.LoaderTask<ModBase.EqualableList<string>, string> Loader)
		{
			string output = Loader.Output;
			if (Loader.State != ModBase.LoadState.Finished)
			{
				ModMain.Hint("皮肤正在获取中，请稍候！", ModMain.HintType.Critical, true);
				if (Loader.State != ModBase.LoadState.Loading)
				{
					Loader.Start(null, false);
					return;
				}
			}
			else
			{
				try
				{
					string text = ModBase.SelectAs("选取保存皮肤的位置", ModBase.GetFileNameFromPath(output), "皮肤图片文件(*.png)|*.png", null);
					if (text.Contains("\\"))
					{
						File.Delete(text);
						if (output.StartsWith(ModBase._TokenizerState))
						{
							new MyBitmap(output).Save(text);
						}
						else
						{
							File.Copy(output, text);
						}
						ModMain.Hint("皮肤保存成功！", ModMain.HintType.Finish, true);
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "保存皮肤失败", ModBase.LogLevel.Hint, "出现错误");
				}
			}
		}

		// Token: 0x06000B51 RID: 2897 RVA: 0x000079A4 File Offset: 0x00005BA4
		private void BtnSkinSave_Checked(MyMenuItem sender, RoutedEventArgs e)
		{
			sender.IsEnabled = (Operators.CompareString(this.DestroyResolver(), "", true) == 0);
		}

		// Token: 0x06000B52 RID: 2898 RVA: 0x0005A5E4 File Offset: 0x000587E4
		public void Load()
		{
			try
			{
				this.CloneResolver(this.m_RepositoryComparator.Output);
				if (Operators.CompareString(this.DestroyResolver(), "", true) == 0)
				{
					throw new Exception("皮肤加载器 " + this.m_RepositoryComparator.Name + " 没有输出");
				}
				if (!this.DestroyResolver().StartsWith(ModBase._TokenizerState) && !File.Exists(this.DestroyResolver()))
				{
					throw new FileNotFoundException("皮肤文件未找到", this.DestroyResolver());
				}
				MyBitmap myBitmap = new MyBitmap(this.DestroyResolver());
				this.ImgBack.Tag = this.DestroyResolver();
				if (myBitmap.templateAccount.Width >= 64 && myBitmap.templateAccount.Height >= 32)
				{
					if (checked(myBitmap.templateAccount.GetPixel(1, 1).A != 0 && myBitmap.templateAccount.GetPixel(myBitmap.templateAccount.Width - 1, myBitmap.templateAccount.Height - 1).A != 0 && myBitmap.templateAccount.GetPixel(myBitmap.templateAccount.Width - 2, 2).A != 0 && (!(myBitmap.templateAccount.GetPixel(1, 1) != myBitmap.templateAccount.GetPixel(41, 9)) || !(myBitmap.templateAccount.GetPixel(myBitmap.templateAccount.Width - 1, myBitmap.templateAccount.Height - 1) != myBitmap.templateAccount.GetPixel(41, 9)) || !(myBitmap.templateAccount.GetPixel(myBitmap.templateAccount.Width - 2, 2) != myBitmap.templateAccount.GetPixel(41, 9)))))
					{
						this.ImgFore.Source = null;
					}
					else
					{
						this.ImgFore.Source = new CroppedBitmap((BitmapSource)myBitmap, new Int32Rect(40, 8, 8, 8));
					}
				}
				else
				{
					this.ImgFore.Source = null;
				}
				if (myBitmap.templateAccount.Width < 32 || myBitmap.templateAccount.Height < 32)
				{
					this.ImgBack.Source = null;
					throw new Exception("图片大小不足，长为 " + Conversions.ToString(myBitmap.templateAccount.Height) + "，宽为 " + Conversions.ToString(myBitmap.templateAccount.Width));
				}
				this.ImgBack.Source = new CroppedBitmap((BitmapSource)myBitmap, new Int32Rect(8, 8, 8, 8));
				ModBase.Log("[Skin] 载入头像成功：" + this.m_RepositoryComparator.Name, ModBase.LogLevel.Normal, "出现错误");
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, string.Concat(new string[]
				{
					"载入头像失败（",
					this.DestroyResolver() ?? "null",
					",",
					this.m_RepositoryComparator.Name,
					"）"
				}), ModBase.LogLevel.Hint, "出现错误");
			}
		}

		// Token: 0x06000B53 RID: 2899 RVA: 0x000079C0 File Offset: 0x00005BC0
		public void Clear()
		{
			this.CloneResolver("");
			this.ImgFore.Source = null;
			this.ImgBack.Source = null;
		}

		// Token: 0x06000B54 RID: 2900 RVA: 0x000079E5 File Offset: 0x00005BE5
		private void RefreshClick(MyMenuItem sender, EventArgs e)
		{
			MySkin.RefreshCache(this.m_RepositoryComparator);
		}

		// Token: 0x06000B55 RID: 2901 RVA: 0x0005A904 File Offset: 0x00058B04
		public static void RefreshCache(ModLoader.LoaderTask<ModBase.EqualableList<string>, string> sender = null)
		{
			MySkin._Closure$__22-0 CS$<>8__locals1 = new MySkin._Closure$__22-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Local_sender = sender;
			bool flag = false;
			try
			{
				List<ModLoader.LoaderTask<ModBase.EqualableList<string>, string>>.Enumerator enumerator = PageLaunchLeft._ExpressionComparator.GetEnumerator();
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.State == ModBase.LoadState.Loading)
					{
						flag = true;
						break;
					}
				}
			}
			finally
			{
				List<ModLoader.LoaderTask<ModBase.EqualableList<string>, string>>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			if (ModMain._FilterAccount != null && flag)
			{
				ModMain.Hint("有正在获取中的皮肤，请稍后再试！", ModMain.HintType.Info, true);
				return;
			}
			ModBase.RunInThread(checked(delegate
			{
				try
				{
					ModMain.Hint("正在刷新皮肤……", ModMain.HintType.Info, true);
					ModBase.Log("[Skin] 正在清空皮肤缓存", ModBase.LogLevel.Normal, "出现错误");
					if (Directory.Exists(ModBase.attributeState + "Cache\\Skin"))
					{
						ModBase.DeleteDirectory(ModBase.attributeState + "Cache\\Skin", false);
					}
					if (Directory.Exists(ModBase.attributeState + "Cache\\Uuid"))
					{
						ModBase.DeleteDirectory(ModBase.attributeState + "Cache\\Uuid", false);
					}
					ModBase.IniClearCache(ModBase.attributeState + "Cache\\Skin\\IndexMojang.ini");
					ModBase.IniClearCache(ModBase.attributeState + "Cache\\Skin\\IndexMs.ini");
					ModBase.IniClearCache(ModBase.attributeState + "Cache\\Skin\\IndexNide.ini");
					ModBase.IniClearCache(ModBase.attributeState + "Cache\\Skin\\IndexAuth.ini");
					ModBase.IniClearCache(ModBase.attributeState + "Cache\\Uuid\\Mojang.ini");
					ModLoader.LoaderTask<ModBase.EqualableList<string>, string>[] array2;
					if (CS$<>8__locals1.$VB$Local_sender == null)
					{
						ModLoader.LoaderTask<ModBase.EqualableList<string>, string>[] array = new ModLoader.LoaderTask<ModBase.EqualableList<string>, string>[3];
						array[0] = PageLaunchLeft.facadeComparator;
						array[1] = PageLaunchLeft._StructComparator;
						array2 = array;
						array[2] = PageLaunchLeft.m_BridgeComparator;
					}
					else
					{
						(array2 = new ModLoader.LoaderTask<ModBase.EqualableList<string>, string>[1])[0] = CS$<>8__locals1.$VB$Local_sender;
					}
					ModLoader.LoaderTask<ModBase.EqualableList<string>, string>[] array3 = array2;
					for (int i = 0; i < array3.Length; i++)
					{
						array3[i].WaitForExit(null, null, true);
					}
					ModMain.Hint("已刷新皮肤！", ModMain.HintType.Finish, true);
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "刷新皮肤缓存失败", ModBase.LogLevel.Msgbox, "出现错误");
				}
			}));
		}

		// Token: 0x06000B56 RID: 2902 RVA: 0x0005A998 File Offset: 0x00058B98
		public static void ReloadCache(string SkinAddress, bool IsMsLogin)
		{
			MySkin._Closure$__23-0 CS$<>8__locals1 = new MySkin._Closure$__23-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Local_SkinAddress = SkinAddress;
			CS$<>8__locals1.$VB$Local_IsMsLogin = IsMsLogin;
			ModBase.RunInThread(checked(delegate
			{
				try
				{
					string text = CS$<>8__locals1.$VB$Local_IsMsLogin ? "Ms" : "Mojang";
					ModBase.WriteIni(ModBase.attributeState + "Cache\\Skin\\Index" + text + ".ini", Conversions.ToString(ModBase._ParamsState.Get("Cache" + text + "Uuid", null)), CS$<>8__locals1.$VB$Local_SkinAddress);
					ModBase.Log(string.Format("[Skin] 已写入皮肤地址缓存 {0} -> {1}", RuntimeHelpers.GetObjectValue(ModBase._ParamsState.Get("Cache" + text + "Uuid", null)), CS$<>8__locals1.$VB$Local_SkinAddress), ModBase.LogLevel.Normal, "出现错误");
					ModLoader.LoaderTask<ModBase.EqualableList<string>, string>[] array2;
					if (!CS$<>8__locals1.$VB$Local_IsMsLogin)
					{
						ModLoader.LoaderTask<ModBase.EqualableList<string>, string>[] array = new ModLoader.LoaderTask<ModBase.EqualableList<string>, string>[2];
						array[0] = PageLaunchLeft.facadeComparator;
						array2 = array;
						array[1] = PageLaunchLeft._StructComparator;
					}
					else
					{
						ModLoader.LoaderTask<ModBase.EqualableList<string>, string>[] array3 = new ModLoader.LoaderTask<ModBase.EqualableList<string>, string>[2];
						array3[0] = PageLaunchLeft.m_BridgeComparator;
						array2 = array3;
						array3[1] = PageLaunchLeft._StructComparator;
					}
					ModLoader.LoaderTask<ModBase.EqualableList<string>, string>[] array4 = array2;
					for (int i = 0; i < array4.Length; i++)
					{
						array4[i].WaitForExit(null, null, true);
					}
					ModMain.Hint("更改皮肤成功！", ModMain.HintType.Finish, true);
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "更改正版皮肤后刷新皮肤失败", ModBase.LogLevel.Feedback, "出现错误");
				}
			}));
		}

		// Token: 0x170001A1 RID: 417
		// (get) Token: 0x06000B57 RID: 2903 RVA: 0x000079F2 File Offset: 0x00005BF2
		// (set) Token: 0x06000B58 RID: 2904 RVA: 0x00007A02 File Offset: 0x00005C02
		public bool HasCape
		{
			get
			{
				return this.BtnSkinCape.Visibility == Visibility.Collapsed;
			}
			set
			{
				if (value)
				{
					this.BtnSkinCape.Visibility = Visibility.Visible;
					return;
				}
				this.BtnSkinCape.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x06000B59 RID: 2905 RVA: 0x0005A9CC File Offset: 0x00058BCC
		private void BtnSkinCape_Click(object sender, RoutedEventArgs e)
		{
			if (this.m_TagComparator)
			{
				ModMain.Hint("正在更改披风中，请稍候！", ModMain.HintType.Info, true);
				return;
			}
			if (ModLaunch._ExpressionTag.State == ModBase.LoadState.Failed)
			{
				ModMain.Hint("登录失败，无法更改披风！", ModMain.HintType.Critical, true);
				return;
			}
			ModMain.Hint("正在获取披风列表，请稍候……", ModMain.HintType.Info, true);
			this.m_TagComparator = true;
			ModBase.RunInNewThread(delegate
			{
				try
				{
					MySkin._Closure$__28-0 CS$<>8__locals1 = new MySkin._Closure$__28-0(CS$<>8__locals1);
					if (ModLaunch._ExpressionTag.State != ModBase.LoadState.Finished)
					{
						ModLaunch._ExpressionTag.WaitForExit(null, null, false);
					}
					if (ModLaunch._ExpressionTag.State == ModBase.LoadState.Failed)
					{
						ModMain.Hint("登录失败，无法更改披风！", ModMain.HintType.Critical, true);
					}
					else
					{
						string merchantProccesor = ModLaunch._ExpressionTag.Output.m_MerchantProccesor;
						CS$<>8__locals1.$VB$Local_SkinData = (JObject)ModBase.GetJson(ModLaunch._ExpressionTag.Output._GlobalProccesor);
						CS$<>8__locals1.$VB$Local_SelId = null;
						ModBase.RunInUiWait(delegate
						{
							try
							{
								Dictionary<string, string> dictionary = new Dictionary<string, string>
								{
									{
										"Migrator",
										"迁移者披风"
									},
									{
										"MapMaker",
										"Realms 地图制作者披风"
									},
									{
										"Moderator",
										"Mojira 管理员披风"
									},
									{
										"Translator-Chinese",
										"Crowdin 中文翻译者披风"
									},
									{
										"Translator",
										"Crowdin 翻译者披风"
									}
								};
								List<IMyRadio> list = new List<IMyRadio>
								{
									new MyRadioBox
									{
										Text = "无披风"
									}
								};
								try
								{
									foreach (JToken jtoken in CS$<>8__locals1.$VB$Local_SkinData["capes"])
									{
										string text2 = jtoken["alias"].ToString();
										if (dictionary.ContainsKey(text2))
										{
											text2 = dictionary[text2];
										}
										list.Add(new MyRadioBox
										{
											Text = text2
										});
									}
								}
								finally
								{
									IEnumerator<JToken> enumerator;
									if (enumerator != null)
									{
										enumerator.Dispose();
									}
								}
								CS$<>8__locals1.$VB$Local_SelId = ModMain.MyMsgBoxSelect(list, "选择披风", "确定", "取消", false);
							}
							catch (Exception ex2)
							{
								ModBase.Log(ex2, "获取玩家皮肤列表失败", ModBase.LogLevel.Feedback, "出现错误");
							}
						});
						if (CS$<>8__locals1.$VB$Local_SelId != null)
						{
							string url = "https://api.minecraftservices.com/minecraft/profile/capes/active";
							int? $VB$Local_SelId = CS$<>8__locals1.$VB$Local_SelId;
							string method = (($VB$Local_SelId != null) ? new bool?($VB$Local_SelId.GetValueOrDefault() == 0) : null).GetValueOrDefault() ? "DELETE" : "PUT";
							$VB$Local_SelId = CS$<>8__locals1.$VB$Local_SelId;
							string text = ModNet.NetRequestRetry(url, method, (($VB$Local_SelId != null) ? new bool?($VB$Local_SelId.GetValueOrDefault() == 0) : null).GetValueOrDefault() ? "" : ("{\"capeId\": \"" + CS$<>8__locals1.$VB$Local_SkinData["capes"][checked(CS$<>8__locals1.$VB$Local_SelId - 1)]["id"].ToString() + "\"}"), "application/json", true, new Dictionary<string, string>
							{
								{
									"Authorization",
									"Bearer " + merchantProccesor
								}
							});
							if (text.Contains("\"errorMessage\""))
							{
								ModMain.Hint(Conversions.ToString(Operators.ConcatenateObject("更改披风失败：", NewLateBinding.LateIndexGet(ModBase.GetJson(text), new object[]
								{
									"errorMessage"
								}, null))), ModMain.HintType.Critical, true);
							}
							else
							{
								ModMain.Hint("更改披风成功！", ModMain.HintType.Finish, true);
							}
						}
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "更改披风失败", ModBase.LogLevel.Hint, "出现错误");
				}
				finally
				{
					this.m_TagComparator = false;
				}
			}, "Cape Change", ThreadPriority.Normal);
		}

		// Token: 0x170001A2 RID: 418
		// (get) Token: 0x06000B5A RID: 2906 RVA: 0x00007A20 File Offset: 0x00005C20
		// (set) Token: 0x06000B5B RID: 2907 RVA: 0x00007A28 File Offset: 0x00005C28
		internal virtual DropShadowEffect ShadowSkin { get; set; }

		// Token: 0x170001A3 RID: 419
		// (get) Token: 0x06000B5C RID: 2908 RVA: 0x00007A31 File Offset: 0x00005C31
		// (set) Token: 0x06000B5D RID: 2909 RVA: 0x0005AA34 File Offset: 0x00058C34
		internal virtual MyMenuItem BtnSkinSave
		{
			[CompilerGenerated]
			get
			{
				return this.m_PrototypeComparator;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = new RoutedEventHandler(this.BtnSkinSave_Click);
				RoutedEventHandler value3 = delegate(object sender, RoutedEventArgs e)
				{
					this.BtnSkinSave_Checked((MyMenuItem)sender, e);
				};
				MyMenuItem prototypeComparator = this.m_PrototypeComparator;
				if (prototypeComparator != null)
				{
					prototypeComparator.Click -= value2;
					prototypeComparator.Checked -= value3;
				}
				this.m_PrototypeComparator = value;
				prototypeComparator = this.m_PrototypeComparator;
				if (prototypeComparator != null)
				{
					prototypeComparator.Click += value2;
					prototypeComparator.Checked += value3;
				}
			}
		}

		// Token: 0x170001A4 RID: 420
		// (get) Token: 0x06000B5E RID: 2910 RVA: 0x00007A39 File Offset: 0x00005C39
		// (set) Token: 0x06000B5F RID: 2911 RVA: 0x0005AA94 File Offset: 0x00058C94
		internal virtual MyMenuItem BtnSkinRefresh
		{
			[CompilerGenerated]
			get
			{
				return this.m_IssuerComparator;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = delegate(object sender, RoutedEventArgs e)
				{
					this.RefreshClick((MyMenuItem)sender, e);
				};
				MyMenuItem issuerComparator = this.m_IssuerComparator;
				if (issuerComparator != null)
				{
					issuerComparator.Click -= value2;
				}
				this.m_IssuerComparator = value;
				issuerComparator = this.m_IssuerComparator;
				if (issuerComparator != null)
				{
					issuerComparator.Click += value2;
				}
			}
		}

		// Token: 0x170001A5 RID: 421
		// (get) Token: 0x06000B60 RID: 2912 RVA: 0x00007A41 File Offset: 0x00005C41
		// (set) Token: 0x06000B61 RID: 2913 RVA: 0x0005AAD8 File Offset: 0x00058CD8
		internal virtual MyMenuItem BtnSkinCape
		{
			[CompilerGenerated]
			get
			{
				return this.m_RequestComparator;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = new RoutedEventHandler(this.BtnSkinCape_Click);
				MyMenuItem requestComparator = this.m_RequestComparator;
				if (requestComparator != null)
				{
					requestComparator.Click -= value2;
				}
				this.m_RequestComparator = value;
				requestComparator = this.m_RequestComparator;
				if (requestComparator != null)
				{
					requestComparator.Click += value2;
				}
			}
		}

		// Token: 0x170001A6 RID: 422
		// (get) Token: 0x06000B62 RID: 2914 RVA: 0x00007A49 File Offset: 0x00005C49
		// (set) Token: 0x06000B63 RID: 2915 RVA: 0x00007A51 File Offset: 0x00005C51
		internal virtual Image ImgBack { get; set; }

		// Token: 0x170001A7 RID: 423
		// (get) Token: 0x06000B64 RID: 2916 RVA: 0x00007A5A File Offset: 0x00005C5A
		// (set) Token: 0x06000B65 RID: 2917 RVA: 0x00007A62 File Offset: 0x00005C62
		internal virtual Image ImgFore { get; set; }

		// Token: 0x06000B66 RID: 2918 RVA: 0x0005AB1C File Offset: 0x00058D1C
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.proccesorComparator)
			{
				this.proccesorComparator = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagelaunch/myskin.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000B67 RID: 2919 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000B68 RID: 2920 RVA: 0x0005AB4C File Offset: 0x00058D4C
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.ShadowSkin = (DropShadowEffect)target;
				return;
			}
			if (connectionId == 2)
			{
				this.BtnSkinSave = (MyMenuItem)target;
				return;
			}
			if (connectionId == 3)
			{
				this.BtnSkinRefresh = (MyMenuItem)target;
				return;
			}
			if (connectionId == 4)
			{
				this.BtnSkinCape = (MyMenuItem)target;
				return;
			}
			if (connectionId == 5)
			{
				this.ImgBack = (Image)target;
				return;
			}
			if (connectionId == 6)
			{
				this.ImgFore = (Image)target;
				return;
			}
			this.proccesorComparator = true;
		}

		// Token: 0x040005E5 RID: 1509
		[CompilerGenerated]
		private MySkin.ClickEventHandler _ModelComparator;

		// Token: 0x040005E6 RID: 1510
		private string _WrapperComparator;

		// Token: 0x040005E7 RID: 1511
		public ModLoader.LoaderTask<ModBase.EqualableList<string>, string> m_RepositoryComparator;

		// Token: 0x040005E8 RID: 1512
		private bool resolverComparator;

		// Token: 0x040005E9 RID: 1513
		private bool m_TagComparator;

		// Token: 0x040005EA RID: 1514
		[AccessedThroughProperty("ShadowSkin")]
		[CompilerGenerated]
		private DropShadowEffect m_ComparatorComparator;

		// Token: 0x040005EB RID: 1515
		[AccessedThroughProperty("BtnSkinSave")]
		[CompilerGenerated]
		private MyMenuItem m_PrototypeComparator;

		// Token: 0x040005EC RID: 1516
		[AccessedThroughProperty("BtnSkinRefresh")]
		[CompilerGenerated]
		private MyMenuItem m_IssuerComparator;

		// Token: 0x040005ED RID: 1517
		[AccessedThroughProperty("BtnSkinCape")]
		[CompilerGenerated]
		private MyMenuItem m_RequestComparator;

		// Token: 0x040005EE RID: 1518
		[CompilerGenerated]
		[AccessedThroughProperty("ImgBack")]
		private Image m_AccountComparator;

		// Token: 0x040005EF RID: 1519
		[AccessedThroughProperty("ImgFore")]
		[CompilerGenerated]
		private Image stateComparator;

		// Token: 0x040005F0 RID: 1520
		private bool proccesorComparator;

		// Token: 0x0200012A RID: 298
		// (Invoke) Token: 0x06000B70 RID: 2928
		public delegate void ClickEventHandler(object sender, MouseButtonEventArgs e);
	}
}
