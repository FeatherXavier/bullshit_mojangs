﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200003B RID: 59
	public class MyPageLeft : Grid
	{
		// Token: 0x06000143 RID: 323 RVA: 0x00002E25 File Offset: 0x00001025
		public MyPageLeft()
		{
			this.m_Identifier = ModBase.GetUuid();
		}

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x06000144 RID: 324 RVA: 0x00002E39 File Offset: 0x00001039
		// (set) Token: 0x06000145 RID: 325 RVA: 0x00002E4B File Offset: 0x0000104B
		public FrameworkElement AnimatedControl
		{
			get
			{
				return (FrameworkElement)base.GetValue(MyPageLeft._Instance);
			}
			set
			{
				base.SetValue(MyPageLeft._Instance, value);
			}
		}

		// Token: 0x06000146 RID: 326 RVA: 0x00011368 File Offset: 0x0000F568
		public void TriggerShowAnimation()
		{
			if (this.AnimatedControl == null)
			{
				if (!(base.RenderTransform is ScaleTransform))
				{
					base.RenderTransform = new ScaleTransform(0.96, 0.96);
					base.RenderTransformOrigin = new Point(0.5, 0.5);
				}
				base.Opacity = 0.0;
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaScaleTransform(this, 1.0 - ((ScaleTransform)base.RenderTransform).ScaleX, 400, 0, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Weak), false),
					ModAnimation.AaOpacity(this, 1.0, 100, 0, null, false)
				}, "PageLeft PageChange " + Conversions.ToString(this.m_Identifier), false);
				return;
			}
			List<ModAnimation.AniData> list = new List<ModAnimation.AniData>();
			int num = 0;
			int num2 = 0;
			List<FrameworkElement> allAnimControls = this.GetAllAnimControls();
			checked
			{
				try
				{
					List<FrameworkElement>.Enumerator enumerator = allAnimControls.GetEnumerator();
					while (enumerator.MoveNext())
					{
						MyPageLeft._Closure$__7-0 CS$<>8__locals1 = new MyPageLeft._Closure$__7-0(CS$<>8__locals1);
						CS$<>8__locals1.$VB$Me = this;
						CS$<>8__locals1.$VB$Local_Element = enumerator.Current;
						CS$<>8__locals1.$VB$Local_Element.Opacity = 0.0;
						CS$<>8__locals1.$VB$Local_Element.RenderTransform = new TranslateTransform(-25.0, 0.0);
						list.Add(ModAnimation.AaOpacity(CS$<>8__locals1.$VB$Local_Element, (CS$<>8__locals1.$VB$Local_Element is TextBlock) ? 0.6 : 1.0, 200, num2, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Weak), false));
						list.Add(ModAnimation.AaTranslateX(CS$<>8__locals1.$VB$Local_Element, 5.0, 200, num2, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false));
						list.Add(ModAnimation.AaTranslateX(CS$<>8__locals1.$VB$Local_Element, 20.0, 300, num2, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Weak), false));
						if (CS$<>8__locals1.$VB$Local_Element is MyListItem)
						{
							list.Add(ModAnimation.AaCode(delegate
							{
								((MyListItem)CS$<>8__locals1.$VB$Local_Element).paramsRequest = true;
								((MyListItem)CS$<>8__locals1.$VB$Local_Element).RefreshColor(CS$<>8__locals1.$VB$Me, new EventArgs());
							}, num2 + 280, false));
						}
						num2 = (int)Math.Round(unchecked((double)num2 + (double)Math.Max(8, checked(20 - num)) * 2.5));
						num++;
					}
				}
				finally
				{
					List<FrameworkElement>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				ModAnimation.AniStart(list, "PageLeft PageChange " + Conversions.ToString(this.m_Identifier), false);
			}
		}

		// Token: 0x06000147 RID: 327 RVA: 0x000115F4 File Offset: 0x0000F7F4
		public void TriggerHideAnimation()
		{
			if (this.AnimatedControl == null)
			{
				if (!(base.RenderTransform is ScaleTransform))
				{
					base.RenderTransform = new ScaleTransform(1.0, 1.0);
					base.RenderTransformOrigin = new Point(0.5, 0.5);
				}
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaScaleTransform(this, 0.95 - ((ScaleTransform)base.RenderTransform).ScaleX, 130, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Weak), false),
					ModAnimation.AaOpacity(this, -base.Opacity, 100, 30, null, false)
				}, "PageLeft PageChange " + Conversions.ToString(this.m_Identifier), false);
				return;
			}
			List<ModAnimation.AniData> list = new List<ModAnimation.AniData>();
			int num = 0;
			List<FrameworkElement> allAnimControls = this.GetAllAnimControls();
			checked
			{
				try
				{
					foreach (FrameworkElement frameworkElement in allAnimControls)
					{
						list.Add(ModAnimation.AaOpacity(frameworkElement, unchecked(-frameworkElement.Opacity), 60, (int)Math.Round(unchecked(80.0 / (double)allAnimControls.Count * (double)num)), null, false));
						list.Add(ModAnimation.AaTranslateX(frameworkElement, -6.0, 60, (int)Math.Round(unchecked(80.0 / (double)allAnimControls.Count * (double)num)), null, false));
						num++;
					}
				}
				finally
				{
					List<FrameworkElement>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				ModAnimation.AniStart(list, "PageLeft PageChange " + Conversions.ToString(this.m_Identifier), false);
			}
		}

		// Token: 0x06000148 RID: 328 RVA: 0x00011794 File Offset: 0x0000F994
		private List<FrameworkElement> GetAllAnimControls()
		{
			List<FrameworkElement> result = new List<FrameworkElement>();
			this.GetAllAnimControls(this.AnimatedControl, ref result);
			return result;
		}

		// Token: 0x06000149 RID: 329 RVA: 0x000117B8 File Offset: 0x0000F9B8
		private void GetAllAnimControls(FrameworkElement Element, ref List<FrameworkElement> AllControls)
		{
			if (Element.Visibility != Visibility.Collapsed)
			{
				if (Element is MyTextButton)
				{
					AllControls.Add(Element);
					return;
				}
				if (Element is MyListItem)
				{
					((MyListItem)Element).paramsRequest = false;
					AllControls.Add(Element);
					return;
				}
				if (Element is ContentControl)
				{
					this.GetAllAnimControls((FrameworkElement)((ContentControl)Element).Content, ref AllControls);
					return;
				}
				if (Element is Panel)
				{
					try
					{
						foreach (object obj in ((Panel)Element).Children)
						{
							FrameworkElement element = (FrameworkElement)obj;
							this.GetAllAnimControls(element, ref AllControls);
						}
						return;
					}
					finally
					{
						IEnumerator enumerator;
						if (enumerator is IDisposable)
						{
							(enumerator as IDisposable).Dispose();
						}
					}
				}
				AllControls.Add(Element);
			}
		}

		// Token: 0x040000A4 RID: 164
		private int m_Identifier;

		// Token: 0x040000A5 RID: 165
		public static readonly DependencyProperty _Instance = DependencyProperty.Register("AnimatedControl", typeof(FrameworkElement), typeof(MyPageLeft), new PropertyMetadata(null));
	}
}
