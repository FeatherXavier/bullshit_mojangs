﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic.FileIO;

namespace PCL
{
	// Token: 0x020000D2 RID: 210
	[StandardModule]
	public sealed class ModNet
	{
		// Token: 0x0600088D RID: 2189 RVA: 0x00039934 File Offset: 0x00037B34
		public static string NetGetCodeByClient(string Url, Encoding Encoding, string Accept = "application/json, text/javascript, */*; q=0.01")
		{
			int num = 0;
			Exception ex = null;
			long timeTick = ModBase.GetTimeTick();
			checked
			{
				string result;
				try
				{
					IL_0A:
					if (num != 0)
					{
						if (num != 1)
						{
							if (ModBase.GetTimeTick() - timeTick <= 5500L)
							{
								throw ex;
							}
							Thread.Sleep(500);
							result = ModNet.NetGetCodeByClient(Url, Encoding, 4000, Accept);
						}
						else
						{
							Thread.Sleep(500);
							result = ModNet.NetGetCodeByClient(Url, Encoding, 30000, Accept);
						}
					}
					else
					{
						result = ModNet.NetGetCodeByClient(Url, Encoding, 10000, Accept);
					}
				}
				catch (Exception ex2)
				{
					if (num == 0)
					{
						ex = ex2;
						num++;
						goto IL_0A;
					}
					if (num != 1)
					{
						throw;
					}
					num++;
					goto IL_0A;
				}
				return result;
			}
		}

		// Token: 0x0600088E RID: 2190 RVA: 0x000399E8 File Offset: 0x00037BE8
		public static string NetGetCodeByClient(string Url, Encoding Encoding, int Timeout, string Accept)
		{
			Url = Conversions.ToString(ModBase.GetCdnTypeA(Url));
			ModBase.Log("[Net] 获取客户端网络结果：" + Url + "，最大超时 " + Conversions.ToString(Timeout), ModBase.LogLevel.Normal, "出现错误");
			HttpWebResponse httpWebResponse = null;
			Stream stream = null;
			string result;
			try
			{
				CookieWebClient cookieWebClient = new CookieWebClient();
				cookieWebClient.Encoding = Encoding;
				cookieWebClient._ValWrapper = Timeout;
				cookieWebClient.Headers["User-Agent"] = "PCL2/2.2.9.50 Mozilla/5.0 AppleWebKit/537.36 Chrome/63.0.3239.132 Safari/537.36";
				cookieWebClient.Headers["Accept"] = Accept;
				cookieWebClient.Headers["Accept-Language"] = "en-US,en;q=0.5";
				cookieWebClient.Headers["X-Requested-With"] = "XMLHttpRequest";
				cookieWebClient.Headers["Referer"] = "http://" + Conversions.ToString(246) + ".pcl2.server/";
				result = cookieWebClient.DownloadString(Url);
			}
			catch (Exception ex)
			{
				if (ex.GetType().Equals(typeof(WebException)) && ((WebException)ex).Status == WebExceptionStatus.Timeout)
				{
					throw new TimeoutException("连接服务器超时（" + Url + "）", ex);
				}
				throw new WebException(string.Concat(new string[]
				{
					"获取结果失败，",
					ex.Message,
					"（",
					Url,
					"）"
				}), ex);
			}
			finally
			{
				if (!Information.IsNothing(stream))
				{
					stream.Dispose();
				}
				if (!Information.IsNothing(httpWebResponse))
				{
					httpWebResponse.Dispose();
				}
			}
			return result;
		}

		// Token: 0x0600088F RID: 2191 RVA: 0x00039B90 File Offset: 0x00037D90
		public static object NetGetCodeByRequestRetry(string Url, Encoding Encode = null, string Accept = "", bool IsJson = false)
		{
			int num = 0;
			Exception ex = null;
			long timeTick = ModBase.GetTimeTick();
			checked
			{
				object result;
				try
				{
					IL_0A:
					if (num != 0)
					{
						if (num != 1)
						{
							if (ModBase.GetTimeTick() - timeTick <= 5500L)
							{
								throw ex;
							}
							Thread.Sleep(500);
							result = ModNet.NetGetCodeRequest(Url, Encode, 4000, IsJson, Accept);
						}
						else
						{
							Thread.Sleep(500);
							result = ModNet.NetGetCodeRequest(Url, Encode, 30000, IsJson, Accept);
						}
					}
					else
					{
						result = ModNet.NetGetCodeRequest(Url, Encode, 10000, IsJson, Accept);
					}
				}
				catch (ThreadInterruptedException ex2)
				{
					throw;
				}
				catch (Exception ex3)
				{
					if (num == 0)
					{
						ex = ex3;
						num++;
						goto IL_0A;
					}
					if (num != 1)
					{
						throw;
					}
					num++;
					goto IL_0A;
				}
				return result;
			}
		}

		// Token: 0x06000890 RID: 2192 RVA: 0x00039C60 File Offset: 0x00037E60
		public static object NetGetCodeByRequestMuity(string Url, Encoding Encode = null, string Accept = "", bool IsJson = false)
		{
			ModNet._Closure$__5-0 CS$<>8__locals1 = new ModNet._Closure$__5-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Local_Url = Url;
			CS$<>8__locals1.$VB$Local_Encode = Encode;
			CS$<>8__locals1.$VB$Local_Accept = Accept;
			CS$<>8__locals1.$VB$Local_IsJson = IsJson;
			List<Thread> list = new List<Thread>();
			CS$<>8__locals1.$VB$Local_RequestResult = null;
			CS$<>8__locals1.$VB$Local_RequestEx = null;
			CS$<>8__locals1.$VB$Local_FailCount = 0;
			int num = 1;
			checked
			{
				do
				{
					Thread thread = new Thread((CS$<>8__locals1.$I0 == null) ? (CS$<>8__locals1.$I0 = delegate()
					{
						try
						{
							CS$<>8__locals1.$VB$Local_RequestResult = RuntimeHelpers.GetObjectValue(ModNet.NetGetCodeRequest(CS$<>8__locals1.$VB$Local_Url, CS$<>8__locals1.$VB$Local_Encode, 30000, CS$<>8__locals1.$VB$Local_IsJson, CS$<>8__locals1.$VB$Local_Accept));
						}
						catch (Exception $VB$Local_RequestEx)
						{
							CS$<>8__locals1.$VB$Local_FailCount++;
							CS$<>8__locals1.$VB$Local_RequestEx = $VB$Local_RequestEx;
						}
					}) : CS$<>8__locals1.$I0);
					thread.Start();
					list.Add(thread);
					Thread.Sleep(num * 250);
					if (CS$<>8__locals1.$VB$Local_RequestResult != null)
					{
						goto IL_114;
					}
					num++;
				}
				while (num <= 4);
				while (CS$<>8__locals1.$VB$Local_RequestResult == null)
				{
					if (CS$<>8__locals1.$VB$Local_FailCount == 4)
					{
						try
						{
							try
							{
								foreach (Thread thread2 in list)
								{
									if (thread2.IsAlive)
									{
										thread2.Interrupt();
									}
								}
							}
							finally
							{
								List<Thread>.Enumerator enumerator;
								((IDisposable)enumerator).Dispose();
							}
						}
						catch (Exception ex)
						{
						}
						throw CS$<>8__locals1.$VB$Local_RequestEx;
					}
					Thread.Sleep(20);
				}
				IL_114:
				try
				{
					try
					{
						foreach (Thread thread3 in list)
						{
							if (thread3.IsAlive)
							{
								thread3.Interrupt();
							}
						}
					}
					finally
					{
						List<Thread>.Enumerator enumerator2;
						((IDisposable)enumerator2).Dispose();
					}
				}
				catch (Exception ex2)
				{
				}
				return CS$<>8__locals1.$VB$Local_RequestResult;
			}
		}

		// Token: 0x06000891 RID: 2193 RVA: 0x00039E08 File Offset: 0x00038008
		private static object NetGetCodeRequest(string Url, Encoding Encode, int Timeout, bool IsJson, string Accept)
		{
			if (ModBase.RunInUi())
			{
				throw new Exception("在 UI 线程执行了网络请求");
			}
			Url = Conversions.ToString(ModBase.GetCdnTypeA(Url));
			ModBase.Log("[Net] 获取网络结果：" + Url + "，最大超时 " + Conversions.ToString(Timeout), ModBase.LogLevel.Normal, "出现错误");
			HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(Url);
			List<byte> list = new List<byte>();
			object result;
			try
			{
				if (Url.StartsWith("https", StringComparison.OrdinalIgnoreCase))
				{
					httpWebRequest.ProtocolVersion = HttpVersion.Version10;
				}
				httpWebRequest.Timeout = Timeout;
				httpWebRequest.Accept = Accept;
				httpWebRequest.KeepAlive = false;
				httpWebRequest.UserAgent = "PCL2/2.2.9.50 Mozilla/5.0 AppleWebKit/537.36 Chrome/63.0.3239.132 Safari/537.36";
				httpWebRequest.Referer = "http://" + Conversions.ToString(246) + ".pcl2.server/";
				if (Url.Contains("api.curseforge.com"))
				{
					httpWebRequest.Headers.Add("x-api-key", "$2a$10$7WWV1WELcwX8Xp7d68MHs.5grTyZVa6SynyeSyMh1rsE89nIa09zO");
				}
				using (HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse())
				{
					using (Stream responseStream = httpWebResponse.GetResponseStream())
					{
						responseStream.ReadTimeout = Timeout;
						using (StreamReader streamReader = new StreamReader(responseStream, Encode ?? Encoding.UTF8))
						{
							string text = streamReader.ReadToEnd();
							result = (IsJson ? ModBase.GetJson(text) : text);
						}
					}
				}
			}
			catch (ThreadInterruptedException ex)
			{
				throw;
			}
			catch (Exception ex2)
			{
				if (ex2.GetType().Equals(typeof(WebException)) && ((WebException)ex2).Status == WebExceptionStatus.Timeout)
				{
					throw new TimeoutException(string.Concat(new string[]
					{
						"连接服务器超时，已接收 ",
						Conversions.ToString(list.Count),
						" B（",
						Url,
						"）"
					}));
				}
				throw new WebException(string.Concat(new string[]
				{
					"获取结果失败，",
					ex2.Message,
					"（",
					Url,
					"）"
				}), ex2);
			}
			finally
			{
				httpWebRequest.Abort();
			}
			return result;
		}

		// Token: 0x06000892 RID: 2194 RVA: 0x0003A09C File Offset: 0x0003829C
		public static string NetGetCodeByDownload(string Url, int Timeout = 45000, bool IsJson = false)
		{
			string text = string.Concat(new string[]
			{
				ModBase.attributeState,
				"Cache\\Code\\",
				Conversions.ToString(Url.GetHashCode()),
				"_",
				Conversions.ToString(ModBase.GetUuid())
			});
			ModNet.LoaderDownload loaderDownload = new ModNet.LoaderDownload("源码获取 " + Conversions.ToString(ModBase.GetUuid()) + "#", new List<ModNet.NetFile>
			{
				new ModNet.NetFile(new string[]
				{
					Url
				}, text, new ModBase.FileChecker(-1L, -1L, null, true, false)
				{
					_AnnotationParameter = IsJson
				})
			});
			string result;
			try
			{
				loaderDownload.WaitForExitTime(Timeout, null, "连接服务器超时（" + Url + "）", null, false);
				result = ModBase.ReadFile(text);
				File.Delete(text);
			}
			finally
			{
				loaderDownload.Abort();
			}
			return result;
		}

		// Token: 0x06000893 RID: 2195 RVA: 0x0003A188 File Offset: 0x00038388
		public static string NetGetCodeByDownload(string[] Urls, int Timeout = 45000, bool IsJson = false)
		{
			string text = string.Concat(new string[]
			{
				ModBase.attributeState,
				"Cache\\Code\\",
				Conversions.ToString(Urls[0].GetHashCode()),
				"_",
				Conversions.ToString(ModBase.GetUuid())
			});
			ModNet.LoaderDownload loaderDownload = new ModNet.LoaderDownload("源码获取 " + Conversions.ToString(ModBase.GetUuid()) + "#", new List<ModNet.NetFile>
			{
				new ModNet.NetFile(Urls, text, new ModBase.FileChecker(-1L, -1L, null, true, false)
				{
					_AnnotationParameter = IsJson
				})
			});
			string result;
			try
			{
				loaderDownload.WaitForExitTime(Timeout, null, "连接服务器超时（第一下载源：" + Urls[0] + "）", null, false);
				result = ModBase.ReadFile(text);
				File.Delete(text);
			}
			finally
			{
				loaderDownload.Abort();
			}
			return result;
		}

		// Token: 0x06000894 RID: 2196 RVA: 0x0003A26C File Offset: 0x0003846C
		public static void NetDownload(string Url, string LocalFile)
		{
			ModBase.Log("[Net] 直接下载文件：" + Url, ModBase.LogLevel.Normal, "出现错误");
			try
			{
				Directory.CreateDirectory(ModBase.GetPathFromFullPath(LocalFile));
				File.Delete(LocalFile);
			}
			catch (Exception innerException)
			{
				throw new WebException("预处理下载文件路径失败（" + LocalFile + "）。", innerException);
			}
			using (WebClient webClient = new WebClient())
			{
				try
				{
					webClient.DownloadFile(Url, LocalFile);
				}
				catch (Exception innerException2)
				{
					throw new WebException("直接下载文件失败（" + Url + "）。", innerException2);
				}
			}
		}

		// Token: 0x06000895 RID: 2197 RVA: 0x0003A324 File Offset: 0x00038524
		public static string NetRequestRetry(string Url, string Method, object Data, string ContentType, bool DontRetryOnRefused = true, Dictionary<string, string> Headers = null)
		{
			int num = 0;
			Exception ex = null;
			long timeTick = ModBase.GetTimeTick();
			checked
			{
				string result;
				try
				{
					IL_0A:
					if (num != 0)
					{
						if (num != 1)
						{
							if (ModBase.GetTimeTick() - timeTick <= 5500L)
							{
								throw ex;
							}
							Thread.Sleep(500);
							result = ModNet.NetRequestOnce(Url, Method, RuntimeHelpers.GetObjectValue(Data), ContentType, 4000, Headers, true);
						}
						else
						{
							Thread.Sleep(500);
							result = ModNet.NetRequestOnce(Url, Method, RuntimeHelpers.GetObjectValue(Data), ContentType, 25000, Headers, true);
						}
					}
					else
					{
						result = ModNet.NetRequestOnce(Url, Method, RuntimeHelpers.GetObjectValue(Data), ContentType, 15000, Headers, true);
					}
				}
				catch (ThreadInterruptedException ex2)
				{
					throw;
				}
				catch (Exception ex3)
				{
					if (ex3.InnerException != null && ex3.InnerException.Message.Contains("(40") && DontRetryOnRefused)
					{
						num = 999;
					}
					if (num == 0)
					{
						if (ModBase._EventState)
						{
							ModBase.Log(ex3, "[Net] 网络请求第一次失败（" + Url + "）", ModBase.LogLevel.Debug, "出现错误");
						}
						ex = ex3;
						num++;
						goto IL_0A;
					}
					if (num != 1)
					{
						throw;
					}
					if (ModBase._EventState)
					{
						ModBase.Log(ex3, "[Net] 网络请求第二次失败（" + Url + "）", ModBase.LogLevel.Debug, "出现错误");
					}
					num++;
					goto IL_0A;
				}
				return result;
			}
		}

		// Token: 0x06000896 RID: 2198 RVA: 0x0003A488 File Offset: 0x00038688
		public static object NetRequestMuity(string Url, string Method, object Data, string ContentType, int RequestCount = 4, Dictionary<string, string> Headers = null)
		{
			ModNet._Closure$__11-0 CS$<>8__locals1 = new ModNet._Closure$__11-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Local_Url = Url;
			CS$<>8__locals1.$VB$Local_Method = Method;
			CS$<>8__locals1.$VB$Local_Data = Data;
			CS$<>8__locals1.$VB$Local_ContentType = ContentType;
			CS$<>8__locals1.$VB$Local_Headers = Headers;
			List<Thread> list = new List<Thread>();
			CS$<>8__locals1.$VB$Local_RequestResult = null;
			CS$<>8__locals1.$VB$Local_RequestEx = null;
			CS$<>8__locals1.$VB$Local_FailCount = 0;
			int num = 1;
			checked
			{
				do
				{
					Thread thread = new Thread((CS$<>8__locals1.$I0 == null) ? (CS$<>8__locals1.$I0 = delegate()
					{
						try
						{
							CS$<>8__locals1.$VB$Local_RequestResult = ModNet.NetRequestOnce(CS$<>8__locals1.$VB$Local_Url, CS$<>8__locals1.$VB$Local_Method, RuntimeHelpers.GetObjectValue(CS$<>8__locals1.$VB$Local_Data), CS$<>8__locals1.$VB$Local_ContentType, 30000, CS$<>8__locals1.$VB$Local_Headers, true);
						}
						catch (Exception $VB$Local_RequestEx)
						{
							CS$<>8__locals1.$VB$Local_FailCount++;
							CS$<>8__locals1.$VB$Local_RequestEx = $VB$Local_RequestEx;
						}
					}) : CS$<>8__locals1.$I0);
					thread.Start();
					list.Add(thread);
					Thread.Sleep(num * 250);
					if (CS$<>8__locals1.$VB$Local_RequestResult != null)
					{
						goto IL_10F;
					}
					num++;
				}
				while (num <= 4);
				while (CS$<>8__locals1.$VB$Local_RequestResult == null)
				{
					if (CS$<>8__locals1.$VB$Local_FailCount == RequestCount)
					{
						try
						{
							foreach (Thread thread2 in list)
							{
								if (thread2.IsAlive)
								{
									thread2.Interrupt();
								}
							}
						}
						finally
						{
							List<Thread>.Enumerator enumerator;
							((IDisposable)enumerator).Dispose();
						}
						throw CS$<>8__locals1.$VB$Local_RequestEx;
					}
					Thread.Sleep(20);
				}
				IL_10F:
				try
				{
					foreach (Thread thread3 in list)
					{
						if (thread3.IsAlive)
						{
							thread3.Interrupt();
						}
					}
				}
				finally
				{
					List<Thread>.Enumerator enumerator2;
					((IDisposable)enumerator2).Dispose();
				}
				return CS$<>8__locals1.$VB$Local_RequestResult;
			}
		}

		// Token: 0x06000897 RID: 2199 RVA: 0x0003A608 File Offset: 0x00038808
		public static string NetRequestOnce(string Url, string Method, byte[] Data, string ContentType, int Timeout = 25000, Dictionary<string, string> Headers = null, bool MakeLog = true)
		{
			if (ModBase.RunInUi())
			{
				throw new Exception("在 UI 线程执行了网络请求");
			}
			Url = Conversions.ToString(ModBase.GetCdnTypeA(Url));
			if (MakeLog)
			{
				ModBase.Log(string.Concat(new string[]
				{
					"[Net] 发起网络请求（",
					Method,
					"，",
					Url,
					"），最大超时 ",
					Conversions.ToString(Timeout)
				}), ModBase.LogLevel.Normal, "出现错误");
			}
			Stream stream = null;
			WebResponse webResponse = null;
			string result;
			try
			{
				HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(new Uri(Url));
				httpWebRequest.Method = Method;
				byte[] array;
				if (Data is byte[])
				{
					array = (byte[])Data;
				}
				else
				{
					array = new UTF8Encoding(false).GetBytes(Data.ToString());
				}
				if (Url.Contains("api.curseforge.com"))
				{
					httpWebRequest.Headers.Add("x-api-key", "$2a$10$7WWV1WELcwX8Xp7d68MHs.5grTyZVa6SynyeSyMh1rsE89nIa09zO");
				}
				if (Headers != null)
				{
					try
					{
						foreach (KeyValuePair<string, string> keyValuePair in Headers)
						{
							httpWebRequest.Headers.Add(keyValuePair.Key, keyValuePair.Value);
						}
					}
					finally
					{
						Dictionary<string, string>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
				}
				httpWebRequest.ContentType = ContentType;
				httpWebRequest.Timeout = Timeout;
				httpWebRequest.KeepAlive = false;
				httpWebRequest.UserAgent = "PCL2/2.2.9.50 Mozilla/5.0 AppleWebKit/537.36 Chrome/63.0.3239.132 Safari/537.36";
				httpWebRequest.Referer = "http://" + Conversions.ToString(246) + ".pcl2.server/";
				if (Operators.CompareString(Method, "POST", true) == 0 || Operators.CompareString(Method, "PUT", true) == 0)
				{
					httpWebRequest.ContentLength = (long)array.Length;
					stream = httpWebRequest.GetRequestStream();
					stream.WriteTimeout = Timeout;
					stream.ReadTimeout = Timeout;
					stream.Write(array, 0, array.Length);
					stream.Close();
				}
				webResponse = httpWebRequest.GetResponse();
				stream = webResponse.GetResponseStream();
				stream.WriteTimeout = Timeout;
				stream.ReadTimeout = Timeout;
				using (StreamReader streamReader = new StreamReader(stream))
				{
					result = streamReader.ReadToEnd();
				}
			}
			catch (ThreadInterruptedException ex)
			{
				throw;
			}
			catch (WebException ex2)
			{
				if (ex2.Status == WebExceptionStatus.Timeout)
				{
					throw new TimeoutException("连接服务器超时，请检查你的网络环境是否良好（" + Url + "）", ex2);
				}
				string text = "";
				try
				{
					if (ex2.Response == null)
					{
						ProjectData.ClearProjectError();
					}
					else
					{
						stream = ex2.Response.GetResponseStream();
						stream.WriteTimeout = Timeout;
						stream.ReadTimeout = Timeout;
						using (StreamReader streamReader2 = new StreamReader(stream))
						{
							text = streamReader2.ReadToEnd();
						}
					}
				}
				catch (Exception ex3)
				{
				}
				throw new WebException(string.Concat(new string[]
				{
					"网络请求失败（",
					Url,
					"，",
					ex2.Message,
					"）",
					string.IsNullOrEmpty(text) ? "" : ("\r\n" + text)
				}), ex2);
			}
			catch (Exception innerException)
			{
				throw new WebException("网络请求失败（" + Url + "）", innerException);
			}
			finally
			{
				if (stream != null)
				{
					stream.Dispose();
				}
				if (webResponse != null)
				{
					webResponse.Dispose();
				}
			}
			return result;
		}

		// Token: 0x06000898 RID: 2200 RVA: 0x0003A9DC File Offset: 0x00038BDC
		public static bool HasDownloadingTask(bool IgnoreCustomDownload = false)
		{
			object loaderTaskbarLock = ModLoader.LoaderTaskbarLock;
			ObjectFlowControl.CheckForSyncLockOnValueType(loaderTaskbarLock);
			lock (loaderTaskbarLock)
			{
				try
				{
					foreach (ModLoader.LoaderBase loaderBase in ModLoader.LoaderTaskbar)
					{
						if (loaderBase.Show && loaderBase.State == ModBase.LoadState.Loading && (!IgnoreCustomDownload || !loaderBase.Name.ToString().Contains("自定义下载")))
						{
							return true;
						}
					}
				}
				finally
				{
					List<ModLoader.LoaderBase>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
			}
			return false;
		}

		// Token: 0x040003E3 RID: 995
		public static int prototypeTag;

		// Token: 0x040003E4 RID: 996
		public static long _IssuerTag = 1048576L;

		// Token: 0x040003E5 RID: 997
		public static long requestTag = -1L;

		// Token: 0x040003E6 RID: 998
		public static long m_AccountTag = -1L;

		// Token: 0x040003E7 RID: 999
		private static readonly object _StateTag = RuntimeHelpers.GetObjectValue(new object());

		// Token: 0x040003E8 RID: 1000
		private static long proccesorTag;

		// Token: 0x040003E9 RID: 1001
		public static int m_ParameterTag = 0;

		// Token: 0x040003EA RID: 1002
		private static readonly object authenticationTag = RuntimeHelpers.GetObjectValue(new object());

		// Token: 0x040003EB RID: 1003
		public static ModNet.NetManagerClass reponseTag = new ModNet.NetManagerClass();

		// Token: 0x020000D3 RID: 211
		public class NetSource
		{
			// Token: 0x0600089A RID: 2202 RVA: 0x000064F1 File Offset: 0x000046F1
			public override string ToString()
			{
				return this._ExporterState;
			}

			// Token: 0x040003EC RID: 1004
			public int m_MerchantState;

			// Token: 0x040003ED RID: 1005
			public string _ExporterState;

			// Token: 0x040003EE RID: 1006
			public int m_QueueState;

			// Token: 0x040003EF RID: 1007
			public Exception m_GlobalState;

			// Token: 0x040003F0 RID: 1008
			public ModNet.NetThread _ListState;

			// Token: 0x040003F1 RID: 1009
			public bool methodState;
		}

		// Token: 0x020000D4 RID: 212
		public enum NetState
		{
			// Token: 0x040003F3 RID: 1011
			WaitForCheck = -1,
			// Token: 0x040003F4 RID: 1012
			WaitForDownload,
			// Token: 0x040003F5 RID: 1013
			Connect,
			// Token: 0x040003F6 RID: 1014
			Get,
			// Token: 0x040003F7 RID: 1015
			Download,
			// Token: 0x040003F8 RID: 1016
			Merge,
			// Token: 0x040003F9 RID: 1017
			WaitForCopy,
			// Token: 0x040003FA RID: 1018
			Finish,
			// Token: 0x040003FB RID: 1019
			Error
		}

		// Token: 0x020000D5 RID: 213
		public enum NetPreDownloadBehaviour
		{
			// Token: 0x040003FD RID: 1021
			HintWhileExists,
			// Token: 0x040003FE RID: 1022
			ExitWhileExistsOrDownloading,
			// Token: 0x040003FF RID: 1023
			IgnoreCheck
		}

		// Token: 0x020000D6 RID: 214
		public class NetThread : IEnumerable<ModNet.NetThread>
		{
			// Token: 0x0600089C RID: 2204 RVA: 0x0003AA8C File Offset: 0x00038C8C
			public NetThread()
			{
				this._ProxyState = 0L;
				this.m_ClassState = ModBase.GetTimeTick();
				this._RegistryState = 0L;
				this.producerState = 0L;
				this.candidateState = ModBase.GetTimeTick();
				this.setterState = -1L;
				this.mappingState = ModNet.NetState.WaitForDownload;
			}

			// Token: 0x0600089D RID: 2205 RVA: 0x000064F9 File Offset: 0x000046F9
			private IEnumerable<ModNet.NetThread> SortComparator()
			{
				ModNet.NetThread.VB$StateMachine_5_get_Next vb$StateMachine_5_get_Next = new ModNet.NetThread.VB$StateMachine_5_get_Next(-2);
				vb$StateMachine_5_get_Next.$VB$Me = this;
				return vb$StateMachine_5_get_Next;
			}

			// Token: 0x0600089E RID: 2206 RVA: 0x00006509 File Offset: 0x00004709
			public IEnumerator<ModNet.NetThread> GetEnumerator()
			{
				return this.SortComparator().GetEnumerator();
			}

			// Token: 0x0600089F RID: 2207 RVA: 0x00006509 File Offset: 0x00004709
			IEnumerator IEnumerable.IEnumerable_GetEnumerator()
			{
				return this.SortComparator().GetEnumerator();
			}

			// Token: 0x060008A0 RID: 2208 RVA: 0x00006516 File Offset: 0x00004716
			public bool PrintComparator()
			{
				return this._ImporterState == 0L && this.annotationState._ComparatorProccesor == -2L;
			}

			// Token: 0x060008A1 RID: 2209 RVA: 0x0003AAFC File Offset: 0x00038CFC
			public long CalculateComparator()
			{
				object mockProccesor = this.annotationState.m_MockProccesor;
				ObjectFlowControl.CheckForSyncLockOnValueType(mockProccesor);
				checked
				{
					long result;
					lock (mockProccesor)
					{
						if (this._RefState == null)
						{
							if (this.annotationState.m_PrototypeProccesor)
							{
								result = 1073741824L;
							}
							else
							{
								result = this.annotationState._ComparatorProccesor - 1L;
							}
						}
						else
						{
							result = this._RefState._ImporterState - 1L;
						}
					}
					return result;
				}
			}

			// Token: 0x060008A2 RID: 2210 RVA: 0x00006538 File Offset: 0x00004738
			public long ReadComparator()
			{
				return checked(this.CalculateComparator() + 1L - (this._ImporterState + this._ProxyState));
			}

			// Token: 0x060008A3 RID: 2211 RVA: 0x0003AB94 File Offset: 0x00038D94
			public long CollectComparator()
			{
				checked
				{
					if (ModBase.GetTimeTick() - this.m_ClassState > 200L)
					{
						long num = ModBase.GetTimeTick() - this.m_ClassState;
						this.producerState = (long)Math.Round((double)(this._ProxyState - this._RegistryState) / ((double)num / 1000.0));
						this._RegistryState = this._ProxyState;
						ref long ptr = ref this.m_ClassState;
						this.m_ClassState = ptr + num;
					}
					return this.producerState;
				}
			}

			// Token: 0x060008A4 RID: 2212 RVA: 0x00006558 File Offset: 0x00004758
			public bool MoveComparator()
			{
				return this.mappingState == ModNet.NetState.Finish || this.mappingState == ModNet.NetState.Error;
			}

			// Token: 0x04000400 RID: 1024
			public ModNet.NetFile annotationState;

			// Token: 0x04000401 RID: 1025
			public Thread m_InterceptorState;

			// Token: 0x04000402 RID: 1026
			public ModNet.NetThread _RefState;

			// Token: 0x04000403 RID: 1027
			public int m_ServerState;

			// Token: 0x04000404 RID: 1028
			public string m_ServiceState;

			// Token: 0x04000405 RID: 1029
			public long _ImporterState;

			// Token: 0x04000406 RID: 1030
			public long _ProxyState;

			// Token: 0x04000407 RID: 1031
			private long m_ClassState;

			// Token: 0x04000408 RID: 1032
			private long _RegistryState;

			// Token: 0x04000409 RID: 1033
			private long producerState;

			// Token: 0x0400040A RID: 1034
			public long candidateState;

			// Token: 0x0400040B RID: 1035
			public long setterState;

			// Token: 0x0400040C RID: 1036
			public ModNet.NetState mappingState;

			// Token: 0x0400040D RID: 1037
			public ModNet.NetSource Source;
		}

		// Token: 0x020000D8 RID: 216
		public class NetFile
		{
			// Token: 0x060008AF RID: 2223 RVA: 0x0003ACC0 File Offset: 0x00038EC0
			private ModNet.NetSource GetSource(int Id = 0)
			{
				if (Id >= this.messageState.Count<ModNet.NetSource>() || Id < 0)
				{
					Id = 0;
				}
				object adapterProccesor = this._AdapterProccesor;
				ObjectFlowControl.CheckForSyncLockOnValueType(adapterProccesor);
				checked
				{
					ModNet.NetSource result;
					lock (adapterProccesor)
					{
						if (!this.IsSourceFailed(false))
						{
							ModNet.NetSource netSource = this.messageState[Id];
							while (netSource.methodState)
							{
								Id++;
								if (Id >= this.messageState.Count<ModNet.NetSource>())
								{
									Id = 0;
								}
								netSource = this.messageState[Id];
							}
							result = netSource;
						}
						else if (this.m_ProcState.Count > 0)
						{
							result = this.m_ProcState[0];
						}
						else
						{
							result = null;
						}
					}
					return result;
				}
			}

			// Token: 0x060008B0 RID: 2224 RVA: 0x0003AD74 File Offset: 0x00038F74
			public bool IsSourceFailed(bool AllowOnceSource = true)
			{
				checked
				{
					bool result;
					if (AllowOnceSource && this.m_ProcState.Count > 0)
					{
						result = false;
					}
					else
					{
						object adapterProccesor = this._AdapterProccesor;
						ObjectFlowControl.CheckForSyncLockOnValueType(adapterProccesor);
						lock (adapterProccesor)
						{
							ModNet.NetSource[] array = this.messageState;
							for (int i = 0; i < array.Length; i++)
							{
								if (!array[i].methodState)
								{
									return false;
								}
							}
						}
						result = true;
					}
					return result;
				}
			}

			// Token: 0x060008B1 RID: 2225 RVA: 0x000065A0 File Offset: 0x000047A0
			public bool ConnectComparator()
			{
				return this.m_PrototypeProccesor || this._ComparatorProccesor < 262144L;
			}

			// Token: 0x060008B2 RID: 2226 RVA: 0x0003ADF4 File Offset: 0x00038FF4
			public long GetComparator()
			{
				checked
				{
					if (ModBase.GetTimeTick() - this.m_ProccesorProccesor > 200L)
					{
						long num = ModBase.GetTimeTick() - this.m_ProccesorProccesor;
						this._AuthenticationProccesor = (long)Math.Round((double)(this.m_RequestProccesor - this.parameterProccesor) / ((double)num / 1000.0));
						this.parameterProccesor = this.m_RequestProccesor;
						ref long ptr = ref this.m_ProccesorProccesor;
						this.m_ProccesorProccesor = ptr + num;
					}
					return this._AuthenticationProccesor;
				}
			}

			// Token: 0x1700015A RID: 346
			// (get) Token: 0x060008B3 RID: 2227 RVA: 0x0003AE6C File Offset: 0x0003906C
			public double Progress
			{
				get
				{
					double result;
					switch (this._RepositoryProccesor)
					{
					case ModNet.NetState.WaitForCheck:
						result = 0.0;
						break;
					case ModNet.NetState.WaitForDownload:
						result = 0.01;
						break;
					case ModNet.NetState.Connect:
						result = 0.02;
						break;
					case ModNet.NetState.Get:
						result = 0.04;
						break;
					case ModNet.NetState.Download:
					{
						double num = this.m_PrototypeProccesor ? 0.5 : ((double)this.m_RequestProccesor / (double)Math.Max(this._ComparatorProccesor, 1L));
						num = 1.0 - Math.Pow(1.0 - num, 0.9);
						result = num * 0.94 + 0.05;
						break;
					}
					case ModNet.NetState.Merge:
						result = 0.99;
						break;
					case ModNet.NetState.WaitForCopy:
						result = 0.2;
						break;
					case ModNet.NetState.Finish:
					case ModNet.NetState.Error:
						result = 1.0;
						break;
					default:
						throw new ArgumentOutOfRangeException("文件状态未知：" + Conversions.ToString((int)this._RepositoryProccesor));
					}
					return result;
				}
			}

			// Token: 0x060008B4 RID: 2228 RVA: 0x0003AF94 File Offset: 0x00039194
			private int RateComparator()
			{
				object obj = this.definitionProccesor;
				ObjectFlowControl.CheckForSyncLockOnValueType(obj);
				int result;
				lock (obj)
				{
					result = checked((int)Math.Round((this.m_ContainerProccesor == 0) ? -1.0 : ((double)this._CodeProccesor / (double)this.m_ContainerProccesor)));
				}
				return result;
			}

			// Token: 0x060008B5 RID: 2229 RVA: 0x0003B000 File Offset: 0x00039200
			public override bool Equals(object obj)
			{
				ModNet.NetFile netFile = obj as ModNet.NetFile;
				return netFile != null && this._SystemProccesor == netFile._SystemProccesor;
			}

			// Token: 0x060008B6 RID: 2230 RVA: 0x0003B028 File Offset: 0x00039228
			public NetFile(string[] Urls, string LocalPath, ModBase.FileChecker Check = null)
			{
				this.m_DispatcherState = new List<ModNet.LoaderDownload>();
				this.m_StatusState = 0;
				this.m_ProcState = new List<ModNet.NetSource>();
				this.m_ModelProccesor = null;
				this.m_WrapperProccesor = null;
				this._RepositoryProccesor = ModNet.NetState.WaitForCheck;
				this.resolverProccesor = new List<Exception>();
				this._ComparatorProccesor = -2L;
				this.m_PrototypeProccesor = false;
				this.m_RequestProccesor = 0L;
				this.accountProccesor = RuntimeHelpers.GetObjectValue(new object());
				this.m_ProccesorProccesor = ModBase.GetTimeTick();
				this.parameterProccesor = 0L;
				this._AuthenticationProccesor = 0L;
				this._ReponseProccesor = false;
				this.m_ContainerProccesor = 0;
				this._CodeProccesor = 0L;
				this._TokenizerProccesor = ModBase.RandomInteger(0, 999999);
				this.definitionProccesor = RuntimeHelpers.GetObjectValue(new object());
				this._ParamsProccesor = RuntimeHelpers.GetObjectValue(new object());
				this.m_MockProccesor = RuntimeHelpers.GetObjectValue(new object());
				this._AdapterProccesor = RuntimeHelpers.GetObjectValue(new object());
				this.initializerProccesor = RuntimeHelpers.GetObjectValue(new object());
				this._SystemProccesor = ModBase.GetUuid();
				List<ModNet.NetSource> list = new List<ModNet.NetSource>();
				int num = 0;
				Urls = ModBase.ArrayNoDouble<string>(Urls, null);
				checked
				{
					foreach (string text in Urls)
					{
						list.Add(new ModNet.NetSource
						{
							m_QueueState = 0,
							_ExporterState = Conversions.ToString(ModBase.GetCdnTypeA(text.Replace("\r", "").Replace("\n", "").Trim())),
							m_MerchantState = num,
							methodState = false,
							m_GlobalState = null
						});
						num++;
					}
					this.messageState = list.ToArray();
					this.m_ModelProccesor = LocalPath;
					this.stateProccesor = Check;
					this.m_WrapperProccesor = ModBase.GetFileNameFromPath(LocalPath);
				}
			}

			// Token: 0x060008B7 RID: 2231 RVA: 0x0003B20C File Offset: 0x0003940C
			public bool TryBeginThread()
			{
				checked
				{
					bool result;
					try
					{
						if (ModNet.m_ParameterTag < ModNet.prototypeTag && !this.IsSourceFailed(true))
						{
							if (!this.ConnectComparator() || this._TagProccesor == null || this._TagProccesor.mappingState == ModNet.NetState.Error)
							{
								if (this._RepositoryProccesor < ModNet.NetState.Merge)
								{
									if (this._RepositoryProccesor != ModNet.NetState.WaitForCheck)
									{
										object paramsProccesor = this._ParamsProccesor;
										ObjectFlowControl.CheckForSyncLockOnValueType(paramsProccesor);
										lock (paramsProccesor)
										{
											if (this._RepositoryProccesor < ModNet.NetState.Connect)
											{
												this._RepositoryProccesor = ModNet.NetState.Connect;
											}
										}
										ModNet.NetSource netSource = null;
										object mockProccesor = this.m_MockProccesor;
										ObjectFlowControl.CheckForSyncLockOnValueType(mockProccesor);
										Thread thread;
										ModNet.NetThread netThread4;
										lock (mockProccesor)
										{
											if (!this.ConnectComparator())
											{
												if (!this.IsSourceFailed(false))
												{
													goto IL_16E;
												}
												if (this.m_ProcState[0]._ListState != null && this.m_ProcState[0]._ListState.mappingState != ModNet.NetState.Error)
												{
													return false;
												}
											}
											this.issuerProccesor = null;
											this._TagProccesor = null;
											ModNet.NetManagerClass reponseTag;
											(reponseTag = ModNet.reponseTag).InterruptComparator(reponseTag.RestartComparator() - this.m_RequestProccesor);
											object obj = this.accountProccesor;
											ObjectFlowControl.CheckForSyncLockOnValueType(obj);
											lock (obj)
											{
												this.m_RequestProccesor = 0L;
											}
											this.parameterProccesor = 0L;
											this._RepositoryProccesor = ModNet.NetState.Get;
											IL_16E:
											long num;
											if (this._TagProccesor == null)
											{
												num = 0L;
												netSource = this.GetSource(this.m_StatusState);
												if (netSource == null)
												{
													throw new Exception("无可用源，请反馈此问题。");
												}
												this.m_StatusState = netSource.m_MerchantState + 1;
											}
											else
											{
												try
												{
													foreach (ModNet.NetThread netThread in this._TagProccesor)
													{
														if (netThread.mappingState == ModNet.NetState.Error && netThread.ReadComparator() > 0L)
														{
															num = netThread._ImporterState + netThread._ProxyState;
															netSource = this.GetSource(netThread.Source.m_MerchantState + 1);
															goto IL_2F5;
														}
													}
												}
												finally
												{
													IEnumerator<ModNet.NetThread> enumerator;
													if (enumerator != null)
													{
														enumerator.Dispose();
													}
												}
												string exporterState = this.GetSource(0)._ExporterState;
												if (exporterState.Contains("pcl2-server"))
												{
													return false;
												}
												long num2 = exporterState.Contains("download.mcbbs.net") ? 1310720L : 262144L;
												ModNet.NetThread netThread2 = this._TagProccesor;
												try
												{
													foreach (ModNet.NetThread netThread3 in this._TagProccesor)
													{
														if (netThread3.ReadComparator() > netThread2.ReadComparator())
														{
															netThread2 = netThread3;
														}
													}
												}
												finally
												{
													IEnumerator<ModNet.NetThread> enumerator2;
													if (enumerator2 != null)
													{
														enumerator2.Dispose();
													}
												}
												if (netThread2 == null || netThread2.ReadComparator() < num2)
												{
													return false;
												}
												num = (long)Math.Round(unchecked((double)netThread2.CalculateComparator() - (double)netThread2.ReadComparator() * 0.4));
												netSource = this.GetSource(0);
											}
											IL_2F5:
											if ((num > this._ComparatorProccesor && this._ComparatorProccesor >= 0L && !this.m_PrototypeProccesor) || num < 0L || Information.IsNothing(netSource))
											{
												return false;
											}
											int uuid = ModBase.GetUuid();
											object obj2 = this.initializerProccesor;
											ObjectFlowControl.CheckForSyncLockOnValueType(obj2);
											lock (obj2)
											{
												if (this.m_DispatcherState.Count == 0)
												{
													return false;
												}
												thread = new Thread(delegate(object a0)
												{
													this.Thread((ModNet.NetThread)a0);
												})
												{
													Name = string.Concat(new string[]
													{
														"NetTask ",
														Conversions.ToString(this.m_DispatcherState[0].Uuid),
														"/",
														Conversions.ToString(this._SystemProccesor),
														" Download ",
														Conversions.ToString(uuid),
														"#"
													}),
													Priority = ThreadPriority.BelowNormal
												};
											}
											netThread4 = new ModNet.NetThread
											{
												m_ServerState = uuid,
												_ImporterState = num,
												m_InterceptorState = thread,
												Source = netSource,
												annotationState = this,
												mappingState = ModNet.NetState.WaitForDownload
											};
											if (!netThread4.PrintComparator() && this._TagProccesor != null)
											{
												ModNet.NetThread netThread5 = this._TagProccesor;
												while (netThread5.CalculateComparator() <= num)
												{
													netThread5 = netThread5._RefState;
												}
												netThread4._RefState = netThread5._RefState;
												netThread5._RefState = netThread4;
											}
											else
											{
												this._TagProccesor = netThread4;
											}
										}
										object authenticationTag = ModNet.authenticationTag;
										ObjectFlowControl.CheckForSyncLockOnValueType(authenticationTag);
										lock (authenticationTag)
										{
											ModNet.m_ParameterTag++;
										}
										object adapterProccesor = this._AdapterProccesor;
										ObjectFlowControl.CheckForSyncLockOnValueType(adapterProccesor);
										lock (adapterProccesor)
										{
											if (this.IsSourceFailed(false))
											{
												this.m_ProcState[0]._ListState = netThread4;
											}
										}
										thread.Start(netThread4);
										return true;
									}
								}
								return false;
							}
						}
						result = false;
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "尝试开始下载线程失败（" + (this.m_WrapperProccesor ?? "Nothing") + "）", ModBase.LogLevel.Hint, "出现错误");
						result = false;
					}
					return result;
				}
			}

			// Token: 0x060008B8 RID: 2232 RVA: 0x0003B858 File Offset: 0x00039A58
			private void Thread(ModNet.NetThread Info)
			{
				if (ModBase._EventState || Info._ImporterState == 0L)
				{
					ModBase.Log(string.Concat(new string[]
					{
						"[Download] ",
						this.m_WrapperProccesor,
						" ",
						Conversions.ToString(Info.m_ServerState),
						"#：开始，起始点 ",
						Conversions.ToString(Info._ImporterState),
						"，",
						Info.Source._ExporterState
					}), ModBase.LogLevel.Normal, "出现错误");
				}
				Stream stream = null;
				checked
				{
					int num = Math.Min(Math.Max(this.RateComparator(), 6000) * (1 + Info.Source.m_QueueState), 30000);
					Info.mappingState = ModNet.NetState.Connect;
					try
					{
						int num2 = 0;
						if (!this.m_ProcState.Contains(Info.Source) || Info.Equals(Info.Source._ListState))
						{
							HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(Info.Source._ExporterState);
							if (Info.Source._ExporterState.StartsWith("https", StringComparison.OrdinalIgnoreCase))
							{
								httpWebRequest.ProtocolVersion = HttpVersion.Version10;
							}
							httpWebRequest.Timeout = num;
							httpWebRequest.UserAgent = "PCL2/2.2.9.50 Mozilla/5.0 AppleWebKit/537.36 Chrome/63.0.3239.132 Safari/537.36";
							httpWebRequest.AddRange(Info._ImporterState);
							httpWebRequest.Referer = "http://" + Conversions.ToString(246) + ".pcl2.server/";
							if (Info.Source._ExporterState.Contains("api.curseforge.com"))
							{
								httpWebRequest.Headers.Add("x-api-key", "$2a$10$7WWV1WELcwX8Xp7d68MHs.5grTyZVa6SynyeSyMh1rsE89nIa09zO");
							}
							using (HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse())
							{
								long contentLength = httpWebResponse.ContentLength;
								if (contentLength == -1L)
								{
									if (this._ComparatorProccesor > 1L)
									{
										ModBase.Log(string.Concat(new string[]
										{
											"[Download] ",
											this.m_WrapperProccesor,
											" ",
											Conversions.ToString(Info.m_ServerState),
											"#：文件大小未知，但已从其他下载源获取，不作处理"
										}), ModBase.LogLevel.Normal, "出现错误");
									}
									else
									{
										this._ComparatorProccesor = -1L;
										this.m_PrototypeProccesor = true;
										ModBase.Log(string.Concat(new string[]
										{
											"[Download] ",
											this.m_WrapperProccesor,
											" ",
											Conversions.ToString(Info.m_ServerState),
											"#：文件大小未知"
										}), ModBase.LogLevel.Normal, "出现错误");
									}
								}
								else
								{
									if (contentLength < 0L)
									{
										throw new Exception("获取片大小失败，结果为 " + Conversions.ToString(contentLength) + "。");
									}
									if (Info.PrintComparator())
									{
										if (this.stateProccesor != null)
										{
											if (contentLength < this.stateProccesor._GlobalParameter && this.stateProccesor._GlobalParameter > 0L)
											{
												throw new Exception(string.Concat(new string[]
												{
													"文件大小不足，获取结果为 ",
													Conversions.ToString(contentLength),
													"，要求至少为 ",
													Conversions.ToString(this.stateProccesor._GlobalParameter),
													"。"
												}));
											}
											if (contentLength != this.stateProccesor.queueParameter && this.stateProccesor.queueParameter > 0L)
											{
												throw new Exception(string.Concat(new string[]
												{
													"文件大小不一致，获取结果为 ",
													Conversions.ToString(contentLength),
													"，要求必须为 ",
													Conversions.ToString(this.stateProccesor.queueParameter),
													"。"
												}));
											}
										}
										this._ComparatorProccesor = contentLength;
										this.m_PrototypeProccesor = false;
										ModBase.Log(string.Concat(new string[]
										{
											"[Download] ",
											this.m_WrapperProccesor,
											"：文件大小 ",
											Conversions.ToString(contentLength),
											" B（",
											ModBase.GetString(contentLength),
											"）"
										}), ModBase.LogLevel.Normal, "出现错误");
										if (contentLength > 52428800L)
										{
											foreach (DriveInfo driveInfo in DriveInfo.GetDrives())
											{
												string text = driveInfo.Name.First<char>().ToString();
												double num3 = unchecked((ModBase.attributeState.StartsWith(text) ? ((double)contentLength * 1.1) : 0.0) + (double)(this.m_ModelProccesor.StartsWith(text) ? checked(contentLength + 5242880L) : 0L));
												if ((double)driveInfo.TotalFreeSpace < num3)
												{
													throw new Exception(string.Concat(new string[]
													{
														text,
														" 盘空间不足，无法进行下载。\r\n需要至少 ",
														ModBase.GetString((long)Math.Round(num3)),
														" 空间，但当前仅剩余 ",
														ModBase.GetString(driveInfo.TotalFreeSpace),
														"。",
														ModBase.attributeState.StartsWith(text) ? "\r\n\r\n下载时需要与文件同等大小的空间存放缓存，你可以在设置中调整缓存文件夹的位置。" : ""
													}));
												}
											}
										}
									}
									else
									{
										if (this._ComparatorProccesor < 0L)
										{
											throw new Exception("非首线程运行时，尚未获取文件大小。");
										}
										if (Info._ImporterState > 0L && contentLength == this._ComparatorProccesor)
										{
											object adapterProccesor = this._AdapterProccesor;
											ObjectFlowControl.CheckForSyncLockOnValueType(adapterProccesor);
											lock (adapterProccesor)
											{
												if (this.m_ProcState.Contains(Info.Source))
												{
													goto IL_ACF;
												}
												this.m_ProcState.Add(Info.Source);
											}
											throw new WebException("该下载源不支持断点续传。");
										}
										if (this._ComparatorProccesor - Info._ImporterState != contentLength)
										{
											throw new WebException(string.Concat(new string[]
											{
												"获取到的片大小不一致：线程结果为 ",
												Conversions.ToString(contentLength),
												" B，任务结果为 ",
												Conversions.ToString(this._ComparatorProccesor),
												"B，起点为 ",
												Conversions.ToString(Info._ImporterState),
												"B。"
											}));
										}
									}
								}
								Info.mappingState = ModNet.NetState.Get;
								object paramsProccesor = this._ParamsProccesor;
								ObjectFlowControl.CheckForSyncLockOnValueType(paramsProccesor);
								lock (paramsProccesor)
								{
									if (this._RepositoryProccesor < ModNet.NetState.Get)
									{
										this._RepositoryProccesor = ModNet.NetState.Get;
									}
								}
								if (this.ConnectComparator())
								{
									Info.m_ServiceState = null;
									this.issuerProccesor = new List<byte>();
								}
								else
								{
									Info.m_ServiceState = string.Concat(new string[]
									{
										ModBase.attributeState,
										"Download\\",
										Conversions.ToString(this._SystemProccesor),
										"_",
										Conversions.ToString(Info.m_ServerState),
										"_",
										Conversions.ToString(ModBase.RandomInteger(0, 999999)),
										".tmp"
									});
									stream = new FileStream(Info.m_ServiceState, FileMode.Create, FileAccess.Write, FileShare.Read);
								}
								using (Stream responseStream = httpWebResponse.GetResponseStream())
								{
									responseStream.ReadTimeout = num;
									if (Conversions.ToBoolean(ModBase._ParamsState.Get("SystemDebugDelay", null)))
									{
										System.Threading.Thread.Sleep(ModBase.RandomInteger(50, 3000));
									}
									byte[] array = new byte[16385];
									num2 = responseStream.Read(array, 0, 16384);
									int num4;
									long num5;
									for (;;)
									{
										if (!this.m_PrototypeProccesor)
										{
											if (Info.ReadComparator() <= 0L)
											{
												break;
											}
										}
										if (num2 <= 0 || ModBase.m_SystemState || this._RepositoryProccesor >= ModNet.NetState.Merge)
										{
											break;
										}
										if (Info.Source.methodState && !Info.Equals(Info.Source._ListState))
										{
											break;
										}
										while (ModNet.requestTag > 0L && ModNet.m_AccountTag <= 0L)
										{
											System.Threading.Thread.Sleep(16);
										}
										num4 = (int)(unchecked(this.m_PrototypeProccesor ? ((long)num2) : Math.Min((long)num2, Info.ReadComparator())));
										object stateTag = ModNet._StateTag;
										ObjectFlowControl.CheckForSyncLockOnValueType(stateTag);
										lock (stateTag)
										{
											if (ModNet.requestTag > 0L)
											{
												ModNet.m_AccountTag -= unchecked((long)num4);
											}
										}
										num5 = ModBase.GetTimeTick() - Info.setterState;
										if (num5 > 1000000L)
										{
											num5 = 0L;
										}
										if (num4 > 0)
										{
											long ptr2;
											if (Info._ProxyState == 0L)
											{
												Info.mappingState = ModNet.NetState.Download;
												object paramsProccesor2 = this._ParamsProccesor;
												ObjectFlowControl.CheckForSyncLockOnValueType(paramsProccesor2);
												lock (paramsProccesor2)
												{
													if (this._RepositoryProccesor < ModNet.NetState.Download)
													{
														this._RepositoryProccesor = ModNet.NetState.Download;
													}
												}
												object obj = this.definitionProccesor;
												ObjectFlowControl.CheckForSyncLockOnValueType(obj);
												lock (obj)
												{
													ref int ptr = ref this.m_ContainerProccesor;
													this.m_ContainerProccesor = ptr + 1;
													ptr2 = ref this._CodeProccesor;
													this._CodeProccesor = ptr2 + (ModBase.GetTimeTick() - Info.candidateState);
												}
											}
											object obj2 = this.definitionProccesor;
											ObjectFlowControl.CheckForSyncLockOnValueType(obj2);
											lock (obj2)
											{
												Info.Source.m_QueueState = 0;
												object obj3 = this.initializerProccesor;
												ObjectFlowControl.CheckForSyncLockOnValueType(obj3);
												lock (obj3)
												{
													try
													{
														foreach (ModNet.LoaderDownload loaderDownload in this.m_DispatcherState)
														{
															loaderDownload.FailCount = 0;
														}
													}
													finally
													{
														List<ModNet.LoaderDownload>.Enumerator enumerator;
														((IDisposable)enumerator).Dispose();
													}
												}
											}
											ModNet.NetManagerClass reponseTag;
											(reponseTag = ModNet.reponseTag).InterruptComparator(reponseTag.RestartComparator() + unchecked((long)num4));
											object obj4 = this.accountProccesor;
											ObjectFlowControl.CheckForSyncLockOnValueType(obj4);
											lock (obj4)
											{
												ptr2 = ref this.m_RequestProccesor;
												this.m_RequestProccesor = ptr2 + unchecked((long)num4);
											}
											ptr2 = ref Info._ProxyState;
											Info._ProxyState = ptr2 + unchecked((long)num4);
											if (this.ConnectComparator())
											{
												if (array.Count<byte>() == num4)
												{
													this.issuerProccesor.AddRange(array);
												}
												else
												{
													this.issuerProccesor.AddRange(array.ToList<byte>().GetRange(0, num4));
												}
											}
											else
											{
												stream.Write(array, 0, num4);
											}
											if (num5 > 1000L && num5 > unchecked((long)num4))
											{
												goto IL_A6B;
											}
											Info.setterState = ModBase.GetTimeTick();
											if (Info.ReadComparator() == 0L && !this.m_PrototypeProccesor)
											{
												break;
											}
										}
										else if (Info.setterState > 0L && num5 > unchecked((long)num))
										{
											goto IL_AA8;
										}
										num2 = responseStream.Read(array, 0, 16384);
									}
									goto IL_AB3;
									IL_A6B:
									throw new TimeoutException(string.Concat(new string[]
									{
										"由于速度过慢断开链接，下载 ",
										Conversions.ToString(num4),
										" B，消耗 ",
										Conversions.ToString(num5),
										" ms。"
									}));
									IL_AA8:
									throw new TimeoutException("操作超时，无数据。");
									IL_AB3:;
								}
							}
						}
						IL_ACF:
						if (num2 == 0 && Info.ReadComparator() > 0L && !this.m_PrototypeProccesor)
						{
							throw new Exception("服务器无返回数据，但下载尚未完成");
						}
						if (this._RepositoryProccesor != ModNet.NetState.Error && !Info.Source.methodState && (Info.ReadComparator() <= 0L || this.m_PrototypeProccesor))
						{
							Info.mappingState = ModNet.NetState.Finish;
							if (ModBase._EventState)
							{
								ModBase.Log(string.Concat(new string[]
								{
									"[Download] ",
									this.m_WrapperProccesor,
									" ",
									Conversions.ToString(Info.m_ServerState),
									"#：完成，已下载 ",
									ModBase.GetString(Info._ProxyState)
								}), ModBase.LogLevel.Normal, "出现错误");
							}
						}
						else
						{
							Info.mappingState = ModNet.NetState.Error;
							ModBase.Log(string.Concat(new string[]
							{
								"[Download] ",
								this.m_WrapperProccesor,
								" ",
								Conversions.ToString(Info.m_ServerState),
								"#：中断"
							}), ModBase.LogLevel.Normal, "出现错误");
						}
					}
					catch (Exception ex)
					{
						object obj5 = this.definitionProccesor;
						ObjectFlowControl.CheckForSyncLockOnValueType(obj5);
						lock (obj5)
						{
							ModNet.NetSource source = Info.Source;
							ref int ptr = ref source.m_QueueState;
							source.m_QueueState = ptr + 1;
							object obj6 = this.initializerProccesor;
							ObjectFlowControl.CheckForSyncLockOnValueType(obj6);
							lock (obj6)
							{
								try
								{
									foreach (ModNet.LoaderDownload loaderDownload2 in this.m_DispatcherState)
									{
										ModNet.LoaderDownload loaderDownload3;
										(loaderDownload3 = loaderDownload2).FailCount = loaderDownload3.FailCount + 1;
									}
								}
								finally
								{
									List<ModNet.LoaderDownload>.Enumerator enumerator2;
									((IDisposable)enumerator2).Dispose();
								}
							}
						}
						string text2 = ModBase.GetString(ex, false, false).ToLower().Replace(" ", "");
						bool flag11 = text2.Contains("由于连接方在一段时间后没有正确答复或连接的主机没有反应") || text2.Contains("超时") || text2.Contains("timeout") || text2.Contains("timedout");
						ModBase.Log(string.Concat(new string[]
						{
							"[Download] ",
							this.m_WrapperProccesor,
							" ",
							Conversions.ToString(Info.m_ServerState),
							flag11 ? ("#：超时（" + Conversions.ToString(unchecked((double)num * 0.001)) + "s）") : ("#：出错，" + ModBase.GetString(ex, false, false))
						}), ModBase.LogLevel.Normal, "出现错误");
						Info.mappingState = ModNet.NetState.Error;
						Info.Source.m_GlobalState = ex;
						if (ex.Message.Contains("该下载源不支持") || ex.Message.Contains("(404)") || ex.Message.Contains("(403)") || ex.Message.Contains("(502)") || ex.Message.Contains("无返回数据") || ex.Message.Contains("空间不足") || ((double)Info.Source.m_QueueState >= ModBase.MathRange((double)ModNet.prototypeTag, 5.0, 40.0) && this.m_RequestProccesor < 1L) || Info.Source.m_QueueState > ModNet.prototypeTag)
						{
							bool flag12 = false;
							object adapterProccesor2 = this._AdapterProccesor;
							ObjectFlowControl.CheckForSyncLockOnValueType(adapterProccesor2);
							lock (adapterProccesor2)
							{
								if (Info.Source._ListState != null && Info.Source._ListState.Equals(Info))
								{
									this.m_ProcState.RemoveAt(0);
								}
								else if (Info.Source.methodState)
								{
									goto IL_EA8;
								}
								Info.Source.methodState = true;
								flag12 = true;
								IL_EA8:;
							}
							if (flag12)
							{
								ModBase.Log(string.Concat(new string[]
								{
									"[Download] ",
									this.m_WrapperProccesor,
									" ",
									Conversions.ToString(this._SystemProccesor),
									"#：下载源被禁用（",
									Conversions.ToString(Info.Source.m_MerchantState),
									"）：",
									Info.Source._ExporterState
								}), ModBase.LogLevel.Normal, "出现错误");
								ModBase.Log(ex, "下载源 " + Conversions.ToString(Info.Source.m_MerchantState) + " 已被禁用", (ex.Message.Contains("不支持断点续传") || ex.Message.Contains("404") || ex.Message.Contains("416")) ? ModBase.LogLevel.Developer : ModBase.LogLevel.Debug, "出现错误");
								if (this.IsSourceFailed(true))
								{
									ModBase.Log("[Download] 文件 " + this.m_WrapperProccesor + " 已无可用下载源", ModBase.LogLevel.Normal, "出现错误");
									Exception raiseEx = null;
									object adapterProccesor3 = this._AdapterProccesor;
									ObjectFlowControl.CheckForSyncLockOnValueType(adapterProccesor3);
									lock (adapterProccesor3)
									{
										foreach (ModNet.NetSource netSource in this.messageState)
										{
											ModBase.Log("[Download] 已禁用的下载源：" + netSource._ExporterState, ModBase.LogLevel.Normal, "出现错误");
											if (netSource.m_GlobalState != null)
											{
												raiseEx = netSource.m_GlobalState;
												ModBase.Log(netSource.m_GlobalState, "下载源禁用原因", ModBase.LogLevel.Developer, "出现错误");
											}
										}
									}
									this.Fail(raiseEx);
								}
								else if (ex.Message.Contains("空间不足"))
								{
									this.Fail(ex);
								}
							}
						}
						if (this._ComparatorProccesor == -2L)
						{
							object mockProccesor = this.m_MockProccesor;
							ObjectFlowControl.CheckForSyncLockOnValueType(mockProccesor);
							lock (mockProccesor)
							{
								this._TagProccesor = null;
							}
						}
					}
					finally
					{
						if (stream != null)
						{
							stream.Dispose();
						}
						object authenticationTag = ModNet.authenticationTag;
						ObjectFlowControl.CheckForSyncLockOnValueType(authenticationTag);
						lock (authenticationTag)
						{
							ModNet.m_ParameterTag--;
						}
						if (((this._ComparatorProccesor >= 0L && this.m_RequestProccesor >= this._ComparatorProccesor) || (this._ComparatorProccesor == -1L && this.m_RequestProccesor > 0L)) && this._RepositoryProccesor < ModNet.NetState.Merge)
						{
							this.Merge();
						}
					}
				}
			}

			// Token: 0x060008B9 RID: 2233 RVA: 0x0003CB9C File Offset: 0x0003AD9C
			private void Merge()
			{
				object paramsProccesor = this._ParamsProccesor;
				ObjectFlowControl.CheckForSyncLockOnValueType(paramsProccesor);
				lock (paramsProccesor)
				{
					if (this._RepositoryProccesor >= ModNet.NetState.Merge)
					{
						return;
					}
					this._RepositoryProccesor = ModNet.NetState.Merge;
				}
				int num = 0;
				Stream stream = null;
				BinaryWriter binaryWriter = null;
				checked
				{
					try
					{
						IL_40:
						object mockProccesor = this.m_MockProccesor;
						ObjectFlowControl.CheckForSyncLockOnValueType(mockProccesor);
						lock (mockProccesor)
						{
							if (ModBase._EventState)
							{
								ModBase.Log("[Download] " + this.m_WrapperProccesor + "：正在合并文件", ModBase.LogLevel.Normal, "出现错误");
							}
							if (File.Exists(this.m_ModelProccesor))
							{
								File.Delete(this.m_ModelProccesor);
							}
							new FileInfo(this.m_ModelProccesor).Directory.Create();
							if (this.ConnectComparator())
							{
								stream = new FileStream(this.m_ModelProccesor, FileMode.Create);
								binaryWriter = new BinaryWriter(stream);
								binaryWriter.Write(this.issuerProccesor.ToArray());
								binaryWriter.Dispose();
								binaryWriter = null;
								stream.Dispose();
								stream = null;
							}
							else if (this._TagProccesor._ProxyState == this.m_RequestProccesor)
							{
								File.Copy(this._TagProccesor.m_ServiceState, this.m_ModelProccesor, true);
							}
							else
							{
								stream = new FileStream(this.m_ModelProccesor, FileMode.Create);
								binaryWriter = new BinaryWriter(stream);
								try
								{
									foreach (ModNet.NetThread netThread in this._TagProccesor)
									{
										if (netThread._ProxyState != 0L)
										{
											using (FileStream fileStream = new FileStream(netThread.m_ServiceState, FileMode.Open, FileAccess.Read, FileShare.Read))
											{
												BinaryReader binaryReader = new BinaryReader(fileStream);
												binaryWriter.Write(binaryReader.ReadBytes((int)fileStream.Length));
												binaryReader.Close();
											}
										}
									}
								}
								finally
								{
									IEnumerator<ModNet.NetThread> enumerator;
									if (enumerator != null)
									{
										enumerator.Dispose();
									}
								}
								binaryWriter.Dispose();
								binaryWriter = null;
								stream.Dispose();
								stream = null;
							}
							if (!this.m_PrototypeProccesor && this.stateProccesor != null)
							{
								if (this.stateProccesor.queueParameter == -1L)
								{
									this.stateProccesor.queueParameter = this._ComparatorProccesor;
								}
								else if (this.stateProccesor.queueParameter != this._ComparatorProccesor)
								{
									throw new Exception(string.Concat(new string[]
									{
										"文件大小不一致：任务要求为 ",
										Conversions.ToString(this.stateProccesor.queueParameter),
										" B，网络获取结果为 ",
										Conversions.ToString(this._ComparatorProccesor),
										"B"
									}));
								}
							}
							ModBase.FileChecker fileChecker = this.stateProccesor;
							string text = (fileChecker != null) ? fileChecker.Check(this.m_ModelProccesor) : null;
							if (text != null)
							{
								ModBase.Log("[Download] File size detail of " + Conversions.ToString(this._SystemProccesor) + "# :", ModBase.LogLevel.Normal, "出现错误");
								try
								{
									foreach (ModNet.NetThread netThread2 in this._TagProccesor)
									{
										ModBase.Log(string.Concat(new string[]
										{
											"[Download] ",
											Conversions.ToString(netThread2.m_ServerState),
											"#, State ",
											ModBase.GetStringFromEnum(netThread2.mappingState),
											", Range ",
											Conversions.ToString(netThread2._ImporterState),
											"~",
											Conversions.ToString(netThread2._ImporterState + netThread2._ProxyState),
											", Left ",
											Conversions.ToString(netThread2.ReadComparator())
										}), ModBase.LogLevel.Normal, "出现错误");
									}
								}
								finally
								{
									IEnumerator<ModNet.NetThread> enumerator2;
									if (enumerator2 != null)
									{
										enumerator2.Dispose();
									}
								}
								throw new Exception(text);
							}
							if (this.ConnectComparator())
							{
								this.issuerProccesor = null;
							}
							else
							{
								try
								{
									foreach (ModNet.NetThread netThread3 in this._TagProccesor)
									{
										if (netThread3.m_ServiceState != null)
										{
											File.Delete(netThread3.m_ServiceState);
										}
									}
								}
								finally
								{
									IEnumerator<ModNet.NetThread> enumerator3;
									if (enumerator3 != null)
									{
										enumerator3.Dispose();
									}
								}
							}
							this.Finish(true);
						}
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "合并文件出错（" + this.m_WrapperProccesor + "）", ModBase.LogLevel.Debug, "出现错误");
						if (stream != null)
						{
							stream.Dispose();
							stream = null;
						}
						if (binaryWriter != null)
						{
							binaryWriter.Dispose();
							binaryWriter = null;
						}
						if (num <= 3)
						{
							System.Threading.Thread.Sleep(ModBase.RandomInteger(500, 1000));
							num++;
							goto IL_40;
						}
						this.Fail(ex);
					}
				}
			}

			// Token: 0x060008BA RID: 2234 RVA: 0x0003D0B0 File Offset: 0x0003B2B0
			private void Fail(Exception RaiseEx = null)
			{
				object paramsProccesor = this._ParamsProccesor;
				ObjectFlowControl.CheckForSyncLockOnValueType(paramsProccesor);
				lock (paramsProccesor)
				{
					if (this._RepositoryProccesor >= ModNet.NetState.Finish)
					{
						return;
					}
					if (RaiseEx != null)
					{
						this.resolverProccesor.Add(RaiseEx);
					}
					this._RepositoryProccesor = ModNet.NetState.Error;
				}
				try
				{
					if (File.Exists(this.m_ModelProccesor))
					{
						File.Delete(this.m_ModelProccesor);
					}
				}
				catch (Exception ex)
				{
				}
				object decoratorProccesor = ModNet.reponseTag.decoratorProccesor;
				ObjectFlowControl.CheckForSyncLockOnValueType(decoratorProccesor);
				lock (decoratorProccesor)
				{
					ModNet.NetManagerClass reponseTag = ModNet.reponseTag;
					ref int ptr = ref reponseTag._InfoProccesor;
					reponseTag._InfoProccesor = checked(ptr - 1);
					ModBase.Log("[Download] " + this.m_WrapperProccesor + "：已失败，剩余文件 " + Conversions.ToString(ModNet.reponseTag._InfoProccesor), ModBase.LogLevel.Normal, "出现错误");
				}
				try
				{
					foreach (ModNet.LoaderDownload loaderDownload in this.m_DispatcherState)
					{
						loaderDownload.OnFileFail(this);
					}
				}
				finally
				{
					List<ModNet.LoaderDownload>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
			}

			// Token: 0x060008BB RID: 2235 RVA: 0x0003D200 File Offset: 0x0003B400
			public void Abort(ModNet.LoaderDownload CausedByTask)
			{
				object obj = this.initializerProccesor;
				ObjectFlowControl.CheckForSyncLockOnValueType(obj);
				lock (obj)
				{
					this.m_DispatcherState.Remove(CausedByTask);
					if (this.m_DispatcherState.Count > 0)
					{
						return;
					}
				}
				object paramsProccesor = this._ParamsProccesor;
				ObjectFlowControl.CheckForSyncLockOnValueType(paramsProccesor);
				lock (paramsProccesor)
				{
					if (this._RepositoryProccesor >= ModNet.NetState.Finish)
					{
						return;
					}
					this._RepositoryProccesor = ModNet.NetState.Error;
				}
				object decoratorProccesor = ModNet.reponseTag.decoratorProccesor;
				ObjectFlowControl.CheckForSyncLockOnValueType(decoratorProccesor);
				lock (decoratorProccesor)
				{
					ModNet.NetManagerClass reponseTag = ModNet.reponseTag;
					ref int ptr = ref reponseTag._InfoProccesor;
					reponseTag._InfoProccesor = checked(ptr - 1);
					if (ModBase._EventState)
					{
						ModBase.Log("[Download] " + this.m_WrapperProccesor + "：已取消，剩余文件 " + Conversions.ToString(ModNet.reponseTag._InfoProccesor), ModBase.LogLevel.Normal, "出现错误");
					}
				}
			}

			// Token: 0x060008BC RID: 2236 RVA: 0x0003D328 File Offset: 0x0003B528
			public void Finish(bool PrintLog = true)
			{
				object paramsProccesor = this._ParamsProccesor;
				ObjectFlowControl.CheckForSyncLockOnValueType(paramsProccesor);
				lock (paramsProccesor)
				{
					if (this._RepositoryProccesor >= ModNet.NetState.Finish)
					{
						return;
					}
					this._RepositoryProccesor = ModNet.NetState.Finish;
				}
				object decoratorProccesor = ModNet.reponseTag.decoratorProccesor;
				ObjectFlowControl.CheckForSyncLockOnValueType(decoratorProccesor);
				lock (decoratorProccesor)
				{
					ModNet.NetManagerClass reponseTag = ModNet.reponseTag;
					ref int ptr = ref reponseTag._InfoProccesor;
					reponseTag._InfoProccesor = checked(ptr - 1);
					if (PrintLog)
					{
						ModBase.Log("[Download] " + this.m_WrapperProccesor + "：已完成，剩余文件 " + Conversions.ToString(ModNet.reponseTag._InfoProccesor), ModBase.LogLevel.Normal, "出现错误");
					}
				}
				object obj = this.initializerProccesor;
				ObjectFlowControl.CheckForSyncLockOnValueType(obj);
				lock (obj)
				{
					try
					{
						foreach (ModNet.LoaderDownload loaderDownload in this.m_DispatcherState)
						{
							loaderDownload.OnFileFinish(this);
						}
					}
					finally
					{
						List<ModNet.LoaderDownload>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
				}
			}

			// Token: 0x04000413 RID: 1043
			public List<ModNet.LoaderDownload> m_DispatcherState;

			// Token: 0x04000414 RID: 1044
			public ModNet.NetSource[] messageState;

			// Token: 0x04000415 RID: 1045
			private int m_StatusState;

			// Token: 0x04000416 RID: 1046
			public List<ModNet.NetSource> m_ProcState;

			// Token: 0x04000417 RID: 1047
			public string m_ModelProccesor;

			// Token: 0x04000418 RID: 1048
			public string m_WrapperProccesor;

			// Token: 0x04000419 RID: 1049
			public ModNet.NetState _RepositoryProccesor;

			// Token: 0x0400041A RID: 1050
			public List<Exception> resolverProccesor;

			// Token: 0x0400041B RID: 1051
			private ModNet.NetThread _TagProccesor;

			// Token: 0x0400041C RID: 1052
			public long _ComparatorProccesor;

			// Token: 0x0400041D RID: 1053
			public bool m_PrototypeProccesor;

			// Token: 0x0400041E RID: 1054
			private List<byte> issuerProccesor;

			// Token: 0x0400041F RID: 1055
			public long m_RequestProccesor;

			// Token: 0x04000420 RID: 1056
			private readonly object accountProccesor;

			// Token: 0x04000421 RID: 1057
			public ModBase.FileChecker stateProccesor;

			// Token: 0x04000422 RID: 1058
			private long m_ProccesorProccesor;

			// Token: 0x04000423 RID: 1059
			private long parameterProccesor;

			// Token: 0x04000424 RID: 1060
			private long _AuthenticationProccesor;

			// Token: 0x04000425 RID: 1061
			public bool _ReponseProccesor;

			// Token: 0x04000426 RID: 1062
			private int m_ContainerProccesor;

			// Token: 0x04000427 RID: 1063
			private long _CodeProccesor;

			// Token: 0x04000428 RID: 1064
			public readonly int _TokenizerProccesor;

			// Token: 0x04000429 RID: 1065
			public readonly object definitionProccesor;

			// Token: 0x0400042A RID: 1066
			public readonly object _ParamsProccesor;

			// Token: 0x0400042B RID: 1067
			public readonly object m_MockProccesor;

			// Token: 0x0400042C RID: 1068
			public readonly object _AdapterProccesor;

			// Token: 0x0400042D RID: 1069
			public readonly object initializerProccesor;

			// Token: 0x0400042E RID: 1070
			private readonly int _SystemProccesor;
		}

		// Token: 0x020000D9 RID: 217
		public class LoaderDownload : ModLoader.LoaderBase
		{
			// Token: 0x1700015B RID: 347
			// (get) Token: 0x060008BF RID: 2239 RVA: 0x0003D46C File Offset: 0x0003B66C
			// (set) Token: 0x060008C0 RID: 2240 RVA: 0x000065CB File Offset: 0x000047CB
			public override double Progress
			{
				get
				{
					double result;
					if (base.State >= ModBase.LoadState.Finished)
					{
						result = 1.0;
					}
					else if (this.Files.Count == 0)
					{
						result = 0.0;
					}
					else
					{
						result = this._Progress;
					}
					return result;
				}
				set
				{
					throw new Exception("文件下载不允许指定进度");
				}
			}

			// Token: 0x1700015C RID: 348
			// (get) Token: 0x060008C1 RID: 2241 RVA: 0x000065D7 File Offset: 0x000047D7
			// (set) Token: 0x060008C2 RID: 2242 RVA: 0x0003D4B0 File Offset: 0x0003B6B0
			public int FailCount
			{
				get
				{
					return this._FailCount;
				}
				set
				{
					int num2;
					int num4;
					object obj;
					try
					{
						IL_00:
						int num = 1;
						this._FailCount = value;
						IL_09:
						num = 2;
						if (base.State != ModBase.LoadState.Loading || (double)value < Math.Min(2000.0, Math.Max((double)this.FileRemain * 5.5, (double)ModNet.prototypeTag * 5.5 + 3.0)))
						{
							goto IL_133;
						}
						IL_5C:
						num = 3;
						ModBase.Log("[Download] 由于同加载器中失败次数过多引发强制失败：连续失败了 " + Conversions.ToString(value) + " 次", ModBase.LogLevel.Debug, "出现错误");
						IL_7E:
						ProjectData.ClearProjectError();
						num2 = 1;
						IL_85:
						num = 5;
						List<Exception> list = new List<Exception>();
						IL_8D:
						num = 6;
						object filesLock = this.FilesLock;
						ObjectFlowControl.CheckForSyncLockOnValueType(filesLock);
						lock (filesLock)
						{
							try
							{
								foreach (ModNet.NetFile netFile in this.Files)
								{
									foreach (ModNet.NetSource netSource in netFile.messageState)
									{
										if (netSource.m_GlobalState != null)
										{
											list.Add(netSource.m_GlobalState);
											if (list.Count > 10)
											{
												goto IL_12A;
											}
										}
									}
								}
							}
							finally
							{
								List<ModNet.NetFile>.Enumerator enumerator;
								((IDisposable)enumerator).Dispose();
							}
						}
						IL_12A:
						num = 7;
						this.OnFail(list);
						IL_133:
						goto IL_1A2;
						IL_135:
						int num3 = num4 + 1;
						num4 = 0;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
						IL_163:
						goto IL_197;
						IL_165:
						num4 = num;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num2);
						IL_175:;
					}
					catch when (endfilter(obj is Exception & num2 != 0 & num4 == 0))
					{
						Exception ex = (Exception)obj2;
						goto IL_165;
					}
					IL_197:
					throw ProjectData.CreateProjectError(-2146828237);
					IL_1A2:
					if (num4 != 0)
					{
						ProjectData.ClearProjectError();
					}
				}
			}

			// Token: 0x060008C3 RID: 2243 RVA: 0x0003D6B4 File Offset: 0x0003B8B4
			public void RefreshStat()
			{
				double num = 0.0;
				double num2 = 0.0;
				object filesLock = this.FilesLock;
				ObjectFlowControl.CheckForSyncLockOnValueType(filesLock);
				lock (filesLock)
				{
					try
					{
						foreach (ModNet.NetFile netFile in this.Files)
						{
							if (netFile._ReponseProccesor)
							{
								num += netFile.Progress * 0.2;
								num2 += 0.2;
							}
							else
							{
								num += netFile.Progress;
								num2 += 1.0;
							}
						}
					}
					finally
					{
						List<ModNet.NetFile>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
				}
				if (num2 > 0.0)
				{
					num /= num2;
				}
				if (num < 1.0 && num > 0.0)
				{
					num = 1.0 - Math.Pow(1.0 - num, 0.9);
				}
				this._Progress = num * 0.99 + 0.01;
			}

			// Token: 0x060008C4 RID: 2244 RVA: 0x0003D7EC File Offset: 0x0003B9EC
			public LoaderDownload(string Name, List<ModNet.NetFile> FileTasks)
			{
				this.FilesLock = RuntimeHelpers.GetObjectValue(new object());
				this.FileRemainLock = RuntimeHelpers.GetObjectValue(new object());
				this._Progress = 0.0;
				this._FailCount = 0;
				this.Name = Name;
				this.Files = FileTasks;
			}

			// Token: 0x060008C5 RID: 2245 RVA: 0x0003D844 File Offset: 0x0003BA44
			public override void Start(object Input = null, bool IsForceRestart = false)
			{
				object filesLock = this.FilesLock;
				ObjectFlowControl.CheckForSyncLockOnValueType(filesLock);
				checked
				{
					lock (filesLock)
					{
						if (Input != null)
						{
							this.Files = (List<ModNet.NetFile>)Input;
						}
						List<ModNet.NetFile> list = new List<ModNet.NetFile>();
						int num = this.Files.Count - 1;
						int i = 0;
						IL_A7:
						while (i <= num)
						{
							int num2 = i + 1;
							int num3 = this.Files.Count - 1;
							for (int j = num2; j <= num3; j++)
							{
								if (Operators.CompareString(this.Files[i].m_ModelProccesor, this.Files[j].m_ModelProccesor, true) == 0)
								{
									IL_A1:
									i++;
									goto IL_A7;
								}
							}
							list.Add(this.Files[i]);
							goto IL_A1;
						}
						this.Files = list;
						object fileRemainLock = this.FileRemainLock;
						ObjectFlowControl.CheckForSyncLockOnValueType(fileRemainLock);
						lock (fileRemainLock)
						{
							try
							{
								List<ModNet.NetFile>.Enumerator enumerator = this.Files.GetEnumerator();
								while (enumerator.MoveNext())
								{
									if (enumerator.Current._RepositoryProccesor != ModNet.NetState.Finish)
									{
										ref int ptr = ref this.FileRemain;
										this.FileRemain = ptr + 1;
									}
								}
							}
							finally
							{
								List<ModNet.NetFile>.Enumerator enumerator;
								((IDisposable)enumerator).Dispose();
							}
						}
					}
					base.State = ModBase.LoadState.Loading;
					ModBase.RunInNewThread(delegate
					{
						try
						{
							ModNet.LoaderDownload._Closure$__14-1 CS$<>8__locals1 = new ModNet.LoaderDownload._Closure$__14-1(CS$<>8__locals1);
							CS$<>8__locals1.$VB$Me = this;
							if (this.Files.Count == 0)
							{
								this.OnFinish();
							}
							else
							{
								try
								{
									foreach (ModNet.NetFile netFile in this.Files)
									{
										if (netFile == null)
										{
											throw new ArgumentException("存在空文件请求！");
										}
										foreach (ModNet.NetSource netSource in netFile.messageState)
										{
											if (!netSource._ExporterState.ToLower().StartsWith("https://") && !netSource._ExporterState.ToLower().StartsWith("http://"))
											{
												netSource.m_GlobalState = new ArgumentException("输入的下载链接不正确！");
												netSource.methodState = true;
											}
										}
										if (netFile.IsSourceFailed(true))
										{
											throw new ArgumentException("输入的下载链接不正确！");
										}
										if (!netFile.m_ModelProccesor.ToLower().Contains(":\\"))
										{
											throw new ArgumentException("输入的本地文件地址不正确！");
										}
										if (netFile.m_ModelProccesor.EndsWith("\\"))
										{
											throw new ArgumentException("请输入含文件名的完整文件路径！");
										}
										string fullName = new FileInfo(netFile.m_ModelProccesor).Directory.FullName;
										if (!Directory.Exists(fullName))
										{
											Directory.CreateDirectory(fullName);
										}
									}
								}
								finally
								{
									List<ModNet.NetFile>.Enumerator enumerator2;
									((IDisposable)enumerator2).Dispose();
								}
								ModNet.reponseTag.Start(this);
								List<string> list2 = new List<string>();
								CS$<>8__locals1.$VB$Local_FoldersFinal = new List<string>();
								if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("SystemDebugSkipCopy", null))))
								{
									list2.Add(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\.minecraft\\");
									try
									{
										foreach (ModMinecraft.McFolder mcFolder in ModMinecraft._FactoryTag)
										{
											list2.Add(mcFolder.Path);
										}
									}
									finally
									{
										List<ModMinecraft.McFolder>.Enumerator enumerator3;
										((IDisposable)enumerator3).Dispose();
									}
									list2 = ModBase.ArrayNoDouble<string>(list2, null);
									try
									{
										foreach (string text in list2)
										{
											if (Operators.CompareString(text, ModMinecraft._MapperTag, true) != 0 && Directory.Exists(text))
											{
												CS$<>8__locals1.$VB$Local_FoldersFinal.Add(text);
											}
										}
									}
									finally
									{
										List<string>.Enumerator enumerator4;
										((IDisposable)enumerator4).Dispose();
									}
								}
								object filesLock2 = this.FilesLock;
								ObjectFlowControl.CheckForSyncLockOnValueType(filesLock2);
								lock (filesLock2)
								{
									int num4 = (int)Math.Round(Math.Max(10.0, unchecked((double)this.Files.Count / 10.0 + 1.0)));
									List<ModNet.NetFile> list3 = new List<ModNet.NetFile>();
									try
									{
										foreach (ModNet.NetFile item in this.Files)
										{
											list3.Add(item);
											if (list3.Count == num4)
											{
												ModNet.LoaderDownload._Closure$__14-0 CS$<>8__locals2 = new ModNet.LoaderDownload._Closure$__14-0(CS$<>8__locals2);
												CS$<>8__locals2.$VB$NonLocal_$VB$Closure_2 = CS$<>8__locals1;
												CS$<>8__locals2.$VB$Local_FilesToRun = new List<ModNet.NetFile>();
												CS$<>8__locals2.$VB$Local_FilesToRun.AddRange(list3);
												ModBase.RunInNewThread(delegate
												{
													CS$<>8__locals2.$VB$NonLocal_$VB$Closure_2.$VB$Me.StartCopy(CS$<>8__locals2.$VB$Local_FilesToRun, CS$<>8__locals2.$VB$NonLocal_$VB$Closure_2.$VB$Local_FoldersFinal);
												}, "NetTask FileCopy " + Conversions.ToString(this.Uuid), ThreadPriority.Normal);
												list3.Clear();
											}
										}
									}
									finally
									{
										List<ModNet.NetFile>.Enumerator enumerator5;
										((IDisposable)enumerator5).Dispose();
									}
									if (list3.Count > 0)
									{
										ModNet.LoaderDownload._Closure$__14-2 CS$<>8__locals3 = new ModNet.LoaderDownload._Closure$__14-2(CS$<>8__locals3);
										CS$<>8__locals3.$VB$NonLocal_$VB$Closure_3 = CS$<>8__locals1;
										CS$<>8__locals3.$VB$Local_FilesToRun = new List<ModNet.NetFile>();
										CS$<>8__locals3.$VB$Local_FilesToRun.AddRange(list3);
										ModBase.RunInNewThread(delegate
										{
											CS$<>8__locals3.$VB$NonLocal_$VB$Closure_3.$VB$Me.StartCopy(CS$<>8__locals3.$VB$Local_FilesToRun, CS$<>8__locals3.$VB$NonLocal_$VB$Closure_3.$VB$Local_FoldersFinal);
										}, "NetTask FileCopy " + Conversions.ToString(this.Uuid), ThreadPriority.Normal);
										list3.Clear();
									}
								}
							}
						}
						catch (Exception item2)
						{
							this.OnFail(new List<Exception>
							{
								item2
							});
						}
					}, "NetTask " + Conversions.ToString(this.Uuid) + " Main", ThreadPriority.Normal);
				}
			}

			// Token: 0x060008C6 RID: 2246 RVA: 0x0003D9FC File Offset: 0x0003BBFC
			private void StartCopy(List<ModNet.NetFile> Files, List<string> FolderList)
			{
				checked
				{
					try
					{
						if (ModBase._EventState)
						{
							ModBase.Log("[Download] 检查线程分配文件数：" + Conversions.ToString(Files.Count), ModBase.LogLevel.Normal, "出现错误");
						}
						List<KeyValuePair<ModNet.NetFile, string>> list = new List<KeyValuePair<ModNet.NetFile, string>>();
						try
						{
							foreach (ModNet.NetFile netFile in Files)
							{
								string text = null;
								if (netFile.stateProccesor != null && ModMinecraft._FactoryTag != null && netFile.stateProccesor.methodParameter && netFile.m_ModelProccesor.StartsWith(ModMinecraft._MapperTag))
								{
									string str = netFile.m_ModelProccesor.Replace(ModMinecraft._MapperTag, "");
									try
									{
										foreach (string str2 in FolderList)
										{
											string text2 = str2 + str;
											if (netFile.stateProccesor.Check(text2) == null)
											{
												text = text2;
												break;
											}
										}
									}
									finally
									{
										List<string>.Enumerator enumerator2;
										((IDisposable)enumerator2).Dispose();
									}
								}
								object lockState = this.LockState;
								ObjectFlowControl.CheckForSyncLockOnValueType(lockState);
								lock (lockState)
								{
									if (text != null)
									{
										netFile._RepositoryProccesor = ModNet.NetState.WaitForCopy;
										netFile._ReponseProccesor = true;
										list.Add(new KeyValuePair<ModNet.NetFile, string>(netFile, text));
									}
									else
									{
										netFile._RepositoryProccesor = ModNet.NetState.WaitForDownload;
										netFile._ReponseProccesor = false;
									}
								}
							}
						}
						finally
						{
							List<ModNet.NetFile>.Enumerator enumerator;
							((IDisposable)enumerator).Dispose();
						}
						try
						{
							foreach (KeyValuePair<ModNet.NetFile, string> keyValuePair in list)
							{
								ModNet.NetFile key = keyValuePair.Key;
								string value = keyValuePair.Value;
								int num = 0;
								for (;;)
								{
									try
									{
										ModBase.Log("[Download] 复制已存在的文件（" + value + "）", ModBase.LogLevel.Normal, "出现错误");
										Microsoft.VisualBasic.FileIO.FileSystem.CopyFile(value, key.m_ModelProccesor, true);
										key.Finish(false);
										break;
									}
									catch (Exception ex)
									{
										num++;
										ModBase.Log(ex, string.Format("复制已存在的文件失败，重试第 {2} 次（{0} -> {1}）", value, key.m_ModelProccesor, num), ModBase.LogLevel.Debug, "出现错误");
										if (num >= 3)
										{
											key._RepositoryProccesor = ModNet.NetState.WaitForDownload;
											key._ReponseProccesor = false;
											break;
										}
										Thread.Sleep(200);
									}
								}
							}
						}
						finally
						{
							List<KeyValuePair<ModNet.NetFile, string>>.Enumerator enumerator3;
							((IDisposable)enumerator3).Dispose();
						}
					}
					catch (Exception ex2)
					{
						ModBase.Log(ex2, "下载已存在文件查找失败", ModBase.LogLevel.Feedback, "出现错误");
					}
				}
			}

			// Token: 0x060008C7 RID: 2247 RVA: 0x0003DCF0 File Offset: 0x0003BEF0
			public void OnFileFinish(ModNet.NetFile File)
			{
				object fileRemainLock = this.FileRemainLock;
				ObjectFlowControl.CheckForSyncLockOnValueType(fileRemainLock);
				lock (fileRemainLock)
				{
					ref int ptr = ref this.FileRemain;
					this.FileRemain = checked(ptr - 1);
					if (this.FileRemain > 0)
					{
						return;
					}
				}
				this.OnFinish();
			}

			// Token: 0x060008C8 RID: 2248 RVA: 0x0003DD50 File Offset: 0x0003BF50
			public void OnFinish()
			{
				base.RaisePreviewFinish();
				object lockState = this.LockState;
				ObjectFlowControl.CheckForSyncLockOnValueType(lockState);
				lock (lockState)
				{
					if (base.State <= ModBase.LoadState.Loading)
					{
						base.State = ModBase.LoadState.Finished;
					}
				}
			}

			// Token: 0x060008C9 RID: 2249 RVA: 0x0003DDA8 File Offset: 0x0003BFA8
			public void OnFileFail(ModNet.NetFile File)
			{
				foreach (ModNet.NetSource netSource in File.messageState)
				{
					if (!Information.IsNothing(netSource.m_GlobalState))
					{
						File.resolverProccesor.Add(netSource.m_GlobalState);
					}
				}
				this.OnFail(File.resolverProccesor);
			}

			// Token: 0x060008CA RID: 2250 RVA: 0x0003DDF8 File Offset: 0x0003BFF8
			public void OnFail(List<Exception> ExList)
			{
				object lockState = this.LockState;
				ObjectFlowControl.CheckForSyncLockOnValueType(lockState);
				lock (lockState)
				{
					if (base.State > ModBase.LoadState.Loading)
					{
						return;
					}
					if (ExList == null || ExList.Count == 0)
					{
						ExList = new List<Exception>
						{
							new Exception("未知错误！")
						};
					}
					base.Error = ExList[0];
					object filesLock = this.FilesLock;
					ObjectFlowControl.CheckForSyncLockOnValueType(filesLock);
					lock (filesLock)
					{
						try
						{
							foreach (ModNet.NetFile netFile in this.Files)
							{
								if (netFile._RepositoryProccesor == ModNet.NetState.Error)
								{
									base.Error = new Exception(string.Concat(new string[]
									{
										"文件下载失败：",
										netFile.m_ModelProccesor,
										"（第一下载源：",
										netFile.messageState[0]._ExporterState,
										"）"
									}), ExList[0]);
									break;
								}
							}
						}
						finally
						{
							List<ModNet.NetFile>.Enumerator enumerator;
							((IDisposable)enumerator).Dispose();
						}
					}
					base.State = ModBase.LoadState.Failed;
				}
				object filesLock2 = this.FilesLock;
				ObjectFlowControl.CheckForSyncLockOnValueType(filesLock2);
				lock (filesLock2)
				{
					try
					{
						foreach (ModNet.NetFile netFile2 in this.Files)
						{
							if (netFile2._RepositoryProccesor < ModNet.NetState.Merge)
							{
								netFile2._RepositoryProccesor = ModNet.NetState.Error;
							}
						}
					}
					finally
					{
						List<ModNet.NetFile>.Enumerator enumerator2;
						((IDisposable)enumerator2).Dispose();
					}
				}
				List<string> list = new List<string>();
				try
				{
					foreach (Exception ex in ExList)
					{
						list.Add(ModBase.GetString(ex, false, false));
					}
				}
				finally
				{
					List<Exception>.Enumerator enumerator3;
					((IDisposable)enumerator3).Dispose();
				}
				ModBase.Log("[Download] " + ModBase.Join(ModBase.ArrayNoDouble<string>(list.ToArray(), null), "\r\n"), ModBase.LogLevel.Normal, "出现错误");
			}

			// Token: 0x060008CB RID: 2251 RVA: 0x0003E08C File Offset: 0x0003C28C
			public override void Abort()
			{
				object lockState = this.LockState;
				ObjectFlowControl.CheckForSyncLockOnValueType(lockState);
				lock (lockState)
				{
					if (base.State >= ModBase.LoadState.Finished)
					{
						return;
					}
					base.State = ModBase.LoadState.Aborted;
				}
				ModBase.Log("[Download] " + this.Name + " 已取消！", ModBase.LogLevel.Normal, "出现错误");
				object filesLock = this.FilesLock;
				ObjectFlowControl.CheckForSyncLockOnValueType(filesLock);
				lock (filesLock)
				{
					try
					{
						foreach (ModNet.NetFile netFile in this.Files)
						{
							netFile.Abort(this);
						}
					}
					finally
					{
						List<ModNet.NetFile>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
				}
			}

			// Token: 0x0400042F RID: 1071
			public List<ModNet.NetFile> Files;

			// Token: 0x04000430 RID: 1072
			private readonly object FilesLock;

			// Token: 0x04000431 RID: 1073
			private int FileRemain;

			// Token: 0x04000432 RID: 1074
			private readonly object FileRemainLock;

			// Token: 0x04000433 RID: 1075
			private double _Progress;

			// Token: 0x04000434 RID: 1076
			private int _FailCount;
		}

		// Token: 0x020000DD RID: 221
		public class NetManagerClass
		{
			// Token: 0x060008D6 RID: 2262 RVA: 0x0003E5E4 File Offset: 0x0003C7E4
			public NetManagerClass()
			{
				this._WriterProccesor = new Dictionary<string, ModNet.NetFile>();
				this.m_BroadcasterProccesor = RuntimeHelpers.GetObjectValue(new object());
				this._AttributeProccesor = new List<ModNet.LoaderDownload>();
				this.m_SpecificationProccesor = RuntimeHelpers.GetObjectValue(new object());
				this._PredicateProccesor = 0L;
				this._ClientProccesor = RuntimeHelpers.GetObjectValue(new object());
				this._InfoProccesor = 0;
				this.decoratorProccesor = RuntimeHelpers.GetObjectValue(new object());
				this.propertyProccesor = 0L;
				this.descriptorProccesor = new List<long>
				{
					0L,
					0L,
					0L,
					0L,
					0L,
					0L,
					0L,
					0L,
					0L,
					0L
				};
				this._MapProccesor = 0L;
				this.m_EventProccesor = ModBase.GetUuid();
				this.poolProccesor = false;
				this.publisherProccesor = false;
			}

			// Token: 0x060008D7 RID: 2263 RVA: 0x0000666D File Offset: 0x0000486D
			public long RestartComparator()
			{
				return this._PredicateProccesor;
			}

			// Token: 0x060008D8 RID: 2264 RVA: 0x0003E73C File Offset: 0x0003C93C
			public void InterruptComparator(long value)
			{
				object clientProccesor = this._ClientProccesor;
				ObjectFlowControl.CheckForSyncLockOnValueType(clientProccesor);
				lock (clientProccesor)
				{
					this._PredicateProccesor = value;
				}
			}

			// Token: 0x060008D9 RID: 2265 RVA: 0x0003E784 File Offset: 0x0003C984
			private void RefreshStat()
			{
				checked
				{
					try
					{
						long num = ModBase.GetTimeTick() - this.m_AlgoProccesor;
						ref long ptr = ref this.m_AlgoProccesor;
						this.m_AlgoProccesor = ptr + num;
						double a = Math.Max(0.0, (double)(this.RestartComparator() - this.propertyProccesor) / ((double)num / 1000.0));
						this.descriptorProccesor.Add((long)Math.Round(a));
						this.descriptorProccesor.RemoveAt(0);
						this.propertyProccesor = this.RestartComparator();
						this._MapProccesor = (long)Math.Round(unchecked((double)this.descriptorProccesor[9] + (double)this.descriptorProccesor[8] * 0.9 + (double)this.descriptorProccesor[7] * 0.8 + (double)this.descriptorProccesor[6] * 0.7 + (double)this.descriptorProccesor[5] * 0.6 + (double)this.descriptorProccesor[4] * 0.5 + (double)this.descriptorProccesor[3] * 0.4 + (double)this.descriptorProccesor[2] * 0.3 + (double)this.descriptorProccesor[1] * 0.2 + (double)this.descriptorProccesor[0] * 0.1) / 5.5);
						this.descriptorProccesor.Add((long)Math.Round(a));
						this.descriptorProccesor.RemoveAt(0);
						long num2 = (long)Math.Round(unchecked((double)Math.Min(Math.Min(Math.Min(Math.Min(this.descriptorProccesor[5], this.descriptorProccesor[6]), this.descriptorProccesor[7]), this.descriptorProccesor[8]), this.descriptorProccesor[9]) * 0.9));
						if (num2 > ModNet._IssuerTag)
						{
							ModNet._IssuerTag = num2;
							ModBase.Log("[Download] 速度下限已提升到 " + ModBase.GetString(num2), ModBase.LogLevel.Normal, "出现错误");
						}
						object specificationProccesor = this.m_SpecificationProccesor;
						ObjectFlowControl.CheckForSyncLockOnValueType(specificationProccesor);
						lock (specificationProccesor)
						{
							try
							{
								foreach (ModNet.LoaderDownload loaderDownload in this._AttributeProccesor)
								{
									loaderDownload.RefreshStat();
								}
							}
							finally
							{
								List<ModNet.LoaderDownload>.Enumerator enumerator;
								((IDisposable)enumerator).Dispose();
							}
						}
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "刷新下载公开属性失败", ModBase.LogLevel.Debug, "出现错误");
					}
				}
			}

			// Token: 0x060008DA RID: 2266 RVA: 0x0003EA74 File Offset: 0x0003CC74
			private void StartManager()
			{
				checked
				{
					if (!this.poolProccesor)
					{
						this.poolProccesor = true;
						ModBase.RunInNewThread(delegate
						{
							try
							{
								for (;;)
								{
									long timeTick = ModBase.GetTimeTick();
									if (this._InfoProccesor == 0 && this._WriterProccesor.Count > 0)
									{
										object broadcasterProccesor = this.m_BroadcasterProccesor;
										ObjectFlowControl.CheckForSyncLockOnValueType(broadcasterProccesor);
										lock (broadcasterProccesor)
										{
											this._WriterProccesor.Clear();
										}
									}
									if (this._MapProccesor < ModNet._IssuerTag || this._InfoProccesor > ModNet.prototypeTag)
									{
										bool flag2 = false;
										int num = (int)Math.Round(Math.Max((double)this._InfoProccesor, ModBase.MathRange((double)ModNet.m_ParameterTag / 2.0, 1.0, 4.0)));
										num = (int)Math.Floor((double)num / 2.0);
										num = (int)Math.Round(ModBase.MathRange((double)num, 1.0, (double)ModNet.prototypeTag));
										do
										{
											flag2 = false;
											List<ModNet.NetFile> list = new List<ModNet.NetFile>();
											List<ModNet.NetFile> list2 = new List<ModNet.NetFile>();
											object broadcasterProccesor2 = this.m_BroadcasterProccesor;
											ObjectFlowControl.CheckForSyncLockOnValueType(broadcasterProccesor2);
											lock (broadcasterProccesor2)
											{
												try
												{
													foreach (ModNet.NetFile netFile in this._WriterProccesor.Values)
													{
														if (netFile._TokenizerProccesor % 2 != 0)
														{
															if (netFile._RepositoryProccesor == ModNet.NetState.WaitForDownload)
															{
																list.Add(netFile);
															}
															else if (netFile._RepositoryProccesor < ModNet.NetState.Merge)
															{
																list2.Add(netFile);
															}
														}
													}
												}
												finally
												{
													Dictionary<string, ModNet.NetFile>.ValueCollection.Enumerator enumerator;
													((IDisposable)enumerator).Dispose();
												}
											}
											try
											{
												foreach (ModNet.NetFile netFile2 in list)
												{
													if (num == 0)
													{
														break;
													}
													if (netFile2.TryBeginThread())
													{
														flag2 = true;
														num--;
													}
												}
											}
											finally
											{
												List<ModNet.NetFile>.Enumerator enumerator2;
												((IDisposable)enumerator2).Dispose();
											}
											try
											{
												foreach (ModNet.NetFile netFile3 in list2)
												{
													if (num == 0)
													{
														break;
													}
													if (netFile3.TryBeginThread())
													{
														flag2 = true;
														num--;
													}
												}
											}
											finally
											{
												List<ModNet.NetFile>.Enumerator enumerator3;
												((IDisposable)enumerator3).Dispose();
											}
										}
										while (num > 0 && flag2);
									}
									while (ModBase.GetTimeTick() - timeTick < 120L)
									{
										Thread.Sleep(10);
									}
								}
							}
							catch (Exception ex)
							{
								ModBase.Log(ex, "下载管理启动线程 1 出错", ModBase.LogLevel.Assert, "出现错误");
							}
						}, "NetManager ThreadStarter Single", ThreadPriority.Normal);
						ModBase.RunInNewThread(delegate
						{
							try
							{
								for (;;)
								{
									long timeTick = ModBase.GetTimeTick();
									if (this._MapProccesor < ModNet._IssuerTag)
									{
										goto IL_16;
									}
									if (this._InfoProccesor > ModNet.prototypeTag)
									{
										goto IL_16;
									}
									IL_1BB:
									while (ModBase.GetTimeTick() - timeTick < 120L)
									{
										Thread.Sleep(10);
									}
									continue;
									IL_16:
									bool flag = false;
									int num = (int)Math.Round(Math.Max((double)this._InfoProccesor, ModBase.MathRange((double)ModNet.m_ParameterTag / 2.0, 1.0, 4.0)));
									num = (int)Math.Floor((double)num / 2.0);
									num = (int)Math.Round(ModBase.MathRange((double)num, 1.0, (double)ModNet.prototypeTag));
									for (;;)
									{
										flag = false;
										List<ModNet.NetFile> list = new List<ModNet.NetFile>();
										List<ModNet.NetFile> list2 = new List<ModNet.NetFile>();
										object broadcasterProccesor = this.m_BroadcasterProccesor;
										ObjectFlowControl.CheckForSyncLockOnValueType(broadcasterProccesor);
										lock (broadcasterProccesor)
										{
											try
											{
												foreach (ModNet.NetFile netFile in this._WriterProccesor.Values)
												{
													if (netFile._TokenizerProccesor % 2 != 1)
													{
														if (netFile._RepositoryProccesor == ModNet.NetState.WaitForDownload)
														{
															list.Add(netFile);
														}
														else if (netFile._RepositoryProccesor < ModNet.NetState.Merge)
														{
															list2.Add(netFile);
														}
													}
												}
											}
											finally
											{
												Dictionary<string, ModNet.NetFile>.ValueCollection.Enumerator enumerator;
												((IDisposable)enumerator).Dispose();
											}
										}
										try
										{
											IL_109:
											foreach (ModNet.NetFile netFile2 in list)
											{
												if (num == 0)
												{
													break;
												}
												if (netFile2.TryBeginThread())
												{
													flag = true;
													num--;
												}
											}
										}
										finally
										{
											List<ModNet.NetFile>.Enumerator enumerator2;
											((IDisposable)enumerator2).Dispose();
										}
										try
										{
											foreach (ModNet.NetFile netFile3 in list2)
											{
												if (num == 0)
												{
													break;
												}
												if (netFile3.TryBeginThread())
												{
													flag = true;
													num--;
												}
											}
										}
										finally
										{
											List<ModNet.NetFile>.Enumerator enumerator3;
											((IDisposable)enumerator3).Dispose();
										}
										if (num > 0 && flag)
										{
											continue;
										}
										goto IL_1BB;
										goto IL_109;
									}
								}
							}
							catch (Exception ex)
							{
								ModBase.Log(ex, "下载管理启动线程 2 出错", ModBase.LogLevel.Assert, "出现错误");
							}
						}, "NetManager ThreadStarter Odd", ThreadPriority.Normal);
						ModBase.RunInNewThread(delegate
						{
							try
							{
								ModNet.proccesorTag = ModBase.GetTimeTick();
								for (;;)
								{
									long timeTick = ModBase.GetTimeTick();
									long num = timeTick;
									if (ModNet.requestTag > 0L)
									{
										ModNet.m_AccountTag = (long)Math.Round(unchecked((double)ModNet.requestTag / 1000.0 * (double)(checked(timeTick - ModNet.proccesorTag))));
									}
									ModNet.proccesorTag = timeTick;
									this.RefreshStat();
									while (ModBase.GetTimeTick() - num < 170L)
									{
										Thread.Sleep(10);
									}
								}
							}
							catch (Exception ex)
							{
								ModBase.Log(ex, "下载管理刷新线程出错", ModBase.LogLevel.Assert, "出现错误");
							}
						}, "NetManager StatRefresher", ThreadPriority.Normal);
					}
				}
			}

			// Token: 0x060008DB RID: 2267 RVA: 0x0003EAD8 File Offset: 0x0003CCD8
			public void Start(ModNet.LoaderDownload Task)
			{
				this.StartManager();
				if (!this.publisherProccesor)
				{
					try
					{
						ModBase.DeleteDirectory(ModBase.attributeState + "Download", false);
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "清理下载缓存失败", ModBase.LogLevel.Debug, "出现错误");
					}
					this.publisherProccesor = true;
				}
				Directory.CreateDirectory(ModBase.attributeState + "Download");
				object broadcasterProccesor = this.m_BroadcasterProccesor;
				ObjectFlowControl.CheckForSyncLockOnValueType(broadcasterProccesor);
				checked
				{
					lock (broadcasterProccesor)
					{
						int num = Task.Files.Count - 1;
						int i = 0;
						while (i <= num)
						{
							ModNet.NetFile netFile = Task.Files[i];
							if (this._WriterProccesor.ContainsKey(netFile.m_ModelProccesor))
							{
								if (this._WriterProccesor[netFile.m_ModelProccesor]._RepositoryProccesor >= ModNet.NetState.Finish)
								{
									object initializerProccesor = netFile.initializerProccesor;
									ObjectFlowControl.CheckForSyncLockOnValueType(initializerProccesor);
									lock (initializerProccesor)
									{
										netFile.m_DispatcherState.Add(Task);
									}
									this._WriterProccesor[netFile.m_ModelProccesor] = netFile;
									object obj = this.decoratorProccesor;
									ObjectFlowControl.CheckForSyncLockOnValueType(obj);
									lock (obj)
									{
										ref int ptr = ref this._InfoProccesor;
										this._InfoProccesor = ptr + 1;
										if (ModBase._EventState)
										{
											ModBase.Log("[Download] " + netFile.m_WrapperProccesor + "：已替换列表，剩余文件 " + Conversions.ToString(this._InfoProccesor), ModBase.LogLevel.Normal, "出现错误");
										}
										goto IL_290;
									}
								}
								netFile = this._WriterProccesor[netFile.m_ModelProccesor];
								object initializerProccesor2 = netFile.initializerProccesor;
								ObjectFlowControl.CheckForSyncLockOnValueType(initializerProccesor2);
								lock (initializerProccesor2)
								{
									netFile.m_DispatcherState.Add(Task);
									goto IL_290;
								}
								goto IL_1DA;
							}
							goto IL_1DA;
							IL_290:
							Task.Files[i] = netFile;
							i++;
							continue;
							IL_1DA:
							object initializerProccesor3 = netFile.initializerProccesor;
							ObjectFlowControl.CheckForSyncLockOnValueType(initializerProccesor3);
							lock (initializerProccesor3)
							{
								netFile.m_DispatcherState.Add(Task);
							}
							this._WriterProccesor.Add(netFile.m_ModelProccesor, netFile);
							object obj2 = this.decoratorProccesor;
							ObjectFlowControl.CheckForSyncLockOnValueType(obj2);
							lock (obj2)
							{
								ref int ptr = ref this._InfoProccesor;
								this._InfoProccesor = ptr + 1;
								if (ModBase._EventState)
								{
									ModBase.Log("[Download] " + netFile.m_WrapperProccesor + "：已加入列表，剩余文件 " + Conversions.ToString(this._InfoProccesor), ModBase.LogLevel.Normal, "出现错误");
								}
							}
							goto IL_290;
						}
					}
					object specificationProccesor = this.m_SpecificationProccesor;
					ObjectFlowControl.CheckForSyncLockOnValueType(specificationProccesor);
					lock (specificationProccesor)
					{
						this._AttributeProccesor.Add(Task);
					}
				}
			}

			// Token: 0x0400043B RID: 1083
			public Dictionary<string, ModNet.NetFile> _WriterProccesor;

			// Token: 0x0400043C RID: 1084
			public readonly object m_BroadcasterProccesor;

			// Token: 0x0400043D RID: 1085
			public List<ModNet.LoaderDownload> _AttributeProccesor;

			// Token: 0x0400043E RID: 1086
			private readonly object m_SpecificationProccesor;

			// Token: 0x0400043F RID: 1087
			private long _PredicateProccesor;

			// Token: 0x04000440 RID: 1088
			private readonly object _ClientProccesor;

			// Token: 0x04000441 RID: 1089
			public int _InfoProccesor;

			// Token: 0x04000442 RID: 1090
			public readonly object decoratorProccesor;

			// Token: 0x04000443 RID: 1091
			private long propertyProccesor;

			// Token: 0x04000444 RID: 1092
			public List<long> descriptorProccesor;

			// Token: 0x04000445 RID: 1093
			public long _MapProccesor;

			// Token: 0x04000446 RID: 1094
			public readonly int m_EventProccesor;

			// Token: 0x04000447 RID: 1095
			private long m_AlgoProccesor;

			// Token: 0x04000448 RID: 1096
			private bool poolProccesor;

			// Token: 0x04000449 RID: 1097
			private bool publisherProccesor;
		}
	}
}
