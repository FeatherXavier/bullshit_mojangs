﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Navigation;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000098 RID: 152
	[DesignerGenerated]
	public class FormLoginOAuth : Window, IComponentConnector
	{
		// Token: 0x0600057A RID: 1402 RVA: 0x0002B2DC File Offset: 0x000294DC
		public FormLoginOAuth()
		{
			base.Loaded += this.FrmLoginOAuth_Loaded;
			base.Closed += delegate(object sender, EventArgs e)
			{
				this.FormLoginOAuth_Closed();
			};
			this.callbackRepository = false;
			this._AdvisorRepository = false;
			this.m_ObserverRepository = false;
			this._SingletonRepository = RuntimeHelpers.GetObjectValue(new object());
			this.InitializeComponent();
		}

		// Token: 0x0600057B RID: 1403 RVA: 0x0002B340 File Offset: 0x00029540
		[CompilerGenerated]
		public void LoginRepository(FormLoginOAuth.OnLoginSuccessEventHandler obj)
		{
			FormLoginOAuth.OnLoginSuccessEventHandler onLoginSuccessEventHandler = this.schemaRepository;
			FormLoginOAuth.OnLoginSuccessEventHandler onLoginSuccessEventHandler2;
			do
			{
				onLoginSuccessEventHandler2 = onLoginSuccessEventHandler;
				FormLoginOAuth.OnLoginSuccessEventHandler value = (FormLoginOAuth.OnLoginSuccessEventHandler)Delegate.Combine(onLoginSuccessEventHandler2, obj);
				onLoginSuccessEventHandler = Interlocked.CompareExchange<FormLoginOAuth.OnLoginSuccessEventHandler>(ref this.schemaRepository, value, onLoginSuccessEventHandler2);
			}
			while (onLoginSuccessEventHandler != onLoginSuccessEventHandler2);
		}

		// Token: 0x0600057C RID: 1404 RVA: 0x0002B378 File Offset: 0x00029578
		[CompilerGenerated]
		public void CollectRepository(FormLoginOAuth.OnLoginSuccessEventHandler obj)
		{
			FormLoginOAuth.OnLoginSuccessEventHandler onLoginSuccessEventHandler = this.schemaRepository;
			FormLoginOAuth.OnLoginSuccessEventHandler onLoginSuccessEventHandler2;
			do
			{
				onLoginSuccessEventHandler2 = onLoginSuccessEventHandler;
				FormLoginOAuth.OnLoginSuccessEventHandler value = (FormLoginOAuth.OnLoginSuccessEventHandler)Delegate.Remove(onLoginSuccessEventHandler2, obj);
				onLoginSuccessEventHandler = Interlocked.CompareExchange<FormLoginOAuth.OnLoginSuccessEventHandler>(ref this.schemaRepository, value, onLoginSuccessEventHandler2);
			}
			while (onLoginSuccessEventHandler != onLoginSuccessEventHandler2);
		}

		// Token: 0x0600057D RID: 1405 RVA: 0x0002B3B0 File Offset: 0x000295B0
		[CompilerGenerated]
		public void MoveRepository(FormLoginOAuth.OnLoginCanceledEventHandler obj)
		{
			FormLoginOAuth.OnLoginCanceledEventHandler onLoginCanceledEventHandler = this.databaseRepository;
			FormLoginOAuth.OnLoginCanceledEventHandler onLoginCanceledEventHandler2;
			do
			{
				onLoginCanceledEventHandler2 = onLoginCanceledEventHandler;
				FormLoginOAuth.OnLoginCanceledEventHandler value = (FormLoginOAuth.OnLoginCanceledEventHandler)Delegate.Combine(onLoginCanceledEventHandler2, obj);
				onLoginCanceledEventHandler = Interlocked.CompareExchange<FormLoginOAuth.OnLoginCanceledEventHandler>(ref this.databaseRepository, value, onLoginCanceledEventHandler2);
			}
			while (onLoginCanceledEventHandler != onLoginCanceledEventHandler2);
		}

		// Token: 0x0600057E RID: 1406 RVA: 0x0002B3E8 File Offset: 0x000295E8
		[CompilerGenerated]
		public void EnableRepository(FormLoginOAuth.OnLoginCanceledEventHandler obj)
		{
			FormLoginOAuth.OnLoginCanceledEventHandler onLoginCanceledEventHandler = this.databaseRepository;
			FormLoginOAuth.OnLoginCanceledEventHandler onLoginCanceledEventHandler2;
			do
			{
				onLoginCanceledEventHandler2 = onLoginCanceledEventHandler;
				FormLoginOAuth.OnLoginCanceledEventHandler value = (FormLoginOAuth.OnLoginCanceledEventHandler)Delegate.Remove(onLoginCanceledEventHandler2, obj);
				onLoginCanceledEventHandler = Interlocked.CompareExchange<FormLoginOAuth.OnLoginCanceledEventHandler>(ref this.databaseRepository, value, onLoginCanceledEventHandler2);
			}
			while (onLoginCanceledEventHandler != onLoginCanceledEventHandler2);
		}

		// Token: 0x0600057F RID: 1407 RVA: 0x0002B420 File Offset: 0x00029620
		private void Browser_Navigating(WebBrowser sender, NavigatingCancelEventArgs e)
		{
			string absoluteUri = e.Uri.AbsoluteUri;
			if (ModBase._EventState)
			{
				ModBase.Log(Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("[Login] 登录浏览器 ", sender.Tag), " 导向："), absoluteUri)), ModBase.LogLevel.Normal, "出现错误");
			}
			if (absoluteUri.Contains("code="))
			{
				string text = ModBase.RegexSeek(absoluteUri, "(?<=code\\=)[^&]+", RegexOptions.None);
				ModBase.Log("[Login] 抓取到 OAuth 返回码：" + text, ModBase.LogLevel.Normal, "出现错误");
				this.callbackRepository = true;
				FormLoginOAuth.OnLoginSuccessEventHandler onLoginSuccessEventHandler = this.schemaRepository;
				if (onLoginSuccessEventHandler != null)
				{
					onLoginSuccessEventHandler(text);
					return;
				}
			}
			else if (absoluteUri.Contains("github."))
			{
				ModMain.Hint("PCL2 不支持使用 GitHub 登录微软账号！", ModMain.HintType.Critical, true);
				this._AdvisorRepository = true;
				base.Close();
			}
		}

		// Token: 0x06000580 RID: 1408 RVA: 0x0002B4E0 File Offset: 0x000296E0
		private void Browser_Navigated(WebBrowser sender, NavigationEventArgs e)
		{
			object singletonRepository = this._SingletonRepository;
			ObjectFlowControl.CheckForSyncLockOnValueType(singletonRepository);
			lock (singletonRepository)
			{
				if (this.m_ObserverRepository)
				{
					return;
				}
				this.m_ObserverRepository = true;
			}
			Action $I1;
			ModBase.RunInThread(delegate
			{
				Thread.Sleep(1000);
				ModBase.RunInUi(($I1 == null) ? ($I1 = delegate()
				{
					sender.Visibility = Visibility.Visible;
					this.PanLoading.Visibility = Visibility.Collapsed;
				}) : $I1, false);
			});
		}

		// Token: 0x06000581 RID: 1409 RVA: 0x00004E0D File Offset: 0x0000300D
		private void FrmLoginOAuth_Loaded(object sender, RoutedEventArgs e)
		{
			this.Browser1.Navigate(FormLoginOAuth.m_ContextRepository);
			ModBase.RunInThread(delegate
			{
				Thread.Sleep(1500);
				ModBase.RunInUi(delegate()
				{
					try
					{
						if (!this.m_ObserverRepository)
						{
							this.Browser2.Navigate(FormLoginOAuth.m_ContextRepository);
						}
					}
					catch (Exception ex)
					{
					}
				}, false);
				Thread.Sleep(1500);
				ModBase.RunInUi(delegate()
				{
					try
					{
						if (!this.m_ObserverRepository)
						{
							this.Browser3.Navigate(FormLoginOAuth.collectionRepository);
						}
					}
					catch (Exception ex)
					{
					}
				}, false);
			});
		}

		// Token: 0x06000582 RID: 1410 RVA: 0x0002B558 File Offset: 0x00029758
		private void FormLoginOAuth_Closed()
		{
			try
			{
				this.Browser1.Dispose();
				this.Browser2.Dispose();
				this.Browser3.Dispose();
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "释放微软登录浏览器失败", ModBase.LogLevel.Debug, "出现错误");
			}
			if (!this.callbackRepository)
			{
				FormLoginOAuth.OnLoginCanceledEventHandler onLoginCanceledEventHandler = this.databaseRepository;
				if (onLoginCanceledEventHandler != null)
				{
					onLoginCanceledEventHandler(this._AdvisorRepository);
				}
			}
			ModMain.m_CollectionAccount.Focus();
		}

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x06000583 RID: 1411 RVA: 0x00004E30 File Offset: 0x00003030
		// (set) Token: 0x06000584 RID: 1412 RVA: 0x00004E38 File Offset: 0x00003038
		internal virtual StackPanel PanLoading { get; set; }

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x06000585 RID: 1413 RVA: 0x00004E41 File Offset: 0x00003041
		// (set) Token: 0x06000586 RID: 1414 RVA: 0x00004E49 File Offset: 0x00003049
		internal virtual MyLoading Loading { get; set; }

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x06000587 RID: 1415 RVA: 0x00004E52 File Offset: 0x00003052
		// (set) Token: 0x06000588 RID: 1416 RVA: 0x0002B5E0 File Offset: 0x000297E0
		internal virtual WebBrowser Browser1
		{
			[CompilerGenerated]
			get
			{
				return this._ReaderRepository;
			}
			[CompilerGenerated]
			set
			{
				NavigatingCancelEventHandler value2 = delegate(object sender, NavigatingCancelEventArgs e)
				{
					this.Browser_Navigating((WebBrowser)sender, e);
				};
				NavigatedEventHandler value3 = delegate(object sender, NavigationEventArgs e)
				{
					this.Browser_Navigated((WebBrowser)sender, e);
				};
				WebBrowser readerRepository = this._ReaderRepository;
				if (readerRepository != null)
				{
					readerRepository.Navigating -= value2;
					readerRepository.Navigated -= value3;
				}
				this._ReaderRepository = value;
				readerRepository = this._ReaderRepository;
				if (readerRepository != null)
				{
					readerRepository.Navigating += value2;
					readerRepository.Navigated += value3;
				}
			}
		}

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x06000589 RID: 1417 RVA: 0x00004E5A File Offset: 0x0000305A
		// (set) Token: 0x0600058A RID: 1418 RVA: 0x0002B640 File Offset: 0x00029840
		internal virtual WebBrowser Browser2
		{
			[CompilerGenerated]
			get
			{
				return this.fieldRepository;
			}
			[CompilerGenerated]
			set
			{
				NavigatingCancelEventHandler value2 = delegate(object sender, NavigatingCancelEventArgs e)
				{
					this.Browser_Navigating((WebBrowser)sender, e);
				};
				NavigatedEventHandler value3 = delegate(object sender, NavigationEventArgs e)
				{
					this.Browser_Navigated((WebBrowser)sender, e);
				};
				WebBrowser webBrowser = this.fieldRepository;
				if (webBrowser != null)
				{
					webBrowser.Navigating -= value2;
					webBrowser.Navigated -= value3;
				}
				this.fieldRepository = value;
				webBrowser = this.fieldRepository;
				if (webBrowser != null)
				{
					webBrowser.Navigating += value2;
					webBrowser.Navigated += value3;
				}
			}
		}

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x0600058B RID: 1419 RVA: 0x00004E62 File Offset: 0x00003062
		// (set) Token: 0x0600058C RID: 1420 RVA: 0x0002B6A0 File Offset: 0x000298A0
		internal virtual WebBrowser Browser3
		{
			[CompilerGenerated]
			get
			{
				return this._PageRepository;
			}
			[CompilerGenerated]
			set
			{
				NavigatingCancelEventHandler value2 = delegate(object sender, NavigatingCancelEventArgs e)
				{
					this.Browser_Navigating((WebBrowser)sender, e);
				};
				NavigatedEventHandler value3 = delegate(object sender, NavigationEventArgs e)
				{
					this.Browser_Navigated((WebBrowser)sender, e);
				};
				WebBrowser pageRepository = this._PageRepository;
				if (pageRepository != null)
				{
					pageRepository.Navigating -= value2;
					pageRepository.Navigated -= value3;
				}
				this._PageRepository = value;
				pageRepository = this._PageRepository;
				if (pageRepository != null)
				{
					pageRepository.Navigating += value2;
					pageRepository.Navigated += value3;
				}
			}
		}

		// Token: 0x0600058D RID: 1421 RVA: 0x0002B700 File Offset: 0x00029900
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.printerRepository)
			{
				this.printerRepository = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagelaunch/formloginoauth.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x0600058E RID: 1422 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600058F RID: 1423 RVA: 0x0002B730 File Offset: 0x00029930
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanLoading = (StackPanel)target;
				return;
			}
			if (connectionId == 2)
			{
				this.Loading = (MyLoading)target;
				return;
			}
			if (connectionId == 3)
			{
				this.Browser1 = (WebBrowser)target;
				return;
			}
			if (connectionId == 4)
			{
				this.Browser2 = (WebBrowser)target;
				return;
			}
			if (connectionId == 5)
			{
				this.Browser3 = (WebBrowser)target;
				return;
			}
			this.printerRepository = true;
		}

		// Token: 0x0400028F RID: 655
		[CompilerGenerated]
		private FormLoginOAuth.OnLoginSuccessEventHandler schemaRepository;

		// Token: 0x04000290 RID: 656
		[CompilerGenerated]
		private FormLoginOAuth.OnLoginCanceledEventHandler databaseRepository;

		// Token: 0x04000291 RID: 657
		private bool callbackRepository;

		// Token: 0x04000292 RID: 658
		private bool _AdvisorRepository;

		// Token: 0x04000293 RID: 659
		private bool m_ObserverRepository;

		// Token: 0x04000294 RID: 660
		private object _SingletonRepository;

		// Token: 0x04000295 RID: 661
		public static string m_ContextRepository = "https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize?prompt=login&client_id=00000000402b5328&response_type=code&scope=service%3A%3Auser.auth.xboxlive.com%3A%3AMBI_SSL&redirect_uri=https:%2F%2Flogin.live.com%2Foauth20_desktop.srf";

		// Token: 0x04000296 RID: 662
		public static string collectionRepository = "https://login.live.com/oauth20_authorize.srf?prompt=login&client_id=00000000402b5328&response_type=code&scope=service%3A%3Auser.auth.xboxlive.com%3A%3AMBI_SSL&redirect_uri=https:%2F%2Flogin.live.com%2Foauth20_desktop.srf";

		// Token: 0x04000297 RID: 663
		[CompilerGenerated]
		[AccessedThroughProperty("PanLoading")]
		private StackPanel m_ConsumerRepository;

		// Token: 0x04000298 RID: 664
		[CompilerGenerated]
		[AccessedThroughProperty("Loading")]
		private MyLoading filterRepository;

		// Token: 0x04000299 RID: 665
		[CompilerGenerated]
		[AccessedThroughProperty("Browser1")]
		private WebBrowser _ReaderRepository;

		// Token: 0x0400029A RID: 666
		[CompilerGenerated]
		[AccessedThroughProperty("Browser2")]
		private WebBrowser fieldRepository;

		// Token: 0x0400029B RID: 667
		[AccessedThroughProperty("Browser3")]
		[CompilerGenerated]
		private WebBrowser _PageRepository;

		// Token: 0x0400029C RID: 668
		private bool printerRepository;

		// Token: 0x02000099 RID: 153
		// (Invoke) Token: 0x0600059D RID: 1437
		public delegate void OnLoginSuccessEventHandler(string code);

		// Token: 0x0200009A RID: 154
		// (Invoke) Token: 0x060005A2 RID: 1442
		public delegate void OnLoginCanceledEventHandler(bool IsForceExit);
	}
}
