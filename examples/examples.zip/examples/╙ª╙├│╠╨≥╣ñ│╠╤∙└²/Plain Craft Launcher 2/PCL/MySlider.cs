﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000185 RID: 389
	[DesignerGenerated]
	public class MySlider : Border, IComponentConnector
	{
		// Token: 0x060011E2 RID: 4578 RVA: 0x000784C4 File Offset: 0x000766C4
		public MySlider()
		{
			base.SizeChanged += this.RefreshWidth;
			base.MouseLeftButtonDown += this.DragStart;
			base.IsEnabledChanged += delegate(object sender, DependencyPropertyChangedEventArgs e)
			{
				this.RefreshColor();
			};
			base.MouseEnter += delegate(object sender, MouseEventArgs e)
			{
				this.RefreshColor();
			};
			base.MouseLeave += delegate(object sender, MouseEventArgs e)
			{
				this.RefreshColor();
			};
			base.MouseEnter += delegate(object sender, MouseEventArgs e)
			{
				this.MySlider_MouseEnter();
			};
			base.KeyDown += this.MySlider_KeyDown;
			this.m_WorkerRequest = ModBase.GetUuid();
			this.m_ConfigRequest = 100;
			this._ManagerRequest = false;
			this.m_RuleRequest = 0;
			this.ValueByKey = 1U;
			this.InitializeComponent();
		}

		// Token: 0x060011E3 RID: 4579 RVA: 0x00078584 File Offset: 0x00076784
		[CompilerGenerated]
		public void UpdateTag(MySlider.ChangeEventHandler obj)
		{
			MySlider.ChangeEventHandler changeEventHandler = this.dicRequest;
			MySlider.ChangeEventHandler changeEventHandler2;
			do
			{
				changeEventHandler2 = changeEventHandler;
				MySlider.ChangeEventHandler value = (MySlider.ChangeEventHandler)Delegate.Combine(changeEventHandler2, obj);
				changeEventHandler = Interlocked.CompareExchange<MySlider.ChangeEventHandler>(ref this.dicRequest, value, changeEventHandler2);
			}
			while (changeEventHandler != changeEventHandler2);
		}

		// Token: 0x060011E4 RID: 4580 RVA: 0x000785BC File Offset: 0x000767BC
		[CompilerGenerated]
		public void ViewTag(MySlider.ChangeEventHandler obj)
		{
			MySlider.ChangeEventHandler changeEventHandler = this.dicRequest;
			MySlider.ChangeEventHandler changeEventHandler2;
			do
			{
				changeEventHandler2 = changeEventHandler;
				MySlider.ChangeEventHandler value = (MySlider.ChangeEventHandler)Delegate.Remove(changeEventHandler2, obj);
				changeEventHandler = Interlocked.CompareExchange<MySlider.ChangeEventHandler>(ref this.dicRequest, value, changeEventHandler2);
			}
			while (changeEventHandler != changeEventHandler2);
		}

		// Token: 0x060011E5 RID: 4581 RVA: 0x000785F4 File Offset: 0x000767F4
		[CompilerGenerated]
		public void InstantiateTag(MySlider.PreviewChangeEventHandler obj)
		{
			MySlider.PreviewChangeEventHandler previewChangeEventHandler = this._ConfigurationRequest;
			MySlider.PreviewChangeEventHandler previewChangeEventHandler2;
			do
			{
				previewChangeEventHandler2 = previewChangeEventHandler;
				MySlider.PreviewChangeEventHandler value = (MySlider.PreviewChangeEventHandler)Delegate.Combine(previewChangeEventHandler2, obj);
				previewChangeEventHandler = Interlocked.CompareExchange<MySlider.PreviewChangeEventHandler>(ref this._ConfigurationRequest, value, previewChangeEventHandler2);
			}
			while (previewChangeEventHandler != previewChangeEventHandler2);
		}

		// Token: 0x060011E6 RID: 4582 RVA: 0x0007862C File Offset: 0x0007682C
		[CompilerGenerated]
		public void RemoveTag(MySlider.PreviewChangeEventHandler obj)
		{
			MySlider.PreviewChangeEventHandler previewChangeEventHandler = this._ConfigurationRequest;
			MySlider.PreviewChangeEventHandler previewChangeEventHandler2;
			do
			{
				previewChangeEventHandler2 = previewChangeEventHandler;
				MySlider.PreviewChangeEventHandler value = (MySlider.PreviewChangeEventHandler)Delegate.Remove(previewChangeEventHandler2, obj);
				previewChangeEventHandler = Interlocked.CompareExchange<MySlider.PreviewChangeEventHandler>(ref this._ConfigurationRequest, value, previewChangeEventHandler2);
			}
			while (previewChangeEventHandler != previewChangeEventHandler2);
		}

		// Token: 0x17000312 RID: 786
		// (get) Token: 0x060011E7 RID: 4583 RVA: 0x0000A8D1 File Offset: 0x00008AD1
		// (set) Token: 0x060011E8 RID: 4584 RVA: 0x0000A8D9 File Offset: 0x00008AD9
		public int MaxValue
		{
			get
			{
				return this.m_ConfigRequest;
			}
			set
			{
				if (value != this.m_ConfigRequest)
				{
					this.m_ConfigRequest = value;
					this.RefreshWidth(null, null);
				}
			}
		}

		// Token: 0x17000313 RID: 787
		// (get) Token: 0x060011E9 RID: 4585 RVA: 0x0000A8F3 File Offset: 0x00008AF3
		// (set) Token: 0x060011EA RID: 4586 RVA: 0x00078664 File Offset: 0x00076864
		public int Value
		{
			get
			{
				return this.m_RuleRequest;
			}
			set
			{
				try
				{
					value = checked((int)Math.Round(ModBase.MathRange((double)value, 0.0, (double)this.MaxValue)));
					if (this.m_RuleRequest != value)
					{
						int ruleRequest = this.m_RuleRequest;
						this.m_RuleRequest = value;
						if (ModAnimation.DefineModel() == 0)
						{
							ModBase.RouteEventArgs routeEventArgs = new ModBase.RouteEventArgs(false);
							MySlider.PreviewChangeEventHandler configurationRequest = this._ConfigurationRequest;
							if (configurationRequest != null)
							{
								configurationRequest(this, routeEventArgs);
							}
							if (routeEventArgs.proxyParameter)
							{
								this.m_RuleRequest = ruleRequest;
								this.DragStop();
								return;
							}
						}
						if (base.IsLoaded && ModAnimation.DefineModel() == 0)
						{
							if (base.ActualWidth < 16.0)
							{
								return;
							}
							double num = (double)this.m_RuleRequest / (double)this.MaxValue * (base.ActualWidth - 16.0);
							double num2 = Math.Abs(this.LineFore.Width / (base.ActualWidth - 16.0) - (double)this.m_RuleRequest / (double)this.MaxValue);
							double num3 = (1.0 - Math.Pow(1.0 - num2, 3.0)) * 300.0 + (double)(this._ManagerRequest ? 100 : 0);
							ModAnimation.AniStart(new ModAnimation.AniData[]
							{
								ModAnimation.AaWidth(this.LineFore, Math.Max(0.0, num + ((num < 0.5) ? 0.0 : 0.5)) - this.LineFore.Width, checked((int)Math.Round(num3)), 0, (ModAnimation.AniEase)((num3 > 50.0) ? new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle) : new ModAnimation.AniEaseLinear()), false),
								ModAnimation.AaWidth(this.LineBack, Math.Max(0.0, base.ActualWidth - 16.0 - num + ((base.ActualWidth - 16.0 - num < 0.5) ? 0.0 : 0.5)) - this.LineBack.Width, checked((int)Math.Round(num3)), 0, (ModAnimation.AniEase)((num3 > 50.0) ? new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle) : new ModAnimation.AniEaseLinear()), false),
								ModAnimation.AaX(this.ShapeDot, num - this.ShapeDot.Margin.Left, checked((int)Math.Round(num3)), 0, (ModAnimation.AniEase)((num3 > 50.0) ? new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle) : new ModAnimation.AniEaseLinear()), false)
							}, "MySlider Progress " + Conversions.ToString(this.m_WorkerRequest), false);
						}
						else
						{
							this.RefreshWidth(null, null);
						}
						if (ModAnimation.DefineModel() == 0)
						{
							MySlider.ChangeEventHandler changeEventHandler = this.dicRequest;
							if (changeEventHandler != null)
							{
								changeEventHandler(this, false);
							}
						}
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "滑动条进度改变出错", ModBase.LogLevel.Hint, "出现错误");
				}
			}
		}

		// Token: 0x060011EB RID: 4587 RVA: 0x0007898C File Offset: 0x00076B8C
		private void RefreshWidth(object sender, SizeChangedEventArgs e)
		{
			if (!Information.IsNothing(e))
			{
				this.PanMain.Width = e.NewSize.Width;
			}
			ModAnimation.AniStop("MySlider Progress " + Conversions.ToString(this.m_WorkerRequest));
			double num = (double)this.m_RuleRequest / (double)this.MaxValue * (base.ActualWidth - 16.0);
			this.LineFore.Width = Math.Max(0.0, num + ((num < 0.5) ? 0.0 : 0.5));
			this.LineBack.Width = Math.Max(0.0, base.ActualWidth - 16.0 - num + ((base.ActualWidth - 16.0 - num < 0.5) ? 0.0 : 0.5));
			ModBase.SetLeft(this.ShapeDot, num);
		}

		// Token: 0x060011EC RID: 4588 RVA: 0x00078A9C File Offset: 0x00076C9C
		private void DragStart(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
			ModMain._ParameterState = this;
			ModMain.m_CollectionAccount.DragDoing();
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaScaleTransform(this.ShapeDot, 0.8 - ((ScaleTransform)this.ShapeDot.RenderTransform).ScaleX, 75, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false)
			}, "MySlider Scale " + Conversions.ToString(this.m_WorkerRequest), false);
			if (this.merchantRequest != null)
			{
				this.TextHint.Text = Conversions.ToString(this.merchantRequest.DynamicInvoke(new object[]
				{
					this.Value
				}));
				this.Popup.IsOpen = true;
				ModAnimation.AniStop("MySlider KeyPopup " + Conversions.ToString(this.m_WorkerRequest));
			}
		}

		// Token: 0x060011ED RID: 4589 RVA: 0x00078B7C File Offset: 0x00076D7C
		public void DragDoing()
		{
			int num = checked((int)Math.Round(unchecked(ModBase.MathRange((Mouse.GetPosition(this.PanMain).X - 8.0) / (base.ActualWidth - 16.0), 0.0, 1.0) * (double)this.MaxValue)));
			if (num != this.Value)
			{
				this.Value = num;
			}
			if (this.merchantRequest != null)
			{
				this.TextHint.Text = Conversions.ToString(this.merchantRequest.DynamicInvoke(new object[]
				{
					num
				}));
			}
		}

		// Token: 0x060011EE RID: 4590 RVA: 0x00078C20 File Offset: 0x00076E20
		public void DragStop()
		{
			this.RefreshColor();
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaScaleTransform(this.ShapeDot, 1.0 - ((ScaleTransform)this.ShapeDot.RenderTransform).ScaleX, 200, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false)
			}, "MySlider Scale " + Conversions.ToString(this.m_WorkerRequest), false);
			if (this.merchantRequest != null)
			{
				this.Popup.IsOpen = false;
			}
		}

		// Token: 0x060011EF RID: 4591 RVA: 0x00078CA8 File Offset: 0x00076EA8
		private void RefreshColor()
		{
			try
			{
				string text;
				int time;
				if (base.IsEnabled)
				{
					if (!base.IsMouseOver && (Information.IsNothing(RuntimeHelpers.GetObjectValue(ModMain._ParameterState)) || !ModMain._ParameterState.Equals(this)))
					{
						text = "ColorBrush1";
						time = 200;
					}
					else
					{
						text = "ColorBrush3";
						time = 100;
					}
				}
				else
				{
					text = "ColorBrushGray4";
					time = 200;
				}
				if (base.IsLoaded && ModAnimation.DefineModel() == 0)
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaColor(this, Border.BorderBrushProperty, text, time, 0, null, false)
					}, "MySlider Color " + Conversions.ToString(this.m_WorkerRequest), false);
				}
				else
				{
					ModAnimation.AniStop("MySlider Color " + Conversions.ToString(this.m_WorkerRequest));
					base.SetResourceReference(Border.BorderBrushProperty, text);
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "滑动条颜色改变出错", ModBase.LogLevel.Debug, "出现错误");
			}
		}

		// Token: 0x17000314 RID: 788
		// (get) Token: 0x060011F0 RID: 4592 RVA: 0x0000A8FB File Offset: 0x00008AFB
		// (set) Token: 0x060011F1 RID: 4593 RVA: 0x0000A903 File Offset: 0x00008B03
		public uint ValueByKey { get; set; }

		// Token: 0x060011F2 RID: 4594 RVA: 0x0000A90C File Offset: 0x00008B0C
		private void MySlider_MouseEnter()
		{
			base.Focus();
		}

		// Token: 0x060011F3 RID: 4595 RVA: 0x00078DA8 File Offset: 0x00076FA8
		private void MySlider_KeyDown(object sender, KeyEventArgs e)
		{
			checked
			{
				if (!object.ReferenceEquals(this, RuntimeHelpers.GetObjectValue(ModMain._ParameterState)))
				{
					if (e.Key == Key.Left)
					{
						this._ManagerRequest = true;
						this.Value = (int)(unchecked((long)this.Value) - (long)(unchecked((ulong)this.ValueByKey)));
						this._ManagerRequest = false;
						e.Handled = true;
					}
					else
					{
						if (e.Key != Key.Right)
						{
							return;
						}
						this._ManagerRequest = true;
						this.Value = (int)(unchecked((long)this.Value) + (long)(unchecked((ulong)this.ValueByKey)));
						this._ManagerRequest = false;
						e.Handled = true;
					}
					if (this.merchantRequest != null)
					{
						this.TextHint.Text = Conversions.ToString(this.merchantRequest.DynamicInvoke(new object[]
						{
							this.Value
						}));
						this.Popup.IsOpen = true;
						ModAnimation.AniStop("MySlider KeyPopup " + Conversions.ToString(this.m_WorkerRequest));
						ModAnimation.AniStart(ModAnimation.AaCode(delegate
						{
							this.Popup.IsOpen = false;
						}, (int)Math.Round(unchecked(700.0 * ModAnimation.m_Test)), false), "MySlider KeyPopup " + Conversions.ToString(this.m_WorkerRequest), false);
					}
				}
			}
		}

		// Token: 0x17000315 RID: 789
		// (get) Token: 0x060011F4 RID: 4596 RVA: 0x0000A915 File Offset: 0x00008B15
		// (set) Token: 0x060011F5 RID: 4597 RVA: 0x0000A91D File Offset: 0x00008B1D
		internal virtual MySlider PanBack { get; set; }

		// Token: 0x17000316 RID: 790
		// (get) Token: 0x060011F6 RID: 4598 RVA: 0x0000A926 File Offset: 0x00008B26
		// (set) Token: 0x060011F7 RID: 4599 RVA: 0x0000A92E File Offset: 0x00008B2E
		internal virtual Grid PanMain { get; set; }

		// Token: 0x17000317 RID: 791
		// (get) Token: 0x060011F8 RID: 4600 RVA: 0x0000A937 File Offset: 0x00008B37
		// (set) Token: 0x060011F9 RID: 4601 RVA: 0x0000A93F File Offset: 0x00008B3F
		internal virtual Line LineBack { get; set; }

		// Token: 0x17000318 RID: 792
		// (get) Token: 0x060011FA RID: 4602 RVA: 0x0000A948 File Offset: 0x00008B48
		// (set) Token: 0x060011FB RID: 4603 RVA: 0x0000A950 File Offset: 0x00008B50
		internal virtual Line LineFore { get; set; }

		// Token: 0x17000319 RID: 793
		// (get) Token: 0x060011FC RID: 4604 RVA: 0x0000A959 File Offset: 0x00008B59
		// (set) Token: 0x060011FD RID: 4605 RVA: 0x0000A961 File Offset: 0x00008B61
		internal virtual Ellipse ShapeDot { get; set; }

		// Token: 0x1700031A RID: 794
		// (get) Token: 0x060011FE RID: 4606 RVA: 0x0000A96A File Offset: 0x00008B6A
		// (set) Token: 0x060011FF RID: 4607 RVA: 0x0000A972 File Offset: 0x00008B72
		internal virtual Popup Popup { get; set; }

		// Token: 0x1700031B RID: 795
		// (get) Token: 0x06001200 RID: 4608 RVA: 0x0000A97B File Offset: 0x00008B7B
		// (set) Token: 0x06001201 RID: 4609 RVA: 0x0000A983 File Offset: 0x00008B83
		internal virtual TextBlock TextHint { get; set; }

		// Token: 0x06001202 RID: 4610 RVA: 0x00078EDC File Offset: 0x000770DC
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.serverRequest)
			{
				this.serverRequest = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/controls/myslider.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06001203 RID: 4611 RVA: 0x00078F0C File Offset: 0x0007710C
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MySlider)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanMain = (Grid)target;
				return;
			}
			if (connectionId == 3)
			{
				this.LineBack = (Line)target;
				return;
			}
			if (connectionId == 4)
			{
				this.LineFore = (Line)target;
				return;
			}
			if (connectionId == 5)
			{
				this.ShapeDot = (Ellipse)target;
				return;
			}
			if (connectionId == 6)
			{
				this.Popup = (Popup)target;
				return;
			}
			if (connectionId == 7)
			{
				this.TextHint = (TextBlock)target;
				return;
			}
			this.serverRequest = true;
		}

		// Token: 0x040008C9 RID: 2249
		public int m_WorkerRequest;

		// Token: 0x040008CA RID: 2250
		[CompilerGenerated]
		private MySlider.ChangeEventHandler dicRequest;

		// Token: 0x040008CB RID: 2251
		[CompilerGenerated]
		private MySlider.PreviewChangeEventHandler _ConfigurationRequest;

		// Token: 0x040008CC RID: 2252
		private int m_ConfigRequest;

		// Token: 0x040008CD RID: 2253
		private bool _ManagerRequest;

		// Token: 0x040008CE RID: 2254
		private int m_RuleRequest;

		// Token: 0x040008CF RID: 2255
		public Delegate merchantRequest;

		// Token: 0x040008D0 RID: 2256
		[CompilerGenerated]
		private uint m_ExporterRequest;

		// Token: 0x040008D1 RID: 2257
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MySlider _QueueRequest;

		// Token: 0x040008D2 RID: 2258
		[AccessedThroughProperty("PanMain")]
		[CompilerGenerated]
		private Grid _GlobalRequest;

		// Token: 0x040008D3 RID: 2259
		[CompilerGenerated]
		[AccessedThroughProperty("LineBack")]
		private Line m_ListRequest;

		// Token: 0x040008D4 RID: 2260
		[AccessedThroughProperty("LineFore")]
		[CompilerGenerated]
		private Line _MethodRequest;

		// Token: 0x040008D5 RID: 2261
		[CompilerGenerated]
		[AccessedThroughProperty("ShapeDot")]
		private Ellipse m_AnnotationRequest;

		// Token: 0x040008D6 RID: 2262
		[AccessedThroughProperty("Popup")]
		[CompilerGenerated]
		private Popup _InterceptorRequest;

		// Token: 0x040008D7 RID: 2263
		[CompilerGenerated]
		[AccessedThroughProperty("TextHint")]
		private TextBlock _RefRequest;

		// Token: 0x040008D8 RID: 2264
		private bool serverRequest;

		// Token: 0x02000186 RID: 390
		// (Invoke) Token: 0x0600120D RID: 4621
		public delegate void ChangeEventHandler(object sender, bool user);

		// Token: 0x02000187 RID: 391
		// (Invoke) Token: 0x06001212 RID: 4626
		public delegate void PreviewChangeEventHandler(object sender, ModBase.RouteEventArgs e);
	}
}
