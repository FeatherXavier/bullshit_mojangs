﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200005B RID: 91
	public class MyTextBox : TextBox
	{
		// Token: 0x060002B6 RID: 694 RVA: 0x000180D0 File Offset: 0x000162D0
		public MyTextBox()
		{
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.Validate();
			};
			base.TextChanged += delegate(object sender, TextChangedEventArgs e)
			{
				this.MyTextBox_TextChanged((MyTextBox)sender, e);
			};
			base.IsEnabledChanged += delegate(object sender, DependencyPropertyChangedEventArgs e)
			{
				this.RefreshColor();
			};
			base.MouseEnter += delegate(object sender, MouseEventArgs e)
			{
				this.RefreshColor();
			};
			base.MouseLeave += delegate(object sender, MouseEventArgs e)
			{
				this.RefreshColor();
			};
			base.GotFocus += delegate(object sender, RoutedEventArgs e)
			{
				this.RefreshColor();
			};
			base.LostFocus += delegate(object sender, RoutedEventArgs e)
			{
				this.RefreshColor();
			};
			base.IsEnabledChanged += delegate(object sender, DependencyPropertyChangedEventArgs e)
			{
				this.RefreshTextColor();
			};
			this.HasAnimation = true;
			this.ShowValidateResult = true;
			this._AlgoWrapper = null;
			this.poolWrapper = null;
			this.publisherWrapper = ModBase.GetUuid();
			this.m_TaskWrapper = new List<RoutedEventHandler>();
			this.m_SerializerWrapper = new Collection<Validate>();
			this._RoleWrapper = -1;
			this.valueWrapper = false;
			this.m_RecordWrapper = "";
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x060002B7 RID: 695 RVA: 0x000038D4 File Offset: 0x00001AD4
		// (set) Token: 0x060002B8 RID: 696 RVA: 0x000038DC File Offset: 0x00001ADC
		public bool HasAnimation { get; set; }

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x060002B9 RID: 697 RVA: 0x000038E5 File Offset: 0x00001AE5
		// (set) Token: 0x060002BA RID: 698 RVA: 0x000038ED File Offset: 0x00001AED
		public bool ShowValidateResult { get; set; }

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x060002BB RID: 699 RVA: 0x000181CC File Offset: 0x000163CC
		private TextBlock labWrong
		{
			get
			{
				TextBlock result;
				if (base.Template == null)
				{
					result = null;
				}
				else
				{
					if (this._AlgoWrapper == null)
					{
						this._AlgoWrapper = (TextBlock)base.Template.FindName("labWrong", this);
					}
					result = this._AlgoWrapper;
				}
				return result;
			}
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x060002BC RID: 700 RVA: 0x00018214 File Offset: 0x00016414
		private TextBlock labHint
		{
			get
			{
				TextBlock result;
				if (base.Template == null)
				{
					result = null;
				}
				else
				{
					if (this.poolWrapper == null)
					{
						this.poolWrapper = (TextBlock)base.Template.FindName("labHint", this);
					}
					result = this.poolWrapper;
				}
				return result;
			}
		}

		// Token: 0x060002BD RID: 701 RVA: 0x0001825C File Offset: 0x0001645C
		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();
			if (Operators.CompareString(this.HintText, "", true) != 0 && Operators.CompareString(this.labHint.Text, "", true) == 0)
			{
				this.labHint.Text = ((Operators.CompareString(base.Text, "", true) == 0) ? this.HintText : "");
			}
		}

		// Token: 0x060002BE RID: 702 RVA: 0x000182C8 File Offset: 0x000164C8
		[CompilerGenerated]
		public static void PostWrapper(MyTextBox.ValidateChangedEventHandler obj)
		{
			MyTextBox.ValidateChangedEventHandler validateChangedEventHandler = MyTextBox.watcherWrapper;
			MyTextBox.ValidateChangedEventHandler validateChangedEventHandler2;
			do
			{
				validateChangedEventHandler2 = validateChangedEventHandler;
				MyTextBox.ValidateChangedEventHandler value = (MyTextBox.ValidateChangedEventHandler)Delegate.Combine(validateChangedEventHandler2, obj);
				validateChangedEventHandler = Interlocked.CompareExchange<MyTextBox.ValidateChangedEventHandler>(ref MyTextBox.watcherWrapper, value, validateChangedEventHandler2);
			}
			while (validateChangedEventHandler != validateChangedEventHandler2);
		}

		// Token: 0x060002BF RID: 703 RVA: 0x000182FC File Offset: 0x000164FC
		[CompilerGenerated]
		public static void RevertWrapper(MyTextBox.ValidateChangedEventHandler obj)
		{
			MyTextBox.ValidateChangedEventHandler validateChangedEventHandler = MyTextBox.watcherWrapper;
			MyTextBox.ValidateChangedEventHandler validateChangedEventHandler2;
			do
			{
				validateChangedEventHandler2 = validateChangedEventHandler;
				MyTextBox.ValidateChangedEventHandler value = (MyTextBox.ValidateChangedEventHandler)Delegate.Remove(validateChangedEventHandler2, obj);
				validateChangedEventHandler = Interlocked.CompareExchange<MyTextBox.ValidateChangedEventHandler>(ref MyTextBox.watcherWrapper, value, validateChangedEventHandler2);
			}
			while (validateChangedEventHandler != validateChangedEventHandler2);
		}

		// Token: 0x060002C0 RID: 704 RVA: 0x000038F6 File Offset: 0x00001AF6
		public void SetupRepository(RoutedEventHandler value)
		{
			this.m_TaskWrapper.Add(value);
		}

		// Token: 0x060002C1 RID: 705 RVA: 0x00003904 File Offset: 0x00001B04
		public void FindRepository(RoutedEventHandler value)
		{
			this.m_TaskWrapper.Remove(value);
		}

		// Token: 0x060002C2 RID: 706 RVA: 0x00018330 File Offset: 0x00016530
		private void raise_ValidatedTextChanged(object sender, TextChangedEventArgs e)
		{
			try
			{
				foreach (RoutedEventHandler routedEventHandler in this.m_TaskWrapper)
				{
					if (!Information.IsNothing(routedEventHandler))
					{
						routedEventHandler(RuntimeHelpers.GetObjectValue(sender), e);
					}
				}
			}
			finally
			{
				List<RoutedEventHandler>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x060002C3 RID: 707 RVA: 0x00003913 File Offset: 0x00001B13
		// (set) Token: 0x060002C4 RID: 708 RVA: 0x00003925 File Offset: 0x00001B25
		public string ValidateResult
		{
			get
			{
				return Conversions.ToString(base.GetValue(MyTextBox.iteratorWrapper));
			}
			set
			{
				base.SetValue(MyTextBox.iteratorWrapper, value);
			}
		}

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x060002C5 RID: 709 RVA: 0x00003933 File Offset: 0x00001B33
		// (set) Token: 0x060002C6 RID: 710 RVA: 0x0000393B File Offset: 0x00001B3B
		public Collection<Validate> ValidateRules
		{
			get
			{
				return this.m_SerializerWrapper;
			}
			set
			{
				this.m_SerializerWrapper = value;
				this.Validate();
			}
		}

		// Token: 0x060002C7 RID: 711 RVA: 0x00018394 File Offset: 0x00016594
		public void Validate()
		{
			MyTextBox._Closure$__36-0 CS$<>8__locals1 = new MyTextBox._Closure$__36-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Me = this;
			this.ValidateResult = "";
			try
			{
				foreach (Validate validate in this.ValidateRules)
				{
					this.ValidateResult = validate.Validate(base.Text);
					if (Information.IsNothing(this.ValidateResult))
					{
						break;
					}
					if (Operators.CompareString(this.ValidateResult, "", true) != 0)
					{
						break;
					}
				}
			}
			finally
			{
				IEnumerator<Validate> enumerator;
				if (enumerator != null)
				{
					enumerator.Dispose();
				}
			}
			CS$<>8__locals1.$VB$Local_NewResult = ((Operators.CompareString(this.ValidateResult, "", true) == 0) ? 0 : 1);
			if (this._RoleWrapper != CS$<>8__locals1.$VB$Local_NewResult)
			{
				if (base.IsLoaded && this.labWrong != null)
				{
					this.ChangeValidateResult(Operators.CompareString(this.ValidateResult, "", true) == 0, true);
				}
				else
				{
					ModBase.RunInNewThread(delegate
					{
						Thread.Sleep(30);
						ModBase.RunInUi((CS$<>8__locals1.$I1 == null) ? (CS$<>8__locals1.$I1 = delegate()
						{
							CS$<>8__locals1.$VB$Me.ChangeValidateResult(CS$<>8__locals1.$VB$Local_NewResult != 0, false);
						}) : CS$<>8__locals1.$I1, false);
					}, "DelayedValidate Change", ThreadPriority.Normal);
				}
			}
			if (this.ShowValidateResult && Operators.CompareString(this.ValidateResult, "", true) != 0)
			{
				if (base.IsLoaded && this.labWrong != null)
				{
					this.labWrong.Text = this.ValidateResult;
					return;
				}
				ModBase.RunInNewThread(delegate
				{
					MyTextBox._Closure$__36-1 CS$<>8__locals2 = new MyTextBox._Closure$__36-1(CS$<>8__locals2);
					CS$<>8__locals2.$VB$Me = this;
					CS$<>8__locals2.$VB$Local_IsFinished = false;
					while (!CS$<>8__locals2.$VB$Local_IsFinished)
					{
						Thread.Sleep(20);
						ModBase.RunInUiWait(delegate
						{
							if (CS$<>8__locals2.$VB$Me.labWrong != null)
							{
								CS$<>8__locals2.$VB$Me.labWrong.Text = CS$<>8__locals2.$VB$Me.ValidateResult;
								CS$<>8__locals2.$VB$Local_IsFinished = true;
							}
							if (!CS$<>8__locals2.$VB$Me.IsLoaded)
							{
								CS$<>8__locals2.$VB$Local_IsFinished = true;
							}
						});
					}
				}, "DelayedValidate Text", ThreadPriority.Normal);
			}
		}

		// Token: 0x060002C8 RID: 712 RVA: 0x000184F0 File Offset: 0x000166F0
		private void ChangeValidateResult(bool NewResult, bool IsLoaded)
		{
			if (IsLoaded && ModAnimation.DefineModel() == 0 && this.valueWrapper && this.labWrong != null)
			{
				if (NewResult)
				{
					this._RoleWrapper = 0;
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaOpacity(this.labWrong, -this.labWrong.Opacity, 150, 0, null, false),
						ModAnimation.AaHeight(this.labWrong, -this.labWrong.Height, 150, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
						ModAnimation.AaCode(delegate
						{
							this.labWrong.Visibility = Visibility.Collapsed;
						}, 0, true)
					}, "MyTextBox Validate " + Conversions.ToString(this.publisherWrapper), false);
				}
				else if (this.ShowValidateResult)
				{
					this._RoleWrapper = 1;
					this.labWrong.Visibility = Visibility.Visible;
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaOpacity(this.labWrong, 1.0 - this.labWrong.Opacity, 170, 0, null, false),
						ModAnimation.AaHeight(this.labWrong, 21.0 - this.labWrong.Height, 300, 0, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Weak), false)
					}, "MyTextBox Validate " + Conversions.ToString(this.publisherWrapper), false);
				}
				else
				{
					this._RoleWrapper = 2;
				}
			}
			else
			{
				this._RoleWrapper = 3;
			}
			this.RefreshColor();
			MyTextBox.ValidateChangedEventHandler validateChangedEventHandler = MyTextBox.watcherWrapper;
			if (validateChangedEventHandler != null)
			{
				validateChangedEventHandler(this, new EventArgs());
			}
		}

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x060002C9 RID: 713 RVA: 0x0000394A File Offset: 0x00001B4A
		// (set) Token: 0x060002CA RID: 714 RVA: 0x00003952 File Offset: 0x00001B52
		public string HintText
		{
			get
			{
				return this.m_RecordWrapper;
			}
			set
			{
				this.m_RecordWrapper = value;
				if (this.labHint != null)
				{
					this.labHint.Text = ((Operators.CompareString(base.Text, "", true) == 0) ? this.HintText : "");
				}
			}
		}

		// Token: 0x060002CB RID: 715 RVA: 0x00018690 File Offset: 0x00016890
		private void MyTextBox_TextChanged(MyTextBox sender, TextChangedEventArgs e)
		{
			try
			{
				if (this.labHint != null)
				{
					this.labHint.Text = ((Operators.CompareString(base.Text, "", true) == 0) ? this.HintText : "");
				}
				this.valueWrapper = base.IsLoaded;
				this.Validate();
				if (Operators.CompareString(this.ValidateResult, "", true) == 0)
				{
					this.raise_ValidatedTextChanged(sender, e);
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "进行输入验证时出错", ModBase.LogLevel.Assert, "出现错误");
			}
		}

		// Token: 0x060002CC RID: 716 RVA: 0x00018730 File Offset: 0x00016930
		private void RefreshColor()
		{
			try
			{
				if (this.HasAnimation)
				{
					if (base.TemplatedParent == null || !(base.TemplatedParent is MyComboBox))
					{
						string text;
						string text2;
						int time;
						if (base.IsEnabled)
						{
							if (Operators.CompareString(this.ValidateResult, "", true) != 0 && this.valueWrapper)
							{
								text = "ColorBrushRedLight";
								text2 = "ColorBrushRedBack";
								time = 200;
							}
							else if (base.IsFocused)
							{
								text = "ColorBrush4";
								text2 = "ColorBrush9";
								time = 60;
							}
							else if (base.IsMouseOver)
							{
								text = "ColorBrush3";
								text2 = "ColorBrushHalfWhite";
								time = 100;
							}
							else
							{
								text = "ColorBrush1";
								text2 = "ColorBrushHalfWhite";
								time = 200;
							}
						}
						else
						{
							text = "ColorBrushGray4";
							text2 = "ColorBrushHalfWhite";
							time = 200;
						}
						if (base.IsLoaded && ModAnimation.DefineModel() == 0)
						{
							ModAnimation.AniStart(new ModAnimation.AniData[]
							{
								ModAnimation.AaColor(this, Control.BorderBrushProperty, text, time, 0, null, false),
								ModAnimation.AaColor(this, Control.BackgroundProperty, text2, time, 0, null, false)
							}, "MyTextBox Color " + Conversions.ToString(this.publisherWrapper), false);
						}
						else
						{
							ModAnimation.AniStop("MyTextBox Color " + Conversions.ToString(this.publisherWrapper));
							base.SetResourceReference(Control.BorderBrushProperty, text);
							base.SetResourceReference(Control.BackgroundProperty, text2);
						}
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "文本框颜色改变出错", ModBase.LogLevel.Debug, "出现错误");
			}
		}

		// Token: 0x060002CD RID: 717 RVA: 0x000188C4 File Offset: 0x00016AC4
		private void RefreshTextColor()
		{
			ModBase.MyColor myColor = base.IsEnabled ? ModMain.mapperAccount : ModMain._ValAccount;
			if ((double)((SolidColorBrush)base.Foreground).Color.R != myColor.m_RulesParameter)
			{
				if (base.IsLoaded && ModAnimation.DefineModel() == 0 && Operators.CompareString(base.Text, "", true) != 0)
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaColor(this, Control.ForegroundProperty, base.IsEnabled ? "ColorBrushGray1" : "ColorBrushGray4", 200, 0, null, false)
					}, "MyTextBox TextColor " + Conversions.ToString(this.publisherWrapper), false);
					return;
				}
				ModAnimation.AniStop("MyTextBox TextColor " + Conversions.ToString(this.publisherWrapper));
				base.Foreground = myColor;
			}
		}

		// Token: 0x04000123 RID: 291
		[CompilerGenerated]
		private bool _DescriptorWrapper;

		// Token: 0x04000124 RID: 292
		[CompilerGenerated]
		private bool eventWrapper;

		// Token: 0x04000125 RID: 293
		private TextBlock _AlgoWrapper;

		// Token: 0x04000126 RID: 294
		private TextBlock poolWrapper;

		// Token: 0x04000127 RID: 295
		public int publisherWrapper;

		// Token: 0x04000128 RID: 296
		[CompilerGenerated]
		private static MyTextBox.ValidateChangedEventHandler watcherWrapper;

		// Token: 0x04000129 RID: 297
		public List<RoutedEventHandler> m_TaskWrapper;

		// Token: 0x0400012A RID: 298
		public static readonly DependencyProperty iteratorWrapper = DependencyProperty.Register("ValidateResult", typeof(string), typeof(MyTextBox), new PropertyMetadata(""));

		// Token: 0x0400012B RID: 299
		private Collection<Validate> m_SerializerWrapper;

		// Token: 0x0400012C RID: 300
		private int _RoleWrapper;

		// Token: 0x0400012D RID: 301
		private bool valueWrapper;

		// Token: 0x0400012E RID: 302
		private string m_RecordWrapper;

		// Token: 0x0200005C RID: 92
		// (Invoke) Token: 0x060002DB RID: 731
		public delegate void ValidateChangedEventHandler(object sender, EventArgs e);
	}
}
