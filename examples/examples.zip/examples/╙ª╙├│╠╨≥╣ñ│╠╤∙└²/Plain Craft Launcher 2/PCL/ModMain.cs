﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic.FileIO;
using Newtonsoft.Json.Linq;
using PCL.My;

namespace PCL
{
	// Token: 0x02000196 RID: 406
	[StandardModule]
	public sealed class ModMain
	{
		// Token: 0x06001316 RID: 4886 RVA: 0x0007DE50 File Offset: 0x0007C050
		public static void Hint(string Text, ModMain.HintType Type = ModMain.HintType.Info, bool Log = true)
		{
			if (ModMain.expressionAccount == null)
			{
				ModMain.expressionAccount = new List<ModMain.HintMessage>();
			}
			ModMain.expressionAccount.Add(new ModMain.HintMessage
			{
				regParameter = Text,
				Type = Type,
				invocationParameter = Log
			});
		}

		// Token: 0x06001317 RID: 4887 RVA: 0x0007DE9C File Offset: 0x0007C09C
		private static void HintTick()
		{
			try
			{
				if (ModMain.expressionAccount.Count != 0)
				{
					while (ModMain.expressionAccount.Count > 0)
					{
						ModMain._Closure$__5-0 CS$<>8__locals1 = new ModMain._Closure$__5-0(CS$<>8__locals1);
						ModMain.HintMessage hintMessage = ModMain.expressionAccount[0];
						hintMessage.regParameter = hintMessage.regParameter.Replace("\r\n", " ").Replace("\r", " ").Replace("\n", " ");
						if (ModMain.m_CollectionAccount.PanHint.Children.Count < 20)
						{
							CS$<>8__locals1.$VB$Local_DoubleStack = null;
							try
							{
								foreach (object obj in ModMain.m_CollectionAccount.PanHint.Children)
								{
									Border border = (Border)obj;
									if (Conversions.ToBoolean(Conversions.ToBoolean(NewLateBinding.LateIndexGet(border.Tag, new object[]
									{
										0
									}, null)) && Operators.CompareString(((TextBlock)border.Child).Text, hintMessage.regParameter, true) == 0))
									{
										CS$<>8__locals1.$VB$Local_DoubleStack = border;
									}
								}
							}
							finally
							{
								IEnumerator enumerator;
								if (enumerator is IDisposable)
								{
									(enumerator as IDisposable).Dispose();
								}
							}
							if (!Information.IsNothing(CS$<>8__locals1.$VB$Local_DoubleStack))
							{
								if (!ModAnimation.AniIsRun(Conversions.ToString(Operators.ConcatenateObject("Hint Show ", NewLateBinding.LateIndexGet(CS$<>8__locals1.$VB$Local_DoubleStack.Tag, new object[]
								{
									1
								}, null)))))
								{
									ModAnimation.AniStop(Conversions.ToString(Operators.ConcatenateObject("Hint Hide ", NewLateBinding.LateIndexGet(CS$<>8__locals1.$VB$Local_DoubleStack.Tag, new object[]
									{
										1
									}, null))));
									double a = (800.0 + ModBase.MathRange((double)hintMessage.regParameter.Length, 5.0, 23.0) * 180.0) * ModAnimation.m_Test;
									ModAnimation.AniStart(checked(new ModAnimation.AniData[]
									{
										ModAnimation.AaX(CS$<>8__locals1.$VB$Local_DoubleStack, unchecked(-12.0 - CS$<>8__locals1.$VB$Local_DoubleStack.Margin.Left), 50, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
										ModAnimation.AaX(CS$<>8__locals1.$VB$Local_DoubleStack, -8.0, 50, 50, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
										ModAnimation.AaX(CS$<>8__locals1.$VB$Local_DoubleStack, 8.0, 50, 100, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
										ModAnimation.AaX(CS$<>8__locals1.$VB$Local_DoubleStack, -8.0, 50, 150, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
										ModAnimation.AaX(CS$<>8__locals1.$VB$Local_DoubleStack, -50.0, 200, (int)Math.Round(a), new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
										ModAnimation.AaOpacity(CS$<>8__locals1.$VB$Local_DoubleStack, -1.0, 150, (int)Math.Round(a), null, false),
										ModAnimation.AaCode(delegate
										{
											NewLateBinding.LateIndexSetComplex(CS$<>8__locals1.$VB$Local_DoubleStack.Tag, new object[]
											{
												0,
												false
											}, null, false, true);
										}, (int)Math.Round(a), false),
										ModAnimation.AaHeight(CS$<>8__locals1.$VB$Local_DoubleStack, -26.0, 100, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), true),
										ModAnimation.AaCode(delegate
										{
											ModMain.m_CollectionAccount.PanHint.Children.Remove(CS$<>8__locals1.$VB$Local_DoubleStack);
										}, 0, true)
									}), Conversions.ToString(Operators.ConcatenateObject("Hint Hide ", NewLateBinding.LateIndexGet(CS$<>8__locals1.$VB$Local_DoubleStack.Tag, new object[]
									{
										1
									}, null))), false);
								}
							}
							else
							{
								ModMain._Closure$__5-1 CS$<>8__locals2 = new ModMain._Closure$__5-1(CS$<>8__locals2);
								CS$<>8__locals2.$VB$Local_NewHintControl = new Border
								{
									Tag = new object[]
									{
										true,
										ModBase.GetUuid()
									},
									Margin = new Thickness(-70.0, 0.0, 20.0, 0.0),
									Opacity = 0.0,
									Height = 0.0,
									HorizontalAlignment = HorizontalAlignment.Left,
									CornerRadius = new CornerRadius(0.0, 6.0, 6.0, 0.0)
								};
								switch (hintMessage.Type)
								{
								case ModMain.HintType.Info:
									CS$<>8__locals2.$VB$Local_NewHintControl.Background = new LinearGradientBrush(new GradientStopCollection(new List<GradientStop>
									{
										new GradientStop(new ModBase.MyColor(10.0, 142.0, 252.0), 1.0),
										new GradientStop(new ModBase.MyColor(37.0, 155.0, 252.0), 0.0)
									}), 90.0);
									break;
								case ModMain.HintType.Finish:
									CS$<>8__locals2.$VB$Local_NewHintControl.Background = new LinearGradientBrush(new GradientStopCollection(new List<GradientStop>
									{
										new GradientStop(new ModBase.MyColor(29.0, 160.0, 29.0), 1.0),
										new GradientStop(new ModBase.MyColor(33.0, 177.0, 33.0), 0.0)
									}), 90.0);
									break;
								case ModMain.HintType.Critical:
									CS$<>8__locals2.$VB$Local_NewHintControl.Background = new LinearGradientBrush(new GradientStopCollection(new List<GradientStop>
									{
										new GradientStop(new ModBase.MyColor(244.0, 43.0, 0.0), 1.0),
										new GradientStop(new ModBase.MyColor(255.0, 53.0, 11.0), 0.0)
									}), 90.0);
									ModBase.m_AlgoState = true;
									break;
								default:
									ModBase.DebugAssert(false);
									break;
								}
								CS$<>8__locals2.$VB$Local_NewHintControl.Child = new TextBlock
								{
									TextTrimming = TextTrimming.CharacterEllipsis,
									FontSize = 13.0,
									Text = hintMessage.regParameter,
									Foreground = new ModBase.MyColor(255.0, 255.0, 255.0),
									Margin = new Thickness(33.0, 5.0, 8.0, 5.0)
								};
								ModMain.m_CollectionAccount.PanHint.Children.Add(CS$<>8__locals2.$VB$Local_NewHintControl);
								List<ModAnimation.AniData> list = new List<ModAnimation.AniData>();
								if (ModMain.m_CollectionAccount.PanHint.Children.Count > 1)
								{
									list.Add(ModAnimation.AaHeight(CS$<>8__locals2.$VB$Local_NewHintControl, 26.0, 150, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false));
								}
								else
								{
									CS$<>8__locals2.$VB$Local_NewHintControl.Height = 26.0;
								}
								list.AddRange(new ModAnimation.AniData[]
								{
									ModAnimation.AaX(CS$<>8__locals2.$VB$Local_NewHintControl, 30.0, 500, 0, new ModAnimation.AniEaseOutElastic(ModAnimation.AniEasePower.Weak), false),
									ModAnimation.AaX(CS$<>8__locals2.$VB$Local_NewHintControl, 20.0, 250, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
									ModAnimation.AaOpacity(CS$<>8__locals2.$VB$Local_NewHintControl, 1.0, 150, 100, null, false)
								});
								ModAnimation.AniStart(list, Conversions.ToString(Operators.ConcatenateObject("Hint Show ", NewLateBinding.LateIndexGet(CS$<>8__locals2.$VB$Local_NewHintControl.Tag, new object[]
								{
									1
								}, null))), false);
								double a2 = (800.0 + ModBase.MathRange((double)hintMessage.regParameter.Length, 5.0, 23.0) * 180.0) * ModAnimation.m_Test;
								ModAnimation.AniStart(checked(new ModAnimation.AniData[]
								{
									ModAnimation.AaX(CS$<>8__locals2.$VB$Local_NewHintControl, -50.0, 200, (int)Math.Round(a2), new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
									ModAnimation.AaOpacity(CS$<>8__locals2.$VB$Local_NewHintControl, -1.0, 150, (int)Math.Round(a2), null, false),
									ModAnimation.AaCode(delegate
									{
										NewLateBinding.LateIndexSetComplex(CS$<>8__locals2.$VB$Local_NewHintControl.Tag, new object[]
										{
											0,
											false
										}, null, false, true);
									}, (int)Math.Round(a2), false),
									ModAnimation.AaHeight(CS$<>8__locals2.$VB$Local_NewHintControl, -26.0, 100, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), true),
									ModAnimation.AaCode(delegate
									{
										ModMain.m_CollectionAccount.PanHint.Children.Remove(CS$<>8__locals2.$VB$Local_NewHintControl);
									}, 0, true)
								}), Conversions.ToString(Operators.ConcatenateObject("Hint Hide ", NewLateBinding.LateIndexGet(CS$<>8__locals2.$VB$Local_NewHintControl.Tag, new object[]
								{
									1
								}, null))), false);
							}
						}
						if (hintMessage.invocationParameter)
						{
							ModBase.Log("[UI] 弹出提示：" + hintMessage.regParameter, ModBase.LogLevel.Normal, "出现错误");
						}
						ModMain.expressionAccount.RemoveAt(0);
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "显示弹出提示失败", ModBase.LogLevel.Normal, "出现错误");
			}
		}

		// Token: 0x06001318 RID: 4888 RVA: 0x0007E878 File Offset: 0x0007CA78
		public static int MyMsgBox(string Caption, string Title = "提示", string Button1 = "确定", string Button2 = "", string Button3 = "", bool IsWarn = false, bool HighLight = true, bool ForceWait = false)
		{
			ModMain.MyMsgBoxConverter myMsgBoxConverter = new ModMain.MyMsgBoxConverter
			{
				Type = ModMain.MyMsgBoxType.Text,
				_ProcessParameter = Button1,
				_ValParameter = Button2,
				utilsParameter = Button3,
				m_ComposerParameter = Caption,
				m_OrderParameter = IsWarn,
				Title = Title,
				factoryParameter = HighLight,
				_PolicyParameter = true
			};
			ModMain._GetterAccount.Add(myMsgBoxConverter);
			if (ModBase.RunInUi())
			{
				ModMain.MyMsgBoxTick();
			}
			checked
			{
				int result;
				if (Button2.Length <= 0 && !ForceWait)
				{
					result = 1;
				}
				else
				{
					if (ModMain.m_CollectionAccount != null && (ModMain.m_CollectionAccount.PanMsg != null || !ModBase.RunInUi()))
					{
						try
						{
							ModMain.m_CollectionAccount.DragStop();
							ComponentDispatcher.PushModal();
							Dispatcher.PushFrame(myMsgBoxConverter.m_ThreadParameter);
							goto IL_17D;
						}
						finally
						{
							ComponentDispatcher.PopModal();
						}
					}
					ModMain._GetterAccount.Remove(myMsgBoxConverter);
					if (Button2.Length > 0)
					{
						MsgBoxResult msgBoxResult = Interaction.MsgBox(Caption, ((Button3.Length > 0) ? MsgBoxStyle.YesNoCancel : MsgBoxStyle.YesNo) + (IsWarn ? 16 : 32), Title);
						if (msgBoxResult != MsgBoxResult.Cancel)
						{
							if (msgBoxResult != MsgBoxResult.Yes)
							{
								if (msgBoxResult == MsgBoxResult.No)
								{
									myMsgBoxConverter._CustomerParameter = 2;
								}
							}
							else
							{
								myMsgBoxConverter._CustomerParameter = 1;
							}
						}
						else
						{
							myMsgBoxConverter._CustomerParameter = 3;
						}
					}
					else
					{
						Interaction.MsgBox(Caption, MsgBoxStyle.OkOnly + (IsWarn ? 16 : 32), Title);
						myMsgBoxConverter._CustomerParameter = 1;
					}
					ModBase.Log(string.Concat(new string[]
					{
						"[Control] 主窗体加载完成前出现意料外的等待弹窗：",
						Button1,
						",",
						Button2,
						",",
						Button3
					}), ModBase.LogLevel.Debug, "出现错误");
					IL_17D:
					ModBase.Log(Conversions.ToString(Operators.ConcatenateObject("[Control] 普通弹框返回：", myMsgBoxConverter._CustomerParameter ?? "null")), ModBase.LogLevel.Normal, "出现错误");
					result = Conversions.ToInteger(myMsgBoxConverter._CustomerParameter);
				}
				return result;
			}
		}

		// Token: 0x06001319 RID: 4889 RVA: 0x0007EA48 File Offset: 0x0007CC48
		public static string MyMsgBoxInput(string Caption, Collection<Validate> ValidateRules, string HintText = "", string Title = "提示", string Button1 = "确定", string Button2 = "", bool IsWarn = false)
		{
			ModMain.MyMsgBoxConverter myMsgBoxConverter = new ModMain.MyMsgBoxConverter
			{
				mapperParameter = HintText,
				Type = ModMain.MyMsgBoxType.Input,
				itemParameter = ValidateRules,
				_ProcessParameter = Button1,
				_ValParameter = Button2,
				m_ComposerParameter = Caption,
				m_OrderParameter = IsWarn,
				Title = Title
			};
			ModMain._GetterAccount.Add(myMsgBoxConverter);
			try
			{
				if (ModMain.m_CollectionAccount != null)
				{
					ModMain.m_CollectionAccount.DragStop();
				}
				ComponentDispatcher.PushModal();
				Dispatcher.PushFrame(myMsgBoxConverter.m_ThreadParameter);
			}
			finally
			{
				ComponentDispatcher.PopModal();
			}
			ModBase.Log(Conversions.ToString(Operators.ConcatenateObject("[Control] 输入弹框返回：", myMsgBoxConverter._CustomerParameter ?? "null")), ModBase.LogLevel.Normal, "出现错误");
			return Conversions.ToString(myMsgBoxConverter._CustomerParameter);
		}

		// Token: 0x0600131A RID: 4890 RVA: 0x0007EB10 File Offset: 0x0007CD10
		public static int? MyMsgBoxSelect(List<IMyRadio> Selections, string Title = "提示", string Button1 = "确定", string Button2 = "", bool IsWarn = false)
		{
			ModMain.MyMsgBoxConverter myMsgBoxConverter = new ModMain.MyMsgBoxConverter
			{
				Type = ModMain.MyMsgBoxType.Select,
				_ProcessParameter = Button1,
				_ValParameter = Button2,
				m_ComposerParameter = Selections,
				m_OrderParameter = IsWarn,
				Title = Title
			};
			ModMain._GetterAccount.Add(myMsgBoxConverter);
			try
			{
				if (ModMain.m_CollectionAccount != null)
				{
					ModMain.m_CollectionAccount.DragStop();
				}
				ComponentDispatcher.PushModal();
				Dispatcher.PushFrame(myMsgBoxConverter.m_ThreadParameter);
			}
			finally
			{
				ComponentDispatcher.PopModal();
			}
			ModBase.Log(Conversions.ToString(Operators.ConcatenateObject("[Control] 选择弹框返回：", myMsgBoxConverter._CustomerParameter ?? "null")), ModBase.LogLevel.Normal, "出现错误");
			return (int?)myMsgBoxConverter._CustomerParameter;
		}

		// Token: 0x0600131B RID: 4891 RVA: 0x0007EBC8 File Offset: 0x0007CDC8
		public static void MyMsgBoxTick()
		{
			try
			{
				if (ModMain.m_CollectionAccount != null && ModMain.m_CollectionAccount.PanMsg != null)
				{
					if (ModMain.m_CollectionAccount.WindowState != WindowState.Minimized)
					{
						if (ModMain.m_CollectionAccount.PanMsg.Children.Count > 0)
						{
							ModMain.m_CollectionAccount.PanMsg.Visibility = Visibility.Visible;
						}
						else if (ModMain._GetterAccount.Count > 0)
						{
							ModMain.m_CollectionAccount.PanMsg.Visibility = Visibility.Visible;
							switch (ModMain._GetterAccount[0].Type)
							{
							case ModMain.MyMsgBoxType.Text:
								ModMain.m_CollectionAccount.PanMsg.Children.Add(new MyMsgText(ModMain._GetterAccount[0]));
								break;
							case ModMain.MyMsgBoxType.Select:
								ModMain.m_CollectionAccount.PanMsg.Children.Add(new MyMsgSelect(ModMain._GetterAccount[0]));
								break;
							case ModMain.MyMsgBoxType.Input:
								ModMain.m_CollectionAccount.PanMsg.Children.Add(new MyMsgInput(ModMain._GetterAccount[0]));
								break;
							}
							ModMain._GetterAccount.RemoveAt(0);
						}
						else if (ModMain.m_CollectionAccount.PanMsg.Visibility != Visibility.Collapsed)
						{
							ModMain.m_CollectionAccount.PanMsg.Visibility = Visibility.Collapsed;
						}
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "处理等待中的弹窗失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x0600131C RID: 4892 RVA: 0x0007ED54 File Offset: 0x0007CF54
		public static void CompareTag(int ident_counter = -1)
		{
			try
			{
				if (ModMain.customerAccount != ident_counter || ident_counter < 0)
				{
					if (ident_counter >= 0)
					{
						ModMain.customerAccount = ident_counter;
					}
					switch (ModMain.m_ObserverAccount)
					{
					case 1:
						ModMain._CallbackAccount = 999;
						break;
					case 2:
						ModMain.m_SchemaAccount = ModBase.RandomInteger(0, 359);
						ModMain._DatabaseAccount = ModBase.RandomInteger(40, 70);
						ModMain._CallbackAccount = ModBase.RandomInteger(-20, 20);
						break;
					}
					ModMain._ListenerAccount = new ModBase.MyColor().FromHSL2((double)ModMain.m_SchemaAccount, (double)ModMain._DatabaseAccount * 0.2, 25.0 + (double)ModMain._CallbackAccount * 0.3);
					checked
					{
						ModMain._IdentifierAccount = new ModBase.MyColor().FromHSL2((double)ModMain.m_SchemaAccount, (double)ModMain._DatabaseAccount, (double)(45 + ModMain._CallbackAccount));
						ModMain._InstanceAccount = new ModBase.MyColor().FromHSL2((double)ModMain.m_SchemaAccount, (double)ModMain._DatabaseAccount, (double)(55 + ModMain._CallbackAccount));
						ModMain.creatorAccount = new ModBase.MyColor().FromHSL2((double)ModMain.m_SchemaAccount, (double)ModMain._DatabaseAccount, (double)(65 + ModMain._CallbackAccount));
					}
					ModMain._ObjectAccount = new ModBase.MyColor().FromHSL2((double)ModMain.m_SchemaAccount, (double)ModMain._DatabaseAccount, 80.0 + (double)ModMain._CallbackAccount * 0.4);
					ModMain._RegAccount = new ModBase.MyColor().FromHSL2((double)ModMain.m_SchemaAccount, (double)ModMain._DatabaseAccount, 91.0 + (double)ModMain._CallbackAccount * 0.1);
					ModMain.m_InvocationAccount = new ModBase.MyColor().FromHSL2((double)ModMain.m_SchemaAccount, (double)ModMain._DatabaseAccount, 94.0);
					ModMain.m_ComposerAccount = new ModBase.MyColor().FromHSL2((double)ModMain.m_SchemaAccount, (double)ModMain._DatabaseAccount, 97.0);
					ModMain._ItemAccount = new ModBase.MyColor(190.0, ModMain.m_InvocationAccount);
					ModMain.m_ConnectionAccount = new ModBase.MyColor(1.0, ModMain.m_ComposerAccount);
					Application.Current.Resources["ColorBrush1"] = new SolidColorBrush(ModMain._ListenerAccount);
					Application.Current.Resources["ColorBrush2"] = new SolidColorBrush(ModMain._IdentifierAccount);
					Application.Current.Resources["ColorBrush3"] = new SolidColorBrush(ModMain._InstanceAccount);
					Application.Current.Resources["ColorBrush4"] = new SolidColorBrush(ModMain.creatorAccount);
					Application.Current.Resources["ColorBrush5"] = new SolidColorBrush(ModMain._ObjectAccount);
					Application.Current.Resources["ColorBrush6"] = new SolidColorBrush(ModMain._RegAccount);
					Application.Current.Resources["ColorBrush7"] = new SolidColorBrush(ModMain.m_InvocationAccount);
					Application.Current.Resources["ColorBrush8"] = new SolidColorBrush(ModMain.m_ComposerAccount);
					Application.Current.Resources["ColorBrush9"] = new SolidColorBrush(ModMain._ItemAccount);
					Application.Current.Resources["ColorObject1"] = ModMain._ListenerAccount;
					Application.Current.Resources["ColorObject2"] = ModMain._IdentifierAccount;
					Application.Current.Resources["ColorObject3"] = ModMain._InstanceAccount;
					Application.Current.Resources["ColorObject4"] = ModMain.creatorAccount;
					Application.Current.Resources["ColorObject5"] = ModMain._ObjectAccount;
					Application.Current.Resources["ColorObject6"] = ModMain._RegAccount;
					Application.Current.Resources["ColorObject7"] = ModMain.m_InvocationAccount;
					Application.Current.Resources["ColorObject8"] = ModMain.m_ComposerAccount;
					Application.Current.Resources["ColorObject9"] = ModMain._ItemAccount;
					ModMain.InitTag();
					if (ModMain.customerAccount != 12 && ModMain.customerAccount != 14 && ModMain.m_ObserverAccount != 2)
					{
						ModBase.Log("[UI] 刷新主题：" + Conversions.ToString(ModMain.customerAccount), ModBase.LogLevel.Normal, "出现错误");
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "刷新主题颜色失败", ModBase.LogLevel.Hint, "出现错误");
			}
		}

		// Token: 0x0600131D RID: 4893 RVA: 0x0000B261 File Offset: 0x00009461
		public static void InitTag()
		{
			ModBase.RunInUi((ModMain._Closure$__.$I40-0 == null) ? (ModMain._Closure$__.$I40-0 = delegate()
			{
				if (ModMain.m_CollectionAccount.IsLoaded)
				{
					LinearGradientBrush linearGradientBrush = new LinearGradientBrush
					{
						EndPoint = new Point(1.0, 0.0),
						StartPoint = new Point(0.0, 0.0)
					};
					checked
					{
						if (ModMain.customerAccount == 5)
						{
							linearGradientBrush.GradientStops.Add(new GradientStop
							{
								Offset = 0.0,
								Color = new ModBase.MyColor().FromHSL2((double)ModMain.m_SchemaAccount, (double)ModMain._DatabaseAccount, 25.0)
							});
							linearGradientBrush.GradientStops.Add(new GradientStop
							{
								Offset = 0.5,
								Color = new ModBase.MyColor().FromHSL2((double)ModMain.m_SchemaAccount, (double)ModMain._DatabaseAccount, 15.0)
							});
							linearGradientBrush.GradientStops.Add(new GradientStop
							{
								Offset = 1.0,
								Color = new ModBase.MyColor().FromHSL2((double)ModMain.m_SchemaAccount, (double)ModMain._DatabaseAccount, 25.0)
							});
							ModMain.m_CollectionAccount.PanTitle.Background = linearGradientBrush;
							ModMain.m_CollectionAccount.PanTitle.Background.Freeze();
						}
						else if (ModMain.customerAccount != 12 && ModMain.m_ObserverAccount != 2)
						{
							if (ModMain.m_AdvisorAccount is int)
							{
								linearGradientBrush.GradientStops.Add(new GradientStop
								{
									Offset = 0.0,
									Color = new ModBase.MyColor().FromHSL2(Conversions.ToDouble(Operators.SubtractObject(ModMain.m_SchemaAccount, ModMain.m_AdvisorAccount)), (double)ModMain._DatabaseAccount, (double)(48 + ModMain._CallbackAccount))
								});
								linearGradientBrush.GradientStops.Add(new GradientStop
								{
									Offset = 0.5,
									Color = new ModBase.MyColor().FromHSL2((double)ModMain.m_SchemaAccount, (double)ModMain._DatabaseAccount, (double)(54 + ModMain._CallbackAccount))
								});
								linearGradientBrush.GradientStops.Add(new GradientStop
								{
									Offset = 1.0,
									Color = new ModBase.MyColor().FromHSL2(Conversions.ToDouble(Operators.AddObject(ModMain.m_SchemaAccount, ModMain.m_AdvisorAccount)), (double)ModMain._DatabaseAccount, (double)(48 + ModMain._CallbackAccount))
								});
							}
							else
							{
								linearGradientBrush.GradientStops.Add(new GradientStop
								{
									Offset = 0.0,
									Color = new ModBase.MyColor().FromHSL2(Conversions.ToDouble(Operators.AddObject(ModMain.m_SchemaAccount, NewLateBinding.LateIndexGet(ModMain.m_AdvisorAccount, new object[]
									{
										0
									}, null))), (double)ModMain._DatabaseAccount, (double)(48 + ModMain._CallbackAccount))
								});
								linearGradientBrush.GradientStops.Add(new GradientStop
								{
									Offset = 0.5,
									Color = new ModBase.MyColor().FromHSL2(Conversions.ToDouble(Operators.AddObject(ModMain.m_SchemaAccount, NewLateBinding.LateIndexGet(ModMain.m_AdvisorAccount, new object[]
									{
										1
									}, null))), (double)ModMain._DatabaseAccount, (double)(54 + ModMain._CallbackAccount))
								});
								linearGradientBrush.GradientStops.Add(new GradientStop
								{
									Offset = 1.0,
									Color = new ModBase.MyColor().FromHSL2(Conversions.ToDouble(Operators.AddObject(ModMain.m_SchemaAccount, NewLateBinding.LateIndexGet(ModMain.m_AdvisorAccount, new object[]
									{
										2
									}, null))), (double)ModMain._DatabaseAccount, (double)(48 + ModMain._CallbackAccount))
								});
							}
							ModMain.m_CollectionAccount.PanTitle.Background = linearGradientBrush;
							ModMain.m_CollectionAccount.PanTitle.Background.Freeze();
						}
						else
						{
							linearGradientBrush.GradientStops.Add(new GradientStop
							{
								Offset = 0.0,
								Color = new ModBase.MyColor().FromHSL2((double)(ModMain.m_SchemaAccount - 21), (double)ModMain._DatabaseAccount, (double)(53 + ModMain._CallbackAccount))
							});
							linearGradientBrush.GradientStops.Add(new GradientStop
							{
								Offset = 0.33,
								Color = new ModBase.MyColor().FromHSL2((double)(ModMain.m_SchemaAccount - 7), (double)ModMain._DatabaseAccount, (double)(47 + ModMain._CallbackAccount))
							});
							linearGradientBrush.GradientStops.Add(new GradientStop
							{
								Offset = 0.67,
								Color = new ModBase.MyColor().FromHSL2((double)(ModMain.m_SchemaAccount + 7), (double)ModMain._DatabaseAccount, (double)(47 + ModMain._CallbackAccount))
							});
							linearGradientBrush.GradientStops.Add(new GradientStop
							{
								Offset = 1.0,
								Color = new ModBase.MyColor().FromHSL2((double)(ModMain.m_SchemaAccount + 21), (double)ModMain._DatabaseAccount, (double)(53 + ModMain._CallbackAccount))
							});
							ModMain.m_CollectionAccount.PanTitle.Background = linearGradientBrush;
						}
						if (ModMain.customerAccount >= 5 && ModMain.customerAccount != 14)
						{
							ModMain.m_CollectionAccount.ImgTitle.Source = new MyBitmap(ModBase._TokenizerState + "Themes/" + Conversions.ToString(ModMain.customerAccount) + ".png");
						}
						else
						{
							ModMain.m_CollectionAccount.ImgTitle.Source = null;
						}
						ModMain.m_CollectionAccount.ImgTitle.Opacity = ((ModMain.customerAccount == 13) ? 0.25 : 0.5);
					}
					if (Conversions.ToBoolean(ModBase._ParamsState.Get("UiBackgroundColorful", null)))
					{
						linearGradientBrush = new LinearGradientBrush
						{
							EndPoint = new Point(0.1, 1.0),
							StartPoint = new Point(0.9, 0.0)
						};
						linearGradientBrush.GradientStops.Add(new GradientStop
						{
							Offset = -0.1,
							Color = new ModBase.MyColor().FromHSL2((double)(checked(ModMain.m_SchemaAccount - 20)), (double)Math.Min(60, ModMain._DatabaseAccount) * 0.5, 80.0)
						});
						linearGradientBrush.GradientStops.Add(new GradientStop
						{
							Offset = 0.4,
							Color = new ModBase.MyColor().FromHSL2((double)ModMain.m_SchemaAccount, (double)ModMain._DatabaseAccount * 0.9, 90.0)
						});
						linearGradientBrush.GradientStops.Add(new GradientStop
						{
							Offset = 1.1,
							Color = new ModBase.MyColor().FromHSL2((double)(checked(ModMain.m_SchemaAccount + 20)), (double)Math.Min(60, ModMain._DatabaseAccount) * 0.5, 80.0)
						});
						ModMain.m_CollectionAccount.PanForm.Background = linearGradientBrush;
					}
					else
					{
						ModMain.m_CollectionAccount.PanForm.Background = new ModBase.MyColor(250.0, 250.0, 250.0);
					}
					ModMain.m_CollectionAccount.PanForm.Background.Freeze();
				}
			}) : ModMain._Closure$__.$I40-0, false);
		}

		// Token: 0x0600131E RID: 4894 RVA: 0x0007F250 File Offset: 0x0007D450
		public static void SearchTag(bool ignorespec)
		{
			ModMain._Closure$__41-0 CS$<>8__locals1 = new ModMain._Closure$__41-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Local_EffectSetup = ignorespec;
			ModBase.RunInUi(checked(delegate()
			{
				try
				{
					string text = Conversions.ToString(ModBase._ParamsState.Get("UiLauncherThemeHide2", null));
					if (Operators.CompareString(text, "", true) == 0)
					{
						text = "3";
					}
					if (ModBase._ParamsState.Get("UiLauncherThemeHide", null).ToString().Contains("7"))
					{
						text += "|7";
					}
					if (ModBase._ParamsState.Get("UiLauncherThemeHide", null).ToString().Contains("6"))
					{
						text += "|6";
					}
					text = ModBase.Join(ModBase.ArrayNoDouble<string>(text.Split(new char[]
					{
						'|'
					}), null).SkipWhile((ModMain._Closure$__.$I41-1 == null) ? (ModMain._Closure$__.$I41-1 = ((string Data) => string.IsNullOrEmpty(Data))) : ModMain._Closure$__.$I41-1).ToList<string>(), "|");
					ModBase._ParamsState.Set("UiLauncherThemeHide2", text, false, null);
					List<string> list = new List<string>(text.Split(new char[]
					{
						'|'
					}));
					int num = 0;
					try
					{
						foreach (string value in list)
						{
							int num2 = Conversions.ToInteger(value);
							if (num2 >= 5 && num2 <= 14 && num2 != 8)
							{
								num++;
							}
						}
					}
					finally
					{
						List<string>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
					if (ModMain.CreateTag(null))
					{
						num++;
					}
					string text2 = Conversions.ToString(ModBase._ParamsState.Get("UiLauncherTheme", null));
					if (!ModMain.AssetTag(Conversions.ToInteger(text2)))
					{
						ModBase.Log("[UI] 检测到尚未解锁的主题：" + text2 + "，已重置为默认主题", ModBase.LogLevel.Normal, "出现错误");
						ModBase._ParamsState.Set("UiLauncherTheme", 0, false, null);
					}
					if (CS$<>8__locals1.$VB$Local_EffectSetup)
					{
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "检查主题失败", ModBase.LogLevel.Feedback, "出现错误");
				}
			}), false);
		}

		// Token: 0x0600131F RID: 4895 RVA: 0x0007F280 File Offset: 0x0007D480
		public static bool AssetTag(int first_Low)
		{
			checked
			{
				bool result;
				if (first_Low == 8)
				{
					result = ModMain.CreateTag(null);
				}
				else if (first_Low == 14)
				{
					int num = 0;
					string[] array = ModBase._ParamsState.Get("UiLauncherThemeHide2", null).ToString().Split(new char[]
					{
						'|'
					});
					for (int i = 0; i < array.Length; i++)
					{
						int num2 = Conversions.ToInteger(array[i]);
						if (num2 >= 5 && num2 <= 14 && num2 != 8)
						{
							num++;
						}
					}
					if (ModMain.CreateTag(null))
					{
						num++;
					}
					result = (num >= 5);
				}
				else
				{
					result = (new int[]
					{
						0,
						1,
						2,
						3,
						4,
						42
					}.Contains(first_Low) || ModBase._ParamsState.Get("UiLauncherThemeHide2", null).ToString().Split(new char[]
					{
						'|'
					}).Contains(first_Low.ToString()));
				}
				return result;
			}
		}

		// Token: 0x06001320 RID: 4896 RVA: 0x0000B28D File Offset: 0x0000948D
		public static bool ThemeUnlock(int Id, bool ShowDoubleHint = true, string UnlockHint = null)
		{
			return false;
		}

		// Token: 0x06001321 RID: 4897 RVA: 0x0007F35C File Offset: 0x0007D55C
		public static bool CreateTag(string value = null)
		{
			string cont = (value ?? ModBase._ParamsState.Get("UiLauncherThemeGold", null)).ToString().Replace("#", "");
			return ModBase.FillComparator("Gold|0|" + ModBase.initializerState.Replace("-", ""), cont);
		}

		// Token: 0x06001322 RID: 4898 RVA: 0x0007F3B8 File Offset: 0x0007D5B8
		public static void BackgroundRefresh(bool IsHint, bool Refresh)
		{
			try
			{
				List<string> list = new List<string>();
				try
				{
					foreach (string text in MyWpfExtension.FindModel().FileSystem.GetFiles(ModBase.Path + "PCL\\Pictures\\", Microsoft.VisualBasic.FileIO.SearchOption.SearchAllSubDirectories, new string[]
					{
						"*.*"
					}))
					{
						if (!text.ToLower().EndsWith(".ini"))
						{
							list.Add(text);
						}
					}
				}
				finally
				{
					IEnumerator<string> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				if (list.Count == 0)
				{
					if (Refresh)
					{
						if (ModMain.m_CollectionAccount.ImgBack.Visibility == Visibility.Collapsed)
						{
							if (IsHint)
							{
								ModMain.Hint("未检测到可用背景图片！", ModMain.HintType.Critical, true);
							}
						}
						else
						{
							ModMain.m_CollectionAccount.ImgBack.Visibility = Visibility.Collapsed;
							if (IsHint)
							{
								ModMain.Hint("背景图片已清除！", ModMain.HintType.Finish, true);
							}
						}
					}
					if (!Information.IsNothing(ModMain.m_ExporterAccount))
					{
						ModMain.m_ExporterAccount.BackgroundRefreshUI(false, 0);
					}
				}
				else
				{
					if (Refresh)
					{
						string text2 = Conversions.ToString(ModBase.RandomOne(list));
						try
						{
							ModBase.Log("[UI] 加载背景图片：" + text2, ModBase.LogLevel.Normal, "出现错误");
							ModMain.m_CollectionAccount.ImgBack.Background = new MyBitmap(text2);
							ModBase._ParamsState.Load("UiBackgroundSuit", true, null);
							ModMain.m_CollectionAccount.ImgBack.Visibility = Visibility.Visible;
							if (IsHint)
							{
								ModMain.Hint("背景图片已刷新：" + ModBase.GetFileNameFromPath(text2), ModMain.HintType.Finish, false);
							}
						}
						catch (Exception ex)
						{
							if (ex.Message.Contains("参数无效"))
							{
								ModBase.Log("刷新背景图片失败，该图片文件可能并非标准格式。\r\n你可以尝试使用画图打开该文件并重新保存，这会让图片变为标准格式。\r\n文件：" + text2, ModBase.LogLevel.Msgbox, "出现错误");
							}
							else
							{
								ModBase.Log(ex, "刷新背景图片失败（" + text2 + "）", ModBase.LogLevel.Msgbox, "出现错误");
							}
						}
					}
					if (!Information.IsNothing(ModMain.m_ExporterAccount))
					{
						ModMain.m_ExporterAccount.BackgroundRefreshUI(true, list.Count);
					}
				}
			}
			catch (Exception ex2)
			{
				ModBase.Log(ex2, "刷新背景图片时出现未知错误", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06001323 RID: 4899 RVA: 0x0007F604 File Offset: 0x0007D804
		public static void FeedbackLoad(ModLoader.LoaderTask<int, Dictionary<string, List<ModMain.FeedbackEntry>>> Loader)
		{
			checked
			{
				try
				{
					string text = Conversions.ToString(ModNet.NetGetCodeByRequestRetry("https://jinshuju.net/f/rP4b6E/r/rP4b6E/share_entries?per_page=300", Encoding.UTF8, "", false));
					if (!Loader.IsAborted)
					{
						if (text.Length < 1000)
						{
							throw new Exception("获取的反馈列表内容异常：" + text);
						}
						List<string> list = ModBase.RegexSearch(text, "<tr [\\S\\s]*?</tr>", RegexOptions.None);
						List<ModMain.FeedbackEntry> list2 = new List<ModMain.FeedbackEntry>();
						Dictionary<string, List<ModMain.FeedbackEntry>> dictionary = new Dictionary<string, List<ModMain.FeedbackEntry>>();
						bool flag = false;
						try
						{
							foreach (string str in list)
							{
								try
								{
									ModMain.FeedbackEntry feedbackEntry = default(ModMain.FeedbackEntry);
									feedbackEntry._SchemaParameter = Conversions.ToInteger(ModBase.RegexSearch(str, "(?<=serial_number\"[\\s\\S]+?title=\")[0-9]*", RegexOptions.None)[0]);
									feedbackEntry.Type = ModBase.RegexSearch(str, "(?<=field_1\"[\\s\\S]+?title=\")[^\"]*", RegexOptions.None)[0];
									feedbackEntry.Title = ModBase.RegexSearch(str, "(?<=field_12\"[\\s\\S]+?title=\")[^\"]*", RegexOptions.None)[0].Replace("&quot;", "\"").Replace("&amp;", "&").Replace("&lt;", "<").Replace("&gt;", ">").Replace("&#39;", "'").Replace("&amp;", "&");
									feedbackEntry.databaseParameter = ModBase.RegexSearch(str, "(?<=field_2\"[\\s\\S]+?title=\")[^\"]*", RegexOptions.None)[0];
									feedbackEntry.observerParameter = ModBase.RegexSearch(str, "(?<=field_3\"[\\s\\S]+?title=\")[^\"]*", RegexOptions.None)[0].Replace("&quot;", "\"").Replace("&amp;", "&").Replace("&lt;", "<").Replace("&gt;", ">").Replace("&#39;", "'").Replace("&amp;", "&");
									feedbackEntry.contextParameter = ModBase.RegexSearch(str, "(?<=field_8\"[\\s\\S]+?title=\")[^\"]*", RegexOptions.None)[0];
									feedbackEntry._CollectionParameter = ModBase.RegexSearch(str, "(?<=field_7\"[\\s\\S]+?title=\")[^\"]*", RegexOptions.None)[0].Replace("&quot;", "\"").Replace("&amp;", "&").Replace("&lt;", "<").Replace("&gt;", ">").Replace("&#39;", "'").Replace("&amp;", "&");
									feedbackEntry.advisorParameter = Conversions.ToInteger(ModBase.RegexSearch(str, "(?<=field_14\"[\\s\\S]+?title=\")[0-9]*", RegexOptions.None)[0]);
									feedbackEntry.filterParameter = ModBase.RegexSearch(str, "(?<=updated_at\"[\\s\\S]+?title=\")[^\"]*", RegexOptions.None)[0];
									feedbackEntry.m_ConsumerParameter = ModBase.RegexSearch(str, "(?<=created_at\"[\\s\\S]+?title=\")[^\"]*", RegexOptions.None)[0];
									feedbackEntry.m_SingletonParameter = ModBase.RegexSearch(str, "(?<=field_15\"[\\s\\S]+?title=\")[^\"]*", RegexOptions.None)[0];
									feedbackEntry.m_CallbackParameter = ModBase.RegexSearch(str, "(?<=field_10\"[\\s\\S]+?title=\")[^\"]*", RegexOptions.None)[0].Replace("&quot;", "\"").Replace("&amp;", "&").Replace("&lt;", "<").Replace("&gt;", ">").Replace("&#39;", "'").Replace("&amp;", "&");
									if (!feedbackEntry.m_CallbackParameter.EndsWith("！") && !feedbackEntry.m_CallbackParameter.EndsWith("？") && !feedbackEntry.m_CallbackParameter.EndsWith("…"))
									{
										ref string ptr = ref feedbackEntry.m_CallbackParameter;
										feedbackEntry.m_CallbackParameter = ptr + "。";
									}
									if (feedbackEntry.contextParameter.Contains(ModBase.initializerState))
									{
										if (!dictionary.ContainsKey("我的反馈"))
										{
											dictionary.Add("我的反馈", new List<ModMain.FeedbackEntry>());
										}
										dictionary["我的反馈"].Add(feedbackEntry);
										List<string> list3 = ModBase.RegexSearch(Conversions.ToString(ModBase._ParamsState.Get("HintFeedback", null)), "(?<=\\[" + Conversions.ToString(feedbackEntry._SchemaParameter) + ",)[0-9]+", RegexOptions.None);
										if (list3.Count == 0)
										{
											ModBase._ParamsState.Set("HintFeedback", Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(ModBase._ParamsState.Get("HintFeedback", null), "["), feedbackEntry._SchemaParameter), ","), feedbackEntry.advisorParameter), "]"), false, null);
											if (feedbackEntry.advisorParameter > 0)
											{
												ModMain.MyMsgBox(string.Concat(new string[]
												{
													"你的反馈 ",
													feedbackEntry.Title,
													" 已收到回复。\r\n目前状态：",
													feedbackEntry.databaseParameter,
													"\r\n\r\n开发者回复（",
													ModBase.GetTimeSpanString(DateTime.Parse(feedbackEntry.filterParameter) - DateTime.Now),
													"）：\r\n",
													feedbackEntry.m_CallbackParameter
												}), "反馈回复通知", "确定", "", "", false, true, false);
											}
										}
										else if (Conversions.ToDouble(list3[0]) < (double)feedbackEntry.advisorParameter)
										{
											ModBase._ParamsState.Set("HintFeedback", ModBase.RegexReplace(Conversions.ToString(ModBase._ParamsState.Get("HintFeedback", null)), Conversions.ToString(feedbackEntry.advisorParameter), "(?<=\\[" + Conversions.ToString(feedbackEntry._SchemaParameter) + ",)[0-9]+", RegexOptions.None), false, null);
											ModMain.MyMsgBox(string.Concat(new string[]
											{
												"你的反馈 ",
												feedbackEntry.Title,
												" 已收到回复。\r\n目前状态：",
												feedbackEntry.databaseParameter,
												"\r\n\r\n开发者回复（",
												ModBase.GetTimeSpanString(DateTime.Parse(feedbackEntry.filterParameter) - DateTime.Now),
												"）：\r\n",
												feedbackEntry.m_CallbackParameter
											}), "反馈回复通知", "确定", "", "", false, true, false);
										}
										if ((Operators.CompareString(feedbackEntry.databaseParameter, "已处理", true) == 0 || Operators.CompareString(feedbackEntry.databaseParameter, "等待处理", true) == 0 || Operators.CompareString(feedbackEntry.databaseParameter, "等待更新", true) == 0 || Operators.CompareString(feedbackEntry.databaseParameter, "已放弃", true) == 0) && Operators.CompareString(feedbackEntry.Type, "Bug 汇报", true) == 0 && !flag)
										{
											flag = true;
										}
									}
									if (Operators.CompareString(feedbackEntry.Type, "已忽略", true) != 0)
									{
										list2.Add(feedbackEntry);
									}
								}
								catch (Exception ex)
								{
									ModBase.Log(ex, "加载反馈列表项目失败", ModBase.LogLevel.Debug, "出现错误");
								}
							}
						}
						finally
						{
							List<string>.Enumerator enumerator;
							((IDisposable)enumerator).Dispose();
						}
						ModMain.FeedbackFilter(ref dictionary, list2, new string[]
						{
							"尚未查看"
						}, "未处理");
						ModMain.FeedbackFilter(ref dictionary, list2, new string[]
						{
							"等待确认",
							"正在处理"
						}, "处理中");
						ModMain.FeedbackFilter(ref dictionary, list2, new string[]
						{
							"等待更新",
							"已处理"
						}, "已处理");
						ModMain.FeedbackFilter(ref dictionary, list2, new string[]
						{
							"等待处理"
						}, "暂缓");
						ModMain.FeedbackFilter(ref dictionary, list2, new string[]
						{
							"已放弃"
						}, "放弃");
						ModMain.FeedbackFilter(ref dictionary, list2, new string[]
						{
							"已拒绝"
						}, "拒绝");
						try
						{
							foreach (KeyValuePair<string, List<ModMain.FeedbackEntry>> keyValuePair in dictionary)
							{
								for (;;)
								{
									IL_7FF:
									int num = keyValuePair.Value.Count - 2;
									for (int i = 0; i <= num; i++)
									{
										if (Operators.CompareString(keyValuePair.Value[i].m_ConsumerParameter, keyValuePair.Value[i + 1].m_ConsumerParameter, true) < 0)
										{
											ModMain.FeedbackEntry value = keyValuePair.Value[i];
											keyValuePair.Value[i] = keyValuePair.Value[i + 1];
											keyValuePair.Value[i + 1] = value;
											goto IL_7FF;
										}
									}
									break;
								}
							}
						}
						finally
						{
							Dictionary<string, List<ModMain.FeedbackEntry>>.Enumerator enumerator2;
							((IDisposable)enumerator2).Dispose();
						}
						if (!Loader.IsAborted)
						{
							Loader.Output = dictionary;
						}
					}
				}
				catch (Exception ex2)
				{
					ModBase.Log(ex2, "反馈列表加载失败", ModBase.LogLevel.Debug, "出现错误");
					throw;
				}
			}
		}

		// Token: 0x06001324 RID: 4900 RVA: 0x0007FED4 File Offset: 0x0007E0D4
		private static void FeedbackFilter(ref Dictionary<string, List<ModMain.FeedbackEntry>> Dict, List<ModMain.FeedbackEntry> List, string[] Formula, string Key)
		{
			List<ModMain.FeedbackEntry> list = new List<ModMain.FeedbackEntry>();
			try
			{
				foreach (ModMain.FeedbackEntry feedbackEntry in List)
				{
					foreach (string right in Formula)
					{
						if (Operators.CompareString(feedbackEntry.databaseParameter, right, true) == 0)
						{
							list.Add(feedbackEntry);
							break;
						}
					}
				}
			}
			finally
			{
				List<ModMain.FeedbackEntry>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			if (list.Count > 0)
			{
				Dict.Add(Key, list);
			}
		}

		// Token: 0x06001325 RID: 4901 RVA: 0x0007FF68 File Offset: 0x0007E168
		private static void HelpLoad(ModLoader.LoaderTask<int, List<ModMain.HelpEntry>> Loader)
		{
			object resolverState = ModMain.m_ResolverState;
			ObjectFlowControl.CheckForSyncLockOnValueType(resolverState);
			checked
			{
				lock (resolverState)
				{
					try
					{
						ModBase.Log("[Help] 正在检查内置帮助文件", ModBase.LogLevel.Normal, "出现错误");
						if (Operators.ConditionalCompareObjectNotEqual(ModBase._ParamsState.Get("SystemHelpVersion", null), 246, true) || !File.Exists(ModBase.attributeState + "Help\\启动器\\联机.xaml"))
						{
							ModBase.DeleteDirectory(ModBase.attributeState + "Help", false);
							Directory.CreateDirectory(ModBase.attributeState + "Help");
							ModBase.WriteFile(ModBase.attributeState + "Cache\\Help.zip", ModBase.GetResources("Help"), false);
							ModBase.ExtractFile(ModBase.attributeState + "Cache\\Help.zip", ModBase.attributeState + "Help", Encoding.UTF8);
							ModBase._ParamsState.Set("SystemHelpVersion", 246, false, null);
							ModBase.Log("[Help] 已解压内置帮助文件：" + Conversions.ToString(File.Exists(ModBase.attributeState + "Help\\启动器\\联机.xaml")), ModBase.LogLevel.Normal, "出现错误");
						}
						List<string> list = new List<string>();
						try
						{
							List<string> list2 = new List<string>();
							if (Directory.Exists(ModBase.Path + "PCL\\Help\\"))
							{
								try
								{
									foreach (FileInfo fileInfo in ModBase.EnumerateFiles(ModBase.Path + "PCL\\Help\\"))
									{
										if (Operators.CompareString(fileInfo.Extension.ToLower(), ".helpignore", true) == 0)
										{
											ModBase.Log("[Help] 发现 .helpignore 文件：" + fileInfo.FullName, ModBase.LogLevel.Normal, "出现错误");
											string[] array = File.ReadAllLines(fileInfo.FullName);
											for (int i = 0; i < array.Length; i++)
											{
												string text = array[i].Split(new char[]
												{
													'#'
												}).First<string>().Trim();
												if (!string.IsNullOrWhiteSpace(text))
												{
													list2.Add(text);
													if (ModBase._EventState)
													{
														ModBase.Log("[Help]  > " + text, ModBase.LogLevel.Normal, "出现错误");
													}
												}
											}
										}
										else if (Operators.CompareString(fileInfo.Extension.ToLower(), ".json", true) == 0)
										{
											list.Add(fileInfo.FullName);
										}
									}
								}
								finally
								{
									List<FileInfo>.Enumerator enumerator;
									((IDisposable)enumerator).Dispose();
								}
							}
							ModBase.Log("[Help] 已扫描 PCL 文件夹下的帮助文件，目前总计 " + Conversions.ToString(list.Count) + " 条", ModBase.LogLevel.Normal, "出现错误");
							try
							{
								List<FileInfo>.Enumerator enumerator2 = ModBase.EnumerateFiles(ModBase.attributeState + "Help").GetEnumerator();
								IL_388:
								while (enumerator2.MoveNext())
								{
									FileInfo fileInfo2 = enumerator2.Current;
									if (Operators.CompareString(fileInfo2.Extension.ToLower(), ".json", true) == 0 && !fileInfo2.Directory.FullName.Replace(ModBase.attributeState + "Help", "").Contains("\\."))
									{
										string text2 = fileInfo2.FullName.Replace(ModBase.attributeState + "Help\\", "");
										try
										{
											foreach (string text3 in list2)
											{
												if (ModBase.RegexCheck(text2, text3, RegexOptions.None))
												{
													if (ModBase._EventState)
													{
														ModBase.Log("[Help] 已忽略 " + text2 + "：" + text3, ModBase.LogLevel.Normal, "出现错误");
													}
													goto IL_388;
												}
											}
										}
										finally
										{
											List<string>.Enumerator enumerator3;
											((IDisposable)enumerator3).Dispose();
										}
										list.Add(fileInfo2.FullName);
									}
								}
							}
							finally
							{
								List<FileInfo>.Enumerator enumerator2;
								((IDisposable)enumerator2).Dispose();
							}
							ModBase.Log("[Help] 已扫描缓存文件夹下的帮助文件，目前总计 " + Conversions.ToString(list.Count) + " 条", ModBase.LogLevel.Normal, "出现错误");
						}
						catch (Exception ex)
						{
							ModBase.Log(ex, "检查帮助文件夹失败", ModBase.LogLevel.Msgbox, "出现错误");
						}
						if (!Loader.IsAborted)
						{
							List<ModMain.HelpEntry> list3 = new List<ModMain.HelpEntry>();
							try
							{
								foreach (string text4 in list)
								{
									try
									{
										ModMain.HelpEntry helpEntry = new ModMain.HelpEntry(text4);
										list3.Add(helpEntry);
										if (ModBase._EventState)
										{
											ModBase.Log("[Help] 已加载的帮助条目：" + helpEntry.Title + " ← " + text4, ModBase.LogLevel.Normal, "出现错误");
										}
									}
									catch (Exception ex2)
									{
										ModBase.Log(ex2, "初始化帮助条目失败（" + text4 + "）", ModBase.LogLevel.Msgbox, "出现错误");
									}
								}
							}
							finally
							{
								List<string>.Enumerator enumerator4;
								((IDisposable)enumerator4).Dispose();
							}
							if (list3.Count == 0)
							{
								throw new Exception("未找到可用的帮助；若不需要帮助页面，可以在 设置 → 个性化 → 功能隐藏 中将其隐藏");
							}
							if (!Loader.IsAborted)
							{
								Loader.Output = list3;
							}
						}
					}
					catch (Exception ex3)
					{
						ModBase.Log(ex3, "帮助列表初始化失败", ModBase.LogLevel.Debug, "出现错误");
						throw;
					}
				}
			}
		}

		// Token: 0x06001326 RID: 4902 RVA: 0x0008051C File Offset: 0x0007E71C
		private static void ServerSub(ModLoader.LoaderTask<int, int> Loader)
		{
			try
			{
				if (File.Exists(ModBase.Path + "PCL\\update.exe"))
				{
					File.Delete(ModBase.Path + "PCL\\update.exe");
					ModBase.Log("[Server] 已清理更新缓存", ModBase.LogLevel.Normal, "出现错误");
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "清理更新缓存失败", ModBase.LogLevel.Debug, "出现错误");
			}
			ModBase.Log("[Server] 正在连接到 PCL2 服务器", ModBase.LogLevel.Normal, "出现错误");
			try
			{
				ModMain.ServerSubReal();
			}
			catch (Exception ex2)
			{
				ModBase.Log(ex2, "连接到 PCL2 服务器失败", ModBase.LogLevel.Debug, "出现错误");
			}
		}

		// Token: 0x06001327 RID: 4903 RVA: 0x000805D8 File Offset: 0x0007E7D8
		private static void ServerSubReal()
		{
			int num = Conversions.ToInteger(ModBase._ParamsState.Get("HintNotice", null));
			int num2 = Conversions.ToInteger(ModBase._ParamsState.Get("HintDownload", null));
			checked
			{
				int num3;
				int num4;
				try
				{
					string text = Conversions.ToString(ModNet.NetGetCodeByRequestRetry("http://pcl2-server-1253424809.file.myqcloud.com/notice.cfg{CDN}", null, "", false));
					num3 = (int)Math.Round(ModBase.Val(text.Split(new char[]
					{
						'|'
					})[0]));
					num4 = (int)Math.Round(ModBase.Val(text.Split(new char[]
					{
						'|'
					})[3]));
					if (num3 == 0)
					{
						throw new Exception("获取到的内容有误！（" + text + "）");
					}
					if (num3 > num)
					{
						ModBase.Log(string.Concat(new string[]
						{
							"[Server] 服务器公告：",
							text,
							"，本地公告编号：",
							Conversions.ToString(num),
							"，需更新"
						}), ModBase.LogLevel.Normal, "出现错误");
					}
					else
					{
						ModBase.Log("[Server] 服务器公告：" + text + "，无需更新", ModBase.LogLevel.Normal, "出现错误");
					}
					ModBase.WriteFile(ModBase.attributeState + "Cache\\Notice.cfg", text, false, null);
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "获取 PCL2 服务器状态失败", ModBase.LogLevel.Debug, "出现错误");
				}
				try
				{
					if (num4 > num2 || !File.Exists(ModBase.attributeState + "download.json"))
					{
						string text2 = ModNet.NetGetCodeByDownload("http://pcl2-server-1253424809.file.myqcloud.com/minecraft/download.json{CDN}", 45000, true);
						Directory.CreateDirectory(ModBase.attributeState + "Cache\\");
						ModBase.WriteFile(ModBase.attributeState + "Cache\\download.json", text2, false, null);
					}
					ModBase._ParamsState.Set("HintDownload", num4, false, null);
				}
				catch (Exception ex2)
				{
					ModBase.Log(ex2, "下载 PCL2 特供版信息失败", ModBase.LogLevel.Debug, "出现错误");
					File.Delete(ModBase.attributeState + "Cache\\download.json");
				}
				string text3;
				try
				{
					if (num3 <= num && File.Exists(ModBase.attributeState + "Cache\\Notice.json"))
					{
						text3 = ModBase.ReadFile(ModBase.attributeState + "Cache\\Notice.json");
					}
					else
					{
						text3 = Conversions.ToString(ModNet.NetGetCodeByRequestRetry("http://pcl2-server-1253424809.file.myqcloud.com/notice.json{CDN}", null, "", false));
						Directory.CreateDirectory(ModBase.attributeState + "Cache\\");
						ModBase.WriteFile(ModBase.attributeState + "Cache\\Notice.json", text3, false, null);
					}
					ModBase._ParamsState.Set("HintNotice", num3, false, null);
				}
				catch (Exception ex3)
				{
					ModBase.Log(ex3, "下载 PCL2 服务器公告失败", ModBase.LogLevel.Debug, "出现错误");
					File.Delete(ModBase.attributeState + "Cache\\Notice.json");
					return;
				}
				try
				{
					try
					{
						foreach (object obj in ((IEnumerable)ModBase.GetJson(text3.Replace("{UNIQUE}", ModBase.initializerState))))
						{
							JObject jobject = (JObject)obj;
							int num5 = (int)Math.Round(ModBase.Val(jobject["id"] ?? 0));
							if (num5 > num)
							{
								bool flag = true;
								try
								{
									foreach (JToken jtoken in (jobject["requirements"] ?? new byte[0]))
									{
										JProperty jproperty = (JProperty)jtoken;
										if (!ModMain.ServerRequirement(jproperty.Name, jproperty.Value))
										{
											flag = false;
										}
									}
								}
								finally
								{
									IEnumerator<JToken> enumerator2;
									if (enumerator2 != null)
									{
										enumerator2.Dispose();
									}
								}
								if (flag)
								{
									int num6 = (int)(jobject["importantLevel"] ?? 2);
									bool flag2 = (bool)(jobject["isUpdate"] ?? false);
									ModBase.Log("[Server] 重要等级 " + Conversions.ToString(num6) + "，更新公告 " + Conversions.ToString(flag2), ModBase.LogLevel.Normal, "出现错误");
									if (!Operators.ConditionalCompareObjectGreater(ModBase._ParamsState.Get(flag2 ? "SystemSystemUpdate" : "SystemSystemActivity", null), num6, true) && (!flag2 || !ModMain._StateState))
									{
										string title = (jobject["title"] ?? "公告").ToString();
										string text4 = (jobject["description"] ?? "").ToString().Replace("\\n", "\r\n");
										JContainer jcontainer = (JContainer)(jobject["buttons"] ?? ModBase.GetJson("[]"));
										int count = jcontainer.Count;
										object obj2 = new object[0];
										if (count > 0)
										{
											ModBase.Log("[Server] 显示公告 " + Conversions.ToString(num5) + "：" + text4, ModBase.LogLevel.Normal, "出现错误");
											int num7;
											switch (count)
											{
											case 1:
												num7 = ModMain.MyMsgBox(text4, title, (jcontainer[0]["text"] ?? "确定").ToString(), "", "", false, true, true);
												break;
											case 2:
												num7 = ModMain.MyMsgBox(text4, title, (jcontainer[0]["text"] ?? "确定").ToString(), (jcontainer[1]["text"] ?? "确定").ToString(), "", false, true, false);
												break;
											case 3:
												num7 = ModMain.MyMsgBox(text4, title, (jcontainer[0]["text"] ?? "确定").ToString(), (jcontainer[1]["text"] ?? "确定").ToString(), (jcontainer[2]["text"] ?? "确定").ToString(), false, true, false);
												break;
											default:
												ModBase.Log(string.Concat(new string[]
												{
													"[Server] 公告 ",
													Conversions.ToString(num5),
													" 的弹窗有 ",
													Conversions.ToString(count),
													" 个按钮，无法显示"
												}), ModBase.LogLevel.Debug, "出现错误");
												continue;
											}
											num7 = (int)Math.Round(ModBase.MathRange((double)num7, 1.0, (double)count));
											obj2 = (jcontainer[num7 - 1]["actions"] ?? new byte[0]);
										}
										else
										{
											obj2 = (jobject["actions"] ?? new byte[0]);
										}
										try
										{
											foreach (object obj3 in ((IEnumerable)obj2))
											{
												JProperty jproperty2 = (JProperty)obj3;
												try
												{
													string name = jproperty2.Name;
													if (Operators.CompareString(name, "copy", true) == 0)
													{
														ModBase.ClipboardSet(jproperty2.Value.ToString(), true);
													}
													else if (Operators.CompareString(name, "shell", true) == 0)
													{
														Process.Start(jproperty2.Value.ToString());
													}
													else if (Operators.CompareString(name, "stop", true) == 0)
													{
														ModMain.m_CollectionAccount.EndProgram(false);
													}
													else if (Operators.CompareString(name, "setup", true) == 0)
													{
														ModBase._ParamsState.Set(((JProperty)jproperty2.Value).Name, ((JProperty)jproperty2.Value).Value.ToString(), false, null);
													}
													else if (Operators.CompareString(name, "slientupdate", true) == 0)
													{
														ModMain.UpdateStart((((JObject)jproperty2.Value)["url"] ?? "http://pcl2-server-1253424809.file.myqcloud.com/update/{KEY}.zip{CDN}").ToString(), true, null, true);
													}
													else
													{
														if (Operators.CompareString(name, "update", true) != 0)
														{
															throw new Exception("未知的行动支：" + jproperty2.Name + ", " + jproperty2.Value.ToString());
														}
														ModMain.UpdateStart((((JObject)jproperty2.Value)["url"] ?? "http://pcl2-server-1253424809.file.myqcloud.com/update/{KEY}.zip{CDN}").ToString(), false, null, true);
													}
												}
												catch (Exception ex4)
												{
													ModBase.Log(ex4, string.Concat(new string[]
													{
														"执行 PCL2 服务器公告动作失败（",
														jproperty2.Name,
														", ",
														jproperty2.Value.ToString(),
														"）"
													}), ModBase.LogLevel.Hint, "出现错误");
												}
											}
										}
										finally
										{
											IEnumerator enumerator3;
											if (enumerator3 is IDisposable)
											{
												(enumerator3 as IDisposable).Dispose();
											}
										}
									}
								}
							}
						}
					}
					finally
					{
						IEnumerator enumerator;
						if (enumerator is IDisposable)
						{
							(enumerator as IDisposable).Dispose();
						}
					}
				}
				catch (Exception ex5)
				{
					ModBase.Log(text3, ModBase.LogLevel.Normal, "出现错误");
					ModBase.Log(ex5, "读取 PCL2 服务器公告失败（" + Conversions.ToString(text3.Length) + "）", ModBase.LogLevel.Hint, "出现错误");
					File.Delete(ModBase.attributeState + "Cache\\Notice.json");
				}
			}
		}

		// Token: 0x06001328 RID: 4904 RVA: 0x00080FF4 File Offset: 0x0007F1F4
		private static bool ServerRequirement(string Name, JToken Value)
		{
			checked
			{
				bool result;
				try
				{
					if (Operators.CompareString(Name, "d10000 <=", true) == 0)
					{
						result = ((double)ModBase.RandomInteger(1, 10000) <= ModBase.Val(Value));
					}
					else if (Operators.CompareString(Name, "opencount <=", true) == 0)
					{
						result = Operators.ConditionalCompareObjectLessEqual(ModBase._ParamsState.Get("SystemCount", null), ModBase.Val(Value), true);
					}
					else if (Operators.CompareString(Name, "opencount >=", true) == 0)
					{
						result = Operators.ConditionalCompareObjectGreaterEqual(ModBase._ParamsState.Get("SystemCount", null), ModBase.Val(Value), true);
					}
					else if (Operators.CompareString(Name, "versioncode <=", true) == 0)
					{
						result = (246.0 <= ModBase.Val(Value));
					}
					else if (Operators.CompareString(Name, "versioncode >=", true) == 0)
					{
						result = (246.0 >= ModBase.Val(Value));
					}
					else if (Operators.CompareString(Name, "versionbranch <=", true) == 0)
					{
						result = (ModBase.Val("50") <= ModBase.Val(Value));
					}
					else if (Operators.CompareString(Name, "versionbranch >=", true) == 0)
					{
						result = (ModBase.Val("50") >= ModBase.Val(Value));
					}
					else if (Operators.CompareString(Name, "uniqueaddress =", true) == 0)
					{
						result = (Operators.CompareString(ModBase.initializerState, Value.ToString(), true) == 0);
					}
					else if (Operators.CompareString(Name, "unlockedtheme =", true) == 0)
					{
						result = ModMain.AssetTag((int)Math.Round(ModBase.Val(Value)));
					}
					else if (Operators.CompareString(Name, "unlockedtheme !=", true) == 0)
					{
						result = !ModMain.AssetTag((int)Math.Round(ModBase.Val(Value)));
					}
					else if (Operators.CompareString(Name, "setupinteger >=", true) == 0)
					{
						result = Operators.ConditionalCompareObjectGreaterEqual(ModBase._ParamsState.Get(((JProperty)Value).Name, null), ModBase.Val(((JProperty)Value).Value), true);
					}
					else if (Operators.CompareString(Name, "setupinteger <=", true) == 0)
					{
						result = Operators.ConditionalCompareObjectLessEqual(ModBase._ParamsState.Get(((JProperty)Value).Name, null), ModBase.Val(((JProperty)Value).Value), true);
					}
					else if (Operators.CompareString(Name, "setupboolean =", true) == 0)
					{
						result = (Operators.CompareString(ModBase._ParamsState.Get(((JProperty)Value).Name, null).ToString().ToLower(), ((JProperty)Value).Value.ToString().ToLower(), true) == 0);
					}
					else if (Operators.CompareString(Name, "debug =", true) == 0)
					{
						result = (Operators.CompareString(ModBase._EventState.ToString().ToLower(), Value.ToString().ToLower(), true) == 0);
					}
					else if (Operators.CompareString(Name, "keyhash !=", true) == 0)
					{
						result = (ModBase.GetHash(ModBase._InfoState.ToLower()) != ModBase.GetHash(Value.ToString().ToLower()));
					}
					else
					{
						ModBase.Log("[Server] 未知的条件支：" + Name + ", " + Value.ToString(), ModBase.LogLevel.Debug, "出现错误");
						result = false;
					}
				}
				catch (Exception ex)
				{
					ModBase.Log("[Server] 判断分支条件失败：" + Name + ", " + Value.ToString(), ModBase.LogLevel.Debug, "出现错误");
					result = false;
				}
				return result;
			}
		}

		// Token: 0x06001329 RID: 4905 RVA: 0x0008136C File Offset: 0x0007F56C
		private static void TimerFool()
		{
			try
			{
				if (ModMain._FilterAccount != null && ModMain._FilterAccount.AprilPosTrans != null && ModMain.m_CollectionAccount.stateAccount != null)
				{
					if (!ModMain.m_PrototypeState && !(ModMain.m_CollectionAccount.comparatorAccount != FormMain.PageType.Launch) && ModAnimation.DefineModel() == 0 && ModMain._FilterAccount.BtnLaunch.IsLoaded)
					{
						Point position = ModMain.m_CollectionAccount.stateAccount.GetPosition(ModMain.m_CollectionAccount);
						double num;
						double num2;
						Vector vector;
						Vector vector3;
						checked
						{
							if (position == ModMain._AccountState)
							{
								ModMain._RequestState++;
							}
							else
							{
								ModMain._AccountState = position;
								ModMain._RequestState = 0;
							}
							num = ModMain._FilterAccount.BtnLaunch.ActualWidth / 2.0;
							num2 = ModMain._FilterAccount.BtnLaunch.ActualHeight / 2.0;
							vector = (Vector)(ModMain.m_CollectionAccount.stateAccount.GetPosition(ModMain._FilterAccount.BtnLaunch) - new Vector(num, num2));
							Vector vector2 = new Vector(vector.X, vector.Y);
							vector2.Normalize();
							vector3 = -vector2;
						}
						double length = new Vector(Math.Max(0.0, Math.Abs(vector.X) - num), Math.Max(0.0, Math.Abs(vector.Y) - num2)).Length;
						double num3 = Math.Sin((double)ModMain.m_ReponseState / 37.5 * 3.141592653589793);
						Vector vector4 = Math.Max(0.0, num3 * 0.25 - 0.65 - Math.Log((length + 0.4) / 200.0)) * vector3;
						if (ModMain._RequestState >= 320)
						{
							Vector vector5 = (Vector)(ModMain.m_CollectionAccount.stateAccount.GetPosition(ModMain.m_CollectionAccount.PanMain) - new Vector(num, ModMain.m_CollectionAccount.PanMain.ActualHeight - num2 * 3.0));
							Vector vector6 = new Vector(ModMain._FilterAccount.AprilPosTrans.X, ModMain._FilterAccount.AprilPosTrans.Y);
							if (vector5.Length > 250.0 && vector6.Length > 0.4)
							{
								vector4 -= vector6 * 0.0005;
								vector6.Normalize();
								vector4 -= vector6 * 0.15;
							}
						}
						Point point = ModMain._FilterAccount.BtnLaunch.TranslatePoint(new Point(0.0, 0.0), ModMain.m_CollectionAccount.PanForm);
						if (point.X < -num * 2.0)
						{
							TranslateTransform aprilPosTrans;
							(aprilPosTrans = ModMain._FilterAccount.AprilPosTrans).X = aprilPosTrans.X + (ModMain.m_CollectionAccount.PanForm.ActualWidth + num * 2.0);
							ModMain.issuerState.X = ModMain.issuerState.X - 80.0;
							if (point.Y < 0.0)
							{
								(aprilPosTrans = ModMain._FilterAccount.AprilPosTrans).Y = aprilPosTrans.Y + num2 * 2.5;
							}
							else if (point.Y > ModMain.m_CollectionAccount.PanForm.ActualHeight - num2 * 2.0)
							{
								(aprilPosTrans = ModMain._FilterAccount.AprilPosTrans).Y = aprilPosTrans.Y - num2 * 2.5;
							}
						}
						else if (point.X > ModMain.m_CollectionAccount.PanForm.ActualWidth)
						{
							TranslateTransform aprilPosTrans;
							(aprilPosTrans = ModMain._FilterAccount.AprilPosTrans).X = aprilPosTrans.X - (ModMain.m_CollectionAccount.PanForm.ActualWidth + num * 2.0);
							ModMain.issuerState.X = ModMain.issuerState.X + 80.0;
							if (point.Y < 0.0)
							{
								(aprilPosTrans = ModMain._FilterAccount.AprilPosTrans).Y = aprilPosTrans.Y + num2 * 2.5;
							}
							else if (point.Y > ModMain.m_CollectionAccount.PanForm.ActualHeight - num2 * 2.0)
							{
								(aprilPosTrans = ModMain._FilterAccount.AprilPosTrans).Y = aprilPosTrans.Y - num2 * 2.5;
							}
						}
						else if (point.Y < -num2 * 2.0)
						{
							TranslateTransform aprilPosTrans;
							(aprilPosTrans = ModMain._FilterAccount.AprilPosTrans).Y = aprilPosTrans.Y + (ModMain.m_CollectionAccount.PanForm.ActualHeight + num2 * 2.0);
							ModMain.issuerState.Y = ModMain.issuerState.Y - 25.0;
							if (point.X < 0.0)
							{
								(aprilPosTrans = ModMain._FilterAccount.AprilPosTrans).X = aprilPosTrans.X + num * 2.0;
							}
							else if (point.X > ModMain.m_CollectionAccount.PanForm.ActualWidth - num * 2.0)
							{
								(aprilPosTrans = ModMain._FilterAccount.AprilPosTrans).X = aprilPosTrans.X - num * 2.0;
							}
						}
						else if (point.Y > ModMain.m_CollectionAccount.PanForm.ActualHeight)
						{
							TranslateTransform aprilPosTrans;
							(aprilPosTrans = ModMain._FilterAccount.AprilPosTrans).Y = aprilPosTrans.Y - (ModMain.m_CollectionAccount.PanForm.ActualHeight + num2 * 2.0);
							ModMain.issuerState.Y = ModMain.issuerState.Y + 25.0;
							if (point.X < 0.0)
							{
								(aprilPosTrans = ModMain._FilterAccount.AprilPosTrans).X = aprilPosTrans.X + num * 2.0;
							}
							else if (point.X > ModMain.m_CollectionAccount.PanForm.ActualWidth - num * 2.0)
							{
								(aprilPosTrans = ModMain._FilterAccount.AprilPosTrans).X = aprilPosTrans.X - num * 2.0;
							}
						}
						ModMain.issuerState = ModMain.issuerState * 0.8 + vector4;
						double num4 = Math.Min(80.0, ModMain.issuerState.Length);
						if (num4 >= 0.01)
						{
							ModMain.issuerState.Normalize();
							ModMain.issuerState *= num4;
							TranslateTransform aprilPosTrans;
							(aprilPosTrans = ModMain._FilterAccount.AprilPosTrans).X = aprilPosTrans.X + ModMain.issuerState.X;
							(aprilPosTrans = ModMain._FilterAccount.AprilPosTrans).Y = aprilPosTrans.Y + ModMain.issuerState.Y;
							ModMain._FilterAccount.AprilScaleTrans.ScaleX = ModBase.MathRange(1.0 - (Math.Abs(vector3.X) - Math.Abs(vector3.Y)) * (num4 / 160.0), 0.2, 1.8);
							ModMain._FilterAccount.AprilScaleTrans.ScaleY = ModBase.MathRange(1.0 - (Math.Abs(vector3.Y) - Math.Abs(vector3.X)) * (num4 / 100.0), 0.2, 1.8);
						}
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "愚人节移动出错", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x0600132A RID: 4906 RVA: 0x00081BE0 File Offset: 0x0007FDE0
		public static void UpdateStart(string BaseUrl, bool Slient, string ReceivedKey = null, bool ForceValidated = false)
		{
			if (ModMain._StateState)
			{
				if (ModMain.m_ProccesorState)
				{
					ModMain.UpdateRestart(true);
					return;
				}
			}
			else
			{
				ModMain._StateState = true;
				ModBase.Log("[System] 更新已开始，静默：" + Conversions.ToString(Slient), ModBase.LogLevel.Normal, "出现错误");
				string UpdateKey = "Publi2";
				if (!Slient)
				{
					ModMain.Hint("PCL2 正在下载更新，更新结束时将自动重启，请稍候！", ModMain.HintType.Info, true);
				}
				VB$AnonymousDelegate_2 $I1;
				Action<ModLoader.LoaderTask<string, int>> $IR1;
				ModBase.RunInUi(delegate()
				{
					try
					{
						string text = BaseUrl.Replace("{KEY}", UpdateKey);
						ModLoader.LoaderCombo<string> Loader = new ModLoader.LoaderCombo<string>("启动器更新", new ModLoader.LoaderBase[]
						{
							new ModNet.LoaderDownload("下载更新文件", new List<ModNet.NetFile>
							{
								new ModNet.NetFile(new string[]
								{
									text
								}, ModBase.attributeState + "Update.zip", new ModBase.FileChecker(1048576L, -1L, null, false, false))
							})
							{
								ProgressWeight = 1.0
							},
							new ModLoader.LoaderTask<string, int>("安装更新", ($IR1 == null) ? ($IR1 = delegate(ModLoader.LoaderTask<string, int> a0)
							{
								(($I1 == null) ? ($I1 = delegate()
								{
									File.Delete(ModBase.Path + "PCL\\Plain Craft Launcher 2.exe");
									ZipFile.ExtractToDirectory(ModBase.attributeState + "Update.zip", ModBase.Path + "PCL\\");
									File.Delete(ModBase.attributeState + "Update.zip");
									ModBase.Log("[System] 更新文件解压完成", ModBase.LogLevel.Normal, "出现错误");
									if (Slient)
									{
										ModMain.m_ProccesorState = true;
										return;
									}
									ModMain.UpdateRestart(true);
								}) : $I1)();
							}) : $IR1, null, ThreadPriority.Normal)
							{
								ProgressWeight = 0.1
							}
						});
						Loader.OnStateChanged = delegate(ModLoader.LoaderBase a0)
						{
							base._Lambda$__2();
						};
						Loader.Start(null, false);
						if (!Slient)
						{
							ModLoader.LoaderTaskbarAdd(Loader);
							ModMain.m_CollectionAccount.BtnExtraDownload.ShowRefresh();
						}
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "开始启动器更新失败", ModBase.LogLevel.Feedback, "出现错误");
					}
				}, false);
			}
		}

		// Token: 0x0600132B RID: 4907 RVA: 0x00081C70 File Offset: 0x0007FE70
		public static void UpdateRestart(bool TriggerRestartAndByEnd)
		{
			ModMain.m_ProccesorState = false;
			string fileName = ModBase.Path + "PCL\\Plain Craft Launcher 2.exe";
			string text = string.Concat(new string[]
			{
				"--update ",
				Conversions.ToString(Process.GetCurrentProcess().Id),
				" \"",
				AppDomain.CurrentDomain.SetupInformation.ApplicationName,
				"\" \"",
				AppDomain.CurrentDomain.SetupInformation.ApplicationName,
				"\" ",
				Conversions.ToString(TriggerRestartAndByEnd)
			});
			ModBase.Log("[System] 更新程序启动，参数：" + text, ModBase.LogLevel.Normal, "出现错误");
			Process.Start(new ProcessStartInfo(fileName)
			{
				WindowStyle = ProcessWindowStyle.Hidden,
				CreateNoWindow = true,
				Arguments = text
			});
			if (TriggerRestartAndByEnd)
			{
				ModMain.m_CollectionAccount.EndProgram(false);
				ModBase.Log("[System] 已由于更新强制结束程序", ModBase.LogLevel.Normal, "出现错误");
			}
		}

		// Token: 0x0600132C RID: 4908 RVA: 0x00081D54 File Offset: 0x0007FF54
		public static void UpdateReplace(int ProcessId, string OldFileName, string NewFileName, bool TriggerRestart)
		{
			try
			{
				Process.GetProcessById(ProcessId).Kill();
			}
			catch (Exception ex)
			{
			}
			checked
			{
				string path = Strings.Mid(ModBase.Path, 1, ModBase.Path.Length - 4) + ModBase.GetFileNameFromPath(OldFileName);
				string text = Strings.Mid(ModBase.Path, 1, ModBase.Path.Length - 4) + ModBase.GetFileNameFromPath(NewFileName);
				Exception ex2 = null;
				int num = 0;
				do
				{
					try
					{
						if (File.Exists(path))
						{
							File.Delete(path);
						}
						if (File.Exists(text))
						{
							File.Delete(text);
						}
						if (!File.Exists(path) && !File.Exists(text))
						{
							break;
						}
						Thread.Sleep(2000);
					}
					catch (Exception ex3)
					{
						ex2 = ex3;
					}
					num++;
				}
				while (num <= 4);
				if (!File.Exists(path) && !File.Exists(text))
				{
					try
					{
						File.Copy(ModBase.m_CodeState, text);
					}
					catch (UnauthorizedAccessException ex4)
					{
						Interaction.MsgBox("PCL2 更新失败：权限不足。请手动复制 PCL 文件夹下的新版本程序。\r\n若 PCL2 位于桌面或 C 盘，你可以尝试将其挪到其他文件夹，这可能可以解决权限问题。\r\n" + ModBase.GetString(ex4, true, false), MsgBoxStyle.Critical, "更新失败");
					}
					catch (Exception ex5)
					{
						Interaction.MsgBox("PCL2 更新失败：无法复制新文件。请手动复制 PCL 文件夹下的新版本程序。\r\n" + ModBase.GetString(ex5, true, false), MsgBoxStyle.Critical, "更新失败");
						return;
					}
					if (TriggerRestart)
					{
						try
						{
							Process.Start(text);
						}
						catch (Exception ex6)
						{
							Interaction.MsgBox("PCL2 更新失败：无法重新启动。\r\n" + ModBase.GetString(ex6, true, false), MsgBoxStyle.Critical, "更新失败");
						}
					}
					return;
				}
				if (ex2 is UnauthorizedAccessException)
				{
					Interaction.MsgBox(string.Concat(new string[]
					{
						"由于权限不足，PCL2 无法完成更新。请尝试：\r\n",
						(text.StartsWith(Environment.GetFolderPath(Environment.SpecialFolder.Desktop)) || text.StartsWith(Environment.GetFolderPath(Environment.SpecialFolder.Personal))) ? " - 将 PCL2 文件移动到桌面、文档以外的文件夹（这或许可以一劳永逸地解决权限问题）\r\n" : "",
						text.StartsWith("C") ? " - 将 PCL2 文件移动到 C 盘以外的文件夹（这或许可以一劳永逸地解决权限问题）\r\n" : "",
						" - 右键以管理员身份运行 PCL2\r\n - 手动复制已下载到 PCL 文件夹下的新版本程序，覆盖原程序\r\n\r\n",
						ModBase.GetString(ex2, true, false)
					}), MsgBoxStyle.Critical, "更新失败");
					return;
				}
				Interaction.MsgBox("PCL2 更新失败：无法删除原文件。请手动复制已下载到 PCL 文件夹下的新版本程序覆盖原程序。\r\n" + ModBase.GetString(ex2, true, false), MsgBoxStyle.Critical, "更新失败");
			}
		}

		// Token: 0x0600132D RID: 4909 RVA: 0x00081FBC File Offset: 0x000801BC
		public static void ShowWindowToTop(IntPtr Handle)
		{
			try
			{
				ModMain.PostMessageA(Handle, 6402U, 0L, 0L);
				ModMain.SetForegroundWindow(Handle);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "设置窗口置顶失败", ModBase.LogLevel.Hint, "出现错误");
			}
		}

		// Token: 0x0600132E RID: 4910
		[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		public static extern IntPtr FindWindowA([MarshalAs(UnmanagedType.VBByRefStr)] ref string ClassName, [MarshalAs(UnmanagedType.VBByRefStr)] ref string WindowName);

		// Token: 0x0600132F RID: 4911
		[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		public static extern int SetForegroundWindow(IntPtr hWnd);

		// Token: 0x06001330 RID: 4912
		[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		private static extern bool PostMessageA(IntPtr hWnd, uint msg, long wParam, long lParam);

		// Token: 0x06001331 RID: 4913 RVA: 0x00082020 File Offset: 0x00080220
		private static void TimerMain()
		{
			try
			{
				ModMain.HintTick();
				ModMain.MyMsgBoxTick();
				ModMain.m_CollectionAccount.DragTick();
				ModLoader.LoaderTaskbarProgressRefresh();
				if (ModMain.m_ObserverAccount == 2)
				{
					ModMain.CompareTag(-1);
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "短程主时钟执行异常", ModBase.LogLevel.Assert, "出现错误");
			}
			checked
			{
				ModMain._AuthenticationState++;
				if (ModMain._AuthenticationState == 4)
				{
					ModMain._AuthenticationState = 0;
					try
					{
						if (ModMain.customerAccount == 12)
						{
							ModMain.CompareTag(-1);
						}
					}
					catch (Exception ex2)
					{
						ModBase.Log(ex2, "中程主时钟执行异常", ModBase.LogLevel.Assert, "出现错误");
					}
				}
				ModMain.m_ReponseState++;
				if (ModMain.m_ReponseState == 150)
				{
					ModMain.m_ReponseState = 0;
					try
					{
						if (ModMain.m_CollectionAccount.BtnExtraApril_ShowCheck())
						{
							ModMain.m_CollectionAccount.BtnExtraApril.Ribble();
						}
						ModBase.RunInUi((ModMain._Closure$__.$I122-0 == null) ? (ModMain._Closure$__.$I122-0 = delegate()
						{
							if (!ModMain.m_CollectionAccount.Hidden)
							{
								if (ModMain.m_CollectionAccount.Top < -10000.0)
								{
									ModMain.m_CollectionAccount.Top = 100.0;
								}
								if (ModMain.m_CollectionAccount.Left < -10000.0)
								{
									ModMain.m_CollectionAccount.Left = 100.0;
								}
							}
						}) : ModMain._Closure$__.$I122-0, false);
					}
					catch (Exception ex3)
					{
						ModBase.Log(ex3, "长程主时钟执行异常", ModBase.LogLevel.Assert, "出现错误");
					}
				}
			}
		}

		// Token: 0x06001332 RID: 4914 RVA: 0x0008216C File Offset: 0x0008036C
		public static void TimerMainStartRun()
		{
			ModBase.RunInNewThread((ModMain._Closure$__.$I123-0 == null) ? (ModMain._Closure$__.$I123-0 = delegate()
			{
				try
				{
					for (;;)
					{
						ModBase.RunInUiWait(new Action(ModMain.TimerMain));
						Thread.Sleep(49);
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "程序主时钟出错", ModBase.LogLevel.Feedback, "出现错误");
				}
			}) : ModMain._Closure$__.$I123-0, "Timer Main", ThreadPriority.Normal);
			if (ModMain.m_ComparatorState)
			{
				ModBase.RunInNewThread((ModMain._Closure$__.$I123-1 == null) ? (ModMain._Closure$__.$I123-1 = delegate()
				{
					try
					{
						int tickCount = MyWpfExtension.FindModel().Clock.TickCount;
						for (;;)
						{
							if (tickCount != MyWpfExtension.FindModel().Clock.TickCount)
							{
								tickCount = MyWpfExtension.FindModel().Clock.TickCount;
								ModBase.RunInUiWait(new Action(ModMain.TimerFool));
							}
							Thread.Sleep(1);
						}
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "愚人节主时钟出错", ModBase.LogLevel.Feedback, "出现错误");
					}
				}) : ModMain._Closure$__.$I123-1, "Timer Main Fool", ThreadPriority.Normal);
			}
		}

		// Token: 0x04000957 RID: 2391
		private static List<ModMain.HintMessage> expressionAccount = ModMain.expressionAccount ?? new List<ModMain.HintMessage>();

		// Token: 0x04000958 RID: 2392
		public static List<ModMain.MyMsgBoxConverter> _GetterAccount = ModMain._GetterAccount ?? new List<ModMain.MyMsgBoxConverter>();

		// Token: 0x04000959 RID: 2393
		public static ModBase.MyColor _ListenerAccount = new ModBase.MyColor(52.0, 61.0, 74.0);

		// Token: 0x0400095A RID: 2394
		public static ModBase.MyColor _IdentifierAccount = new ModBase.MyColor(11.0, 91.0, 203.0);

		// Token: 0x0400095B RID: 2395
		public static ModBase.MyColor _InstanceAccount = new ModBase.MyColor(19.0, 112.0, 243.0);

		// Token: 0x0400095C RID: 2396
		public static ModBase.MyColor creatorAccount = new ModBase.MyColor(72.0, 144.0, 245.0);

		// Token: 0x0400095D RID: 2397
		public static ModBase.MyColor _ObjectAccount = new ModBase.MyColor(150.0, 192.0, 249.0);

		// Token: 0x0400095E RID: 2398
		public static ModBase.MyColor _RegAccount = new ModBase.MyColor(213.0, 230.0, 253.0);

		// Token: 0x0400095F RID: 2399
		public static ModBase.MyColor m_InvocationAccount = new ModBase.MyColor(222.0, 236.0, 253.0);

		// Token: 0x04000960 RID: 2400
		public static ModBase.MyColor m_ComposerAccount = new ModBase.MyColor(234.0, 242.0, 254.0);

		// Token: 0x04000961 RID: 2401
		public static ModBase.MyColor _ItemAccount = new ModBase.MyColor(128.0, ModMain.m_InvocationAccount);

		// Token: 0x04000962 RID: 2402
		public static ModBase.MyColor mapperAccount = new ModBase.MyColor(64.0, 64.0, 64.0);

		// Token: 0x04000963 RID: 2403
		public static ModBase.MyColor factoryAccount = new ModBase.MyColor(115.0, 115.0, 115.0);

		// Token: 0x04000964 RID: 2404
		public static ModBase.MyColor processAccount = new ModBase.MyColor(140.0, 140.0, 140.0);

		// Token: 0x04000965 RID: 2405
		public static ModBase.MyColor _ValAccount = new ModBase.MyColor(166.0, 166.0, 166.0);

		// Token: 0x04000966 RID: 2406
		public static ModBase.MyColor m_UtilsAccount = new ModBase.MyColor(204.0, 204.0, 204.0);

		// Token: 0x04000967 RID: 2407
		public static ModBase.MyColor m_OrderAccount = new ModBase.MyColor(235.0, 235.0, 235.0);

		// Token: 0x04000968 RID: 2408
		public static ModBase.MyColor _PolicyAccount = new ModBase.MyColor(240.0, 240.0, 240.0);

		// Token: 0x04000969 RID: 2409
		public static ModBase.MyColor _ThreadAccount = new ModBase.MyColor(245.0, 245.0, 245.0);

		// Token: 0x0400096A RID: 2410
		public static ModBase.MyColor m_ConnectionAccount = new ModBase.MyColor(1.0, ModMain.m_ComposerAccount);

		// Token: 0x0400096B RID: 2411
		public static int customerAccount = -1;

		// Token: 0x0400096C RID: 2412
		public static int m_SchemaAccount = 210;

		// Token: 0x0400096D RID: 2413
		public static int _DatabaseAccount = 85;

		// Token: 0x0400096E RID: 2414
		public static int _CallbackAccount = 0;

		// Token: 0x0400096F RID: 2415
		public static object m_AdvisorAccount = 0;

		// Token: 0x04000970 RID: 2416
		public static int m_ObserverAccount = 0;

		// Token: 0x04000971 RID: 2417
		private static bool singletonAccount = false;

		// Token: 0x04000972 RID: 2418
		private static int contextAccount = 1;

		// Token: 0x04000973 RID: 2419
		public static FormMain m_CollectionAccount;

		// Token: 0x04000974 RID: 2420
		public static SplashScreen consumerAccount;

		// Token: 0x04000975 RID: 2421
		public static PageLaunchLeft _FilterAccount;

		// Token: 0x04000976 RID: 2422
		public static PageLaunchRight _ReaderAccount;

		// Token: 0x04000977 RID: 2423
		public static PageSelectLeft fieldAccount;

		// Token: 0x04000978 RID: 2424
		public static PageSelectRight _PageAccount;

		// Token: 0x04000979 RID: 2425
		public static PageSpeedLeft _PrinterAccount;

		// Token: 0x0400097A RID: 2426
		public static PageSpeedRight m_TokenAccount;

		// Token: 0x0400097B RID: 2427
		public static PageLinkLeft m_InterpreterAccount;

		// Token: 0x0400097C RID: 2428
		public static PageLinkIoi _ParserAccount;

		// Token: 0x0400097D RID: 2429
		public static PageOtherHelpDetail m_StubAccount;

		// Token: 0x0400097E RID: 2430
		public static PageLinkFeedback _ErrorAccount;

		// Token: 0x0400097F RID: 2431
		public static PageDownloadLeft exceptionAccount;

		// Token: 0x04000980 RID: 2432
		public static PageDownloadInstall _TestsAccount;

		// Token: 0x04000981 RID: 2433
		public static PageDownloadClient strategyAccount;

		// Token: 0x04000982 RID: 2434
		public static PageDownloadOptiFine _RulesAccount;

		// Token: 0x04000983 RID: 2435
		public static PageDownloadLiteLoader _WorkerAccount;

		// Token: 0x04000984 RID: 2436
		public static PageDownloadForge _DicAccount;

		// Token: 0x04000985 RID: 2437
		public static PageDownloadFabric configurationAccount;

		// Token: 0x04000986 RID: 2438
		public static PageDownloadMod m_ConfigAccount;

		// Token: 0x04000987 RID: 2439
		public static PageDownloadPack managerAccount;

		// Token: 0x04000988 RID: 2440
		public static PageSetupLeft _RuleAccount;

		// Token: 0x04000989 RID: 2441
		public static PageSetupLaunch m_MerchantAccount;

		// Token: 0x0400098A RID: 2442
		public static PageSetupUI m_ExporterAccount;

		// Token: 0x0400098B RID: 2443
		public static PageSetupSystem queueAccount;

		// Token: 0x0400098C RID: 2444
		public static PageSetupLink m_GlobalAccount;

		// Token: 0x0400098D RID: 2445
		public static PageOtherLeft m_ListAccount;

		// Token: 0x0400098E RID: 2446
		public static PageOtherHelp m_MethodAccount;

		// Token: 0x0400098F RID: 2447
		public static PageOtherAbout m_AnnotationAccount;

		// Token: 0x04000990 RID: 2448
		public static PageOtherFeedback interceptorAccount;

		// Token: 0x04000991 RID: 2449
		public static PageOtherTest m_RefAccount;

		// Token: 0x04000992 RID: 2450
		public static PageLoginMojang _ServerAccount;

		// Token: 0x04000993 RID: 2451
		public static PageLoginMojangSkin serviceAccount;

		// Token: 0x04000994 RID: 2452
		public static PageLoginLegacy _ImporterAccount;

		// Token: 0x04000995 RID: 2453
		public static PageLoginNide _ProxyAccount;

		// Token: 0x04000996 RID: 2454
		public static PageLoginNideSkin _ClassAccount;

		// Token: 0x04000997 RID: 2455
		public static PageLoginAuth m_RegistryAccount;

		// Token: 0x04000998 RID: 2456
		public static PageLoginAuthSkin m_ProducerAccount;

		// Token: 0x04000999 RID: 2457
		public static PageLoginMs candidateAccount;

		// Token: 0x0400099A RID: 2458
		public static PageLoginMsSkin _SetterAccount;

		// Token: 0x0400099B RID: 2459
		public static PageVersionLeft _MappingAccount;

		// Token: 0x0400099C RID: 2460
		public static PageVersionOverall dispatcherAccount;

		// Token: 0x0400099D RID: 2461
		public static PageVersionMod m_MessageAccount;

		// Token: 0x0400099E RID: 2462
		public static PageVersionModDisabled m_StatusAccount;

		// Token: 0x0400099F RID: 2463
		public static PageVersionSetup _ProcAccount;

		// Token: 0x040009A0 RID: 2464
		public static PageDownloadCfDetail modelState;

		// Token: 0x040009A1 RID: 2465
		public static ModLoader.LoaderTask<int, Dictionary<string, List<ModMain.FeedbackEntry>>> wrapperState = new ModLoader.LoaderTask<int, Dictionary<string, List<ModMain.FeedbackEntry>>>("Feedback Page", new Action<ModLoader.LoaderTask<int, Dictionary<string, List<ModMain.FeedbackEntry>>>>(ModMain.FeedbackLoad), null, ThreadPriority.Lowest)
		{
			ReloadTimeout = 180000
		};

		// Token: 0x040009A2 RID: 2466
		public static ModLoader.LoaderTask<int, List<ModMain.HelpEntry>> m_RepositoryState = new ModLoader.LoaderTask<int, List<ModMain.HelpEntry>>("Help Page", new Action<ModLoader.LoaderTask<int, List<ModMain.HelpEntry>>>(ModMain.HelpLoad), null, ThreadPriority.BelowNormal);

		// Token: 0x040009A3 RID: 2467
		private static readonly object m_ResolverState = RuntimeHelpers.GetObjectValue(new object());

		// Token: 0x040009A4 RID: 2468
		public static ModLoader.LoaderTask<int, int> _TagState = new ModLoader.LoaderTask<int, int>("PCL2 服务", new Action<ModLoader.LoaderTask<int, int>>(ModMain.ServerSub), null, ThreadPriority.BelowNormal);

		// Token: 0x040009A5 RID: 2469
		public static bool m_ComparatorState = DateTime.Now.Month == 4 && DateTime.Now.Day == 1;

		// Token: 0x040009A6 RID: 2470
		public static bool m_PrototypeState = false;

		// Token: 0x040009A7 RID: 2471
		private static Vector issuerState = new Vector(0.0, 0.0);

		// Token: 0x040009A8 RID: 2472
		private static int _RequestState = 0;

		// Token: 0x040009A9 RID: 2473
		private static Point _AccountState = new Point(0.0, 0.0);

		// Token: 0x040009AA RID: 2474
		public static bool _StateState = false;

		// Token: 0x040009AB RID: 2475
		public static bool m_ProccesorState = false;

		// Token: 0x040009AC RID: 2476
		public static MySlider _ParameterState = null;

		// Token: 0x040009AD RID: 2477
		private static int _AuthenticationState = 0;

		// Token: 0x040009AE RID: 2478
		private static int m_ReponseState = 0;

		// Token: 0x02000197 RID: 407
		public enum HintType
		{
			// Token: 0x040009B0 RID: 2480
			Info,
			// Token: 0x040009B1 RID: 2481
			Finish,
			// Token: 0x040009B2 RID: 2482
			Critical
		}

		// Token: 0x02000198 RID: 408
		private struct HintMessage
		{
			// Token: 0x040009B3 RID: 2483
			public string regParameter;

			// Token: 0x040009B4 RID: 2484
			public ModMain.HintType Type;

			// Token: 0x040009B5 RID: 2485
			public bool invocationParameter;
		}

		// Token: 0x02000199 RID: 409
		public class MyMsgBoxConverter
		{
			// Token: 0x06001333 RID: 4915 RVA: 0x000821E0 File Offset: 0x000803E0
			public MyMsgBoxConverter()
			{
				this.mapperParameter = "";
				this._ProcessParameter = "确定";
				this._ValParameter = "";
				this.utilsParameter = "";
				this.m_OrderParameter = false;
				this._PolicyParameter = false;
				this.m_ThreadParameter = new DispatcherFrame(true);
				this.connectionParameter = false;
			}

			// Token: 0x040009B6 RID: 2486
			public ModMain.MyMsgBoxType Type;

			// Token: 0x040009B7 RID: 2487
			public string Title;

			// Token: 0x040009B8 RID: 2488
			public object m_ComposerParameter;

			// Token: 0x040009B9 RID: 2489
			public Collection<Validate> itemParameter;

			// Token: 0x040009BA RID: 2490
			public string mapperParameter;

			// Token: 0x040009BB RID: 2491
			public bool factoryParameter;

			// Token: 0x040009BC RID: 2492
			public string _ProcessParameter;

			// Token: 0x040009BD RID: 2493
			public string _ValParameter;

			// Token: 0x040009BE RID: 2494
			public string utilsParameter;

			// Token: 0x040009BF RID: 2495
			public bool m_OrderParameter;

			// Token: 0x040009C0 RID: 2496
			public bool _PolicyParameter;

			// Token: 0x040009C1 RID: 2497
			public DispatcherFrame m_ThreadParameter;

			// Token: 0x040009C2 RID: 2498
			public bool connectionParameter;

			// Token: 0x040009C3 RID: 2499
			public string _CustomerParameter;
		}

		// Token: 0x0200019A RID: 410
		public enum MyMsgBoxType
		{
			// Token: 0x040009C5 RID: 2501
			Text,
			// Token: 0x040009C6 RID: 2502
			Select,
			// Token: 0x040009C7 RID: 2503
			Input
		}

		// Token: 0x0200019B RID: 411
		public struct FeedbackEntry
		{
			// Token: 0x06001335 RID: 4917 RVA: 0x0000B290 File Offset: 0x00009490
			public bool IsActive()
			{
				return Operators.CompareString(this.databaseParameter, "尚未查看", true) == 0 || Operators.CompareString(this.databaseParameter, "等待确认", true) == 0 || Operators.CompareString(this.databaseParameter, "正在处理", true) == 0;
			}

			// Token: 0x040009C8 RID: 2504
			public int _SchemaParameter;

			// Token: 0x040009C9 RID: 2505
			public string Type;

			// Token: 0x040009CA RID: 2506
			public string databaseParameter;

			// Token: 0x040009CB RID: 2507
			public string m_CallbackParameter;

			// Token: 0x040009CC RID: 2508
			public string Title;

			// Token: 0x040009CD RID: 2509
			public int advisorParameter;

			// Token: 0x040009CE RID: 2510
			public string observerParameter;

			// Token: 0x040009CF RID: 2511
			public string m_SingletonParameter;

			// Token: 0x040009D0 RID: 2512
			public string contextParameter;

			// Token: 0x040009D1 RID: 2513
			public string _CollectionParameter;

			// Token: 0x040009D2 RID: 2514
			public string m_ConsumerParameter;

			// Token: 0x040009D3 RID: 2515
			public string filterParameter;
		}

		// Token: 0x0200019C RID: 412
		public class HelpEntry
		{
			// Token: 0x06001337 RID: 4919 RVA: 0x00082244 File Offset: 0x00080444
			public HelpEntry(string FilePath)
			{
				this.printerParameter = null;
				this.tokenParameter = true;
				this._InterpreterParameter = true;
				this.m_ParserParameter = true;
				JObject jobject = (JObject)ModBase.GetJson(ModBase.ReadFile(FilePath).Replace("{path}", ModBase.Path));
				if (jobject == null)
				{
					throw new FileNotFoundException("未找到帮助文件：" + FilePath, FilePath);
				}
				if (jobject["Title"] == null)
				{
					throw new ArgumentException("未找到 Title 项");
				}
				this.Title = (string)jobject["Title"];
				this.m_ReaderParameter = (string)(jobject["Description"] ?? "");
				this._FieldParameter = (string)(jobject["Keywords"] ?? "");
				this.printerParameter = (string)jobject["Logo"];
				this.tokenParameter = (bool)(jobject["ShowInSearch"] ?? this.tokenParameter);
				this._InterpreterParameter = (bool)(jobject["ShowInPublic"] ?? this._InterpreterParameter);
				this.m_ParserParameter = (bool)(jobject["ShowInSnapshot"] ?? this.m_ParserParameter);
				this.m_PageParameter = new List<string>();
				try
				{
					foreach (object obj in ((IEnumerable)(jobject["Types"] ?? ModBase.GetJson("[]"))))
					{
						object objectValue = RuntimeHelpers.GetObjectValue(obj);
						this.m_PageParameter.Add(Conversions.ToString(objectValue));
					}
				}
				finally
				{
					IEnumerator enumerator;
					if (enumerator is IDisposable)
					{
						(enumerator as IDisposable).Dispose();
					}
				}
				if (((bool?)(jobject["IsEvent"] ?? false)).GetValueOrDefault())
				{
					this._ErrorParameter = (string)jobject["EventType"];
					if (this._ErrorParameter == null)
					{
						throw new ArgumentException("未找到 EventType 项");
					}
					this._ExceptionParameter = (string)(jobject["EventData"] ?? "");
					this.m_StubParameter = true;
					return;
				}
				else
				{
					string text = FilePath.ToLower().Replace(".json", ".xaml");
					if (!File.Exists(text))
					{
						throw new FileNotFoundException("未找到帮助条目 .json 对应的 .xaml 文件（" + text + "）");
					}
					this._TestsParameter = ModBase.ReadFile(text);
					this.m_StubParameter = false;
					return;
				}
			}

			// Token: 0x06001338 RID: 4920 RVA: 0x0000B2CE File Offset: 0x000094CE
			public MyListItem ToListItem()
			{
				return this.SetToListItem(new MyListItem());
			}

			// Token: 0x06001339 RID: 4921 RVA: 0x000824E8 File Offset: 0x000806E8
			public MyListItem SetToListItem(MyListItem Item)
			{
				string text;
				if (this.m_StubParameter)
				{
					if (Operators.CompareString(this._ErrorParameter, "弹出窗口", true) == 0)
					{
						text = "pack://application:,,,/images/Blocks/GrassPath.png";
					}
					else
					{
						text = "pack://application:,,,/images/Blocks/CommandBlock.png";
					}
				}
				else
				{
					text = "pack://application:,,,/images/Blocks/Grass.png";
				}
				Item.SnapsToDevicePixels = true;
				Item.Title = this.Title;
				Item.Info = this.m_ReaderParameter;
				Item.Logo = (this.printerParameter ?? text);
				Item.Height = 42.0;
				Item.Type = MyListItem.CheckType.Clickable;
				Item.Tag = this;
				Item.PaddingRight = 4;
				Item.EventType = null;
				Item.EventData = null;
				Item.WriteResolver((ModMain.HelpEntry._Closure$__.$I14-0 == null) ? (ModMain.HelpEntry._Closure$__.$I14-0 = delegate(object sender, MouseButtonEventArgs e)
				{
					PageOtherHelp.OnItemClick((ModMain.HelpEntry)NewLateBinding.LateGet(sender, null, "Tag", new object[0], null, null, null));
				}) : ModMain.HelpEntry._Closure$__.$I14-0);
				return Item;
			}

			// Token: 0x040009D4 RID: 2516
			public string Title;

			// Token: 0x040009D5 RID: 2517
			public string m_ReaderParameter;

			// Token: 0x040009D6 RID: 2518
			public string _FieldParameter;

			// Token: 0x040009D7 RID: 2519
			public List<string> m_PageParameter;

			// Token: 0x040009D8 RID: 2520
			public string printerParameter;

			// Token: 0x040009D9 RID: 2521
			public bool tokenParameter;

			// Token: 0x040009DA RID: 2522
			public bool _InterpreterParameter;

			// Token: 0x040009DB RID: 2523
			public bool m_ParserParameter;

			// Token: 0x040009DC RID: 2524
			public bool m_StubParameter;

			// Token: 0x040009DD RID: 2525
			public string _ErrorParameter;

			// Token: 0x040009DE RID: 2526
			public string _ExceptionParameter;

			// Token: 0x040009DF RID: 2527
			public string _TestsParameter;
		}
	}
}
