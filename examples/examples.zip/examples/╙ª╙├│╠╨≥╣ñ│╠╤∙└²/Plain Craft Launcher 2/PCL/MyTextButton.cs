﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200005F RID: 95
	public class MyTextButton : Label
	{
		// Token: 0x060002E5 RID: 741 RVA: 0x00018B20 File Offset: 0x00016D20
		[CompilerGenerated]
		public void ResolveRepository(MyTextButton.ClickEventHandler obj)
		{
			MyTextButton.ClickEventHandler clickEventHandler = this.m_VisitorWrapper;
			MyTextButton.ClickEventHandler clickEventHandler2;
			do
			{
				clickEventHandler2 = clickEventHandler;
				MyTextButton.ClickEventHandler value = (MyTextButton.ClickEventHandler)Delegate.Combine(clickEventHandler2, obj);
				clickEventHandler = Interlocked.CompareExchange<MyTextButton.ClickEventHandler>(ref this.m_VisitorWrapper, value, clickEventHandler2);
			}
			while (clickEventHandler != clickEventHandler2);
		}

		// Token: 0x060002E6 RID: 742 RVA: 0x00018B58 File Offset: 0x00016D58
		[CompilerGenerated]
		public void TestRepository(MyTextButton.ClickEventHandler obj)
		{
			MyTextButton.ClickEventHandler clickEventHandler = this.m_VisitorWrapper;
			MyTextButton.ClickEventHandler clickEventHandler2;
			do
			{
				clickEventHandler2 = clickEventHandler;
				MyTextButton.ClickEventHandler value = (MyTextButton.ClickEventHandler)Delegate.Remove(clickEventHandler2, obj);
				clickEventHandler = Interlocked.CompareExchange<MyTextButton.ClickEventHandler>(ref this.m_VisitorWrapper, value, clickEventHandler2);
			}
			while (clickEventHandler != clickEventHandler2);
		}

		// Token: 0x060002E7 RID: 743 RVA: 0x00018B90 File Offset: 0x00016D90
		public MyTextButton()
		{
			base.PreviewMouseLeftButtonDown += this.MyTextButton_MouseLeftButtonDown;
			base.MouseLeave += delegate(object sender, MouseEventArgs e)
			{
				this.MyTextButton_MouseLeave();
			};
			base.PreviewMouseLeftButtonUp += this.MyTextButton_MouseLeftButtonUp;
			base.MouseEnter += delegate(object sender, MouseEventArgs e)
			{
				this.RefreshColor();
			};
			base.MouseLeave += delegate(object sender, MouseEventArgs e)
			{
				this.RefreshColor();
			};
			base.IsEnabledChanged += delegate(object sender, DependencyPropertyChangedEventArgs e)
			{
				this.RefreshColor();
			};
			base.MouseLeftButtonDown += delegate(object sender, MouseButtonEventArgs e)
			{
				this.RefreshColor();
			};
			base.MouseLeftButtonUp += delegate(object sender, MouseButtonEventArgs e)
			{
				this.RefreshColor();
			};
			this.helperWrapper = ModBase.GetUuid();
			this.baseWrapper = false;
			base.SetResourceReference(Control.ForegroundProperty, "ColorBrush1");
			base.Background = ModMain.m_ConnectionAccount;
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x060002E8 RID: 744 RVA: 0x00003A0A File Offset: 0x00001C0A
		// (set) Token: 0x060002E9 RID: 745 RVA: 0x00003A1C File Offset: 0x00001C1C
		public string Text
		{
			get
			{
				return Conversions.ToString(base.GetValue(MyTextButton._ParamWrapper));
			}
			set
			{
				base.SetValue(MyTextButton._ParamWrapper, value);
			}
		}

		// Token: 0x060002EA RID: 746 RVA: 0x00003A2A File Offset: 0x00001C2A
		private void MyTextButton_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			this.baseWrapper = true;
			e.Handled = true;
		}

		// Token: 0x060002EB RID: 747 RVA: 0x00003A3A File Offset: 0x00001C3A
		private void MyTextButton_MouseLeave()
		{
			this.baseWrapper = false;
		}

		// Token: 0x060002EC RID: 748 RVA: 0x00018C68 File Offset: 0x00016E68
		private void MyTextButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.baseWrapper)
			{
				this.baseWrapper = false;
				ModBase.Log("[Control] 按下文本按钮：" + this.Text, ModBase.LogLevel.Normal, "出现错误");
				MyTextButton.ClickEventHandler visitorWrapper = this.m_VisitorWrapper;
				if (visitorWrapper != null)
				{
					visitorWrapper(this, null);
				}
				ModEvent.TryStartEvent(this.EventType, this.EventData);
				e.Handled = true;
			}
		}

		// Token: 0x060002ED RID: 749 RVA: 0x00018CCC File Offset: 0x00016ECC
		private void RefreshColor()
		{
			string text;
			int time;
			if (this.baseWrapper)
			{
				text = "ColorBrush4";
				time = 30;
			}
			else if (base.IsMouseOver)
			{
				text = "ColorBrush3";
				time = 100;
			}
			else
			{
				text = "ColorBrush1";
				time = 200;
			}
			if (Operators.CompareString(this.m_ProductWrapper, text, true) != 0)
			{
				this.m_ProductWrapper = text;
				if (base.IsLoaded && ModAnimation.DefineModel() == 0)
				{
					ModAnimation.AniStart(ModAnimation.AaColor(this, Control.ForegroundProperty, text, time, 0, null, false), "MyTextButton Color " + Conversions.ToString(this.helperWrapper), false);
					return;
				}
				ModAnimation.AniStop("MyTextButton Color " + Conversions.ToString(this.helperWrapper));
				base.SetResourceReference(Control.ForegroundProperty, text);
			}
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x060002EE RID: 750 RVA: 0x00003A43 File Offset: 0x00001C43
		// (set) Token: 0x060002EF RID: 751 RVA: 0x00003A55 File Offset: 0x00001C55
		public string EventType
		{
			get
			{
				return Conversions.ToString(base.GetValue(MyTextButton._AttrWrapper));
			}
			set
			{
				base.SetValue(MyTextButton._AttrWrapper, value);
			}
		}

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x060002F0 RID: 752 RVA: 0x00003A63 File Offset: 0x00001C63
		// (set) Token: 0x060002F1 RID: 753 RVA: 0x00003A75 File Offset: 0x00001C75
		public string EventData
		{
			get
			{
				return Conversions.ToString(base.GetValue(MyTextButton.m_FacadeWrapper));
			}
			set
			{
				base.SetValue(MyTextButton.m_FacadeWrapper, value);
			}
		}

		// Token: 0x04000134 RID: 308
		[CompilerGenerated]
		private MyTextButton.ClickEventHandler m_VisitorWrapper;

		// Token: 0x04000135 RID: 309
		public int helperWrapper;

		// Token: 0x04000136 RID: 310
		public static readonly DependencyProperty _ParamWrapper = DependencyProperty.Register("Text", typeof(string), typeof(MyTextButton), new PropertyMetadata("", delegate(DependencyObject a0, DependencyPropertyChangedEventArgs a1)
		{
			((MyTextButton._Closure$__.$I0-0 == null) ? (MyTextButton._Closure$__.$I0-0 = delegate(MyTextButton sender, DependencyPropertyChangedEventArgs e)
			{
				if (Conversions.ToBoolean(Operators.NotObject(Operators.CompareObjectEqual(e.OldValue, e.NewValue, true))))
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaOpacity(sender, -sender.Opacity, 50, 0, null, false),
						ModAnimation.AaCode(delegate
						{
							sender.Content = RuntimeHelpers.GetObjectValue(e.NewValue);
						}, 0, true),
						ModAnimation.AaOpacity(sender, 1.0, 170, 0, null, false)
					}, "MyTextButton Text " + Conversions.ToString(sender.helperWrapper), false);
				}
			}) : MyTextButton._Closure$__.$I0-0)((MyTextButton)a0, a1);
		}));

		// Token: 0x04000137 RID: 311
		public bool baseWrapper;

		// Token: 0x04000138 RID: 312
		private string m_ProductWrapper;

		// Token: 0x04000139 RID: 313
		public static readonly DependencyProperty _AttrWrapper = DependencyProperty.Register("EventType", typeof(string), typeof(MyTextButton), new PropertyMetadata(null));

		// Token: 0x0400013A RID: 314
		public static readonly DependencyProperty m_FacadeWrapper = DependencyProperty.Register("EventData", typeof(string), typeof(MyTextButton), new PropertyMetadata(null));

		// Token: 0x02000060 RID: 96
		// (Invoke) Token: 0x060002FB RID: 763
		public delegate void ClickEventHandler(object sender, EventArgs e);
	}
}
