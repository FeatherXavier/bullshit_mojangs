﻿using System;

namespace PCL
{
	// Token: 0x020000E0 RID: 224
	public abstract class Validate
	{
		// Token: 0x060008E7 RID: 2279
		public abstract string Validate(string Str);
	}
}
