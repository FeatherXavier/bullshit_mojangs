﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x020000EA RID: 234
	public class ValidateFolderName : Validate
	{
		// Token: 0x17000163 RID: 355
		// (get) Token: 0x06000920 RID: 2336 RVA: 0x0000685A File Offset: 0x00004A5A
		// (set) Token: 0x06000921 RID: 2337 RVA: 0x00006862 File Offset: 0x00004A62
		public string Path { get; set; }

		// Token: 0x06000922 RID: 2338 RVA: 0x0000686B File Offset: 0x00004A6B
		[CompilerGenerated]
		public bool DeleteRepository()
		{
			return this._SpecificationTag;
		}

		// Token: 0x06000923 RID: 2339 RVA: 0x00006873 File Offset: 0x00004A73
		[CompilerGenerated]
		public void CompareRepository(bool AutoPropertyValue)
		{
			this._SpecificationTag = AutoPropertyValue;
		}

		// Token: 0x06000924 RID: 2340 RVA: 0x0000687C File Offset: 0x00004A7C
		[CompilerGenerated]
		public bool SearchRepository()
		{
			return this._PredicateTag;
		}

		// Token: 0x06000925 RID: 2341 RVA: 0x00006884 File Offset: 0x00004A84
		[CompilerGenerated]
		public void AssetRepository(bool AutoPropertyValue)
		{
			this._PredicateTag = AutoPropertyValue;
		}

		// Token: 0x06000926 RID: 2342 RVA: 0x0003FB40 File Offset: 0x0003DD40
		public ValidateFolderName(string Path, bool UseMinecraftCharCheck = true, bool IgnoreCase = true)
		{
			this.CompareRepository(true);
			this.AssetRepository(true);
			int num2;
			int num4;
			object obj;
			try
			{
				IL_15:
				int num = 1;
				this.Path = Path;
				IL_1E:
				num = 2;
				this.AssetRepository(IgnoreCase);
				IL_27:
				num = 3;
				this.CompareRepository(UseMinecraftCharCheck);
				IL_30:
				ProjectData.ClearProjectError();
				num2 = 1;
				IL_37:
				num = 5;
				this.m_ClientTag = new DirectoryInfo(Path).EnumerateDirectories();
				IL_4A:
				goto IL_B1;
				IL_4C:
				int num3 = num4 + 1;
				num4 = 0;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
				IL_72:
				goto IL_A6;
				IL_74:
				num4 = num;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num2);
				IL_84:;
			}
			catch when (endfilter(obj is Exception & num2 != 0 & num4 == 0))
			{
				Exception ex = (Exception)obj2;
				goto IL_74;
			}
			IL_A6:
			throw ProjectData.CreateProjectError(-2146828237);
			IL_B1:
			if (num4 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		// Token: 0x06000927 RID: 2343 RVA: 0x0003FC18 File Offset: 0x0003DE18
		public override string Validate(string Str)
		{
			string result;
			try
			{
				string text = new ValidateNullOrWhiteSpace().Validate(Str);
				if (Operators.CompareString(text, "", true) != 0)
				{
					result = text;
				}
				else if (Str.StartsWith(" "))
				{
					result = "文件夹名不能以空格开头！";
				}
				else if (Str.EndsWith(" "))
				{
					result = "文件夹名不能以空格结尾！";
				}
				else
				{
					text = new ValidateLength(1, 100).Validate(Str);
					if (Operators.CompareString(text, "", true) != 0)
					{
						result = text;
					}
					else if (Str.EndsWith("."))
					{
						result = "文件夹名不能以小数点结尾！";
					}
					else
					{
						string text2 = new ValidateExcept(new string(System.IO.Path.GetInvalidFileNameChars()) + (this.DeleteRepository() ? "!;" : ""), "文件夹名不可包含 % 字符！").Validate(Str);
						if (Operators.CompareString(text2, "", true) != 0)
						{
							result = text2;
						}
						else
						{
							string text3 = new ValidateExceptSame(new string[]
							{
								"CON",
								"PRN",
								"AUX",
								"CLOCK$",
								"NUL",
								"COM0",
								"COM1",
								"COM2",
								"COM3",
								"COM4",
								"COM5",
								"COM6",
								"COM7",
								"COM8",
								"COM9",
								"LPT0",
								"LPT1",
								"LPT2",
								"LPT3",
								"LPT4",
								"LPT5",
								"LPT6",
								"LPT7",
								"LPT8",
								"LPT9"
							}, "文件夹名不可为 %！", false).Validate(Str);
							if (Operators.CompareString(text3, "", true) != 0)
							{
								result = text3;
							}
							else
							{
								List<string> list = new List<string>();
								if (this.m_ClientTag != null)
								{
									try
									{
										foreach (DirectoryInfo directoryInfo in this.m_ClientTag)
										{
											list.Add(directoryInfo.Name);
										}
									}
									finally
									{
										IEnumerator<DirectoryInfo> enumerator;
										if (enumerator != null)
										{
											enumerator.Dispose();
										}
									}
								}
								string text4 = new ValidateExceptSame(list, "不可与现有文件夹重名！", this.SearchRepository()).Validate(Str);
								if (Operators.CompareString(text4, "", true) != 0)
								{
									result = text4;
								}
								else
								{
									result = "";
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "检查文件夹名出错", ModBase.LogLevel.Debug, "出现错误");
				result = "错误：" + ex.Message;
			}
			return result;
		}

		// Token: 0x04000466 RID: 1126
		[CompilerGenerated]
		private string m_AttributeTag;

		// Token: 0x04000467 RID: 1127
		[CompilerGenerated]
		private bool _SpecificationTag;

		// Token: 0x04000468 RID: 1128
		[CompilerGenerated]
		private bool _PredicateTag;

		// Token: 0x04000469 RID: 1129
		private readonly IEnumerable<DirectoryInfo> m_ClientTag;
	}
}
