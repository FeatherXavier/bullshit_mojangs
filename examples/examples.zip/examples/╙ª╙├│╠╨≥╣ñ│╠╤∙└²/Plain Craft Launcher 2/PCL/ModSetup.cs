﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Effects;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000155 RID: 341
	public class ModSetup
	{
		// Token: 0x06000DE8 RID: 3560 RVA: 0x00066318 File Offset: 0x00064518
		public ModSetup()
		{
			this.indexerPrototype = new Dictionary<string, ModSetup.SetupEntry>
			{
				{
					"Identify",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, false)
				},
				{
					"HintDownloadThread",
					new ModSetup.SetupEntry(false, ModSetup.SetupSource.Registry, false)
				},
				{
					"HintNotice",
					new ModSetup.SetupEntry(0, ModSetup.SetupSource.Registry, false)
				},
				{
					"HintDownload",
					new ModSetup.SetupEntry(0, ModSetup.SetupSource.Registry, false)
				},
				{
					"HintFeedbackDelete",
					new ModSetup.SetupEntry(false, ModSetup.SetupSource.Registry, false)
				},
				{
					"HintFeedback",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, false)
				},
				{
					"HintModDisable",
					new ModSetup.SetupEntry(false, ModSetup.SetupSource.Registry, false)
				},
				{
					"HintInstallBack",
					new ModSetup.SetupEntry(false, ModSetup.SetupSource.Registry, false)
				},
				{
					"HintInstallFabricApi",
					new ModSetup.SetupEntry(false, ModSetup.SetupSource.Registry, false)
				},
				{
					"HintHide",
					new ModSetup.SetupEntry(false, ModSetup.SetupSource.Registry, false)
				},
				{
					"HintHandInstall",
					new ModSetup.SetupEntry(false, ModSetup.SetupSource.Registry, false)
				},
				{
					"TestSetupReader",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"SystemEula",
					new ModSetup.SetupEntry(false, ModSetup.SetupSource.Registry, false)
				},
				{
					"SystemCount",
					new ModSetup.SetupEntry(0, ModSetup.SetupSource.Registry, true)
				},
				{
					"SystemLaunchCount",
					new ModSetup.SetupEntry(0, ModSetup.SetupSource.Registry, true)
				},
				{
					"SystemLastVersionReg",
					new ModSetup.SetupEntry(0, ModSetup.SetupSource.Registry, true)
				},
				{
					"SystemHighestBetaVersionReg",
					new ModSetup.SetupEntry(0, ModSetup.SetupSource.Registry, true)
				},
				{
					"SystemHighestAlphaVersionReg",
					new ModSetup.SetupEntry(0, ModSetup.SetupSource.Registry, true)
				},
				{
					"SystemSetupVersionReg",
					new ModSetup.SetupEntry(1, ModSetup.SetupSource.Registry, false)
				},
				{
					"SystemSetupVersionIni",
					new ModSetup.SetupEntry(1, 0, false)
				},
				{
					"SystemHelpVersion",
					new ModSetup.SetupEntry(0, ModSetup.SetupSource.Registry, false)
				},
				{
					"SystemDebugMode",
					new ModSetup.SetupEntry(false, ModSetup.SetupSource.Registry, false)
				},
				{
					"SystemDebugAnim",
					new ModSetup.SetupEntry(9, ModSetup.SetupSource.Registry, false)
				},
				{
					"SystemDebugDelay",
					new ModSetup.SetupEntry(false, ModSetup.SetupSource.Registry, false)
				},
				{
					"SystemDebugSkipCopy",
					new ModSetup.SetupEntry(false, ModSetup.SetupSource.Registry, false)
				},
				{
					"SystemSystemCache",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, false)
				},
				{
					"SystemSystemUpdate",
					new ModSetup.SetupEntry(0, 0, false)
				},
				{
					"SystemSystemActivity",
					new ModSetup.SetupEntry(0, 0, false)
				},
				{
					"CacheMsOAuthRefresh",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheMsAccess",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheMsUuid",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheMsName",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheMojangAccess",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheMojangClient",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheMojangUuid",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheMojangName",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheMojangUsername",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheMojangPass",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheNideAccess",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheNideClient",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheNideUuid",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheNideName",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheNideUsername",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheNidePass",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheNideServer",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheAuthAccess",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheAuthClient",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheAuthUuid",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheAuthName",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheAuthUsername",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheAuthPass",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheAuthServerServer",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheAuthServerName",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheAuthServerRegister",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"CacheDownloadFolder",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, false)
				},
				{
					"CacheJavaListVersion",
					new ModSetup.SetupEntry(0, ModSetup.SetupSource.Registry, false)
				},
				{
					"LoginRemember",
					new ModSetup.SetupEntry(true, ModSetup.SetupSource.Registry, true)
				},
				{
					"LoginLegacyName",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"LoginMojangEmail",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"LoginMojangPass",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"LoginNideEmail",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"LoginNidePass",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"LoginAuthEmail",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"LoginAuthPass",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"LoginType",
					new ModSetup.SetupEntry(ModLaunch.McLoginType.Legacy, ModSetup.SetupSource.Registry, false)
				},
				{
					"LoginPageType",
					new ModSetup.SetupEntry(0, 0, false)
				},
				{
					"LaunchSkinID",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, false)
				},
				{
					"LaunchSkinType",
					new ModSetup.SetupEntry(0, ModSetup.SetupSource.Registry, false)
				},
				{
					"LaunchSkinSlim",
					new ModSetup.SetupEntry(false, ModSetup.SetupSource.Registry, false)
				},
				{
					"LaunchVersionSelect",
					new ModSetup.SetupEntry("", 0, false)
				},
				{
					"LaunchFolderSelect",
					new ModSetup.SetupEntry("", 0, false)
				},
				{
					"LaunchFolders",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, false)
				},
				{
					"LaunchArgumentTitle",
					new ModSetup.SetupEntry("", 0, false)
				},
				{
					"LaunchArgumentInfo",
					new ModSetup.SetupEntry("PCL2", 0, false)
				},
				{
					"LaunchArgumentJavaSelect",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, false)
				},
				{
					"LaunchArgumentJavaAll",
					new ModSetup.SetupEntry("[]", ModSetup.SetupSource.Registry, false)
				},
				{
					"LaunchArgumentIndie",
					new ModSetup.SetupEntry(0, 0, false)
				},
				{
					"LaunchArgumentVisible",
					new ModSetup.SetupEntry(5, ModSetup.SetupSource.Registry, false)
				},
				{
					"LaunchArgumentPriority",
					new ModSetup.SetupEntry(1, ModSetup.SetupSource.Registry, false)
				},
				{
					"LaunchArgumentWindowWidth",
					new ModSetup.SetupEntry(854, 0, false)
				},
				{
					"LaunchArgumentWindowHeight",
					new ModSetup.SetupEntry(480, 0, false)
				},
				{
					"LaunchArgumentWindowType",
					new ModSetup.SetupEntry(1, 0, false)
				},
				{
					"LaunchAdvanceJvm",
					new ModSetup.SetupEntry("-XX:+UseG1GC -XX:-UseAdaptiveSizePolicy -XX:-OmitStackTraceInFastThrow -Dfml.ignoreInvalidMinecraftCertificates=True -Dfml.ignorePatchDiscrepancies=True -Dlog4j2.formatMsgNoLookups=true", 0, false)
				},
				{
					"LaunchAdvanceGame",
					new ModSetup.SetupEntry("", 0, false)
				},
				{
					"LaunchAdvanceAssets",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"LaunchRamType",
					new ModSetup.SetupEntry(0, 0, false)
				},
				{
					"LaunchRamCustom",
					new ModSetup.SetupEntry(15, 0, false)
				},
				{
					"LinkAuto",
					new ModSetup.SetupEntry(false, ModSetup.SetupSource.Registry, false)
				},
				{
					"LinkName",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, false)
				},
				{
					"LinkIoiVersion",
					new ModSetup.SetupEntry(0, ModSetup.SetupSource.Registry, true)
				},
				{
					"ToolHelpChinese",
					new ModSetup.SetupEntry(true, ModSetup.SetupSource.Registry, false)
				},
				{
					"ToolDownloadThread",
					new ModSetup.SetupEntry(63, ModSetup.SetupSource.Registry, false)
				},
				{
					"ToolDownloadSpeed",
					new ModSetup.SetupEntry(42, ModSetup.SetupSource.Registry, false)
				},
				{
					"ToolDownloadVersion",
					new ModSetup.SetupEntry(0, ModSetup.SetupSource.Registry, false)
				},
				{
					"ToolUpdateAlpha",
					new ModSetup.SetupEntry(0, ModSetup.SetupSource.Registry, true)
				},
				{
					"ToolUpdateRelease",
					new ModSetup.SetupEntry(false, ModSetup.SetupSource.Registry, false)
				},
				{
					"ToolUpdateSnapshot",
					new ModSetup.SetupEntry(false, ModSetup.SetupSource.Registry, false)
				},
				{
					"ToolUpdateReleaseLast",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, false)
				},
				{
					"ToolUpdateSnapshotLast",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, false)
				},
				{
					"UiLauncherTransparent",
					new ModSetup.SetupEntry(600, 0, false)
				},
				{
					"UiLauncherHue",
					new ModSetup.SetupEntry(180, 0, false)
				},
				{
					"UiLauncherSat",
					new ModSetup.SetupEntry(80, 0, false)
				},
				{
					"UiLauncherDelta",
					new ModSetup.SetupEntry(90, 0, false)
				},
				{
					"UiLauncherLight",
					new ModSetup.SetupEntry(20, 0, false)
				},
				{
					"UiLauncherTheme",
					new ModSetup.SetupEntry(0, 0, false)
				},
				{
					"UiLauncherThemeGold",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Registry, true)
				},
				{
					"UiLauncherThemeHide",
					new ModSetup.SetupEntry("0|1|2|3|4", ModSetup.SetupSource.Registry, true)
				},
				{
					"UiLauncherThemeHide2",
					new ModSetup.SetupEntry("0|1|2|3|4", ModSetup.SetupSource.Registry, true)
				},
				{
					"UiLauncherLogo",
					new ModSetup.SetupEntry(true, 0, false)
				},
				{
					"UiLauncherEmail",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"UiBackgroundColorful",
					new ModSetup.SetupEntry(true, 0, false)
				},
				{
					"UiBackgroundOpacity",
					new ModSetup.SetupEntry(1000, 0, false)
				},
				{
					"UiBackgroundBlur",
					new ModSetup.SetupEntry(0, 0, false)
				},
				{
					"UiBackgroundSuit",
					new ModSetup.SetupEntry(0, 0, false)
				},
				{
					"UiCustomType",
					new ModSetup.SetupEntry(0, 0, false)
				},
				{
					"UiCustomNet",
					new ModSetup.SetupEntry("", 0, false)
				},
				{
					"UiLogoType",
					new ModSetup.SetupEntry(1, 0, false)
				},
				{
					"UiLogoText",
					new ModSetup.SetupEntry("", 0, false)
				},
				{
					"UiLogoLeft",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"UiMusicVolume",
					new ModSetup.SetupEntry(500, 0, false)
				},
				{
					"UiMusicStop",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"UiMusicStart",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"UiMusicAuto",
					new ModSetup.SetupEntry(true, 0, false)
				},
				{
					"UiHiddenPageDownload",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"UiHiddenPageLink",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"UiHiddenPageSetup",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"UiHiddenPageOther",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"UiHiddenFunctionSelect",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"UiHiddenFunctionHidden",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"UiHiddenSetupLaunch",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"UiHiddenSetupUi",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"UiHiddenSetupLink",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"UiHiddenSetupSystem",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"UiHiddenOtherHelp",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"UiHiddenOtherFeedback",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"UiHiddenOtherAbout",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"UiHiddenOtherTest",
					new ModSetup.SetupEntry(false, 0, false)
				},
				{
					"VersionAdvanceJvm",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Version, false)
				},
				{
					"VersionAdvanceGame",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Version, false)
				},
				{
					"VersionAdvanceAssets",
					new ModSetup.SetupEntry(0, ModSetup.SetupSource.Version, false)
				},
				{
					"VersionRamType",
					new ModSetup.SetupEntry(2, ModSetup.SetupSource.Version, false)
				},
				{
					"VersionRamCustom",
					new ModSetup.SetupEntry(15, ModSetup.SetupSource.Version, false)
				},
				{
					"VersionArgumentTitle",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Version, false)
				},
				{
					"VersionArgumentInfo",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Version, false)
				},
				{
					"VersionArgumentIndie",
					new ModSetup.SetupEntry(-1, ModSetup.SetupSource.Version, false)
				},
				{
					"VersionArgumentJavaSelect",
					new ModSetup.SetupEntry("使用全局设置", ModSetup.SetupSource.Version, false)
				},
				{
					"VersionServerEnter",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Version, false)
				},
				{
					"VersionServerLogin",
					new ModSetup.SetupEntry(0, ModSetup.SetupSource.Version, false)
				},
				{
					"VersionServerNide",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Version, false)
				},
				{
					"VersionServerAuthRegister",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Version, false)
				},
				{
					"VersionServerAuthName",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Version, false)
				},
				{
					"VersionServerAuthServer",
					new ModSetup.SetupEntry("", ModSetup.SetupSource.Version, false)
				}
			};
		}

		// Token: 0x06000DE9 RID: 3561 RVA: 0x00008DED File Offset: 0x00006FED
		public void Set(string Key, object Value, bool ForceReload = false, ModMinecraft.McVersion Version = null)
		{
			this.Set(Key, RuntimeHelpers.GetObjectValue(Value), this.indexerPrototype[Key], ForceReload, Version);
		}

		// Token: 0x06000DEA RID: 3562 RVA: 0x00067748 File Offset: 0x00065948
		private void Set(string Key, object Value, ModSetup.SetupEntry E, bool ForceReload, ModMinecraft.McVersion Version)
		{
			try
			{
				Value = RuntimeHelpers.GetObjectValue(Conversion.CTypeDynamic(RuntimeHelpers.GetObjectValue(Value), (Type)E.Type));
				if (E._RecordParameter == 2)
				{
					if (Operators.ConditionalCompareObjectEqual(E.Value, Value, true) && !ForceReload)
					{
						return;
					}
				}
				else if (E.Source != ModSetup.SetupSource.Version)
				{
					E._RecordParameter = 2;
				}
				E.Value = RuntimeHelpers.GetObjectValue(Value);
				if (E.serializerParameter)
				{
					try
					{
						if (Value == null)
						{
							Value = "";
						}
						Value = ModBase.PostTag(Conversions.ToString(Value), "PCL" + ModBase.initializerState);
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "加密设置失败：" + Key, ModBase.LogLevel.Developer, "出现错误");
					}
				}
				switch (E.Source)
				{
				case ModSetup.SetupSource.Normal:
					ModBase.WriteIni("Setup", Key, Conversions.ToString(Value));
					break;
				case ModSetup.SetupSource.Registry:
					ModBase.WriteReg(Key, Conversions.ToString(Value), false);
					break;
				case ModSetup.SetupSource.Version:
					if (Version == null)
					{
						throw new Exception("更改版本设置 " + Key + " 时未提供目标版本");
					}
					ModBase.WriteIni(Version.Path + "PCL\\Setup.ini", Key, Conversions.ToString(Value));
					break;
				}
				MethodInfo method = typeof(ModSetup).GetMethod(Key);
				if (method != null)
				{
					method.Invoke(this, new object[]
					{
						Value
					});
				}
			}
			catch (Exception ex2)
			{
				ModBase.Log(ex2, Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("设置设置项时出错（" + Key + ", ", Value), "）")), ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000DEB RID: 3563 RVA: 0x00008E0B File Offset: 0x0000700B
		public object Load(string Key, bool ForceReload = false, ModMinecraft.McVersion Version = null)
		{
			return this.Load(Key, this.indexerPrototype[Key], ForceReload, Version);
		}

		// Token: 0x06000DEC RID: 3564 RVA: 0x00067918 File Offset: 0x00065B18
		private object Load(string Key, ModSetup.SetupEntry E, bool ForceReload, ModMinecraft.McVersion Version)
		{
			object value;
			if (E._RecordParameter == 2 && !ForceReload)
			{
				value = E.Value;
			}
			else
			{
				this.Read(Key, ref E, Version);
				if (E.Source != ModSetup.SetupSource.Version)
				{
					E._RecordParameter = 2;
				}
				MethodInfo method = typeof(ModSetup).GetMethod(Key);
				if (method != null)
				{
					method.Invoke(this, new object[]
					{
						E.Value
					});
				}
				value = E.Value;
			}
			return value;
		}

		// Token: 0x06000DED RID: 3565 RVA: 0x00008E22 File Offset: 0x00007022
		public object Get(string Key, ModMinecraft.McVersion Version = null)
		{
			if (!this.indexerPrototype.ContainsKey(Key))
			{
				throw new KeyNotFoundException("未找到设置项：" + Key)
				{
					Source = Key
				};
			}
			return this.Get(Key, this.indexerPrototype[Key], Version);
		}

		// Token: 0x06000DEE RID: 3566 RVA: 0x0006798C File Offset: 0x00065B8C
		private object Get(string Key, ModSetup.SetupEntry E, ModMinecraft.McVersion Version)
		{
			string text = this.ForceValue(Key);
			if (text != null)
			{
				E.Value = RuntimeHelpers.GetObjectValue(Conversion.CTypeDynamic(text, (Type)E.Type));
				E._RecordParameter = 1;
			}
			if (E._RecordParameter == 0)
			{
				this.Read(Key, ref E, Version);
				if (E.Source != ModSetup.SetupSource.Version)
				{
					E._RecordParameter = 1;
				}
			}
			return E.Value;
		}

		// Token: 0x06000DEF RID: 3567 RVA: 0x000679F0 File Offset: 0x00065BF0
		public void Reset(string Key, bool ForceReload = false, ModMinecraft.McVersion Version = null)
		{
			ModSetup.SetupEntry setupEntry = this.indexerPrototype[Key];
			this.Set(Key, RuntimeHelpers.GetObjectValue(setupEntry.m_RoleParameter), setupEntry, ForceReload, Version);
		}

		// Token: 0x06000DF0 RID: 3568 RVA: 0x00067A20 File Offset: 0x00065C20
		private void Read(string Key, ref ModSetup.SetupEntry E, ModMinecraft.McVersion Version)
		{
			try
			{
				if (E._RecordParameter == 0)
				{
					ModSetup.SetupSource source = E.Source;
					string text;
					if (source != ModSetup.SetupSource.Normal)
					{
						if (source != ModSetup.SetupSource.Registry)
						{
							if (Version == null)
							{
								throw new Exception("读取版本设置 " + Key + " 时未提供目标版本");
							}
							text = ModBase.ReadIni(Version.Path + "PCL\\Setup.ini", Key, Conversions.ToString(E.m_ValueParameter));
						}
						else
						{
							text = ModBase.ReadReg(Key, Conversions.ToString(E.m_ValueParameter));
						}
					}
					else
					{
						text = ModBase.ReadIni("Setup", Key, Conversions.ToString(E.m_ValueParameter));
					}
					if (E.serializerParameter)
					{
						if (text.Equals(RuntimeHelpers.GetObjectValue(E.m_ValueParameter)))
						{
							text = Conversions.ToString(E.m_RoleParameter);
						}
						else
						{
							try
							{
								text = ModBase.RevertTag(text, "PCL" + ModBase.initializerState);
							}
							catch (Exception ex)
							{
								ModBase.Log(ex, "解密设置失败：" + Key, ModBase.LogLevel.Developer, "出现错误");
								text = Conversions.ToString(E.m_RoleParameter);
								ModBase._ParamsState.Set(Key, RuntimeHelpers.GetObjectValue(E.m_RoleParameter), true, null);
							}
						}
					}
					E.Value = RuntimeHelpers.GetObjectValue(Conversion.CTypeDynamic(text, (Type)E.Type));
				}
			}
			catch (Exception ex2)
			{
				ModBase.Log(ex2, "读取设置失败：" + Key, ModBase.LogLevel.Hint, "出现错误");
				E.Value = RuntimeHelpers.GetObjectValue(Conversion.CTypeDynamic(RuntimeHelpers.GetObjectValue(E.m_RoleParameter), (Type)E.Type));
			}
		}

		// Token: 0x06000DF1 RID: 3569 RVA: 0x00067BEC File Offset: 0x00065DEC
		private string ForceValue(string Key)
		{
			string result;
			if (Operators.CompareString(Key, "UiHiddenOtherFeedback", true) == 0)
			{
				result = "True";
			}
			else if (Operators.CompareString(Key, "UiLauncherTheme", true) == 0)
			{
				result = "0";
			}
			else
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000DF2 RID: 3570 RVA: 0x00067C28 File Offset: 0x00065E28
		public void LaunchVersionSelect(string Value)
		{
			ModBase.Log("[Setup] 当前选择的 Minecraft 版本：" + Value, ModBase.LogLevel.Normal, "出现错误");
			ModBase.WriteIni(ModMinecraft._MapperTag + "PCL.ini", "Version", Information.IsNothing(ModMinecraft.SetupResolver()) ? "" : ModMinecraft.SetupResolver().Name);
		}

		// Token: 0x06000DF3 RID: 3571 RVA: 0x00067C84 File Offset: 0x00065E84
		public void LaunchFolderSelect(string Value)
		{
			ModBase.Log("[Setup] 当前选择的 Minecraft 文件夹：" + Value.ToString().Replace("$", ModBase.Path), ModBase.LogLevel.Normal, "出现错误");
			ModMinecraft._MapperTag = Value.ToString().Replace("$", ModBase.Path);
		}

		// Token: 0x06000DF4 RID: 3572 RVA: 0x00008E5E File Offset: 0x0000705E
		public void LaunchRamType(int Type)
		{
			if (ModMain.m_MerchantAccount != null)
			{
				ModMain.m_MerchantAccount.RamType(Type);
			}
		}

		// Token: 0x06000DF5 RID: 3573 RVA: 0x00067CD8 File Offset: 0x00065ED8
		public Size GetLaunchArgumentWindowSize()
		{
			object left = ModBase._ParamsState.Get("LaunchArgumentWindowType", null);
			Size $VB$Local_Result;
			if (Conversions.ToBoolean(Conversions.ToBoolean(Operators.CompareObjectEqual(left, 0, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 1, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 4, true))))
			{
				$VB$Local_Result = new Size(854.0, 480.0);
			}
			else if (Operators.ConditionalCompareObjectEqual(left, 2, true))
			{
				Size Result;
				ModBase.RunInUiWait(delegate
				{
					Result = new Size(Math.Round(ModBase.GetPixelSize(ModMain.m_CollectionAccount.PanForm.ActualWidth)), Math.Round(ModBase.GetPixelSize(ModMain.m_CollectionAccount.PanForm.ActualHeight) - 38.0));
				});
				$VB$Local_Result = Result;
			}
			else if (Operators.ConditionalCompareObjectEqual(left, 3, true))
			{
				$VB$Local_Result = new Size(Conversions.ToDouble(ModBase._ParamsState.Get("LaunchArgumentWindowWidth", null)), Conversions.ToDouble(ModBase._ParamsState.Get("LaunchArgumentWindowHeight", null)));
			}
			else
			{
				$VB$Local_Result = new Size(100.0, 100.0);
			}
			return $VB$Local_Result;
		}

		// Token: 0x06000DF6 RID: 3574 RVA: 0x00008E72 File Offset: 0x00007072
		public void LaunchSkinType(int Value)
		{
			ModBase.RunInUi(delegate()
			{
				if (!Information.IsNothing(ModMain.m_MerchantAccount))
				{
					switch (Value)
					{
					case 0:
					case 1:
					case 2:
						ModMain.m_MerchantAccount.PanSkinID.Visibility = Visibility.Collapsed;
						ModMain.m_MerchantAccount.PanSkinChange.Visibility = Visibility.Collapsed;
						break;
					case 3:
						ModMain.m_MerchantAccount.PanSkinID.Visibility = Visibility.Visible;
						ModMain.m_MerchantAccount.PanSkinChange.Visibility = Visibility.Collapsed;
						break;
					case 4:
						ModMain.m_MerchantAccount.PanSkinID.Visibility = Visibility.Collapsed;
						ModMain.m_MerchantAccount.PanSkinChange.Visibility = Visibility.Visible;
						break;
					}
					ModMain.m_MerchantAccount.CardSkin.TriggerForceResize();
				}
				PageLaunchLeft._StructComparator.Start(null, false);
			}, false);
		}

		// Token: 0x06000DF7 RID: 3575 RVA: 0x00008E91 File Offset: 0x00007091
		public void LaunchSkinID(string Value)
		{
			PageLaunchLeft._StructComparator.Start(null, false);
		}

		// Token: 0x06000DF8 RID: 3576 RVA: 0x00008E9F File Offset: 0x0000709F
		public void ToolDownloadThread(int Value)
		{
			ModNet.prototypeTag = checked(Value + 1);
		}

		// Token: 0x06000DF9 RID: 3577 RVA: 0x00067DE8 File Offset: 0x00065FE8
		public void ToolDownloadSpeed(int Value)
		{
			checked
			{
				if (Value <= 14)
				{
					ModNet.requestTag = (long)Math.Round(unchecked((double)(checked(Value + 1)) * 0.1 * 1024.0 * 1024.0));
					return;
				}
				if (Value <= 31)
				{
					ModNet.requestTag = (long)Math.Round(unchecked((double)(checked(Value - 11)) * 0.5 * 1024.0 * 1024.0));
					return;
				}
				if (Value <= 41)
				{
					ModNet.requestTag = unchecked((long)(checked((Value - 21) * 1024))) * 1024L;
					return;
				}
				ModNet.requestTag = -1L;
			}
		}

		// Token: 0x06000DFA RID: 3578 RVA: 0x00008EA9 File Offset: 0x000070A9
		public void UiBackgroundOpacity(int Value)
		{
			ModMain.m_CollectionAccount.ImgBack.Opacity = (double)Value / 1000.0;
		}

		// Token: 0x06000DFB RID: 3579 RVA: 0x00067E8C File Offset: 0x0006608C
		public void UiBackgroundBlur(int Value)
		{
			checked
			{
				if (Value == 0)
				{
					ModMain.m_CollectionAccount.ImgBack.Effect = null;
				}
				else
				{
					ModMain.m_CollectionAccount.ImgBack.Effect = new BlurEffect
					{
						Radius = (double)(Value + 1)
					};
				}
				ModMain.m_CollectionAccount.ImgBack.Margin = new Thickness((double)(0 - (Value + 1)) / 1.8);
			}
		}

		// Token: 0x06000DFC RID: 3580 RVA: 0x00067EF0 File Offset: 0x000660F0
		public void UiBackgroundSuit(int Value)
		{
			if (!Information.IsNothing(ModMain.m_CollectionAccount.ImgBack.Background))
			{
				double width = ((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).ImageSource.Width;
				double height = ((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).ImageSource.Height;
				if (Value == 0)
				{
					if (width <= ModMain.m_CollectionAccount.PanMain.ActualWidth - 10.0 && height <= ModMain.m_CollectionAccount.PanMain.ActualHeight - 10.0)
					{
						if (width < ModMain.m_CollectionAccount.PanMain.ActualWidth / 3.0 && height < ModMain.m_CollectionAccount.PanMain.ActualHeight / 3.0)
						{
							Value = 4;
						}
						else
						{
							Value = 1;
						}
					}
					else
					{
						Value = 2;
					}
				}
				((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).TileMode = TileMode.None;
				((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).Viewport = new Rect(0.0, 0.0, 1.0, 1.0);
				((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).ViewportUnits = BrushMappingMode.RelativeToBoundingBox;
				switch (Value)
				{
				case 1:
					ModMain.m_CollectionAccount.ImgBack.HorizontalAlignment = HorizontalAlignment.Center;
					ModMain.m_CollectionAccount.ImgBack.VerticalAlignment = VerticalAlignment.Center;
					((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).Stretch = Stretch.None;
					ModMain.m_CollectionAccount.ImgBack.Width = ((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).ImageSource.Width;
					ModMain.m_CollectionAccount.ImgBack.Height = ((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).ImageSource.Height;
					return;
				case 2:
					ModMain.m_CollectionAccount.ImgBack.HorizontalAlignment = HorizontalAlignment.Stretch;
					ModMain.m_CollectionAccount.ImgBack.VerticalAlignment = VerticalAlignment.Stretch;
					((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).Stretch = Stretch.UniformToFill;
					ModMain.m_CollectionAccount.ImgBack.Width = double.NaN;
					ModMain.m_CollectionAccount.ImgBack.Height = double.NaN;
					return;
				case 3:
					ModMain.m_CollectionAccount.ImgBack.HorizontalAlignment = HorizontalAlignment.Stretch;
					ModMain.m_CollectionAccount.ImgBack.VerticalAlignment = VerticalAlignment.Stretch;
					((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).Stretch = Stretch.Fill;
					ModMain.m_CollectionAccount.ImgBack.Width = double.NaN;
					ModMain.m_CollectionAccount.ImgBack.Height = double.NaN;
					return;
				case 4:
					ModMain.m_CollectionAccount.ImgBack.HorizontalAlignment = HorizontalAlignment.Stretch;
					ModMain.m_CollectionAccount.ImgBack.VerticalAlignment = VerticalAlignment.Stretch;
					((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).Stretch = Stretch.None;
					((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).TileMode = TileMode.Tile;
					((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).Viewport = new Rect(0.0, 0.0, ((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).ImageSource.Width, ((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).ImageSource.Height);
					((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).ViewportUnits = BrushMappingMode.Absolute;
					ModMain.m_CollectionAccount.ImgBack.Width = double.NaN;
					ModMain.m_CollectionAccount.ImgBack.Height = double.NaN;
					return;
				case 5:
					ModMain.m_CollectionAccount.ImgBack.HorizontalAlignment = HorizontalAlignment.Left;
					ModMain.m_CollectionAccount.ImgBack.VerticalAlignment = VerticalAlignment.Top;
					((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).Stretch = Stretch.None;
					ModMain.m_CollectionAccount.ImgBack.Width = ((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).ImageSource.Width;
					ModMain.m_CollectionAccount.ImgBack.Height = ((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).ImageSource.Height;
					return;
				case 6:
					ModMain.m_CollectionAccount.ImgBack.HorizontalAlignment = HorizontalAlignment.Right;
					ModMain.m_CollectionAccount.ImgBack.VerticalAlignment = VerticalAlignment.Top;
					((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).Stretch = Stretch.None;
					ModMain.m_CollectionAccount.ImgBack.Width = ((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).ImageSource.Width;
					ModMain.m_CollectionAccount.ImgBack.Height = ((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).ImageSource.Height;
					return;
				case 7:
					ModMain.m_CollectionAccount.ImgBack.HorizontalAlignment = HorizontalAlignment.Left;
					ModMain.m_CollectionAccount.ImgBack.VerticalAlignment = VerticalAlignment.Bottom;
					((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).Stretch = Stretch.None;
					ModMain.m_CollectionAccount.ImgBack.Width = ((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).ImageSource.Width;
					ModMain.m_CollectionAccount.ImgBack.Height = ((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).ImageSource.Height;
					return;
				case 8:
					ModMain.m_CollectionAccount.ImgBack.HorizontalAlignment = HorizontalAlignment.Right;
					ModMain.m_CollectionAccount.ImgBack.VerticalAlignment = VerticalAlignment.Bottom;
					((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).Stretch = Stretch.None;
					ModMain.m_CollectionAccount.ImgBack.Width = ((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).ImageSource.Width;
					ModMain.m_CollectionAccount.ImgBack.Height = ((ImageBrush)ModMain.m_CollectionAccount.ImgBack.Background).ImageSource.Height;
					break;
				default:
					return;
				}
			}
		}

		// Token: 0x06000DFD RID: 3581 RVA: 0x00068540 File Offset: 0x00066740
		public void UiCustomType(int Value)
		{
			ModMain._ReaderAccount.workerComparator = true;
			if (ModMain.m_ExporterAccount != null)
			{
				switch (Value)
				{
				case 0:
					ModMain.m_ExporterAccount.PanCustomLocal.Visibility = Visibility.Collapsed;
					ModMain.m_ExporterAccount.PanCustomNet.Visibility = Visibility.Collapsed;
					break;
				case 1:
					ModMain.m_ExporterAccount.PanCustomLocal.Visibility = Visibility.Visible;
					ModMain.m_ExporterAccount.PanCustomNet.Visibility = Visibility.Collapsed;
					break;
				case 2:
					ModMain.m_ExporterAccount.PanCustomLocal.Visibility = Visibility.Collapsed;
					ModMain.m_ExporterAccount.PanCustomNet.Visibility = Visibility.Visible;
					break;
				}
				ModMain.m_ExporterAccount.CardCustom.TriggerForceResize();
			}
		}

		// Token: 0x06000DFE RID: 3582 RVA: 0x00008EC6 File Offset: 0x000070C6
		public void UiCustomNet(string Value)
		{
			ModMain._ReaderAccount.workerComparator = true;
		}

		// Token: 0x06000DFF RID: 3583 RVA: 0x000685EC File Offset: 0x000667EC
		public void UiLogoType(int Value)
		{
			switch (Value)
			{
			case 0:
				ModMain.m_CollectionAccount.ShapeTitleLogo.Visibility = Visibility.Collapsed;
				ModMain.m_CollectionAccount.LabTitleLogo.Visibility = Visibility.Collapsed;
				ModMain.m_CollectionAccount.ImageTitleLogo.Visibility = Visibility.Collapsed;
				if (!Information.IsNothing(ModMain.m_ExporterAccount))
				{
					ModMain.m_ExporterAccount.CheckLogoLeft.Visibility = Visibility.Visible;
					ModMain.m_ExporterAccount.PanLogoText.Visibility = Visibility.Collapsed;
					ModMain.m_ExporterAccount.PanLogoChange.Visibility = Visibility.Collapsed;
				}
				break;
			case 1:
				ModMain.m_CollectionAccount.ShapeTitleLogo.Visibility = Visibility.Visible;
				ModMain.m_CollectionAccount.LabTitleLogo.Visibility = Visibility.Collapsed;
				ModMain.m_CollectionAccount.ImageTitleLogo.Visibility = Visibility.Collapsed;
				if (!Information.IsNothing(ModMain.m_ExporterAccount))
				{
					ModMain.m_ExporterAccount.CheckLogoLeft.Visibility = Visibility.Collapsed;
					ModMain.m_ExporterAccount.PanLogoText.Visibility = Visibility.Collapsed;
					ModMain.m_ExporterAccount.PanLogoChange.Visibility = Visibility.Collapsed;
				}
				break;
			case 2:
				ModMain.m_CollectionAccount.ShapeTitleLogo.Visibility = Visibility.Collapsed;
				ModMain.m_CollectionAccount.LabTitleLogo.Visibility = Visibility.Visible;
				ModMain.m_CollectionAccount.ImageTitleLogo.Visibility = Visibility.Collapsed;
				if (!Information.IsNothing(ModMain.m_ExporterAccount))
				{
					ModMain.m_ExporterAccount.CheckLogoLeft.Visibility = Visibility.Collapsed;
					ModMain.m_ExporterAccount.PanLogoText.Visibility = Visibility.Visible;
					ModMain.m_ExporterAccount.PanLogoChange.Visibility = Visibility.Collapsed;
				}
				ModBase._ParamsState.Load("UiLogoText", true, null);
				break;
			case 3:
				ModMain.m_CollectionAccount.ShapeTitleLogo.Visibility = Visibility.Collapsed;
				ModMain.m_CollectionAccount.LabTitleLogo.Visibility = Visibility.Collapsed;
				ModMain.m_CollectionAccount.ImageTitleLogo.Visibility = Visibility.Visible;
				if (!Information.IsNothing(ModMain.m_ExporterAccount))
				{
					ModMain.m_ExporterAccount.CheckLogoLeft.Visibility = Visibility.Collapsed;
					ModMain.m_ExporterAccount.PanLogoText.Visibility = Visibility.Collapsed;
					ModMain.m_ExporterAccount.PanLogoChange.Visibility = Visibility.Visible;
				}
				try
				{
					ModMain.m_CollectionAccount.ImageTitleLogo.Source = new MyBitmap(ModBase.Path + "PCL\\Logo.png");
				}
				catch (Exception ex)
				{
					ModMain.m_CollectionAccount.ImageTitleLogo.Source = null;
					ModBase.Log(ex, "显示标题栏图片失败", ModBase.LogLevel.Msgbox, "出现错误");
				}
				break;
			}
			ModBase._ParamsState.Load("UiLogoLeft", true, null);
			if (!Information.IsNothing(ModMain.m_ExporterAccount))
			{
				ModMain.m_ExporterAccount.CardLogo.TriggerForceResize();
			}
		}

		// Token: 0x06000E00 RID: 3584 RVA: 0x00008ED3 File Offset: 0x000070D3
		public void UiLogoText(string Value)
		{
			ModMain.m_CollectionAccount.LabTitleLogo.Text = Value;
		}

		// Token: 0x06000E01 RID: 3585 RVA: 0x00068888 File Offset: 0x00066A88
		public void UiLogoLeft(bool Value)
		{
			ModMain.m_CollectionAccount.PanTitleMain.ColumnDefinitions[0].Width = new GridLength((double)((!Value || !Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("UiLogoType", null), 0, true)) ? 1 : 0), GridUnitType.Star);
		}

		// Token: 0x06000E02 RID: 3586 RVA: 0x00008EE5 File Offset: 0x000070E5
		public void UiHiddenPageLink(bool Value)
		{
			PageSetupUI.HiddenRefresh();
		}

		// Token: 0x06000E03 RID: 3587 RVA: 0x00008EE5 File Offset: 0x000070E5
		public void UiHiddenPageDownload(bool Value)
		{
			PageSetupUI.HiddenRefresh();
		}

		// Token: 0x06000E04 RID: 3588 RVA: 0x00008EE5 File Offset: 0x000070E5
		public void UiHiddenPageSetup(bool Value)
		{
			PageSetupUI.HiddenRefresh();
		}

		// Token: 0x06000E05 RID: 3589 RVA: 0x00008EE5 File Offset: 0x000070E5
		public void UiHiddenPageOther(bool Value)
		{
			PageSetupUI.HiddenRefresh();
		}

		// Token: 0x06000E06 RID: 3590 RVA: 0x00008EE5 File Offset: 0x000070E5
		public void UiHiddenFunctionSelect(bool Value)
		{
			PageSetupUI.HiddenRefresh();
		}

		// Token: 0x06000E07 RID: 3591 RVA: 0x00008EE5 File Offset: 0x000070E5
		public void UiHiddenFunctionHidden(bool Value)
		{
			PageSetupUI.HiddenRefresh();
		}

		// Token: 0x06000E08 RID: 3592 RVA: 0x00008EE5 File Offset: 0x000070E5
		public void UiHiddenSetupLaunch(bool Value)
		{
			PageSetupUI.HiddenRefresh();
		}

		// Token: 0x06000E09 RID: 3593 RVA: 0x00008EE5 File Offset: 0x000070E5
		public void UiHiddenSetupUi(bool Value)
		{
			PageSetupUI.HiddenRefresh();
		}

		// Token: 0x06000E0A RID: 3594 RVA: 0x00008EE5 File Offset: 0x000070E5
		public void UiHiddenSetupLink(bool Value)
		{
			PageSetupUI.HiddenRefresh();
		}

		// Token: 0x06000E0B RID: 3595 RVA: 0x00008EE5 File Offset: 0x000070E5
		public void UiHiddenSetupSystem(bool Value)
		{
			PageSetupUI.HiddenRefresh();
		}

		// Token: 0x06000E0C RID: 3596 RVA: 0x00008EE5 File Offset: 0x000070E5
		public void UiHiddenOtherHelp(bool Value)
		{
			PageSetupUI.HiddenRefresh();
		}

		// Token: 0x06000E0D RID: 3597 RVA: 0x00008EE5 File Offset: 0x000070E5
		public void UiHiddenOtherFeedback(bool Value)
		{
			PageSetupUI.HiddenRefresh();
		}

		// Token: 0x06000E0E RID: 3598 RVA: 0x00008EE5 File Offset: 0x000070E5
		public void UiHiddenOtherAbout(bool Value)
		{
			PageSetupUI.HiddenRefresh();
		}

		// Token: 0x06000E0F RID: 3599 RVA: 0x00008EE5 File Offset: 0x000070E5
		public void UiHiddenOtherTest(bool Value)
		{
			PageSetupUI.HiddenRefresh();
		}

		// Token: 0x06000E10 RID: 3600 RVA: 0x00008EEC File Offset: 0x000070EC
		public void SystemDebugMode(bool Value)
		{
			ModBase._EventState = Value;
		}

		// Token: 0x06000E11 RID: 3601 RVA: 0x000688DC File Offset: 0x00066ADC
		public void SystemDebugAnim(int Value)
		{
			ModAnimation.m_Test = ((Value >= 30) ? 200.0 : ModBase.MathRange((double)Value * 0.1 + 0.1, 0.1, 3.0));
		}

		// Token: 0x06000E12 RID: 3602 RVA: 0x00008EF4 File Offset: 0x000070F4
		public void VersionRamType(int Type)
		{
			if (ModMain._ProcAccount != null)
			{
				ModMain._ProcAccount.RamType(Type);
			}
		}

		// Token: 0x06000E13 RID: 3603 RVA: 0x0006892C File Offset: 0x00066B2C
		public void VersionServerLogin(int Type)
		{
			if (ModMain._ProcAccount != null)
			{
				ModBase.WriteIni(ModMinecraft._MapperTag + "PCL.ini", "VersionCache", "");
				if (PageVersionLeft.m_AlgoResolver != null)
				{
					PageVersionLeft.m_AlgoResolver = new ModMinecraft.McVersion(PageVersionLeft.m_AlgoResolver.Name).Load();
					ModLoader.LoaderFolderRun(ModMinecraft.threadTag, ModMinecraft._MapperTag, ModLoader.LoaderFolderRunType.ForceRun, 1, "versions\\", false);
				}
			}
		}

		// Token: 0x040006EB RID: 1771
		private readonly Dictionary<string, ModSetup.SetupEntry> indexerPrototype;

		// Token: 0x02000156 RID: 342
		private enum SetupSource
		{
			// Token: 0x040006ED RID: 1773
			Normal,
			// Token: 0x040006EE RID: 1774
			Registry,
			// Token: 0x040006EF RID: 1775
			Version
		}

		// Token: 0x02000157 RID: 343
		private class SetupEntry
		{
			// Token: 0x06000E15 RID: 3605 RVA: 0x00068998 File Offset: 0x00066B98
			public SetupEntry(object Value, object Source = 0, object Encoded = false)
			{
				this._RecordParameter = 0;
				this.m_RoleParameter = RuntimeHelpers.GetObjectValue(Value);
				this.m_ValueParameter = RuntimeHelpers.GetObjectValue(Conversions.ToBoolean(Encoded) ? ModBase.PostTag(Conversions.ToString(Value), "PCL" + ModBase.initializerState) : Value);
				this.serializerParameter = Conversions.ToBoolean(Encoded);
				this.Value = RuntimeHelpers.GetObjectValue(Value);
				this.Source = (ModSetup.SetupSource)Conversions.ToInteger(Source);
				this.Type = (Value ?? new object()).GetType();
			}

			// Token: 0x040006F0 RID: 1776
			public bool serializerParameter;

			// Token: 0x040006F1 RID: 1777
			public object m_RoleParameter;

			// Token: 0x040006F2 RID: 1778
			public object m_ValueParameter;

			// Token: 0x040006F3 RID: 1779
			public object Value;

			// Token: 0x040006F4 RID: 1780
			public ModSetup.SetupSource Source;

			// Token: 0x040006F5 RID: 1781
			public byte _RecordParameter;

			// Token: 0x040006F6 RID: 1782
			public Type Type;
		}
	}
}
