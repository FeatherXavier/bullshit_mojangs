﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x020000A4 RID: 164
	[DesignerGenerated]
	public class PageLinkFeedback : MyPageRight, IComponentConnector
	{
		// Token: 0x0600062D RID: 1581 RVA: 0x000053C9 File Offset: 0x000035C9
		public PageLinkFeedback()
		{
			this.InitializeComponent();
		}

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x0600062E RID: 1582 RVA: 0x000053D8 File Offset: 0x000035D8
		// (set) Token: 0x0600062F RID: 1583 RVA: 0x000053E0 File Offset: 0x000035E0
		internal virtual MyTextButton BtnNoin { get; set; }

		// Token: 0x06000630 RID: 1584 RVA: 0x0002D6F8 File Offset: 0x0002B8F8
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_CandidateRepository)
			{
				this.m_CandidateRepository = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagelink/pagelinkfeedback.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000631 RID: 1585 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000632 RID: 1586 RVA: 0x000053E9 File Offset: 0x000035E9
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.BtnNoin = (MyTextButton)target;
				return;
			}
			this.m_CandidateRepository = true;
		}

		// Token: 0x040002C8 RID: 712
		[AccessedThroughProperty("BtnNoin")]
		[CompilerGenerated]
		private MyTextButton _ProducerRepository;

		// Token: 0x040002C9 RID: 713
		private bool m_CandidateRepository;
	}
}
