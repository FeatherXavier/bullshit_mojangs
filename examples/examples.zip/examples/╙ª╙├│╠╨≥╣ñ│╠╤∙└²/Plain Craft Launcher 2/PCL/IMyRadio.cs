﻿using System;

namespace PCL
{
	// Token: 0x0200000D RID: 13
	public interface IMyRadio
	{
		// Token: 0x14000001 RID: 1
		// (add) Token: 0x06000040 RID: 64
		// (remove) Token: 0x06000041 RID: 65
		event IMyRadio.CheckEventHandler Check;

		// Token: 0x14000002 RID: 2
		// (add) Token: 0x06000042 RID: 66
		// (remove) Token: 0x06000043 RID: 67
		event IMyRadio.ChangedEventHandler Changed;

		// Token: 0x0200000E RID: 14
		// (Invoke) Token: 0x06000047 RID: 71
		public delegate void CheckEventHandler(object sender, ModBase.RouteEventArgs e);

		// Token: 0x0200000F RID: 15
		// (Invoke) Token: 0x0600004C RID: 76
		public delegate void ChangedEventHandler(object sender, ModBase.RouteEventArgs e);
	}
}
