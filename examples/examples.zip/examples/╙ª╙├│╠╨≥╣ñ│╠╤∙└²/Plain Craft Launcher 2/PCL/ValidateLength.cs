﻿using System;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x020000E7 RID: 231
	public class ValidateLength : Validate
	{
		// Token: 0x1700015F RID: 351
		// (get) Token: 0x06000905 RID: 2309 RVA: 0x0000672E File Offset: 0x0000492E
		// (set) Token: 0x06000906 RID: 2310 RVA: 0x00006736 File Offset: 0x00004936
		public int Min { get; set; }

		// Token: 0x17000160 RID: 352
		// (get) Token: 0x06000907 RID: 2311 RVA: 0x0000673F File Offset: 0x0000493F
		// (set) Token: 0x06000908 RID: 2312 RVA: 0x00006747 File Offset: 0x00004947
		public int Max { get; set; }

		// Token: 0x06000909 RID: 2313 RVA: 0x00006750 File Offset: 0x00004950
		public ValidateLength()
		{
			this.Min = 0;
			this.Max = int.MaxValue;
		}

		// Token: 0x0600090A RID: 2314 RVA: 0x0000676B File Offset: 0x0000496B
		public ValidateLength(int Min, int Max = 2147483647)
		{
			this.Min = 0;
			this.Max = int.MaxValue;
			this.Min = Min;
			this.Max = Max;
		}

		// Token: 0x0600090B RID: 2315 RVA: 0x0003F84C File Offset: 0x0003DA4C
		public override string Validate(string Str)
		{
			string result;
			if (Strings.Len(Str) != this.Max && this.Max == this.Min)
			{
				result = "长度必须为 " + Conversions.ToString(this.Max) + " 个字符！";
			}
			else if (Strings.Len(Str) > this.Max)
			{
				result = "长度最长为 " + Conversions.ToString(this.Max) + " 个字符！";
			}
			else if (Strings.Len(Str) < this.Min)
			{
				result = "长度至少需 " + Conversions.ToString(this.Min) + " 个字符！";
			}
			else
			{
				result = "";
			}
			return result;
		}

		// Token: 0x0400045F RID: 1119
		[CompilerGenerated]
		private int paramsTag;

		// Token: 0x04000460 RID: 1120
		[CompilerGenerated]
		private int m_MockTag;
	}
}
