﻿using System;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200006B RID: 107
	[StandardModule]
	public sealed class ModDevelop
	{
	}
}
