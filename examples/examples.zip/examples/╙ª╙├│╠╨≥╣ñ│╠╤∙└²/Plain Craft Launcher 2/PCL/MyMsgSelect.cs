﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000056 RID: 86
	[DesignerGenerated]
	public class MyMsgSelect : Grid, IComponentConnector
	{
		// Token: 0x06000263 RID: 611 RVA: 0x00016F90 File Offset: 0x00015190
		public MyMsgSelect(ModMain.MyMsgBoxConverter Converter)
		{
			base.Loaded += new RoutedEventHandler(this.Load);
			this.parameterWrapper = ModBase.GetUuid();
			this.authenticationWrapper = -1;
			try
			{
				this.InitializeComponent();
				this.Btn1.Name = this.Btn1.Name + Conversions.ToString(ModBase.GetUuid());
				this.Btn2.Name = this.Btn2.Name + Conversions.ToString(ModBase.GetUuid());
				this.Btn3.Name = this.Btn3.Name + Conversions.ToString(ModBase.GetUuid());
				this.m_ProccesorWrapper = Converter;
				this.LabTitle.Text = Converter.Title;
				this.Btn1.Text = Converter._ProcessParameter;
				if (Converter.m_OrderParameter)
				{
					this.Btn1.ColorType = MyButton.ColorState.Red;
					this.LabTitle.SetResourceReference(TextBlock.ForegroundProperty, "ColorBrushRedLight");
					this.ShapeLine.SetResourceReference(Shape.FillProperty, "ColorBrushRedLight");
				}
				this.Btn2.Text = Converter._ValParameter;
				this.Btn3.Text = Converter.utilsParameter;
				this.Btn2.Visibility = ((Operators.CompareString(Converter._ValParameter, "", true) == 0) ? Visibility.Collapsed : Visibility.Visible);
				this.Btn3.Visibility = ((Operators.CompareString(Converter.utilsParameter, "", true) == 0) ? Visibility.Collapsed : Visibility.Visible);
				try
				{
					foreach (object obj in ((IEnumerable)Converter.m_ComposerParameter))
					{
						IMyRadio myRadio = (IMyRadio)obj;
						this.PanSelection.Children.Add((UIElement)myRadio);
						myRadio.Check += delegate(object sender, ModBase.RouteEventArgs e)
						{
							this.OnChecked((IMyRadio)sender, e);
						};
						if (myRadio is MyListItem)
						{
							((MyListItem)myRadio).Type = MyListItem.CheckType.RadioBox;
							((MyListItem)myRadio).MinHeight = 24.0;
						}
						else
						{
							((MyRadioBox)myRadio).MinHeight = 26.0;
						}
					}
				}
				finally
				{
					IEnumerator enumerator;
					if (enumerator is IDisposable)
					{
						(enumerator as IDisposable).Dispose();
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "选择弹窗初始化失败", ModBase.LogLevel.Hint, "出现错误");
			}
		}

		// Token: 0x06000264 RID: 612 RVA: 0x00017204 File Offset: 0x00015404
		private void Load(object sender, EventArgs e)
		{
			try
			{
				if (this.Btn2.IsVisible && this.Btn1.ColorType != MyButton.ColorState.Red)
				{
					this.Btn1.ColorType = MyButton.ColorState.Highlight;
				}
				this.ShapeLine.StrokeThickness = ModBase.smethod_4(1.0);
				base.Measure(new Size(ModMain.m_CollectionAccount.Width, ModMain.m_CollectionAccount.Height));
				base.Arrange(new Rect(0.0, 0.0, ModMain.m_CollectionAccount.Width, ModMain.m_CollectionAccount.Height));
				if (ModMain.m_CollectionAccount.Width - base.ActualWidth < 20.0)
				{
					base.Width = ModMain.m_CollectionAccount.Width - ModBase.smethod_4(2.0);
				}
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaColor(ModMain.m_CollectionAccount.PanMsg, Panel.BackgroundProperty, new ModBase.MyColor(60.0, 0.0, 0.0, 0.0), 250, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaColor(this.PanBorder, Border.BackgroundProperty, new ModBase.MyColor(255.0, 0.0, 0.0, 0.0), 150, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaOpacity(this.EffectShadow, 0.75, 400, 50, null, false),
					ModAnimation.AaWidth(this.ShapeLine, this.ShapeLine.ActualWidth, 250, 100, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaOpacity(this.ShapeLine, 1.0, 200, 100, null, false),
					ModAnimation.AaWidth(this.LabTitle, this.LabTitle.ActualWidth, 200, 100, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaOpacity(this.LabTitle, 1.0, 150, 150, null, false),
					ModAnimation.AaOpacity(this.PanCaption, 1.0, 150, 150, null, false),
					ModAnimation.AaOpacity(this.Btn1, 1.0, 150, 100, null, false),
					ModAnimation.AaOpacity(this.Btn2, 1.0, 150, 150, null, false),
					ModAnimation.AaOpacity(this.Btn3, 1.0, 150, 200, null, false),
					ModAnimation.AaCode(delegate
					{
						this.ShapeLine.MinWidth = this.ShapeLine.ActualWidth;
						this.ShapeLine.HorizontalAlignment = HorizontalAlignment.Stretch;
						this.ShapeLine.Width = double.NaN;
						this.LabTitle.Width = double.NaN;
						this.LabTitle.TextTrimming = TextTrimming.CharacterEllipsis;
					}, 350, false)
				}, "MyMsgBox Start " + Conversions.ToString(this.parameterWrapper), false);
				this.ShapeLine.Width = 0.0;
				this.ShapeLine.HorizontalAlignment = HorizontalAlignment.Center;
				this.LabTitle.Width = 0.0;
				this.LabTitle.Opacity = 0.0;
				this.LabTitle.TextWrapping = TextWrapping.NoWrap;
				this.PanCaption.Opacity = 0.0;
				ModBase.Log("[Control] 选择弹窗：" + this.LabTitle.Text, ModBase.LogLevel.Normal, "出现错误");
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "选择弹窗加载失败", ModBase.LogLevel.Hint, "出现错误");
			}
		}

		// Token: 0x06000265 RID: 613 RVA: 0x000175E0 File Offset: 0x000157E0
		private void Close()
		{
			this.m_ProccesorWrapper.m_ThreadParameter.Continue = false;
			ComponentDispatcher.PopModal();
			this.LabTitle.TextTrimming = TextTrimming.None;
			this.LabTitle.TextWrapping = TextWrapping.NoWrap;
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaColor(ModMain.m_CollectionAccount.PanMsg, Panel.BackgroundProperty, new ModBase.MyColor(-60.0, 0.0, 0.0, 0.0), 350, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaColor(this.PanBorder, Border.BackgroundProperty, new ModBase.MyColor(-255.0, 0.0, 0.0, 0.0), 300, 100, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaOpacity(this.EffectShadow, -0.75, 150, 0, null, false),
				ModAnimation.AaWidth(this.ShapeLine, -this.ShapeLine.ActualWidth, 250, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaOpacity(this.ShapeLine, -1.0, 150, 100, null, false),
				ModAnimation.AaWidth(this.LabTitle, -this.LabTitle.ActualWidth, 250, 0, null, false),
				ModAnimation.AaOpacity(this.LabTitle, -1.0, 200, 0, null, false),
				ModAnimation.AaOpacity(this.PanCaption, -1.0, 200, 0, null, false),
				ModAnimation.AaOpacity(this.Btn1, -1.0, 150, 0, null, false),
				ModAnimation.AaOpacity(this.Btn2, -1.0, 150, 50, null, false),
				ModAnimation.AaOpacity(this.Btn3, -1.0, 150, 100, null, false),
				ModAnimation.AaCode(delegate
				{
					((Grid)base.Parent).Children.Remove(this);
				}, 0, true)
			}, "MyMsgBox Close " + Conversions.ToString(this.parameterWrapper), false);
		}

		// Token: 0x06000266 RID: 614 RVA: 0x000035F4 File Offset: 0x000017F4
		public void Btn1_Click()
		{
			if (!this.m_ProccesorWrapper.connectionParameter && this.authenticationWrapper != -1)
			{
				this.m_ProccesorWrapper.connectionParameter = true;
				this.m_ProccesorWrapper._CustomerParameter = this.authenticationWrapper;
				this.Close();
			}
		}

		// Token: 0x06000267 RID: 615 RVA: 0x00003634 File Offset: 0x00001834
		private void Btn2_Click()
		{
			if (!this.m_ProccesorWrapper.connectionParameter)
			{
				this.m_ProccesorWrapper.connectionParameter = true;
				this.m_ProccesorWrapper._CustomerParameter = null;
				this.Close();
			}
		}

		// Token: 0x06000268 RID: 616 RVA: 0x00003634 File Offset: 0x00001834
		private void Btn3_Click()
		{
			if (!this.m_ProccesorWrapper.connectionParameter)
			{
				this.m_ProccesorWrapper.connectionParameter = true;
				this.m_ProccesorWrapper._CustomerParameter = null;
				this.Close();
			}
		}

		// Token: 0x06000269 RID: 617 RVA: 0x00003661 File Offset: 0x00001861
		private void OnChecked(IMyRadio sender, EventArgs e)
		{
			this.Btn1.IsEnabled = true;
			this.authenticationWrapper = this.PanSelection.Children.IndexOf((UIElement)sender);
		}

		// Token: 0x0600026A RID: 618 RVA: 0x00017844 File Offset: 0x00015A44
		private void Drag(object sender, MouseButtonEventArgs e)
		{
			int num;
			int num4;
			object obj;
			try
			{
				IL_00:
				ProjectData.ClearProjectError();
				num = 1;
				IL_07:
				int num2 = 2;
				if (e.GetPosition(this.ShapeLine).Y > 2.0)
				{
					goto IL_34;
				}
				IL_28:
				num2 = 3;
				ModMain.m_CollectionAccount.DragMove();
				IL_34:
				goto IL_93;
				IL_36:
				int num3 = num4 + 1;
				num4 = 0;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
				IL_54:
				goto IL_88;
				IL_56:
				num4 = num2;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
				IL_66:;
			}
			catch when (endfilter(obj is Exception & num != 0 & num4 == 0))
			{
				Exception ex = (Exception)obj2;
				goto IL_56;
			}
			IL_88:
			throw ProjectData.CreateProjectError(-2146828237);
			IL_93:
			if (num4 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x0600026B RID: 619 RVA: 0x0000368B File Offset: 0x0000188B
		// (set) Token: 0x0600026C RID: 620 RVA: 0x00003693 File Offset: 0x00001893
		internal virtual MyMsgSelect PanBack { get; set; }

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x0600026D RID: 621 RVA: 0x0000369C File Offset: 0x0000189C
		// (set) Token: 0x0600026E RID: 622 RVA: 0x000178FC File Offset: 0x00015AFC
		internal virtual Border PanBorder
		{
			[CompilerGenerated]
			get
			{
				return this.m_ContainerWrapper;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = new MouseButtonEventHandler(this.Drag);
				Border containerWrapper = this.m_ContainerWrapper;
				if (containerWrapper != null)
				{
					containerWrapper.MouseLeftButtonDown -= value2;
				}
				this.m_ContainerWrapper = value;
				containerWrapper = this.m_ContainerWrapper;
				if (containerWrapper != null)
				{
					containerWrapper.MouseLeftButtonDown += value2;
				}
			}
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x0600026F RID: 623 RVA: 0x000036A4 File Offset: 0x000018A4
		// (set) Token: 0x06000270 RID: 624 RVA: 0x000036AC File Offset: 0x000018AC
		internal virtual DropShadowEffect EffectShadow { get; set; }

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000271 RID: 625 RVA: 0x000036B5 File Offset: 0x000018B5
		// (set) Token: 0x06000272 RID: 626 RVA: 0x00017940 File Offset: 0x00015B40
		internal virtual TextBlock LabTitle
		{
			[CompilerGenerated]
			get
			{
				return this.m_TokenizerWrapper;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = new MouseButtonEventHandler(this.Drag);
				TextBlock tokenizerWrapper = this.m_TokenizerWrapper;
				if (tokenizerWrapper != null)
				{
					tokenizerWrapper.MouseLeftButtonDown -= value2;
				}
				this.m_TokenizerWrapper = value;
				tokenizerWrapper = this.m_TokenizerWrapper;
				if (tokenizerWrapper != null)
				{
					tokenizerWrapper.MouseLeftButtonDown += value2;
				}
			}
		}

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x06000273 RID: 627 RVA: 0x000036BD File Offset: 0x000018BD
		// (set) Token: 0x06000274 RID: 628 RVA: 0x000036C5 File Offset: 0x000018C5
		internal virtual Rectangle ShapeLine { get; set; }

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x06000275 RID: 629 RVA: 0x000036CE File Offset: 0x000018CE
		// (set) Token: 0x06000276 RID: 630 RVA: 0x000036D6 File Offset: 0x000018D6
		internal virtual MyScrollViewer PanCaption { get; set; }

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x06000277 RID: 631 RVA: 0x000036DF File Offset: 0x000018DF
		// (set) Token: 0x06000278 RID: 632 RVA: 0x000036E7 File Offset: 0x000018E7
		internal virtual StackPanel PanSelection { get; set; }

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x06000279 RID: 633 RVA: 0x000036F0 File Offset: 0x000018F0
		// (set) Token: 0x0600027A RID: 634 RVA: 0x000036F8 File Offset: 0x000018F8
		internal virtual StackPanel PanBtn { get; set; }

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x0600027B RID: 635 RVA: 0x00003701 File Offset: 0x00001901
		// (set) Token: 0x0600027C RID: 636 RVA: 0x00017984 File Offset: 0x00015B84
		internal virtual MyButton Btn1
		{
			[CompilerGenerated]
			get
			{
				return this.initializerWrapper;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.Btn1_Click();
				};
				MyButton myButton = this.initializerWrapper;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.initializerWrapper = value;
				myButton = this.initializerWrapper;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x0600027D RID: 637 RVA: 0x00003709 File Offset: 0x00001909
		// (set) Token: 0x0600027E RID: 638 RVA: 0x000179C8 File Offset: 0x00015BC8
		internal virtual MyButton Btn2
		{
			[CompilerGenerated]
			get
			{
				return this.m_SystemWrapper;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.Btn2_Click();
				};
				MyButton systemWrapper = this.m_SystemWrapper;
				if (systemWrapper != null)
				{
					systemWrapper.RevertResolver(obj);
				}
				this.m_SystemWrapper = value;
				systemWrapper = this.m_SystemWrapper;
				if (systemWrapper != null)
				{
					systemWrapper.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x0600027F RID: 639 RVA: 0x00003711 File Offset: 0x00001911
		// (set) Token: 0x06000280 RID: 640 RVA: 0x00017A0C File Offset: 0x00015C0C
		internal virtual MyButton Btn3
		{
			[CompilerGenerated]
			get
			{
				return this.writerWrapper;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.Btn3_Click();
				};
				MyButton myButton = this.writerWrapper;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.writerWrapper = value;
				myButton = this.writerWrapper;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x06000281 RID: 641 RVA: 0x00017A50 File Offset: 0x00015C50
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.broadcasterWrapper)
			{
				this.broadcasterWrapper = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/controls/mymsg/mymsgselect.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000282 RID: 642 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000283 RID: 643 RVA: 0x00017A80 File Offset: 0x00015C80
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyMsgSelect)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanBorder = (Border)target;
				return;
			}
			if (connectionId == 3)
			{
				this.EffectShadow = (DropShadowEffect)target;
				return;
			}
			if (connectionId == 4)
			{
				this.LabTitle = (TextBlock)target;
				return;
			}
			if (connectionId == 5)
			{
				this.ShapeLine = (Rectangle)target;
				return;
			}
			if (connectionId == 6)
			{
				this.PanCaption = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 7)
			{
				this.PanSelection = (StackPanel)target;
				return;
			}
			if (connectionId == 8)
			{
				this.PanBtn = (StackPanel)target;
				return;
			}
			if (connectionId == 9)
			{
				this.Btn1 = (MyButton)target;
				return;
			}
			if (connectionId == 10)
			{
				this.Btn2 = (MyButton)target;
				return;
			}
			if (connectionId == 11)
			{
				this.Btn3 = (MyButton)target;
				return;
			}
			this.broadcasterWrapper = true;
		}

		// Token: 0x0400010D RID: 269
		private readonly ModMain.MyMsgBoxConverter m_ProccesorWrapper;

		// Token: 0x0400010E RID: 270
		private readonly int parameterWrapper;

		// Token: 0x0400010F RID: 271
		private int authenticationWrapper;

		// Token: 0x04000110 RID: 272
		[CompilerGenerated]
		[AccessedThroughProperty("PanBack")]
		private MyMsgSelect _ReponseWrapper;

		// Token: 0x04000111 RID: 273
		[AccessedThroughProperty("PanBorder")]
		[CompilerGenerated]
		private Border m_ContainerWrapper;

		// Token: 0x04000112 RID: 274
		[AccessedThroughProperty("EffectShadow")]
		[CompilerGenerated]
		private DropShadowEffect m_CodeWrapper;

		// Token: 0x04000113 RID: 275
		[AccessedThroughProperty("LabTitle")]
		[CompilerGenerated]
		private TextBlock m_TokenizerWrapper;

		// Token: 0x04000114 RID: 276
		[AccessedThroughProperty("ShapeLine")]
		[CompilerGenerated]
		private Rectangle definitionWrapper;

		// Token: 0x04000115 RID: 277
		[AccessedThroughProperty("PanCaption")]
		[CompilerGenerated]
		private MyScrollViewer m_ParamsWrapper;

		// Token: 0x04000116 RID: 278
		[CompilerGenerated]
		[AccessedThroughProperty("PanSelection")]
		private StackPanel mockWrapper;

		// Token: 0x04000117 RID: 279
		[AccessedThroughProperty("PanBtn")]
		[CompilerGenerated]
		private StackPanel adapterWrapper;

		// Token: 0x04000118 RID: 280
		[AccessedThroughProperty("Btn1")]
		[CompilerGenerated]
		private MyButton initializerWrapper;

		// Token: 0x04000119 RID: 281
		[AccessedThroughProperty("Btn2")]
		[CompilerGenerated]
		private MyButton m_SystemWrapper;

		// Token: 0x0400011A RID: 282
		[CompilerGenerated]
		[AccessedThroughProperty("Btn3")]
		private MyButton writerWrapper;

		// Token: 0x0400011B RID: 283
		private bool broadcasterWrapper;
	}
}
