﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000059 RID: 89
	[DesignerGenerated]
	public class MySearchBox : MyCard, IComponentConnector
	{
		// Token: 0x0600029E RID: 670 RVA: 0x000037E2 File Offset: 0x000019E2
		public MySearchBox()
		{
			base.Loaded += this.MySearchBox_Loaded;
			this.InitializeComponent();
		}

		// Token: 0x0600029F RID: 671 RVA: 0x00017EE0 File Offset: 0x000160E0
		[CompilerGenerated]
		public void RunWrapper(MySearchBox.TextChangedEventHandler obj)
		{
			MySearchBox.TextChangedEventHandler textChangedEventHandler = this.m_ClientWrapper;
			MySearchBox.TextChangedEventHandler textChangedEventHandler2;
			do
			{
				textChangedEventHandler2 = textChangedEventHandler;
				MySearchBox.TextChangedEventHandler value = (MySearchBox.TextChangedEventHandler)Delegate.Combine(textChangedEventHandler2, obj);
				textChangedEventHandler = Interlocked.CompareExchange<MySearchBox.TextChangedEventHandler>(ref this.m_ClientWrapper, value, textChangedEventHandler2);
			}
			while (textChangedEventHandler != textChangedEventHandler2);
		}

		// Token: 0x060002A0 RID: 672 RVA: 0x00017F18 File Offset: 0x00016118
		[CompilerGenerated]
		public void PushWrapper(MySearchBox.TextChangedEventHandler obj)
		{
			MySearchBox.TextChangedEventHandler textChangedEventHandler = this.m_ClientWrapper;
			MySearchBox.TextChangedEventHandler textChangedEventHandler2;
			do
			{
				textChangedEventHandler2 = textChangedEventHandler;
				MySearchBox.TextChangedEventHandler value = (MySearchBox.TextChangedEventHandler)Delegate.Remove(textChangedEventHandler2, obj);
				textChangedEventHandler = Interlocked.CompareExchange<MySearchBox.TextChangedEventHandler>(ref this.m_ClientWrapper, value, textChangedEventHandler2);
			}
			while (textChangedEventHandler != textChangedEventHandler2);
		}

		// Token: 0x060002A1 RID: 673 RVA: 0x00003803 File Offset: 0x00001A03
		private void MySearchBox_Loaded(object sender, RoutedEventArgs e)
		{
			this.TextBox.Focus();
		}

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x060002A2 RID: 674 RVA: 0x00003811 File Offset: 0x00001A11
		// (set) Token: 0x060002A3 RID: 675 RVA: 0x0000381E File Offset: 0x00001A1E
		public string HintText
		{
			get
			{
				return this.TextBox.HintText;
			}
			set
			{
				this.TextBox.HintText = value;
			}
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x060002A4 RID: 676 RVA: 0x0000382C File Offset: 0x00001A2C
		// (set) Token: 0x060002A5 RID: 677 RVA: 0x00003839 File Offset: 0x00001A39
		public string Text
		{
			get
			{
				return this.TextBox.Text;
			}
			set
			{
				this.TextBox.Text = value;
			}
		}

		// Token: 0x060002A6 RID: 678 RVA: 0x00017F50 File Offset: 0x00016150
		private void Text_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (string.IsNullOrEmpty(this.TextBox.Text))
			{
				ModAnimation.AniStart(ModAnimation.AaOpacity(this.BtnClear, -this.BtnClear.Opacity, 90, 0, null, false), "MySearchBox ClearBtn " + Conversions.ToString(this._System), false);
				this.BtnClear.IsHitTestVisible = false;
			}
			else
			{
				ModAnimation.AniStart(ModAnimation.AaOpacity(this.BtnClear, 1.0 - this.BtnClear.Opacity, 90, 0, null, false), "MySearchBox ClearBtn " + Conversions.ToString(this._System), false);
				this.BtnClear.IsHitTestVisible = true;
			}
			MySearchBox.TextChangedEventHandler clientWrapper = this.m_ClientWrapper;
			if (clientWrapper != null)
			{
				clientWrapper(RuntimeHelpers.GetObjectValue(sender), e);
			}
		}

		// Token: 0x060002A7 RID: 679 RVA: 0x00003847 File Offset: 0x00001A47
		private void BtnClear_Click(object sender, EventArgs e)
		{
			this.TextBox.Text = "";
			this.TextBox.Focus();
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x060002A8 RID: 680 RVA: 0x00003865 File Offset: 0x00001A65
		// (set) Token: 0x060002A9 RID: 681 RVA: 0x00018018 File Offset: 0x00016218
		internal virtual MyTextBox TextBox
		{
			[CompilerGenerated]
			get
			{
				return this._InfoWrapper;
			}
			[CompilerGenerated]
			set
			{
				System.Windows.Controls.TextChangedEventHandler value2 = new System.Windows.Controls.TextChangedEventHandler(this.Text_TextChanged);
				MyTextBox infoWrapper = this._InfoWrapper;
				if (infoWrapper != null)
				{
					infoWrapper.TextChanged -= value2;
				}
				this._InfoWrapper = value;
				infoWrapper = this._InfoWrapper;
				if (infoWrapper != null)
				{
					infoWrapper.TextChanged += value2;
				}
			}
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x060002AA RID: 682 RVA: 0x0000386D File Offset: 0x00001A6D
		// (set) Token: 0x060002AB RID: 683 RVA: 0x0001805C File Offset: 0x0001625C
		internal virtual MyIconButton BtnClear
		{
			[CompilerGenerated]
			get
			{
				return this.m_DecoratorWrapper;
			}
			[CompilerGenerated]
			set
			{
				MyIconButton.ClickEventHandler value2 = new MyIconButton.ClickEventHandler(this.BtnClear_Click);
				MyIconButton decoratorWrapper = this.m_DecoratorWrapper;
				if (decoratorWrapper != null)
				{
					decoratorWrapper.Click -= value2;
				}
				this.m_DecoratorWrapper = value;
				decoratorWrapper = this.m_DecoratorWrapper;
				if (decoratorWrapper != null)
				{
					decoratorWrapper.Click += value2;
				}
			}
		}

		// Token: 0x060002AC RID: 684 RVA: 0x000180A0 File Offset: 0x000162A0
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.propertyWrapper)
			{
				this.propertyWrapper = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/controls/mysearchbox.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x060002AD RID: 685 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060002AE RID: 686 RVA: 0x00003875 File Offset: 0x00001A75
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.TextBox = (MyTextBox)target;
				return;
			}
			if (connectionId == 2)
			{
				this.BtnClear = (MyIconButton)target;
				return;
			}
			this.propertyWrapper = true;
		}

		// Token: 0x0400011F RID: 287
		[CompilerGenerated]
		private MySearchBox.TextChangedEventHandler m_ClientWrapper;

		// Token: 0x04000120 RID: 288
		[CompilerGenerated]
		[AccessedThroughProperty("TextBox")]
		private MyTextBox _InfoWrapper;

		// Token: 0x04000121 RID: 289
		[AccessedThroughProperty("BtnClear")]
		[CompilerGenerated]
		private MyIconButton m_DecoratorWrapper;

		// Token: 0x04000122 RID: 290
		private bool propertyWrapper;

		// Token: 0x0200005A RID: 90
		// (Invoke) Token: 0x060002B3 RID: 691
		public delegate void TextChangedEventHandler(object sender, EventArgs e);
	}
}
