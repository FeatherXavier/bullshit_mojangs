﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.VisualBasic.CompilerServices;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PCL.My;

namespace PCL
{
	// Token: 0x020000C1 RID: 193
	[DesignerGenerated]
	public class PageVersionSetup : MyPageRight, IComponentConnector
	{
		// Token: 0x0600079D RID: 1949 RVA: 0x0000602C File Offset: 0x0000422C
		public PageVersionSetup()
		{
			base.Loaded += this.PageSetupSystem_Loaded;
			this.singletonResolver = false;
			this._ContextResolver = 2;
			this.m_CollectionResolver = 1;
			this.InitializeComponent();
		}

		// Token: 0x0600079E RID: 1950 RVA: 0x00034AC8 File Offset: 0x00032CC8
		private void PageSetupSystem_Loaded(object sender, RoutedEventArgs e)
		{
			this.PanBack.ScrollToHome();
			this.RefreshRam(false);
			checked
			{
				ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
				this.Reload();
				ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
				if (!this.singletonResolver)
				{
					this.singletonResolver = true;
					DispatcherTimer dispatcherTimer = new DispatcherTimer();
					dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 1);
					dispatcherTimer.Tick += delegate(object sender, EventArgs e)
					{
						this.RefreshRam();
					};
					dispatcherTimer.Start();
				}
			}
		}

		// Token: 0x0600079F RID: 1951 RVA: 0x00034B40 File Offset: 0x00032D40
		public void Reload()
		{
			try
			{
				this.TextArgumentTitle.Text = Conversions.ToString(ModBase._ParamsState.Get("VersionArgumentTitle", PageVersionLeft.m_AlgoResolver));
				this.TextArgumentInfo.Text = Conversions.ToString(ModBase._ParamsState.Get("VersionArgumentInfo", PageVersionLeft.m_AlgoResolver));
				int num = Conversions.ToInteger(ModBase._ParamsState.Get("VersionArgumentIndie", PageVersionLeft.m_AlgoResolver));
				if (num == -1)
				{
					DirectoryInfo directoryInfo = new DirectoryInfo(PageVersionLeft.m_AlgoResolver.Path + "mods\\");
					DirectoryInfo directoryInfo2 = new DirectoryInfo(PageVersionLeft.m_AlgoResolver.Path + "saves\\");
					if ((directoryInfo.Exists && directoryInfo.EnumerateFiles().Count<FileInfo>() > 0) || (directoryInfo2.Exists && directoryInfo2.EnumerateFiles().Count<FileInfo>() > 0))
					{
						ModBase._ParamsState.Set("VersionArgumentIndie", 1, false, PageVersionLeft.m_AlgoResolver);
						ModBase.Log("[Setup] 已自动开启单版本隔离：" + PageVersionLeft.m_AlgoResolver.Name, ModBase.LogLevel.Normal, "出现错误");
						num = 1;
					}
					else
					{
						ModBase._ParamsState.Set("VersionArgumentIndie", 0, false, PageVersionLeft.m_AlgoResolver);
						ModBase.Log("[Setup] 版本隔离使用全局设置：" + PageVersionLeft.m_AlgoResolver.Name, ModBase.LogLevel.Normal, "出现错误");
						num = 0;
					}
				}
				this.ComboArgumentIndie.SelectedIndex = num;
				this.TextAdvanceJvm.Text = Conversions.ToString(ModBase._ParamsState.Get("VersionAdvanceJvm", PageVersionLeft.m_AlgoResolver));
				this.TextAdvanceGame.Text = Conversions.ToString(ModBase._ParamsState.Get("VersionAdvanceGame", PageVersionLeft.m_AlgoResolver));
				this.ComboAdvanceAssets.SelectedIndex = Conversions.ToInteger(ModBase._ParamsState.Get("VersionAdvanceAssets", PageVersionLeft.m_AlgoResolver));
				this.RefreshJavaComboBox();
				((MyRadioBox)base.FindName(Conversions.ToString(Operators.ConcatenateObject("RadioRamType", ModBase._ParamsState.Load("VersionRamType", false, PageVersionLeft.m_AlgoResolver))))).Checked = true;
				this.SliderRamCustom.Value = Conversions.ToInteger(ModBase._ParamsState.Get("VersionRamCustom", PageVersionLeft.m_AlgoResolver));
				this.TextServerEnter.Text = Conversions.ToString(ModBase._ParamsState.Get("VersionServerEnter", PageVersionLeft.m_AlgoResolver));
				this.ComboServerLogin.SelectedIndex = Conversions.ToInteger(ModBase._ParamsState.Get("VersionServerLogin", PageVersionLeft.m_AlgoResolver));
				this.m_ConsumerResolver = this.ComboServerLogin.SelectedIndex;
				this.ServerLogin(this.ComboServerLogin.SelectedIndex);
				this.TextServerNide.Text = Conversions.ToString(ModBase._ParamsState.Get("VersionServerNide", PageVersionLeft.m_AlgoResolver));
				this.TextServerAuthServer.Text = Conversions.ToString(ModBase._ParamsState.Get("VersionServerAuthServer", PageVersionLeft.m_AlgoResolver));
				this.TextServerAuthName.Text = Conversions.ToString(ModBase._ParamsState.Get("VersionServerAuthName", PageVersionLeft.m_AlgoResolver));
				this.TextServerAuthRegister.Text = Conversions.ToString(ModBase._ParamsState.Get("VersionServerAuthRegister", PageVersionLeft.m_AlgoResolver));
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "重载版本独立设置时出错", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x060007A0 RID: 1952 RVA: 0x00034EA0 File Offset: 0x000330A0
		public void Reset()
		{
			try
			{
				ModBase._ParamsState.Reset("VersionServerEnter", false, PageVersionLeft.m_AlgoResolver);
				ModBase._ParamsState.Reset("VersionServerLogin", false, PageVersionLeft.m_AlgoResolver);
				ModBase._ParamsState.Reset("VersionServerNide", false, PageVersionLeft.m_AlgoResolver);
				ModBase._ParamsState.Reset("VersionServerAuthServer", false, PageVersionLeft.m_AlgoResolver);
				ModBase._ParamsState.Reset("VersionServerAuthRegister", false, PageVersionLeft.m_AlgoResolver);
				ModBase._ParamsState.Reset("VersionServerAuthName", false, PageVersionLeft.m_AlgoResolver);
				ModBase._ParamsState.Reset("VersionArgumentTitle", false, PageVersionLeft.m_AlgoResolver);
				ModBase._ParamsState.Reset("VersionArgumentInfo", false, PageVersionLeft.m_AlgoResolver);
				ModBase._ParamsState.Set("VersionArgumentIndie", 0, false, PageVersionLeft.m_AlgoResolver);
				ModBase._ParamsState.Reset("VersionRamType", false, PageVersionLeft.m_AlgoResolver);
				ModBase._ParamsState.Reset("VersionRamCustom", false, PageVersionLeft.m_AlgoResolver);
				ModBase._ParamsState.Reset("VersionAdvanceJvm", false, PageVersionLeft.m_AlgoResolver);
				ModBase._ParamsState.Reset("VersionAdvanceGame", false, PageVersionLeft.m_AlgoResolver);
				ModBase._ParamsState.Reset("VersionAdvanceAssets", false, PageVersionLeft.m_AlgoResolver);
				ModBase._ParamsState.Reset("VersionArgumentJavaSelect", false, PageVersionLeft.m_AlgoResolver);
				ModMinecraft.composerTag.Start(null, true);
				ModBase.Log("[Setup] 已初始化版本独立设置", ModBase.LogLevel.Normal, "出现错误");
				ModMain.Hint("已初始化版本独立设置！", ModMain.HintType.Finish, false);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "初始化版本独立设置失败", ModBase.LogLevel.Msgbox, "出现错误");
			}
			this.Reload();
		}

		// Token: 0x060007A1 RID: 1953 RVA: 0x0003505C File Offset: 0x0003325C
		private static void RadioBoxChange(MyRadioBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(sender.Tag.ToString().Split(new char[]
				{
					'/'
				})[0], ModBase.Val(sender.Tag.ToString().Split(new char[]
				{
					'/'
				})[1]), false, PageVersionLeft.m_AlgoResolver);
			}
		}

		// Token: 0x060007A2 RID: 1954 RVA: 0x000350C4 File Offset: 0x000332C4
		private static void TextBoxChange(MyTextBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				string text = sender.Text;
				if (Operators.ConditionalCompareObjectEqual(sender.Tag, "VersionServerAuthServer", true) || Operators.ConditionalCompareObjectEqual(sender.Tag, "VersionServerAuthRegister", true))
				{
					text = text.TrimEnd(new char[]
					{
						'/'
					});
				}
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), text, false, PageVersionLeft.m_AlgoResolver);
			}
		}

		// Token: 0x060007A3 RID: 1955 RVA: 0x00006062 File Offset: 0x00004262
		private static void SliderChange(MySlider sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.Value, false, PageVersionLeft.m_AlgoResolver);
			}
		}

		// Token: 0x060007A4 RID: 1956 RVA: 0x00006091 File Offset: 0x00004291
		private static void ComboChange(MyComboBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.SelectedIndex, false, PageVersionLeft.m_AlgoResolver);
			}
		}

		// Token: 0x060007A5 RID: 1957 RVA: 0x000060C0 File Offset: 0x000042C0
		public void RamType(int Type)
		{
			if (this.SliderRamCustom != null)
			{
				this.SliderRamCustom.IsEnabled = (Type == 1);
			}
		}

		// Token: 0x060007A6 RID: 1958 RVA: 0x00035134 File Offset: 0x00033334
		public void RefreshRam(bool ShowAnim)
		{
			if (this.LabRamGame != null && this.LabRamUsed != null && !(ModMain.m_CollectionAccount.comparatorAccount != FormMain.PageType.VersionSetup) && ModMain._MappingAccount.poolResolver == FormMain.PageSubType.DownloadInstall)
			{
				double ram = PageVersionSetup.GetRam(PageVersionLeft.m_AlgoResolver);
				double num = Math.Round(MyWpfExtension.FindModel().Info.TotalPhysicalMemory / 1024.0 / 1024.0 / 1024.0 * 10.0) / 10.0;
				double num2 = Math.Round(MyWpfExtension.FindModel().Info.AvailablePhysicalMemory / 1024.0 / 1024.0 / 1024.0 * 10.0) / 10.0;
				double num3 = Math.Min(ram, num2);
				double num4 = num - num2;
				double num5 = Math.Round(ModBase.MathRange(num - num4 - ram, 0.0, 1000.0) * 10.0) / 10.0;
				checked
				{
					if (num <= 1.5)
					{
						this.SliderRamCustom.MaxValue = (int)Math.Round(Math.Max(Math.Floor(unchecked(num - 0.3) / 0.1), 1.0));
					}
					else if (num <= 8.0)
					{
						this.SliderRamCustom.MaxValue = (int)Math.Round(unchecked(Math.Floor((num - 1.5) / 0.5) + 12.0));
					}
					else if (num <= 16.0)
					{
						this.SliderRamCustom.MaxValue = (int)Math.Round(unchecked(Math.Floor((num - 8.0) / 1.0) + 25.0));
					}
					else if (num <= 32.0)
					{
						this.SliderRamCustom.MaxValue = (int)Math.Round(unchecked(Math.Floor((num - 16.0) / 2.0) + 33.0));
					}
					else
					{
						this.SliderRamCustom.MaxValue = (int)Math.Round(Math.Min(unchecked(Math.Floor((num - 32.0) / 4.0) + 41.0), 49.0));
					}
					this.LabRamGame.Text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject((ram == Math.Floor(ram)) ? (Conversions.ToString(ram) + ".0") : ram, " GB"), (ram != num3) ? Operators.ConcatenateObject(Operators.ConcatenateObject(" (可用 ", (num3 == Math.Floor(num3)) ? (Conversions.ToString(num3) + ".0") : num3), " GB)") : ""));
					this.LabRamUsed.Text = Conversions.ToString(Operators.ConcatenateObject((num4 == Math.Floor(num4)) ? (Conversions.ToString(num4) + ".0") : num4, " GB"));
					this.LabRamTotal.Text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(" / ", (num == Math.Floor(num)) ? (Conversions.ToString(num) + ".0") : num), " GB"));
					this.LabRamWarn.Visibility = ((ram != 1.0 || ModMinecraft.JavaUse64Bit(PageVersionLeft.m_AlgoResolver) || ModBase.m_WriterState) ? Visibility.Collapsed : Visibility.Visible);
				}
				if (ShowAnim)
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaGridLengthWidth(this.ColumnRamUsed, num4 - this.ColumnRamUsed.Width.Value, 800, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false),
						ModAnimation.AaGridLengthWidth(this.ColumnRamGame, num3 - this.ColumnRamGame.Width.Value, 800, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false),
						ModAnimation.AaGridLengthWidth(this.ColumnRamEmpty, num5 - this.ColumnRamEmpty.Width.Value, 800, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false)
					}, "VersionSetup Ram Grid", false);
					return;
				}
				this.ColumnRamUsed.Width = new GridLength(num4, GridUnitType.Star);
				this.ColumnRamGame.Width = new GridLength(num3, GridUnitType.Star);
				this.ColumnRamEmpty.Width = new GridLength(num5, GridUnitType.Star);
			}
		}

		// Token: 0x060007A7 RID: 1959 RVA: 0x000060D9 File Offset: 0x000042D9
		private void RefreshRam()
		{
			this.RefreshRam(true);
		}

		// Token: 0x060007A8 RID: 1960 RVA: 0x000355E4 File Offset: 0x000337E4
		private void RefreshRamText()
		{
			double actualWidth = this.RectRamUsed.ActualWidth;
			double actualWidth2 = this.PanRamDisplay.ActualWidth;
			double actualWidth3 = this.LabRamGame.ActualWidth;
			double actualWidth4 = this.LabRamUsed.ActualWidth;
			double actualWidth5 = this.LabRamTotal.ActualWidth;
			double actualWidth6 = this.LabRamGameTitle.ActualWidth;
			double actualWidth7 = this.LabRamUsedTitle.ActualWidth;
			int num;
			if (actualWidth - 30.0 >= actualWidth4 && actualWidth - 30.0 >= actualWidth7)
			{
				if (actualWidth - 25.0 < actualWidth4 + actualWidth5)
				{
					num = 1;
				}
				else
				{
					num = 2;
				}
			}
			else
			{
				num = 0;
			}
			if (this._ContextResolver != num)
			{
				this._ContextResolver = num;
				switch (num)
				{
				case 0:
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaOpacity(this.LabRamUsed, -this.LabRamUsed.Opacity, 100, 0, null, false),
						ModAnimation.AaOpacity(this.LabRamTotal, -this.LabRamTotal.Opacity, 100, 0, null, false),
						ModAnimation.AaOpacity(this.LabRamUsedTitle, -this.LabRamUsedTitle.Opacity, 100, 0, null, false)
					}, "VersionSetup Ram TextLeft", false);
					break;
				case 1:
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaOpacity(this.LabRamUsed, 1.0 - this.LabRamUsed.Opacity, 100, 0, null, false),
						ModAnimation.AaOpacity(this.LabRamTotal, -this.LabRamTotal.Opacity, 100, 0, null, false),
						ModAnimation.AaOpacity(this.LabRamUsedTitle, 0.7 - this.LabRamUsedTitle.Opacity, 100, 0, null, false)
					}, "VersionSetup Ram TextLeft", false);
					break;
				case 2:
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaOpacity(this.LabRamUsed, 1.0 - this.LabRamUsed.Opacity, 100, 0, null, false),
						ModAnimation.AaOpacity(this.LabRamTotal, 1.0 - this.LabRamTotal.Opacity, 100, 0, null, false),
						ModAnimation.AaOpacity(this.LabRamUsedTitle, 0.7 - this.LabRamUsedTitle.Opacity, 100, 0, null, false)
					}, "VersionSetup Ram TextLeft", false);
					break;
				}
			}
			int num2;
			if (actualWidth2 >= actualWidth3 + 2.0 + actualWidth && actualWidth2 >= actualWidth6 + 2.0 + actualWidth)
			{
				num2 = 1;
			}
			else
			{
				num2 = 0;
			}
			if (num2 == 0)
			{
				if (ModAnimation.DefineModel() == 0 && (this.m_CollectionResolver != num2 || ModAnimation.AniIsRun("VersionSetup Ram TextRight")))
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaX(this.LabRamGame, actualWidth2 - actualWidth3 - this.LabRamGame.Margin.Left, 100, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Weak), false),
						ModAnimation.AaX(this.LabRamGameTitle, actualWidth2 - actualWidth6 - this.LabRamGameTitle.Margin.Left, 100, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Weak), false)
					}, "VersionSetup Ram TextRight", false);
				}
				else
				{
					this.LabRamGame.Margin = new Thickness(actualWidth2 - actualWidth3, 3.0, 0.0, 0.0);
					this.LabRamGameTitle.Margin = new Thickness(actualWidth2 - actualWidth6, 0.0, 0.0, 5.0);
				}
			}
			else if (ModAnimation.DefineModel() == 0 && (this.m_CollectionResolver != num2 || ModAnimation.AniIsRun("VersionSetup Ram TextRight")))
			{
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaX(this.LabRamGame, 2.0 + actualWidth - this.LabRamGame.Margin.Left, 100, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Weak), false),
					ModAnimation.AaX(this.LabRamGameTitle, 2.0 + actualWidth - this.LabRamGameTitle.Margin.Left, 100, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Weak), false)
				}, "VersionSetup Ram TextRight", false);
			}
			else
			{
				this.LabRamGame.Margin = new Thickness(2.0 + actualWidth, 3.0, 0.0, 0.0);
				this.LabRamGameTitle.Margin = new Thickness(2.0 + actualWidth, 0.0, 0.0, 5.0);
			}
			this.m_CollectionResolver = num2;
		}

		// Token: 0x060007A9 RID: 1961 RVA: 0x00035AAC File Offset: 0x00033CAC
		public static double GetRam(ModMinecraft.McVersion Version)
		{
			double result;
			if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("VersionRamType", Version), 2, true))
			{
				result = PageSetupLaunch.GetRam(Version, true);
			}
			else
			{
				double num7;
				if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("VersionRamType", Version), 0, true))
				{
					double num = Math.Round(MyWpfExtension.FindModel().Info.AvailablePhysicalMemory / 1024.0 / 1024.0 / 1024.0 * 10.0) / 10.0;
					if (Version != null && !Version._WrapperParameter)
					{
						Version.Load();
					}
					double val;
					double num3;
					double num4;
					double num5;
					if (Version != null && Version.Version.CalculatePrototype())
					{
						DirectoryInfo directoryInfo = new DirectoryInfo(Version.CreateComparator() + "mods\\");
						int num2 = directoryInfo.Exists ? directoryInfo.GetFiles().Length : 0;
						val = 0.4 + (double)num2 / 150.0;
						num3 = 1.5 + (double)num2 / 100.0;
						num4 = 3.0 + (double)num2 / 60.0;
						num5 = 6.0 + (double)num2 / 30.0;
					}
					else if (Version != null && Version.Version.m_PrototypeParameter)
					{
						val = 0.3;
						num3 = 1.5;
						num4 = 3.0;
						num5 = 6.0;
					}
					else
					{
						val = 0.3;
						num3 = 1.5;
						num4 = 2.5;
						num5 = 4.0;
					}
					double num6 = num3;
					num = Math.Max(0.0, num - 0.1);
					num7 += Math.Min(num * 1.0, num6);
					num -= num6 / 1.0 + 0.1;
					if (num >= 0.1)
					{
						num6 = num4 - num3;
						num = Math.Max(0.0, num - 0.1);
						num7 += Math.Min(num * 0.8, num6);
						num -= num6 / 0.8 + 0.1;
						if (num >= 0.1)
						{
							num6 = num5 - num4;
							num = Math.Max(0.0, num - 0.2);
							num7 += Math.Min(num * 0.6, num6);
							num -= num6 / 0.6 + 0.2;
							if (num >= 0.1)
							{
								num6 = num5;
								num = Math.Max(0.0, num - 0.3);
								num7 += Math.Min(num * 0.4, num6);
								num -= num6 / 0.4 + 0.3;
							}
						}
					}
					num7 = Math.Round(Math.Max(num7, val), 1);
				}
				else
				{
					int num8 = Conversions.ToInteger(ModBase._ParamsState.Get("VersionRamCustom", Version));
					if (num8 <= 12)
					{
						num7 = (double)num8 * 0.1 + 0.3;
					}
					else if (num8 <= 25)
					{
						num7 = (double)(checked(num8 - 12)) * 0.5 + 1.5;
					}
					else if (num8 <= 33)
					{
						num7 = (double)(checked((num8 - 25) * 1 + 8));
					}
					else if (num8 <= 41)
					{
						num7 = (double)(checked((num8 - 33) * 2 + 16));
					}
					else
					{
						num7 = (double)(checked((num8 - 41) * 4 + 32));
					}
				}
				if (!ModMinecraft.JavaUse64Bit(PageVersionLeft.m_AlgoResolver))
				{
					num7 = Math.Min(1.0, num7);
				}
				result = num7;
			}
			return result;
		}

		// Token: 0x060007AA RID: 1962 RVA: 0x00035E90 File Offset: 0x00034090
		private void ComboServerLogin_Changed()
		{
			if (ModAnimation.DefineModel() == 0)
			{
				this.ServerLogin(this.ComboServerLogin.SelectedIndex);
				if ((this.ComboServerLogin.SelectedIndex != 3 || Operators.CompareString(this.TextServerNide.ValidateResult, "", true) == 0) && (this.ComboServerLogin.SelectedIndex != 4 || Operators.CompareString(this.TextServerAuthServer.ValidateResult, "", true) == 0) && this.m_ConsumerResolver != this.ComboServerLogin.SelectedIndex)
				{
					this.m_ConsumerResolver = this.ComboServerLogin.SelectedIndex;
					PageVersionSetup.ComboChange(this.ComboServerLogin, null);
				}
			}
		}

		// Token: 0x060007AB RID: 1963 RVA: 0x00035F34 File Offset: 0x00034134
		public void ServerLogin(int Type)
		{
			if (this.LabServerNide != null)
			{
				this.LabServerNide.Visibility = ((Type == 3) ? Visibility.Visible : Visibility.Collapsed);
				this.TextServerNide.Visibility = ((Type == 3) ? Visibility.Visible : Visibility.Collapsed);
				this.PanServerNide.Visibility = ((Type == 3) ? Visibility.Visible : Visibility.Collapsed);
				this.LabServerAuthName.Visibility = ((Type == 4) ? Visibility.Visible : Visibility.Collapsed);
				this.TextServerAuthName.Visibility = ((Type == 4) ? Visibility.Visible : Visibility.Collapsed);
				this.LabServerAuthRegister.Visibility = ((Type == 4) ? Visibility.Visible : Visibility.Collapsed);
				this.TextServerAuthRegister.Visibility = ((Type == 4) ? Visibility.Visible : Visibility.Collapsed);
				this.LabServerAuthServer.Visibility = ((Type == 4) ? Visibility.Visible : Visibility.Collapsed);
				this.TextServerAuthServer.Visibility = ((Type == 4) ? Visibility.Visible : Visibility.Collapsed);
				this.BtnServerAuthLittle.Visibility = ((Type == 4) ? Visibility.Visible : Visibility.Collapsed);
				this.CardServer.TriggerForceResize();
			}
		}

		// Token: 0x060007AC RID: 1964 RVA: 0x000060E2 File Offset: 0x000042E2
		private void BtnServerNideWeb_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://login2.nide8.com:233/server/intro");
		}

		// Token: 0x060007AD RID: 1965 RVA: 0x000060EE File Offset: 0x000042EE
		private void BtnServerNideBbs_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://www.mcbbs.net/thread-729821-1-1.html");
		}

		// Token: 0x060007AE RID: 1966 RVA: 0x000060FA File Offset: 0x000042FA
		private void BtnServerAuthLittle_Click(object sender, EventArgs e)
		{
			this.TextServerAuthServer.Text = "https://littleskin.cn/api/yggdrasil";
			this.TextServerAuthRegister.Text = "https://littleskin.cn/auth/register";
			this.TextServerAuthName.Text = "Little Skin 登录";
		}

		// Token: 0x060007AF RID: 1967 RVA: 0x00036018 File Offset: 0x00034218
		public void RefreshJavaComboBox()
		{
			if (this.ComboArgumentJava != null)
			{
				this.ComboArgumentJava.Items.Clear();
				this.ComboArgumentJava.Items.Add(new MyComboBoxItem
				{
					Content = "使用全局设置",
					Tag = "使用全局设置"
				});
				this.ComboArgumentJava.Items.Add(new MyComboBoxItem
				{
					Content = "自动选择适合所选游戏版本的 Java",
					Tag = "自动选择"
				});
				MyComboBoxItem myComboBoxItem = null;
				string text = Conversions.ToString(ModBase._ParamsState.Get("VersionArgumentJavaSelect", PageVersionLeft.m_AlgoResolver));
				try
				{
					try
					{
						foreach (ModMinecraft.JavaEntry javaEntry in ModMinecraft._RegTag)
						{
							MyComboBoxItem myComboBoxItem2 = new MyComboBoxItem
							{
								Content = javaEntry.ToString(),
								ToolTip = javaEntry.m_ListProccesor,
								Tag = javaEntry
							};
							ToolTipService.SetPlacement(myComboBoxItem2, PlacementMode.Right);
							ToolTipService.SetHorizontalOffset(myComboBoxItem2, 5.0);
							this.ComboArgumentJava.Items.Add(myComboBoxItem2);
							if (Operators.CompareString(text, "", true) != 0 && Operators.CompareString(text, "使用全局设置", true) != 0 && Operators.CompareString(ModMinecraft.JavaEntry.FromJson((JObject)ModBase.GetJson(text)).m_ListProccesor, javaEntry.m_ListProccesor, true) == 0)
							{
								myComboBoxItem = myComboBoxItem2;
							}
						}
					}
					finally
					{
						List<ModMinecraft.JavaEntry>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
				}
				catch (Exception ex)
				{
					ModBase._ParamsState.Set("VersionArgumentJavaSelect", "使用全局设置", false, PageVersionLeft.m_AlgoResolver);
					ModBase.Log(ex, "更新版本设置 Java 下拉框失败", ModBase.LogLevel.Feedback, "出现错误");
				}
				if (myComboBoxItem == null && ModMinecraft._RegTag.Count > 0)
				{
					if (Operators.CompareString(text, "", true) == 0)
					{
						myComboBoxItem = (MyComboBoxItem)this.ComboArgumentJava.Items[1];
					}
					else
					{
						myComboBoxItem = (MyComboBoxItem)this.ComboArgumentJava.Items[0];
					}
				}
				this.ComboArgumentJava.SelectedItem = myComboBoxItem;
				if (myComboBoxItem == null)
				{
					this.ComboArgumentJava.Items.Clear();
					this.ComboArgumentJava.Items.Add(new ComboBoxItem
					{
						Content = "未找到可用的 Java",
						IsSelected = true
					});
				}
				this.RefreshRam(true);
			}
		}

		// Token: 0x060007B0 RID: 1968 RVA: 0x00036270 File Offset: 0x00034470
		private void ComboArgumentJava_DropDownOpened(object sender, EventArgs e)
		{
			if (this.ComboArgumentJava.SelectedItem == null || Operators.ConditionalCompareObjectEqual(NewLateBinding.LateGet(this.ComboArgumentJava.Items[0], null, "Content", new object[0], null, null, null), "未找到可用的 Java", true) || Operators.ConditionalCompareObjectEqual(NewLateBinding.LateGet(this.ComboArgumentJava.Items[0], null, "Content", new object[0], null, null, null), "加载中……", true))
			{
				this.ComboArgumentJava.IsDropDownOpen = false;
			}
		}

		// Token: 0x060007B1 RID: 1969 RVA: 0x000362FC File Offset: 0x000344FC
		private void JavaSelectionUpdate()
		{
			if (ModAnimation.DefineModel() == 0 && this.ComboArgumentJava.SelectedItem != null && NewLateBinding.LateGet(this.ComboArgumentJava.SelectedItem, null, "Tag", new object[0], null, null, null) != null)
			{
				object objectValue = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(this.ComboArgumentJava.SelectedItem, null, "Tag", new object[0], null, null, null));
				if ("使用全局设置".Equals(RuntimeHelpers.GetObjectValue(objectValue)))
				{
					ModBase._ParamsState.Set("VersionArgumentJavaSelect", "使用全局设置", false, PageVersionLeft.m_AlgoResolver);
					ModBase.Log("[Java] 修改版本 Java 选择设置：使用全局设置", ModBase.LogLevel.Normal, "出现错误");
				}
				else if ("自动选择".Equals(RuntimeHelpers.GetObjectValue(objectValue)))
				{
					ModBase._ParamsState.Set("VersionArgumentJavaSelect", "", false, PageVersionLeft.m_AlgoResolver);
					ModBase.Log("[Java] 修改版本 Java 选择设置：自动选择", ModBase.LogLevel.Normal, "出现错误");
				}
				else
				{
					ModBase._ParamsState.Set("VersionArgumentJavaSelect", ((JObject)NewLateBinding.LateGet(objectValue, null, "ToJson", new object[0], null, null, null)).ToString(0, new JsonConverter[0]), false, PageVersionLeft.m_AlgoResolver);
					ModBase.Log("[Java] 修改版本 Java 选择设置：" + objectValue.ToString(), ModBase.LogLevel.Normal, "出现错误");
				}
				this.RefreshRam(true);
			}
		}

		// Token: 0x17000122 RID: 290
		// (get) Token: 0x060007B2 RID: 1970 RVA: 0x0000612C File Offset: 0x0000432C
		// (set) Token: 0x060007B3 RID: 1971 RVA: 0x00006134 File Offset: 0x00004334
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x17000123 RID: 291
		// (get) Token: 0x060007B4 RID: 1972 RVA: 0x0000613D File Offset: 0x0000433D
		// (set) Token: 0x060007B5 RID: 1973 RVA: 0x00006145 File Offset: 0x00004345
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x17000124 RID: 292
		// (get) Token: 0x060007B6 RID: 1974 RVA: 0x0000614E File Offset: 0x0000434E
		// (set) Token: 0x060007B7 RID: 1975 RVA: 0x00006156 File Offset: 0x00004356
		internal virtual MyCard CardArgument { get; set; }

		// Token: 0x17000125 RID: 293
		// (get) Token: 0x060007B8 RID: 1976 RVA: 0x0000615F File Offset: 0x0000435F
		// (set) Token: 0x060007B9 RID: 1977 RVA: 0x00036448 File Offset: 0x00034648
		internal virtual MyTextBox TextArgumentTitle
		{
			[CompilerGenerated]
			get
			{
				return this.pageResolver;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageVersionSetup._Closure$__.$IR39-2 == null) ? (PageVersionSetup._Closure$__.$IR39-2 = delegate(object sender, RoutedEventArgs e)
				{
					PageVersionSetup.TextBoxChange((MyTextBox)sender, e);
				}) : PageVersionSetup._Closure$__.$IR39-2;
				MyTextBox myTextBox = this.pageResolver;
				if (myTextBox != null)
				{
					myTextBox.FindRepository(value2);
				}
				this.pageResolver = value;
				myTextBox = this.pageResolver;
				if (myTextBox != null)
				{
					myTextBox.SetupRepository(value2);
				}
			}
		}

		// Token: 0x17000126 RID: 294
		// (get) Token: 0x060007BA RID: 1978 RVA: 0x00006167 File Offset: 0x00004367
		// (set) Token: 0x060007BB RID: 1979 RVA: 0x000364A4 File Offset: 0x000346A4
		internal virtual MyTextBox TextArgumentInfo
		{
			[CompilerGenerated]
			get
			{
				return this._PrinterResolver;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageVersionSetup._Closure$__.$IR43-3 == null) ? (PageVersionSetup._Closure$__.$IR43-3 = delegate(object sender, RoutedEventArgs e)
				{
					PageVersionSetup.TextBoxChange((MyTextBox)sender, e);
				}) : PageVersionSetup._Closure$__.$IR43-3;
				MyTextBox printerResolver = this._PrinterResolver;
				if (printerResolver != null)
				{
					printerResolver.FindRepository(value2);
				}
				this._PrinterResolver = value;
				printerResolver = this._PrinterResolver;
				if (printerResolver != null)
				{
					printerResolver.SetupRepository(value2);
				}
			}
		}

		// Token: 0x17000127 RID: 295
		// (get) Token: 0x060007BC RID: 1980 RVA: 0x0000616F File Offset: 0x0000436F
		// (set) Token: 0x060007BD RID: 1981 RVA: 0x00036500 File Offset: 0x00034700
		internal virtual MyTextBox TextAdvanceJvm
		{
			[CompilerGenerated]
			get
			{
				return this._TokenResolver;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageVersionSetup._Closure$__.$IR47-4 == null) ? (PageVersionSetup._Closure$__.$IR47-4 = delegate(object sender, RoutedEventArgs e)
				{
					PageVersionSetup.TextBoxChange((MyTextBox)sender, e);
				}) : PageVersionSetup._Closure$__.$IR47-4;
				MyTextBox tokenResolver = this._TokenResolver;
				if (tokenResolver != null)
				{
					tokenResolver.FindRepository(value2);
				}
				this._TokenResolver = value;
				tokenResolver = this._TokenResolver;
				if (tokenResolver != null)
				{
					tokenResolver.SetupRepository(value2);
				}
			}
		}

		// Token: 0x17000128 RID: 296
		// (get) Token: 0x060007BE RID: 1982 RVA: 0x00006177 File Offset: 0x00004377
		// (set) Token: 0x060007BF RID: 1983 RVA: 0x0003655C File Offset: 0x0003475C
		internal virtual MyTextBox TextAdvanceGame
		{
			[CompilerGenerated]
			get
			{
				return this._InterpreterResolver;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageVersionSetup._Closure$__.$IR51-5 == null) ? (PageVersionSetup._Closure$__.$IR51-5 = delegate(object sender, RoutedEventArgs e)
				{
					PageVersionSetup.TextBoxChange((MyTextBox)sender, e);
				}) : PageVersionSetup._Closure$__.$IR51-5;
				MyTextBox interpreterResolver = this._InterpreterResolver;
				if (interpreterResolver != null)
				{
					interpreterResolver.FindRepository(value2);
				}
				this._InterpreterResolver = value;
				interpreterResolver = this._InterpreterResolver;
				if (interpreterResolver != null)
				{
					interpreterResolver.SetupRepository(value2);
				}
			}
		}

		// Token: 0x17000129 RID: 297
		// (get) Token: 0x060007C0 RID: 1984 RVA: 0x0000617F File Offset: 0x0000437F
		// (set) Token: 0x060007C1 RID: 1985 RVA: 0x000365B8 File Offset: 0x000347B8
		internal virtual MyComboBox ComboArgumentIndie
		{
			[CompilerGenerated]
			get
			{
				return this.m_ParserResolver;
			}
			[CompilerGenerated]
			set
			{
				SelectionChangedEventHandler value2 = (PageVersionSetup._Closure$__.$IR55-6 == null) ? (PageVersionSetup._Closure$__.$IR55-6 = delegate(object sender, SelectionChangedEventArgs e)
				{
					PageVersionSetup.ComboChange((MyComboBox)sender, e);
				}) : PageVersionSetup._Closure$__.$IR55-6;
				MyComboBox parserResolver = this.m_ParserResolver;
				if (parserResolver != null)
				{
					parserResolver.SelectionChanged -= value2;
				}
				this.m_ParserResolver = value;
				parserResolver = this.m_ParserResolver;
				if (parserResolver != null)
				{
					parserResolver.SelectionChanged += value2;
				}
			}
		}

		// Token: 0x1700012A RID: 298
		// (get) Token: 0x060007C2 RID: 1986 RVA: 0x00006187 File Offset: 0x00004387
		// (set) Token: 0x060007C3 RID: 1987 RVA: 0x00036614 File Offset: 0x00034814
		internal virtual MyComboBox ComboAdvanceAssets
		{
			[CompilerGenerated]
			get
			{
				return this.stubResolver;
			}
			[CompilerGenerated]
			set
			{
				SelectionChangedEventHandler value2 = (PageVersionSetup._Closure$__.$IR59-7 == null) ? (PageVersionSetup._Closure$__.$IR59-7 = delegate(object sender, SelectionChangedEventArgs e)
				{
					PageVersionSetup.ComboChange((MyComboBox)sender, e);
				}) : PageVersionSetup._Closure$__.$IR59-7;
				MyComboBox myComboBox = this.stubResolver;
				if (myComboBox != null)
				{
					myComboBox.SelectionChanged -= value2;
				}
				this.stubResolver = value;
				myComboBox = this.stubResolver;
				if (myComboBox != null)
				{
					myComboBox.SelectionChanged += value2;
				}
			}
		}

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x060007C4 RID: 1988 RVA: 0x0000618F File Offset: 0x0000438F
		// (set) Token: 0x060007C5 RID: 1989 RVA: 0x00036670 File Offset: 0x00034870
		internal virtual MyComboBox ComboArgumentJava
		{
			[CompilerGenerated]
			get
			{
				return this.m_ErrorResolver;
			}
			[CompilerGenerated]
			set
			{
				EventHandler value2 = new EventHandler(this.ComboArgumentJava_DropDownOpened);
				SelectionChangedEventHandler value3 = delegate(object sender, SelectionChangedEventArgs e)
				{
					this.JavaSelectionUpdate();
				};
				MyComboBox errorResolver = this.m_ErrorResolver;
				if (errorResolver != null)
				{
					errorResolver.DropDownOpened -= value2;
					errorResolver.SelectionChanged -= value3;
				}
				this.m_ErrorResolver = value;
				errorResolver = this.m_ErrorResolver;
				if (errorResolver != null)
				{
					errorResolver.DropDownOpened += value2;
					errorResolver.SelectionChanged += value3;
				}
			}
		}

		// Token: 0x1700012C RID: 300
		// (get) Token: 0x060007C6 RID: 1990 RVA: 0x00006197 File Offset: 0x00004397
		// (set) Token: 0x060007C7 RID: 1991 RVA: 0x0000619F File Offset: 0x0000439F
		internal virtual MyHint LabRamWarn { get; set; }

		// Token: 0x1700012D RID: 301
		// (get) Token: 0x060007C8 RID: 1992 RVA: 0x000061A8 File Offset: 0x000043A8
		// (set) Token: 0x060007C9 RID: 1993 RVA: 0x000366D0 File Offset: 0x000348D0
		internal virtual MyRadioBox RadioRamType2
		{
			[CompilerGenerated]
			get
			{
				return this._TestsResolver;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageVersionSetup._Closure$__.$IR71-9 == null) ? (PageVersionSetup._Closure$__.$IR71-9 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageVersionSetup.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageVersionSetup._Closure$__.$IR71-9;
				IMyRadio.CheckEventHandler value3 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.RefreshRam();
				};
				MyRadioBox testsResolver = this._TestsResolver;
				if (testsResolver != null)
				{
					testsResolver.Check -= value2;
					testsResolver.Check -= value3;
				}
				this._TestsResolver = value;
				testsResolver = this._TestsResolver;
				if (testsResolver != null)
				{
					testsResolver.Check += value2;
					testsResolver.Check += value3;
				}
			}
		}

		// Token: 0x1700012E RID: 302
		// (get) Token: 0x060007CA RID: 1994 RVA: 0x000061B0 File Offset: 0x000043B0
		// (set) Token: 0x060007CB RID: 1995 RVA: 0x00036748 File Offset: 0x00034948
		internal virtual MyRadioBox RadioRamType0
		{
			[CompilerGenerated]
			get
			{
				return this._StrategyResolver;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageVersionSetup._Closure$__.$IR75-11 == null) ? (PageVersionSetup._Closure$__.$IR75-11 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageVersionSetup.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageVersionSetup._Closure$__.$IR75-11;
				IMyRadio.CheckEventHandler value3 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.RefreshRam();
				};
				MyRadioBox strategyResolver = this._StrategyResolver;
				if (strategyResolver != null)
				{
					strategyResolver.Check -= value2;
					strategyResolver.Check -= value3;
				}
				this._StrategyResolver = value;
				strategyResolver = this._StrategyResolver;
				if (strategyResolver != null)
				{
					strategyResolver.Check += value2;
					strategyResolver.Check += value3;
				}
			}
		}

		// Token: 0x1700012F RID: 303
		// (get) Token: 0x060007CC RID: 1996 RVA: 0x000061B8 File Offset: 0x000043B8
		// (set) Token: 0x060007CD RID: 1997 RVA: 0x000367C0 File Offset: 0x000349C0
		internal virtual MyRadioBox RadioRamType1
		{
			[CompilerGenerated]
			get
			{
				return this.rulesResolver;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageVersionSetup._Closure$__.$IR79-13 == null) ? (PageVersionSetup._Closure$__.$IR79-13 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageVersionSetup.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageVersionSetup._Closure$__.$IR79-13;
				IMyRadio.CheckEventHandler value3 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.RefreshRam();
				};
				MyRadioBox myRadioBox = this.rulesResolver;
				if (myRadioBox != null)
				{
					myRadioBox.Check -= value2;
					myRadioBox.Check -= value3;
				}
				this.rulesResolver = value;
				myRadioBox = this.rulesResolver;
				if (myRadioBox != null)
				{
					myRadioBox.Check += value2;
					myRadioBox.Check += value3;
				}
			}
		}

		// Token: 0x17000130 RID: 304
		// (get) Token: 0x060007CE RID: 1998 RVA: 0x000061C0 File Offset: 0x000043C0
		// (set) Token: 0x060007CF RID: 1999 RVA: 0x00036838 File Offset: 0x00034A38
		internal virtual MySlider SliderRamCustom
		{
			[CompilerGenerated]
			get
			{
				return this._WorkerResolver;
			}
			[CompilerGenerated]
			set
			{
				MySlider.ChangeEventHandler obj = (PageVersionSetup._Closure$__.$IR83-15 == null) ? (PageVersionSetup._Closure$__.$IR83-15 = delegate(object a0, bool a1)
				{
					PageVersionSetup.SliderChange((MySlider)a0, a1);
				}) : PageVersionSetup._Closure$__.$IR83-15;
				MySlider.ChangeEventHandler obj2 = delegate(object a0, bool a1)
				{
					this.RefreshRam();
				};
				MySlider workerResolver = this._WorkerResolver;
				if (workerResolver != null)
				{
					workerResolver.ViewTag(obj);
					workerResolver.ViewTag(obj2);
				}
				this._WorkerResolver = value;
				workerResolver = this._WorkerResolver;
				if (workerResolver != null)
				{
					workerResolver.UpdateTag(obj);
					workerResolver.UpdateTag(obj2);
				}
			}
		}

		// Token: 0x17000131 RID: 305
		// (get) Token: 0x060007D0 RID: 2000 RVA: 0x000061C8 File Offset: 0x000043C8
		// (set) Token: 0x060007D1 RID: 2001 RVA: 0x000061D0 File Offset: 0x000043D0
		internal virtual Grid PanRamDisplay { get; set; }

		// Token: 0x17000132 RID: 306
		// (get) Token: 0x060007D2 RID: 2002 RVA: 0x000061D9 File Offset: 0x000043D9
		// (set) Token: 0x060007D3 RID: 2003 RVA: 0x000061E1 File Offset: 0x000043E1
		internal virtual ColumnDefinition ColumnRamUsed { get; set; }

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x060007D4 RID: 2004 RVA: 0x000061EA File Offset: 0x000043EA
		// (set) Token: 0x060007D5 RID: 2005 RVA: 0x000061F2 File Offset: 0x000043F2
		internal virtual ColumnDefinition ColumnRamGame { get; set; }

		// Token: 0x17000134 RID: 308
		// (get) Token: 0x060007D6 RID: 2006 RVA: 0x000061FB File Offset: 0x000043FB
		// (set) Token: 0x060007D7 RID: 2007 RVA: 0x00006203 File Offset: 0x00004403
		internal virtual ColumnDefinition ColumnRamEmpty { get; set; }

		// Token: 0x17000135 RID: 309
		// (get) Token: 0x060007D8 RID: 2008 RVA: 0x0000620C File Offset: 0x0000440C
		// (set) Token: 0x060007D9 RID: 2009 RVA: 0x00006214 File Offset: 0x00004414
		internal virtual Rectangle RectRamUsed { get; set; }

		// Token: 0x17000136 RID: 310
		// (get) Token: 0x060007DA RID: 2010 RVA: 0x0000621D File Offset: 0x0000441D
		// (set) Token: 0x060007DB RID: 2011 RVA: 0x000368B0 File Offset: 0x00034AB0
		internal virtual Rectangle RectRamGame
		{
			[CompilerGenerated]
			get
			{
				return this.m_MerchantResolver;
			}
			[CompilerGenerated]
			set
			{
				SizeChangedEventHandler value2 = delegate(object sender, SizeChangedEventArgs e)
				{
					this.RefreshRamText();
				};
				Rectangle merchantResolver = this.m_MerchantResolver;
				if (merchantResolver != null)
				{
					merchantResolver.SizeChanged -= value2;
				}
				this.m_MerchantResolver = value;
				merchantResolver = this.m_MerchantResolver;
				if (merchantResolver != null)
				{
					merchantResolver.SizeChanged += value2;
				}
			}
		}

		// Token: 0x17000137 RID: 311
		// (get) Token: 0x060007DC RID: 2012 RVA: 0x00006225 File Offset: 0x00004425
		// (set) Token: 0x060007DD RID: 2013 RVA: 0x000368F4 File Offset: 0x00034AF4
		internal virtual Rectangle RectRamEmpty
		{
			[CompilerGenerated]
			get
			{
				return this.exporterResolver;
			}
			[CompilerGenerated]
			set
			{
				SizeChangedEventHandler value2 = delegate(object sender, SizeChangedEventArgs e)
				{
					this.RefreshRamText();
				};
				Rectangle rectangle = this.exporterResolver;
				if (rectangle != null)
				{
					rectangle.SizeChanged -= value2;
				}
				this.exporterResolver = value;
				rectangle = this.exporterResolver;
				if (rectangle != null)
				{
					rectangle.SizeChanged += value2;
				}
			}
		}

		// Token: 0x17000138 RID: 312
		// (get) Token: 0x060007DE RID: 2014 RVA: 0x0000622D File Offset: 0x0000442D
		// (set) Token: 0x060007DF RID: 2015 RVA: 0x00006235 File Offset: 0x00004435
		internal virtual TextBlock LabRamUsedTitle { get; set; }

		// Token: 0x17000139 RID: 313
		// (get) Token: 0x060007E0 RID: 2016 RVA: 0x0000623E File Offset: 0x0000443E
		// (set) Token: 0x060007E1 RID: 2017 RVA: 0x00006246 File Offset: 0x00004446
		internal virtual TextBlock LabRamGameTitle { get; set; }

		// Token: 0x1700013A RID: 314
		// (get) Token: 0x060007E2 RID: 2018 RVA: 0x0000624F File Offset: 0x0000444F
		// (set) Token: 0x060007E3 RID: 2019 RVA: 0x00006257 File Offset: 0x00004457
		internal virtual TextBlock LabRamUsed { get; set; }

		// Token: 0x1700013B RID: 315
		// (get) Token: 0x060007E4 RID: 2020 RVA: 0x00006260 File Offset: 0x00004460
		// (set) Token: 0x060007E5 RID: 2021 RVA: 0x00006268 File Offset: 0x00004468
		internal virtual TextBlock LabRamTotal { get; set; }

		// Token: 0x1700013C RID: 316
		// (get) Token: 0x060007E6 RID: 2022 RVA: 0x00006271 File Offset: 0x00004471
		// (set) Token: 0x060007E7 RID: 2023 RVA: 0x00036938 File Offset: 0x00034B38
		internal virtual TextBlock LabRamGame
		{
			[CompilerGenerated]
			get
			{
				return this.m_AnnotationResolver;
			}
			[CompilerGenerated]
			set
			{
				SizeChangedEventHandler value2 = delegate(object sender, SizeChangedEventArgs e)
				{
					this.RefreshRamText();
				};
				TextBlock annotationResolver = this.m_AnnotationResolver;
				if (annotationResolver != null)
				{
					annotationResolver.SizeChanged -= value2;
				}
				this.m_AnnotationResolver = value;
				annotationResolver = this.m_AnnotationResolver;
				if (annotationResolver != null)
				{
					annotationResolver.SizeChanged += value2;
				}
			}
		}

		// Token: 0x1700013D RID: 317
		// (get) Token: 0x060007E8 RID: 2024 RVA: 0x00006279 File Offset: 0x00004479
		// (set) Token: 0x060007E9 RID: 2025 RVA: 0x00006281 File Offset: 0x00004481
		internal virtual MyCard CardServer { get; set; }

		// Token: 0x1700013E RID: 318
		// (get) Token: 0x060007EA RID: 2026 RVA: 0x0000628A File Offset: 0x0000448A
		// (set) Token: 0x060007EB RID: 2027 RVA: 0x0003697C File Offset: 0x00034B7C
		internal virtual MyComboBox ComboServerLogin
		{
			[CompilerGenerated]
			get
			{
				return this.refResolver;
			}
			[CompilerGenerated]
			set
			{
				SelectionChangedEventHandler value2 = delegate(object sender, SelectionChangedEventArgs e)
				{
					this.ComboServerLogin_Changed();
				};
				MyComboBox myComboBox = this.refResolver;
				if (myComboBox != null)
				{
					myComboBox.SelectionChanged -= value2;
				}
				this.refResolver = value;
				myComboBox = this.refResolver;
				if (myComboBox != null)
				{
					myComboBox.SelectionChanged += value2;
				}
			}
		}

		// Token: 0x1700013F RID: 319
		// (get) Token: 0x060007EC RID: 2028 RVA: 0x00006292 File Offset: 0x00004492
		// (set) Token: 0x060007ED RID: 2029 RVA: 0x0000629A File Offset: 0x0000449A
		internal virtual TextBlock LabServerNide { get; set; }

		// Token: 0x17000140 RID: 320
		// (get) Token: 0x060007EE RID: 2030 RVA: 0x000062A3 File Offset: 0x000044A3
		// (set) Token: 0x060007EF RID: 2031 RVA: 0x000369C0 File Offset: 0x00034BC0
		internal virtual MyTextBox TextServerNide
		{
			[CompilerGenerated]
			get
			{
				return this._ServiceResolver;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageVersionSetup._Closure$__.$IR147-21 == null) ? (PageVersionSetup._Closure$__.$IR147-21 = delegate(object sender, RoutedEventArgs e)
				{
					PageVersionSetup.TextBoxChange((MyTextBox)sender, e);
				}) : PageVersionSetup._Closure$__.$IR147-21;
				RoutedEventHandler value3 = delegate(object sender, RoutedEventArgs e)
				{
					this.ComboServerLogin_Changed();
				};
				MyTextBox serviceResolver = this._ServiceResolver;
				if (serviceResolver != null)
				{
					serviceResolver.FindRepository(value2);
					serviceResolver.FindRepository(value3);
				}
				this._ServiceResolver = value;
				serviceResolver = this._ServiceResolver;
				if (serviceResolver != null)
				{
					serviceResolver.SetupRepository(value2);
					serviceResolver.SetupRepository(value3);
				}
			}
		}

		// Token: 0x17000141 RID: 321
		// (get) Token: 0x060007F0 RID: 2032 RVA: 0x000062AB File Offset: 0x000044AB
		// (set) Token: 0x060007F1 RID: 2033 RVA: 0x000062B3 File Offset: 0x000044B3
		internal virtual TextBlock LabServerAuthServer { get; set; }

		// Token: 0x17000142 RID: 322
		// (get) Token: 0x060007F2 RID: 2034 RVA: 0x000062BC File Offset: 0x000044BC
		// (set) Token: 0x060007F3 RID: 2035 RVA: 0x00036A38 File Offset: 0x00034C38
		internal virtual MyTextBox TextServerAuthServer
		{
			[CompilerGenerated]
			get
			{
				return this.proxyResolver;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageVersionSetup._Closure$__.$IR155-23 == null) ? (PageVersionSetup._Closure$__.$IR155-23 = delegate(object sender, RoutedEventArgs e)
				{
					PageVersionSetup.TextBoxChange((MyTextBox)sender, e);
				}) : PageVersionSetup._Closure$__.$IR155-23;
				RoutedEventHandler value3 = delegate(object sender, RoutedEventArgs e)
				{
					this.ComboServerLogin_Changed();
				};
				MyTextBox myTextBox = this.proxyResolver;
				if (myTextBox != null)
				{
					myTextBox.FindRepository(value2);
					myTextBox.FindRepository(value3);
				}
				this.proxyResolver = value;
				myTextBox = this.proxyResolver;
				if (myTextBox != null)
				{
					myTextBox.SetupRepository(value2);
					myTextBox.SetupRepository(value3);
				}
			}
		}

		// Token: 0x17000143 RID: 323
		// (get) Token: 0x060007F4 RID: 2036 RVA: 0x000062C4 File Offset: 0x000044C4
		// (set) Token: 0x060007F5 RID: 2037 RVA: 0x000062CC File Offset: 0x000044CC
		internal virtual TextBlock LabServerAuthRegister { get; set; }

		// Token: 0x17000144 RID: 324
		// (get) Token: 0x060007F6 RID: 2038 RVA: 0x000062D5 File Offset: 0x000044D5
		// (set) Token: 0x060007F7 RID: 2039 RVA: 0x00036AB0 File Offset: 0x00034CB0
		internal virtual MyTextBox TextServerAuthRegister
		{
			[CompilerGenerated]
			get
			{
				return this.m_RegistryResolver;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageVersionSetup._Closure$__.$IR163-25 == null) ? (PageVersionSetup._Closure$__.$IR163-25 = delegate(object sender, RoutedEventArgs e)
				{
					PageVersionSetup.TextBoxChange((MyTextBox)sender, e);
				}) : PageVersionSetup._Closure$__.$IR163-25;
				RoutedEventHandler value3 = delegate(object sender, RoutedEventArgs e)
				{
					this.ComboServerLogin_Changed();
				};
				MyTextBox registryResolver = this.m_RegistryResolver;
				if (registryResolver != null)
				{
					registryResolver.FindRepository(value2);
					registryResolver.FindRepository(value3);
				}
				this.m_RegistryResolver = value;
				registryResolver = this.m_RegistryResolver;
				if (registryResolver != null)
				{
					registryResolver.SetupRepository(value2);
					registryResolver.SetupRepository(value3);
				}
			}
		}

		// Token: 0x17000145 RID: 325
		// (get) Token: 0x060007F8 RID: 2040 RVA: 0x000062DD File Offset: 0x000044DD
		// (set) Token: 0x060007F9 RID: 2041 RVA: 0x000062E5 File Offset: 0x000044E5
		internal virtual TextBlock LabServerAuthName { get; set; }

		// Token: 0x17000146 RID: 326
		// (get) Token: 0x060007FA RID: 2042 RVA: 0x000062EE File Offset: 0x000044EE
		// (set) Token: 0x060007FB RID: 2043 RVA: 0x00036B28 File Offset: 0x00034D28
		internal virtual MyTextBox TextServerAuthName
		{
			[CompilerGenerated]
			get
			{
				return this.candidateResolver;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageVersionSetup._Closure$__.$IR171-27 == null) ? (PageVersionSetup._Closure$__.$IR171-27 = delegate(object sender, RoutedEventArgs e)
				{
					PageVersionSetup.TextBoxChange((MyTextBox)sender, e);
				}) : PageVersionSetup._Closure$__.$IR171-27;
				MyTextBox myTextBox = this.candidateResolver;
				if (myTextBox != null)
				{
					myTextBox.FindRepository(value2);
				}
				this.candidateResolver = value;
				myTextBox = this.candidateResolver;
				if (myTextBox != null)
				{
					myTextBox.SetupRepository(value2);
				}
			}
		}

		// Token: 0x17000147 RID: 327
		// (get) Token: 0x060007FC RID: 2044 RVA: 0x000062F6 File Offset: 0x000044F6
		// (set) Token: 0x060007FD RID: 2045 RVA: 0x00036B84 File Offset: 0x00034D84
		internal virtual MyTextBox TextServerEnter
		{
			[CompilerGenerated]
			get
			{
				return this.m_SetterResolver;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageVersionSetup._Closure$__.$IR175-28 == null) ? (PageVersionSetup._Closure$__.$IR175-28 = delegate(object sender, RoutedEventArgs e)
				{
					PageVersionSetup.TextBoxChange((MyTextBox)sender, e);
				}) : PageVersionSetup._Closure$__.$IR175-28;
				MyTextBox setterResolver = this.m_SetterResolver;
				if (setterResolver != null)
				{
					setterResolver.FindRepository(value2);
				}
				this.m_SetterResolver = value;
				setterResolver = this.m_SetterResolver;
				if (setterResolver != null)
				{
					setterResolver.SetupRepository(value2);
				}
			}
		}

		// Token: 0x17000148 RID: 328
		// (get) Token: 0x060007FE RID: 2046 RVA: 0x000062FE File Offset: 0x000044FE
		// (set) Token: 0x060007FF RID: 2047 RVA: 0x00006306 File Offset: 0x00004506
		internal virtual Grid PanServerNide { get; set; }

		// Token: 0x17000149 RID: 329
		// (get) Token: 0x06000800 RID: 2048 RVA: 0x0000630F File Offset: 0x0000450F
		// (set) Token: 0x06000801 RID: 2049 RVA: 0x00036BE0 File Offset: 0x00034DE0
		internal virtual MyButton BtnServerNideWeb
		{
			[CompilerGenerated]
			get
			{
				return this.m_DispatcherResolver;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnServerNideWeb_Click);
				MyButton dispatcherResolver = this.m_DispatcherResolver;
				if (dispatcherResolver != null)
				{
					dispatcherResolver.RevertResolver(obj);
				}
				this.m_DispatcherResolver = value;
				dispatcherResolver = this.m_DispatcherResolver;
				if (dispatcherResolver != null)
				{
					dispatcherResolver.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700014A RID: 330
		// (get) Token: 0x06000802 RID: 2050 RVA: 0x00006317 File Offset: 0x00004517
		// (set) Token: 0x06000803 RID: 2051 RVA: 0x00036C24 File Offset: 0x00034E24
		internal virtual MyButton BtnServerNideBbs
		{
			[CompilerGenerated]
			get
			{
				return this._MessageResolver;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnServerNideBbs_Click);
				MyButton messageResolver = this._MessageResolver;
				if (messageResolver != null)
				{
					messageResolver.RevertResolver(obj);
				}
				this._MessageResolver = value;
				messageResolver = this._MessageResolver;
				if (messageResolver != null)
				{
					messageResolver.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700014B RID: 331
		// (get) Token: 0x06000804 RID: 2052 RVA: 0x0000631F File Offset: 0x0000451F
		// (set) Token: 0x06000805 RID: 2053 RVA: 0x00036C68 File Offset: 0x00034E68
		internal virtual MyButton BtnServerAuthLittle
		{
			[CompilerGenerated]
			get
			{
				return this.statusResolver;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnServerAuthLittle_Click);
				MyButton myButton = this.statusResolver;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.statusResolver = value;
				myButton = this.statusResolver;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x06000806 RID: 2054 RVA: 0x00036CAC File Offset: 0x00034EAC
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_ProcResolver)
			{
				this.m_ProcResolver = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pageversion/pageversionsetup.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000807 RID: 2055 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000808 RID: 2056 RVA: 0x00036CDC File Offset: 0x00034EDC
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			if (connectionId == 3)
			{
				this.CardArgument = (MyCard)target;
				return;
			}
			if (connectionId == 4)
			{
				this.TextArgumentTitle = (MyTextBox)target;
				return;
			}
			if (connectionId == 5)
			{
				this.TextArgumentInfo = (MyTextBox)target;
				return;
			}
			if (connectionId == 6)
			{
				this.TextAdvanceJvm = (MyTextBox)target;
				return;
			}
			if (connectionId == 7)
			{
				this.TextAdvanceGame = (MyTextBox)target;
				return;
			}
			if (connectionId == 8)
			{
				this.ComboArgumentIndie = (MyComboBox)target;
				return;
			}
			if (connectionId == 9)
			{
				this.ComboAdvanceAssets = (MyComboBox)target;
				return;
			}
			if (connectionId == 10)
			{
				this.ComboArgumentJava = (MyComboBox)target;
				return;
			}
			if (connectionId == 11)
			{
				this.LabRamWarn = (MyHint)target;
				return;
			}
			if (connectionId == 12)
			{
				this.RadioRamType2 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 13)
			{
				this.RadioRamType0 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 14)
			{
				this.RadioRamType1 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 15)
			{
				this.SliderRamCustom = (MySlider)target;
				return;
			}
			if (connectionId == 16)
			{
				this.PanRamDisplay = (Grid)target;
				return;
			}
			if (connectionId == 17)
			{
				this.ColumnRamUsed = (ColumnDefinition)target;
				return;
			}
			if (connectionId == 18)
			{
				this.ColumnRamGame = (ColumnDefinition)target;
				return;
			}
			if (connectionId == 19)
			{
				this.ColumnRamEmpty = (ColumnDefinition)target;
				return;
			}
			if (connectionId == 20)
			{
				this.RectRamUsed = (Rectangle)target;
				return;
			}
			if (connectionId == 21)
			{
				this.RectRamGame = (Rectangle)target;
				return;
			}
			if (connectionId == 22)
			{
				this.RectRamEmpty = (Rectangle)target;
				return;
			}
			if (connectionId == 23)
			{
				this.LabRamUsedTitle = (TextBlock)target;
				return;
			}
			if (connectionId == 24)
			{
				this.LabRamGameTitle = (TextBlock)target;
				return;
			}
			if (connectionId == 25)
			{
				this.LabRamUsed = (TextBlock)target;
				return;
			}
			if (connectionId == 26)
			{
				this.LabRamTotal = (TextBlock)target;
				return;
			}
			if (connectionId == 27)
			{
				this.LabRamGame = (TextBlock)target;
				return;
			}
			if (connectionId == 28)
			{
				this.CardServer = (MyCard)target;
				return;
			}
			if (connectionId == 29)
			{
				this.ComboServerLogin = (MyComboBox)target;
				return;
			}
			if (connectionId == 30)
			{
				this.LabServerNide = (TextBlock)target;
				return;
			}
			if (connectionId == 31)
			{
				this.TextServerNide = (MyTextBox)target;
				return;
			}
			if (connectionId == 32)
			{
				this.LabServerAuthServer = (TextBlock)target;
				return;
			}
			if (connectionId == 33)
			{
				this.TextServerAuthServer = (MyTextBox)target;
				return;
			}
			if (connectionId == 34)
			{
				this.LabServerAuthRegister = (TextBlock)target;
				return;
			}
			if (connectionId == 35)
			{
				this.TextServerAuthRegister = (MyTextBox)target;
				return;
			}
			if (connectionId == 36)
			{
				this.LabServerAuthName = (TextBlock)target;
				return;
			}
			if (connectionId == 37)
			{
				this.TextServerAuthName = (MyTextBox)target;
				return;
			}
			if (connectionId == 38)
			{
				this.TextServerEnter = (MyTextBox)target;
				return;
			}
			if (connectionId == 39)
			{
				this.PanServerNide = (Grid)target;
				return;
			}
			if (connectionId == 40)
			{
				this.BtnServerNideWeb = (MyButton)target;
				return;
			}
			if (connectionId == 41)
			{
				this.BtnServerNideBbs = (MyButton)target;
				return;
			}
			if (connectionId == 42)
			{
				this.BtnServerAuthLittle = (MyButton)target;
				return;
			}
			this.m_ProcResolver = true;
		}

		// Token: 0x04000364 RID: 868
		private bool singletonResolver;

		// Token: 0x04000365 RID: 869
		private int _ContextResolver;

		// Token: 0x04000366 RID: 870
		private int m_CollectionResolver;

		// Token: 0x04000367 RID: 871
		private int m_ConsumerResolver;

		// Token: 0x04000368 RID: 872
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyScrollViewer filterResolver;

		// Token: 0x04000369 RID: 873
		[AccessedThroughProperty("PanMain")]
		[CompilerGenerated]
		private StackPanel m_ReaderResolver;

		// Token: 0x0400036A RID: 874
		[AccessedThroughProperty("CardArgument")]
		[CompilerGenerated]
		private MyCard m_FieldResolver;

		// Token: 0x0400036B RID: 875
		[CompilerGenerated]
		[AccessedThroughProperty("TextArgumentTitle")]
		private MyTextBox pageResolver;

		// Token: 0x0400036C RID: 876
		[AccessedThroughProperty("TextArgumentInfo")]
		[CompilerGenerated]
		private MyTextBox _PrinterResolver;

		// Token: 0x0400036D RID: 877
		[AccessedThroughProperty("TextAdvanceJvm")]
		[CompilerGenerated]
		private MyTextBox _TokenResolver;

		// Token: 0x0400036E RID: 878
		[CompilerGenerated]
		[AccessedThroughProperty("TextAdvanceGame")]
		private MyTextBox _InterpreterResolver;

		// Token: 0x0400036F RID: 879
		[CompilerGenerated]
		[AccessedThroughProperty("ComboArgumentIndie")]
		private MyComboBox m_ParserResolver;

		// Token: 0x04000370 RID: 880
		[CompilerGenerated]
		[AccessedThroughProperty("ComboAdvanceAssets")]
		private MyComboBox stubResolver;

		// Token: 0x04000371 RID: 881
		[CompilerGenerated]
		[AccessedThroughProperty("ComboArgumentJava")]
		private MyComboBox m_ErrorResolver;

		// Token: 0x04000372 RID: 882
		[CompilerGenerated]
		[AccessedThroughProperty("LabRamWarn")]
		private MyHint exceptionResolver;

		// Token: 0x04000373 RID: 883
		[CompilerGenerated]
		[AccessedThroughProperty("RadioRamType2")]
		private MyRadioBox _TestsResolver;

		// Token: 0x04000374 RID: 884
		[CompilerGenerated]
		[AccessedThroughProperty("RadioRamType0")]
		private MyRadioBox _StrategyResolver;

		// Token: 0x04000375 RID: 885
		[CompilerGenerated]
		[AccessedThroughProperty("RadioRamType1")]
		private MyRadioBox rulesResolver;

		// Token: 0x04000376 RID: 886
		[CompilerGenerated]
		[AccessedThroughProperty("SliderRamCustom")]
		private MySlider _WorkerResolver;

		// Token: 0x04000377 RID: 887
		[AccessedThroughProperty("PanRamDisplay")]
		[CompilerGenerated]
		private Grid m_DicResolver;

		// Token: 0x04000378 RID: 888
		[CompilerGenerated]
		[AccessedThroughProperty("ColumnRamUsed")]
		private ColumnDefinition _ConfigurationResolver;

		// Token: 0x04000379 RID: 889
		[CompilerGenerated]
		[AccessedThroughProperty("ColumnRamGame")]
		private ColumnDefinition m_ConfigResolver;

		// Token: 0x0400037A RID: 890
		[CompilerGenerated]
		[AccessedThroughProperty("ColumnRamEmpty")]
		private ColumnDefinition _ManagerResolver;

		// Token: 0x0400037B RID: 891
		[AccessedThroughProperty("RectRamUsed")]
		[CompilerGenerated]
		private Rectangle m_RuleResolver;

		// Token: 0x0400037C RID: 892
		[AccessedThroughProperty("RectRamGame")]
		[CompilerGenerated]
		private Rectangle m_MerchantResolver;

		// Token: 0x0400037D RID: 893
		[AccessedThroughProperty("RectRamEmpty")]
		[CompilerGenerated]
		private Rectangle exporterResolver;

		// Token: 0x0400037E RID: 894
		[AccessedThroughProperty("LabRamUsedTitle")]
		[CompilerGenerated]
		private TextBlock _QueueResolver;

		// Token: 0x0400037F RID: 895
		[AccessedThroughProperty("LabRamGameTitle")]
		[CompilerGenerated]
		private TextBlock _GlobalResolver;

		// Token: 0x04000380 RID: 896
		[AccessedThroughProperty("LabRamUsed")]
		[CompilerGenerated]
		private TextBlock m_ListResolver;

		// Token: 0x04000381 RID: 897
		[AccessedThroughProperty("LabRamTotal")]
		[CompilerGenerated]
		private TextBlock _MethodResolver;

		// Token: 0x04000382 RID: 898
		[AccessedThroughProperty("LabRamGame")]
		[CompilerGenerated]
		private TextBlock m_AnnotationResolver;

		// Token: 0x04000383 RID: 899
		[CompilerGenerated]
		[AccessedThroughProperty("CardServer")]
		private MyCard interceptorResolver;

		// Token: 0x04000384 RID: 900
		[AccessedThroughProperty("ComboServerLogin")]
		[CompilerGenerated]
		private MyComboBox refResolver;

		// Token: 0x04000385 RID: 901
		[CompilerGenerated]
		[AccessedThroughProperty("LabServerNide")]
		private TextBlock serverResolver;

		// Token: 0x04000386 RID: 902
		[AccessedThroughProperty("TextServerNide")]
		[CompilerGenerated]
		private MyTextBox _ServiceResolver;

		// Token: 0x04000387 RID: 903
		[CompilerGenerated]
		[AccessedThroughProperty("LabServerAuthServer")]
		private TextBlock importerResolver;

		// Token: 0x04000388 RID: 904
		[AccessedThroughProperty("TextServerAuthServer")]
		[CompilerGenerated]
		private MyTextBox proxyResolver;

		// Token: 0x04000389 RID: 905
		[CompilerGenerated]
		[AccessedThroughProperty("LabServerAuthRegister")]
		private TextBlock _ClassResolver;

		// Token: 0x0400038A RID: 906
		[CompilerGenerated]
		[AccessedThroughProperty("TextServerAuthRegister")]
		private MyTextBox m_RegistryResolver;

		// Token: 0x0400038B RID: 907
		[CompilerGenerated]
		[AccessedThroughProperty("LabServerAuthName")]
		private TextBlock producerResolver;

		// Token: 0x0400038C RID: 908
		[AccessedThroughProperty("TextServerAuthName")]
		[CompilerGenerated]
		private MyTextBox candidateResolver;

		// Token: 0x0400038D RID: 909
		[AccessedThroughProperty("TextServerEnter")]
		[CompilerGenerated]
		private MyTextBox m_SetterResolver;

		// Token: 0x0400038E RID: 910
		[AccessedThroughProperty("PanServerNide")]
		[CompilerGenerated]
		private Grid mappingResolver;

		// Token: 0x0400038F RID: 911
		[AccessedThroughProperty("BtnServerNideWeb")]
		[CompilerGenerated]
		private MyButton m_DispatcherResolver;

		// Token: 0x04000390 RID: 912
		[CompilerGenerated]
		[AccessedThroughProperty("BtnServerNideBbs")]
		private MyButton _MessageResolver;

		// Token: 0x04000391 RID: 913
		[AccessedThroughProperty("BtnServerAuthLittle")]
		[CompilerGenerated]
		private MyButton statusResolver;

		// Token: 0x04000392 RID: 914
		private bool m_ProcResolver;
	}
}
