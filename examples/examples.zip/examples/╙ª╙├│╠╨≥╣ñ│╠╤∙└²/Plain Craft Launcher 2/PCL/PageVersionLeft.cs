﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x020000BB RID: 187
	[DesignerGenerated]
	public class PageVersionLeft : MyPageLeft, IComponentConnector
	{
		// Token: 0x060006FE RID: 1790 RVA: 0x00005B2A File Offset: 0x00003D2A
		public PageVersionLeft()
		{
			base.Loaded += this.PageVersionLeft_Loaded;
			this.poolResolver = FormMain.PageSubType.Default;
			this.InitializeComponent();
		}

		// Token: 0x060006FF RID: 1791 RVA: 0x00031ACC File Offset: 0x0002FCCC
		private void PageVersionLeft_Loaded(object sender, RoutedEventArgs e)
		{
			if (PageVersionLeft.m_AlgoResolver != null && PageVersionLeft.m_AlgoResolver.Version.CalculatePrototype())
			{
				this.ItemMod.Visibility = Visibility.Visible;
				this.ItemModDisabled.Visibility = Visibility.Collapsed;
				return;
			}
			this.ItemMod.Visibility = Visibility.Collapsed;
			this.ItemModDisabled.Visibility = Visibility.Visible;
		}

		// Token: 0x06000700 RID: 1792 RVA: 0x00005B52 File Offset: 0x00003D52
		private void PageCheck(MyListItem sender, ModBase.RouteEventArgs e)
		{
			if (sender.Tag != null)
			{
				this.PageChange(checked((FormMain.PageSubType)Math.Round(ModBase.Val(RuntimeHelpers.GetObjectValue(sender.Tag)))));
			}
		}

		// Token: 0x06000701 RID: 1793 RVA: 0x00031B24 File Offset: 0x0002FD24
		public object PageGet(FormMain.PageSubType ID = (FormMain.PageSubType)(-1))
		{
			if (ID == (FormMain.PageSubType)(-1))
			{
				ID = this.poolResolver;
			}
			object result;
			switch (ID)
			{
			case FormMain.PageSubType.Default:
				if (ModMain.dispatcherAccount == null)
				{
					ModMain.dispatcherAccount = new PageVersionOverall();
				}
				result = ModMain.dispatcherAccount;
				break;
			case FormMain.PageSubType.DownloadInstall:
				if (Information.IsNothing(ModMain._ProcAccount))
				{
					ModMain._ProcAccount = new PageVersionSetup();
				}
				result = ModMain._ProcAccount;
				break;
			case FormMain.PageSubType.SetupSystem:
				if (ModMain.m_MessageAccount == null)
				{
					ModMain.m_MessageAccount = new PageVersionMod();
				}
				result = ModMain.m_MessageAccount;
				break;
			case FormMain.PageSubType.SetupLink:
				if (ModMain.m_StatusAccount == null)
				{
					ModMain.m_StatusAccount = new PageVersionModDisabled();
				}
				result = ModMain.m_StatusAccount;
				break;
			default:
				throw new Exception("未知的版本设置子页面种类：" + Conversions.ToString((int)ID));
			}
			return result;
		}

		// Token: 0x06000702 RID: 1794 RVA: 0x00031BD4 File Offset: 0x0002FDD4
		public void PageChange(FormMain.PageSubType ID)
		{
			checked
			{
				if (this.poolResolver != ID)
				{
					ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
					try
					{
						PageVersionLeft.PageChangeRun((MyPageRight)this.PageGet(ID));
						this.poolResolver = ID;
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "切换设置分页面失败（ID " + Conversions.ToString((int)ID) + "）", ModBase.LogLevel.Feedback, "出现错误");
					}
					finally
					{
						ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
					}
				}
			}
		}

		// Token: 0x06000703 RID: 1795 RVA: 0x00031C68 File Offset: 0x0002FE68
		private static void PageChangeRun(MyPageRight Target)
		{
			if (Target.Parent != null)
			{
				Target.SetValue(ContentPresenter.ContentProperty, null);
			}
			ModMain.m_CollectionAccount.m_RequestAccount = Target;
			((MyPageRight)ModMain.m_CollectionAccount.PanMainRight.Child).PageOnExit();
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaCode((PageVersionLeft._Closure$__.$I7-0 == null) ? (PageVersionLeft._Closure$__.$I7-0 = delegate()
				{
					((MyPageRight)ModMain.m_CollectionAccount.PanMainRight.Child).PageOnForceExit();
					ModMain.m_CollectionAccount.PanMainRight.Child = ModMain.m_CollectionAccount.m_RequestAccount;
					ModMain.m_CollectionAccount.m_RequestAccount.Opacity = 0.0;
				}) : PageVersionLeft._Closure$__.$I7-0, 130, false),
				ModAnimation.AaCode((PageVersionLeft._Closure$__.$I7-1 == null) ? (PageVersionLeft._Closure$__.$I7-1 = delegate()
				{
					ModMain.m_CollectionAccount.m_RequestAccount.Opacity = 1.0;
					ModMain.m_CollectionAccount.m_RequestAccount.PageOnEnter();
				}) : PageVersionLeft._Closure$__.$I7-1, 30, true)
			}, "PageLeft PageChange", false);
		}

		// Token: 0x06000704 RID: 1796 RVA: 0x00005B78 File Offset: 0x00003D78
		public void Refresh(object sender, EventArgs e)
		{
			if (ModMain.m_MessageAccount != null)
			{
				ModMain.m_MessageAccount.RefreshList(true);
			}
		}

		// Token: 0x06000705 RID: 1797 RVA: 0x00031D28 File Offset: 0x0002FF28
		public void Reset(object sender, EventArgs e)
		{
			if (ModMain.MyMsgBox("是否要初始化该版本的版本独立设置？该操作不可撤销。", "初始化确认", "确定", "取消", "", true, true, false) == 1)
			{
				if (Information.IsNothing(ModMain._ProcAccount))
				{
					ModMain._ProcAccount = new PageVersionSetup();
				}
				ModMain._ProcAccount.Reset();
			}
		}

		// Token: 0x170000FB RID: 251
		// (get) Token: 0x06000706 RID: 1798 RVA: 0x00005B8C File Offset: 0x00003D8C
		// (set) Token: 0x06000707 RID: 1799 RVA: 0x00005B94 File Offset: 0x00003D94
		internal virtual StackPanel PanItem { get; set; }

		// Token: 0x170000FC RID: 252
		// (get) Token: 0x06000708 RID: 1800 RVA: 0x00005B9D File Offset: 0x00003D9D
		// (set) Token: 0x06000709 RID: 1801 RVA: 0x00031D7C File Offset: 0x0002FF7C
		internal virtual MyListItem ItemOverall
		{
			[CompilerGenerated]
			get
			{
				return this._WatcherResolver;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem watcherResolver = this._WatcherResolver;
				if (watcherResolver != null)
				{
					watcherResolver.Check -= value2;
				}
				this._WatcherResolver = value;
				watcherResolver = this._WatcherResolver;
				if (watcherResolver != null)
				{
					watcherResolver.Check += value2;
				}
			}
		}

		// Token: 0x170000FD RID: 253
		// (get) Token: 0x0600070A RID: 1802 RVA: 0x00005BA5 File Offset: 0x00003DA5
		// (set) Token: 0x0600070B RID: 1803 RVA: 0x00031DC0 File Offset: 0x0002FFC0
		internal virtual MyListItem ItemSetup
		{
			[CompilerGenerated]
			get
			{
				return this.testResolver;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem myListItem = this.testResolver;
				if (myListItem != null)
				{
					myListItem.Check -= value2;
				}
				this.testResolver = value;
				myListItem = this.testResolver;
				if (myListItem != null)
				{
					myListItem.Check += value2;
				}
			}
		}

		// Token: 0x170000FE RID: 254
		// (get) Token: 0x0600070C RID: 1804 RVA: 0x00005BAD File Offset: 0x00003DAD
		// (set) Token: 0x0600070D RID: 1805 RVA: 0x00031E04 File Offset: 0x00030004
		internal virtual MyListItem ItemMod
		{
			[CompilerGenerated]
			get
			{
				return this.m_TaskResolver;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem taskResolver = this.m_TaskResolver;
				if (taskResolver != null)
				{
					taskResolver.Check -= value2;
				}
				this.m_TaskResolver = value;
				taskResolver = this.m_TaskResolver;
				if (taskResolver != null)
				{
					taskResolver.Check += value2;
				}
			}
		}

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x0600070E RID: 1806 RVA: 0x00005BB5 File Offset: 0x00003DB5
		// (set) Token: 0x0600070F RID: 1807 RVA: 0x00031E48 File Offset: 0x00030048
		internal virtual MyListItem ItemModDisabled
		{
			[CompilerGenerated]
			get
			{
				return this.m_IteratorResolver;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem iteratorResolver = this.m_IteratorResolver;
				if (iteratorResolver != null)
				{
					iteratorResolver.Check -= value2;
				}
				this.m_IteratorResolver = value;
				iteratorResolver = this.m_IteratorResolver;
				if (iteratorResolver != null)
				{
					iteratorResolver.Check += value2;
				}
			}
		}

		// Token: 0x06000710 RID: 1808 RVA: 0x00031E8C File Offset: 0x0003008C
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_SerializerResolver)
			{
				this.m_SerializerResolver = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pageversion/pageversionleft.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000711 RID: 1809 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000712 RID: 1810 RVA: 0x00031EBC File Offset: 0x000300BC
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanItem = (StackPanel)target;
				return;
			}
			if (connectionId == 2)
			{
				this.ItemOverall = (MyListItem)target;
				return;
			}
			if (connectionId == 3)
			{
				this.ItemSetup = (MyListItem)target;
				return;
			}
			if (connectionId == 4)
			{
				this.ItemMod = (MyListItem)target;
				return;
			}
			if (connectionId == 5)
			{
				this.ItemModDisabled = (MyListItem)target;
				return;
			}
			this.m_SerializerResolver = true;
		}

		// Token: 0x04000330 RID: 816
		public static ModMinecraft.McVersion m_AlgoResolver;

		// Token: 0x04000331 RID: 817
		public FormMain.PageSubType poolResolver;

		// Token: 0x04000332 RID: 818
		[CompilerGenerated]
		[AccessedThroughProperty("PanItem")]
		private StackPanel publisherResolver;

		// Token: 0x04000333 RID: 819
		[AccessedThroughProperty("ItemOverall")]
		[CompilerGenerated]
		private MyListItem _WatcherResolver;

		// Token: 0x04000334 RID: 820
		[CompilerGenerated]
		[AccessedThroughProperty("ItemSetup")]
		private MyListItem testResolver;

		// Token: 0x04000335 RID: 821
		[AccessedThroughProperty("ItemMod")]
		[CompilerGenerated]
		private MyListItem m_TaskResolver;

		// Token: 0x04000336 RID: 822
		[AccessedThroughProperty("ItemModDisabled")]
		[CompilerGenerated]
		private MyListItem m_IteratorResolver;

		// Token: 0x04000337 RID: 823
		private bool m_SerializerResolver;
	}
}
