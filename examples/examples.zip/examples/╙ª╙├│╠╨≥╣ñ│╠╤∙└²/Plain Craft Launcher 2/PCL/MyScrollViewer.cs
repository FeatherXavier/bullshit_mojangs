﻿using System;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000058 RID: 88
	public class MyScrollViewer : ScrollViewer
	{
		// Token: 0x06000294 RID: 660 RVA: 0x00017D90 File Offset: 0x00015F90
		public MyScrollViewer()
		{
			base.PreviewMouseWheel += this.MyScrollViewer_PreviewMouseWheel;
			base.ScrollChanged += this.MyScrollViewer_ScrollChanged;
			base.IsVisibleChanged += this.MyScrollViewer_IsVisibleChanged;
			this.DeltaMuity = 1.0;
		}

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x06000295 RID: 661 RVA: 0x00003748 File Offset: 0x00001948
		// (set) Token: 0x06000296 RID: 662 RVA: 0x00003750 File Offset: 0x00001950
		public double DeltaMuity { get; set; }

		// Token: 0x06000297 RID: 663 RVA: 0x00017DEC File Offset: 0x00015FEC
		private void MyScrollViewer_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
		{
			if (e.Delta != 0 && base.ActualHeight != 0.0 && base.ScrollableHeight != 0.0)
			{
				string name = e.Source.GetType().Name;
				if (NewLateBinding.LateGet(base.Content, null, "TemplatedParent", new object[0], null, null, null) != null || (!name.Contains("Combo") && Operators.CompareString(name, "MyTextBox", true) != 0))
				{
					this.PerformVerticalOffsetDelta((double)(checked(0 - e.Delta)));
					e.Handled = true;
				}
			}
		}

		// Token: 0x06000298 RID: 664 RVA: 0x00003759 File Offset: 0x00001959
		public void PerformVerticalOffsetDelta(double Delta)
		{
			ModAnimation.AniStart(ModAnimation.AaDouble(delegate(object a0)
			{
				this._Lambda$__7-0(Conversions.ToDouble(a0));
			}, Delta * this.DeltaMuity, 300, 0, new ModAnimation.AniEaseOutFluent((ModAnimation.AniEasePower)6), false), "", false);
		}

		// Token: 0x06000299 RID: 665 RVA: 0x00017E84 File Offset: 0x00016084
		private void MyScrollViewer_ScrollChanged(object sender, ScrollChangedEventArgs e)
		{
			this._PredicateWrapper = base.VerticalOffset;
			if (ModMain.m_CollectionAccount != null && (e.VerticalChange != 0.0 || e.ViewportHeightChange != 0.0))
			{
				ModMain.m_CollectionAccount.BtnExtraBack.ShowRefresh();
			}
		}

		// Token: 0x0600029A RID: 666 RVA: 0x0000378C File Offset: 0x0000198C
		private void MyScrollViewer_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			ModMain.m_CollectionAccount.BtnExtraBack.ShowRefresh();
		}

		// Token: 0x0400011D RID: 285
		[CompilerGenerated]
		private double m_SpecificationWrapper;

		// Token: 0x0400011E RID: 286
		private double _PredicateWrapper;
	}
}
