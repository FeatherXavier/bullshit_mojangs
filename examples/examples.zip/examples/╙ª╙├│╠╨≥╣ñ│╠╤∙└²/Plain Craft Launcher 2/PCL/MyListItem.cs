﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200016A RID: 362
	[DesignerGenerated]
	public class MyListItem : Grid, IMyRadio, IComponentConnector
	{
		// Token: 0x0600109A RID: 4250 RVA: 0x00072458 File Offset: 0x00070658
		public MyListItem()
		{
			base.SizeChanged += delegate(object sender, SizeChangedEventArgs e)
			{
				this.OnSizeChanged();
			};
			base.PreviewMouseLeftButtonUp += this.Button_MouseUp;
			base.PreviewMouseLeftButtonDown += this.Button_MouseDown;
			base.MouseLeave += new MouseEventHandler(this.Button_MouseLeave);
			base.PreviewMouseLeftButtonUp += new MouseButtonEventHandler(this.Button_MouseLeave);
			base.MouseEnter += new MouseEventHandler(this.RefreshColor);
			base.MouseLeave += new MouseEventHandler(this.RefreshColor);
			base.MouseLeftButtonDown += new MouseButtonEventHandler(this.RefreshColor);
			base.MouseLeftButtonUp += new MouseButtonEventHandler(this.RefreshColor);
			base.Loaded += this.MyListItem_Loaded;
			this.m_MessageIssuer = null;
			this._ModelRequest = null;
			this.wrapperRequest = ModBase.GetUuid();
			this.m_RepositoryRequest = true;
			this.prototypeRequest = "";
			this._IssuerRequest = "";
			this._RequestRequest = 1.0;
			this.UpdateResolver(false);
			this.stateRequest = false;
			this.proccesorRequest = MyListItem.CheckType.None;
			this._ParameterRequest = false;
			this.containerRequest = false;
			this.paramsRequest = true;
			this.InitializeComponent();
		}

		// Token: 0x0600109B RID: 4251 RVA: 0x00072598 File Offset: 0x00070798
		[CompilerGenerated]
		public void WriteResolver(MyListItem.ClickEventHandler obj)
		{
			MyListItem.ClickEventHandler clickEventHandler = this.candidateIssuer;
			MyListItem.ClickEventHandler clickEventHandler2;
			do
			{
				clickEventHandler2 = clickEventHandler;
				MyListItem.ClickEventHandler value = (MyListItem.ClickEventHandler)Delegate.Combine(clickEventHandler2, obj);
				clickEventHandler = Interlocked.CompareExchange<MyListItem.ClickEventHandler>(ref this.candidateIssuer, value, clickEventHandler2);
			}
			while (clickEventHandler != clickEventHandler2);
		}

		// Token: 0x0600109C RID: 4252 RVA: 0x000725D0 File Offset: 0x000707D0
		[CompilerGenerated]
		public void SelectResolver(MyListItem.ClickEventHandler obj)
		{
			MyListItem.ClickEventHandler clickEventHandler = this.candidateIssuer;
			MyListItem.ClickEventHandler clickEventHandler2;
			do
			{
				clickEventHandler2 = clickEventHandler;
				MyListItem.ClickEventHandler value = (MyListItem.ClickEventHandler)Delegate.Remove(clickEventHandler2, obj);
				clickEventHandler = Interlocked.CompareExchange<MyListItem.ClickEventHandler>(ref this.candidateIssuer, value, clickEventHandler2);
			}
			while (clickEventHandler != clickEventHandler2);
		}

		// Token: 0x0600109D RID: 4253 RVA: 0x00072608 File Offset: 0x00070808
		[CompilerGenerated]
		public void ChangeResolver(MyListItem.LogoClickEventHandler obj)
		{
			MyListItem.LogoClickEventHandler logoClickEventHandler = this.setterIssuer;
			MyListItem.LogoClickEventHandler logoClickEventHandler2;
			do
			{
				logoClickEventHandler2 = logoClickEventHandler;
				MyListItem.LogoClickEventHandler value = (MyListItem.LogoClickEventHandler)Delegate.Combine(logoClickEventHandler2, obj);
				logoClickEventHandler = Interlocked.CompareExchange<MyListItem.LogoClickEventHandler>(ref this.setterIssuer, value, logoClickEventHandler2);
			}
			while (logoClickEventHandler != logoClickEventHandler2);
		}

		// Token: 0x0600109E RID: 4254 RVA: 0x00072640 File Offset: 0x00070840
		[CompilerGenerated]
		public void CountResolver(MyListItem.LogoClickEventHandler obj)
		{
			MyListItem.LogoClickEventHandler logoClickEventHandler = this.setterIssuer;
			MyListItem.LogoClickEventHandler logoClickEventHandler2;
			do
			{
				logoClickEventHandler2 = logoClickEventHandler;
				MyListItem.LogoClickEventHandler value = (MyListItem.LogoClickEventHandler)Delegate.Remove(logoClickEventHandler2, obj);
				logoClickEventHandler = Interlocked.CompareExchange<MyListItem.LogoClickEventHandler>(ref this.setterIssuer, value, logoClickEventHandler2);
			}
			while (logoClickEventHandler != logoClickEventHandler2);
		}

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x0600109F RID: 4255 RVA: 0x00072678 File Offset: 0x00070878
		// (remove) Token: 0x060010A0 RID: 4256 RVA: 0x000726B0 File Offset: 0x000708B0
		public event IMyRadio.CheckEventHandler Check
		{
			[CompilerGenerated]
			add
			{
				IMyRadio.CheckEventHandler checkEventHandler = this.mappingIssuer;
				IMyRadio.CheckEventHandler checkEventHandler2;
				do
				{
					checkEventHandler2 = checkEventHandler;
					IMyRadio.CheckEventHandler value2 = (IMyRadio.CheckEventHandler)Delegate.Combine(checkEventHandler2, value);
					checkEventHandler = Interlocked.CompareExchange<IMyRadio.CheckEventHandler>(ref this.mappingIssuer, value2, checkEventHandler2);
				}
				while (checkEventHandler != checkEventHandler2);
			}
			[CompilerGenerated]
			remove
			{
				IMyRadio.CheckEventHandler checkEventHandler = this.mappingIssuer;
				IMyRadio.CheckEventHandler checkEventHandler2;
				do
				{
					checkEventHandler2 = checkEventHandler;
					IMyRadio.CheckEventHandler value2 = (IMyRadio.CheckEventHandler)Delegate.Remove(checkEventHandler2, value);
					checkEventHandler = Interlocked.CompareExchange<IMyRadio.CheckEventHandler>(ref this.mappingIssuer, value2, checkEventHandler2);
				}
				while (checkEventHandler != checkEventHandler2);
			}
		}

		// Token: 0x1400000A RID: 10
		// (add) Token: 0x060010A1 RID: 4257 RVA: 0x000726E8 File Offset: 0x000708E8
		// (remove) Token: 0x060010A2 RID: 4258 RVA: 0x00072720 File Offset: 0x00070920
		public event IMyRadio.ChangedEventHandler Changed
		{
			[CompilerGenerated]
			add
			{
				IMyRadio.ChangedEventHandler changedEventHandler = this.m_DispatcherIssuer;
				IMyRadio.ChangedEventHandler changedEventHandler2;
				do
				{
					changedEventHandler2 = changedEventHandler;
					IMyRadio.ChangedEventHandler value2 = (IMyRadio.ChangedEventHandler)Delegate.Combine(changedEventHandler2, value);
					changedEventHandler = Interlocked.CompareExchange<IMyRadio.ChangedEventHandler>(ref this.m_DispatcherIssuer, value2, changedEventHandler2);
				}
				while (changedEventHandler != changedEventHandler2);
			}
			[CompilerGenerated]
			remove
			{
				IMyRadio.ChangedEventHandler changedEventHandler = this.m_DispatcherIssuer;
				IMyRadio.ChangedEventHandler changedEventHandler2;
				do
				{
					changedEventHandler2 = changedEventHandler;
					IMyRadio.ChangedEventHandler value2 = (IMyRadio.ChangedEventHandler)Delegate.Remove(changedEventHandler2, value);
					changedEventHandler = Interlocked.CompareExchange<IMyRadio.ChangedEventHandler>(ref this.m_DispatcherIssuer, value2, changedEventHandler2);
				}
				while (changedEventHandler != changedEventHandler2);
			}
		}

		// Token: 0x170002D3 RID: 723
		// (get) Token: 0x060010A3 RID: 4259 RVA: 0x00072758 File Offset: 0x00070958
		public Border RectBack
		{
			get
			{
				if (this.m_MessageIssuer == null)
				{
					Border border = new Border
					{
						Name = "RectBack",
						CornerRadius = new CornerRadius((double)(this.IsScaleAnimationEnabled ? 6 : 0)),
						RenderTransform = (this.IsScaleAnimationEnabled ? new ScaleTransform(0.8, 0.8) : null),
						RenderTransformOrigin = new Point(0.5, 0.5),
						BorderThickness = new Thickness(ModBase.smethod_4(1.0)),
						SnapsToDevicePixels = true,
						IsHitTestVisible = false,
						Opacity = 0.0
					};
					border.SetResourceReference(Border.BackgroundProperty, "ColorBrush7");
					border.SetResourceReference(Border.BorderBrushProperty, "ColorBrush6");
					Grid.SetColumnSpan(border, 999);
					Grid.SetRowSpan(border, 999);
					base.Children.Insert(0, border);
					this.m_MessageIssuer = border;
				}
				return this.m_MessageIssuer;
			}
		}

		// Token: 0x170002D4 RID: 724
		// (get) Token: 0x060010A4 RID: 4260 RVA: 0x00072864 File Offset: 0x00070A64
		public TextBlock LabInfo
		{
			get
			{
				if (this._ModelRequest == null)
				{
					TextBlock textBlock = new TextBlock
					{
						Name = "LabInfo",
						SnapsToDevicePixels = false,
						UseLayoutRounding = false,
						HorizontalAlignment = HorizontalAlignment.Left,
						IsHitTestVisible = false,
						TextTrimming = TextTrimming.CharacterEllipsis,
						Visibility = Visibility.Collapsed,
						FontSize = 12.0,
						Margin = new Thickness(4.0, 0.0, 0.0, 0.0),
						Opacity = 0.6
					};
					Grid.SetColumn(textBlock, 3);
					Grid.SetRow(textBlock, 2);
					base.Children.Add(textBlock);
					this._ModelRequest = textBlock;
				}
				return this._ModelRequest;
			}
		}

		// Token: 0x170002D5 RID: 725
		// (get) Token: 0x060010A5 RID: 4261 RVA: 0x00009DB4 File Offset: 0x00007FB4
		// (set) Token: 0x060010A6 RID: 4262 RVA: 0x00009DBC File Offset: 0x00007FBC
		public bool IsScaleAnimationEnabled
		{
			get
			{
				return this.m_RepositoryRequest;
			}
			set
			{
				this.m_RepositoryRequest = value;
				if (this.m_MessageIssuer != null)
				{
					this.RectBack.CornerRadius = new CornerRadius((double)(value ? 6 : 0));
				}
			}
		}

		// Token: 0x170002D6 RID: 726
		// (get) Token: 0x060010A7 RID: 4263 RVA: 0x0007292C File Offset: 0x00070B2C
		// (set) Token: 0x060010A8 RID: 4264 RVA: 0x00009DE5 File Offset: 0x00007FE5
		public int PaddingLeft
		{
			get
			{
				return checked((int)Math.Round(this.ColumnPaddingLeft.Width.Value));
			}
			set
			{
				this.ColumnPaddingLeft.Width = new GridLength((double)value);
			}
		}

		// Token: 0x170002D7 RID: 727
		// (get) Token: 0x060010A9 RID: 4265 RVA: 0x00072954 File Offset: 0x00070B54
		// (set) Token: 0x060010AA RID: 4266 RVA: 0x00009DF9 File Offset: 0x00007FF9
		public int PaddingRight
		{
			get
			{
				return checked((int)Math.Round(this.ColumnPaddingRight.Width.Value));
			}
			set
			{
				this.ColumnPaddingRight.Width = new GridLength((double)value);
			}
		}

		// Token: 0x170002D8 RID: 728
		// (get) Token: 0x060010AB RID: 4267 RVA: 0x00009E0D File Offset: 0x0000800D
		// (set) Token: 0x060010AC RID: 4268 RVA: 0x0007297C File Offset: 0x00070B7C
		public IEnumerable Buttons
		{
			get
			{
				return this.resolverRequest;
			}
			set
			{
				this.resolverRequest = value;
				if (!Information.IsNothing(this._StatusIssuer))
				{
					base.Children.Remove(this._StatusIssuer);
					this._StatusIssuer = null;
				}
				int num = 0;
				checked
				{
					try
					{
						foreach (object obj in value)
						{
							RuntimeHelpers.GetObjectValue(obj);
							num++;
						}
					}
					finally
					{
						IEnumerator enumerator;
						if (enumerator is IDisposable)
						{
							(enumerator as IDisposable).Dispose();
						}
					}
					if (num != 0)
					{
						if (num == 1)
						{
							try
							{
								foreach (object obj2 in value)
								{
									MyIconButton myIconButton = (MyIconButton)obj2;
									if (myIconButton.Height.Equals(double.NaN))
									{
										myIconButton.Height = 23.0;
									}
									if (myIconButton.Width.Equals(double.NaN))
									{
										myIconButton.Width = 23.0;
									}
									MyIconButton myIconButton2 = myIconButton;
									myIconButton2.Opacity = 0.0;
									myIconButton2.Margin = new Thickness(0.0, 0.0, 5.0, 0.0);
									myIconButton2.SnapsToDevicePixels = false;
									myIconButton2.HorizontalAlignment = HorizontalAlignment.Right;
									myIconButton2.VerticalAlignment = VerticalAlignment.Center;
									myIconButton2.SnapsToDevicePixels = false;
									myIconButton2.UseLayoutRounding = false;
									Grid.SetColumn(myIconButton, 4);
									Grid.SetColumnSpan(myIconButton, 4);
									Grid.SetRowSpan(myIconButton, 4);
									base.Children.Add(myIconButton);
									this._StatusIssuer = myIconButton;
								}
								return;
							}
							finally
							{
								IEnumerator enumerator2;
								if (enumerator2 is IDisposable)
								{
									(enumerator2 as IDisposable).Dispose();
								}
							}
						}
						this._StatusIssuer = new StackPanel
						{
							Opacity = 0.0,
							Margin = new Thickness(0.0, 0.0, 5.0, 0.0),
							SnapsToDevicePixels = false,
							Orientation = Orientation.Horizontal,
							HorizontalAlignment = HorizontalAlignment.Right,
							VerticalAlignment = VerticalAlignment.Center,
							UseLayoutRounding = false
						};
						Grid.SetColumn(this._StatusIssuer, 4);
						Grid.SetColumnSpan(this._StatusIssuer, 4);
						Grid.SetRowSpan(this._StatusIssuer, 4);
						try
						{
							foreach (object obj3 in value)
							{
								MyIconButton myIconButton3 = (MyIconButton)obj3;
								if (myIconButton3.Height.Equals(double.NaN))
								{
									myIconButton3.Height = 23.0;
								}
								if (myIconButton3.Width.Equals(double.NaN))
								{
									myIconButton3.Width = 23.0;
								}
								((StackPanel)this._StatusIssuer).Children.Add(myIconButton3);
							}
						}
						finally
						{
							IEnumerator enumerator3;
							if (enumerator3 is IDisposable)
							{
								(enumerator3 as IDisposable).Dispose();
							}
						}
						base.Children.Add(this._StatusIssuer);
					}
				}
			}
		}

		// Token: 0x170002D9 RID: 729
		// (get) Token: 0x060010AD RID: 4269 RVA: 0x00009E15 File Offset: 0x00008015
		// (set) Token: 0x060010AE RID: 4270 RVA: 0x00009E27 File Offset: 0x00008027
		public string Title
		{
			get
			{
				return Conversions.ToString(base.GetValue(MyListItem.tagRequest));
			}
			set
			{
				base.SetValue(MyListItem.tagRequest, value);
			}
		}

		// Token: 0x170002DA RID: 730
		// (get) Token: 0x060010AF RID: 4271 RVA: 0x00009E35 File Offset: 0x00008035
		// (set) Token: 0x060010B0 RID: 4272 RVA: 0x00009E47 File Offset: 0x00008047
		public double FontSize
		{
			get
			{
				return Conversions.ToDouble(base.GetValue(MyListItem.m_ComparatorRequest));
			}
			set
			{
				base.SetValue(MyListItem.m_ComparatorRequest, value);
			}
		}

		// Token: 0x170002DB RID: 731
		// (get) Token: 0x060010B1 RID: 4273 RVA: 0x00009E5A File Offset: 0x0000805A
		// (set) Token: 0x060010B2 RID: 4274 RVA: 0x00072CAC File Offset: 0x00070EAC
		public string Info
		{
			get
			{
				return this.prototypeRequest;
			}
			set
			{
				if (Operators.CompareString(this.prototypeRequest, value, true) != 0)
				{
					value = value.Replace("\r", "").Replace("\n", "");
					this.prototypeRequest = value;
					this.LabInfo.Text = value;
					this.LabInfo.Visibility = ((Operators.CompareString(value, "", true) == 0) ? Visibility.Collapsed : Visibility.Visible);
				}
			}
		}

		// Token: 0x170002DC RID: 732
		// (get) Token: 0x060010B3 RID: 4275 RVA: 0x00009E62 File Offset: 0x00008062
		// (set) Token: 0x060010B4 RID: 4276 RVA: 0x00072D1C File Offset: 0x00070F1C
		public string Logo
		{
			get
			{
				return this._IssuerRequest;
			}
			set
			{
				if (Operators.CompareString(this._IssuerRequest, value, true) != 0)
				{
					this._IssuerRequest = value;
					if (!Information.IsNothing(this.PathLogo))
					{
						base.Children.Remove(this.PathLogo);
					}
					if (Operators.CompareString(this._IssuerRequest, "", true) != 0)
					{
						if (this._IssuerRequest.ToLower().StartsWith("http"))
						{
							this.PathLogo = new Image
							{
								IsHitTestVisible = this.PublishResolver(),
								Source = (ImageSource)new ImageSourceConverter().ConvertFromString(this._IssuerRequest),
								RenderTransformOrigin = new Point(0.5, 0.5),
								RenderTransform = new ScaleTransform
								{
									ScaleX = this.LogoScale,
									ScaleY = this.LogoScale
								},
								SnapsToDevicePixels = true,
								UseLayoutRounding = false
							};
							RenderOptions.SetBitmapScalingMode(this.PathLogo, BitmapScalingMode.LowQuality);
						}
						else if (this._IssuerRequest.ToLower().EndsWith(".png"))
						{
							MyBitmap image = new MyBitmap(this._IssuerRequest);
							this.PathLogo = new Canvas
							{
								IsHitTestVisible = this.PublishResolver(),
								Background = image,
								RenderTransformOrigin = new Point(0.5, 0.5),
								RenderTransform = new ScaleTransform
								{
									ScaleX = this.LogoScale,
									ScaleY = this.LogoScale
								},
								SnapsToDevicePixels = true,
								UseLayoutRounding = false
							};
							this.PathLogo.HorizontalAlignment = HorizontalAlignment.Stretch;
							this.PathLogo.VerticalAlignment = VerticalAlignment.Stretch;
							RenderOptions.SetBitmapScalingMode(this.PathLogo, BitmapScalingMode.HighQuality);
						}
						else
						{
							this.PathLogo = new Path
							{
								IsHitTestVisible = this.PublishResolver(),
								HorizontalAlignment = HorizontalAlignment.Center,
								VerticalAlignment = VerticalAlignment.Center,
								Stretch = Stretch.Uniform,
								Data = (Geometry)new GeometryConverter().ConvertFromString(this._IssuerRequest),
								RenderTransformOrigin = new Point(0.5, 0.5),
								RenderTransform = new ScaleTransform
								{
									ScaleX = this.LogoScale,
									ScaleY = this.LogoScale
								},
								SnapsToDevicePixels = false,
								UseLayoutRounding = false
							};
							this.PathLogo.SetBinding(Shape.FillProperty, new Binding("Foreground")
							{
								Source = this
							});
						}
						Grid.SetColumn(this.PathLogo, 2);
						Grid.SetRowSpan(this.PathLogo, 4);
						this.OnSizeChanged();
						base.Children.Add(this.PathLogo);
						if (this.PublishResolver())
						{
							this.PathLogo.MouseLeave += delegate(object sender, MouseEventArgs e)
							{
								this.stateRequest = false;
							};
							this.PathLogo.MouseLeftButtonDown += delegate(object sender, MouseButtonEventArgs e)
							{
								this.stateRequest = true;
							};
							this.PathLogo.MouseLeftButtonUp += delegate(object sender, MouseButtonEventArgs e)
							{
								if (this.stateRequest)
								{
									this.stateRequest = false;
									MyListItem.LogoClickEventHandler logoClickEventHandler = this.setterIssuer;
									if (logoClickEventHandler != null)
									{
										logoClickEventHandler(RuntimeHelpers.GetObjectValue(sender), e);
									}
								}
							};
						}
					}
					this.ColumnLogo.Width = new GridLength((double)(checked(((Operators.CompareString(this._IssuerRequest, "", true) == 0) ? 0 : 34) + ((base.Height < 40.0) ? 0 : 4))));
				}
			}
		}

		// Token: 0x170002DD RID: 733
		// (get) Token: 0x060010B5 RID: 4277 RVA: 0x00009E6A File Offset: 0x0000806A
		// (set) Token: 0x060010B6 RID: 4278 RVA: 0x00009E72 File Offset: 0x00008072
		public double LogoScale
		{
			get
			{
				return this._RequestRequest;
			}
			set
			{
				this._RequestRequest = value;
				if (!Information.IsNothing(this.PathLogo))
				{
					this.PathLogo.RenderTransform = new ScaleTransform
					{
						ScaleX = this.LogoScale,
						ScaleY = this.LogoScale
					};
				}
			}
		}

		// Token: 0x060010B7 RID: 4279 RVA: 0x00009EB0 File Offset: 0x000080B0
		[CompilerGenerated]
		public bool PublishResolver()
		{
			return this.accountRequest;
		}

		// Token: 0x060010B8 RID: 4280 RVA: 0x00009EB8 File Offset: 0x000080B8
		[CompilerGenerated]
		public void UpdateResolver(bool AutoPropertyValue)
		{
			this.accountRequest = AutoPropertyValue;
		}

		// Token: 0x170002DE RID: 734
		// (get) Token: 0x060010B9 RID: 4281 RVA: 0x00009EC1 File Offset: 0x000080C1
		// (set) Token: 0x060010BA RID: 4282 RVA: 0x00073054 File Offset: 0x00071254
		public MyListItem.CheckType Type
		{
			get
			{
				return this.proccesorRequest;
			}
			set
			{
				if (this.proccesorRequest != value)
				{
					this.proccesorRequest = value;
					this.ColumnCheck.Width = new GridLength((double)((this.proccesorRequest == MyListItem.CheckType.None || this.proccesorRequest == MyListItem.CheckType.Clickable) ? ((base.Height < 40.0) ? 4 : 2) : 6));
					if (this.proccesorRequest != MyListItem.CheckType.None)
					{
						if (this.proccesorRequest != MyListItem.CheckType.Clickable)
						{
							if (Information.IsNothing(this.procIssuer))
							{
								this.procIssuer = new Border
								{
									Width = 5.0,
									Height = (this.Checked ? double.NaN : 0.0),
									CornerRadius = new CornerRadius(2.0, 2.0, 2.0, 2.0),
									VerticalAlignment = (this.Checked ? VerticalAlignment.Stretch : VerticalAlignment.Center),
									HorizontalAlignment = HorizontalAlignment.Left,
									UseLayoutRounding = false,
									SnapsToDevicePixels = false,
									Margin = (this.Checked ? new Thickness(-1.0, 6.0, 0.0, 6.0) : new Thickness(-1.0, 0.0, 0.0, 0.0))
								};
								this.procIssuer.SetResourceReference(Border.BackgroundProperty, "ColorBrush3");
								Grid.SetRowSpan(this.procIssuer, 4);
								base.Children.Add(this.procIssuer);
								return;
							}
							return;
						}
					}
					if (!Information.IsNothing(this.procIssuer))
					{
						base.Children.Remove(this.procIssuer);
						this.procIssuer = null;
					}
					this.SetChecked(false, false, false);
					return;
				}
			}
		}

		// Token: 0x060010BB RID: 4283 RVA: 0x00073230 File Offset: 0x00071430
		private void OnSizeChanged()
		{
			this.ColumnCheck.Width = new GridLength((double)((this.proccesorRequest == MyListItem.CheckType.None || this.proccesorRequest == MyListItem.CheckType.Clickable) ? ((base.Height < 40.0) ? 4 : 2) : 6));
			this.ColumnLogo.Width = new GridLength((double)(checked(((Operators.CompareString(this._IssuerRequest, "", true) == 0) ? 0 : 34) + ((base.Height < 40.0) ? 0 : 4))));
			if (!Information.IsNothing(this.PathLogo))
			{
				if (this._IssuerRequest.EndsWith(".png"))
				{
					this.PathLogo.Margin = new Thickness(4.0, 5.0, 3.0, 5.0);
				}
				else
				{
					this.PathLogo.Margin = new Thickness((double)((base.Height < 40.0) ? 6 : 8), 8.0, (double)((base.Height < 40.0) ? 4 : 6), 8.0);
				}
			}
			this.LabTitle.Margin = new Thickness(4.0, 0.0, 0.0, (double)((base.Height < 40.0) ? 0 : 2));
		}

		// Token: 0x170002DF RID: 735
		// (get) Token: 0x060010BC RID: 4284 RVA: 0x00009EC9 File Offset: 0x000080C9
		// (set) Token: 0x060010BD RID: 4285 RVA: 0x00009ED1 File Offset: 0x000080D1
		public bool Checked
		{
			get
			{
				return this._ParameterRequest;
			}
			set
			{
				this.SetChecked(value, false, true);
			}
		}

		// Token: 0x060010BE RID: 4286 RVA: 0x000733A0 File Offset: 0x000715A0
		public void SetChecked(bool value, bool user, bool anime)
		{
			try
			{
				ModBase.RouteEventArgs routeEventArgs = new ModBase.RouteEventArgs(user);
				bool parameterRequest = this._ParameterRequest;
				if (this.Type == MyListItem.CheckType.RadioBox)
				{
					if (base.IsInitialized && value != this._ParameterRequest)
					{
						this._ParameterRequest = value;
						IMyRadio.ChangedEventHandler dispatcherIssuer = this.m_DispatcherIssuer;
						if (dispatcherIssuer != null)
						{
							dispatcherIssuer(this, routeEventArgs);
						}
						if (routeEventArgs.proxyParameter)
						{
							this._ParameterRequest = parameterRequest;
							return;
						}
					}
					this._ParameterRequest = value;
				}
				else
				{
					if (value == this._ParameterRequest)
					{
						return;
					}
					this._ParameterRequest = value;
					if (base.IsInitialized)
					{
						IMyRadio.ChangedEventHandler dispatcherIssuer2 = this.m_DispatcherIssuer;
						if (dispatcherIssuer2 != null)
						{
							dispatcherIssuer2(this, routeEventArgs);
						}
						if (routeEventArgs.proxyParameter)
						{
							this._ParameterRequest = parameterRequest;
							return;
						}
					}
				}
				if (value)
				{
					ModBase.RouteEventArgs routeEventArgs2 = new ModBase.RouteEventArgs(user);
					IMyRadio.CheckEventHandler checkEventHandler = this.mappingIssuer;
					if (checkEventHandler != null)
					{
						checkEventHandler(this, routeEventArgs2);
					}
					if (routeEventArgs2.proxyParameter)
					{
						return;
					}
				}
				checked
				{
					if (this.Type == MyListItem.CheckType.RadioBox)
					{
						if (Information.IsNothing(base.Parent))
						{
							return;
						}
						List<MyListItem> list = new List<MyListItem>();
						int num = 0;
						try
						{
							foreach (object obj in ((IEnumerable)NewLateBinding.LateGet(base.Parent, null, "Children", new object[0], null, null, null)))
							{
								object objectValue = RuntimeHelpers.GetObjectValue(obj);
								if (objectValue is MyListItem && ((MyListItem)objectValue).Type == MyListItem.CheckType.RadioBox)
								{
									list.Add((MyListItem)objectValue);
									if (Conversions.ToBoolean(NewLateBinding.LateGet(objectValue, null, "Checked", new object[0], null, null, null)))
									{
										num++;
									}
								}
							}
						}
						finally
						{
							IEnumerator enumerator;
							if (enumerator is IDisposable)
							{
								(enumerator as IDisposable).Dispose();
							}
						}
						int num2 = num;
						if (num2 == 0)
						{
							list[0].Checked = true;
						}
						else if (num2 > 1)
						{
							if (this.Checked)
							{
								try
								{
									foreach (MyListItem myListItem in list)
									{
										if (myListItem.Checked && !myListItem.Equals(this))
										{
											myListItem.Checked = false;
										}
									}
									goto IL_255;
								}
								finally
								{
									List<MyListItem>.Enumerator enumerator2;
									((IDisposable)enumerator2).Dispose();
								}
							}
							bool flag = false;
							try
							{
								foreach (MyListItem myListItem2 in list)
								{
									if (myListItem2.Checked)
									{
										if (flag)
										{
											myListItem2.Checked = false;
										}
										else
										{
											flag = true;
										}
									}
								}
							}
							finally
							{
								List<MyListItem>.Enumerator enumerator3;
								((IDisposable)enumerator3).Dispose();
							}
						}
					}
					IL_255:;
				}
				if (base.IsLoaded && ModAnimation.DefineModel() == 0 && anime)
				{
					List<ModAnimation.AniData> list2 = new List<ModAnimation.AniData>();
					if (this.Checked)
					{
						if (!Information.IsNothing(this.procIssuer))
						{
							double num3 = base.ActualHeight - this.procIssuer.ActualHeight - 12.0;
							list2.Add(ModAnimation.AaHeight(this.procIssuer, num3 * 0.4, 200, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Weak), false));
							list2.Add(ModAnimation.AaHeight(this.procIssuer, num3 * 0.6, 300, 0, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Weak), false));
							list2.Add(ModAnimation.AaOpacity(this.procIssuer, 1.0 - this.procIssuer.Opacity, 30, 0, null, false));
							this.procIssuer.VerticalAlignment = VerticalAlignment.Center;
							this.procIssuer.Margin = new Thickness(-1.0, 0.0, 0.0, 0.0);
						}
						list2.Add(ModAnimation.AaColor(this, MyListItem.authenticationRequest, "ColorBrush3", 200, 0, null, false));
					}
					else
					{
						if (!Information.IsNothing(this.procIssuer))
						{
							list2.Add(ModAnimation.AaHeight(this.procIssuer, -this.procIssuer.ActualHeight, 120, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Weak), false));
							list2.Add(ModAnimation.AaOpacity(this.procIssuer, -this.procIssuer.Opacity, 70, 40, null, false));
							this.procIssuer.VerticalAlignment = VerticalAlignment.Center;
						}
						list2.Add(ModAnimation.AaColor(this, MyListItem.authenticationRequest, "ColorBrush1", 120, 0, null, false));
					}
					ModAnimation.AniStart(list2, "MyListItem Checked " + Conversions.ToString(this.wrapperRequest), false);
				}
				else if (this.Checked)
				{
					if (!Information.IsNothing(this.procIssuer))
					{
						this.procIssuer.Height = double.NaN;
						this.procIssuer.Margin = new Thickness(-1.0, 6.0, 0.0, 6.0);
						this.procIssuer.Opacity = 1.0;
						this.procIssuer.VerticalAlignment = VerticalAlignment.Stretch;
					}
					base.SetResourceReference(MyListItem.authenticationRequest, "ColorBrush3");
				}
				else
				{
					if (!Information.IsNothing(this.procIssuer))
					{
						this.procIssuer.Height = 0.0;
						this.procIssuer.Margin = new Thickness(-1.0, 0.0, 0.0, 0.0);
						this.procIssuer.Opacity = 0.0;
						this.procIssuer.VerticalAlignment = VerticalAlignment.Center;
					}
					base.SetResourceReference(MyListItem.authenticationRequest, "ColorBrush1");
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "设置 Checked 失败", ModBase.LogLevel.Debug, "出现错误");
			}
		}

		// Token: 0x170002E0 RID: 736
		// (get) Token: 0x060010BF RID: 4287 RVA: 0x00009EDC File Offset: 0x000080DC
		// (set) Token: 0x060010C0 RID: 4288 RVA: 0x00009EEE File Offset: 0x000080EE
		public Brush Foreground
		{
			get
			{
				return (Brush)base.GetValue(MyListItem.authenticationRequest);
			}
			set
			{
				base.SetValue(MyListItem.authenticationRequest, value);
			}
		}

		// Token: 0x060010C1 RID: 4289 RVA: 0x00073988 File Offset: 0x00071B88
		private void Button_MouseUp(object sender, MouseButtonEventArgs e)
		{
			if (this.containerRequest)
			{
				MyListItem.ClickEventHandler clickEventHandler = this.candidateIssuer;
				if (clickEventHandler != null)
				{
					clickEventHandler(RuntimeHelpers.GetObjectValue(sender), e);
				}
				if (!e.Handled)
				{
					if (!string.IsNullOrEmpty(this.EventType))
					{
						ModEvent.TryStartEvent(this.EventType, this.EventData);
						e.Handled = true;
					}
					if (!e.Handled)
					{
						switch (this.Type)
						{
						case MyListItem.CheckType.Clickable:
							ModBase.Log("[Control] 按下单击列表项：" + this.Title, ModBase.LogLevel.Normal, "出现错误");
							return;
						case MyListItem.CheckType.RadioBox:
							ModBase.Log("[Control] 按下单选列表项：" + this.Title, ModBase.LogLevel.Normal, "出现错误");
							if (!this.Checked)
							{
								this.SetChecked(true, true, true);
								return;
							}
							break;
						case MyListItem.CheckType.CheckBox:
							ModBase.Log("[Control] 按下复选列表项（" + (!this.Checked).ToString() + "）：" + this.Title, ModBase.LogLevel.Normal, "出现错误");
							this.SetChecked(!this.Checked, true, true);
							break;
						default:
							return;
						}
					}
				}
			}
		}

		// Token: 0x060010C2 RID: 4290 RVA: 0x00009EFC File Offset: 0x000080FC
		private void Button_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (base.IsMouseDirectlyOver && this.Type != MyListItem.CheckType.None)
			{
				this.containerRequest = true;
				if (!Information.IsNothing(this._StatusIssuer))
				{
					this._StatusIssuer.IsHitTestVisible = false;
				}
			}
		}

		// Token: 0x060010C3 RID: 4291 RVA: 0x00009F2E File Offset: 0x0000812E
		private void Button_MouseLeave(object sender, object e)
		{
			this.containerRequest = false;
			if (!Information.IsNothing(this._StatusIssuer))
			{
				this._StatusIssuer.IsHitTestVisible = true;
			}
		}

		// Token: 0x170002E1 RID: 737
		// (get) Token: 0x060010C4 RID: 4292 RVA: 0x00009F50 File Offset: 0x00008150
		// (set) Token: 0x060010C5 RID: 4293 RVA: 0x00009F62 File Offset: 0x00008162
		public string EventType
		{
			get
			{
				return Conversions.ToString(base.GetValue(MyListItem.codeRequest));
			}
			set
			{
				base.SetValue(MyListItem.codeRequest, value);
			}
		}

		// Token: 0x170002E2 RID: 738
		// (get) Token: 0x060010C6 RID: 4294 RVA: 0x00009F70 File Offset: 0x00008170
		// (set) Token: 0x060010C7 RID: 4295 RVA: 0x00009F82 File Offset: 0x00008182
		public string EventData
		{
			get
			{
				return Conversions.ToString(base.GetValue(MyListItem.tokenizerRequest));
			}
			set
			{
				base.SetValue(MyListItem.tokenizerRequest, value);
			}
		}

		// Token: 0x060010C8 RID: 4296 RVA: 0x00073A9C File Offset: 0x00071C9C
		public void RefreshColor(object sender, EventArgs e)
		{
			if (this._ReponseRequest != null)
			{
				this._ReponseRequest((MyListItem)sender, e);
				this._ReponseRequest = null;
			}
			string text;
			int num;
			if (this.containerRequest && (this.Type != MyListItem.CheckType.RadioBox || !this.Checked))
			{
				text = "MouseDown";
				num = 120;
			}
			else if (base.IsMouseOver && this.paramsRequest)
			{
				text = "MouseOver";
				num = 120;
			}
			else
			{
				text = "Idle";
				num = 180;
			}
			if (Operators.CompareString(this.m_DefinitionRequest, text, true) != 0)
			{
				this.m_DefinitionRequest = text;
				if (base.IsLoaded && ModAnimation.DefineModel() == 0)
				{
					List<ModAnimation.AniData> list = new List<ModAnimation.AniData>();
					if (base.IsMouseOver && this.paramsRequest)
					{
						if (this._StatusIssuer != null)
						{
							list.Add(ModAnimation.AaOpacity(this._StatusIssuer, 1.0 - this._StatusIssuer.Opacity, checked((int)Math.Round(unchecked((double)num * 0.7))), checked((int)Math.Round(unchecked((double)num * 0.3))), null, false));
						}
						list.AddRange(new ModAnimation.AniData[]
						{
							ModAnimation.AaColor(this.RectBack, Border.BackgroundProperty, this.containerRequest ? "ColorBrush6" : "ColorBrush9", num, 0, null, false),
							ModAnimation.AaOpacity(this.RectBack, 1.0 - this.RectBack.Opacity, num, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false)
						});
						if (this.IsScaleAnimationEnabled)
						{
							list.Add(ModAnimation.AaScaleTransform(this.RectBack, 1.0 - ((ScaleTransform)this.RectBack.RenderTransform).ScaleX, checked((int)Math.Round(unchecked((double)num * 1.6))), 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false));
							if (this.containerRequest)
							{
								list.Add(ModAnimation.AaScaleTransform(this, 0.98 - ((ScaleTransform)base.RenderTransform).ScaleX, checked((int)Math.Round(unchecked((double)num * 0.9))), 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false));
							}
							else
							{
								list.Add(ModAnimation.AaScaleTransform(this, 1.0 - ((ScaleTransform)base.RenderTransform).ScaleX, checked((int)Math.Round(unchecked((double)num * 1.2))), 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false));
							}
						}
					}
					else
					{
						if (this._StatusIssuer != null)
						{
							list.Add(ModAnimation.AaOpacity(this._StatusIssuer, -this._StatusIssuer.Opacity, checked((int)Math.Round(unchecked((double)num * 0.5))), 0, null, false));
						}
						list.Add(ModAnimation.AaOpacity(this.RectBack, -this.RectBack.Opacity, num, 0, null, false));
						if (this.IsScaleAnimationEnabled)
						{
							list.AddRange(new ModAnimation.AniData[]
							{
								ModAnimation.AaColor(this.RectBack, Border.BackgroundProperty, this.containerRequest ? "ColorBrush6" : "ColorBrush7", num, 0, null, false),
								ModAnimation.AaScaleTransform(this, 1.0 - ((ScaleTransform)base.RenderTransform).ScaleX, checked(num * 3), 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
								ModAnimation.AaScaleTransform(this.RectBack, 0.996 - ((ScaleTransform)this.RectBack.RenderTransform).ScaleX, num, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
								ModAnimation.AaScaleTransform(this.RectBack, -0.246, 1, 0, null, true)
							});
						}
					}
					ModAnimation.AniStart(list, "ListItem Color " + Conversions.ToString(this.wrapperRequest), false);
					return;
				}
				if (base.IsMouseOver && this.paramsRequest)
				{
					if (this._StatusIssuer != null)
					{
						this._StatusIssuer.Opacity = 1.0;
					}
					this.RectBack.Background = ModMain._ItemAccount;
					this.RectBack.Opacity = 1.0;
					this.RectBack.RenderTransform = new ScaleTransform(1.0, 1.0);
					base.RenderTransform = new ScaleTransform(1.0, 1.0);
				}
				else
				{
					if (this._StatusIssuer != null)
					{
						this._StatusIssuer.Opacity = 0.0;
					}
					base.RenderTransform = new ScaleTransform(1.0, 1.0);
					if (this.m_MessageIssuer != null)
					{
						if (this.IsScaleAnimationEnabled)
						{
							this.RectBack.Background = ModMain.m_InvocationAccount;
						}
						this.RectBack.Opacity = 0.0;
						this.RectBack.RenderTransform = new ScaleTransform(0.75, 0.75);
					}
				}
				ModAnimation.AniStop("ListItem Color " + Conversions.ToString(this.wrapperRequest));
			}
		}

		// Token: 0x060010C9 RID: 4297 RVA: 0x00073F9C File Offset: 0x0007219C
		private void MyListItem_Loaded(object sender, RoutedEventArgs e)
		{
			if (this.Checked)
			{
				base.SetResourceReference(MyListItem.authenticationRequest, "ColorBrush3");
			}
			else
			{
				base.SetResourceReference(MyListItem.authenticationRequest, "ColorBrush1");
			}
			if (Operators.CompareString(this.EventType, "打开帮助", true) == 0)
			{
				try
				{
					new ModMain.HelpEntry(ModEvent.GetEventAbsoluteUrls(this.EventData, this.EventType)[0]).SetToListItem(this);
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "设置帮助 MyListItem 失败", ModBase.LogLevel.Msgbox, "出现错误");
				}
			}
		}

		// Token: 0x060010CA RID: 4298 RVA: 0x00009F90 File Offset: 0x00008190
		public override string ToString()
		{
			return this.Title;
		}

		// Token: 0x170002E3 RID: 739
		// (get) Token: 0x060010CB RID: 4299 RVA: 0x00009F98 File Offset: 0x00008198
		// (set) Token: 0x060010CC RID: 4300 RVA: 0x00009FA0 File Offset: 0x000081A0
		internal virtual MyListItem PanBack { get; set; }

		// Token: 0x170002E4 RID: 740
		// (get) Token: 0x060010CD RID: 4301 RVA: 0x00009FA9 File Offset: 0x000081A9
		// (set) Token: 0x060010CE RID: 4302 RVA: 0x00009FB1 File Offset: 0x000081B1
		internal virtual ColumnDefinition ColumnCheck { get; set; }

		// Token: 0x170002E5 RID: 741
		// (get) Token: 0x060010CF RID: 4303 RVA: 0x00009FBA File Offset: 0x000081BA
		// (set) Token: 0x060010D0 RID: 4304 RVA: 0x00009FC2 File Offset: 0x000081C2
		internal virtual ColumnDefinition ColumnPaddingLeft { get; set; }

		// Token: 0x170002E6 RID: 742
		// (get) Token: 0x060010D1 RID: 4305 RVA: 0x00009FCB File Offset: 0x000081CB
		// (set) Token: 0x060010D2 RID: 4306 RVA: 0x00009FD3 File Offset: 0x000081D3
		internal virtual ColumnDefinition ColumnLogo { get; set; }

		// Token: 0x170002E7 RID: 743
		// (get) Token: 0x060010D3 RID: 4307 RVA: 0x00009FDC File Offset: 0x000081DC
		// (set) Token: 0x060010D4 RID: 4308 RVA: 0x00009FE4 File Offset: 0x000081E4
		internal virtual ColumnDefinition ColumnPaddingRight { get; set; }

		// Token: 0x170002E8 RID: 744
		// (get) Token: 0x060010D5 RID: 4309 RVA: 0x00009FED File Offset: 0x000081ED
		// (set) Token: 0x060010D6 RID: 4310 RVA: 0x00009FF5 File Offset: 0x000081F5
		internal virtual TextBlock LabTitle { get; set; }

		// Token: 0x060010D7 RID: 4311 RVA: 0x00074038 File Offset: 0x00072238
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_AttributeRequest)
			{
				this.m_AttributeRequest = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/controls/mylistitem.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x060010D8 RID: 4312 RVA: 0x00074068 File Offset: 0x00072268
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyListItem)target;
				return;
			}
			if (connectionId == 2)
			{
				this.ColumnCheck = (ColumnDefinition)target;
				return;
			}
			if (connectionId == 3)
			{
				this.ColumnPaddingLeft = (ColumnDefinition)target;
				return;
			}
			if (connectionId == 4)
			{
				this.ColumnLogo = (ColumnDefinition)target;
				return;
			}
			if (connectionId == 5)
			{
				this.ColumnPaddingRight = (ColumnDefinition)target;
				return;
			}
			if (connectionId == 6)
			{
				this.LabTitle = (TextBlock)target;
				return;
			}
			this.m_AttributeRequest = true;
		}

		// Token: 0x04000837 RID: 2103
		[CompilerGenerated]
		private MyListItem.ClickEventHandler candidateIssuer;

		// Token: 0x04000838 RID: 2104
		[CompilerGenerated]
		private MyListItem.LogoClickEventHandler setterIssuer;

		// Token: 0x04000839 RID: 2105
		[CompilerGenerated]
		private IMyRadio.CheckEventHandler mappingIssuer;

		// Token: 0x0400083A RID: 2106
		[CompilerGenerated]
		private IMyRadio.ChangedEventHandler m_DispatcherIssuer;

		// Token: 0x0400083B RID: 2107
		private Border m_MessageIssuer;

		// Token: 0x0400083C RID: 2108
		public FrameworkElement _StatusIssuer;

		// Token: 0x0400083D RID: 2109
		public FrameworkElement PathLogo;

		// Token: 0x0400083E RID: 2110
		public Border procIssuer;

		// Token: 0x0400083F RID: 2111
		private TextBlock _ModelRequest;

		// Token: 0x04000840 RID: 2112
		public int wrapperRequest;

		// Token: 0x04000841 RID: 2113
		private bool m_RepositoryRequest;

		// Token: 0x04000842 RID: 2114
		private IEnumerable resolverRequest;

		// Token: 0x04000843 RID: 2115
		public static readonly DependencyProperty tagRequest = DependencyProperty.Register("Title", typeof(string), typeof(MyListItem));

		// Token: 0x04000844 RID: 2116
		public static readonly DependencyProperty m_ComparatorRequest = DependencyProperty.Register("FontSize", typeof(double), typeof(MyListItem), new PropertyMetadata(14.0));

		// Token: 0x04000845 RID: 2117
		private string prototypeRequest;

		// Token: 0x04000846 RID: 2118
		private string _IssuerRequest;

		// Token: 0x04000847 RID: 2119
		private double _RequestRequest;

		// Token: 0x04000848 RID: 2120
		[CompilerGenerated]
		private bool accountRequest;

		// Token: 0x04000849 RID: 2121
		private bool stateRequest;

		// Token: 0x0400084A RID: 2122
		private MyListItem.CheckType proccesorRequest;

		// Token: 0x0400084B RID: 2123
		private bool _ParameterRequest;

		// Token: 0x0400084C RID: 2124
		public static readonly DependencyProperty authenticationRequest = DependencyProperty.Register("Foreground", typeof(Brush), typeof(MyListItem), new PropertyMetadata(ModMain._ListenerAccount));

		// Token: 0x0400084D RID: 2125
		public Action<MyListItem, EventArgs> _ReponseRequest;

		// Token: 0x0400084E RID: 2126
		private bool containerRequest;

		// Token: 0x0400084F RID: 2127
		public static readonly DependencyProperty codeRequest = DependencyProperty.Register("EventType", typeof(string), typeof(MyListItem), new PropertyMetadata(null));

		// Token: 0x04000850 RID: 2128
		public static readonly DependencyProperty tokenizerRequest = DependencyProperty.Register("EventData", typeof(string), typeof(MyListItem), new PropertyMetadata(null));

		// Token: 0x04000851 RID: 2129
		private string m_DefinitionRequest;

		// Token: 0x04000852 RID: 2130
		public bool paramsRequest;

		// Token: 0x04000853 RID: 2131
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyListItem _MockRequest;

		// Token: 0x04000854 RID: 2132
		[AccessedThroughProperty("ColumnCheck")]
		[CompilerGenerated]
		private ColumnDefinition _AdapterRequest;

		// Token: 0x04000855 RID: 2133
		[CompilerGenerated]
		[AccessedThroughProperty("ColumnPaddingLeft")]
		private ColumnDefinition m_InitializerRequest;

		// Token: 0x04000856 RID: 2134
		[AccessedThroughProperty("ColumnLogo")]
		[CompilerGenerated]
		private ColumnDefinition m_SystemRequest;

		// Token: 0x04000857 RID: 2135
		[AccessedThroughProperty("ColumnPaddingRight")]
		[CompilerGenerated]
		private ColumnDefinition m_WriterRequest;

		// Token: 0x04000858 RID: 2136
		[CompilerGenerated]
		[AccessedThroughProperty("LabTitle")]
		private TextBlock _BroadcasterRequest;

		// Token: 0x04000859 RID: 2137
		private bool m_AttributeRequest;

		// Token: 0x0200016B RID: 363
		// (Invoke) Token: 0x060010E0 RID: 4320
		public delegate void ClickEventHandler(object sender, MouseButtonEventArgs e);

		// Token: 0x0200016C RID: 364
		// (Invoke) Token: 0x060010E5 RID: 4325
		public delegate void LogoClickEventHandler(object sender, MouseButtonEventArgs e);

		// Token: 0x0200016D RID: 365
		public enum CheckType
		{
			// Token: 0x0400085B RID: 2139
			None,
			// Token: 0x0400085C RID: 2140
			Clickable,
			// Token: 0x0400085D RID: 2141
			RadioBox,
			// Token: 0x0400085E RID: 2142
			CheckBox
		}
	}
}
