﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200016E RID: 366
	[DesignerGenerated]
	public class MyButton : Border, IComponentConnector
	{
		// Token: 0x060010E8 RID: 4328 RVA: 0x000741F4 File Offset: 0x000723F4
		public MyButton()
		{
			base.MouseEnter += new MouseEventHandler(this.RefreshColor);
			base.MouseLeave += new MouseEventHandler(this.RefreshColor);
			base.Loaded += new RoutedEventHandler(this.RefreshColor);
			base.IsEnabledChanged += delegate(object sender, DependencyPropertyChangedEventArgs e)
			{
				this.RefreshColor(RuntimeHelpers.GetObjectValue(sender), e);
			};
			base.MouseLeftButtonUp += this.Button_MouseUp;
			base.MouseLeftButtonDown += this.Button_MouseDown;
			base.MouseEnter += delegate(object sender, MouseEventArgs e)
			{
				this.Button_MouseEnter();
			};
			base.MouseLeftButtonUp += delegate(object sender, MouseButtonEventArgs e)
			{
				this.Button_MouseUp();
			};
			base.MouseLeave += delegate(object sender, MouseEventArgs e)
			{
				this.Button_MouseLeave();
			};
			this.m_PredicateRequest = ModBase.GetUuid();
			this._InfoRequest = MyButton.ColorState.Normal;
			this.mapRequest = false;
			this.InitializeComponent();
		}

		// Token: 0x060010E9 RID: 4329 RVA: 0x000742CC File Offset: 0x000724CC
		[CompilerGenerated]
		public void PostResolver(MyButton.ClickEventHandler obj)
		{
			MyButton.ClickEventHandler clickEventHandler = this._SpecificationRequest;
			MyButton.ClickEventHandler clickEventHandler2;
			do
			{
				clickEventHandler2 = clickEventHandler;
				MyButton.ClickEventHandler value = (MyButton.ClickEventHandler)Delegate.Combine(clickEventHandler2, obj);
				clickEventHandler = Interlocked.CompareExchange<MyButton.ClickEventHandler>(ref this._SpecificationRequest, value, clickEventHandler2);
			}
			while (clickEventHandler != clickEventHandler2);
		}

		// Token: 0x060010EA RID: 4330 RVA: 0x00074304 File Offset: 0x00072504
		[CompilerGenerated]
		public void RevertResolver(MyButton.ClickEventHandler obj)
		{
			MyButton.ClickEventHandler clickEventHandler = this._SpecificationRequest;
			MyButton.ClickEventHandler clickEventHandler2;
			do
			{
				clickEventHandler2 = clickEventHandler;
				MyButton.ClickEventHandler value = (MyButton.ClickEventHandler)Delegate.Remove(clickEventHandler2, obj);
				clickEventHandler = Interlocked.CompareExchange<MyButton.ClickEventHandler>(ref this._SpecificationRequest, value, clickEventHandler2);
			}
			while (clickEventHandler != clickEventHandler2);
		}

		// Token: 0x170002E9 RID: 745
		// (get) Token: 0x060010EB RID: 4331 RVA: 0x0000A018 File Offset: 0x00008218
		// (set) Token: 0x060010EC RID: 4332 RVA: 0x0000A025 File Offset: 0x00008225
		public string Text
		{
			get
			{
				return this.LabText.Text;
			}
			set
			{
				this.LabText.Text = value;
			}
		}

		// Token: 0x170002EA RID: 746
		// (get) Token: 0x060010ED RID: 4333 RVA: 0x0000A033 File Offset: 0x00008233
		// (set) Token: 0x060010EE RID: 4334 RVA: 0x0000A040 File Offset: 0x00008240
		public Thickness TextPadding
		{
			get
			{
				return this.LabText.Padding;
			}
			set
			{
				this.LabText.Padding = value;
			}
		}

		// Token: 0x170002EB RID: 747
		// (get) Token: 0x060010EF RID: 4335 RVA: 0x0000A04E File Offset: 0x0000824E
		// (set) Token: 0x060010F0 RID: 4336 RVA: 0x0000A056 File Offset: 0x00008256
		public MyButton.ColorState ColorType
		{
			get
			{
				return this._InfoRequest;
			}
			set
			{
				this._InfoRequest = value;
				this.RefreshColor(null, null);
			}
		}

		// Token: 0x170002EC RID: 748
		// (get) Token: 0x060010F1 RID: 4337 RVA: 0x0000A067 File Offset: 0x00008267
		// (set) Token: 0x060010F2 RID: 4338 RVA: 0x0000A074 File Offset: 0x00008274
		public new Thickness Padding
		{
			get
			{
				return this.PanFore.Padding;
			}
			set
			{
				this.PanFore.Padding = value;
			}
		}

		// Token: 0x170002ED RID: 749
		// (get) Token: 0x060010F3 RID: 4339 RVA: 0x0000A082 File Offset: 0x00008282
		// (set) Token: 0x060010F4 RID: 4340 RVA: 0x0000A08F File Offset: 0x0000828F
		public Transform RealRenderTransform
		{
			get
			{
				return this.PanFore.RenderTransform;
			}
			set
			{
				this.PanFore.RenderTransform = value;
			}
		}

		// Token: 0x060010F5 RID: 4341 RVA: 0x0007433C File Offset: 0x0007253C
		private void RefreshColor(object obj = null, object e = null)
		{
			try
			{
				if (base.IsLoaded && ModAnimation.DefineModel() == 0)
				{
					if (base.IsEnabled)
					{
						switch (this.ColorType)
						{
						case MyButton.ColorState.Normal:
							if (base.IsMouseOver)
							{
								ModAnimation.AniStart(new ModAnimation.AniData[]
								{
									ModAnimation.AaColor(this.PanFore, Border.BorderBrushProperty, "ColorBrush3", 100, 0, null, false)
								}, "MyButton Color " + Conversions.ToString(this.m_PredicateRequest), false);
							}
							else
							{
								ModAnimation.AniStart(new ModAnimation.AniData[]
								{
									ModAnimation.AaColor(this.PanFore, Border.BorderBrushProperty, "ColorBrush1", 200, 0, null, false)
								}, "MyButton Color " + Conversions.ToString(this.m_PredicateRequest), false);
							}
							break;
						case MyButton.ColorState.Highlight:
							if (base.IsMouseOver)
							{
								ModAnimation.AniStart(new ModAnimation.AniData[]
								{
									ModAnimation.AaColor(this.PanFore, Border.BorderBrushProperty, "ColorBrush3", 100, 0, null, false)
								}, "MyButton Color " + Conversions.ToString(this.m_PredicateRequest), false);
							}
							else
							{
								ModAnimation.AniStart(new ModAnimation.AniData[]
								{
									ModAnimation.AaColor(this.PanFore, Border.BorderBrushProperty, "ColorBrush2", 200, 0, null, false)
								}, "MyButton Color " + Conversions.ToString(this.m_PredicateRequest), false);
							}
							break;
						case MyButton.ColorState.Red:
							if (base.IsMouseOver)
							{
								ModAnimation.AniStart(new ModAnimation.AniData[]
								{
									ModAnimation.AaColor(this.PanFore, Border.BorderBrushProperty, "ColorBrushRedLight", 100, 0, null, false)
								}, "MyButton Color " + Conversions.ToString(this.m_PredicateRequest), false);
							}
							else
							{
								ModAnimation.AniStart(new ModAnimation.AniData[]
								{
									ModAnimation.AaColor(this.PanFore, Border.BorderBrushProperty, "ColorBrushRedDark", 200, 0, null, false)
								}, "MyButton Color " + Conversions.ToString(this.m_PredicateRequest), false);
							}
							break;
						}
					}
					else
					{
						ModAnimation.AniStart(new ModAnimation.AniData[]
						{
							ModAnimation.AaColor(this.PanFore, Border.BorderBrushProperty, ModMain._ValAccount - this.PanFore.BorderBrush, 200, 0, null, false)
						}, "MyButton Color " + Conversions.ToString(this.m_PredicateRequest), false);
					}
				}
				else
				{
					ModAnimation.AniStop("MyButton Color " + Conversions.ToString(this.m_PredicateRequest));
					if (base.IsEnabled)
					{
						switch (this.ColorType)
						{
						case MyButton.ColorState.Normal:
							if (base.IsMouseOver)
							{
								this.PanFore.SetResourceReference(Border.BorderBrushProperty, "ColorBrush3");
							}
							else
							{
								this.PanFore.SetResourceReference(Border.BorderBrushProperty, "ColorBrush1");
							}
							break;
						case MyButton.ColorState.Highlight:
							if (base.IsMouseOver)
							{
								this.PanFore.SetResourceReference(Border.BorderBrushProperty, "ColorBrush3");
							}
							else
							{
								this.PanFore.SetResourceReference(Border.BorderBrushProperty, "ColorBrush2");
							}
							break;
						case MyButton.ColorState.Red:
							if (base.IsMouseOver)
							{
								this.PanFore.SetResourceReference(Border.BorderBrushProperty, "ColorBrushRedLight");
							}
							else
							{
								this.PanFore.SetResourceReference(Border.BorderBrushProperty, "ColorBrushRedDark");
							}
							break;
						}
					}
					else
					{
						this.PanFore.BorderBrush = ModMain._ValAccount;
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "刷新按钮颜色出错", ModBase.LogLevel.Debug, "出现错误");
			}
		}

		// Token: 0x060010F6 RID: 4342 RVA: 0x000746F0 File Offset: 0x000728F0
		private void Button_MouseUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mapRequest)
			{
				ModBase.Log("[Control] 按下按钮：" + this.Text, ModBase.LogLevel.Normal, "出现错误");
				MyButton.ClickEventHandler specificationRequest = this._SpecificationRequest;
				if (specificationRequest != null)
				{
					specificationRequest(RuntimeHelpers.GetObjectValue(sender), e);
				}
				if (!string.IsNullOrEmpty(Conversions.ToString(base.Tag)) && (base.Tag.ToString().StartsWith("链接-") || base.Tag.ToString().StartsWith("启动-")))
				{
					ModMain.Hint("主页自定义按钮语法已更新，且不再兼容老版本语法，请查看新的自定义示例！", ModMain.HintType.Info, true);
				}
				ModEvent.TryStartEvent(this.EventType, this.EventData);
			}
		}

		// Token: 0x170002EE RID: 750
		// (get) Token: 0x060010F7 RID: 4343 RVA: 0x0000A09D File Offset: 0x0000829D
		// (set) Token: 0x060010F8 RID: 4344 RVA: 0x0000A0AF File Offset: 0x000082AF
		public string EventType
		{
			get
			{
				return Conversions.ToString(base.GetValue(MyButton.propertyRequest));
			}
			set
			{
				base.SetValue(MyButton.propertyRequest, value);
			}
		}

		// Token: 0x170002EF RID: 751
		// (get) Token: 0x060010F9 RID: 4345 RVA: 0x0000A0BD File Offset: 0x000082BD
		// (set) Token: 0x060010FA RID: 4346 RVA: 0x0000A0CF File Offset: 0x000082CF
		public string EventData
		{
			get
			{
				return Conversions.ToString(base.GetValue(MyButton._DescriptorRequest));
			}
			set
			{
				base.SetValue(MyButton._DescriptorRequest, value);
			}
		}

		// Token: 0x060010FB RID: 4347 RVA: 0x00074798 File Offset: 0x00072998
		private void Button_MouseDown(object sender, MouseButtonEventArgs e)
		{
			this.mapRequest = true;
			base.Focus();
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaScaleTransform(this.PanFore, 0.955 - ((ScaleTransform)this.PanFore.RenderTransform).ScaleX, 80, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.ExtraStrong), false),
				ModAnimation.AaScaleTransform(this.PanFore, -0.01, 700, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false)
			}, "MyButton Scale " + Conversions.ToString(this.m_PredicateRequest), false);
		}

		// Token: 0x060010FC RID: 4348 RVA: 0x00074838 File Offset: 0x00072A38
		private void Button_MouseEnter()
		{
			ModAnimation.AniStart(ModAnimation.AaColor(this.PanFore, Border.BackgroundProperty, (this._InfoRequest == MyButton.ColorState.Red) ? "ColorBrushRedBack" : "ColorBrush9", 100, 0, null, false), "MyButton Background " + Conversions.ToString(this.m_PredicateRequest), false);
		}

		// Token: 0x060010FD RID: 4349 RVA: 0x0007488C File Offset: 0x00072A8C
		private void Button_MouseUp()
		{
			if (this.mapRequest)
			{
				this.mapRequest = false;
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaScaleTransform(this.PanFore, 1.0 - ((ScaleTransform)this.PanFore.RenderTransform).ScaleX, 300, 10, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false)
				}, "MyButton Scale " + Conversions.ToString(this.m_PredicateRequest), false);
			}
		}

		// Token: 0x060010FE RID: 4350 RVA: 0x00074908 File Offset: 0x00072B08
		private void Button_MouseLeave()
		{
			ModAnimation.AniStart(ModAnimation.AaColor(this.PanFore, Border.BackgroundProperty, "ColorBrushHalfWhite", 200, 0, null, false), "MyButton Background " + Conversions.ToString(this.m_PredicateRequest), false);
			if (this.mapRequest)
			{
				this.mapRequest = false;
				ModAnimation.AniStart(ModAnimation.AaScaleTransform(this.PanFore, 1.0 - ((ScaleTransform)this.PanFore.RenderTransform).ScaleX, 800, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false), "MyButton Scale " + Conversions.ToString(this.m_PredicateRequest), false);
			}
		}

		// Token: 0x170002F0 RID: 752
		// (get) Token: 0x060010FF RID: 4351 RVA: 0x0000A0DD File Offset: 0x000082DD
		// (set) Token: 0x06001100 RID: 4352 RVA: 0x0000A0E5 File Offset: 0x000082E5
		internal virtual MyButton PanBack { get; set; }

		// Token: 0x170002F1 RID: 753
		// (get) Token: 0x06001101 RID: 4353 RVA: 0x0000A0EE File Offset: 0x000082EE
		// (set) Token: 0x06001102 RID: 4354 RVA: 0x0000A0F6 File Offset: 0x000082F6
		internal virtual Border PanFore { get; set; }

		// Token: 0x170002F2 RID: 754
		// (get) Token: 0x06001103 RID: 4355 RVA: 0x0000A0FF File Offset: 0x000082FF
		// (set) Token: 0x06001104 RID: 4356 RVA: 0x0000A107 File Offset: 0x00008307
		internal virtual TextBlock LabText { get; set; }

		// Token: 0x06001105 RID: 4357 RVA: 0x000749B0 File Offset: 0x00072BB0
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this._PublisherRequest)
			{
				this._PublisherRequest = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/controls/mybutton.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06001106 RID: 4358 RVA: 0x0000A110 File Offset: 0x00008310
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyButton)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanFore = (Border)target;
				return;
			}
			if (connectionId == 3)
			{
				this.LabText = (TextBlock)target;
				return;
			}
			this._PublisherRequest = true;
		}

		// Token: 0x0400085F RID: 2143
		[CompilerGenerated]
		private MyButton.ClickEventHandler _SpecificationRequest;

		// Token: 0x04000860 RID: 2144
		public int m_PredicateRequest;

		// Token: 0x04000861 RID: 2145
		public static readonly DependencyProperty m_ClientRequest = DependencyProperty.Register("Text", typeof(string), typeof(MyButton), new PropertyMetadata(delegate(DependencyObject sender, DependencyPropertyChangedEventArgs e)
		{
			if (!Information.IsNothing(sender))
			{
				((MyButton)sender).LabText.Text = Conversions.ToString(e.NewValue);
			}
		}));

		// Token: 0x04000862 RID: 2146
		private MyButton.ColorState _InfoRequest;

		// Token: 0x04000863 RID: 2147
		public static readonly DependencyProperty _DecoratorRequest = DependencyProperty.Register("Padding", typeof(Thickness), typeof(MyButton), new PropertyMetadata(delegate(DependencyObject a0, DependencyPropertyChangedEventArgs a1)
		{
			((MyButton._Closure$__.$I0-1 == null) ? (MyButton._Closure$__.$I0-1 = delegate(MyButton sender, DependencyPropertyChangedEventArgs e)
			{
				if (sender != null)
				{
					Border panFore = sender.PanFore;
					object newValue = e.NewValue;
					panFore.Padding = ((newValue != null) ? ((Thickness)newValue) : default(Thickness));
				}
			}) : MyButton._Closure$__.$I0-1)((MyButton)a0, a1);
		}));

		// Token: 0x04000864 RID: 2148
		public static readonly DependencyProperty propertyRequest = DependencyProperty.Register("EventType", typeof(string), typeof(MyButton), new PropertyMetadata(null));

		// Token: 0x04000865 RID: 2149
		public static readonly DependencyProperty _DescriptorRequest = DependencyProperty.Register("EventData", typeof(string), typeof(MyButton), new PropertyMetadata(null));

		// Token: 0x04000866 RID: 2150
		private bool mapRequest;

		// Token: 0x04000867 RID: 2151
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyButton eventRequest;

		// Token: 0x04000868 RID: 2152
		[CompilerGenerated]
		[AccessedThroughProperty("PanFore")]
		private Border algoRequest;

		// Token: 0x04000869 RID: 2153
		[CompilerGenerated]
		[AccessedThroughProperty("LabText")]
		private TextBlock _PoolRequest;

		// Token: 0x0400086A RID: 2154
		private bool _PublisherRequest;

		// Token: 0x0200016F RID: 367
		// (Invoke) Token: 0x0600110E RID: 4366
		public delegate void ClickEventHandler(object sender, EventArgs e);

		// Token: 0x02000170 RID: 368
		public enum ColorState
		{
			// Token: 0x0400086C RID: 2156
			Normal,
			// Token: 0x0400086D RID: 2157
			Highlight,
			// Token: 0x0400086E RID: 2158
			Red
		}
	}
}
