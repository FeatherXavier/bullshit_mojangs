﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Windows.Markup;

namespace PCL.XamlGeneratedNamespace
{
	// Token: 0x020001B6 RID: 438
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public sealed class GeneratedInternalTypeHelper : InternalTypeHelper
	{
		// Token: 0x06001418 RID: 5144 RVA: 0x0000B9C1 File Offset: 0x00009BC1
		protected override object CreateInstance(Type type, CultureInfo culture)
		{
			return Activator.CreateInstance(type, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.CreateInstance, null, null, culture);
		}

		// Token: 0x06001419 RID: 5145 RVA: 0x0000B9D1 File Offset: 0x00009BD1
		protected override object GetPropertyValue(PropertyInfo propertyInfo, object target, CultureInfo culture)
		{
			return propertyInfo.GetValue(RuntimeHelpers.GetObjectValue(target), BindingFlags.Default, null, null, culture);
		}

		// Token: 0x0600141A RID: 5146 RVA: 0x0000B9E3 File Offset: 0x00009BE3
		protected override void SetPropertyValue(PropertyInfo propertyInfo, object target, object value, CultureInfo culture)
		{
			propertyInfo.SetValue(RuntimeHelpers.GetObjectValue(target), RuntimeHelpers.GetObjectValue(value), BindingFlags.Default, null, null, culture);
		}

		// Token: 0x0600141B RID: 5147 RVA: 0x00088AA8 File Offset: 0x00086CA8
		protected override Delegate CreateDelegate(Type delegateType, object target, string handler)
		{
			return (Delegate)target.GetType().InvokeMember("_CreateDelegate", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.InvokeMethod, null, RuntimeHelpers.GetObjectValue(target), new object[]
			{
				delegateType,
				handler
			}, null);
		}

		// Token: 0x0600141C RID: 5148 RVA: 0x0000B9FC File Offset: 0x00009BFC
		protected override void AddEventHandler(EventInfo eventInfo, object target, Delegate handler)
		{
			eventInfo.AddEventHandler(RuntimeHelpers.GetObjectValue(target), handler);
		}
	}
}
