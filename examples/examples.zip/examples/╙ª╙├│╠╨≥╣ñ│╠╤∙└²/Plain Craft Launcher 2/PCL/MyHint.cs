﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200004B RID: 75
	[DesignerGenerated]
	public class MyHint : Border, IComponentConnector
	{
		// Token: 0x060001B6 RID: 438 RVA: 0x0000313B File Offset: 0x0000133B
		public MyHint()
		{
			base.Loaded += this.MyHint_Loaded;
			this.observer = ModBase.GetUuid();
			this.m_Context = true;
			this.collection = "";
			this.InitializeComponent();
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x060001B7 RID: 439 RVA: 0x00003179 File Offset: 0x00001379
		// (set) Token: 0x060001B8 RID: 440 RVA: 0x00014FD4 File Offset: 0x000131D4
		public bool IsWarn
		{
			get
			{
				return this.m_Context;
			}
			set
			{
				if (this.m_Context != value)
				{
					this.m_Context = value;
					if (this.m_Context)
					{
						base.BorderBrush = new ModBase.MyColor("#99FF4444");
						this.Gradient1.Color = new ModBase.MyColor("#88FFBBBB");
						this.Gradient2.Color = new ModBase.MyColor("#88FF8888");
						this.Path.Fill = new ModBase.MyColor("#BF0000");
						this.LabText.Foreground = new ModBase.MyColor("#BF0000");
						this.BtnClose.Foreground = new ModBase.MyColor("#BF0000");
						this.Path.Data = (Geometry)new GeometryConverter().ConvertFromString("F1 M 58.5832,55.4172L 17.4169,55.4171C 15.5619,53.5621 15.5619,50.5546 17.4168,48.6996L 35.201,15.8402C 37.056,13.9852 40.0635,13.9852 41.9185,15.8402L 58.5832,48.6997C 60.4382,50.5546 60.4382,53.5622 58.5832,55.4172 Z M 34.0417,25.7292L 36.0208,41.9584L 39.9791,41.9583L 41.9583,25.7292L 34.0417,25.7292 Z M 38,44.3333C 36.2511,44.3333 34.8333,45.7511 34.8333,47.5C 34.8333,49.2489 36.2511,50.6667 38,50.6667C 39.7489,50.6667 41.1666,49.2489 41.1666,47.5C 41.1666,45.7511 39.7489,44.3333 38,44.3333 Z ");
						return;
					}
					base.BorderBrush = new ModBase.MyColor("#994D76FF");
					this.Gradient1.Color = new ModBase.MyColor("#88B0D0FF");
					this.Gradient2.Color = new ModBase.MyColor("#889EBAFF");
					this.Path.Fill = new ModBase.MyColor("#0062BF");
					this.LabText.Foreground = new ModBase.MyColor("#0062BF");
					this.BtnClose.Foreground = new ModBase.MyColor("#0062BF");
					this.Path.Data = (Geometry)new GeometryConverter().ConvertFromString("F1M38,19C48.4934,19 57,27.5066 57,38 57,48.4934 48.4934,57 38,57 27.5066,57 19,48.4934 19,38 19,27.5066 27.5066,19 38,19z M33.25,33.25L33.25,36.4167 36.4166,36.4167 36.4166,47.5 33.25,47.5 33.25,50.6667 44.3333,50.6667 44.3333,47.5 41.1666,47.5 41.1666,36.4167 41.1666,33.25 33.25,33.25z M38.7917,25.3333C37.48,25.3333 36.4167,26.3967 36.4167,27.7083 36.4167,29.02 37.48,30.0833 38.7917,30.0833 40.1033,30.0833 41.1667,29.02 41.1667,27.7083 41.1667,26.3967 40.1033,25.3333 38.7917,25.3333z");
				}
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x060001B9 RID: 441 RVA: 0x00003181 File Offset: 0x00001381
		// (set) Token: 0x060001BA RID: 442 RVA: 0x0000318E File Offset: 0x0000138E
		public string Text
		{
			get
			{
				return this.LabText.Text;
			}
			set
			{
				this.LabText.Text = value;
			}
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x060001BB RID: 443 RVA: 0x0000319C File Offset: 0x0000139C
		// (set) Token: 0x060001BC RID: 444 RVA: 0x000031AC File Offset: 0x000013AC
		public bool CanClose
		{
			get
			{
				return this.BtnClose.Visibility == Visibility.Visible;
			}
			set
			{
				this.BtnClose.Visibility = (value ? Visibility.Visible : Visibility.Collapsed);
			}
		}

		// Token: 0x060001BD RID: 445 RVA: 0x000031C0 File Offset: 0x000013C0
		private void MyHint_Loaded(object sender, RoutedEventArgs e)
		{
			if (Conversions.ToBoolean(this.CanClose && Conversions.ToBoolean(ModBase._ParamsState.Get(this.collection, null))))
			{
				base.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x060001BE RID: 446 RVA: 0x000031F6 File Offset: 0x000013F6
		private void BtnClose_Click(object sender, EventArgs e)
		{
			ModBase._ParamsState.Set(this.collection, true, false, null);
			ModAnimation.AniDispose(this, false, null);
		}

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x060001BF RID: 447 RVA: 0x00003218 File Offset: 0x00001418
		// (set) Token: 0x060001C0 RID: 448 RVA: 0x00003220 File Offset: 0x00001420
		internal virtual MyHint PanBack { get; set; }

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x060001C1 RID: 449 RVA: 0x00003229 File Offset: 0x00001429
		// (set) Token: 0x060001C2 RID: 450 RVA: 0x00003231 File Offset: 0x00001431
		internal virtual GradientStop Gradient1 { get; set; }

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x060001C3 RID: 451 RVA: 0x0000323A File Offset: 0x0000143A
		// (set) Token: 0x060001C4 RID: 452 RVA: 0x00003242 File Offset: 0x00001442
		internal virtual GradientStop Gradient2 { get; set; }

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x060001C5 RID: 453 RVA: 0x0000324B File Offset: 0x0000144B
		// (set) Token: 0x060001C6 RID: 454 RVA: 0x00003253 File Offset: 0x00001453
		internal virtual Path Path { get; set; }

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x060001C7 RID: 455 RVA: 0x0000325C File Offset: 0x0000145C
		// (set) Token: 0x060001C8 RID: 456 RVA: 0x00003264 File Offset: 0x00001464
		internal virtual TextBlock LabText { get; set; }

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x060001C9 RID: 457 RVA: 0x0000326D File Offset: 0x0000146D
		// (set) Token: 0x060001CA RID: 458 RVA: 0x0001516C File Offset: 0x0001336C
		internal virtual MyIconButton BtnClose
		{
			[CompilerGenerated]
			get
			{
				return this.printer;
			}
			[CompilerGenerated]
			set
			{
				MyIconButton.ClickEventHandler value2 = new MyIconButton.ClickEventHandler(this.BtnClose_Click);
				MyIconButton myIconButton = this.printer;
				if (myIconButton != null)
				{
					myIconButton.Click -= value2;
				}
				this.printer = value;
				myIconButton = this.printer;
				if (myIconButton != null)
				{
					myIconButton.Click += value2;
				}
			}
		}

		// Token: 0x060001CB RID: 459 RVA: 0x000151B0 File Offset: 0x000133B0
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.token)
			{
				this.token = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/controls/myhint.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x060001CC RID: 460 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060001CD RID: 461 RVA: 0x000151E0 File Offset: 0x000133E0
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyHint)target;
				return;
			}
			if (connectionId == 2)
			{
				this.Gradient1 = (GradientStop)target;
				return;
			}
			if (connectionId == 3)
			{
				this.Gradient2 = (GradientStop)target;
				return;
			}
			if (connectionId == 4)
			{
				this.Path = (Path)target;
				return;
			}
			if (connectionId == 5)
			{
				this.LabText = (TextBlock)target;
				return;
			}
			if (connectionId == 6)
			{
				this.BtnClose = (MyIconButton)target;
				return;
			}
			this.token = true;
		}

		// Token: 0x040000D3 RID: 211
		public int observer;

		// Token: 0x040000D4 RID: 212
		private bool m_Context;

		// Token: 0x040000D5 RID: 213
		public string collection;

		// Token: 0x040000D6 RID: 214
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyHint m_Consumer;

		// Token: 0x040000D7 RID: 215
		[AccessedThroughProperty("Gradient1")]
		[CompilerGenerated]
		private GradientStop filter;

		// Token: 0x040000D8 RID: 216
		[AccessedThroughProperty("Gradient2")]
		[CompilerGenerated]
		private GradientStop _Reader;

		// Token: 0x040000D9 RID: 217
		[AccessedThroughProperty("Path")]
		[CompilerGenerated]
		private Path _Field;

		// Token: 0x040000DA RID: 218
		[AccessedThroughProperty("LabText")]
		[CompilerGenerated]
		private TextBlock page;

		// Token: 0x040000DB RID: 219
		[CompilerGenerated]
		[AccessedThroughProperty("BtnClose")]
		private MyIconButton printer;

		// Token: 0x040000DC RID: 220
		private bool token;
	}
}
