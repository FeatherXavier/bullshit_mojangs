﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.VisualBasic.CompilerServices;
using Newtonsoft.Json.Linq;

namespace PCL
{
	// Token: 0x02000091 RID: 145
	[DesignerGenerated]
	public class PageDownloadInstall : MyPageRight, IComponentConnector
	{
		// Token: 0x0600045A RID: 1114 RVA: 0x00026920 File Offset: 0x00024B20
		public PageDownloadInstall()
		{
			base.Initialized += delegate(object sender, EventArgs e)
			{
				this.LoaderInit();
			};
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.Init();
			};
			this.methodWrapper = false;
			this.annotationWrapper = false;
			this._InterceptorWrapper = false;
			this.importerWrapper = null;
			this._ProxyWrapper = null;
			this.classWrapper = null;
			this.m_RegistryWrapper = null;
			this._ProducerWrapper = null;
			this.m_CandidateWrapper = false;
			this.m_SetterWrapper = false;
			this.InitializeComponent();
		}

		// Token: 0x0600045B RID: 1115 RVA: 0x000269A4 File Offset: 0x00024BA4
		private void LoaderInit()
		{
			base.PageLoaderInit(this.LoadMinecraft, this.PanLoad, this.PanBack, null, ModDownload.propertyTag, delegate(ModLoader.LoaderBase a0)
			{
				this.LoadMinecraft_OnFinish();
			}, null, true);
		}

		// Token: 0x0600045C RID: 1116 RVA: 0x000269E0 File Offset: 0x00024BE0
		private void Init()
		{
			this.PanBack.ScrollToHome();
			ModDownload.m_AlgoTag.Start(null, false);
			ModDownload.iteratorTag.Start(null, false);
			ModDownload.m_ValueTag.Start(null, false);
			this.TextSelectName.ValidateRules = new Collection<Validate>
			{
				new ValidateFolderName(ModMinecraft._MapperTag + "versions", true, true)
			};
			this.TextSelectName.Validate();
			this.SelectReload();
			if (!this.methodWrapper)
			{
				this.methodWrapper = true;
				ModDownloadLib.McDownloadForgeRecommendedRefresh();
				this.LoadOptiFine.State = ModDownload.m_AlgoTag;
				this.LoadLiteLoader.State = ModDownload.iteratorTag;
				this.LoadFabric.State = ModDownload.m_ValueTag;
				this.LoadFabricApi.State = ModDownload._HelperTag;
			}
		}

		// Token: 0x0600045D RID: 1117 RVA: 0x00026AB0 File Offset: 0x00024CB0
		private void EnterSelectPage()
		{
			if (!this.annotationWrapper)
			{
				this.annotationWrapper = true;
				this.m_CandidateWrapper = false;
				this.PanSelect.Visibility = Visibility.Visible;
				this.PanSelect.IsHitTestVisible = true;
				this.PanMinecraft.IsHitTestVisible = false;
				this.PanBack.IsHitTestVisible = false;
				this.PanBack.ScrollToHome();
				this.CardMinecraft.IsSwaped = true;
				this.CardOptiFine.IsSwaped = true;
				this.CardLiteLoader.IsSwaped = true;
				this.CardForge.IsSwaped = true;
				this.CardFabric.IsSwaped = true;
				this.CardFabricApi.IsSwaped = true;
				if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("HintInstallBack", null))))
				{
					ModBase._ParamsState.Set("HintInstallBack", true, false, null);
					ModMain.Hint("点击 Minecraft 项即可返回游戏主版本选择页面！", ModMain.HintType.Info, true);
				}
				try
				{
					foreach (FrameworkElement frameworkElement in base.GetAllAnimControls(this.PanSelect))
					{
						frameworkElement.Opacity = 1.0;
						frameworkElement.RenderTransform = new TranslateTransform();
					}
				}
				finally
				{
					List<FrameworkElement>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				if (this.m_RefWrapper.StartsWith("1."))
				{
					ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>> loaderTask = new ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>("DlForgeVersion " + this.m_RefWrapper, new Action<ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>>(ModDownload.DlForgeVersionMain), null, ThreadPriority.Normal);
					this.LoadForge.State = loaderTask;
					loaderTask.Start(this.m_RefWrapper, false);
				}
				ModDownload._HelperTag.Start(null, false);
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaOpacity(this.PanMinecraft, -this.PanMinecraft.Opacity, 100, 10, null, false),
					ModAnimation.AaTranslateX(this.PanMinecraft, -50.0 - ((TranslateTransform)this.PanMinecraft.RenderTransform).X, 110, 10, null, false),
					ModAnimation.AaCode(delegate
					{
						this.PanBack.ScrollToHome();
						this.TextSelectName.Validate();
						this.OptiFine_Loaded();
						this.LiteLoader_Loaded();
						this.Forge_Loaded();
						this.Fabric_Loaded();
						this.FabricApi_Loaded();
						this.SelectReload();
					}, 0, true),
					ModAnimation.AaOpacity(this.PanSelect, 1.0 - this.PanSelect.Opacity, 250, 150, null, false),
					ModAnimation.AaTranslateX(this.PanSelect, -((TranslateTransform)this.PanSelect.RenderTransform).X, 500, 150, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Weak), false),
					ModAnimation.AaCode(delegate
					{
						this.PanMinecraft.Visibility = Visibility.Collapsed;
						this.PanBack.IsHitTestVisible = true;
						if (!this._InterceptorWrapper)
						{
							this._InterceptorWrapper = true;
							this.BtnOptiFineClearInner.SetBinding(Shape.FillProperty, new Binding("Foreground")
							{
								Source = this.CardOptiFine._Adapter,
								Mode = BindingMode.OneWay
							});
							this.BtnLiteLoaderClearInner.SetBinding(Shape.FillProperty, new Binding("Foreground")
							{
								Source = this.CardLiteLoader._Adapter,
								Mode = BindingMode.OneWay
							});
							this.BtnForgeClearInner.SetBinding(Shape.FillProperty, new Binding("Foreground")
							{
								Source = this.CardForge._Adapter,
								Mode = BindingMode.OneWay
							});
							this.BtnFabricClearInner.SetBinding(Shape.FillProperty, new Binding("Foreground")
							{
								Source = this.CardFabric._Adapter,
								Mode = BindingMode.OneWay
							});
							this.BtnFabricApiClearInner.SetBinding(Shape.FillProperty, new Binding("Foreground")
							{
								Source = this.CardFabricApi._Adapter,
								Mode = BindingMode.OneWay
							});
						}
					}, 0, true)
				}, "FrmDownloadInstall SelectPageSwitch", true);
			}
		}

		// Token: 0x0600045E RID: 1118 RVA: 0x00026D60 File Offset: 0x00024F60
		public void ExitSelectPage()
		{
			if (this.annotationWrapper)
			{
				this.annotationWrapper = false;
				this.SelectClear();
				this.PanMinecraft.Visibility = Visibility.Visible;
				this.PanSelect.IsHitTestVisible = false;
				this.PanMinecraft.IsHitTestVisible = true;
				this.PanBack.IsHitTestVisible = false;
				this.PanBack.ScrollToHome();
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaOpacity(this.PanSelect, -this.PanSelect.Opacity, 90, 10, null, false),
					ModAnimation.AaTranslateX(this.PanSelect, 50.0 - ((TranslateTransform)this.PanSelect.RenderTransform).X, 100, 10, null, false),
					ModAnimation.AaCode(delegate
					{
						this.PanBack.ScrollToHome();
					}, 0, true),
					ModAnimation.AaOpacity(this.PanMinecraft, 1.0 - this.PanMinecraft.Opacity, 150, 100, null, false),
					ModAnimation.AaTranslateX(this.PanMinecraft, -((TranslateTransform)this.PanMinecraft.RenderTransform).X, 400, 100, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Weak), false),
					ModAnimation.AaCode(delegate
					{
						this.PanSelect.Visibility = Visibility.Collapsed;
						this.PanBack.IsHitTestVisible = true;
					}, 0, true)
				}, "FrmDownloadInstall SelectPageSwitch", false);
			}
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x00026EC8 File Offset: 0x000250C8
		public void MinecraftSelected(MyListItem sender, object e)
		{
			this.m_RefWrapper = sender.Title;
			this.serverWrapper = NewLateBinding.LateIndexGet(sender.Tag, new object[]
			{
				"url"
			}, null).ToString();
			this._ServiceWrapper = sender.Logo;
			this.EnterSelectPage();
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x000043A6 File Offset: 0x000025A6
		private void CardMinecraft_PreviewSwap(object sender, ModBase.RouteEventArgs e)
		{
			this.ExitSelectPage();
			e.proxyParameter = true;
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x00026F18 File Offset: 0x00025118
		private void SetOptiFineInfoShow(string IsShow)
		{
			if (!Operators.ConditionalCompareObjectEqual(this.PanOptiFineInfo.Tag, IsShow, true))
			{
				this.PanOptiFineInfo.Tag = IsShow;
				if (Operators.CompareString(IsShow, "True", true) == 0)
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaTranslateY(this.PanOptiFineInfo, -((TranslateTransform)this.PanOptiFineInfo.RenderTransform).Y, 270, 100, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Middle), false),
						ModAnimation.AaOpacity(this.PanOptiFineInfo, 1.0 - this.PanOptiFineInfo.Opacity, 100, 90, null, false)
					}, "SetOptiFineInfoShow", false);
					return;
				}
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaTranslateY(this.PanOptiFineInfo, 6.0 - ((TranslateTransform)this.PanOptiFineInfo.RenderTransform).Y, 200, 0, null, false),
					ModAnimation.AaOpacity(this.PanOptiFineInfo, -this.PanOptiFineInfo.Opacity, 100, 0, null, false)
				}, "SetOptiFineInfoShow", false);
			}
		}

		// Token: 0x06000462 RID: 1122 RVA: 0x00027038 File Offset: 0x00025238
		private void SetLiteLoaderInfoShow(string IsShow)
		{
			if (!Operators.ConditionalCompareObjectEqual(this.PanLiteLoaderInfo.Tag, IsShow, true))
			{
				this.PanLiteLoaderInfo.Tag = IsShow;
				if (Operators.CompareString(IsShow, "True", true) == 0)
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaTranslateY(this.PanLiteLoaderInfo, -((TranslateTransform)this.PanLiteLoaderInfo.RenderTransform).Y, 270, 100, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Middle), false),
						ModAnimation.AaOpacity(this.PanLiteLoaderInfo, 1.0 - this.PanLiteLoaderInfo.Opacity, 100, 90, null, false)
					}, "SetLiteLoaderInfoShow", false);
					return;
				}
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaTranslateY(this.PanLiteLoaderInfo, 6.0 - ((TranslateTransform)this.PanLiteLoaderInfo.RenderTransform).Y, 200, 0, null, false),
					ModAnimation.AaOpacity(this.PanLiteLoaderInfo, -this.PanLiteLoaderInfo.Opacity, 100, 0, null, false)
				}, "SetLiteLoaderInfoShow", false);
			}
		}

		// Token: 0x06000463 RID: 1123 RVA: 0x00027158 File Offset: 0x00025358
		private void SetForgeInfoShow(string IsShow)
		{
			if (!Operators.ConditionalCompareObjectEqual(this.PanForgeInfo.Tag, IsShow, true))
			{
				this.PanForgeInfo.Tag = IsShow;
				if (Operators.CompareString(IsShow, "True", true) == 0)
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaTranslateY(this.PanForgeInfo, -((TranslateTransform)this.PanForgeInfo.RenderTransform).Y, 270, 100, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Middle), false),
						ModAnimation.AaOpacity(this.PanForgeInfo, 1.0 - this.PanForgeInfo.Opacity, 100, 90, null, false)
					}, "SetForgeInfoShow", false);
					return;
				}
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaTranslateY(this.PanForgeInfo, 6.0 - ((TranslateTransform)this.PanForgeInfo.RenderTransform).Y, 200, 0, null, false),
					ModAnimation.AaOpacity(this.PanForgeInfo, -this.PanForgeInfo.Opacity, 100, 0, null, false)
				}, "SetForgeInfoShow", false);
			}
		}

		// Token: 0x06000464 RID: 1124 RVA: 0x00027278 File Offset: 0x00025478
		private void SetFabricInfoShow(string IsShow)
		{
			if (!Operators.ConditionalCompareObjectEqual(this.PanFabricInfo.Tag, IsShow, true))
			{
				this.PanFabricInfo.Tag = IsShow;
				if (Operators.CompareString(IsShow, "True", true) == 0)
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaTranslateY(this.PanFabricInfo, -((TranslateTransform)this.PanFabricInfo.RenderTransform).Y, 270, 100, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Middle), false),
						ModAnimation.AaOpacity(this.PanFabricInfo, 1.0 - this.PanFabricInfo.Opacity, 100, 90, null, false)
					}, "SetFabricInfoShow", false);
					return;
				}
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaTranslateY(this.PanFabricInfo, 6.0 - ((TranslateTransform)this.PanFabricInfo.RenderTransform).Y, 200, 0, null, false),
					ModAnimation.AaOpacity(this.PanFabricInfo, -this.PanFabricInfo.Opacity, 100, 0, null, false)
				}, "SetFabricInfoShow", false);
			}
		}

		// Token: 0x06000465 RID: 1125 RVA: 0x00027398 File Offset: 0x00025598
		private void SetFabricApiInfoShow(string IsShow)
		{
			if (!Operators.ConditionalCompareObjectEqual(this.PanFabricApiInfo.Tag, IsShow, true))
			{
				this.PanFabricApiInfo.Tag = IsShow;
				if (Operators.CompareString(IsShow, "True", true) == 0)
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaTranslateY(this.PanFabricApiInfo, -((TranslateTransform)this.PanFabricApiInfo.RenderTransform).Y, 270, 100, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Middle), false),
						ModAnimation.AaOpacity(this.PanFabricApiInfo, 1.0 - this.PanFabricApiInfo.Opacity, 100, 90, null, false)
					}, "SetFabricApiInfoShow", false);
					return;
				}
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaTranslateY(this.PanFabricApiInfo, 6.0 - ((TranslateTransform)this.PanFabricApiInfo.RenderTransform).Y, 200, 0, null, false),
					ModAnimation.AaOpacity(this.PanFabricApiInfo, -this.PanFabricApiInfo.Opacity, 100, 0, null, false)
				}, "SetFabricApiInfoShow", false);
			}
		}

		// Token: 0x06000466 RID: 1126 RVA: 0x000274B8 File Offset: 0x000256B8
		private void SelectReload()
		{
			if (this.m_RefWrapper != null)
			{
				this.SelectNameUpdate();
				this.ItemSelect.Title = this.TextSelectName.Text;
				this.ItemSelect.Info = this.GetSelectInfo();
				this.ItemSelect.Logo = this.GetSelectLogo();
				this.LabMinecraft.Text = this.m_RefWrapper;
				this.ImgMinecraft.Source = new MyBitmap(this._ServiceWrapper);
				string text = this.LoadOptiFineGetError();
				this.CardOptiFine.initializer.Visibility = ((text == null) ? Visibility.Visible : Visibility.Collapsed);
				if (text != null)
				{
					this.CardOptiFine.IsSwaped = true;
				}
				this.SetOptiFineInfoShow(Conversions.ToString(this.CardOptiFine.IsSwaped));
				if (this.importerWrapper == null)
				{
					this.BtnOptiFineClear.Visibility = Visibility.Collapsed;
					this.ImgOptiFine.Visibility = Visibility.Collapsed;
					this.LabOptiFine.Text = (text ?? "点击选择");
					this.LabOptiFine.Foreground = ModMain._ValAccount;
				}
				else
				{
					this.BtnOptiFineClear.Visibility = Visibility.Visible;
					this.ImgOptiFine.Visibility = Visibility.Visible;
					this.LabOptiFine.Text = this.importerWrapper.m_SerializerProccesor.Replace(this.m_RefWrapper + " ", "");
					this.LabOptiFine.Foreground = ModMain.mapperAccount;
				}
				this.HintOptiFine.Visibility = ((this.m_RegistryWrapper != null) ? Visibility.Visible : Visibility.Collapsed);
				string text2 = this.LoadLiteLoaderGetError();
				this.CardLiteLoader.initializer.Visibility = ((text2 == null) ? Visibility.Visible : Visibility.Collapsed);
				if (text2 != null)
				{
					this.CardLiteLoader.IsSwaped = true;
				}
				this.SetLiteLoaderInfoShow(Conversions.ToString(this.CardLiteLoader.IsSwaped));
				if (this._ProxyWrapper == null)
				{
					this.BtnLiteLoaderClear.Visibility = Visibility.Collapsed;
					this.ImgLiteLoader.Visibility = Visibility.Collapsed;
					this.LabLiteLoader.Text = (text2 ?? "点击选择");
					this.LabLiteLoader.Foreground = ModMain._ValAccount;
				}
				else
				{
					this.BtnLiteLoaderClear.Visibility = Visibility.Visible;
					this.ImgLiteLoader.Visibility = Visibility.Visible;
					this.LabLiteLoader.Text = this._ProxyWrapper.Inherit;
					this.LabLiteLoader.Foreground = ModMain.mapperAccount;
				}
				string text3 = this.LoadForgeGetError();
				this.CardForge.initializer.Visibility = ((text3 == null) ? Visibility.Visible : Visibility.Collapsed);
				if (text3 != null)
				{
					this.CardForge.IsSwaped = true;
				}
				this.SetForgeInfoShow(Conversions.ToString(this.CardForge.IsSwaped));
				if (this.classWrapper == null)
				{
					this.BtnForgeClear.Visibility = Visibility.Collapsed;
					this.ImgForge.Visibility = Visibility.Collapsed;
					this.LabForge.Text = (text3 ?? "点击选择");
					this.LabForge.Foreground = ModMain._ValAccount;
				}
				else
				{
					this.BtnForgeClear.Visibility = Visibility.Visible;
					this.ImgForge.Visibility = Visibility.Visible;
					this.LabForge.Text = this.classWrapper.productProccesor;
					this.LabForge.Foreground = ModMain.mapperAccount;
				}
				string text4 = this.LoadFabricGetError();
				this.CardFabric.initializer.Visibility = ((text4 == null) ? Visibility.Visible : Visibility.Collapsed);
				if (text4 != null)
				{
					this.CardFabric.IsSwaped = true;
				}
				this.SetFabricInfoShow(Conversions.ToString(this.CardFabric.IsSwaped));
				if (this.m_RegistryWrapper == null)
				{
					this.BtnFabricClear.Visibility = Visibility.Collapsed;
					this.ImgFabric.Visibility = Visibility.Collapsed;
					this.LabFabric.Text = (text4 ?? "点击选择");
					this.LabFabric.Foreground = ModMain._ValAccount;
				}
				else
				{
					this.BtnFabricClear.Visibility = Visibility.Visible;
					this.ImgFabric.Visibility = Visibility.Visible;
					this.LabFabric.Text = this.m_RegistryWrapper.Replace("+build", "");
					this.LabFabric.Foreground = ModMain.mapperAccount;
				}
				this.HintFabric.Visibility = ((this.importerWrapper != null) ? Visibility.Visible : Visibility.Collapsed);
				string text5 = this.LoadFabricApiGetError();
				this.CardFabricApi.initializer.Visibility = ((text5 == null) ? Visibility.Visible : Visibility.Collapsed);
				if (text5 != null || this.m_RegistryWrapper == null)
				{
					this.CardFabricApi.IsSwaped = true;
				}
				this.SetFabricApiInfoShow(Conversions.ToString(this.CardFabricApi.IsSwaped));
				if (this._ProducerWrapper == null)
				{
					this.BtnFabricApiClear.Visibility = Visibility.Collapsed;
					this.ImgFabricApi.Visibility = Visibility.Collapsed;
					this.LabFabricApi.Text = (text5 ?? "点击选择");
					this.LabFabricApi.Foreground = ModMain._ValAccount;
				}
				else
				{
					this.BtnFabricApiClear.Visibility = Visibility.Visible;
					this.ImgFabricApi.Visibility = Visibility.Visible;
					this.LabFabricApi.Text = this._ProducerWrapper.m_CollectionProccesor.Split(new char[]
					{
						']'
					})[1].Replace("Fabric API ", "").Replace(" build ", ".").Trim();
					this.LabFabricApi.Foreground = ModMain.mapperAccount;
				}
				this.HintFabricAPI.Visibility = ((this.m_RegistryWrapper == null || this._ProducerWrapper != null) ? Visibility.Collapsed : Visibility.Visible);
			}
		}

		// Token: 0x06000467 RID: 1127 RVA: 0x000043B5 File Offset: 0x000025B5
		private void SelectClear()
		{
			this.m_RefWrapper = null;
			this.serverWrapper = null;
			this._ServiceWrapper = null;
			this.importerWrapper = null;
			this._ProxyWrapper = null;
			this.classWrapper = null;
			this.m_RegistryWrapper = null;
			this._ProducerWrapper = null;
		}

		// Token: 0x06000468 RID: 1128 RVA: 0x00027A08 File Offset: 0x00025C08
		private string GetSelectName()
		{
			string text = this.m_RefWrapper;
			if (this.m_RegistryWrapper != null)
			{
				text = text + "-Fabric " + this.m_RegistryWrapper.Replace("+build", "");
			}
			if (this.classWrapper != null)
			{
				text = text + "-Forge_" + this.classWrapper.productProccesor;
			}
			if (this._ProxyWrapper != null)
			{
				text += "-LiteLoader";
			}
			if (this.importerWrapper != null)
			{
				text = text + "-OptiFine_" + this.importerWrapper.m_SerializerProccesor.Replace(this.m_RefWrapper + " ", "").Replace(" ", "_");
			}
			return text;
		}

		// Token: 0x06000469 RID: 1129 RVA: 0x00027AC4 File Offset: 0x00025CC4
		private string GetSelectInfo()
		{
			string text = "";
			if (this.m_RegistryWrapper != null)
			{
				text = text + ", Fabric " + this.m_RegistryWrapper.Replace("+build", "");
			}
			if (this.classWrapper != null)
			{
				text = text + ", Forge " + this.classWrapper.productProccesor;
			}
			if (this._ProxyWrapper != null)
			{
				text += ", LiteLoader";
			}
			if (this.importerWrapper != null)
			{
				text = text + ", OptiFine " + this.importerWrapper.m_SerializerProccesor.Replace(this.m_RefWrapper + " ", "");
			}
			if (Operators.CompareString(text, "", true) == 0)
			{
				text = ", 无附加安装";
			}
			return text.TrimStart(", ".ToCharArray());
		}

		// Token: 0x0600046A RID: 1130 RVA: 0x00027B90 File Offset: 0x00025D90
		private string GetSelectLogo()
		{
			string result;
			if (this.m_RegistryWrapper != null)
			{
				result = "pack://application:,,,/images/Blocks/Fabric.png";
			}
			else if (this.classWrapper != null)
			{
				result = "pack://application:,,,/images/Blocks/Anvil.png";
			}
			else if (this._ProxyWrapper != null)
			{
				result = "pack://application:,,,/images/Blocks/Egg.png";
			}
			else if (this.importerWrapper != null)
			{
				result = "pack://application:,,,/images/Blocks/GrassPath.png";
			}
			else
			{
				result = this._ServiceWrapper;
			}
			return result;
		}

		// Token: 0x0600046B RID: 1131 RVA: 0x000043EF File Offset: 0x000025EF
		private void SelectNameUpdate()
		{
			if (!this.m_CandidateWrapper && !this.m_SetterWrapper)
			{
				this.m_SetterWrapper = true;
				this.TextSelectName.Text = this.GetSelectName();
				this.m_SetterWrapper = false;
			}
		}

		// Token: 0x0600046C RID: 1132 RVA: 0x00004420 File Offset: 0x00002620
		private void TextSelectName_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (!this.m_SetterWrapper)
			{
				this.m_CandidateWrapper = true;
				this.SelectReload();
			}
		}

		// Token: 0x0600046D RID: 1133 RVA: 0x00004437 File Offset: 0x00002637
		private void TextSelectName_ValidateChanged(object sender, EventArgs e)
		{
			this.BtnSelectStart.IsEnabled = (Operators.CompareString(this.TextSelectName.ValidateResult, "", true) == 0);
		}

		// Token: 0x0600046E RID: 1134 RVA: 0x00027BE8 File Offset: 0x00025DE8
		private void LoadMinecraft_OnFinish()
		{
			this.ExitSelectPage();
			checked
			{
				try
				{
					Dictionary<string, List<JObject>> dictionary = new Dictionary<string, List<JObject>>
					{
						{
							"正式版",
							new List<JObject>()
						},
						{
							"预览版",
							new List<JObject>()
						},
						{
							"远古版",
							new List<JObject>()
						},
						{
							"愚人节版",
							new List<JObject>()
						}
					};
					JArray jarray = (JArray)ModDownload.propertyTag.Output.Value["versions"];
					try
					{
						foreach (JToken jtoken in jarray)
						{
							JObject jobject = (JObject)jtoken;
							string text = (string)jobject["type"];
							string left = text;
							if (Operators.CompareString(left, "release", true) == 0)
							{
								text = "正式版";
							}
							else if (Operators.CompareString(left, "snapshot", true) == 0)
							{
								text = "预览版";
								if (jobject["id"].ToString().StartsWith("1.") && !jobject["id"].ToString().ToLower().Contains("combat") && !jobject["id"].ToString().ToLower().Contains("rc") && !jobject["id"].ToString().ToLower().Contains("experimental") && !jobject["id"].ToString().ToLower().Contains("pre"))
								{
									text = "正式版";
									jobject["type"] = "release";
								}
								string left2 = jobject["id"].ToString().ToLower();
								if (Operators.CompareString(left2, "20w14infinite", true) != 0 && Operators.CompareString(left2, "20w14∞", true) != 0)
								{
									if (Operators.CompareString(left2, "3d shareware v1.34", true) == 0 || Operators.CompareString(left2, "1.rv-pre1", true) == 0 || Operators.CompareString(left2, "15w14a", true) == 0 || Operators.CompareString(left2, "2.0", true) == 0)
									{
										text = "愚人节版";
										jobject["type"] = "special";
										jobject.Add("lore", ModMinecraft.GetMcFoolName((string)jobject["id"]));
									}
								}
								else
								{
									text = "愚人节版";
									jobject["id"] = "20w14∞";
									jobject["type"] = "special";
									jobject.Add("lore", ModMinecraft.GetMcFoolName((string)jobject["id"]));
								}
							}
							else if (Operators.CompareString(left, "special", true) == 0)
							{
								text = "愚人节版";
							}
							else
							{
								text = "远古版";
							}
							dictionary[text].Add(jobject);
						}
					}
					finally
					{
						IEnumerator<JToken> enumerator;
						if (enumerator != null)
						{
							enumerator.Dispose();
						}
					}
					int num = dictionary.Keys.Count - 1;
					for (int i = 0; i <= num; i++)
					{
						dictionary[dictionary.Keys.ElementAtOrDefault(i)] = ModBase.Sort<JObject>(dictionary.Values.ElementAtOrDefault(i), (PageDownloadInstall._Closure$__.$IR33-4 == null) ? (PageDownloadInstall._Closure$__.$IR33-4 = ((object a0, object a1) => ((PageDownloadInstall._Closure$__.$I33-0 == null) ? (PageDownloadInstall._Closure$__.$I33-0 = ((JObject Left, JObject Right) => DateTime.Compare(Extensions.Value<DateTime>(Left["releaseTime"]), Extensions.Value<DateTime>(Right["releaseTime"])) > 0)) : PageDownloadInstall._Closure$__.$I33-0)((JObject)a0, (JObject)a1))) : PageDownloadInstall._Closure$__.$IR33-4);
					}
					this.PanMinecraft.Children.Clear();
					MyCard myCard = new MyCard();
					myCard.Title = "最新版本";
					myCard.Margin = new Thickness(0.0, 15.0, 0.0, 15.0);
					myCard.CustomizeModel(2);
					MyCard myCard2 = myCard;
					List<JObject> list = new List<JObject>();
					JObject jobject2 = (JObject)dictionary["正式版"][0].DeepClone();
					jobject2["lore"] = "最新正式版，发布于 " + jobject2["releaseTime"].ToString();
					list.Add(jobject2);
					if (DateTime.Compare(Extensions.Value<DateTime>(dictionary["正式版"][0]["releaseTime"]), Extensions.Value<DateTime>(dictionary["预览版"][0]["releaseTime"])) < 0)
					{
						JObject jobject3 = (JObject)dictionary["预览版"][0].DeepClone();
						jobject3["lore"] = "最新预览版，发布于 " + jobject3["releaseTime"].ToString();
						list.Add(jobject3);
					}
					StackPanel element = new StackPanel
					{
						Margin = new Thickness(20.0, 40.0, 18.0, 0.0),
						VerticalAlignment = VerticalAlignment.Top,
						RenderTransform = new TranslateTransform(0.0, 0.0),
						Tag = list
					};
					MyCard.StackInstall(ref element, 7, "");
					myCard2.Children.Add(element);
					this.PanMinecraft.Children.Insert(0, myCard2);
					try
					{
						foreach (KeyValuePair<string, List<JObject>> keyValuePair in dictionary)
						{
							if (keyValuePair.Value.Count != 0)
							{
								MyCard myCard3 = new MyCard();
								myCard3.Title = keyValuePair.Key + " (" + Conversions.ToString(keyValuePair.Value.Count) + ")";
								myCard3.Margin = new Thickness(0.0, 0.0, 0.0, 15.0);
								myCard3.CustomizeModel(7);
								MyCard myCard4 = myCard3;
								StackPanel stackPanel = new StackPanel
								{
									Margin = new Thickness(20.0, 40.0, 18.0, 0.0),
									VerticalAlignment = VerticalAlignment.Top,
									RenderTransform = new TranslateTransform(0.0, 0.0),
									Tag = keyValuePair.Value
								};
								myCard4.Children.Add(stackPanel);
								myCard4.m_Decorator = stackPanel;
								myCard4.IsSwaped = true;
								this.PanMinecraft.Children.Add(myCard4);
							}
						}
					}
					finally
					{
						Dictionary<string, List<JObject>>.Enumerator enumerator2;
						((IDisposable)enumerator2).Dispose();
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "可视化安装版本列表出错", ModBase.LogLevel.Feedback, "出现错误");
				}
			}
		}

		// Token: 0x0600046F RID: 1135 RVA: 0x000282E8 File Offset: 0x000264E8
		private string LoadOptiFineGetError()
		{
			string result;
			if (this.LoadOptiFine.State.LoadingState == MyLoading.MyLoadingState.Run)
			{
				result = "正在获取版本列表……";
			}
			else if (this.LoadOptiFine.State.LoadingState == MyLoading.MyLoadingState.Error)
			{
				result = Conversions.ToString(Operators.ConcatenateObject("获取版本列表失败：", NewLateBinding.LateGet(NewLateBinding.LateGet(this.LoadOptiFine.State, null, "Error", new object[0], null, null, null), null, "Message", new object[0], null, null, null)));
			}
			else
			{
				try
				{
					List<ModDownload.DlOptiFineListEntry>.Enumerator enumerator = ModDownload.m_AlgoTag.Output.Value.GetEnumerator();
					while (enumerator.MoveNext())
					{
						if (enumerator.Current.m_SerializerProccesor.StartsWith(this.m_RefWrapper + " "))
						{
							if (this.classWrapper != null && ModMinecraft.VersionSortInteger(this.m_RefWrapper, "1.13") >= 0 && ModMinecraft.VersionSortInteger("1.14.3", this.m_RefWrapper) >= 0)
							{
								return "与 Forge 不兼容";
							}
							return null;
						}
					}
				}
				finally
				{
					List<ModDownload.DlOptiFineListEntry>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				result = "没有可用版本";
			}
			return result;
		}

		// Token: 0x06000470 RID: 1136 RVA: 0x0000445D File Offset: 0x0000265D
		private void CardOptiFine_PreviewSwap(object sender, ModBase.RouteEventArgs e)
		{
			if (this.LoadOptiFineGetError() != null)
			{
				e.proxyParameter = true;
			}
		}

		// Token: 0x06000471 RID: 1137 RVA: 0x00028414 File Offset: 0x00026614
		private void OptiFine_Loaded()
		{
			try
			{
				if (ModDownload.m_AlgoTag.State == ModBase.LoadState.Finished)
				{
					List<ModDownload.DlOptiFineListEntry> list = new List<ModDownload.DlOptiFineListEntry>();
					try
					{
						foreach (ModDownload.DlOptiFineListEntry dlOptiFineListEntry in ModDownload.m_AlgoTag.Output.Value)
						{
							if (dlOptiFineListEntry.m_SerializerProccesor.StartsWith(this.m_RefWrapper + " "))
							{
								list.Add(dlOptiFineListEntry);
							}
						}
					}
					finally
					{
						List<ModDownload.DlOptiFineListEntry>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
					if (list.Count != 0)
					{
						list = ModBase.Sort<ModDownload.DlOptiFineListEntry>(list, (PageDownloadInstall._Closure$__.$IR36-5 == null) ? (PageDownloadInstall._Closure$__.$IR36-5 = ((object a0, object a1) => ((PageDownloadInstall._Closure$__.$I36-0 == null) ? (PageDownloadInstall._Closure$__.$I36-0 = ((ModDownload.DlOptiFineListEntry Left, ModDownload.DlOptiFineListEntry Right) => ModMinecraft.VersionSortBoolean(Left.m_SerializerProccesor, Right.m_SerializerProccesor))) : PageDownloadInstall._Closure$__.$I36-0)((ModDownload.DlOptiFineListEntry)a0, (ModDownload.DlOptiFineListEntry)a1))) : PageDownloadInstall._Closure$__.$IR36-5);
						this.PanOptiFine.Children.Clear();
						try
						{
							foreach (ModDownload.DlOptiFineListEntry entry in list)
							{
								this.PanOptiFine.Children.Add(ModDownloadLib.OptiFineDownloadListItem(entry, delegate(object sender, MouseButtonEventArgs e)
								{
									this.OptiFine_Selected((MyListItem)sender, e);
								}, false));
							}
						}
						finally
						{
							List<ModDownload.DlOptiFineListEntry>.Enumerator enumerator2;
							((IDisposable)enumerator2).Dispose();
						}
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "可视化 OptiFine 安装版本列表出错", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000472 RID: 1138 RVA: 0x0000446E File Offset: 0x0000266E
		private void OptiFine_Selected(MyListItem sender, EventArgs e)
		{
			this.importerWrapper = (ModDownload.DlOptiFineListEntry)sender.Tag;
			this.CardOptiFine.IsSwaped = true;
			this.SelectReload();
		}

		// Token: 0x06000473 RID: 1139 RVA: 0x00004493 File Offset: 0x00002693
		private void OptiFine_Clear(object sender, MouseButtonEventArgs e)
		{
			this.importerWrapper = null;
			this.CardOptiFine.IsSwaped = true;
			e.Handled = true;
			this.SelectReload();
		}

		// Token: 0x06000474 RID: 1140 RVA: 0x0002859C File Offset: 0x0002679C
		private string LoadLiteLoaderGetError()
		{
			string result;
			if (this.m_RefWrapper.Contains("1.") && ModBase.Val(this.m_RefWrapper.Split(new char[]
			{
				'.'
			})[1]) <= 12.0)
			{
				if (this.LoadLiteLoader.State.LoadingState == MyLoading.MyLoadingState.Run)
				{
					result = "正在获取版本列表……";
				}
				else if (this.LoadLiteLoader.State.LoadingState == MyLoading.MyLoadingState.Error)
				{
					result = Conversions.ToString(Operators.ConcatenateObject("获取版本列表失败：", NewLateBinding.LateGet(NewLateBinding.LateGet(this.LoadLiteLoader.State, null, "Error", new object[0], null, null, null), null, "Message", new object[0], null, null, null)));
				}
				else
				{
					try
					{
						List<ModDownload.DlLiteLoaderListEntry>.Enumerator enumerator = ModDownload.iteratorTag.Output.Value.GetEnumerator();
						while (enumerator.MoveNext())
						{
							if (Operators.CompareString(enumerator.Current.Inherit, this.m_RefWrapper, true) == 0)
							{
								return null;
							}
						}
					}
					finally
					{
						List<ModDownload.DlLiteLoaderListEntry>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
					result = "没有可用版本";
				}
			}
			else
			{
				result = "没有可用版本";
			}
			return result;
		}

		// Token: 0x06000475 RID: 1141 RVA: 0x000044B5 File Offset: 0x000026B5
		private void CardLiteLoader_PreviewSwap(object sender, ModBase.RouteEventArgs e)
		{
			if (this.LoadLiteLoaderGetError() != null)
			{
				e.proxyParameter = true;
			}
		}

		// Token: 0x06000476 RID: 1142 RVA: 0x000286CC File Offset: 0x000268CC
		private void LiteLoader_Loaded()
		{
			try
			{
				if (ModDownload.iteratorTag.State == ModBase.LoadState.Finished)
				{
					List<ModDownload.DlLiteLoaderListEntry> list = new List<ModDownload.DlLiteLoaderListEntry>();
					try
					{
						foreach (ModDownload.DlLiteLoaderListEntry dlLiteLoaderListEntry in ModDownload.iteratorTag.Output.Value)
						{
							if (Operators.CompareString(dlLiteLoaderListEntry.Inherit, this.m_RefWrapper, true) == 0)
							{
								list.Add(dlLiteLoaderListEntry);
							}
						}
					}
					finally
					{
						List<ModDownload.DlLiteLoaderListEntry>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
					if (list.Count != 0)
					{
						this.PanLiteLoader.Children.Clear();
						try
						{
							foreach (ModDownload.DlLiteLoaderListEntry entry in list)
							{
								this.PanLiteLoader.Children.Add(ModDownloadLib.LiteLoaderDownloadListItem(entry, delegate(object sender, MouseButtonEventArgs e)
								{
									this.LiteLoader_Selected((MyListItem)sender, e);
								}, false));
							}
						}
						finally
						{
							List<ModDownload.DlLiteLoaderListEntry>.Enumerator enumerator2;
							((IDisposable)enumerator2).Dispose();
						}
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "可视化 LiteLoader 安装版本列表出错", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000477 RID: 1143 RVA: 0x000044C6 File Offset: 0x000026C6
		private void LiteLoader_Selected(MyListItem sender, EventArgs e)
		{
			this._ProxyWrapper = (ModDownload.DlLiteLoaderListEntry)sender.Tag;
			this.CardLiteLoader.IsSwaped = true;
			this.SelectReload();
		}

		// Token: 0x06000478 RID: 1144 RVA: 0x000044EB File Offset: 0x000026EB
		private void LiteLoader_Clear(object sender, MouseButtonEventArgs e)
		{
			this._ProxyWrapper = null;
			this.CardLiteLoader.IsSwaped = true;
			e.Handled = true;
			this.SelectReload();
		}

		// Token: 0x06000479 RID: 1145 RVA: 0x000287FC File Offset: 0x000269FC
		private string LoadForgeGetError()
		{
			string result;
			if (!this.m_RefWrapper.StartsWith("1."))
			{
				result = "没有可用版本";
			}
			else if (!this.LoadForge.State.IsLoader)
			{
				result = "正在获取版本列表……";
			}
			else
			{
				ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>> loaderTask = (ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>)this.LoadForge.State;
				if (Operators.CompareString(this.m_RefWrapper, loaderTask.Input, true) != 0)
				{
					result = "正在获取版本列表……";
				}
				else if (loaderTask.State == ModBase.LoadState.Loading)
				{
					result = "正在获取版本列表……";
				}
				else if (loaderTask.State == ModBase.LoadState.Failed)
				{
					string message = loaderTask.Error.Message;
					if (message.Contains("没有可用版本"))
					{
						result = "没有可用版本";
					}
					else
					{
						result = "获取版本列表失败：" + message;
					}
				}
				else if (loaderTask.State != ModBase.LoadState.Finished)
				{
					result = "获取版本列表失败：未知错误，状态为 " + ModBase.GetStringFromEnum(loaderTask.State);
				}
				else
				{
					try
					{
						foreach (ModDownload.DlForgeVersionEntry dlForgeVersionEntry in loaderTask.Output)
						{
							if (Operators.CompareString(dlForgeVersionEntry._IndexerProccesor, "universal", true) != 0 && Operators.CompareString(dlForgeVersionEntry._IndexerProccesor, "client", true) != 0)
							{
								if (this.m_RegistryWrapper != null)
								{
									return "与 Fabric 不兼容";
								}
								if (this.importerWrapper != null && ModMinecraft.VersionSortInteger(this.m_RefWrapper, "1.13") >= 0 && ModMinecraft.VersionSortInteger("1.14.3", this.m_RefWrapper) >= 0)
								{
									return "与 OptiFine 不兼容";
								}
								return null;
							}
						}
					}
					finally
					{
						List<ModDownload.DlForgeVersionEntry>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
					result = "该版本不支持自动安装";
				}
			}
			return result;
		}

		// Token: 0x0600047A RID: 1146 RVA: 0x0000450D File Offset: 0x0000270D
		private void CardForge_PreviewSwap(object sender, ModBase.RouteEventArgs e)
		{
			if (this.LoadForgeGetError() != null)
			{
				e.proxyParameter = true;
			}
		}

		// Token: 0x0600047B RID: 1147 RVA: 0x000289A8 File Offset: 0x00026BA8
		private void Forge_Loaded()
		{
			try
			{
				if (this.LoadForge.State.IsLoader)
				{
					ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>> loaderTask = (ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>)this.LoadForge.State;
					if (Operators.CompareString(this.m_RefWrapper, loaderTask.Input, true) == 0)
					{
						if (loaderTask.State == ModBase.LoadState.Finished)
						{
							List<ModDownload.DlForgeVersionEntry> list = new List<ModDownload.DlForgeVersionEntry>();
							list.AddRange(loaderTask.Output);
							if (loaderTask.Output.Count != 0)
							{
								this.PanForge.Children.Clear();
								list = ModBase.Sort<ModDownload.DlForgeVersionEntry>(list, (PageDownloadInstall._Closure$__.$IR46-8 == null) ? (PageDownloadInstall._Closure$__.$IR46-8 = ((object a0, object a1) => ((PageDownloadInstall._Closure$__.$I46-0 == null) ? (PageDownloadInstall._Closure$__.$I46-0 = ((ModDownload.DlForgeVersionEntry Left, ModDownload.DlForgeVersionEntry Right) => new Version(Left.productProccesor) > new Version(Right.productProccesor))) : PageDownloadInstall._Closure$__.$I46-0)((ModDownload.DlForgeVersionEntry)a0, (ModDownload.DlForgeVersionEntry)a1))) : PageDownloadInstall._Closure$__.$IR46-8);
								ModDownloadLib.ForgeDownloadListItemPreload(this.PanForge, list, delegate(object sender, MouseButtonEventArgs e)
								{
									this.Forge_Selected((MyListItem)sender, e);
								}, false);
								try
								{
									foreach (ModDownload.DlForgeVersionEntry dlForgeVersionEntry in list)
									{
										if (Operators.CompareString(dlForgeVersionEntry._IndexerProccesor, "universal", true) != 0 && Operators.CompareString(dlForgeVersionEntry._IndexerProccesor, "client", true) != 0)
										{
											this.PanForge.Children.Add(ModDownloadLib.ForgeDownloadListItem(dlForgeVersionEntry, delegate(object sender, MouseButtonEventArgs e)
											{
												this.Forge_Selected((MyListItem)sender, e);
											}, false));
										}
									}
								}
								finally
								{
									List<ModDownload.DlForgeVersionEntry>.Enumerator enumerator;
									((IDisposable)enumerator).Dispose();
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "可视化 Forge 安装版本列表出错", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x0600047C RID: 1148 RVA: 0x0000451E File Offset: 0x0000271E
		private void Forge_Selected(MyListItem sender, EventArgs e)
		{
			this.classWrapper = (ModDownload.DlForgeVersionEntry)sender.Tag;
			this.CardForge.IsSwaped = true;
			this.SelectReload();
		}

		// Token: 0x0600047D RID: 1149 RVA: 0x00004543 File Offset: 0x00002743
		private void Forge_Clear(object sender, MouseButtonEventArgs e)
		{
			this.classWrapper = null;
			this.CardForge.IsSwaped = true;
			e.Handled = true;
			this.SelectReload();
		}

		// Token: 0x0600047E RID: 1150 RVA: 0x00028B48 File Offset: 0x00026D48
		private string LoadFabricGetError()
		{
			string result;
			if (this.LoadFabric.State.LoadingState == MyLoading.MyLoadingState.Run)
			{
				result = "正在获取版本列表……";
			}
			else if (this.LoadFabric.State.LoadingState == MyLoading.MyLoadingState.Error)
			{
				result = Conversions.ToString(Operators.ConcatenateObject("获取版本列表失败：", NewLateBinding.LateGet(NewLateBinding.LateGet(this.LoadFabric.State, null, "Error", new object[0], null, null, null), null, "Message", new object[0], null, null, null)));
			}
			else
			{
				try
				{
					IEnumerator<JToken> enumerator = ModDownload.m_ValueTag.Output.Value["game"].GetEnumerator();
					while (enumerator.MoveNext())
					{
						if (Operators.CompareString(((JObject)enumerator.Current)["version"].ToString(), this.m_RefWrapper, true) == 0)
						{
							if (this.classWrapper != null)
							{
								return "与 Forge 不兼容";
							}
							return null;
						}
					}
				}
				finally
				{
					IEnumerator<JToken> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				result = "没有可用版本";
			}
			return result;
		}

		// Token: 0x0600047F RID: 1151 RVA: 0x00004565 File Offset: 0x00002765
		private void CardFabric_PreviewSwap(object sender, ModBase.RouteEventArgs e)
		{
			if (this.LoadFabricGetError() != null)
			{
				e.proxyParameter = true;
			}
		}

		// Token: 0x06000480 RID: 1152 RVA: 0x00028C54 File Offset: 0x00026E54
		private void Fabric_Loaded()
		{
			try
			{
				if (ModDownload.m_ValueTag.State == ModBase.LoadState.Finished)
				{
					JArray jarray = (JArray)ModDownload.m_ValueTag.Output.Value["loader"];
					if (jarray.Count != 0)
					{
						this.PanFabric.Children.Clear();
						try
						{
							foreach (JToken jtoken in jarray)
							{
								this.PanFabric.Children.Add(ModDownloadLib.FabricDownloadListItem((JObject)jtoken, delegate(object sender, MouseButtonEventArgs e)
								{
									this.Fabric_Selected((MyListItem)sender, e);
								}));
							}
						}
						finally
						{
							IEnumerator<JToken> enumerator;
							if (enumerator != null)
							{
								enumerator.Dispose();
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "可视化 Fabric 安装版本列表出错", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000481 RID: 1153 RVA: 0x00028D38 File Offset: 0x00026F38
		private void Fabric_Selected(MyListItem sender, EventArgs e)
		{
			this.m_RegistryWrapper = NewLateBinding.LateIndexGet(sender.Tag, new object[]
			{
				"version"
			}, null).ToString();
			this.FabricApi_Loaded();
			this.CardFabric.IsSwaped = true;
			this.SelectReload();
			if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("HintInstallFabricApi", null))))
			{
				ModBase._ParamsState.Set("HintInstallFabricApi", true, false, null);
				ModMain.Hint("安装 Fabric 时通常还需要安装 Fabric API，在选择 Fabric 后就会显示其安装选项！", ModMain.HintType.Info, true);
			}
		}

		// Token: 0x06000482 RID: 1154 RVA: 0x00004576 File Offset: 0x00002776
		private void Fabric_Clear(object sender, MouseButtonEventArgs e)
		{
			this.m_RegistryWrapper = null;
			this._ProducerWrapper = null;
			this.CardFabric.IsSwaped = true;
			e.Handled = true;
			this.SelectReload();
		}

		// Token: 0x06000483 RID: 1155 RVA: 0x00028DC4 File Offset: 0x00026FC4
		private bool IsSuitableFabricApi(string DisplayName, string MinecraftVersion)
		{
			checked
			{
				bool result;
				try
				{
					if (DisplayName != null && MinecraftVersion != null)
					{
						DisplayName = DisplayName.ToLower();
						MinecraftVersion = MinecraftVersion.ToLower();
						if (DisplayName.StartsWith("[" + MinecraftVersion + "]"))
						{
							result = true;
						}
						else if (!DisplayName.Contains("/"))
						{
							result = false;
						}
						else
						{
							List<string> list = ModBase.RegexSearch(DisplayName.Split(new char[]
							{
								']'
							})[0], "[a-z/]+|[0-9/]+", RegexOptions.None);
							List<string> list2 = ModBase.RegexSearch(MinecraftVersion.Split(new char[]
							{
								']'
							})[0], "[a-z/]+|[0-9/]+", RegexOptions.None);
							int num = 0;
							while (list.Count - 1 >= num || list2.Count - 1 >= num)
							{
								string text = (list.Count - 1 < num) ? "-1" : list[num];
								string text2 = (list2.Count - 1 < num) ? "-1" : list2[num];
								if (!text.Contains("/"))
								{
									if (Operators.CompareString(text, text2, true) != 0)
									{
										return false;
									}
								}
								else if (!text.Contains(text2))
								{
									return false;
								}
								num++;
							}
							result = true;
						}
					}
					else
					{
						result = false;
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, string.Concat(new string[]
					{
						"判断 Fabric API 版本适配性出错（",
						DisplayName,
						", ",
						MinecraftVersion,
						"）"
					}), ModBase.LogLevel.Debug, "出现错误");
					result = false;
				}
				return result;
			}
		}

		// Token: 0x06000484 RID: 1156 RVA: 0x00028F58 File Offset: 0x00027158
		private string LoadFabricApiGetError()
		{
			string result;
			if (this.m_RegistryWrapper == null)
			{
				result = "需要安装 Fabric";
			}
			else if (this.LoadFabricApi.State.LoadingState == MyLoading.MyLoadingState.Run)
			{
				result = "正在获取版本列表……";
			}
			else if (this.LoadFabricApi.State.LoadingState == MyLoading.MyLoadingState.Error)
			{
				result = Conversions.ToString(Operators.ConcatenateObject("获取版本列表失败：", NewLateBinding.LateGet(NewLateBinding.LateGet(this.LoadFabricApi.State, null, "Error", new object[0], null, null, null), null, "Message", new object[0], null, null, null)));
			}
			else
			{
				try
				{
					foreach (ModDownload.DlCfFile dlCfFile in ModDownload._HelperTag.Output)
					{
						if (this.IsSuitableFabricApi(dlCfFile.m_CollectionProccesor, this.m_RefWrapper))
						{
							return null;
						}
					}
				}
				finally
				{
					List<ModDownload.DlCfFile>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				result = "没有可用版本";
			}
			return result;
		}

		// Token: 0x06000485 RID: 1157 RVA: 0x0000459F File Offset: 0x0000279F
		private void CardFabricApi_PreviewSwap(object sender, ModBase.RouteEventArgs e)
		{
			if (this.LoadFabricApiGetError() != null)
			{
				e.proxyParameter = true;
			}
		}

		// Token: 0x06000486 RID: 1158 RVA: 0x00029050 File Offset: 0x00027250
		private void FabricApi_Loaded()
		{
			try
			{
				if (ModDownload._HelperTag.State == ModBase.LoadState.Finished)
				{
					if (this.m_RefWrapper != null && this.m_RegistryWrapper != null)
					{
						List<ModDownload.DlCfFile> list = new List<ModDownload.DlCfFile>();
						try
						{
							foreach (ModDownload.DlCfFile dlCfFile in ModDownload._HelperTag.Output)
							{
								if (this.IsSuitableFabricApi(dlCfFile.m_CollectionProccesor, this.m_RefWrapper))
								{
									if (!dlCfFile.m_CollectionProccesor.StartsWith("["))
									{
										ModBase.Log("[Download] 已特判修改 Fabric API 显示名：" + dlCfFile.m_CollectionProccesor, ModBase.LogLevel.Debug, "出现错误");
										dlCfFile.m_CollectionProccesor = "[" + this.m_RefWrapper + "] " + dlCfFile.m_CollectionProccesor;
									}
									list.Add(dlCfFile);
								}
							}
						}
						finally
						{
							List<ModDownload.DlCfFile>.Enumerator enumerator;
							((IDisposable)enumerator).Dispose();
						}
						if (list.Count != 0)
						{
							list = ModBase.Sort<ModDownload.DlCfFile>(list, (PageDownloadInstall._Closure$__.$IR57-12 == null) ? (PageDownloadInstall._Closure$__.$IR57-12 = ((object a0, object a1) => ((PageDownloadInstall._Closure$__.$I57-0 == null) ? (PageDownloadInstall._Closure$__.$I57-0 = ((ModDownload.DlCfFile Left, ModDownload.DlCfFile Right) => DateTime.Compare(Left.m_ConsumerProccesor, Right.m_ConsumerProccesor) > 0)) : PageDownloadInstall._Closure$__.$I57-0)((ModDownload.DlCfFile)a0, (ModDownload.DlCfFile)a1))) : PageDownloadInstall._Closure$__.$IR57-12);
							this.PanFabricApi.Children.Clear();
							try
							{
								foreach (ModDownload.DlCfFile dlCfFile2 in list)
								{
									if (this.IsSuitableFabricApi(dlCfFile2.m_CollectionProccesor, this.m_RefWrapper))
									{
										this.PanFabricApi.Children.Add(ModDownloadLib.FabricApiDownloadListItem(dlCfFile2, delegate(object sender, MouseButtonEventArgs e)
										{
											this.FabricApi_Selected((MyListItem)sender, e);
										}));
									}
								}
							}
							finally
							{
								List<ModDownload.DlCfFile>.Enumerator enumerator2;
								((IDisposable)enumerator2).Dispose();
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "可视化 Fabric API 安装版本列表出错", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000487 RID: 1159 RVA: 0x000045B0 File Offset: 0x000027B0
		private void FabricApi_Selected(MyListItem sender, EventArgs e)
		{
			this._ProducerWrapper = (ModDownload.DlCfFile)sender.Tag;
			this.CardFabricApi.IsSwaped = true;
			this.SelectReload();
		}

		// Token: 0x06000488 RID: 1160 RVA: 0x000045D5 File Offset: 0x000027D5
		private void FabricApi_Clear(object sender, MouseButtonEventArgs e)
		{
			this._ProducerWrapper = null;
			this.CardFabricApi.IsSwaped = true;
			e.Handled = true;
			this.SelectReload();
		}

		// Token: 0x06000489 RID: 1161 RVA: 0x00029244 File Offset: 0x00027444
		private void BtnSelectStart_Click(object sender, EventArgs e)
		{
			if (((this.classWrapper == null && this.m_RegistryWrapper == null) || (!Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LaunchArgumentIndie", null), 0, true) && !Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LaunchArgumentIndie", null), 2, true)) || ModMain.MyMsgBox("你尚未开启版本隔离，这会导致多个 MC 共用同一个 Mod 文件夹。\r\n因此在切换 MC 版本时，MC 会因为读取到与当前版本不符的 Mod 而崩溃。\r\nPCL2 推荐你在开始下载前，在 设置 → 版本隔离 中开启版本隔离选项！", "版本隔离提示", "取消下载", "继续", "", false, true, false) != 1) && ModDownloadLib.McInstall(new ModDownloadLib.McInstallRequest
			{
				_ConnectionState = this.TextSelectName.Text,
				schemaState = this.serverWrapper,
				customerState = this.m_RefWrapper,
				_CallbackState = this.importerWrapper,
				observerState = this.classWrapper,
				_SingletonState = this.m_RegistryWrapper,
				contextState = this._ProducerWrapper,
				m_CollectionState = this._ProxyWrapper
			}))
			{
				this.ExitSelectPage();
			}
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x0600048A RID: 1162 RVA: 0x000045F7 File Offset: 0x000027F7
		// (set) Token: 0x0600048B RID: 1163 RVA: 0x000045FF File Offset: 0x000027FF
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x0600048C RID: 1164 RVA: 0x00004608 File Offset: 0x00002808
		// (set) Token: 0x0600048D RID: 1165 RVA: 0x00004610 File Offset: 0x00002810
		internal virtual VirtualizingStackPanel PanMinecraft { get; set; }

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x0600048E RID: 1166 RVA: 0x00004619 File Offset: 0x00002819
		// (set) Token: 0x0600048F RID: 1167 RVA: 0x00004621 File Offset: 0x00002821
		internal virtual StackPanel PanSelect { get; set; }

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x06000490 RID: 1168 RVA: 0x0000462A File Offset: 0x0000282A
		// (set) Token: 0x06000491 RID: 1169 RVA: 0x00004632 File Offset: 0x00002832
		internal virtual MyHint HintFabricAPI { get; set; }

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x06000492 RID: 1170 RVA: 0x0000463B File Offset: 0x0000283B
		// (set) Token: 0x06000493 RID: 1171 RVA: 0x00004643 File Offset: 0x00002843
		internal virtual MyListItem ItemSelect { get; set; }

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x06000494 RID: 1172 RVA: 0x0000464C File Offset: 0x0000284C
		// (set) Token: 0x06000495 RID: 1173 RVA: 0x00029338 File Offset: 0x00027538
		internal virtual MyButton BtnSelectStart
		{
			[CompilerGenerated]
			get
			{
				return this.m_ModelRepository;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnSelectStart_Click);
				MyButton modelRepository = this.m_ModelRepository;
				if (modelRepository != null)
				{
					modelRepository.RevertResolver(obj);
				}
				this.m_ModelRepository = value;
				modelRepository = this.m_ModelRepository;
				if (modelRepository != null)
				{
					modelRepository.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x06000496 RID: 1174 RVA: 0x00004654 File Offset: 0x00002854
		// (set) Token: 0x06000497 RID: 1175 RVA: 0x0002937C File Offset: 0x0002757C
		internal virtual MyTextBox TextSelectName
		{
			[CompilerGenerated]
			get
			{
				return this._WrapperRepository;
			}
			[CompilerGenerated]
			set
			{
				TextChangedEventHandler value2 = new TextChangedEventHandler(this.TextSelectName_TextChanged);
				MyTextBox.ValidateChangedEventHandler obj = new MyTextBox.ValidateChangedEventHandler(this.TextSelectName_ValidateChanged);
				MyTextBox wrapperRepository = this._WrapperRepository;
				if (wrapperRepository != null)
				{
					wrapperRepository.TextChanged -= value2;
					MyTextBox.RevertWrapper(obj);
				}
				this._WrapperRepository = value;
				wrapperRepository = this._WrapperRepository;
				if (wrapperRepository != null)
				{
					wrapperRepository.TextChanged += value2;
					MyTextBox.PostWrapper(obj);
				}
			}
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x06000498 RID: 1176 RVA: 0x0000465C File Offset: 0x0000285C
		// (set) Token: 0x06000499 RID: 1177 RVA: 0x000293D8 File Offset: 0x000275D8
		internal virtual MyCard CardMinecraft
		{
			[CompilerGenerated]
			get
			{
				return this.m_RepositoryRepository;
			}
			[CompilerGenerated]
			set
			{
				MyCard.PreviewSwapEventHandler obj = new MyCard.PreviewSwapEventHandler(this.CardMinecraft_PreviewSwap);
				MyCard repositoryRepository = this.m_RepositoryRepository;
				if (repositoryRepository != null)
				{
					repositoryRepository.LogoutModel(obj);
				}
				this.m_RepositoryRepository = value;
				repositoryRepository = this.m_RepositoryRepository;
				if (repositoryRepository != null)
				{
					repositoryRepository.RemoveModel(obj);
				}
			}
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x0600049A RID: 1178 RVA: 0x00004664 File Offset: 0x00002864
		// (set) Token: 0x0600049B RID: 1179 RVA: 0x0000466C File Offset: 0x0000286C
		internal virtual Grid PanMinecraftInfo { get; set; }

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x0600049C RID: 1180 RVA: 0x00004675 File Offset: 0x00002875
		// (set) Token: 0x0600049D RID: 1181 RVA: 0x0000467D File Offset: 0x0000287D
		internal virtual Image ImgMinecraft { get; set; }

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x0600049E RID: 1182 RVA: 0x00004686 File Offset: 0x00002886
		// (set) Token: 0x0600049F RID: 1183 RVA: 0x0000468E File Offset: 0x0000288E
		internal virtual TextBlock LabMinecraft { get; set; }

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x060004A0 RID: 1184 RVA: 0x00004697 File Offset: 0x00002897
		// (set) Token: 0x060004A1 RID: 1185 RVA: 0x0002941C File Offset: 0x0002761C
		internal virtual MyCard CardOptiFine
		{
			[CompilerGenerated]
			get
			{
				return this.prototypeRepository;
			}
			[CompilerGenerated]
			set
			{
				MyCard.SwapEventHandler obj = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.SelectReload();
				};
				MyCard.PreviewSwapEventHandler obj2 = new MyCard.PreviewSwapEventHandler(this.CardOptiFine_PreviewSwap);
				MyCard myCard = this.prototypeRepository;
				if (myCard != null)
				{
					myCard.ForgotModel(obj);
					myCard.LogoutModel(obj2);
				}
				this.prototypeRepository = value;
				myCard = this.prototypeRepository;
				if (myCard != null)
				{
					myCard.ReflectModel(obj);
					myCard.RemoveModel(obj2);
				}
			}
		}

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x060004A2 RID: 1186 RVA: 0x0000469F File Offset: 0x0000289F
		// (set) Token: 0x060004A3 RID: 1187 RVA: 0x000046A7 File Offset: 0x000028A7
		internal virtual MyHint HintOptiFine { get; set; }

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x060004A4 RID: 1188 RVA: 0x000046B0 File Offset: 0x000028B0
		// (set) Token: 0x060004A5 RID: 1189 RVA: 0x000046B8 File Offset: 0x000028B8
		internal virtual StackPanel PanOptiFine { get; set; }

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x060004A6 RID: 1190 RVA: 0x000046C1 File Offset: 0x000028C1
		// (set) Token: 0x060004A7 RID: 1191 RVA: 0x000046C9 File Offset: 0x000028C9
		internal virtual Grid PanOptiFineInfo { get; set; }

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x060004A8 RID: 1192 RVA: 0x000046D2 File Offset: 0x000028D2
		// (set) Token: 0x060004A9 RID: 1193 RVA: 0x000046DA File Offset: 0x000028DA
		internal virtual Image ImgOptiFine { get; set; }

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x060004AA RID: 1194 RVA: 0x000046E3 File Offset: 0x000028E3
		// (set) Token: 0x060004AB RID: 1195 RVA: 0x000046EB File Offset: 0x000028EB
		internal virtual TextBlock LabOptiFine { get; set; }

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x060004AC RID: 1196 RVA: 0x000046F4 File Offset: 0x000028F4
		// (set) Token: 0x060004AD RID: 1197 RVA: 0x0002947C File Offset: 0x0002767C
		internal virtual Grid BtnOptiFineClear
		{
			[CompilerGenerated]
			get
			{
				return this._ParameterRepository;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = new MouseButtonEventHandler(this.OptiFine_Clear);
				Grid parameterRepository = this._ParameterRepository;
				if (parameterRepository != null)
				{
					parameterRepository.MouseLeftButtonUp -= value2;
				}
				this._ParameterRepository = value;
				parameterRepository = this._ParameterRepository;
				if (parameterRepository != null)
				{
					parameterRepository.MouseLeftButtonUp += value2;
				}
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x060004AE RID: 1198 RVA: 0x000046FC File Offset: 0x000028FC
		// (set) Token: 0x060004AF RID: 1199 RVA: 0x00004704 File Offset: 0x00002904
		internal virtual Path BtnOptiFineClearInner { get; set; }

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x060004B0 RID: 1200 RVA: 0x0000470D File Offset: 0x0000290D
		// (set) Token: 0x060004B1 RID: 1201 RVA: 0x000294C0 File Offset: 0x000276C0
		internal virtual MyCard CardForge
		{
			[CompilerGenerated]
			get
			{
				return this.m_ReponseRepository;
			}
			[CompilerGenerated]
			set
			{
				MyCard.SwapEventHandler obj = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.SelectReload();
				};
				MyCard.PreviewSwapEventHandler obj2 = new MyCard.PreviewSwapEventHandler(this.CardForge_PreviewSwap);
				MyCard reponseRepository = this.m_ReponseRepository;
				if (reponseRepository != null)
				{
					reponseRepository.ForgotModel(obj);
					reponseRepository.LogoutModel(obj2);
				}
				this.m_ReponseRepository = value;
				reponseRepository = this.m_ReponseRepository;
				if (reponseRepository != null)
				{
					reponseRepository.ReflectModel(obj);
					reponseRepository.RemoveModel(obj2);
				}
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x060004B2 RID: 1202 RVA: 0x00004715 File Offset: 0x00002915
		// (set) Token: 0x060004B3 RID: 1203 RVA: 0x0000471D File Offset: 0x0000291D
		internal virtual StackPanel PanForge { get; set; }

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x060004B4 RID: 1204 RVA: 0x00004726 File Offset: 0x00002926
		// (set) Token: 0x060004B5 RID: 1205 RVA: 0x0000472E File Offset: 0x0000292E
		internal virtual Grid PanForgeInfo { get; set; }

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x060004B6 RID: 1206 RVA: 0x00004737 File Offset: 0x00002937
		// (set) Token: 0x060004B7 RID: 1207 RVA: 0x0000473F File Offset: 0x0000293F
		internal virtual Image ImgForge { get; set; }

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x060004B8 RID: 1208 RVA: 0x00004748 File Offset: 0x00002948
		// (set) Token: 0x060004B9 RID: 1209 RVA: 0x00004750 File Offset: 0x00002950
		internal virtual TextBlock LabForge { get; set; }

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x060004BA RID: 1210 RVA: 0x00004759 File Offset: 0x00002959
		// (set) Token: 0x060004BB RID: 1211 RVA: 0x00029520 File Offset: 0x00027720
		internal virtual Grid BtnForgeClear
		{
			[CompilerGenerated]
			get
			{
				return this.paramsRepository;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = new MouseButtonEventHandler(this.Forge_Clear);
				Grid grid = this.paramsRepository;
				if (grid != null)
				{
					grid.MouseLeftButtonUp -= value2;
				}
				this.paramsRepository = value;
				grid = this.paramsRepository;
				if (grid != null)
				{
					grid.MouseLeftButtonUp += value2;
				}
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x060004BC RID: 1212 RVA: 0x00004761 File Offset: 0x00002961
		// (set) Token: 0x060004BD RID: 1213 RVA: 0x00004769 File Offset: 0x00002969
		internal virtual Path BtnForgeClearInner { get; set; }

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x060004BE RID: 1214 RVA: 0x00004772 File Offset: 0x00002972
		// (set) Token: 0x060004BF RID: 1215 RVA: 0x00029564 File Offset: 0x00027764
		internal virtual MyCard CardFabric
		{
			[CompilerGenerated]
			get
			{
				return this.adapterRepository;
			}
			[CompilerGenerated]
			set
			{
				MyCard.SwapEventHandler obj = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.SelectReload();
				};
				MyCard.PreviewSwapEventHandler obj2 = new MyCard.PreviewSwapEventHandler(this.CardFabric_PreviewSwap);
				MyCard myCard = this.adapterRepository;
				if (myCard != null)
				{
					myCard.ForgotModel(obj);
					myCard.LogoutModel(obj2);
				}
				this.adapterRepository = value;
				myCard = this.adapterRepository;
				if (myCard != null)
				{
					myCard.ReflectModel(obj);
					myCard.RemoveModel(obj2);
				}
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x060004C0 RID: 1216 RVA: 0x0000477A File Offset: 0x0000297A
		// (set) Token: 0x060004C1 RID: 1217 RVA: 0x00004782 File Offset: 0x00002982
		internal virtual MyHint HintFabric { get; set; }

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x060004C2 RID: 1218 RVA: 0x0000478B File Offset: 0x0000298B
		// (set) Token: 0x060004C3 RID: 1219 RVA: 0x00004793 File Offset: 0x00002993
		internal virtual StackPanel PanFabric { get; set; }

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x060004C4 RID: 1220 RVA: 0x0000479C File Offset: 0x0000299C
		// (set) Token: 0x060004C5 RID: 1221 RVA: 0x000047A4 File Offset: 0x000029A4
		internal virtual Grid PanFabricInfo { get; set; }

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x060004C6 RID: 1222 RVA: 0x000047AD File Offset: 0x000029AD
		// (set) Token: 0x060004C7 RID: 1223 RVA: 0x000047B5 File Offset: 0x000029B5
		internal virtual Image ImgFabric { get; set; }

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x060004C8 RID: 1224 RVA: 0x000047BE File Offset: 0x000029BE
		// (set) Token: 0x060004C9 RID: 1225 RVA: 0x000047C6 File Offset: 0x000029C6
		internal virtual TextBlock LabFabric { get; set; }

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x060004CA RID: 1226 RVA: 0x000047CF File Offset: 0x000029CF
		// (set) Token: 0x060004CB RID: 1227 RVA: 0x000295C4 File Offset: 0x000277C4
		internal virtual Grid BtnFabricClear
		{
			[CompilerGenerated]
			get
			{
				return this.specificationRepository;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = new MouseButtonEventHandler(this.Fabric_Clear);
				Grid grid = this.specificationRepository;
				if (grid != null)
				{
					grid.MouseLeftButtonUp -= value2;
				}
				this.specificationRepository = value;
				grid = this.specificationRepository;
				if (grid != null)
				{
					grid.MouseLeftButtonUp += value2;
				}
			}
		}

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x060004CC RID: 1228 RVA: 0x000047D7 File Offset: 0x000029D7
		// (set) Token: 0x060004CD RID: 1229 RVA: 0x000047DF File Offset: 0x000029DF
		internal virtual Path BtnFabricClearInner { get; set; }

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x060004CE RID: 1230 RVA: 0x000047E8 File Offset: 0x000029E8
		// (set) Token: 0x060004CF RID: 1231 RVA: 0x00029608 File Offset: 0x00027808
		internal virtual MyCard CardFabricApi
		{
			[CompilerGenerated]
			get
			{
				return this.clientRepository;
			}
			[CompilerGenerated]
			set
			{
				MyCard.SwapEventHandler obj = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.SelectReload();
				};
				MyCard.PreviewSwapEventHandler obj2 = new MyCard.PreviewSwapEventHandler(this.CardFabricApi_PreviewSwap);
				MyCard myCard = this.clientRepository;
				if (myCard != null)
				{
					myCard.ForgotModel(obj);
					myCard.LogoutModel(obj2);
				}
				this.clientRepository = value;
				myCard = this.clientRepository;
				if (myCard != null)
				{
					myCard.ReflectModel(obj);
					myCard.RemoveModel(obj2);
				}
			}
		}

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x060004D0 RID: 1232 RVA: 0x000047F0 File Offset: 0x000029F0
		// (set) Token: 0x060004D1 RID: 1233 RVA: 0x000047F8 File Offset: 0x000029F8
		internal virtual StackPanel PanFabricApi { get; set; }

		// Token: 0x1700009C RID: 156
		// (get) Token: 0x060004D2 RID: 1234 RVA: 0x00004801 File Offset: 0x00002A01
		// (set) Token: 0x060004D3 RID: 1235 RVA: 0x00004809 File Offset: 0x00002A09
		internal virtual Grid PanFabricApiInfo { get; set; }

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x060004D4 RID: 1236 RVA: 0x00004812 File Offset: 0x00002A12
		// (set) Token: 0x060004D5 RID: 1237 RVA: 0x0000481A File Offset: 0x00002A1A
		internal virtual Image ImgFabricApi { get; set; }

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x060004D6 RID: 1238 RVA: 0x00004823 File Offset: 0x00002A23
		// (set) Token: 0x060004D7 RID: 1239 RVA: 0x0000482B File Offset: 0x00002A2B
		internal virtual TextBlock LabFabricApi { get; set; }

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x060004D8 RID: 1240 RVA: 0x00004834 File Offset: 0x00002A34
		// (set) Token: 0x060004D9 RID: 1241 RVA: 0x00029668 File Offset: 0x00027868
		internal virtual Grid BtnFabricApiClear
		{
			[CompilerGenerated]
			get
			{
				return this.mapRepository;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = new MouseButtonEventHandler(this.FabricApi_Clear);
				Grid grid = this.mapRepository;
				if (grid != null)
				{
					grid.MouseLeftButtonUp -= value2;
				}
				this.mapRepository = value;
				grid = this.mapRepository;
				if (grid != null)
				{
					grid.MouseLeftButtonUp += value2;
				}
			}
		}

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x060004DA RID: 1242 RVA: 0x0000483C File Offset: 0x00002A3C
		// (set) Token: 0x060004DB RID: 1243 RVA: 0x00004844 File Offset: 0x00002A44
		internal virtual Path BtnFabricApiClearInner { get; set; }

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x060004DC RID: 1244 RVA: 0x0000484D File Offset: 0x00002A4D
		// (set) Token: 0x060004DD RID: 1245 RVA: 0x000296AC File Offset: 0x000278AC
		internal virtual MyCard CardLiteLoader
		{
			[CompilerGenerated]
			get
			{
				return this._AlgoRepository;
			}
			[CompilerGenerated]
			set
			{
				MyCard.SwapEventHandler obj = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.SelectReload();
				};
				MyCard.PreviewSwapEventHandler obj2 = new MyCard.PreviewSwapEventHandler(this.CardLiteLoader_PreviewSwap);
				MyCard algoRepository = this._AlgoRepository;
				if (algoRepository != null)
				{
					algoRepository.ForgotModel(obj);
					algoRepository.LogoutModel(obj2);
				}
				this._AlgoRepository = value;
				algoRepository = this._AlgoRepository;
				if (algoRepository != null)
				{
					algoRepository.ReflectModel(obj);
					algoRepository.RemoveModel(obj2);
				}
			}
		}

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x060004DE RID: 1246 RVA: 0x00004855 File Offset: 0x00002A55
		// (set) Token: 0x060004DF RID: 1247 RVA: 0x0000485D File Offset: 0x00002A5D
		internal virtual StackPanel PanLiteLoader { get; set; }

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x060004E0 RID: 1248 RVA: 0x00004866 File Offset: 0x00002A66
		// (set) Token: 0x060004E1 RID: 1249 RVA: 0x0000486E File Offset: 0x00002A6E
		internal virtual Grid PanLiteLoaderInfo { get; set; }

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x060004E2 RID: 1250 RVA: 0x00004877 File Offset: 0x00002A77
		// (set) Token: 0x060004E3 RID: 1251 RVA: 0x0000487F File Offset: 0x00002A7F
		internal virtual Image ImgLiteLoader { get; set; }

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x060004E4 RID: 1252 RVA: 0x00004888 File Offset: 0x00002A88
		// (set) Token: 0x060004E5 RID: 1253 RVA: 0x00004890 File Offset: 0x00002A90
		internal virtual TextBlock LabLiteLoader { get; set; }

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x060004E6 RID: 1254 RVA: 0x00004899 File Offset: 0x00002A99
		// (set) Token: 0x060004E7 RID: 1255 RVA: 0x0002970C File Offset: 0x0002790C
		internal virtual Grid BtnLiteLoaderClear
		{
			[CompilerGenerated]
			get
			{
				return this.iteratorRepository;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = new MouseButtonEventHandler(this.LiteLoader_Clear);
				Grid grid = this.iteratorRepository;
				if (grid != null)
				{
					grid.MouseLeftButtonUp -= value2;
				}
				this.iteratorRepository = value;
				grid = this.iteratorRepository;
				if (grid != null)
				{
					grid.MouseLeftButtonUp += value2;
				}
			}
		}

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x060004E8 RID: 1256 RVA: 0x000048A1 File Offset: 0x00002AA1
		// (set) Token: 0x060004E9 RID: 1257 RVA: 0x000048A9 File Offset: 0x00002AA9
		internal virtual Path BtnLiteLoaderClearInner { get; set; }

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x060004EA RID: 1258 RVA: 0x000048B2 File Offset: 0x00002AB2
		// (set) Token: 0x060004EB RID: 1259 RVA: 0x000048BA File Offset: 0x00002ABA
		internal virtual MyCard PanLoad { get; set; }

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x060004EC RID: 1260 RVA: 0x000048C3 File Offset: 0x00002AC3
		// (set) Token: 0x060004ED RID: 1261 RVA: 0x000048CB File Offset: 0x00002ACB
		internal virtual MyLoading LoadMinecraft { get; set; }

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x060004EE RID: 1262 RVA: 0x000048D4 File Offset: 0x00002AD4
		// (set) Token: 0x060004EF RID: 1263 RVA: 0x00029750 File Offset: 0x00027950
		internal virtual MyLoading LoadOptiFine
		{
			[CompilerGenerated]
			get
			{
				return this.recordRepository;
			}
			[CompilerGenerated]
			set
			{
				MyLoading.StateChangedEventHandler obj = delegate(object a0, MyLoading.MyLoadingState a1, MyLoading.MyLoadingState a2)
				{
					this.SelectReload();
				};
				MyLoading.StateChangedEventHandler obj2 = delegate(object a0, MyLoading.MyLoadingState a1, MyLoading.MyLoadingState a2)
				{
					this.OptiFine_Loaded();
				};
				MyLoading myLoading = this.recordRepository;
				if (myLoading != null)
				{
					myLoading.RemoveWrapper(obj);
					myLoading.RemoveWrapper(obj2);
				}
				this.recordRepository = value;
				myLoading = this.recordRepository;
				if (myLoading != null)
				{
					myLoading.InstantiateWrapper(obj);
					myLoading.InstantiateWrapper(obj2);
				}
			}
		}

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x060004F0 RID: 1264 RVA: 0x000048DC File Offset: 0x00002ADC
		// (set) Token: 0x060004F1 RID: 1265 RVA: 0x000297B0 File Offset: 0x000279B0
		internal virtual MyLoading LoadForge
		{
			[CompilerGenerated]
			get
			{
				return this.visitorRepository;
			}
			[CompilerGenerated]
			set
			{
				MyLoading.StateChangedEventHandler obj = delegate(object a0, MyLoading.MyLoadingState a1, MyLoading.MyLoadingState a2)
				{
					this.SelectReload();
				};
				MyLoading.StateChangedEventHandler obj2 = delegate(object a0, MyLoading.MyLoadingState a1, MyLoading.MyLoadingState a2)
				{
					this.Forge_Loaded();
				};
				MyLoading myLoading = this.visitorRepository;
				if (myLoading != null)
				{
					myLoading.RemoveWrapper(obj);
					myLoading.RemoveWrapper(obj2);
				}
				this.visitorRepository = value;
				myLoading = this.visitorRepository;
				if (myLoading != null)
				{
					myLoading.InstantiateWrapper(obj);
					myLoading.InstantiateWrapper(obj2);
				}
			}
		}

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x060004F2 RID: 1266 RVA: 0x000048E4 File Offset: 0x00002AE4
		// (set) Token: 0x060004F3 RID: 1267 RVA: 0x00029810 File Offset: 0x00027A10
		internal virtual MyLoading LoadLiteLoader
		{
			[CompilerGenerated]
			get
			{
				return this.helperRepository;
			}
			[CompilerGenerated]
			set
			{
				MyLoading.StateChangedEventHandler obj = delegate(object a0, MyLoading.MyLoadingState a1, MyLoading.MyLoadingState a2)
				{
					this.SelectReload();
				};
				MyLoading.StateChangedEventHandler obj2 = delegate(object a0, MyLoading.MyLoadingState a1, MyLoading.MyLoadingState a2)
				{
					this.LiteLoader_Loaded();
				};
				MyLoading myLoading = this.helperRepository;
				if (myLoading != null)
				{
					myLoading.RemoveWrapper(obj);
					myLoading.RemoveWrapper(obj2);
				}
				this.helperRepository = value;
				myLoading = this.helperRepository;
				if (myLoading != null)
				{
					myLoading.InstantiateWrapper(obj);
					myLoading.InstantiateWrapper(obj2);
				}
			}
		}

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x060004F4 RID: 1268 RVA: 0x000048EC File Offset: 0x00002AEC
		// (set) Token: 0x060004F5 RID: 1269 RVA: 0x00029870 File Offset: 0x00027A70
		internal virtual MyLoading LoadFabric
		{
			[CompilerGenerated]
			get
			{
				return this._ParamRepository;
			}
			[CompilerGenerated]
			set
			{
				MyLoading.StateChangedEventHandler obj = delegate(object a0, MyLoading.MyLoadingState a1, MyLoading.MyLoadingState a2)
				{
					this.SelectReload();
				};
				MyLoading.StateChangedEventHandler obj2 = delegate(object a0, MyLoading.MyLoadingState a1, MyLoading.MyLoadingState a2)
				{
					this.Fabric_Loaded();
				};
				MyLoading paramRepository = this._ParamRepository;
				if (paramRepository != null)
				{
					paramRepository.RemoveWrapper(obj);
					paramRepository.RemoveWrapper(obj2);
				}
				this._ParamRepository = value;
				paramRepository = this._ParamRepository;
				if (paramRepository != null)
				{
					paramRepository.InstantiateWrapper(obj);
					paramRepository.InstantiateWrapper(obj2);
				}
			}
		}

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x060004F6 RID: 1270 RVA: 0x000048F4 File Offset: 0x00002AF4
		// (set) Token: 0x060004F7 RID: 1271 RVA: 0x000298D0 File Offset: 0x00027AD0
		internal virtual MyLoading LoadFabricApi
		{
			[CompilerGenerated]
			get
			{
				return this.baseRepository;
			}
			[CompilerGenerated]
			set
			{
				MyLoading.StateChangedEventHandler obj = delegate(object a0, MyLoading.MyLoadingState a1, MyLoading.MyLoadingState a2)
				{
					this.SelectReload();
				};
				MyLoading.StateChangedEventHandler obj2 = delegate(object a0, MyLoading.MyLoadingState a1, MyLoading.MyLoadingState a2)
				{
					this.FabricApi_Loaded();
				};
				MyLoading myLoading = this.baseRepository;
				if (myLoading != null)
				{
					myLoading.RemoveWrapper(obj);
					myLoading.RemoveWrapper(obj2);
				}
				this.baseRepository = value;
				myLoading = this.baseRepository;
				if (myLoading != null)
				{
					myLoading.InstantiateWrapper(obj);
					myLoading.InstantiateWrapper(obj2);
				}
			}
		}

		// Token: 0x060004F8 RID: 1272 RVA: 0x00029930 File Offset: 0x00027B30
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this._ProductRepository)
			{
				this._ProductRepository = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagedownload/pagedownloadinstall.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x060004F9 RID: 1273 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060004FA RID: 1274 RVA: 0x00029960 File Offset: 0x00027B60
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanMinecraft = (VirtualizingStackPanel)target;
				return;
			}
			if (connectionId == 3)
			{
				this.PanSelect = (StackPanel)target;
				return;
			}
			if (connectionId == 4)
			{
				this.HintFabricAPI = (MyHint)target;
				return;
			}
			if (connectionId == 5)
			{
				this.ItemSelect = (MyListItem)target;
				return;
			}
			if (connectionId == 6)
			{
				this.BtnSelectStart = (MyButton)target;
				return;
			}
			if (connectionId == 7)
			{
				this.TextSelectName = (MyTextBox)target;
				return;
			}
			if (connectionId == 8)
			{
				this.CardMinecraft = (MyCard)target;
				return;
			}
			if (connectionId == 9)
			{
				this.PanMinecraftInfo = (Grid)target;
				return;
			}
			if (connectionId == 10)
			{
				this.ImgMinecraft = (Image)target;
				return;
			}
			if (connectionId == 11)
			{
				this.LabMinecraft = (TextBlock)target;
				return;
			}
			if (connectionId == 12)
			{
				this.CardOptiFine = (MyCard)target;
				return;
			}
			if (connectionId == 13)
			{
				this.HintOptiFine = (MyHint)target;
				return;
			}
			if (connectionId == 14)
			{
				this.PanOptiFine = (StackPanel)target;
				return;
			}
			if (connectionId == 15)
			{
				this.PanOptiFineInfo = (Grid)target;
				return;
			}
			if (connectionId == 16)
			{
				this.ImgOptiFine = (Image)target;
				return;
			}
			if (connectionId == 17)
			{
				this.LabOptiFine = (TextBlock)target;
				return;
			}
			if (connectionId == 18)
			{
				this.BtnOptiFineClear = (Grid)target;
				return;
			}
			if (connectionId == 19)
			{
				this.BtnOptiFineClearInner = (Path)target;
				return;
			}
			if (connectionId == 20)
			{
				this.CardForge = (MyCard)target;
				return;
			}
			if (connectionId == 21)
			{
				this.PanForge = (StackPanel)target;
				return;
			}
			if (connectionId == 22)
			{
				this.PanForgeInfo = (Grid)target;
				return;
			}
			if (connectionId == 23)
			{
				this.ImgForge = (Image)target;
				return;
			}
			if (connectionId == 24)
			{
				this.LabForge = (TextBlock)target;
				return;
			}
			if (connectionId == 25)
			{
				this.BtnForgeClear = (Grid)target;
				return;
			}
			if (connectionId == 26)
			{
				this.BtnForgeClearInner = (Path)target;
				return;
			}
			if (connectionId == 27)
			{
				this.CardFabric = (MyCard)target;
				return;
			}
			if (connectionId == 28)
			{
				this.HintFabric = (MyHint)target;
				return;
			}
			if (connectionId == 29)
			{
				this.PanFabric = (StackPanel)target;
				return;
			}
			if (connectionId == 30)
			{
				this.PanFabricInfo = (Grid)target;
				return;
			}
			if (connectionId == 31)
			{
				this.ImgFabric = (Image)target;
				return;
			}
			if (connectionId == 32)
			{
				this.LabFabric = (TextBlock)target;
				return;
			}
			if (connectionId == 33)
			{
				this.BtnFabricClear = (Grid)target;
				return;
			}
			if (connectionId == 34)
			{
				this.BtnFabricClearInner = (Path)target;
				return;
			}
			if (connectionId == 35)
			{
				this.CardFabricApi = (MyCard)target;
				return;
			}
			if (connectionId == 36)
			{
				this.PanFabricApi = (StackPanel)target;
				return;
			}
			if (connectionId == 37)
			{
				this.PanFabricApiInfo = (Grid)target;
				return;
			}
			if (connectionId == 38)
			{
				this.ImgFabricApi = (Image)target;
				return;
			}
			if (connectionId == 39)
			{
				this.LabFabricApi = (TextBlock)target;
				return;
			}
			if (connectionId == 40)
			{
				this.BtnFabricApiClear = (Grid)target;
				return;
			}
			if (connectionId == 41)
			{
				this.BtnFabricApiClearInner = (Path)target;
				return;
			}
			if (connectionId == 42)
			{
				this.CardLiteLoader = (MyCard)target;
				return;
			}
			if (connectionId == 43)
			{
				this.PanLiteLoader = (StackPanel)target;
				return;
			}
			if (connectionId == 44)
			{
				this.PanLiteLoaderInfo = (Grid)target;
				return;
			}
			if (connectionId == 45)
			{
				this.ImgLiteLoader = (Image)target;
				return;
			}
			if (connectionId == 46)
			{
				this.LabLiteLoader = (TextBlock)target;
				return;
			}
			if (connectionId == 47)
			{
				this.BtnLiteLoaderClear = (Grid)target;
				return;
			}
			if (connectionId == 48)
			{
				this.BtnLiteLoaderClearInner = (Path)target;
				return;
			}
			if (connectionId == 49)
			{
				this.PanLoad = (MyCard)target;
				return;
			}
			if (connectionId == 50)
			{
				this.LoadMinecraft = (MyLoading)target;
				return;
			}
			if (connectionId == 51)
			{
				this.LoadOptiFine = (MyLoading)target;
				return;
			}
			if (connectionId == 52)
			{
				this.LoadForge = (MyLoading)target;
				return;
			}
			if (connectionId == 53)
			{
				this.LoadLiteLoader = (MyLoading)target;
				return;
			}
			if (connectionId == 54)
			{
				this.LoadFabric = (MyLoading)target;
				return;
			}
			if (connectionId == 55)
			{
				this.LoadFabricApi = (MyLoading)target;
				return;
			}
			this._ProductRepository = true;
		}

		// Token: 0x04000220 RID: 544
		private bool methodWrapper;

		// Token: 0x04000221 RID: 545
		private bool annotationWrapper;

		// Token: 0x04000222 RID: 546
		private bool _InterceptorWrapper;

		// Token: 0x04000223 RID: 547
		private string m_RefWrapper;

		// Token: 0x04000224 RID: 548
		private string serverWrapper;

		// Token: 0x04000225 RID: 549
		private string _ServiceWrapper;

		// Token: 0x04000226 RID: 550
		private ModDownload.DlOptiFineListEntry importerWrapper;

		// Token: 0x04000227 RID: 551
		private ModDownload.DlLiteLoaderListEntry _ProxyWrapper;

		// Token: 0x04000228 RID: 552
		private ModDownload.DlForgeVersionEntry classWrapper;

		// Token: 0x04000229 RID: 553
		private string m_RegistryWrapper;

		// Token: 0x0400022A RID: 554
		private ModDownload.DlCfFile _ProducerWrapper;

		// Token: 0x0400022B RID: 555
		private bool m_CandidateWrapper;

		// Token: 0x0400022C RID: 556
		private bool m_SetterWrapper;

		// Token: 0x0400022D RID: 557
		[CompilerGenerated]
		[AccessedThroughProperty("PanBack")]
		private MyScrollViewer mappingWrapper;

		// Token: 0x0400022E RID: 558
		[CompilerGenerated]
		[AccessedThroughProperty("PanMinecraft")]
		private VirtualizingStackPanel dispatcherWrapper;

		// Token: 0x0400022F RID: 559
		[CompilerGenerated]
		[AccessedThroughProperty("PanSelect")]
		private StackPanel messageWrapper;

		// Token: 0x04000230 RID: 560
		[AccessedThroughProperty("HintFabricAPI")]
		[CompilerGenerated]
		private MyHint _StatusWrapper;

		// Token: 0x04000231 RID: 561
		[AccessedThroughProperty("ItemSelect")]
		[CompilerGenerated]
		private MyListItem _ProcWrapper;

		// Token: 0x04000232 RID: 562
		[CompilerGenerated]
		[AccessedThroughProperty("BtnSelectStart")]
		private MyButton m_ModelRepository;

		// Token: 0x04000233 RID: 563
		[AccessedThroughProperty("TextSelectName")]
		[CompilerGenerated]
		private MyTextBox _WrapperRepository;

		// Token: 0x04000234 RID: 564
		[AccessedThroughProperty("CardMinecraft")]
		[CompilerGenerated]
		private MyCard m_RepositoryRepository;

		// Token: 0x04000235 RID: 565
		[CompilerGenerated]
		[AccessedThroughProperty("PanMinecraftInfo")]
		private Grid resolverRepository;

		// Token: 0x04000236 RID: 566
		[CompilerGenerated]
		[AccessedThroughProperty("ImgMinecraft")]
		private Image _TagRepository;

		// Token: 0x04000237 RID: 567
		[AccessedThroughProperty("LabMinecraft")]
		[CompilerGenerated]
		private TextBlock _ComparatorRepository;

		// Token: 0x04000238 RID: 568
		[CompilerGenerated]
		[AccessedThroughProperty("CardOptiFine")]
		private MyCard prototypeRepository;

		// Token: 0x04000239 RID: 569
		[CompilerGenerated]
		[AccessedThroughProperty("HintOptiFine")]
		private MyHint _IssuerRepository;

		// Token: 0x0400023A RID: 570
		[AccessedThroughProperty("PanOptiFine")]
		[CompilerGenerated]
		private StackPanel m_RequestRepository;

		// Token: 0x0400023B RID: 571
		[AccessedThroughProperty("PanOptiFineInfo")]
		[CompilerGenerated]
		private Grid accountRepository;

		// Token: 0x0400023C RID: 572
		[CompilerGenerated]
		[AccessedThroughProperty("ImgOptiFine")]
		private Image _StateRepository;

		// Token: 0x0400023D RID: 573
		[CompilerGenerated]
		[AccessedThroughProperty("LabOptiFine")]
		private TextBlock _ProccesorRepository;

		// Token: 0x0400023E RID: 574
		[CompilerGenerated]
		[AccessedThroughProperty("BtnOptiFineClear")]
		private Grid _ParameterRepository;

		// Token: 0x0400023F RID: 575
		[CompilerGenerated]
		[AccessedThroughProperty("BtnOptiFineClearInner")]
		private Path authenticationRepository;

		// Token: 0x04000240 RID: 576
		[CompilerGenerated]
		[AccessedThroughProperty("CardForge")]
		private MyCard m_ReponseRepository;

		// Token: 0x04000241 RID: 577
		[AccessedThroughProperty("PanForge")]
		[CompilerGenerated]
		private StackPanel containerRepository;

		// Token: 0x04000242 RID: 578
		[CompilerGenerated]
		[AccessedThroughProperty("PanForgeInfo")]
		private Grid _CodeRepository;

		// Token: 0x04000243 RID: 579
		[CompilerGenerated]
		[AccessedThroughProperty("ImgForge")]
		private Image _TokenizerRepository;

		// Token: 0x04000244 RID: 580
		[CompilerGenerated]
		[AccessedThroughProperty("LabForge")]
		private TextBlock definitionRepository;

		// Token: 0x04000245 RID: 581
		[CompilerGenerated]
		[AccessedThroughProperty("BtnForgeClear")]
		private Grid paramsRepository;

		// Token: 0x04000246 RID: 582
		[CompilerGenerated]
		[AccessedThroughProperty("BtnForgeClearInner")]
		private Path m_MockRepository;

		// Token: 0x04000247 RID: 583
		[AccessedThroughProperty("CardFabric")]
		[CompilerGenerated]
		private MyCard adapterRepository;

		// Token: 0x04000248 RID: 584
		[AccessedThroughProperty("HintFabric")]
		[CompilerGenerated]
		private MyHint initializerRepository;

		// Token: 0x04000249 RID: 585
		[AccessedThroughProperty("PanFabric")]
		[CompilerGenerated]
		private StackPanel systemRepository;

		// Token: 0x0400024A RID: 586
		[AccessedThroughProperty("PanFabricInfo")]
		[CompilerGenerated]
		private Grid _WriterRepository;

		// Token: 0x0400024B RID: 587
		[CompilerGenerated]
		[AccessedThroughProperty("ImgFabric")]
		private Image m_BroadcasterRepository;

		// Token: 0x0400024C RID: 588
		[CompilerGenerated]
		[AccessedThroughProperty("LabFabric")]
		private TextBlock _AttributeRepository;

		// Token: 0x0400024D RID: 589
		[CompilerGenerated]
		[AccessedThroughProperty("BtnFabricClear")]
		private Grid specificationRepository;

		// Token: 0x0400024E RID: 590
		[CompilerGenerated]
		[AccessedThroughProperty("BtnFabricClearInner")]
		private Path _PredicateRepository;

		// Token: 0x0400024F RID: 591
		[CompilerGenerated]
		[AccessedThroughProperty("CardFabricApi")]
		private MyCard clientRepository;

		// Token: 0x04000250 RID: 592
		[AccessedThroughProperty("PanFabricApi")]
		[CompilerGenerated]
		private StackPanel _InfoRepository;

		// Token: 0x04000251 RID: 593
		[AccessedThroughProperty("PanFabricApiInfo")]
		[CompilerGenerated]
		private Grid _DecoratorRepository;

		// Token: 0x04000252 RID: 594
		[AccessedThroughProperty("ImgFabricApi")]
		[CompilerGenerated]
		private Image _PropertyRepository;

		// Token: 0x04000253 RID: 595
		[AccessedThroughProperty("LabFabricApi")]
		[CompilerGenerated]
		private TextBlock descriptorRepository;

		// Token: 0x04000254 RID: 596
		[AccessedThroughProperty("BtnFabricApiClear")]
		[CompilerGenerated]
		private Grid mapRepository;

		// Token: 0x04000255 RID: 597
		[CompilerGenerated]
		[AccessedThroughProperty("BtnFabricApiClearInner")]
		private Path eventRepository;

		// Token: 0x04000256 RID: 598
		[CompilerGenerated]
		[AccessedThroughProperty("CardLiteLoader")]
		private MyCard _AlgoRepository;

		// Token: 0x04000257 RID: 599
		[CompilerGenerated]
		[AccessedThroughProperty("PanLiteLoader")]
		private StackPanel poolRepository;

		// Token: 0x04000258 RID: 600
		[AccessedThroughProperty("PanLiteLoaderInfo")]
		[CompilerGenerated]
		private Grid publisherRepository;

		// Token: 0x04000259 RID: 601
		[AccessedThroughProperty("ImgLiteLoader")]
		[CompilerGenerated]
		private Image _WatcherRepository;

		// Token: 0x0400025A RID: 602
		[CompilerGenerated]
		[AccessedThroughProperty("LabLiteLoader")]
		private TextBlock taskRepository;

		// Token: 0x0400025B RID: 603
		[AccessedThroughProperty("BtnLiteLoaderClear")]
		[CompilerGenerated]
		private Grid iteratorRepository;

		// Token: 0x0400025C RID: 604
		[AccessedThroughProperty("BtnLiteLoaderClearInner")]
		[CompilerGenerated]
		private Path m_SerializerRepository;

		// Token: 0x0400025D RID: 605
		[CompilerGenerated]
		[AccessedThroughProperty("PanLoad")]
		private MyCard _RoleRepository;

		// Token: 0x0400025E RID: 606
		[AccessedThroughProperty("LoadMinecraft")]
		[CompilerGenerated]
		private MyLoading valueRepository;

		// Token: 0x0400025F RID: 607
		[AccessedThroughProperty("LoadOptiFine")]
		[CompilerGenerated]
		private MyLoading recordRepository;

		// Token: 0x04000260 RID: 608
		[AccessedThroughProperty("LoadForge")]
		[CompilerGenerated]
		private MyLoading visitorRepository;

		// Token: 0x04000261 RID: 609
		[AccessedThroughProperty("LoadLiteLoader")]
		[CompilerGenerated]
		private MyLoading helperRepository;

		// Token: 0x04000262 RID: 610
		[CompilerGenerated]
		[AccessedThroughProperty("LoadFabric")]
		private MyLoading _ParamRepository;

		// Token: 0x04000263 RID: 611
		[AccessedThroughProperty("LoadFabricApi")]
		[CompilerGenerated]
		private MyLoading baseRepository;

		// Token: 0x04000264 RID: 612
		private bool _ProductRepository;
	}
}
