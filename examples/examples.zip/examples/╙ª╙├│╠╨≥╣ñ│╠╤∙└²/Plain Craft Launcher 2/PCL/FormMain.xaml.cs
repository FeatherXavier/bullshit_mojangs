﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using PCL.My;

namespace PCL
{
	// Token: 0x0200018D RID: 397
	[DesignerGenerated]
	public partial class FormMain : Window
	{
		// Token: 0x06001243 RID: 4675 RVA: 0x00079C2C File Offset: 0x00077E2C
		private void ShowUpdateLog(int LastVersion)
		{
			FormMain._Closure$__1-0 CS$<>8__locals1 = new FormMain._Closure$__1-0(CS$<>8__locals1);
			int num = 0;
			int num2 = 0;
			List<KeyValuePair<int, string>> list = new List<KeyValuePair<int, string>>();
			checked
			{
				if (LastVersion < 246)
				{
					list.Add(new KeyValuePair<int, string>(5, "Mod 下载支持筛选 Forge Mod 与 Fabric Mod"));
					list.Add(new KeyValuePair<int, string>(4, "大幅修改联机页面布局（作为联机优化的第二个阶段）"));
					list.Add(new KeyValuePair<int, string>(3, "Mod、整合包下载的综合优化"));
					list.Add(new KeyValuePair<int, string>(2, "修复使用离线登录进入 Forge 的存档可能导致游戏崩溃"));
					num += 13;
					num2 += 11;
				}
				if (LastVersion < 242)
				{
					list.Add(new KeyValuePair<int, string>(2, "修复 MC 所包含的一个严重安全漏洞"));
					if (LastVersion >= 236)
					{
						list.Add(new KeyValuePair<int, string>(2, "修复可能无法更改登录信息的 Bug"));
					}
				}
				if (LastVersion < 238)
				{
					if (LastVersion == 236)
					{
						list.Add(new KeyValuePair<int, string>(2, "修复无法使用联机模块的 Bug"));
					}
					num++;
					num2 += 2;
				}
				if (LastVersion < 236)
				{
					list.Add(new KeyValuePair<int, string>(6, "网络状态检测支持检测 Windows 防火墙与网络延迟"));
					list.Add(new KeyValuePair<int, string>(6, "重制右侧页面的切换动画，卡片与提示条将逐个进入退出，并具有独特的位移动画"));
					list.Add(new KeyValuePair<int, string>(5, "添加 MC 1.18 中要求 Java 17 的检测与提醒"));
					list.Add(new KeyValuePair<int, string>(4, "优化页面切换、下载的性能"));
					list.Add(new KeyValuePair<int, string>(3, "允许拖拽按钮的设置第三方登录"));
					list.Add(new KeyValuePair<int, string>(2, "修复网络状态检测的结果总为 A 级的 Bug"));
					list.Add(new KeyValuePair<int, string>(2, "修复无法下载新版本的 Forge 的 Bug"));
					num += 25;
					num2 += 22;
				}
				if (LastVersion < 233)
				{
					list.Add(new KeyValuePair<int, string>(7, "微软账号支持更换皮肤与披风"));
					list.Add(new KeyValuePair<int, string>(6, "支持拖拽整合包文件到 PCL2 进行快捷安装"));
					list.Add(new KeyValuePair<int, string>(6, "Mod 下载支持显示对应的 MC 版本与 Mod 加载器，且可以跳转到 MCBBS 介绍页"));
					list.Add(new KeyValuePair<int, string>(5, "支持安装 1.17 OptiFine + Forge"));
					list.Add(new KeyValuePair<int, string>(5, "使用 Mojang 账号登录将会显示迁移提醒"));
					num += 12;
					num2 += 26;
				}
				if (LastVersion < 231)
				{
					list.Add(new KeyValuePair<int, string>(9, "联机功能的早期测试（尚未完成，延迟很高，之后会优化的）"));
					list.Add(new KeyValuePair<int, string>(5, "添加 1.18 实验性快照 5 的特供下载，且支持列表的联网更新"));
					num += 11;
					num2 += 3;
				}
				if (LastVersion < 226)
				{
					list.Add(new KeyValuePair<int, string>(6, "支持 1.17.1 Forge、Fabric 的安装与启动"));
					list.Add(new KeyValuePair<int, string>(4, "优化 Forge 下载与安装速度，提高安装稳定性"));
					list.Add(new KeyValuePair<int, string>(4, "更新内置帮助库，添加数个指南页面与整合包、存档的安装教程"));
					list.Add(new KeyValuePair<int, string>(3, "支持将游戏文件夹压缩包作为游戏整合包导入"));
					num += 12;
					num2 += 13;
				}
				if (LastVersion < 224)
				{
					list.Add(new KeyValuePair<int, string>(6, "界面与动画综合优化，重新制作主题配色"));
					list.Add(new KeyValuePair<int, string>(5, "添加 1.18 实验性快照的特供下载"));
					list.Add(new KeyValuePair<int, string>(4, "更新内置帮助库，添加光影、数据包、Mod 等资源的安装教程"));
					list.Add(new KeyValuePair<int, string>(4, "游戏崩溃分析优化"));
					list.Add(new KeyValuePair<int, string>(4, "若设置为自动更新，PCL2 会在关闭时才替换文件"));
					list.Add(new KeyValuePair<int, string>(4, "追加大量千万████的可能性"));
					num += 33;
					num2 += 20;
				}
				if (LastVersion < 217)
				{
					list.Add(new KeyValuePair<int, string>(7, "可以根据游戏版本自动选择所需的 Java"));
					list.Add(new KeyValuePair<int, string>(6, "允许在 Java 版本检测不通过时强制指定使用 Java"));
					list.Add(new KeyValuePair<int, string>(6, "允许为不同版本独立设置 Java"));
					list.Add(new KeyValuePair<int, string>(5, "Java 选择与搜索的综合优化"));
					list.Add(new KeyValuePair<int, string>(2, "修复无法使用 Mod、整合包搜索功能的 Bug"));
					num += 8;
					num2 += 20;
				}
				if (LastVersion < 214)
				{
					list.Add(new KeyValuePair<int, string>(6, "添加一键关闭所有运行中的 Minecraft 的按钮"));
					list.Add(new KeyValuePair<int, string>(5, "增加对 MC 1.17 需要 Java 16 的检测与说明"));
					list.Add(new KeyValuePair<int, string>(4, "Minecraft 崩溃分析优化"));
					list.Add(new KeyValuePair<int, string>(2, "修复无法修改部分个性化设置的严重 Bug"));
					list.Add(new KeyValuePair<int, string>(1, "修复 Windows 7 可能无法登录微软账号的严重 Bug"));
					list.Add(new KeyValuePair<int, string>(1, "修复网络不稳定时安装整合包极易失败的严重 Bug"));
					num += 10;
					num2 += 13;
				}
				if (LastVersion < 212)
				{
					list.Add(new KeyValuePair<int, string>(9, "添加帮助页面，且可以自行添加、删除其中的内容"));
					list.Add(new KeyValuePair<int, string>(6, "支持安装 MCBBS 格式的整合包"));
					list.Add(new KeyValuePair<int, string>(5, "自定义主页/帮助页面的 XAML 功能扩展"));
					list.Add(new KeyValuePair<int, string>(5, "同时安装 OptiFine 与 Forge 时，OptiFine 将作为 Mod 安装"));
					list.Add(new KeyValuePair<int, string>(4, "优化 CurseForge 搜索"));
					list.Add(new KeyValuePair<int, string>(3, "优化多个报错提示，更加人性化"));
					list.Add(new KeyValuePair<int, string>(3, "适配适用于快照版 MC 的 OptiFine"));
					list.Add(new KeyValuePair<int, string>(2, "修复进入 OptiFine 下载页面导致卡死的严重 Bug"));
					list.Add(new KeyValuePair<int, string>(1, "修复无法启动部分 OptiFine+Forge 版本的 Bug"));
					num += 20;
					num2 += 42;
				}
				if (LastVersion < 205)
				{
					list.Add(new KeyValuePair<int, string>(9, "游戏崩溃后，PCL2 会自动进行分析，并给出原因与处理建议"));
					list.Add(new KeyValuePair<int, string>(8, "重制背景音乐播放，暂停与下一曲现在通过右下角的按钮控制"));
					list.Add(new KeyValuePair<int, string>(7, "优化启动器更新，允许在设置页面手动检查更新"));
					list.Add(new KeyValuePair<int, string>(6, "可以将已有的错误报告或崩溃日志拖入 PCL2 的窗口内进行分析"));
					list.Add(new KeyValuePair<int, string>(4, "微软登录相关优化"));
					num += 19;
					num2 += 21;
				}
				if (LastVersion < 201)
				{
					list.Add(new KeyValuePair<int, string>(8, "支持启动器自动更新与更新提示"));
					list.Add(new KeyValuePair<int, string>(6, "添加返回顶部按钮"));
					list.Add(new KeyValuePair<int, string>(6, "允许修改缓存文件夹目录，并清除缓存文件"));
					num += 20;
					num2 += 19;
				}
				List<string> list2 = new List<string>();
				List<KeyValuePair<int, string>> list3 = ModBase.Sort<KeyValuePair<int, string>>(list, (FormMain._Closure$__.$IR1-1 == null) ? (FormMain._Closure$__.$IR1-1 = ((object a0, object a1) => ((FormMain._Closure$__.$I1-0 == null) ? (FormMain._Closure$__.$I1-0 = ((KeyValuePair<int, string> Left, KeyValuePair<int, string> Right) => Left.Key > Right.Key)) : FormMain._Closure$__.$I1-0)((a0 != null) ? ((KeyValuePair<int, string>)a0) : default(KeyValuePair<int, string>), (a1 != null) ? ((KeyValuePair<int, string>)a1) : default(KeyValuePair<int, string>)))) : FormMain._Closure$__.$IR1-1);
				if (list3.Count == 0 && num == 0 && num2 == 0)
				{
					list2.Add("龙猫忘记写更新日志啦！可以去提醒他一下……");
				}
				int num3 = Math.Min(9, list3.Count - 1);
				for (int i = 0; i <= num3; i++)
				{
					list2.Add(list3[i].Value);
				}
				if (list3.Count > 10)
				{
					num += list3.Count - 10;
				}
				if (num > 0 || num2 > 0)
				{
					list2.Add(((num > 0) ? ("其他 " + Conversions.ToString(num) + " 项小调整与修改") : "") + ((num <= 0 || num2 <= 0) ? "" : "，") + ((num2 > 0) ? ("修复了 " + Conversions.ToString(num2) + " 个 Bug") : "") + "，详见完整更新日志");
				}
				CS$<>8__locals1.$VB$Local_Content = "· " + ModBase.Join(list2, "\r\n· ");
				ModBase.RunInNewThread(delegate
				{
					if (ModMain.MyMsgBox(CS$<>8__locals1.$VB$Local_Content, "PCL2 已更新至 Release 2.2.9", "确定", "完整更新日志", "", false, true, false) == 2)
					{
						ModBase.OpenWebsite("https://afdian.net/@LTCat?tab=feed");
					}
				}, "UpdateLog Output", ThreadPriority.Normal);
			}
		}

		// Token: 0x06001244 RID: 4676 RVA: 0x0007A270 File Offset: 0x00078470
		public FormMain()
		{
			base.Loaded += this.FormMain_Loaded;
			base.Closing += this.FormMain_Closing;
			base.SizeChanged += delegate(object sender, SizeChangedEventArgs e)
			{
				this.FormMain_SizeChanged();
			};
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.FormMain_SizeChanged();
			};
			base.KeyDown += this.FormMain_KeyDown;
			base.MouseDown += this.FormMain_MouseDown;
			base.Activated += delegate(object sender, EventArgs e)
			{
				this.FormMain_Activated();
			};
			base.PreviewDragOver += this.FrmMain_PreviewDragOver;
			base.PreviewDrop += this.FrmMain_Drop;
			base.MouseMove += this.FormMain_MouseMove;
			this.m_ProcRequest = false;
			this._RepositoryAccount = false;
			this._ResolverAccount = false;
			this.tagAccount = false;
			this.comparatorAccount = FormMain.PageType.Launch;
			this.m_PrototypeAccount = new List<FormMain.PageStackData>();
			this.accountAccount = false;
			this.stateAccount = null;
			ModBase._MockState = ModBase.GetTimeTick();
			ModMain.m_CollectionAccount = this;
			ModMain._FilterAccount = new PageLaunchLeft();
			ModMain._ReaderAccount = new PageLaunchRight();
			int num = Conversions.ToInteger(ModBase._ParamsState.Get("SystemLastVersionReg", null));
			if (num < 246)
			{
				this.UpgradeSub(num);
			}
			else if (num > 246)
			{
				this.DowngradeSub(num);
			}
			ModMain.SearchTag(false);
			ModBase._ParamsState.Load("UiLauncherTheme", false, null);
			this.InitializeComponent();
			base.Opacity = 0.0;
			if (!Information.IsNothing(ModMain._FilterAccount.Parent))
			{
				ModMain._FilterAccount.SetValue(ContentPresenter.ContentProperty, null);
			}
			if (!Information.IsNothing(ModMain._ReaderAccount.Parent))
			{
				ModMain._ReaderAccount.SetValue(ContentPresenter.ContentProperty, null);
			}
			this.PanMainLeft.Child = ModMain._FilterAccount;
			this.PanMainRight.Child = ModMain._ReaderAccount;
			ModMain._ReaderAccount.FlushModel(MyPageRight.PageStates.ContentStay);
			if (FormMain._ModelAccount)
			{
				this.PageChange(FormMain.PageType.Link, FormMain.PageSubType.Default);
			}
			if (ModBase._EventState)
			{
				ModMain.Hint("[调试模式] PCL 正以调试模式运行，这可能会造成性能的下降，若无必要请不要开启！", ModMain.HintType.Info, true);
			}
			ModMinecraft._ProcessTag.Start(0, false);
			ModBase.Log("[Start] 第二阶段加载用时：" + Conversions.ToString(checked(ModBase.GetTimeTick() - ModBase._MockState)) + " ms", ModBase.LogLevel.Normal, "出现错误");
		}

		// Token: 0x06001245 RID: 4677 RVA: 0x0007A4D0 File Offset: 0x000786D0
		private void FormMain_Loaded(object sender, RoutedEventArgs e)
		{
			ModBase._MockState = ModBase.GetTimeTick();
			ModBase.containerState = new WindowInteropHelper(this).Handle;
			ModBase._ParamsState.Load("UiBackgroundOpacity", false, null);
			ModBase._ParamsState.Load("UiBackgroundBlur", false, null);
			ModBase._ParamsState.Load("UiLogoType", false, null);
			ModBase._ParamsState.Load("UiHiddenPageDownload", false, null);
			ModMain.BackgroundRefresh(false, true);
			ModMusic.MusicRefreshPlay(false, true);
			ModMinecraft.JavaListInit();
			this.BtnExtraDownload.m_Val = new MyExtraButton.ShowCheckDelegate(this.BtnExtraDownload_ShowCheck);
			this.BtnExtraBack.m_Val = new MyExtraButton.ShowCheckDelegate(this.BtnExtraBack_ShowCheck);
			this.BtnExtraApril.m_Val = new MyExtraButton.ShowCheckDelegate(this.BtnExtraApril_ShowCheck);
			this.BtnExtraShutdown.m_Val = new MyExtraButton.ShowCheckDelegate(this.BtnExtraShutdown_ShowCheck);
			this.BtnExtraApril.ShowRefresh();
			MyResizer myResizer = new MyResizer(this);
			myResizer.addResizerDown(this.ResizerB);
			myResizer.addResizerLeft(this.ResizerL);
			myResizer.addResizerLeftDown(this.ResizerLB);
			myResizer.addResizerLeftUp(this.ResizerLT);
			myResizer.addResizerRight(this.ResizerR);
			myResizer.addResizerRightDown(this.ResizerRB);
			myResizer.addResizerRightUp(this.ResizerRT);
			myResizer.addResizerUp(this.ResizerT);
			if (ModBase.RandomInteger(1, 1000) == 23)
			{
				this.ShapeTitleLogo.Data = (Geometry)new GeometryConverter().ConvertFromString("M26,29 v-25 h5 a7,7 180 0 1 0,14 h-5 M80,6.5 a10,11.5 180 1 0 0,18   M47,2.5 v24.5 h12   M98,2 v27   M107,2 v27");
			}
			ModMain.InitTag();
			base.Height = Conversions.ToDouble(ModBase.ReadReg("WindowHeight", Conversions.ToString(base.MinHeight + 50.0)));
			base.Width = Conversions.ToDouble(ModBase.ReadReg("WindowWidth", Conversions.ToString(base.MinWidth + 50.0)));
			base.Topmost = false;
			if (ModMain.consumerAccount != null)
			{
				ModMain.consumerAccount.Close(new TimeSpan(0, 0, 0, 0, checked((int)Math.Round(400.0 / ModAnimation.m_Test))));
			}
			base.Top = (ModBase.smethod_4((double)MyWpfExtension.FindModel().Screen.WorkingArea.Height) - base.Height) / 2.0;
			base.Left = (ModBase.smethod_4((double)MyWpfExtension.FindModel().Screen.WorkingArea.Width) - base.Width) / 2.0;
			this._RepositoryAccount = true;
			this.ShowWindowToTop();
			((HwndSource)PresentationSource.FromVisual(this)).AddHook(new HwndSourceHook(this.WndProc));
			checked
			{
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaCode((FormMain._Closure$__.$I5-0 == null) ? (FormMain._Closure$__.$I5-0 = delegate()
					{
						ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
					}) : FormMain._Closure$__.$I5-0, 50, false),
					ModAnimation.AaOpacity(this, Conversions.ToDouble(Operators.AddObject(Operators.DivideObject(ModBase._ParamsState.Get("UiLauncherTransparent", null), 1000), 0.4)), 300, 100, null, false),
					ModAnimation.AaScaleTransform(this.PanBack, 0.05, 500, 100, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Weak), false),
					ModAnimation.AaCode(delegate
					{
						this.PanBack.RenderTransform = null;
						this.m_ProcRequest = true;
						ModBase.Log(string.Concat(new string[]
						{
							"[System] DPI：",
							Conversions.ToString(ModBase.m_DescriptorState),
							"，工作区尺寸：",
							Conversions.ToString(MyWpfExtension.FindModel().Screen.WorkingArea.Width),
							" x ",
							Conversions.ToString(MyWpfExtension.FindModel().Screen.WorkingArea.Height),
							"，系统版本：",
							ModBase.broadcasterState.ToString()
						}), ModBase.LogLevel.Normal, "出现错误");
					}, 0, true)
				}, "Form Show", false);
				ModAnimation.AniStartRun();
				ModMain.TimerMainStartRun();
				ModBase.RunInNewThread(delegate
				{
					if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("SystemEula", null))))
					{
						for (;;)
						{
							switch (ModMain.MyMsgBox("在使用 PCL2 前，请同意 PCL2 的用户协议与免责声明。", "协议授权", "同意", "拒绝", "打开用户协议与免责声明页面", false, true, false))
							{
							case 1:
								goto IL_62;
							case 2:
								goto IL_7B;
							case 3:
								ModBase.OpenWebsite("https://shimo.im/docs/rGrd8pY8xWkt6ryW");
								continue;
							}
							break;
						}
						goto IL_82;
						IL_62:
						ModBase._ParamsState.Set("SystemEula", true, false, null);
						goto IL_82;
						IL_7B:
						this.EndProgram(false);
					}
					IL_82:
					try
					{
						Thread.Sleep(200);
						if (Conversions.ToBoolean(ModBase._ParamsState.Get("LinkAuto", null)))
						{
							PageLinkIoi.NewRepository().Start(null, false);
						}
						if (Conversions.ToBoolean(Operators.NotObject(Operators.CompareObjectEqual(ModBase._ParamsState.Get("HintFeedback", null), "", true))))
						{
							ModMain.wrapperState.Start(null, false);
						}
						ModDownload.m_DescriptorTag.Start(1, false);
						this.RunCountSub();
						ModMain._TagState.Start(1, false);
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "初始化加载池运行失败", ModBase.LogLevel.Feedback, "出现错误");
					}
					try
					{
						if (File.Exists(ModBase.Path + "PCL\\Plain Craft Launcher 2.exe"))
						{
							File.Delete(ModBase.Path + "PCL\\Plain Craft Launcher 2.exe");
						}
					}
					catch (Exception ex2)
					{
						ModBase.Log(ex2, "清理自动更新文件失败", ModBase.LogLevel.Debug, "出现错误");
					}
				}, "Start Loader", ThreadPriority.Lowest);
				ModBase.Log("[Start] 第三阶段加载用时：" + Conversions.ToString(ModBase.GetTimeTick() - ModBase._MockState) + " ms", ModBase.LogLevel.Normal, "出现错误");
			}
		}

		// Token: 0x06001246 RID: 4678 RVA: 0x0000ABD6 File Offset: 0x00008DD6
		private void RunCountSub()
		{
			ModBase._ParamsState.Set("SystemCount", Operators.AddObject(ModBase._ParamsState.Get("SystemCount", null), 1), false, null);
		}

		// Token: 0x06001247 RID: 4679 RVA: 0x0007A88C File Offset: 0x00078A8C
		private void UpgradeSub(int LastVersionCode)
		{
			ModBase.Log("[Start] 版本号从 " + Conversions.ToString(LastVersionCode) + " 升高到 " + Conversions.ToString(246), ModBase.LogLevel.Normal, "出现错误");
			ModBase._ParamsState.Set("SystemLastVersionReg", 246, false, null);
			int num = Conversions.ToInteger(ModBase._ParamsState.Get("SystemHighestBetaVersionReg", null));
			if (num < 246)
			{
				ModBase._ParamsState.Set("SystemHighestBetaVersionReg", 246, false, null);
				ModBase.Log("[Start] 最高版本号从 " + Conversions.ToString(num) + " 升高到 " + Conversions.ToString(246), ModBase.LogLevel.Normal, "出现错误");
			}
			if (num <= 207)
			{
				List<string> list = new List<string>
				{
					"2"
				};
				list.AddRange(new List<string>(ModBase._ParamsState.Get("UiLauncherThemeHide", null).ToString().Split(new char[]
				{
					'|'
				})));
				list.AddRange(new List<string>(ModBase._ParamsState.Get("UiLauncherThemeHide2", null).ToString().Split(new char[]
				{
					'|'
				})));
				ModBase._ParamsState.Set("UiLauncherThemeHide2", ModBase.Join(ModBase.ArrayNoDouble<string>(list, null), "|"), false, null);
			}
			if (LastVersionCode <= 115 && ModBase._ParamsState.Get("UiLauncherThemeHide2", null).ToString().Split(new char[]
			{
				'|'
			}).Contains("13"))
			{
				List<string> list2 = new List<string>(ModBase._ParamsState.Get("UiLauncherThemeHide2", null).ToString().Split(new char[]
				{
					'|'
				}));
				list2.Remove("13");
				ModBase._ParamsState.Set("UiLauncherThemeHide2", ModBase.Join(list2, "|"), false, null);
				ModMain.MyMsgBox("由于新版 PCL2 修改了欧皇彩的解锁方式，你需要重新解锁欧皇彩。\r\n多谢各位的理解啦！", "重新解锁提醒", "确定", "", "", false, true, false);
			}
			if (LastVersionCode <= 152 && ModBase._ParamsState.Get("UiLauncherThemeHide2", null).ToString().Split(new char[]
			{
				'|'
			}).Contains("12"))
			{
				List<string> list3 = new List<string>(ModBase._ParamsState.Get("UiLauncherThemeHide2", null).ToString().Split(new char[]
				{
					'|'
				}));
				list3.Remove("12");
				ModBase._ParamsState.Set("UiLauncherThemeHide2", ModBase.Join(list3, "|"), false, null);
				ModMain.MyMsgBox("由于新版 PCL2 修改了滑稽彩的解锁方式，你需要重新解锁滑稽彩。\r\n多谢各位的理解啦！", "重新解锁提醒", "确定", "", "", false, true, false);
			}
			if (LastVersionCode <= 161 && File.Exists(ModBase.Path + "PCL\\CustomSkin.png") && !File.Exists(ModBase.attributeState + "CustomSkin.png"))
			{
				File.Copy(ModBase.Path + "PCL\\CustomSkin.png", ModBase.attributeState + "CustomSkin.png");
				ModBase.Log("[Start] 已移动离线自定义皮肤", ModBase.LogLevel.Normal, "出现错误");
			}
			if (LastVersionCode <= 205)
			{
				ModBase._ParamsState.Set("UiHiddenOtherHelp", false, false, null);
				ModBase.Log("[Start] 已解除帮助页面的隐藏", ModBase.LogLevel.Normal, "出现错误");
			}
			if (LastVersionCode != 0 && num < 246)
			{
				this.ShowUpdateLog(num);
			}
		}

		// Token: 0x06001248 RID: 4680 RVA: 0x0007ABE8 File Offset: 0x00078DE8
		private void DowngradeSub(int LastVersionCode)
		{
			ModBase.Log("[Start] 版本号从 " + Conversions.ToString(LastVersionCode) + " 降低到 " + Conversions.ToString(246), ModBase.LogLevel.Normal, "出现错误");
			ModBase._ParamsState.Set("SystemLastVersionReg", 246, false, null);
		}

		// Token: 0x06001249 RID: 4681 RVA: 0x0000AC04 File Offset: 0x00008E04
		private void FormMain_Closing(object sender, CancelEventArgs e)
		{
			this.EndProgram(true);
			e.Cancel = true;
		}

		// Token: 0x0600124A RID: 4682 RVA: 0x0007AC3C File Offset: 0x00078E3C
		public void EndProgram(bool SendWarning)
		{
			if (SendWarning && ModNet.HasDownloadingTask(false))
			{
				if (ModMain.MyMsgBox("还有下载任务尚未完成，是否确定退出？", "提示", "确定", "取消", "", false, true, false) != 1)
				{
					return;
				}
				ModBase.RunInNewThread((FormMain._Closure$__.$I10-0 == null) ? (FormMain._Closure$__.$I10-0 = checked(delegate()
				{
					ModBase.Log("[System] 正在强行停止任务", ModBase.LogLevel.Normal, "出现错误");
					ModLoader.LoaderBase[] array = ModLoader.LoaderTaskbar.ToArray();
					for (int i = 0; i < array.Length; i++)
					{
						array[i].Abort();
					}
				})) : FormMain._Closure$__.$I10-0, "强行停止下载任务", ThreadPriority.Normal);
			}
			ModBase.RunInUiWait(delegate
			{
				base.IsHitTestVisible = false;
				if (this.PanBack.RenderTransform == null)
				{
					this.PanBack.RenderTransform = new ScaleTransform();
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaOpacity(this, -base.Opacity, 100, 100, null, false),
						ModAnimation.AaScaleTransform(this.PanBack, -0.05, 200, 0, new ModAnimation.AniEaseInBack(ModAnimation.AniEasePower.Middle), false),
						ModAnimation.AaCode(delegate
						{
							base.IsHitTestVisible = false;
							base.Top = -10000.0;
							base.ShowInTaskbar = false;
						}, 225, false),
						ModAnimation.AaCode((FormMain._Closure$__.$IR10-5 == null) ? (FormMain._Closure$__.$IR10-5 = delegate()
						{
							FormMain.EndProgramForce(ModBase.Result.Success);
						}) : FormMain._Closure$__.$IR10-5, 250, false)
					}, "Form Close", false);
				}
				else
				{
					FormMain.EndProgramForce(ModBase.Result.Success);
				}
				ModBase.Log("[System] 收到关闭指令", ModBase.LogLevel.Normal, "出现错误");
			});
		}

		// Token: 0x0600124B RID: 4683 RVA: 0x0007ACBC File Offset: 0x00078EBC
		public static void EndProgramForce(ModBase.Result ReturnCode = ModBase.Result.Success)
		{
			int num;
			int num4;
			object obj;
			try
			{
				IL_00:
				ProjectData.ClearProjectError();
				num = 1;
				IL_07:
				int num2 = 2;
				ModBase.m_SystemState = true;
				IL_0F:
				num2 = 3;
				ModAnimation.CheckModel(checked(ModAnimation.DefineModel() + 1));
				IL_1D:
				num2 = 4;
				PageLinkIoi.IoiStop(false);
				IL_26:
				num2 = 5;
				if (!ModMain.m_ProccesorState)
				{
					goto IL_37;
				}
				IL_2F:
				num2 = 6;
				ModMain.UpdateRestart(false);
				IL_37:
				num2 = 7;
				if (ReturnCode != ModBase.Result.Exception)
				{
					goto IL_9A;
				}
				IL_3D:
				num2 = 8;
				if (FormMain.wrapperAccount)
				{
					goto IL_8D;
				}
				IL_46:
				num2 = 9;
				ModBase.FeedbackInfo();
				IL_4E:
				num2 = 10;
				ModBase.Log("请在 https://jinshuju.net/f/rP4b6E?x_field_1=crash 提交错误报告，以便于作者解决此问题！", ModBase.LogLevel.Normal, "出现错误");
				IL_61:
				num2 = 11;
				FormMain.wrapperAccount = true;
				IL_6A:
				num2 = 12;
				ModBase.ShellAndGetExitCode(ModBase.Path + "PCL\\Log1.txt", "", false, 1000000);
				IL_8D:
				num2 = 13;
				Thread.Sleep(500);
				IL_9A:
				num2 = 14;
				ModBase.Log("[System] 程序已退出，返回值：" + ModBase.GetStringFromEnum(ReturnCode), ModBase.LogLevel.Normal, "出现错误");
				IL_BD:
				num2 = 15;
				ModBase.LogFlush();
				IL_C5:
				num2 = 16;
				if (ReturnCode != ModBase.Result.Success)
				{
					goto IL_DA;
				}
				IL_CB:
				num2 = 17;
				Process.GetCurrentProcess().Kill();
				goto IL_E3;
				IL_DA:
				num2 = 19;
				Environment.Exit((int)ReturnCode);
				IL_E3:
				goto IL_185;
				IL_E8:
				int num3 = num4 + 1;
				num4 = 0;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
				IL_146:
				goto IL_17A;
				IL_148:
				num4 = num2;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
				IL_158:;
			}
			catch when (endfilter(obj is Exception & num != 0 & num4 == 0))
			{
				Exception ex = (Exception)obj2;
				goto IL_148;
			}
			IL_17A:
			throw ProjectData.CreateProjectError(-2146828237);
			IL_185:
			if (num4 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		// Token: 0x0600124C RID: 4684 RVA: 0x0000AC14 File Offset: 0x00008E14
		private void BtnTitleClose_Click(object sender, RoutedEventArgs e)
		{
			this.EndProgram(true);
		}

		// Token: 0x0600124D RID: 4685 RVA: 0x0007AE74 File Offset: 0x00079074
		private void FormDragMove(object sender, MouseButtonEventArgs e)
		{
			int num;
			int num4;
			object obj;
			try
			{
				IL_00:
				ProjectData.ClearProjectError();
				num = 1;
				IL_07:
				int num2 = 2;
				if (!Conversions.ToBoolean(NewLateBinding.LateGet(sender, null, "IsMouseDirectlyOver", new object[0], null, null, null)))
				{
					goto IL_2D;
				}
				IL_25:
				num2 = 3;
				base.DragMove();
				IL_2D:
				goto IL_8C;
				IL_2F:
				int num3 = num4 + 1;
				num4 = 0;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
				IL_4D:
				goto IL_81;
				IL_4F:
				num4 = num2;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
				IL_5F:;
			}
			catch when (endfilter(obj is Exception & num != 0 & num4 == 0))
			{
				Exception ex = (Exception)obj2;
				goto IL_4F;
			}
			IL_81:
			throw ProjectData.CreateProjectError(-2146828237);
			IL_8C:
			if (num4 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		// Token: 0x0600124E RID: 4686 RVA: 0x0007AF28 File Offset: 0x00079128
		private void FormMain_SizeChanged()
		{
			if (this._RepositoryAccount)
			{
				ModBase.WriteReg("WindowHeight", Conversions.ToString(base.Height), false);
				ModBase.WriteReg("WindowWidth", Conversions.ToString(base.Width), false);
			}
			this.RectForm.Rect = new Rect(0.0, 0.0, this.BorderForm.ActualWidth, this.BorderForm.ActualHeight);
			this.PanForm.Width = this.BorderForm.ActualWidth + 0.001;
			this.PanForm.Height = this.BorderForm.ActualHeight + 0.001;
			this.PanMain.Width = this.PanForm.Width;
			this.PanMain.Height = Math.Max(0.0, this.PanForm.Height - this.PanTitle.ActualHeight);
		}

		// Token: 0x0600124F RID: 4687 RVA: 0x0000AC1D File Offset: 0x00008E1D
		private void BtnTitleMin_Click()
		{
			base.WindowState = WindowState.Minimized;
		}

		// Token: 0x06001250 RID: 4688 RVA: 0x0007B028 File Offset: 0x00079228
		private void FormMain_KeyDown(object sender, KeyEventArgs e)
		{
			if (!e.IsRepeat)
			{
				if (e.Key == Key.Return && this.PanMsg.Children.Count > 0)
				{
					NewLateBinding.LateCall(this.PanMsg.Children[0], null, "Btn1_Click", new object[0], null, null, null, true);
					return;
				}
				if (e.Key == Key.F11 && this.comparatorAccount == FormMain.PageType.VersionSelect)
				{
					ModMain._PageAccount._EventComparator = !ModMain._PageAccount._EventComparator;
					ModLoader.LoaderFolderRun(ModMinecraft.threadTag, ModMinecraft._MapperTag, ModLoader.LoaderFolderRunType.ForceRun, 1, "versions\\", false);
					return;
				}
				if (e.Key == Key.F12)
				{
					PageSetupUI.SortResolver(!PageSetupUI.AwakeResolver());
					if (PageSetupUI.AwakeResolver())
					{
						ModMain.Hint("功能隐藏设置已暂时关闭！", ModMain.HintType.Finish, true);
					}
					else
					{
						ModMain.Hint("功能隐藏设置已重新开启！", ModMain.HintType.Finish, true);
					}
					PageSetupUI.HiddenRefresh();
					return;
				}
				if (e.Key == Key.Return && this.comparatorAccount == FormMain.PageType.Launch)
				{
					if (ModMain.m_ComparatorState && !ModMain.m_PrototypeState)
					{
						ModMain.Hint("木大！", ModMain.HintType.Info, true);
					}
					else
					{
						ModMain._FilterAccount.LaunchButtonClick("");
					}
				}
				if (e.SystemKey == Key.LeftAlt || e.SystemKey == Key.RightAlt)
				{
					e.Handled = true;
				}
				if (e.Key == Key.Escape)
				{
					this.TriggerPageBack();
				}
			}
		}

		// Token: 0x06001251 RID: 4689 RVA: 0x0000AC26 File Offset: 0x00008E26
		private void FormMain_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (e.ChangedButton == MouseButton.XButton1 || e.ChangedButton == MouseButton.XButton2)
			{
				this.TriggerPageBack();
			}
		}

		// Token: 0x06001252 RID: 4690 RVA: 0x0000AC40 File Offset: 0x00008E40
		private void TriggerPageBack()
		{
			if (this.comparatorAccount == FormMain.PageType.Download && this.QueryTag() == FormMain.PageSubType.DownloadInstall)
			{
				ModMain._TestsAccount.ExitSelectPage();
				return;
			}
			this.PageBack();
		}

		// Token: 0x06001253 RID: 4691 RVA: 0x0007B184 File Offset: 0x00079384
		private void FormMain_Activated()
		{
			try
			{
				if (this.comparatorAccount == FormMain.PageType.VersionSetup && this.QueryTag() == FormMain.PageSubType.SetupSystem)
				{
					ModMain.m_MessageAccount.RefreshList(false);
				}
				else if (this.comparatorAccount == FormMain.PageType.VersionSelect)
				{
					ModLoader.LoaderFolderRun(ModMinecraft.threadTag, ModMinecraft._MapperTag, ModLoader.LoaderFolderRunType.RunOnUpdated, 1, "versions\\", false);
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "切回窗口时出错", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06001254 RID: 4692 RVA: 0x0000AC6F File Offset: 0x00008E6F
		private void FrmMain_PreviewDragOver(object sender, DragEventArgs e)
		{
			if (e.Data.GetFormats().Contains("FileDrop"))
			{
				e.Effects = DragDropEffects.Link;
				return;
			}
			e.Effects = DragDropEffects.None;
		}

		// Token: 0x06001255 RID: 4693 RVA: 0x0007B218 File Offset: 0x00079418
		private void FrmMain_Drop(object sender, DragEventArgs e)
		{
			try
			{
				if (e.Data.GetDataPresent(DataFormats.Text))
				{
					try
					{
						string text = Conversions.ToString(e.Data.GetData(DataFormats.Text));
						ModBase.Log("[System] 接受文本拖拽：" + text, ModBase.LogLevel.Normal, "出现错误");
						if (text.StartsWith("authlib-injector:yggdrasil-server:"))
						{
							e.Handled = true;
							string text2 = WebUtility.UrlDecode(text.Substring("authlib-injector:yggdrasil-server:".Length));
							ModBase.Log("[System] Authlib 拖拽：" + text2, ModBase.LogLevel.Normal, "出现错误");
							if (!string.IsNullOrEmpty(new ValidateHttp().Validate(text2)))
							{
								ModMain.Hint("输入的 Authlib 验证服务器不符合网址格式（" + text2 + "）！", ModMain.HintType.Critical, true);
							}
							else if (ModMinecraft.SetupResolver() == null)
							{
								ModMain.Hint("请先下载游戏，再设置第三方登录！", ModMain.HintType.Critical, true);
							}
							else
							{
								if (Operators.CompareString(text2, "https://littleskin.cn/api/yggdrasil", true) == 0)
								{
									if (ModMain.MyMsgBox("是否要在版本 " + ModMinecraft.SetupResolver().Name + " 中开启 Little Skin 登录？\r\n你可以在 版本设置 → 设置 → 服务器选项 中修改登录方式。", "第三方登录开启确认", "确定", "取消", "", false, true, false) == 2)
									{
										return;
									}
									ModBase._ParamsState.Set("VersionServerLogin", 4, false, ModMinecraft.SetupResolver());
									ModBase._ParamsState.Set("VersionServerAuthServer", "https://littleskin.cn/api/yggdrasil", false, ModMinecraft.SetupResolver());
									ModBase._ParamsState.Set("VersionServerAuthRegister", "https://littleskin.cn/auth/register", false, ModMinecraft.SetupResolver());
									ModBase._ParamsState.Set("VersionServerAuthName", "Little Skin 登录", false, ModMinecraft.SetupResolver());
								}
								else
								{
									if (ModMain.MyMsgBox(string.Concat(new string[]
									{
										"是否要在版本 ",
										ModMinecraft.SetupResolver().Name,
										" 中开启第三方登录？\r\n登录服务器：",
										text2,
										"\r\n\r\n你可以在 版本设置 → 设置 → 服务器选项 中修改登录方式。"
									}), "第三方登录开启确认", "确定", "取消", "", false, true, false) == 2)
									{
										return;
									}
									ModBase._ParamsState.Set("VersionServerLogin", 4, false, ModMinecraft.SetupResolver());
									ModBase._ParamsState.Set("VersionServerAuthServer", text2, false, ModMinecraft.SetupResolver());
									ModBase._ParamsState.Set("VersionServerAuthRegister", "", false, ModMinecraft.SetupResolver());
									ModBase._ParamsState.Set("VersionServerAuthName", "", false, ModMinecraft.SetupResolver());
								}
								if (this.comparatorAccount == FormMain.PageType.VersionSetup && this.QueryTag() == FormMain.PageSubType.DownloadInstall)
								{
									ModMain._ProcAccount.Reload();
								}
								else if (this.comparatorAccount == FormMain.PageType.Launch)
								{
									ModMain._FilterAccount.RefreshPage(true, false);
								}
							}
						}
						goto IL_376;
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "无法接取文本拖拽事件", ModBase.LogLevel.Developer, "出现错误");
						return;
					}
				}
				if (e.Data.GetDataPresent(DataFormats.FileDrop))
				{
					List<string> list = new List<string>((IEnumerable<string>)((Array)e.Data.GetData(DataFormats.FileDrop)));
					e.Handled = true;
					if (Directory.Exists(list.First<string>()) && !File.Exists(list.First<string>()))
					{
						ModMain.Hint("请拖入一个文件，而非文件夹！", ModMain.HintType.Critical, true);
					}
					else if (list.Count > 1)
					{
						ModMain.Hint("一次请只拖入一个文件！", ModMain.HintType.Critical, true);
					}
					else
					{
						string FilePath = list.First<string>();
						ModBase.Log("[System] 接受文件拖拽：" + FilePath, ModBase.LogLevel.Developer, "出现错误");
						ModBase.RunInNewThread(delegate
						{
							if (Operators.CompareString(FilePath.Split(new char[]
							{
								'.'
							}).Last<string>().ToLower(), "zip", true) == 0)
							{
								ModBase.Log("[System] 文件为 zip 压缩包，尝试作为整合包安装", ModBase.LogLevel.Normal, "出现错误");
								if (ModModpack.ModpackInstall(FilePath, null, false))
								{
									return;
								}
							}
							try
							{
								ModBase.Log("[System] 尝试进行错误报告分析", ModBase.LogLevel.Normal, "出现错误");
								CrashAnalyzer crashAnalyzer = new CrashAnalyzer(ModBase.GetUuid());
								crashAnalyzer.Import(FilePath);
								if (crashAnalyzer.Prepare() != 0)
								{
									crashAnalyzer.Analyze(null);
									crashAnalyzer.Output(true, new List<string>());
									return;
								}
							}
							catch (Exception ex3)
							{
								ModBase.Log(ex3, "自主错误报告分析失败", ModBase.LogLevel.Feedback, "出现错误");
							}
							ModMain.Hint("PCL2 无法确定应当执行的文件拖拽操作……", ModMain.HintType.Info, true);
						}, "文件拖拽", ThreadPriority.Normal);
					}
				}
				IL_376:;
			}
			catch (Exception ex2)
			{
				ModBase.Log(ex2, "接取拖拽事件失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06001256 RID: 4694 RVA: 0x0007B5F4 File Offset: 0x000797F4
		private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
		{
			if (msg == 30)
			{
				DateTime now = DateTime.Now;
				if (DateTime.Compare(now.Date, ModBase.adapterState.Date) == 0)
				{
					ModBase.Log("[System] 系统时间微调为：" + now.ToLongDateString() + " " + now.ToLongTimeString(), ModBase.LogLevel.Normal, "出现错误");
					this._ResolverAccount = false;
				}
				else
				{
					ModBase.Log("[System] 系统时间修改为：" + now.ToLongDateString() + " " + now.ToLongTimeString(), ModBase.LogLevel.Normal, "出现错误");
					this._ResolverAccount = true;
				}
			}
			else if (msg == 6402)
			{
				ModBase.Log("[System] 收到置顶信息：" + Conversions.ToString(hwnd.ToInt64()), ModBase.LogLevel.Normal, "出现错误");
				if (!this.m_ProcRequest)
				{
					ModBase.Log("[System] 窗口尚未加载完成，忽略置顶请求", ModBase.LogLevel.Normal, "出现错误");
					return IntPtr.Zero;
				}
				this.ShowWindowToTop();
				handled = true;
			}
			return IntPtr.Zero;
		}

		// Token: 0x17000324 RID: 804
		// (get) Token: 0x06001257 RID: 4695 RVA: 0x0000AC97 File Offset: 0x00008E97
		// (set) Token: 0x06001258 RID: 4696 RVA: 0x0007B6E8 File Offset: 0x000798E8
		public bool Hidden
		{
			get
			{
				return this.tagAccount;
			}
			set
			{
				if (this.tagAccount != value)
				{
					this.tagAccount = value;
					if (value)
					{
						base.Left -= 10000.0;
						base.ShowInTaskbar = false;
						base.Visibility = Visibility.Hidden;
						ModBase.Log(string.Concat(new string[]
						{
							"[System] 窗口已隐藏，位置：(",
							Conversions.ToString(base.Left),
							",",
							Conversions.ToString(base.Top),
							")"
						}), ModBase.LogLevel.Normal, "出现错误");
						return;
					}
					if (base.Left < -2000.0)
					{
						base.Left += 10000.0;
					}
					this.ShowWindowToTop();
				}
			}
		}

		// Token: 0x06001259 RID: 4697 RVA: 0x0000AC9F File Offset: 0x00008E9F
		public void ShowWindowToTop()
		{
			ModBase.RunInUi(delegate()
			{
				base.Visibility = Visibility.Visible;
				base.ShowInTaskbar = true;
				base.WindowState = WindowState.Normal;
				this.Hidden = false;
				base.Topmost = true;
				base.Topmost = false;
				ModMain.SetForegroundWindow(ModBase.containerState);
				base.Focus();
				ModBase.Log(string.Concat(new string[]
				{
					"[System] 窗口已置顶，位置：(",
					Conversions.ToString(base.Left),
					", ",
					Conversions.ToString(base.Top),
					"), ",
					Conversions.ToString(base.Width),
					" x ",
					Conversions.ToString(base.Height)
				}), ModBase.LogLevel.Normal, "出现错误");
			}, false);
		}

		// Token: 0x0600125A RID: 4698 RVA: 0x0007B7A8 File Offset: 0x000799A8
		private string PageNameGet(FormMain.PageStackData Stack)
		{
			string result;
			switch (Stack.m_CreatorParameter)
			{
			case FormMain.PageType.VersionSelect:
				result = "版本选择";
				break;
			case FormMain.PageType.DownloadManager:
				result = "下载管理";
				break;
			case FormMain.PageType.VersionSetup:
				result = "版本设置 - " + ((PageVersionLeft.m_AlgoResolver == null) ? "未知版本" : PageVersionLeft.m_AlgoResolver.Name);
				break;
			case FormMain.PageType.CfDetail:
				if (Stack.m_ObjectParameter == null)
				{
					ModBase.Log("[Control] CurseForge 工程详情页面未提供关键项", ModBase.LogLevel.Feedback, "出现错误");
					result = "未知页面";
				}
				else
				{
					ModDownload.DlCfProject dlCfProject = (ModDownload.DlCfProject)Stack.m_ObjectParameter;
					result = (dlCfProject.threadProccesor ? "整合包下载 - " : "Mod 下载 - ") + dlCfProject.FlushComparator();
				}
				break;
			case FormMain.PageType.HelpDetail:
				if (Stack.m_ObjectParameter == null)
				{
					ModBase.Log("[Control] 帮助详情页面未提供关键项", ModBase.LogLevel.Msgbox, "出现错误");
					result = "未知页面";
				}
				else
				{
					result = ((ModMain.HelpEntry)NewLateBinding.LateIndexGet(Stack.m_ObjectParameter, new object[]
					{
						0
					}, null)).Title;
				}
				break;
			default:
				result = "";
				break;
			}
			return result;
		}

		// Token: 0x0600125B RID: 4699 RVA: 0x0000ACB3 File Offset: 0x00008EB3
		public void PageNameRefresh(FormMain.PageStackData Type)
		{
			this.LabTitleInner.Text = this.PageNameGet(Type);
		}

		// Token: 0x0600125C RID: 4700 RVA: 0x0000ACC7 File Offset: 0x00008EC7
		public void PageNameRefresh()
		{
			this.PageNameRefresh(this.comparatorAccount);
		}

		// Token: 0x0600125D RID: 4701 RVA: 0x0007B8B8 File Offset: 0x00079AB8
		public FormMain.PageSubType QueryTag()
		{
			FormMain.PageStackData left = this.comparatorAccount;
			FormMain.PageSubType result;
			if (left == FormMain.PageType.Download)
			{
				if (ModMain.exceptionAccount == null)
				{
					ModMain.exceptionAccount = new PageDownloadLeft();
				}
				result = ModMain.exceptionAccount.paramsPrototype;
			}
			else if (left == FormMain.PageType.Link)
			{
				if (ModMain.m_InterpreterAccount == null)
				{
					ModMain.m_InterpreterAccount = new PageLinkLeft();
				}
				result = ModMain.m_InterpreterAccount.specificationResolver;
			}
			else if (left == FormMain.PageType.Setup)
			{
				if (ModMain._RuleAccount == null)
				{
					ModMain._RuleAccount = new PageSetupLeft();
				}
				result = ModMain._RuleAccount._ParamPrototype;
			}
			else if (left == FormMain.PageType.Other)
			{
				if (ModMain.m_ListAccount == null)
				{
					ModMain.m_ListAccount = new PageOtherLeft();
				}
				result = ModMain.m_ListAccount._TestPrototype;
			}
			else if (left == FormMain.PageType.VersionSetup)
			{
				if (ModMain._MappingAccount == null)
				{
					ModMain._MappingAccount = new PageVersionLeft();
				}
				result = ModMain._MappingAccount.poolResolver;
			}
			else
			{
				result = FormMain.PageSubType.Default;
			}
			return result;
		}

		// Token: 0x0600125E RID: 4702 RVA: 0x0007B9B4 File Offset: 0x00079BB4
		public void PageChange(FormMain.PageStackData Stack, FormMain.PageSubType SubType = FormMain.PageSubType.Default)
		{
			if (Operators.CompareString(this.PageNameGet(Stack), "", true) == 0)
			{
				this.PageChangeExit();
				this.accountAccount = true;
				((MyRadioButton)this.PanTitleSelect.Children[(int)Stack]).SetChecked(true, true, Operators.CompareString(this.PageNameGet(this.comparatorAccount), "", true) == 0);
				this.accountAccount = false;
				switch (Stack.m_CreatorParameter)
				{
				case FormMain.PageType.Download:
					if (ModMain.exceptionAccount == null)
					{
						ModMain.exceptionAccount = new PageDownloadLeft();
					}
					((MyListItem)ModMain.exceptionAccount.PanItem.Children[(int)SubType]).SetChecked(true, true, Stack == this.comparatorAccount);
					break;
				case FormMain.PageType.Link:
					if (ModMain.m_InterpreterAccount == null)
					{
						ModMain.m_InterpreterAccount = new PageLinkLeft();
					}
					((MyListItem)ModMain.m_InterpreterAccount.PanItem.Children[(int)SubType]).SetChecked(true, true, Stack == this.comparatorAccount);
					break;
				case FormMain.PageType.Setup:
					if (ModMain._RuleAccount == null)
					{
						ModMain._RuleAccount = new PageSetupLeft();
					}
					((MyListItem)ModMain._RuleAccount.PanItem.Children[(int)SubType]).SetChecked(true, true, Stack == this.comparatorAccount);
					break;
				case FormMain.PageType.Other:
					if (ModMain.m_ListAccount == null)
					{
						ModMain.m_ListAccount = new PageOtherLeft();
					}
					((MyListItem)ModMain.m_ListAccount.PanItem.Children[(int)SubType]).SetChecked(true, true, Stack == this.comparatorAccount);
					break;
				}
				this.PageChangeActual(Stack, SubType);
				return;
			}
			FormMain.PageType creatorParameter = Stack.m_CreatorParameter;
			if (creatorParameter == FormMain.PageType.VersionSetup)
			{
				if (ModMain._MappingAccount == null)
				{
					ModMain._MappingAccount = new PageVersionLeft();
				}
				((MyListItem)ModMain._MappingAccount.PanItem.Children[(int)SubType]).SetChecked(true, true, Stack == this.comparatorAccount);
			}
			this.PageChangeActual(Stack, SubType);
		}

		// Token: 0x0600125F RID: 4703 RVA: 0x0000ACD5 File Offset: 0x00008ED5
		private void BtnTitleSelect_Click(MyRadioButton sender, bool raiseByMouse)
		{
			if (!this.accountAccount)
			{
				this.PageChangeActual(checked((FormMain.PageType)Math.Round(ModBase.Val(RuntimeHelpers.GetObjectValue(sender.Tag)))), (FormMain.PageSubType)(-1));
			}
		}

		// Token: 0x06001260 RID: 4704 RVA: 0x0000AD01 File Offset: 0x00008F01
		public void PageBack()
		{
			if (this.m_PrototypeAccount.Count != 0)
			{
				this.PageChangeActual(this.m_PrototypeAccount[0], (FormMain.PageSubType)(-1));
			}
		}

		// Token: 0x06001261 RID: 4705 RVA: 0x0007BBA8 File Offset: 0x00079DA8
		private void PageChangeActual(FormMain.PageStackData Stack, FormMain.PageSubType SubType = (FormMain.PageSubType)(-1))
		{
			if (!(this.comparatorAccount == Stack) || (this.QueryTag() != SubType && SubType != (FormMain.PageSubType)(-1)))
			{
				ModAnimation.CheckModel(checked(ModAnimation.DefineModel() + 1));
				try
				{
					FormMain._Closure$__47-0 CS$<>8__locals1 = new FormMain._Closure$__47-0(CS$<>8__locals1);
					CS$<>8__locals1.$VB$Me = this;
					CS$<>8__locals1.$VB$Local_PageName = this.PageNameGet(Stack);
					if (Operators.CompareString(CS$<>8__locals1.$VB$Local_PageName, "", true) == 0)
					{
						this.PageChangeExit();
					}
					else if (this.m_PrototypeAccount.Count == 0)
					{
						this.PanTitleInner.Visibility = Visibility.Visible;
						this.PanTitleMain.IsHitTestVisible = false;
						this.PanTitleInner.IsHitTestVisible = true;
						this.PageNameRefresh(Stack);
						ModAnimation.AniStart(new ModAnimation.AniData[]
						{
							ModAnimation.AaOpacity(this.PanTitleMain, -this.PanTitleMain.Opacity, 150, 0, null, false),
							ModAnimation.AaX(this.PanTitleMain, 12.0 - this.PanTitleMain.Margin.Left, 150, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Weak), false),
							ModAnimation.AaOpacity(this.PanTitleInner, 1.0 - this.PanTitleInner.Opacity, 150, 200, null, false),
							ModAnimation.AaX(this.PanTitleInner, -this.PanTitleInner.Margin.Left, 350, 200, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Middle), false),
							ModAnimation.AaCode(delegate
							{
								this.PanTitleMain.Visibility = Visibility.Collapsed;
							}, 0, true)
						}, "FrmMain Titlebar FirstLayer", false);
						this.m_PrototypeAccount.Insert(0, this.comparatorAccount);
					}
					else
					{
						ModAnimation.AniStart(new ModAnimation.AniData[]
						{
							ModAnimation.AaOpacity(this.LabTitleInner, -this.LabTitleInner.Opacity, 130, 0, null, false),
							ModAnimation.AaCode(delegate
							{
								CS$<>8__locals1.$VB$Me.LabTitleInner.Text = CS$<>8__locals1.$VB$Local_PageName;
							}, 0, true),
							ModAnimation.AaOpacity(this.LabTitleInner, 1.0, 150, 30, null, false)
						}, "FrmMain Titlebar SubLayer", false);
						if (this.m_PrototypeAccount.Contains(Stack))
						{
							while (this.m_PrototypeAccount.Contains(Stack))
							{
								this.m_PrototypeAccount.RemoveAt(0);
							}
						}
						else
						{
							this.m_PrototypeAccount.Insert(0, this.comparatorAccount);
						}
					}
					this.comparatorAccount = Stack;
					switch (Stack.m_CreatorParameter)
					{
					case FormMain.PageType.Launch:
						this.PageChangeAnim(ModMain._FilterAccount, ModMain._ReaderAccount);
						break;
					case FormMain.PageType.Download:
						if (ModMain.exceptionAccount == null)
						{
							ModMain.exceptionAccount = new PageDownloadLeft();
						}
						this.PageChangeAnim(ModMain.exceptionAccount, (FrameworkElement)ModMain.exceptionAccount.PageGet(SubType));
						break;
					case FormMain.PageType.Link:
						if (ModMain.m_InterpreterAccount == null)
						{
							ModMain.m_InterpreterAccount = new PageLinkLeft();
						}
						if (ModMain._ParserAccount == null)
						{
							ModMain._ParserAccount = new PageLinkIoi();
						}
						this.PageChangeAnim(ModMain.m_InterpreterAccount, (FrameworkElement)ModMain.m_InterpreterAccount.PageGet(SubType));
						break;
					case FormMain.PageType.Setup:
						if (ModMain._RuleAccount == null)
						{
							ModMain._RuleAccount = new PageSetupLeft();
						}
						this.PageChangeAnim(ModMain._RuleAccount, (FrameworkElement)ModMain._RuleAccount.PageGet(SubType));
						break;
					case FormMain.PageType.Other:
						if (ModMain.m_ListAccount == null)
						{
							ModMain.m_ListAccount = new PageOtherLeft();
						}
						this.PageChangeAnim(ModMain.m_ListAccount, (FrameworkElement)ModMain.m_ListAccount.PageGet(SubType));
						break;
					case FormMain.PageType.VersionSelect:
						if (ModMain.fieldAccount == null)
						{
							ModMain.fieldAccount = new PageSelectLeft();
						}
						if (ModMain._PageAccount == null)
						{
							ModMain._PageAccount = new PageSelectRight();
						}
						this.PageChangeAnim(ModMain.fieldAccount, ModMain._PageAccount);
						break;
					case FormMain.PageType.DownloadManager:
						if (ModMain._PrinterAccount == null)
						{
							ModMain._PrinterAccount = new PageSpeedLeft();
						}
						if (ModMain.m_TokenAccount == null)
						{
							ModMain.m_TokenAccount = new PageSpeedRight();
						}
						this.PageChangeAnim(ModMain._PrinterAccount, ModMain.m_TokenAccount);
						break;
					case FormMain.PageType.VersionSetup:
						if (ModMain._MappingAccount == null)
						{
							ModMain._MappingAccount = new PageVersionLeft();
						}
						this.PageChangeAnim(ModMain._MappingAccount, (FrameworkElement)ModMain._MappingAccount.PageGet(SubType));
						break;
					case FormMain.PageType.CfDetail:
						if (ModMain.modelState == null)
						{
							ModMain.modelState = new PageDownloadCfDetail();
						}
						this.PageChangeAnim(new MyPageLeft(), ModMain.modelState);
						break;
					case FormMain.PageType.HelpDetail:
						this.PageChangeAnim(new MyPageLeft(), (FrameworkElement)NewLateBinding.LateIndexGet(Stack.m_ObjectParameter, new object[]
						{
							1
						}, null));
						break;
					}
					this.BtnExtraDownload.ShowRefresh();
					this.BtnExtraApril.ShowRefresh();
					ModBase.Log("[Control] 切换主要页面：" + ModBase.GetStringFromEnum(Stack) + ", " + Conversions.ToString((int)SubType), ModBase.LogLevel.Normal, "出现错误");
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "切换主要页面失败（ID " + Conversions.ToString((int)this.comparatorAccount.m_CreatorParameter) + "）", ModBase.LogLevel.Feedback, "出现错误");
				}
				finally
				{
					ModAnimation.CheckModel(checked(ModAnimation.DefineModel() - 1));
				}
			}
		}

		// Token: 0x06001262 RID: 4706 RVA: 0x0007C0F0 File Offset: 0x0007A2F0
		private void PageChangeAnim(FrameworkElement TargetLeft, FrameworkElement TargetRight)
		{
			ModAnimation.AniStop("FrmMain LeftChange");
			ModAnimation.AniStop("FrmMain PageChange");
			ModAnimation.AniStop("PageLeft PageChange");
			checked
			{
				ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
				if (!Information.IsNothing(TargetLeft.Parent))
				{
					TargetLeft.SetValue(ContentPresenter.ContentProperty, null);
				}
				if (!Information.IsNothing(TargetRight) && !Information.IsNothing(TargetRight.Parent))
				{
					TargetRight.SetValue(ContentPresenter.ContentProperty, null);
				}
				this._IssuerAccount = (MyPageLeft)TargetLeft;
				this.m_RequestAccount = (MyPageRight)TargetRight;
				((MyPageLeft)this.PanMainLeft.Child).TriggerHideAnimation();
				((MyPageRight)this.PanMainRight.Child).PageOnExit();
				ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaCode(delegate
					{
						ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
						((MyPageRight)this.PanMainRight.Child).PageOnForceExit();
						this.PanMainLeft.Child = this._IssuerAccount;
						this._IssuerAccount.Opacity = 0.0;
						this.PanMainLeft.Background = null;
						this.PanMainRight.Child = this.m_RequestAccount;
						this.m_RequestAccount.Opacity = 0.0;
						this.PanMainRight.Background = null;
						ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
						ModBase.RunInUi(delegate()
						{
							this.PanMainLeft_Resize(this.PanMainLeft.ActualWidth);
							this.BtnExtraBack.ShowRefresh();
						}, true);
					}, 130, false),
					ModAnimation.AaCode(delegate
					{
						this._IssuerAccount.Opacity = 1.0;
						this._IssuerAccount.TriggerShowAnimation();
						this.m_RequestAccount.Opacity = 1.0;
						this.m_RequestAccount.PageOnEnter();
					}, 30, true)
				}, "FrmMain PageChange", false);
			}
		}

		// Token: 0x06001263 RID: 4707 RVA: 0x0007C1FC File Offset: 0x0007A3FC
		private void PageChangeExit()
		{
			if (this.m_PrototypeAccount.Count != 0)
			{
				this.PanTitleMain.Visibility = Visibility.Visible;
				this.PanTitleMain.IsHitTestVisible = true;
				this.PanTitleInner.IsHitTestVisible = false;
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaOpacity(this.PanTitleInner, -this.PanTitleInner.Opacity, 150, 0, null, false),
					ModAnimation.AaX(this.PanTitleInner, -18.0 - this.PanTitleInner.Margin.Left, 150, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaOpacity(this.PanTitleMain, 1.0 - this.PanTitleMain.Opacity, 150, 200, null, false),
					ModAnimation.AaX(this.PanTitleMain, -this.PanTitleMain.Margin.Left, 350, 200, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Weak), false),
					ModAnimation.AaCode(delegate
					{
						this.PanTitleInner.Visibility = Visibility.Collapsed;
					}, 0, true)
				}, "FrmMain Titlebar FirstLayer", false);
				this.m_PrototypeAccount.Clear();
			}
		}

		// Token: 0x06001264 RID: 4708 RVA: 0x0007C340 File Offset: 0x0007A540
		private void PanMainLeft_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (e.WidthChanged)
			{
				this.PanMainLeft_Resize(e.NewSize.Width);
			}
		}

		// Token: 0x06001265 RID: 4709 RVA: 0x0007C36C File Offset: 0x0007A56C
		private void PanMainLeft_Resize(double NewWidth)
		{
			if (Math.Abs(NewWidth - this.RectLeftBackground.Width) >= 0.1)
			{
				if (ModAnimation.DefineModel() == 0)
				{
					if (this.PanMain.Opacity < 0.1)
					{
						this.PanMainLeft.IsHitTestVisible = false;
					}
					if (NewWidth > 0.0)
					{
						ModAnimation.AniStart(new ModAnimation.AniData[]
						{
							ModAnimation.AaWidth(this.RectLeftBackground, NewWidth - this.RectLeftBackground.Width, 400, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.ExtraStrong), false),
							ModAnimation.AaOpacity(this.RectLeftShadow, 1.0 - this.RectLeftShadow.Opacity, 200, 0, null, false),
							ModAnimation.AaCode(delegate
							{
								this.PanMainLeft.IsHitTestVisible = true;
							}, 250, false)
						}, "FrmMain LeftChange", true);
						return;
					}
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaWidth(this.RectLeftBackground, -this.RectLeftBackground.Width, 200, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
						ModAnimation.AaOpacity(this.RectLeftShadow, -this.RectLeftShadow.Opacity, 200, 0, null, false),
						ModAnimation.AaCode(delegate
						{
							this.PanMainLeft.IsHitTestVisible = true;
						}, 170, false)
					}, "FrmMain LeftChange", true);
					return;
				}
				else
				{
					this.RectLeftBackground.Width = NewWidth;
					this.PanMainLeft.IsHitTestVisible = true;
					ModAnimation.AniStop("FrmMain LeftChange");
				}
			}
		}

		// Token: 0x06001266 RID: 4710 RVA: 0x0000AD23 File Offset: 0x00008F23
		public void DragTick()
		{
			if (ModMain._ParameterState != null && Mouse.LeftButton != MouseButtonState.Pressed)
			{
				this.DragStop();
			}
		}

		// Token: 0x06001267 RID: 4711 RVA: 0x0007C504 File Offset: 0x0007A704
		public void DragDoing()
		{
			if (ModMain._ParameterState != null)
			{
				if (Mouse.LeftButton == MouseButtonState.Pressed)
				{
					NewLateBinding.LateCall(ModMain._ParameterState, null, "DragDoing", new object[0], null, null, null, true);
					return;
				}
				this.DragStop();
			}
		}

		// Token: 0x06001268 RID: 4712 RVA: 0x0000AD3A File Offset: 0x00008F3A
		public void DragStop()
		{
			ModBase.RunInUi((FormMain._Closure$__.$I54-0 == null) ? (FormMain._Closure$__.$I54-0 = delegate()
			{
				if (ModMain._ParameterState != null)
				{
					object objectValue = RuntimeHelpers.GetObjectValue(ModMain._ParameterState);
					ModMain._ParameterState = null;
					NewLateBinding.LateCall(objectValue, null, "DragStop", new object[0], null, null, null, true);
				}
			}) : FormMain._Closure$__.$I54-0, false);
		}

		// Token: 0x06001269 RID: 4713 RVA: 0x0000AD66 File Offset: 0x00008F66
		private void BtnExtraMusic_Click(object sender, EventArgs e)
		{
			ModMusic.MusicControlPause();
		}

		// Token: 0x0600126A RID: 4714 RVA: 0x0000AD6D File Offset: 0x00008F6D
		private void BtnExtraMusic_RightClick(object sender, EventArgs e)
		{
			ModMusic.MusicControlNext();
		}

		// Token: 0x0600126B RID: 4715 RVA: 0x0000AD74 File Offset: 0x00008F74
		private void BtnExtraDownload_Click(object sender, EventArgs e)
		{
			this.PageChange(FormMain.PageType.DownloadManager, FormMain.PageSubType.Default);
		}

		// Token: 0x0600126C RID: 4716 RVA: 0x0000AD83 File Offset: 0x00008F83
		private bool BtnExtraDownload_ShowCheck()
		{
			return ModNet.HasDownloadingTask(false) && !(this.comparatorAccount == FormMain.PageType.DownloadManager);
		}

		// Token: 0x0600126D RID: 4717 RVA: 0x0007C544 File Offset: 0x0007A744
		public void AprilGiveup()
		{
			if (ModMain.m_ComparatorState && !ModMain.m_PrototypeState)
			{
				ModMain.Hint("=D", ModMain.HintType.Finish, true);
				ModMain.m_PrototypeState = true;
				ModMain._FilterAccount.AprilScaleTrans.ScaleX = 1.0;
				ModMain._FilterAccount.AprilScaleTrans.ScaleY = 1.0;
				this.BtnExtraApril.ShowRefresh();
			}
		}

		// Token: 0x0600126E RID: 4718 RVA: 0x0000ADA3 File Offset: 0x00008FA3
		public bool BtnExtraApril_ShowCheck()
		{
			return ModMain.m_ComparatorState && !ModMain.m_PrototypeState && this.comparatorAccount == FormMain.PageType.Launch;
		}

		// Token: 0x0600126F RID: 4719 RVA: 0x0007C5AC File Offset: 0x0007A7AC
		public void BtnExtraShutdown_Click()
		{
			try
			{
				if (ModLaunch.facadeTag != null)
				{
					ModLaunch.facadeTag.Abort();
				}
				try
				{
					foreach (ModWatcher.Watcher watcher in ModWatcher._ItemWrapper)
					{
						watcher.Kill();
					}
				}
				finally
				{
					List<ModWatcher.Watcher>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				ModMain.Hint("已关闭运行中的 Minecraft！", ModMain.HintType.Finish, true);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "强制关闭所有 Minecraft 失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06001270 RID: 4720 RVA: 0x0000ADC6 File Offset: 0x00008FC6
		public bool BtnExtraShutdown_ShowCheck()
		{
			return ModWatcher.factoryWrapper;
		}

		// Token: 0x06001271 RID: 4721 RVA: 0x0007C648 File Offset: 0x0007A848
		private void BtnExtraBack_Click(object sender, EventArgs e)
		{
			MyScrollViewer myScrollViewer = this.BtnExtraBack_GetRealChild();
			myScrollViewer.PerformVerticalOffsetDelta(-myScrollViewer.VerticalOffset);
		}

		// Token: 0x06001272 RID: 4722 RVA: 0x0007C66C File Offset: 0x0007A86C
		private bool BtnExtraBack_ShowCheck()
		{
			MyScrollViewer myScrollViewer = this.BtnExtraBack_GetRealChild();
			return myScrollViewer != null && myScrollViewer.Visibility == Visibility.Visible && myScrollViewer.VerticalOffset > base.Height + (double)(this.BtnExtraBack.Show ? 0 : 1500);
		}

		// Token: 0x06001273 RID: 4723 RVA: 0x0007C6B4 File Offset: 0x0007A8B4
		private MyScrollViewer BtnExtraBack_GetRealChild()
		{
			MyScrollViewer result;
			if (this.PanMainRight.Child == null)
			{
				result = null;
			}
			else
			{
				UIElement child = ((AdornerDecorator)this.PanMainRight.Child).Child;
				if (child == null)
				{
					result = null;
				}
				else if (child is MyScrollViewer)
				{
					result = (MyScrollViewer)child;
				}
				else if (child is Grid && ((Grid)child).Children[0] is MyScrollViewer)
				{
					result = (MyScrollViewer)((Grid)child).Children[0];
				}
				else
				{
					result = null;
				}
			}
			return result;
		}

		// Token: 0x06001274 RID: 4724 RVA: 0x0000ADCD File Offset: 0x00008FCD
		private void FormMain_MouseMove(object sender, MouseEventArgs e)
		{
			this.stateAccount = e;
		}

		// Token: 0x17000325 RID: 805
		// (get) Token: 0x06001275 RID: 4725 RVA: 0x0000ADD6 File Offset: 0x00008FD6
		// (set) Token: 0x06001276 RID: 4726 RVA: 0x0000ADDE File Offset: 0x00008FDE
		internal virtual FormMain WindMain { get; set; }

		// Token: 0x17000326 RID: 806
		// (get) Token: 0x06001277 RID: 4727 RVA: 0x0000ADE7 File Offset: 0x00008FE7
		// (set) Token: 0x06001278 RID: 4728 RVA: 0x0007C73C File Offset: 0x0007A93C
		internal virtual Grid PanBack
		{
			[CompilerGenerated]
			get
			{
				return this.parameterAccount;
			}
			[CompilerGenerated]
			set
			{
				MouseEventHandler value2 = delegate(object sender, MouseEventArgs e)
				{
					this.DragDoing();
				};
				Grid grid = this.parameterAccount;
				if (grid != null)
				{
					grid.MouseMove -= value2;
				}
				this.parameterAccount = value;
				grid = this.parameterAccount;
				if (grid != null)
				{
					grid.MouseMove += value2;
				}
			}
		}

		// Token: 0x17000327 RID: 807
		// (get) Token: 0x06001279 RID: 4729 RVA: 0x0000ADEF File Offset: 0x00008FEF
		// (set) Token: 0x0600127A RID: 4730 RVA: 0x0000ADF7 File Offset: 0x00008FF7
		internal virtual Rectangle ResizerT { get; set; }

		// Token: 0x17000328 RID: 808
		// (get) Token: 0x0600127B RID: 4731 RVA: 0x0000AE00 File Offset: 0x00009000
		// (set) Token: 0x0600127C RID: 4732 RVA: 0x0000AE08 File Offset: 0x00009008
		internal virtual Rectangle ResizerB { get; set; }

		// Token: 0x17000329 RID: 809
		// (get) Token: 0x0600127D RID: 4733 RVA: 0x0000AE11 File Offset: 0x00009011
		// (set) Token: 0x0600127E RID: 4734 RVA: 0x0000AE19 File Offset: 0x00009019
		internal virtual Rectangle ResizerR { get; set; }

		// Token: 0x1700032A RID: 810
		// (get) Token: 0x0600127F RID: 4735 RVA: 0x0000AE22 File Offset: 0x00009022
		// (set) Token: 0x06001280 RID: 4736 RVA: 0x0000AE2A File Offset: 0x0000902A
		internal virtual Rectangle ResizerL { get; set; }

		// Token: 0x1700032B RID: 811
		// (get) Token: 0x06001281 RID: 4737 RVA: 0x0000AE33 File Offset: 0x00009033
		// (set) Token: 0x06001282 RID: 4738 RVA: 0x0000AE3B File Offset: 0x0000903B
		internal virtual Rectangle ResizerLT { get; set; }

		// Token: 0x1700032C RID: 812
		// (get) Token: 0x06001283 RID: 4739 RVA: 0x0000AE44 File Offset: 0x00009044
		// (set) Token: 0x06001284 RID: 4740 RVA: 0x0000AE4C File Offset: 0x0000904C
		internal virtual Rectangle ResizerLB { get; set; }

		// Token: 0x1700032D RID: 813
		// (get) Token: 0x06001285 RID: 4741 RVA: 0x0000AE55 File Offset: 0x00009055
		// (set) Token: 0x06001286 RID: 4742 RVA: 0x0000AE5D File Offset: 0x0000905D
		internal virtual Rectangle ResizerRB { get; set; }

		// Token: 0x1700032E RID: 814
		// (get) Token: 0x06001287 RID: 4743 RVA: 0x0000AE66 File Offset: 0x00009066
		// (set) Token: 0x06001288 RID: 4744 RVA: 0x0000AE6E File Offset: 0x0000906E
		internal virtual Rectangle ResizerRT { get; set; }

		// Token: 0x1700032F RID: 815
		// (get) Token: 0x06001289 RID: 4745 RVA: 0x0000AE77 File Offset: 0x00009077
		// (set) Token: 0x0600128A RID: 4746 RVA: 0x0000AE7F File Offset: 0x0000907F
		internal virtual Border BorderForm { get; set; }

		// Token: 0x17000330 RID: 816
		// (get) Token: 0x0600128B RID: 4747 RVA: 0x0000AE88 File Offset: 0x00009088
		// (set) Token: 0x0600128C RID: 4748 RVA: 0x0000AE90 File Offset: 0x00009090
		internal virtual RectangleGeometry RectForm { get; set; }

		// Token: 0x17000331 RID: 817
		// (get) Token: 0x0600128D RID: 4749 RVA: 0x0000AE99 File Offset: 0x00009099
		// (set) Token: 0x0600128E RID: 4750 RVA: 0x0000AEA1 File Offset: 0x000090A1
		internal virtual Grid PanForm { get; set; }

		// Token: 0x17000332 RID: 818
		// (get) Token: 0x0600128F RID: 4751 RVA: 0x0000AEAA File Offset: 0x000090AA
		// (set) Token: 0x06001290 RID: 4752 RVA: 0x0000AEB2 File Offset: 0x000090B2
		internal virtual Canvas ImgBack { get; set; }

		// Token: 0x17000333 RID: 819
		// (get) Token: 0x06001291 RID: 4753 RVA: 0x0000AEBB File Offset: 0x000090BB
		// (set) Token: 0x06001292 RID: 4754 RVA: 0x0007C780 File Offset: 0x0007A980
		internal virtual Grid PanTitle
		{
			[CompilerGenerated]
			get
			{
				return this.m_BroadcasterAccount;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = new MouseButtonEventHandler(this.FormDragMove);
				Grid broadcasterAccount = this.m_BroadcasterAccount;
				if (broadcasterAccount != null)
				{
					broadcasterAccount.MouseLeftButtonDown -= value2;
				}
				this.m_BroadcasterAccount = value;
				broadcasterAccount = this.m_BroadcasterAccount;
				if (broadcasterAccount != null)
				{
					broadcasterAccount.MouseLeftButtonDown += value2;
				}
			}
		}

		// Token: 0x17000334 RID: 820
		// (get) Token: 0x06001293 RID: 4755 RVA: 0x0000AEC3 File Offset: 0x000090C3
		// (set) Token: 0x06001294 RID: 4756 RVA: 0x0000AECB File Offset: 0x000090CB
		internal virtual Image ImgTitle { get; set; }

		// Token: 0x17000335 RID: 821
		// (get) Token: 0x06001295 RID: 4757 RVA: 0x0000AED4 File Offset: 0x000090D4
		// (set) Token: 0x06001296 RID: 4758 RVA: 0x0007C7C4 File Offset: 0x0007A9C4
		internal virtual MyIconButton BtnTitleClose
		{
			[CompilerGenerated]
			get
			{
				return this._SpecificationAccount;
			}
			[CompilerGenerated]
			set
			{
				MyIconButton.ClickEventHandler value2 = delegate(object sender, EventArgs e)
				{
					this.BtnTitleClose_Click(RuntimeHelpers.GetObjectValue(sender), (RoutedEventArgs)e);
				};
				MyIconButton specificationAccount = this._SpecificationAccount;
				if (specificationAccount != null)
				{
					specificationAccount.Click -= value2;
				}
				this._SpecificationAccount = value;
				specificationAccount = this._SpecificationAccount;
				if (specificationAccount != null)
				{
					specificationAccount.Click += value2;
				}
			}
		}

		// Token: 0x17000336 RID: 822
		// (get) Token: 0x06001297 RID: 4759 RVA: 0x0000AEDC File Offset: 0x000090DC
		// (set) Token: 0x06001298 RID: 4760 RVA: 0x0007C808 File Offset: 0x0007AA08
		internal virtual MyIconButton BtnTitleMin
		{
			[CompilerGenerated]
			get
			{
				return this.m_PredicateAccount;
			}
			[CompilerGenerated]
			set
			{
				MyIconButton.ClickEventHandler value2 = delegate(object sender, EventArgs e)
				{
					this.BtnTitleMin_Click();
				};
				MyIconButton predicateAccount = this.m_PredicateAccount;
				if (predicateAccount != null)
				{
					predicateAccount.Click -= value2;
				}
				this.m_PredicateAccount = value;
				predicateAccount = this.m_PredicateAccount;
				if (predicateAccount != null)
				{
					predicateAccount.Click += value2;
				}
			}
		}

		// Token: 0x17000337 RID: 823
		// (get) Token: 0x06001299 RID: 4761 RVA: 0x0000AEE4 File Offset: 0x000090E4
		// (set) Token: 0x0600129A RID: 4762 RVA: 0x0000AEEC File Offset: 0x000090EC
		internal virtual Grid PanTitleMain { get; set; }

		// Token: 0x17000338 RID: 824
		// (get) Token: 0x0600129B RID: 4763 RVA: 0x0000AEF5 File Offset: 0x000090F5
		// (set) Token: 0x0600129C RID: 4764 RVA: 0x0000AEFD File Offset: 0x000090FD
		internal virtual System.Windows.Shapes.Path ShapeTitleLogo { get; set; }

		// Token: 0x17000339 RID: 825
		// (get) Token: 0x0600129D RID: 4765 RVA: 0x0000AF06 File Offset: 0x00009106
		// (set) Token: 0x0600129E RID: 4766 RVA: 0x0000AF0E File Offset: 0x0000910E
		internal virtual TextBlock LabTitleLogo { get; set; }

		// Token: 0x1700033A RID: 826
		// (get) Token: 0x0600129F RID: 4767 RVA: 0x0000AF17 File Offset: 0x00009117
		// (set) Token: 0x060012A0 RID: 4768 RVA: 0x0000AF1F File Offset: 0x0000911F
		internal virtual Image ImageTitleLogo { get; set; }

		// Token: 0x1700033B RID: 827
		// (get) Token: 0x060012A1 RID: 4769 RVA: 0x0000AF28 File Offset: 0x00009128
		// (set) Token: 0x060012A2 RID: 4770 RVA: 0x0000AF30 File Offset: 0x00009130
		internal virtual StackPanel PanTitleSelect { get; set; }

		// Token: 0x1700033C RID: 828
		// (get) Token: 0x060012A3 RID: 4771 RVA: 0x0000AF39 File Offset: 0x00009139
		// (set) Token: 0x060012A4 RID: 4772 RVA: 0x0007C84C File Offset: 0x0007AA4C
		internal virtual MyRadioButton BtnTitleSelect0
		{
			[CompilerGenerated]
			get
			{
				return this._MapAccount;
			}
			[CompilerGenerated]
			set
			{
				MyRadioButton.CheckEventHandler obj = delegate(object a0, bool a1)
				{
					this.BtnTitleSelect_Click((MyRadioButton)a0, a1);
				};
				MyRadioButton mapAccount = this._MapAccount;
				if (mapAccount != null)
				{
					mapAccount.AddTag(obj);
				}
				this._MapAccount = value;
				mapAccount = this._MapAccount;
				if (mapAccount != null)
				{
					mapAccount.CountTag(obj);
				}
			}
		}

		// Token: 0x1700033D RID: 829
		// (get) Token: 0x060012A5 RID: 4773 RVA: 0x0000AF41 File Offset: 0x00009141
		// (set) Token: 0x060012A6 RID: 4774 RVA: 0x0007C890 File Offset: 0x0007AA90
		internal virtual MyRadioButton BtnTitleSelect1
		{
			[CompilerGenerated]
			get
			{
				return this._EventAccount;
			}
			[CompilerGenerated]
			set
			{
				MyRadioButton.CheckEventHandler obj = delegate(object a0, bool a1)
				{
					this.BtnTitleSelect_Click((MyRadioButton)a0, a1);
				};
				MyRadioButton eventAccount = this._EventAccount;
				if (eventAccount != null)
				{
					eventAccount.AddTag(obj);
				}
				this._EventAccount = value;
				eventAccount = this._EventAccount;
				if (eventAccount != null)
				{
					eventAccount.CountTag(obj);
				}
			}
		}

		// Token: 0x1700033E RID: 830
		// (get) Token: 0x060012A7 RID: 4775 RVA: 0x0000AF49 File Offset: 0x00009149
		// (set) Token: 0x060012A8 RID: 4776 RVA: 0x0007C8D4 File Offset: 0x0007AAD4
		internal virtual MyRadioButton BtnTitleSelect2
		{
			[CompilerGenerated]
			get
			{
				return this.algoAccount;
			}
			[CompilerGenerated]
			set
			{
				MyRadioButton.CheckEventHandler obj = delegate(object a0, bool a1)
				{
					this.BtnTitleSelect_Click((MyRadioButton)a0, a1);
				};
				MyRadioButton myRadioButton = this.algoAccount;
				if (myRadioButton != null)
				{
					myRadioButton.AddTag(obj);
				}
				this.algoAccount = value;
				myRadioButton = this.algoAccount;
				if (myRadioButton != null)
				{
					myRadioButton.CountTag(obj);
				}
			}
		}

		// Token: 0x1700033F RID: 831
		// (get) Token: 0x060012A9 RID: 4777 RVA: 0x0000AF51 File Offset: 0x00009151
		// (set) Token: 0x060012AA RID: 4778 RVA: 0x0007C918 File Offset: 0x0007AB18
		internal virtual MyRadioButton BtnTitleSelect3
		{
			[CompilerGenerated]
			get
			{
				return this.poolAccount;
			}
			[CompilerGenerated]
			set
			{
				MyRadioButton.CheckEventHandler obj = delegate(object a0, bool a1)
				{
					this.BtnTitleSelect_Click((MyRadioButton)a0, a1);
				};
				MyRadioButton myRadioButton = this.poolAccount;
				if (myRadioButton != null)
				{
					myRadioButton.AddTag(obj);
				}
				this.poolAccount = value;
				myRadioButton = this.poolAccount;
				if (myRadioButton != null)
				{
					myRadioButton.CountTag(obj);
				}
			}
		}

		// Token: 0x17000340 RID: 832
		// (get) Token: 0x060012AB RID: 4779 RVA: 0x0000AF59 File Offset: 0x00009159
		// (set) Token: 0x060012AC RID: 4780 RVA: 0x0007C95C File Offset: 0x0007AB5C
		internal virtual MyRadioButton BtnTitleSelect4
		{
			[CompilerGenerated]
			get
			{
				return this._PublisherAccount;
			}
			[CompilerGenerated]
			set
			{
				MyRadioButton.CheckEventHandler obj = delegate(object a0, bool a1)
				{
					this.BtnTitleSelect_Click((MyRadioButton)a0, a1);
				};
				MyRadioButton publisherAccount = this._PublisherAccount;
				if (publisherAccount != null)
				{
					publisherAccount.AddTag(obj);
				}
				this._PublisherAccount = value;
				publisherAccount = this._PublisherAccount;
				if (publisherAccount != null)
				{
					publisherAccount.CountTag(obj);
				}
			}
		}

		// Token: 0x17000341 RID: 833
		// (get) Token: 0x060012AD RID: 4781 RVA: 0x0000AF61 File Offset: 0x00009161
		// (set) Token: 0x060012AE RID: 4782 RVA: 0x0000AF69 File Offset: 0x00009169
		internal virtual Grid PanTitleInner { get; set; }

		// Token: 0x17000342 RID: 834
		// (get) Token: 0x060012AF RID: 4783 RVA: 0x0000AF72 File Offset: 0x00009172
		// (set) Token: 0x060012B0 RID: 4784 RVA: 0x0007C9A0 File Offset: 0x0007ABA0
		internal virtual MyIconButton BtnTitleInner
		{
			[CompilerGenerated]
			get
			{
				return this.testAccount;
			}
			[CompilerGenerated]
			set
			{
				MyIconButton.ClickEventHandler value2 = delegate(object sender, EventArgs e)
				{
					this.PageBack();
				};
				MyIconButton myIconButton = this.testAccount;
				if (myIconButton != null)
				{
					myIconButton.Click -= value2;
				}
				this.testAccount = value;
				myIconButton = this.testAccount;
				if (myIconButton != null)
				{
					myIconButton.Click += value2;
				}
			}
		}

		// Token: 0x17000343 RID: 835
		// (get) Token: 0x060012B1 RID: 4785 RVA: 0x0000AF7A File Offset: 0x0000917A
		// (set) Token: 0x060012B2 RID: 4786 RVA: 0x0000AF82 File Offset: 0x00009182
		internal virtual TextBlock LabTitleInner { get; set; }

		// Token: 0x17000344 RID: 836
		// (get) Token: 0x060012B3 RID: 4787 RVA: 0x0000AF8B File Offset: 0x0000918B
		// (set) Token: 0x060012B4 RID: 4788 RVA: 0x0000AF93 File Offset: 0x00009193
		internal virtual Grid PanLeft { get; set; }

		// Token: 0x17000345 RID: 837
		// (get) Token: 0x060012B5 RID: 4789 RVA: 0x0000AF9C File Offset: 0x0000919C
		// (set) Token: 0x060012B6 RID: 4790 RVA: 0x0000AFA4 File Offset: 0x000091A4
		internal virtual Rectangle RectLeftBackground { get; set; }

		// Token: 0x17000346 RID: 838
		// (get) Token: 0x060012B7 RID: 4791 RVA: 0x0000AFAD File Offset: 0x000091AD
		// (set) Token: 0x060012B8 RID: 4792 RVA: 0x0000AFB5 File Offset: 0x000091B5
		internal virtual Rectangle RectLeftShadow { get; set; }

		// Token: 0x17000347 RID: 839
		// (get) Token: 0x060012B9 RID: 4793 RVA: 0x0000AFBE File Offset: 0x000091BE
		// (set) Token: 0x060012BA RID: 4794 RVA: 0x0000AFC6 File Offset: 0x000091C6
		internal virtual Grid PanMain { get; set; }

		// Token: 0x17000348 RID: 840
		// (get) Token: 0x060012BB RID: 4795 RVA: 0x0000AFCF File Offset: 0x000091CF
		// (set) Token: 0x060012BC RID: 4796 RVA: 0x0000AFD7 File Offset: 0x000091D7
		internal virtual Border PanMainRight { get; set; }

		// Token: 0x17000349 RID: 841
		// (get) Token: 0x060012BD RID: 4797 RVA: 0x0000AFE0 File Offset: 0x000091E0
		// (set) Token: 0x060012BE RID: 4798 RVA: 0x0007C9E4 File Offset: 0x0007ABE4
		internal virtual Border PanMainLeft
		{
			[CompilerGenerated]
			get
			{
				return this.visitorAccount;
			}
			[CompilerGenerated]
			set
			{
				SizeChangedEventHandler value2 = new SizeChangedEventHandler(this.PanMainLeft_SizeChanged);
				Border border = this.visitorAccount;
				if (border != null)
				{
					border.SizeChanged -= value2;
				}
				this.visitorAccount = value;
				border = this.visitorAccount;
				if (border != null)
				{
					border.SizeChanged += value2;
				}
			}
		}

		// Token: 0x1700034A RID: 842
		// (get) Token: 0x060012BF RID: 4799 RVA: 0x0000AFE8 File Offset: 0x000091E8
		// (set) Token: 0x060012C0 RID: 4800 RVA: 0x0000AFF0 File Offset: 0x000091F0
		internal virtual StackPanel PanHint { get; set; }

		// Token: 0x1700034B RID: 843
		// (get) Token: 0x060012C1 RID: 4801 RVA: 0x0000AFF9 File Offset: 0x000091F9
		// (set) Token: 0x060012C2 RID: 4802 RVA: 0x0007CA28 File Offset: 0x0007AC28
		internal virtual MyExtraButton BtnExtraBack
		{
			[CompilerGenerated]
			get
			{
				return this._ParamAccount;
			}
			[CompilerGenerated]
			set
			{
				MyExtraButton.ClickEventHandler obj = new MyExtraButton.ClickEventHandler(this.BtnExtraBack_Click);
				MyExtraButton paramAccount = this._ParamAccount;
				if (paramAccount != null)
				{
					paramAccount.CreateModel(obj);
				}
				this._ParamAccount = value;
				paramAccount = this._ParamAccount;
				if (paramAccount != null)
				{
					paramAccount.AssetModel(obj);
				}
			}
		}

		// Token: 0x1700034C RID: 844
		// (get) Token: 0x060012C3 RID: 4803 RVA: 0x0000B001 File Offset: 0x00009201
		// (set) Token: 0x060012C4 RID: 4804 RVA: 0x0007CA6C File Offset: 0x0007AC6C
		internal virtual MyExtraButton BtnExtraDownload
		{
			[CompilerGenerated]
			get
			{
				return this.m_BaseAccount;
			}
			[CompilerGenerated]
			set
			{
				MyExtraButton.ClickEventHandler obj = new MyExtraButton.ClickEventHandler(this.BtnExtraDownload_Click);
				MyExtraButton baseAccount = this.m_BaseAccount;
				if (baseAccount != null)
				{
					baseAccount.CreateModel(obj);
				}
				this.m_BaseAccount = value;
				baseAccount = this.m_BaseAccount;
				if (baseAccount != null)
				{
					baseAccount.AssetModel(obj);
				}
			}
		}

		// Token: 0x1700034D RID: 845
		// (get) Token: 0x060012C5 RID: 4805 RVA: 0x0000B009 File Offset: 0x00009209
		// (set) Token: 0x060012C6 RID: 4806 RVA: 0x0007CAB0 File Offset: 0x0007ACB0
		internal virtual MyExtraButton BtnExtraApril
		{
			[CompilerGenerated]
			get
			{
				return this.productAccount;
			}
			[CompilerGenerated]
			set
			{
				MyExtraButton.ClickEventHandler obj = delegate(object sender, MouseButtonEventArgs e)
				{
					this.AprilGiveup();
				};
				MyExtraButton myExtraButton = this.productAccount;
				if (myExtraButton != null)
				{
					myExtraButton.CreateModel(obj);
				}
				this.productAccount = value;
				myExtraButton = this.productAccount;
				if (myExtraButton != null)
				{
					myExtraButton.AssetModel(obj);
				}
			}
		}

		// Token: 0x1700034E RID: 846
		// (get) Token: 0x060012C7 RID: 4807 RVA: 0x0000B011 File Offset: 0x00009211
		// (set) Token: 0x060012C8 RID: 4808 RVA: 0x0007CAF4 File Offset: 0x0007ACF4
		internal virtual MyExtraButton BtnExtraShutdown
		{
			[CompilerGenerated]
			get
			{
				return this._AttrAccount;
			}
			[CompilerGenerated]
			set
			{
				MyExtraButton.ClickEventHandler obj = delegate(object sender, MouseButtonEventArgs e)
				{
					this.BtnExtraShutdown_Click();
				};
				MyExtraButton attrAccount = this._AttrAccount;
				if (attrAccount != null)
				{
					attrAccount.CreateModel(obj);
				}
				this._AttrAccount = value;
				attrAccount = this._AttrAccount;
				if (attrAccount != null)
				{
					attrAccount.AssetModel(obj);
				}
			}
		}

		// Token: 0x1700034F RID: 847
		// (get) Token: 0x060012C9 RID: 4809 RVA: 0x0000B019 File Offset: 0x00009219
		// (set) Token: 0x060012CA RID: 4810 RVA: 0x0007CB38 File Offset: 0x0007AD38
		internal virtual MyExtraButton BtnExtraMusic
		{
			[CompilerGenerated]
			get
			{
				return this.facadeAccount;
			}
			[CompilerGenerated]
			set
			{
				MyExtraButton.ClickEventHandler obj = new MyExtraButton.ClickEventHandler(this.BtnExtraMusic_Click);
				MyExtraButton.RightClickEventHandler obj2 = new MyExtraButton.RightClickEventHandler(this.BtnExtraMusic_RightClick);
				MyExtraButton myExtraButton = this.facadeAccount;
				if (myExtraButton != null)
				{
					myExtraButton.CreateModel(obj);
					myExtraButton.RevertModel(obj2);
				}
				this.facadeAccount = value;
				myExtraButton = this.facadeAccount;
				if (myExtraButton != null)
				{
					myExtraButton.AssetModel(obj);
					myExtraButton.PostModel(obj2);
				}
			}
		}

		// Token: 0x17000350 RID: 848
		// (get) Token: 0x060012CB RID: 4811 RVA: 0x0000B021 File Offset: 0x00009221
		// (set) Token: 0x060012CC RID: 4812 RVA: 0x0007CB98 File Offset: 0x0007AD98
		internal virtual Grid PanMsg
		{
			[CompilerGenerated]
			get
			{
				return this.bridgeAccount;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = new MouseButtonEventHandler(this.FormDragMove);
				Grid grid = this.bridgeAccount;
				if (grid != null)
				{
					grid.MouseLeftButtonDown -= value2;
				}
				this.bridgeAccount = value;
				grid = this.bridgeAccount;
				if (grid != null)
				{
					grid.MouseLeftButtonDown += value2;
				}
			}
		}

		// Token: 0x040008E9 RID: 2281
		private bool m_ProcRequest;

		// Token: 0x040008EA RID: 2282
		public static bool _ModelAccount = false;

		// Token: 0x040008EB RID: 2283
		private static bool wrapperAccount = false;

		// Token: 0x040008EC RID: 2284
		public bool _RepositoryAccount;

		// Token: 0x040008ED RID: 2285
		public bool _ResolverAccount;

		// Token: 0x040008EE RID: 2286
		private bool tagAccount;

		// Token: 0x040008EF RID: 2287
		public FormMain.PageStackData comparatorAccount;

		// Token: 0x040008F0 RID: 2288
		private readonly List<FormMain.PageStackData> m_PrototypeAccount;

		// Token: 0x040008F1 RID: 2289
		public MyPageLeft _IssuerAccount;

		// Token: 0x040008F2 RID: 2290
		public MyPageRight m_RequestAccount;

		// Token: 0x040008F3 RID: 2291
		private bool accountAccount;

		// Token: 0x040008F4 RID: 2292
		public MouseEventArgs stateAccount;

		// Token: 0x040008F5 RID: 2293
		[AccessedThroughProperty("WindMain")]
		[CompilerGenerated]
		private FormMain proccesorAccount;

		// Token: 0x040008F6 RID: 2294
		[CompilerGenerated]
		[AccessedThroughProperty("PanBack")]
		private Grid parameterAccount;

		// Token: 0x040008F7 RID: 2295
		[CompilerGenerated]
		[AccessedThroughProperty("ResizerT")]
		private Rectangle _AuthenticationAccount;

		// Token: 0x040008F8 RID: 2296
		[AccessedThroughProperty("ResizerB")]
		[CompilerGenerated]
		private Rectangle reponseAccount;

		// Token: 0x040008F9 RID: 2297
		[AccessedThroughProperty("ResizerR")]
		[CompilerGenerated]
		private Rectangle containerAccount;

		// Token: 0x040008FA RID: 2298
		[AccessedThroughProperty("ResizerL")]
		[CompilerGenerated]
		private Rectangle m_CodeAccount;

		// Token: 0x040008FB RID: 2299
		[AccessedThroughProperty("ResizerLT")]
		[CompilerGenerated]
		private Rectangle tokenizerAccount;

		// Token: 0x040008FC RID: 2300
		[AccessedThroughProperty("ResizerLB")]
		[CompilerGenerated]
		private Rectangle definitionAccount;

		// Token: 0x040008FD RID: 2301
		[CompilerGenerated]
		[AccessedThroughProperty("ResizerRB")]
		private Rectangle paramsAccount;

		// Token: 0x040008FE RID: 2302
		[AccessedThroughProperty("ResizerRT")]
		[CompilerGenerated]
		private Rectangle _MockAccount;

		// Token: 0x040008FF RID: 2303
		[CompilerGenerated]
		[AccessedThroughProperty("BorderForm")]
		private Border _AdapterAccount;

		// Token: 0x04000900 RID: 2304
		[CompilerGenerated]
		[AccessedThroughProperty("RectForm")]
		private RectangleGeometry _InitializerAccount;

		// Token: 0x04000901 RID: 2305
		[AccessedThroughProperty("PanForm")]
		[CompilerGenerated]
		private Grid systemAccount;

		// Token: 0x04000902 RID: 2306
		[AccessedThroughProperty("ImgBack")]
		[CompilerGenerated]
		private Canvas m_WriterAccount;

		// Token: 0x04000903 RID: 2307
		[AccessedThroughProperty("PanTitle")]
		[CompilerGenerated]
		private Grid m_BroadcasterAccount;

		// Token: 0x04000904 RID: 2308
		[AccessedThroughProperty("ImgTitle")]
		[CompilerGenerated]
		private Image m_AttributeAccount;

		// Token: 0x04000905 RID: 2309
		[AccessedThroughProperty("BtnTitleClose")]
		[CompilerGenerated]
		private MyIconButton _SpecificationAccount;

		// Token: 0x04000906 RID: 2310
		[AccessedThroughProperty("BtnTitleMin")]
		[CompilerGenerated]
		private MyIconButton m_PredicateAccount;

		// Token: 0x04000907 RID: 2311
		[CompilerGenerated]
		[AccessedThroughProperty("PanTitleMain")]
		private Grid m_ClientAccount;

		// Token: 0x04000908 RID: 2312
		[CompilerGenerated]
		[AccessedThroughProperty("ShapeTitleLogo")]
		private System.Windows.Shapes.Path m_InfoAccount;

		// Token: 0x04000909 RID: 2313
		[CompilerGenerated]
		[AccessedThroughProperty("LabTitleLogo")]
		private TextBlock _DecoratorAccount;

		// Token: 0x0400090A RID: 2314
		[AccessedThroughProperty("ImageTitleLogo")]
		[CompilerGenerated]
		private Image _PropertyAccount;

		// Token: 0x0400090B RID: 2315
		[CompilerGenerated]
		[AccessedThroughProperty("PanTitleSelect")]
		private StackPanel descriptorAccount;

		// Token: 0x0400090C RID: 2316
		[AccessedThroughProperty("BtnTitleSelect0")]
		[CompilerGenerated]
		private MyRadioButton _MapAccount;

		// Token: 0x0400090D RID: 2317
		[CompilerGenerated]
		[AccessedThroughProperty("BtnTitleSelect1")]
		private MyRadioButton _EventAccount;

		// Token: 0x0400090E RID: 2318
		[AccessedThroughProperty("BtnTitleSelect2")]
		[CompilerGenerated]
		private MyRadioButton algoAccount;

		// Token: 0x0400090F RID: 2319
		[AccessedThroughProperty("BtnTitleSelect3")]
		[CompilerGenerated]
		private MyRadioButton poolAccount;

		// Token: 0x04000910 RID: 2320
		[AccessedThroughProperty("BtnTitleSelect4")]
		[CompilerGenerated]
		private MyRadioButton _PublisherAccount;

		// Token: 0x04000911 RID: 2321
		[AccessedThroughProperty("PanTitleInner")]
		[CompilerGenerated]
		private Grid _WatcherAccount;

		// Token: 0x04000912 RID: 2322
		[AccessedThroughProperty("BtnTitleInner")]
		[CompilerGenerated]
		private MyIconButton testAccount;

		// Token: 0x04000913 RID: 2323
		[AccessedThroughProperty("LabTitleInner")]
		[CompilerGenerated]
		private TextBlock m_TaskAccount;

		// Token: 0x04000914 RID: 2324
		[AccessedThroughProperty("PanLeft")]
		[CompilerGenerated]
		private Grid iteratorAccount;

		// Token: 0x04000915 RID: 2325
		[AccessedThroughProperty("RectLeftBackground")]
		[CompilerGenerated]
		private Rectangle serializerAccount;

		// Token: 0x04000916 RID: 2326
		[CompilerGenerated]
		[AccessedThroughProperty("RectLeftShadow")]
		private Rectangle _RoleAccount;

		// Token: 0x04000917 RID: 2327
		[AccessedThroughProperty("PanMain")]
		[CompilerGenerated]
		private Grid _ValueAccount;

		// Token: 0x04000918 RID: 2328
		[CompilerGenerated]
		[AccessedThroughProperty("PanMainRight")]
		private Border _RecordAccount;

		// Token: 0x04000919 RID: 2329
		[CompilerGenerated]
		[AccessedThroughProperty("PanMainLeft")]
		private Border visitorAccount;

		// Token: 0x0400091A RID: 2330
		[CompilerGenerated]
		[AccessedThroughProperty("PanHint")]
		private StackPanel m_HelperAccount;

		// Token: 0x0400091B RID: 2331
		[AccessedThroughProperty("BtnExtraBack")]
		[CompilerGenerated]
		private MyExtraButton _ParamAccount;

		// Token: 0x0400091C RID: 2332
		[CompilerGenerated]
		[AccessedThroughProperty("BtnExtraDownload")]
		private MyExtraButton m_BaseAccount;

		// Token: 0x0400091D RID: 2333
		[AccessedThroughProperty("BtnExtraApril")]
		[CompilerGenerated]
		private MyExtraButton productAccount;

		// Token: 0x0400091E RID: 2334
		[CompilerGenerated]
		[AccessedThroughProperty("BtnExtraShutdown")]
		private MyExtraButton _AttrAccount;

		// Token: 0x0400091F RID: 2335
		[AccessedThroughProperty("BtnExtraMusic")]
		[CompilerGenerated]
		private MyExtraButton facadeAccount;

		// Token: 0x04000920 RID: 2336
		[AccessedThroughProperty("PanMsg")]
		[CompilerGenerated]
		private Grid bridgeAccount;

		// Token: 0x0200018E RID: 398
		public enum PageType
		{
			// Token: 0x04000923 RID: 2339
			Launch,
			// Token: 0x04000924 RID: 2340
			Download,
			// Token: 0x04000925 RID: 2341
			Link,
			// Token: 0x04000926 RID: 2342
			Setup,
			// Token: 0x04000927 RID: 2343
			Other,
			// Token: 0x04000928 RID: 2344
			VersionSelect,
			// Token: 0x04000929 RID: 2345
			DownloadManager,
			// Token: 0x0400092A RID: 2346
			VersionSetup,
			// Token: 0x0400092B RID: 2347
			CfDetail,
			// Token: 0x0400092C RID: 2348
			HelpDetail
		}

		// Token: 0x0200018F RID: 399
		public enum PageSubType
		{
			// Token: 0x0400092E RID: 2350
			Default,
			// Token: 0x0400092F RID: 2351
			DownloadInstall,
			// Token: 0x04000930 RID: 2352
			DownloadClient = 4,
			// Token: 0x04000931 RID: 2353
			DownloadOptiFine,
			// Token: 0x04000932 RID: 2354
			DownloadForge,
			// Token: 0x04000933 RID: 2355
			DownloadFabric,
			// Token: 0x04000934 RID: 2356
			DownloadLiteLoader,
			// Token: 0x04000935 RID: 2357
			DownloadMod = 10,
			// Token: 0x04000936 RID: 2358
			DownloadPack,
			// Token: 0x04000937 RID: 2359
			SetupLaunch = 0,
			// Token: 0x04000938 RID: 2360
			SetupUI,
			// Token: 0x04000939 RID: 2361
			SetupSystem,
			// Token: 0x0400093A RID: 2362
			SetupLink,
			// Token: 0x0400093B RID: 2363
			LinkCato = 2,
			// Token: 0x0400093C RID: 2364
			LinkIoi,
			// Token: 0x0400093D RID: 2365
			LinkSetup = 5,
			// Token: 0x0400093E RID: 2366
			LinkHelp,
			// Token: 0x0400093F RID: 2367
			LinkFeedback,
			// Token: 0x04000940 RID: 2368
			OtherHelp = 0,
			// Token: 0x04000941 RID: 2369
			OtherAbout,
			// Token: 0x04000942 RID: 2370
			OtherTest,
			// Token: 0x04000943 RID: 2371
			OtherFeedback,
			// Token: 0x04000944 RID: 2372
			VersionOverall = 0,
			// Token: 0x04000945 RID: 2373
			VersionSetup,
			// Token: 0x04000946 RID: 2374
			VersionMod,
			// Token: 0x04000947 RID: 2375
			VersionModDisabled
		}

		// Token: 0x02000190 RID: 400
		public class PageStackData
		{
			// Token: 0x060012EB RID: 4843 RVA: 0x0007D3E0 File Offset: 0x0007B5E0
			public override bool Equals(object other)
			{
				bool result;
				if (other == null)
				{
					result = false;
				}
				else if (other is FormMain.PageStackData)
				{
					FormMain.PageStackData pageStackData = (FormMain.PageStackData)other;
					if (this.m_CreatorParameter != pageStackData.m_CreatorParameter)
					{
						result = false;
					}
					else if (this.m_ObjectParameter == null)
					{
						result = (pageStackData.m_ObjectParameter == null);
					}
					else
					{
						result = (pageStackData.m_ObjectParameter != null && this.m_ObjectParameter.Equals(RuntimeHelpers.GetObjectValue(pageStackData.m_ObjectParameter)));
					}
				}
				else
				{
					result = (other is int && !Operators.ConditionalCompareObjectNotEqual(this.m_CreatorParameter, other, true) && this.m_ObjectParameter == null);
				}
				return result;
			}

			// Token: 0x060012EC RID: 4844 RVA: 0x0000B12B File Offset: 0x0000932B
			public static bool operator ==(FormMain.PageStackData left, FormMain.PageStackData right)
			{
				return EqualityComparer<FormMain.PageStackData>.Default.Equals(left, right);
			}

			// Token: 0x060012ED RID: 4845 RVA: 0x0000B139 File Offset: 0x00009339
			public static bool operator !=(FormMain.PageStackData left, FormMain.PageStackData right)
			{
				return !(left == right);
			}

			// Token: 0x060012EE RID: 4846 RVA: 0x0000B145 File Offset: 0x00009345
			public static implicit operator FormMain.PageStackData(FormMain.PageType Value)
			{
				return new FormMain.PageStackData
				{
					m_CreatorParameter = Value
				};
			}

			// Token: 0x060012EF RID: 4847 RVA: 0x0000B153 File Offset: 0x00009353
			public static implicit operator FormMain.PageType(FormMain.PageStackData Value)
			{
				return Value.m_CreatorParameter;
			}

			// Token: 0x04000948 RID: 2376
			public FormMain.PageType m_CreatorParameter;

			// Token: 0x04000949 RID: 2377
			public object[] m_ObjectParameter;
		}
	}
}
