﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000055 RID: 85
	[DesignerGenerated]
	public class MyMsgInput : Grid, IComponentConnector
	{
		// Token: 0x0600023C RID: 572 RVA: 0x0001634C File Offset: 0x0001454C
		public MyMsgInput(ModMain.MyMsgBoxConverter Converter)
		{
			base.Loaded += new RoutedEventHandler(this.Load);
			this._Status = ModBase.GetUuid();
			try
			{
				this.InitializeComponent();
				this.Btn1.Name = this.Btn1.Name + Conversions.ToString(ModBase.GetUuid());
				this.Btn2.Name = this.Btn2.Name + Conversions.ToString(ModBase.GetUuid());
				this.Btn3.Name = this.Btn3.Name + Conversions.ToString(ModBase.GetUuid());
				this.m_Message = Converter;
				this.LabTitle.Text = Converter.Title;
				this.TextCaption.Text = Conversions.ToString(Converter.m_ComposerParameter);
				this.TextCaption.HintText = Converter.mapperParameter;
				this.TextCaption.ValidateRules = Converter.itemParameter;
				this.Btn1.Text = Converter._ProcessParameter;
				if (Converter.m_OrderParameter)
				{
					this.Btn1.ColorType = MyButton.ColorState.Red;
					this.LabTitle.SetResourceReference(TextBlock.ForegroundProperty, "ColorBrushRedLight");
					this.ShapeLine.SetResourceReference(Shape.FillProperty, "ColorBrushRedLight");
				}
				this.Btn2.Text = Converter._ValParameter;
				this.Btn3.Text = Converter.utilsParameter;
				this.Btn2.Visibility = ((Operators.CompareString(Converter._ValParameter, "", true) == 0) ? Visibility.Collapsed : Visibility.Visible);
				this.Btn3.Visibility = ((Operators.CompareString(Converter.utilsParameter, "", true) == 0) ? Visibility.Collapsed : Visibility.Visible);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "输入弹窗初始化失败", ModBase.LogLevel.Hint, "出现错误");
			}
		}

		// Token: 0x0600023D RID: 573 RVA: 0x00016534 File Offset: 0x00014734
		private void Load(object sender, EventArgs e)
		{
			try
			{
				if (this.Btn2.IsVisible && this.Btn1.ColorType != MyButton.ColorState.Red)
				{
					this.Btn1.ColorType = MyButton.ColorState.Highlight;
				}
				this.ShapeLine.StrokeThickness = ModBase.smethod_4(1.0);
				base.Measure(new Size(ModMain.m_CollectionAccount.Width, ModMain.m_CollectionAccount.Height));
				base.Arrange(new Rect(0.0, 0.0, ModMain.m_CollectionAccount.Width, ModMain.m_CollectionAccount.Height));
				if (ModMain.m_CollectionAccount.Width - base.ActualWidth < 20.0)
				{
					base.Width = ModMain.m_CollectionAccount.Width - ModBase.smethod_4(2.0);
				}
				this.TextCaption.Focus();
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaColor(ModMain.m_CollectionAccount.PanMsg, Panel.BackgroundProperty, new ModBase.MyColor(60.0, 0.0, 0.0, 0.0), 250, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaColor(this.PanBorder, Border.BackgroundProperty, new ModBase.MyColor(255.0, 0.0, 0.0, 0.0), 150, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaOpacity(this.EffectShadow, 0.75, 400, 50, null, false),
					ModAnimation.AaWidth(this.ShapeLine, this.ShapeLine.ActualWidth, 250, 100, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaOpacity(this.ShapeLine, 1.0, 200, 100, null, false),
					ModAnimation.AaWidth(this.LabTitle, this.LabTitle.ActualWidth, 200, 100, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaOpacity(this.LabTitle, 1.0, 150, 150, null, false),
					ModAnimation.AaOpacity(this.PanCaption, 1.0, 150, 150, null, false),
					ModAnimation.AaOpacity(this.Btn1, 1.0, 150, 100, null, false),
					ModAnimation.AaOpacity(this.Btn2, 1.0, 150, 150, null, false),
					ModAnimation.AaOpacity(this.Btn3, 1.0, 150, 200, null, false),
					ModAnimation.AaCode(delegate
					{
						this.ShapeLine.MinWidth = this.ShapeLine.ActualWidth;
						this.ShapeLine.HorizontalAlignment = HorizontalAlignment.Stretch;
						this.ShapeLine.Width = double.NaN;
						this.LabTitle.Width = double.NaN;
						this.LabTitle.TextTrimming = TextTrimming.CharacterEllipsis;
					}, 350, false)
				}, "MyMsgBox Start " + Conversions.ToString(this._Status), false);
				this.ShapeLine.Width = 0.0;
				this.ShapeLine.HorizontalAlignment = HorizontalAlignment.Center;
				this.LabTitle.Width = 0.0;
				this.LabTitle.Opacity = 0.0;
				this.LabTitle.TextWrapping = TextWrapping.NoWrap;
				this.PanCaption.Opacity = 0.0;
				ModBase.Log("[Control] 输入弹窗：" + this.LabTitle.Text, ModBase.LogLevel.Normal, "出现错误");
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "输入弹窗加载失败", ModBase.LogLevel.Hint, "出现错误");
			}
		}

		// Token: 0x0600023E RID: 574 RVA: 0x0001691C File Offset: 0x00014B1C
		private void Close()
		{
			this.m_Message.m_ThreadParameter.Continue = false;
			ComponentDispatcher.PopModal();
			this.LabTitle.TextTrimming = TextTrimming.None;
			this.LabTitle.TextWrapping = TextWrapping.NoWrap;
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaColor(ModMain.m_CollectionAccount.PanMsg, Panel.BackgroundProperty, new ModBase.MyColor(-60.0, 0.0, 0.0, 0.0), 350, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaColor(this.PanBorder, Border.BackgroundProperty, new ModBase.MyColor(-255.0, 0.0, 0.0, 0.0), 300, 100, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaOpacity(this.EffectShadow, -0.75, 150, 0, null, false),
				ModAnimation.AaWidth(this.ShapeLine, -this.ShapeLine.ActualWidth, 250, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaOpacity(this.ShapeLine, -1.0, 150, 100, null, false),
				ModAnimation.AaWidth(this.LabTitle, -this.LabTitle.ActualWidth, 250, 0, null, false),
				ModAnimation.AaOpacity(this.LabTitle, -1.0, 200, 0, null, false),
				ModAnimation.AaOpacity(this.PanCaption, -1.0, 200, 0, null, false),
				ModAnimation.AaOpacity(this.Btn1, -1.0, 150, 0, null, false),
				ModAnimation.AaOpacity(this.Btn2, -1.0, 150, 50, null, false),
				ModAnimation.AaOpacity(this.Btn3, -1.0, 150, 100, null, false),
				ModAnimation.AaCode(delegate
				{
					((Grid)base.Parent).Children.Remove(this);
				}, 0, true)
			}, "MyMsgBox Close " + Conversions.ToString(this._Status), false);
		}

		// Token: 0x0600023F RID: 575 RVA: 0x00016B80 File Offset: 0x00014D80
		public void Btn1_Click()
		{
			if (!this.m_Message.connectionParameter && Operators.CompareString(this.TextCaption.ValidateResult, "", true) == 0)
			{
				this.m_Message.connectionParameter = true;
				this.m_Message._CustomerParameter = this.TextCaption.Text;
				this.Close();
			}
		}

		// Token: 0x06000240 RID: 576 RVA: 0x000034EC File Offset: 0x000016EC
		private void Btn2_Click()
		{
			if (!this.m_Message.connectionParameter)
			{
				this.m_Message.connectionParameter = true;
				this.m_Message._CustomerParameter = null;
				this.Close();
			}
		}

		// Token: 0x06000241 RID: 577 RVA: 0x000034EC File Offset: 0x000016EC
		private void Btn3_Click()
		{
			if (!this.m_Message.connectionParameter)
			{
				this.m_Message.connectionParameter = true;
				this.m_Message._CustomerParameter = null;
				this.Close();
			}
		}

		// Token: 0x06000242 RID: 578 RVA: 0x00003519 File Offset: 0x00001719
		private void TextCaption_ValidateChanged(object sender, EventArgs e)
		{
			this.Btn1.IsEnabled = (Operators.CompareString(this.TextCaption.ValidateResult, "", true) == 0);
		}

		// Token: 0x06000243 RID: 579 RVA: 0x00016BDC File Offset: 0x00014DDC
		private void Drag(object sender, MouseButtonEventArgs e)
		{
			int num;
			int num4;
			object obj;
			try
			{
				IL_00:
				ProjectData.ClearProjectError();
				num = 1;
				IL_07:
				int num2 = 2;
				if (e.GetPosition(this.ShapeLine).Y > 2.0)
				{
					goto IL_34;
				}
				IL_28:
				num2 = 3;
				ModMain.m_CollectionAccount.DragMove();
				IL_34:
				goto IL_93;
				IL_36:
				int num3 = num4 + 1;
				num4 = 0;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
				IL_54:
				goto IL_88;
				IL_56:
				num4 = num2;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
				IL_66:;
			}
			catch when (endfilter(obj is Exception & num != 0 & num4 == 0))
			{
				Exception ex = (Exception)obj2;
				goto IL_56;
			}
			IL_88:
			throw ProjectData.CreateProjectError(-2146828237);
			IL_93:
			if (num4 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x06000244 RID: 580 RVA: 0x0000353F File Offset: 0x0000173F
		// (set) Token: 0x06000245 RID: 581 RVA: 0x00016C94 File Offset: 0x00014E94
		internal virtual Border PanBorder
		{
			[CompilerGenerated]
			get
			{
				return this._Proc;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = new MouseButtonEventHandler(this.Drag);
				Border proc = this._Proc;
				if (proc != null)
				{
					proc.MouseLeftButtonDown -= value2;
				}
				this._Proc = value;
				proc = this._Proc;
				if (proc != null)
				{
					proc.MouseLeftButtonDown += value2;
				}
			}
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x06000246 RID: 582 RVA: 0x00003547 File Offset: 0x00001747
		// (set) Token: 0x06000247 RID: 583 RVA: 0x0000354F File Offset: 0x0000174F
		internal virtual DropShadowEffect EffectShadow { get; set; }

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x06000248 RID: 584 RVA: 0x00003558 File Offset: 0x00001758
		// (set) Token: 0x06000249 RID: 585 RVA: 0x00003560 File Offset: 0x00001760
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x0600024A RID: 586 RVA: 0x00003569 File Offset: 0x00001769
		// (set) Token: 0x0600024B RID: 587 RVA: 0x00016CD8 File Offset: 0x00014ED8
		internal virtual TextBlock LabTitle
		{
			[CompilerGenerated]
			get
			{
				return this.repositoryWrapper;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = new MouseButtonEventHandler(this.Drag);
				TextBlock textBlock = this.repositoryWrapper;
				if (textBlock != null)
				{
					textBlock.MouseLeftButtonDown -= value2;
				}
				this.repositoryWrapper = value;
				textBlock = this.repositoryWrapper;
				if (textBlock != null)
				{
					textBlock.MouseLeftButtonDown += value2;
				}
			}
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x0600024C RID: 588 RVA: 0x00003571 File Offset: 0x00001771
		// (set) Token: 0x0600024D RID: 589 RVA: 0x00003579 File Offset: 0x00001779
		internal virtual Rectangle ShapeLine { get; set; }

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x0600024E RID: 590 RVA: 0x00003582 File Offset: 0x00001782
		// (set) Token: 0x0600024F RID: 591 RVA: 0x0000358A File Offset: 0x0000178A
		internal virtual Border PanCaption { get; set; }

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x06000250 RID: 592 RVA: 0x00003593 File Offset: 0x00001793
		// (set) Token: 0x06000251 RID: 593 RVA: 0x00016D1C File Offset: 0x00014F1C
		internal virtual MyTextBox TextCaption
		{
			[CompilerGenerated]
			get
			{
				return this.m_ComparatorWrapper;
			}
			[CompilerGenerated]
			set
			{
				MyTextBox.ValidateChangedEventHandler obj = new MyTextBox.ValidateChangedEventHandler(this.TextCaption_ValidateChanged);
				if (this.m_ComparatorWrapper != null)
				{
					MyTextBox.RevertWrapper(obj);
				}
				this.m_ComparatorWrapper = value;
				if (this.m_ComparatorWrapper != null)
				{
					MyTextBox.PostWrapper(obj);
				}
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x06000252 RID: 594 RVA: 0x0000359B File Offset: 0x0000179B
		// (set) Token: 0x06000253 RID: 595 RVA: 0x000035A3 File Offset: 0x000017A3
		internal virtual StackPanel PanBtn { get; set; }

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06000254 RID: 596 RVA: 0x000035AC File Offset: 0x000017AC
		// (set) Token: 0x06000255 RID: 597 RVA: 0x00016D5C File Offset: 0x00014F5C
		internal virtual MyButton Btn1
		{
			[CompilerGenerated]
			get
			{
				return this.issuerWrapper;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.Btn1_Click();
				};
				MyButton myButton = this.issuerWrapper;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.issuerWrapper = value;
				myButton = this.issuerWrapper;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x06000256 RID: 598 RVA: 0x000035B4 File Offset: 0x000017B4
		// (set) Token: 0x06000257 RID: 599 RVA: 0x00016DA0 File Offset: 0x00014FA0
		internal virtual MyButton Btn2
		{
			[CompilerGenerated]
			get
			{
				return this.m_RequestWrapper;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.Btn2_Click();
				};
				MyButton requestWrapper = this.m_RequestWrapper;
				if (requestWrapper != null)
				{
					requestWrapper.RevertResolver(obj);
				}
				this.m_RequestWrapper = value;
				requestWrapper = this.m_RequestWrapper;
				if (requestWrapper != null)
				{
					requestWrapper.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x06000258 RID: 600 RVA: 0x000035BC File Offset: 0x000017BC
		// (set) Token: 0x06000259 RID: 601 RVA: 0x00016DE4 File Offset: 0x00014FE4
		internal virtual MyButton Btn3
		{
			[CompilerGenerated]
			get
			{
				return this._AccountWrapper;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.Btn3_Click();
				};
				MyButton accountWrapper = this._AccountWrapper;
				if (accountWrapper != null)
				{
					accountWrapper.RevertResolver(obj);
				}
				this._AccountWrapper = value;
				accountWrapper = this._AccountWrapper;
				if (accountWrapper != null)
				{
					accountWrapper.PostResolver(obj);
				}
			}
		}

		// Token: 0x0600025A RID: 602 RVA: 0x00016E28 File Offset: 0x00015028
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_StateWrapper)
			{
				this.m_StateWrapper = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/controls/mymsg/mymsginput.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x0600025B RID: 603 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600025C RID: 604 RVA: 0x00016E58 File Offset: 0x00015058
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBorder = (Border)target;
				return;
			}
			if (connectionId == 2)
			{
				this.EffectShadow = (DropShadowEffect)target;
				return;
			}
			if (connectionId == 3)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			if (connectionId == 4)
			{
				this.LabTitle = (TextBlock)target;
				return;
			}
			if (connectionId == 5)
			{
				this.ShapeLine = (Rectangle)target;
				return;
			}
			if (connectionId == 6)
			{
				this.PanCaption = (Border)target;
				return;
			}
			if (connectionId == 7)
			{
				this.TextCaption = (MyTextBox)target;
				return;
			}
			if (connectionId == 8)
			{
				this.PanBtn = (StackPanel)target;
				return;
			}
			if (connectionId == 9)
			{
				this.Btn1 = (MyButton)target;
				return;
			}
			if (connectionId == 10)
			{
				this.Btn2 = (MyButton)target;
				return;
			}
			if (connectionId == 11)
			{
				this.Btn3 = (MyButton)target;
				return;
			}
			this.m_StateWrapper = true;
		}

		// Token: 0x040000FF RID: 255
		private readonly ModMain.MyMsgBoxConverter m_Message;

		// Token: 0x04000100 RID: 256
		private readonly int _Status;

		// Token: 0x04000101 RID: 257
		[AccessedThroughProperty("PanBorder")]
		[CompilerGenerated]
		private Border _Proc;

		// Token: 0x04000102 RID: 258
		[CompilerGenerated]
		[AccessedThroughProperty("EffectShadow")]
		private DropShadowEffect _ModelWrapper;

		// Token: 0x04000103 RID: 259
		[AccessedThroughProperty("PanMain")]
		[CompilerGenerated]
		private StackPanel m_WrapperWrapper;

		// Token: 0x04000104 RID: 260
		[AccessedThroughProperty("LabTitle")]
		[CompilerGenerated]
		private TextBlock repositoryWrapper;

		// Token: 0x04000105 RID: 261
		[AccessedThroughProperty("ShapeLine")]
		[CompilerGenerated]
		private Rectangle resolverWrapper;

		// Token: 0x04000106 RID: 262
		[CompilerGenerated]
		[AccessedThroughProperty("PanCaption")]
		private Border _TagWrapper;

		// Token: 0x04000107 RID: 263
		[AccessedThroughProperty("TextCaption")]
		[CompilerGenerated]
		private MyTextBox m_ComparatorWrapper;

		// Token: 0x04000108 RID: 264
		[AccessedThroughProperty("PanBtn")]
		[CompilerGenerated]
		private StackPanel m_PrototypeWrapper;

		// Token: 0x04000109 RID: 265
		[AccessedThroughProperty("Btn1")]
		[CompilerGenerated]
		private MyButton issuerWrapper;

		// Token: 0x0400010A RID: 266
		[AccessedThroughProperty("Btn2")]
		[CompilerGenerated]
		private MyButton m_RequestWrapper;

		// Token: 0x0400010B RID: 267
		[AccessedThroughProperty("Btn3")]
		[CompilerGenerated]
		private MyButton _AccountWrapper;

		// Token: 0x0400010C RID: 268
		private bool m_StateWrapper;
	}
}
