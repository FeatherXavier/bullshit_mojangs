﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200001E RID: 30
	[StandardModule]
	public sealed class ModAnimation
	{
		// Token: 0x060000BE RID: 190 RVA: 0x0000DD50 File Offset: 0x0000BF50
		public static void AniDispose(MyCard Control, bool RemoveFromChildren, ParameterizedThreadStart CallBack = null)
		{
			if (Control.IsHitTestVisible)
			{
				Control.IsHitTestVisible = false;
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaScaleTransform(Control, -0.08, 200, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaOpacity(Control, -1.0, 200, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaHeight(Control, -Control.ActualHeight, 150, 100, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaCode(delegate
					{
						if (RemoveFromChildren)
						{
							object[] array;
							bool[] array2;
							NewLateBinding.LateCall(NewLateBinding.LateGet(Control.Parent, null, "Children", new object[0], null, null, null), null, "Remove", array = new object[]
							{
								Control
							}, null, null, array2 = new bool[]
							{
								true
							}, true);
							if (array2[0])
							{
								Control = (MyCard)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array[0]), typeof(MyCard));
							}
						}
						else
						{
							Control.Visibility = Visibility.Collapsed;
						}
						if (CallBack != null)
						{
							CallBack(Control);
						}
					}, 0, true)
				}, "MyCard Dispose " + Conversions.ToString(Control._System), false);
			}
		}

		// Token: 0x060000BF RID: 191 RVA: 0x0000DE50 File Offset: 0x0000C050
		public static void AniDispose(MyHint Control, bool RemoveFromChildren, ParameterizedThreadStart CallBack = null)
		{
			if (Control.IsHitTestVisible)
			{
				Control.IsHitTestVisible = false;
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaScaleTransform(Control, -0.08, 200, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaOpacity(Control, -1.0, 200, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaHeight(Control, -Control.ActualHeight, 150, 100, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaCode(delegate
					{
						if (RemoveFromChildren)
						{
							object[] array;
							bool[] array2;
							NewLateBinding.LateCall(NewLateBinding.LateGet(Control.Parent, null, "Children", new object[0], null, null, null), null, "Remove", array = new object[]
							{
								Control
							}, null, null, array2 = new bool[]
							{
								true
							}, true);
							if (array2[0])
							{
								Control = (MyHint)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array[0]), typeof(MyHint));
							}
						}
						else
						{
							Control.Visibility = Visibility.Collapsed;
						}
						if (CallBack != null)
						{
							CallBack(Control);
						}
					}, 0, true)
				}, "MyCard Dispose " + Conversions.ToString(Control.observer), false);
			}
		}

		// Token: 0x060000C0 RID: 192 RVA: 0x0000DF50 File Offset: 0x0000C150
		public static void AniDispose(MyIconButton Control, bool RemoveFromChildren, ParameterizedThreadStart CallBack = null)
		{
			if (Control.IsHitTestVisible)
			{
				Control.IsHitTestVisible = false;
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaScaleTransform(Control, -1.5, 200, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaCode(delegate
					{
						if (RemoveFromChildren)
						{
							object[] array;
							bool[] array2;
							NewLateBinding.LateCall(NewLateBinding.LateGet(Control.Parent, null, "Children", new object[0], null, null, null), null, "Remove", array = new object[]
							{
								Control
							}, null, null, array2 = new bool[]
							{
								true
							}, true);
							if (array2[0])
							{
								Control = (MyIconButton)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array[0]), typeof(MyIconButton));
							}
						}
						else
						{
							Control.Visibility = Visibility.Collapsed;
						}
						if (CallBack != null)
						{
							CallBack(Control);
						}
					}, 0, true)
				}, "MyIconButton Dispose " + Conversions.ToString(Control.attrRequest), false);
			}
		}

		// Token: 0x060000C1 RID: 193 RVA: 0x00002A54 File Offset: 0x00000C54
		public static int DefineModel()
		{
			return ModAnimation.m_Record;
		}

		// Token: 0x060000C2 RID: 194 RVA: 0x0000DFFC File Offset: 0x0000C1FC
		public static void CheckModel(int value)
		{
			object visitor = ModAnimation.m_Visitor;
			ObjectFlowControl.CheckForSyncLockOnValueType(visitor);
			lock (visitor)
			{
				ModAnimation.m_Record = value;
			}
		}

		// Token: 0x060000C3 RID: 195 RVA: 0x0000E044 File Offset: 0x0000C244
		public static ModAnimation.AniData AaX(object Obj, double Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Number,
				baseState = ModAnimation.AniTypeSub.X,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = RuntimeHelpers.GetObjectValue(Obj),
				Value = Value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000C4 RID: 196 RVA: 0x0000E0B4 File Offset: 0x0000C2B4
		public static ModAnimation.AniData AaY(object Obj, double Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Number,
				baseState = ModAnimation.AniTypeSub.Y,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = RuntimeHelpers.GetObjectValue(Obj),
				Value = Value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x0000E124 File Offset: 0x0000C324
		public static ModAnimation.AniData AaWidth(object Obj, double Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Number,
				baseState = ModAnimation.AniTypeSub.Width,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = RuntimeHelpers.GetObjectValue(Obj),
				Value = Value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000C6 RID: 198 RVA: 0x0000E194 File Offset: 0x0000C394
		public static ModAnimation.AniData AaHeight(object Obj, double Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Number,
				baseState = ModAnimation.AniTypeSub.Height,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = RuntimeHelpers.GetObjectValue(Obj),
				Value = Value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000C7 RID: 199 RVA: 0x0000E204 File Offset: 0x0000C404
		public static ModAnimation.AniData AaOpacity(object Obj, double Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Number,
				baseState = ModAnimation.AniTypeSub.Opacity,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = RuntimeHelpers.GetObjectValue(Obj),
				Value = Value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x0000E274 File Offset: 0x0000C474
		public static ModAnimation.AniData AaValue(object Obj, double Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Number,
				baseState = ModAnimation.AniTypeSub.Value,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = RuntimeHelpers.GetObjectValue(Obj),
				Value = Value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x0000E2E4 File Offset: 0x0000C4E4
		public static ModAnimation.AniData AaRadius(object Obj, double Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Number,
				baseState = ModAnimation.AniTypeSub.Radius,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = RuntimeHelpers.GetObjectValue(Obj),
				Value = Value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000CA RID: 202 RVA: 0x0000E354 File Offset: 0x0000C554
		public static ModAnimation.AniData AaBorderThickness(object Obj, double Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Number,
				baseState = ModAnimation.AniTypeSub.BorderThickness,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = RuntimeHelpers.GetObjectValue(Obj),
				Value = Value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000CB RID: 203 RVA: 0x0000E3C4 File Offset: 0x0000C5C4
		public static ModAnimation.AniData AaStrokeThickness(object Obj, double Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Number,
				baseState = ModAnimation.AniTypeSub.StrokeThickness,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = RuntimeHelpers.GetObjectValue(Obj),
				Value = Value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000CC RID: 204 RVA: 0x0000E434 File Offset: 0x0000C634
		public static ModAnimation.AniData AaGridLengthWidth(object Obj, double Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Number,
				baseState = ModAnimation.AniTypeSub.GridLengthWidth,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = RuntimeHelpers.GetObjectValue(Obj),
				Value = Value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000CD RID: 205 RVA: 0x0000E4A4 File Offset: 0x0000C6A4
		public static ModAnimation.AniData AaDouble(object Obj, DependencyProperty Prop, double Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Number,
				baseState = ModAnimation.AniTypeSub.Double,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = new object[]
				{
					Obj,
					Prop,
					""
				},
				Value = Value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000CE RID: 206 RVA: 0x0000E524 File Offset: 0x0000C724
		public static ModAnimation.AniData AaDouble(ParameterizedThreadStart Lambda, double Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Number,
				baseState = ModAnimation.AniTypeSub.DoubleParam,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = Lambda,
				Value = Value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000CF RID: 207 RVA: 0x0000E590 File Offset: 0x0000C790
		public static ModAnimation.AniData AaColor(FrameworkElement Obj, DependencyProperty Prop, ModBase.MyColor Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Color,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = new object[]
				{
					Obj,
					Prop,
					""
				},
				Value = Value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay),
				templateState = new ModBase.MyColor(0.0, 0.0, 0.0, 0.0)
			};
		}

		// Token: 0x060000D0 RID: 208 RVA: 0x0000E634 File Offset: 0x0000C834
		public static ModAnimation.AniData AaColor(FrameworkElement Obj, DependencyProperty Prop, string Res, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Color,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = new object[]
				{
					Obj,
					Prop,
					Res
				},
				Value = new ModBase.MyColor(RuntimeHelpers.GetObjectValue(Application.Current.FindResource(Res))) - new ModBase.MyColor(RuntimeHelpers.GetObjectValue(Obj.GetValue(Prop))),
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay),
				templateState = new ModBase.MyColor(0.0, 0.0, 0.0, 0.0)
			};
		}

		// Token: 0x060000D1 RID: 209 RVA: 0x0000E6FC File Offset: 0x0000C8FC
		public static ModAnimation.AniData AaScale(object Obj, double Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false, bool Absolute = false)
		{
			ModBase.MyRect value;
			if (Absolute)
			{
				value = new ModBase.MyRect(-0.5 * Value, -0.5 * Value, Value, Value);
			}
			else
			{
				value = new ModBase.MyRect(Conversions.ToDouble(Operators.MultiplyObject(Operators.MultiplyObject(-0.5, NewLateBinding.LateGet(Obj, null, "ActualWidth", new object[0], null, null, null)), Value)), Conversions.ToDouble(Operators.MultiplyObject(Operators.MultiplyObject(-0.5, NewLateBinding.LateGet(Obj, null, "ActualHeight", new object[0], null, null, null)), Value)), Conversions.ToDouble(Operators.MultiplyObject(NewLateBinding.LateGet(Obj, null, "ActualWidth", new object[0], null, null, null), Value)), Conversions.ToDouble(Operators.MultiplyObject(NewLateBinding.LateGet(Obj, null, "ActualHeight", new object[0], null, null, null), Value)));
			}
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Scale,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = RuntimeHelpers.GetObjectValue(Obj),
				Value = value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000D2 RID: 210 RVA: 0x0000E844 File Offset: 0x0000CA44
		public static ModAnimation.AniData AaTextAppear(object Obj, bool Hide = false, bool TimePerText = true, int Time = 70, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return checked(new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.TextAppear,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				productState = (TimePerText ? (Time * ((Obj is TextBlock) ? NewLateBinding.LateGet(Obj, null, "Text", new object[0], null, null, null) : NewLateBinding.LateGet(Obj, null, "Context", new object[0], null, null, null).ToString()).ToString().Length) : Time),
				indexerState = RuntimeHelpers.GetObjectValue(Obj),
				Value = new object[]
				{
					(Obj is TextBlock) ? NewLateBinding.LateGet(Obj, null, "Text", new object[0], null, null, null) : NewLateBinding.LateGet(Obj, null, "Context", new object[0], null, null, null).ToString(),
					Hide
				},
				m_BridgeState = After,
				m_AttrState = 0 - Delay
			});
		}

		// Token: 0x060000D3 RID: 211 RVA: 0x0000E93C File Offset: 0x0000CB3C
		public static ModAnimation.AniData AaCode(ThreadStart Code, int Delay = 0, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Code,
				productState = 1,
				Value = Code,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000D4 RID: 212 RVA: 0x0000E97C File Offset: 0x0000CB7C
		public static ModAnimation.AniData AaScaleTransform(object Obj, double Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.ScaleTransform,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = RuntimeHelpers.GetObjectValue(Obj),
				Value = Value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x0000E9E4 File Offset: 0x0000CBE4
		public static ModAnimation.AniData AaRotateTransform(object Obj, double Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.RotateTransform,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = RuntimeHelpers.GetObjectValue(Obj),
				Value = Value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000D6 RID: 214 RVA: 0x0000EA4C File Offset: 0x0000CC4C
		public static ModAnimation.AniData AaTranslateX(object Obj, double Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Number,
				baseState = ModAnimation.AniTypeSub.TranslateX,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = RuntimeHelpers.GetObjectValue(Obj),
				Value = Value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000D7 RID: 215 RVA: 0x0000EABC File Offset: 0x0000CCBC
		public static ModAnimation.AniData AaTranslateY(object Obj, double Value, int Time = 400, int Delay = 0, ModAnimation.AniEase Ease = null, bool After = false)
		{
			return new ModAnimation.AniData
			{
				paramState = ModAnimation.AniType.Number,
				baseState = ModAnimation.AniTypeSub.TranslateY,
				productState = Time,
				m_StructState = (Ease ?? new ModAnimation.AniEaseLinear()),
				indexerState = RuntimeHelpers.GetObjectValue(Obj),
				Value = Value,
				m_BridgeState = After,
				m_AttrState = checked(0 - Delay)
			};
		}

		// Token: 0x060000D8 RID: 216 RVA: 0x0000EB2C File Offset: 0x0000CD2C
		public static List<ModAnimation.AniData> AaStack(StackPanel Stack, int Time = 100, int Delay = 25)
		{
			List<ModAnimation.AniData> list = new List<ModAnimation.AniData>();
			int num = 0;
			checked
			{
				try
				{
					foreach (object obj in Stack.Children)
					{
						object objectValue = RuntimeHelpers.GetObjectValue(obj);
						NewLateBinding.LateSet(objectValue, null, "Opacity", new object[]
						{
							0
						}, null, null);
						list.Add(ModAnimation.AaOpacity(RuntimeHelpers.GetObjectValue(objectValue), 1.0, Time, num, null, false));
						num += Delay;
					}
				}
				finally
				{
					IEnumerator enumerator;
					if (enumerator is IDisposable)
					{
						(enumerator as IDisposable).Dispose();
					}
				}
				return list;
			}
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x0000EBCC File Offset: 0x0000CDCC
		public static void AniStart(IList AniGroup, string Name = "", bool RefreshTime = false)
		{
			if (RefreshTime)
			{
				ModAnimation.serializer = ModBase.GetTimeTick();
			}
			ModAnimation.AniGroupEntry aniGroupEntry = new ModAnimation.AniGroupEntry
			{
				m_RecordState = ModBase.GetFullList<ModAnimation.AniData>(AniGroup),
				_VisitorState = ModBase.GetTimeTick()
			};
			if (Operators.CompareString(Name, "", true) == 0)
			{
				Name = Conversions.ToString(aniGroupEntry.helperState);
			}
			else
			{
				ModAnimation.AniStop(Name);
			}
			ModAnimation.m_Task.Add(Name, aniGroupEntry);
		}

		// Token: 0x060000DA RID: 218 RVA: 0x00002A5B File Offset: 0x00000C5B
		public static void AniStart(ModAnimation.AniData AniGroup, string Name = "", bool RefreshTime = false)
		{
			ModAnimation.AniStart(new List<ModAnimation.AniData>
			{
				AniGroup
			}, Name, RefreshTime);
		}

		// Token: 0x060000DB RID: 219 RVA: 0x00002A70 File Offset: 0x00000C70
		public static void AniStop(string Name)
		{
			ModAnimation.m_Task.Remove(Name);
		}

		// Token: 0x060000DC RID: 220 RVA: 0x00002A7E File Offset: 0x00000C7E
		public static bool AniIsRun(string Name)
		{
			return ModAnimation.m_Task.ContainsKey(Name);
		}

		// Token: 0x060000DD RID: 221 RVA: 0x0000EC34 File Offset: 0x0000CE34
		public static void AniStartRun()
		{
			ModAnimation.serializer = ModBase.GetTimeTick();
			ModAnimation._Base = ModAnimation.serializer;
			ModAnimation._Role = true;
			ModBase.RunInNewThread((ModAnimation._Closure$__.$I60-0 == null) ? (ModAnimation._Closure$__.$I60-0 = checked(delegate()
			{
				try
				{
					ModBase.Log("[Animation] 动画线程开始", ModBase.LogLevel.Normal, "出现错误");
					for (;;)
					{
						ModAnimation._Closure$__60-0 CS$<>8__locals1 = new ModAnimation._Closure$__60-0(CS$<>8__locals1);
						CS$<>8__locals1.$VB$Local_DeltaTime = (long)Math.Round(ModBase.MathRange((double)(ModBase.GetTimeTick() - ModAnimation.serializer), 0.0, 10000.0));
						if (CS$<>8__locals1.$VB$Local_DeltaTime >= 3L)
						{
							ModAnimation.serializer = ModBase.GetTimeTick();
							if (ModBase._EventState)
							{
								if (ModBase.MathRange((double)(ModAnimation.serializer - ModAnimation._Base), 0.0, 10000.0) >= 500.0)
								{
									ModAnimation.product = ModAnimation.m_Param;
									ModAnimation.m_Param = 0;
									ModAnimation._Base = ModAnimation.serializer;
								}
								ModAnimation.m_Param += 2;
							}
							ModBase.RunInUiWait(delegate
							{
								ModAnimation._Helper = 0;
								ModAnimation.AniTimer((int)Math.Round(unchecked((double)CS$<>8__locals1.$VB$Local_DeltaTime * ModAnimation.m_Test)));
								if (ModBase.RandomInteger(0, 64 * (ModBase._EventState ? 5 : 30)) == 0 && ((ModAnimation.product < 62 && ModAnimation.product > 0) || ModAnimation._Helper > 4 || ModNet.reponseTag._InfoProccesor != 0))
								{
									ModBase.Log(string.Concat(new string[]
									{
										"[Report] FPS ",
										Conversions.ToString(ModAnimation.product),
										", 动画 ",
										Conversions.ToString(ModAnimation._Helper),
										", 下载中 ",
										Conversions.ToString(ModNet.reponseTag._InfoProccesor),
										"（",
										ModBase.GetString(ModNet.reponseTag._MapProccesor),
										"/s）"
									}), ModBase.LogLevel.Normal, "出现错误");
								}
							});
						}
						Thread.Sleep(1);
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "动画帧执行失败", ModBase.LogLevel.Assert, "出现错误");
				}
			})) : ModAnimation._Closure$__.$I60-0, "Animation", ThreadPriority.AboveNormal);
		}

		// Token: 0x060000DE RID: 222 RVA: 0x0000EC8C File Offset: 0x0000CE8C
		public static void AniTimer(int DeltaTick)
		{
			checked
			{
				try
				{
					if (DeltaTick > 200)
					{
						ModBase.Log("[Animation] 两个动画帧间隔 " + Conversions.ToString(DeltaTick) + " ms", ModBase.LogLevel.Developer, "出现错误");
					}
					int num = -1;
					IL_2A3:
					while (num + 1 < ModAnimation.m_Task.Count)
					{
						num++;
						ModAnimation.AniGroupEntry aniGroupEntry = ModAnimation.m_Task.Values.ElementAtOrDefault(num);
						if (aniGroupEntry._VisitorState <= ModAnimation.serializer)
						{
							bool flag = true;
							int i = 0;
							while (i < aniGroupEntry.m_RecordState.Count)
							{
								ModAnimation.AniData aniData = aniGroupEntry.m_RecordState[i];
								if (!aniData.m_BridgeState)
								{
									flag = false;
									ref int ptr = ref aniData.m_AttrState;
									aniData.m_AttrState = ptr + DeltaTick;
									if (aniData.m_AttrState > 0)
									{
										aniData = ModAnimation.AniRun(aniData);
										ModAnimation._Helper++;
									}
									if (aniData.m_AttrState >= aniData.productState)
									{
										if (Conversions.ToBoolean(aniData.paramState == ModAnimation.AniType.Color && Conversions.ToBoolean(Operators.NotObject(Operators.CompareObjectEqual(NewLateBinding.LateIndexGet(aniData.indexerState, new object[]
										{
											2
										}, null), "", true)))))
										{
											object instance = NewLateBinding.LateIndexGet(aniData.indexerState, new object[]
											{
												0
											}, null);
											Type type = null;
											string memberName = "SetResourceReference";
											object[] array = new object[2];
											int num2 = 0;
											object indexerState = aniData.indexerState;
											object instance2 = indexerState;
											object[] array2 = new object[1];
											object obj = array2[0] = 1;
											array[num2] = NewLateBinding.LateIndexGet(instance2, array2, null);
											int num3 = 1;
											object indexerState2 = aniData.indexerState;
											object instance3 = indexerState2;
											object[] array3 = new object[1];
											object obj2 = array3[0] = 2;
											array[num3] = NewLateBinding.LateIndexGet(instance3, array3, null);
											object[] array4 = array;
											bool[] array5;
											NewLateBinding.LateCall(instance, type, memberName, array, null, null, array5 = new bool[]
											{
												true,
												true
											}, true);
											if (array5[0])
											{
												NewLateBinding.LateIndexSetComplex(indexerState, new object[]
												{
													obj,
													array4[0]
												}, null, true, false);
											}
											if (array5[1])
											{
												NewLateBinding.LateIndexSetComplex(indexerState2, new object[]
												{
													obj2,
													array4[1]
												}, null, true, false);
											}
										}
										aniGroupEntry.m_RecordState.RemoveAt(i);
									}
									else
									{
										aniGroupEntry.m_RecordState[i] = aniData;
										i++;
									}
								}
								else
								{
									if (!flag)
									{
										break;
									}
									flag = false;
									aniData.m_BridgeState = false;
									aniGroupEntry.m_RecordState[i] = aniData;
								}
							}
							if (aniGroupEntry.m_RecordState.Count == 0)
							{
								int num4 = ModAnimation.m_Task.Count - 1;
								for (int j = 0; j <= num4; j++)
								{
									if (ModAnimation.m_Task.ElementAt(j).Value.helperState == aniGroupEntry.helperState)
									{
										ModAnimation.m_Task.Remove(ModAnimation.m_Task.ElementAt(j).Key);
										IL_29F:
										num--;
										goto IL_2A3;
									}
								}
								goto IL_29F;
							}
						}
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "动画刻执行失败", ModBase.LogLevel.Hint, "出现错误");
				}
			}
		}

		// Token: 0x060000DF RID: 223 RVA: 0x0000EF90 File Offset: 0x0000D190
		private static ModAnimation.AniData AniRun(ModAnimation.AniData Ani)
		{
			try
			{
				switch (Ani.paramState)
				{
				case ModAnimation.AniType.Number:
				{
					double num = ModBase.MathPercent(0.0, Conversions.ToDouble(Ani.Value), Ani.m_StructState.GetDelta((double)Ani.m_AttrState / (double)Ani.productState, Ani._FacadeState));
					if (num != 0.0)
					{
						switch (Ani.baseState)
						{
						case ModAnimation.AniTypeSub.X:
							ModBase.DeltaLeft((FrameworkElement)Ani.indexerState, num);
							break;
						case ModAnimation.AniTypeSub.Y:
							ModBase.DeltaTop((FrameworkElement)Ani.indexerState, num);
							break;
						case ModAnimation.AniTypeSub.Width:
						{
							FrameworkElement frameworkElement = (FrameworkElement)Ani.indexerState;
							frameworkElement.Width = Math.Max((double.IsNaN(frameworkElement.Width) ? frameworkElement.ActualWidth : frameworkElement.Width) + num, 0.0);
							break;
						}
						case ModAnimation.AniTypeSub.Height:
						{
							FrameworkElement frameworkElement2 = (FrameworkElement)Ani.indexerState;
							frameworkElement2.Height = Math.Max((double.IsNaN(frameworkElement2.Height) ? frameworkElement2.ActualHeight : frameworkElement2.Height) + num, 0.0);
							break;
						}
						case ModAnimation.AniTypeSub.Opacity:
							NewLateBinding.LateSet(Ani.indexerState, null, "Opacity", new object[]
							{
								ModBase.MathRange(Conversions.ToDouble(Operators.AddObject(NewLateBinding.LateGet(Ani.indexerState, null, "Opacity", new object[0], null, null, null), num)), 0.0, 1.0)
							}, null, null);
							break;
						case ModAnimation.AniTypeSub.Value:
						{
							object indexerState = Ani.indexerState;
							NewLateBinding.LateSet(indexerState, null, "Value", new object[]
							{
								Operators.AddObject(NewLateBinding.LateGet(indexerState, null, "Value", new object[0], null, null, null), num)
							}, null, null);
							break;
						}
						case ModAnimation.AniTypeSub.Radius:
						{
							object indexerState = Ani.indexerState;
							NewLateBinding.LateSet(indexerState, null, "Radius", new object[]
							{
								Operators.AddObject(NewLateBinding.LateGet(indexerState, null, "Radius", new object[0], null, null, null), num)
							}, null, null);
							break;
						}
						case ModAnimation.AniTypeSub.BorderThickness:
						{
							object indexerState2 = Ani.indexerState;
							Type type = null;
							string memberName = "BorderThickness";
							object[] array = new object[1];
							int num2 = 0;
							object obj = NewLateBinding.LateGet(Ani.indexerState, null, "BorderThickness", new object[0], null, null, null);
							array[num2] = new Thickness(((obj != null) ? ((Thickness)obj) : default(Thickness)).Bottom + num);
							NewLateBinding.LateSet(indexerState2, type, memberName, array, null, null);
							break;
						}
						case ModAnimation.AniTypeSub.StrokeThickness:
							NewLateBinding.LateSet(Ani.indexerState, null, "StrokeThickness", new object[]
							{
								NewLateBinding.LateGet(null, typeof(Math), "Max", new object[]
								{
									Operators.AddObject(NewLateBinding.LateGet(Ani.indexerState, null, "StrokeThickness", new object[0], null, null, null), num),
									0
								}, null, null, null)
							}, null, null);
							break;
						case ModAnimation.AniTypeSub.TranslateX:
						{
							if (Information.IsNothing(RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(Ani.indexerState, null, "RenderTransform", new object[0], null, null, null))) || !(NewLateBinding.LateGet(Ani.indexerState, null, "RenderTransform", new object[0], null, null, null) is TranslateTransform))
							{
								NewLateBinding.LateSet(Ani.indexerState, null, "RenderTransform", new object[]
								{
									new TranslateTransform(0.0, 0.0)
								}, null, null);
							}
							TranslateTransform translateTransform;
							(translateTransform = (TranslateTransform)NewLateBinding.LateGet(Ani.indexerState, null, "RenderTransform", new object[0], null, null, null)).X = translateTransform.X + num;
							break;
						}
						case ModAnimation.AniTypeSub.TranslateY:
						{
							if (Information.IsNothing(RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(Ani.indexerState, null, "RenderTransform", new object[0], null, null, null))) || !(NewLateBinding.LateGet(Ani.indexerState, null, "RenderTransform", new object[0], null, null, null) is TranslateTransform))
							{
								NewLateBinding.LateSet(Ani.indexerState, null, "RenderTransform", new object[]
								{
									new TranslateTransform(0.0, 0.0)
								}, null, null);
							}
							TranslateTransform translateTransform;
							(translateTransform = (TranslateTransform)NewLateBinding.LateGet(Ani.indexerState, null, "RenderTransform", new object[0], null, null, null)).Y = translateTransform.Y + num;
							break;
						}
						case ModAnimation.AniTypeSub.Double:
						{
							object instance = NewLateBinding.LateIndexGet(Ani.indexerState, new object[]
							{
								0
							}, null);
							Type type2 = null;
							string memberName2 = "SetValue";
							object[] array2 = new object[2];
							int num3 = 0;
							object indexerState = Ani.indexerState;
							object instance2 = indexerState;
							object[] array3 = new object[1];
							object obj2 = array3[0] = 1;
							array2[num3] = NewLateBinding.LateIndexGet(instance2, array3, null);
							int num4 = 1;
							object instance3 = NewLateBinding.LateIndexGet(Ani.indexerState, new object[]
							{
								0
							}, null);
							Type type3 = null;
							string memberName3 = "GetValue";
							object[] array4 = new object[1];
							int num5 = 0;
							object indexerState3 = Ani.indexerState;
							object instance4 = indexerState3;
							object[] array5 = new object[1];
							object obj3 = array5[0] = 1;
							array4[num5] = NewLateBinding.LateIndexGet(instance4, array5, null);
							object[] array6 = array4;
							bool[] array7;
							object left = NewLateBinding.LateGet(instance3, type3, memberName3, array4, null, null, array7 = new bool[]
							{
								true
							});
							if (array7[0])
							{
								NewLateBinding.LateIndexSetComplex(indexerState3, new object[]
								{
									obj3,
									array6[0]
								}, null, true, false);
							}
							array2[num4] = Operators.AddObject(left, num);
							object[] array8 = array2;
							string[] argumentNames = null;
							Type[] typeArguments = null;
							bool[] array9 = new bool[2];
							array9[0] = true;
							bool[] array10 = array9;
							NewLateBinding.LateCall(instance, type2, memberName2, array2, argumentNames, typeArguments, array9, true);
							if (array10[0])
							{
								NewLateBinding.LateIndexSetComplex(indexerState, new object[]
								{
									obj2,
									array8[0]
								}, null, true, false);
							}
							break;
						}
						case ModAnimation.AniTypeSub.DoubleParam:
							((ParameterizedThreadStart)Ani.indexerState)(num);
							break;
						case ModAnimation.AniTypeSub.GridLengthWidth:
							NewLateBinding.LateSet(Ani.indexerState, null, "Width", new object[]
							{
								new GridLength(Conversions.ToDouble(NewLateBinding.LateGet(null, typeof(Math), "Max", new object[]
								{
									Operators.AddObject(NewLateBinding.LateGet(NewLateBinding.LateGet(Ani.indexerState, null, "Width", new object[0], null, null, null), null, "Value", new object[0], null, null, null), num),
									0
								}, null, null, null)), GridUnitType.Star)
							}, null, null);
							break;
						}
					}
					break;
				}
				case ModAnimation.AniType.Color:
				{
					ModBase.MyColor b = ModBase.MathPercent(new ModBase.MyColor(0.0, 0.0, 0.0, 0.0), (ModBase.MyColor)Ani.Value, Ani.m_StructState.GetDelta((double)Ani.m_AttrState / (double)Ani.productState, Ani._FacadeState)) + (ModBase.MyColor)Ani.templateState;
					FrameworkElement frameworkElement3 = (FrameworkElement)NewLateBinding.LateIndexGet(Ani.indexerState, new object[]
					{
						0
					}, null);
					DependencyProperty dependencyProperty = (DependencyProperty)NewLateBinding.LateIndexGet(Ani.indexerState, new object[]
					{
						1
					}, null);
					ModBase.MyColor myColor = new ModBase.MyColor(RuntimeHelpers.GetObjectValue(frameworkElement3.GetValue(dependencyProperty))) + b;
					frameworkElement3.SetValue(dependencyProperty, RuntimeHelpers.GetObjectValue((Operators.CompareString(dependencyProperty.PropertyType.Name, "Color", true) == 0) ? myColor : myColor));
					Ani.templateState = myColor - new ModBase.MyColor(RuntimeHelpers.GetObjectValue(frameworkElement3.GetValue(dependencyProperty)));
					break;
				}
				case ModAnimation.AniType.Scale:
				{
					FrameworkElement frameworkElement4 = (FrameworkElement)Ani.indexerState;
					double delta = Ani.m_StructState.GetDelta((double)Ani.m_AttrState / (double)Ani.productState, Ani._FacadeState);
					frameworkElement4.Margin = new Thickness(frameworkElement4.Margin.Left + ModBase.MathPercent(0.0, Conversions.ToDouble(NewLateBinding.LateGet(Ani.Value, null, "Left", new object[0], null, null, null)), delta), frameworkElement4.Margin.Top + ModBase.MathPercent(0.0, Conversions.ToDouble(NewLateBinding.LateGet(Ani.Value, null, "Top", new object[0], null, null, null)), delta), frameworkElement4.Margin.Right + ModBase.MathPercent(0.0, Conversions.ToDouble(NewLateBinding.LateGet(Ani.Value, null, "Left", new object[0], null, null, null)), delta), frameworkElement4.Margin.Bottom + ModBase.MathPercent(0.0, Conversions.ToDouble(NewLateBinding.LateGet(Ani.Value, null, "Top", new object[0], null, null, null)), delta));
					frameworkElement4.Width = Math.Max(frameworkElement4.Width + ModBase.MathPercent(0.0, Conversions.ToDouble(NewLateBinding.LateGet(Ani.Value, null, "Width", new object[0], null, null, null)), delta), 0.0);
					frameworkElement4.Height = Math.Max(frameworkElement4.Height + ModBase.MathPercent(0.0, Conversions.ToDouble(NewLateBinding.LateGet(Ani.Value, null, "Height", new object[0], null, null, null)), delta), 0.0);
					break;
				}
				case ModAnimation.AniType.TextAppear:
					checked
					{
						int num6 = (int)Math.Round(unchecked((double)(Conversions.ToBoolean(NewLateBinding.LateIndexGet(Ani.Value, new object[]
						{
							1
						}, null)) ? NewLateBinding.LateIndexGet(Ani.Value, new object[]
						{
							0
						}, null).ToString().Length : 0) + Math.Round((double)(checked(NewLateBinding.LateIndexGet(Ani.Value, new object[]
						{
							0
						}, null).ToString().Length * (Conversions.ToBoolean(NewLateBinding.LateIndexGet(Ani.Value, new object[]
						{
							1
						}, null)) ? -1 : 1))) * Ani.m_StructState.GetDelta((double)Ani.m_AttrState / (double)Ani.productState, 0.0))));
						string text = Strings.Mid(Conversions.ToString(NewLateBinding.LateIndexGet(Ani.Value, new object[]
						{
							0
						}, null)), 1, num6);
						if (num6 < NewLateBinding.LateIndexGet(Ani.Value, new object[]
						{
							0
						}, null).ToString().Length)
						{
							if (Convert.ToInt32(Convert.ToChar(Strings.Mid(Conversions.ToString(NewLateBinding.LateIndexGet(Ani.Value, new object[]
							{
								0
							}, null)), num6 + 1, 1))) >= Convert.ToInt32(Convert.ToChar(128)))
							{
								text += Encoding.GetEncoding("GB18030").GetString(new byte[]
								{
									(byte)ModBase.RandomInteger(176, 247),
									(byte)ModBase.RandomInteger(161, 249)
								});
							}
							else
							{
								text = Conversions.ToString(Operators.ConcatenateObject(text, ModBase.RandomOne("0123456789./*-+\\[]{};':/?,!@#$%^&*()_+-=qwwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM".ToCharArray())));
							}
						}
						if (Ani.indexerState is TextBlock)
						{
							NewLateBinding.LateSet(Ani.indexerState, null, "Text", new object[]
							{
								text
							}, null, null);
						}
						else
						{
							NewLateBinding.LateSet(Ani.indexerState, null, "Context", new object[]
							{
								text
							}, null, null);
						}
						break;
					}
				case ModAnimation.AniType.Code:
					((ThreadStart)Ani.Value)();
					break;
				case ModAnimation.AniType.ScaleTransform:
				{
					FrameworkElement frameworkElement5 = (FrameworkElement)Ani.indexerState;
					if (!(frameworkElement5.RenderTransform is ScaleTransform))
					{
						frameworkElement5.RenderTransformOrigin = new Point(0.5, 0.5);
						frameworkElement5.RenderTransform = new ScaleTransform(1.0, 1.0);
					}
					double num7 = ModBase.MathPercent(0.0, Conversions.ToDouble(Ani.Value), Ani.m_StructState.GetDelta((double)Ani.m_AttrState / (double)Ani.productState, Ani._FacadeState));
					((ScaleTransform)frameworkElement5.RenderTransform).ScaleX = Math.Max(((ScaleTransform)frameworkElement5.RenderTransform).ScaleX + num7, 0.0);
					((ScaleTransform)frameworkElement5.RenderTransform).ScaleY = Math.Max(((ScaleTransform)frameworkElement5.RenderTransform).ScaleY + num7, 0.0);
					break;
				}
				case ModAnimation.AniType.RotateTransform:
				{
					FrameworkElement frameworkElement6 = (FrameworkElement)Ani.indexerState;
					if (!(frameworkElement6.RenderTransform is RotateTransform))
					{
						frameworkElement6.RenderTransformOrigin = new Point(0.5, 0.5);
						frameworkElement6.RenderTransform = new RotateTransform(0.0);
					}
					double num8 = ModBase.MathPercent(0.0, Conversions.ToDouble(Ani.Value), Ani.m_StructState.GetDelta((double)Ani.m_AttrState / (double)Ani.productState, Ani._FacadeState));
					((RotateTransform)frameworkElement6.RenderTransform).Angle = ((RotateTransform)frameworkElement6.RenderTransform).Angle + num8;
					break;
				}
				}
				Ani._FacadeState = (double)Ani.m_AttrState / (double)Ani.productState;
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "执行动画失败：" + Ani.ToString(), ModBase.LogLevel.Hint, "出现错误");
			}
			return Ani;
		}

		// Token: 0x0400003A RID: 58
		public static double m_Test = 1.0;

		// Token: 0x0400003B RID: 59
		public static Dictionary<string, ModAnimation.AniGroupEntry> m_Task = new Dictionary<string, ModAnimation.AniGroupEntry>();

		// Token: 0x0400003C RID: 60
		private static long serializer;

		// Token: 0x0400003D RID: 61
		public static bool _Role = false;

		// Token: 0x0400003E RID: 62
		private static int m_Record = 0;

		// Token: 0x0400003F RID: 63
		private static readonly object m_Visitor = RuntimeHelpers.GetObjectValue(new object());

		// Token: 0x04000040 RID: 64
		private static int _Helper = 0;

		// Token: 0x04000041 RID: 65
		private static int m_Param = 0;

		// Token: 0x04000042 RID: 66
		private static long _Base = 0L;

		// Token: 0x04000043 RID: 67
		public static int product = 0;

		// Token: 0x0200001F RID: 31
		public class AniGroupEntry
		{
			// Token: 0x060000E0 RID: 224 RVA: 0x00002A8B File Offset: 0x00000C8B
			public AniGroupEntry()
			{
				this.helperState = ModBase.GetUuid();
			}

			// Token: 0x04000044 RID: 68
			public List<ModAnimation.AniData> m_RecordState;

			// Token: 0x04000045 RID: 69
			public long _VisitorState;

			// Token: 0x04000046 RID: 70
			public int helperState;
		}

		// Token: 0x02000020 RID: 32
		public struct AniData
		{
			// Token: 0x060000E2 RID: 226 RVA: 0x0000FD5C File Offset: 0x0000DF5C
			public override string ToString()
			{
				return string.Concat(new string[]
				{
					ModBase.GetStringFromEnum(this.paramState),
					" | ",
					Conversions.ToString(this.m_AttrState),
					"/",
					Conversions.ToString(this.productState),
					"(",
					Conversions.ToString(Math.Round(this._FacadeState * 100.0)),
					"%)",
					(this.indexerState == null) ? "" : string.Concat(new string[]
					{
						" | ",
						this.indexerState.ToString(),
						"(",
						this.indexerState.GetType().Name,
						")"
					})
				});
			}

			// Token: 0x04000047 RID: 71
			public ModAnimation.AniType paramState;

			// Token: 0x04000048 RID: 72
			public ModAnimation.AniTypeSub baseState;

			// Token: 0x04000049 RID: 73
			public int productState;

			// Token: 0x0400004A RID: 74
			public int m_AttrState;

			// Token: 0x0400004B RID: 75
			public double _FacadeState;

			// Token: 0x0400004C RID: 76
			public bool m_BridgeState;

			// Token: 0x0400004D RID: 77
			public ModAnimation.AniEase m_StructState;

			// Token: 0x0400004E RID: 78
			public object[] indexerState;

			// Token: 0x0400004F RID: 79
			public object[] Value;

			// Token: 0x04000050 RID: 80
			public ModBase.MyColor templateState;
		}

		// Token: 0x02000021 RID: 33
		public enum AniType
		{
			// Token: 0x04000052 RID: 82
			Number,
			// Token: 0x04000053 RID: 83
			Color,
			// Token: 0x04000054 RID: 84
			Scale,
			// Token: 0x04000055 RID: 85
			TextAppear,
			// Token: 0x04000056 RID: 86
			Code,
			// Token: 0x04000057 RID: 87
			ScaleTransform,
			// Token: 0x04000058 RID: 88
			RotateTransform
		}

		// Token: 0x02000022 RID: 34
		public enum AniTypeSub
		{
			// Token: 0x0400005A RID: 90
			X,
			// Token: 0x0400005B RID: 91
			Y,
			// Token: 0x0400005C RID: 92
			Width,
			// Token: 0x0400005D RID: 93
			Height,
			// Token: 0x0400005E RID: 94
			Opacity,
			// Token: 0x0400005F RID: 95
			Value,
			// Token: 0x04000060 RID: 96
			Radius,
			// Token: 0x04000061 RID: 97
			BorderThickness,
			// Token: 0x04000062 RID: 98
			StrokeThickness,
			// Token: 0x04000063 RID: 99
			TranslateX,
			// Token: 0x04000064 RID: 100
			TranslateY,
			// Token: 0x04000065 RID: 101
			Double,
			// Token: 0x04000066 RID: 102
			DoubleParam,
			// Token: 0x04000067 RID: 103
			GridLengthWidth
		}

		// Token: 0x02000023 RID: 35
		public enum AniEasePower
		{
			// Token: 0x04000069 RID: 105
			Weak = 2,
			// Token: 0x0400006A RID: 106
			Middle,
			// Token: 0x0400006B RID: 107
			Strong,
			// Token: 0x0400006C RID: 108
			ExtraStrong
		}

		// Token: 0x02000024 RID: 36
		public abstract class AniEase
		{
			// Token: 0x060000E5 RID: 229
			public abstract double GetValue(double t);

			// Token: 0x060000E6 RID: 230 RVA: 0x00002A9F File Offset: 0x00000C9F
			public virtual double GetDelta(double t1, double t0)
			{
				return this.GetValue(t1) - this.GetValue(t0);
			}
		}

		// Token: 0x02000025 RID: 37
		public class AniEaseInout : ModAnimation.AniEase
		{
			// Token: 0x060000E8 RID: 232 RVA: 0x00002AB0 File Offset: 0x00000CB0
			public AniEaseInout(ModAnimation.AniEase EaseIn, ModAnimation.AniEase EaseOut, double EaseInPercent = 0.5)
			{
				this.m_ExpressionState = EaseIn;
				this.EaseOut = EaseOut;
				this._GetterState = EaseInPercent;
			}

			// Token: 0x060000E9 RID: 233 RVA: 0x0000FE38 File Offset: 0x0000E038
			public override double GetValue(double t)
			{
				double result;
				if (t < this._GetterState)
				{
					result = this._GetterState * this.m_ExpressionState.GetValue(t / this._GetterState);
				}
				else
				{
					result = (1.0 - this._GetterState) * this.EaseOut.GetValue((t - this._GetterState) / (1.0 - this._GetterState)) + this._GetterState;
				}
				return result;
			}

			// Token: 0x0400006D RID: 109
			private readonly ModAnimation.AniEase m_ExpressionState;

			// Token: 0x0400006E RID: 110
			private readonly ModAnimation.AniEase EaseOut;

			// Token: 0x0400006F RID: 111
			private readonly double _GetterState;
		}

		// Token: 0x02000026 RID: 38
		public class AniEaseLinear : ModAnimation.AniEase
		{
			// Token: 0x060000EC RID: 236 RVA: 0x00002AD7 File Offset: 0x00000CD7
			public override double GetValue(double t)
			{
				return ModBase.MathRange(t, 0.0, 1.0);
			}

			// Token: 0x060000ED RID: 237 RVA: 0x00002AF1 File Offset: 0x00000CF1
			public override double GetDelta(double t1, double t0)
			{
				return ModBase.MathRange(t1, 0.0, 1.0) - ModBase.MathRange(t0, 0.0, 1.0);
			}
		}

		// Token: 0x02000027 RID: 39
		public class AniEaseInFluent : ModAnimation.AniEase
		{
			// Token: 0x060000EF RID: 239 RVA: 0x00002B24 File Offset: 0x00000D24
			public AniEaseInFluent(ModAnimation.AniEasePower Power = ModAnimation.AniEasePower.Middle)
			{
				this.p = Power;
			}

			// Token: 0x060000F0 RID: 240 RVA: 0x00002B34 File Offset: 0x00000D34
			public override double GetValue(double t)
			{
				return Math.Pow(ModBase.MathRange(t, 0.0, 1.0), (double)this.p);
			}

			// Token: 0x04000070 RID: 112
			private readonly ModAnimation.AniEasePower p;
		}

		// Token: 0x02000028 RID: 40
		public class AniEaseOutFluent : ModAnimation.AniEase
		{
			// Token: 0x060000F2 RID: 242 RVA: 0x00002B5A File Offset: 0x00000D5A
			public AniEaseOutFluent(ModAnimation.AniEasePower Power = ModAnimation.AniEasePower.Middle)
			{
				this.p = Power;
			}

			// Token: 0x060000F3 RID: 243 RVA: 0x00002B6A File Offset: 0x00000D6A
			public override double GetValue(double t)
			{
				return 1.0 - Math.Pow(ModBase.MathRange(1.0 - t, 0.0, 1.0), (double)this.p);
			}

			// Token: 0x04000071 RID: 113
			private readonly ModAnimation.AniEasePower p;
		}

		// Token: 0x02000029 RID: 41
		public class AniEaseInoutFluent : ModAnimation.AniEase
		{
			// Token: 0x060000F5 RID: 245 RVA: 0x00002BA4 File Offset: 0x00000DA4
			public AniEaseInoutFluent(ModAnimation.AniEasePower Power = ModAnimation.AniEasePower.Middle, double Middle = 0.5)
			{
				this.m_ListenerState = new ModAnimation.AniEaseInout(new ModAnimation.AniEaseInFluent(Power), new ModAnimation.AniEaseOutFluent(Power), Middle);
			}

			// Token: 0x060000F6 RID: 246 RVA: 0x00002BC5 File Offset: 0x00000DC5
			public override double GetValue(double t)
			{
				return this.m_ListenerState.GetValue(t);
			}

			// Token: 0x04000072 RID: 114
			private ModAnimation.AniEaseInout m_ListenerState;
		}

		// Token: 0x0200002A RID: 42
		public class AniEaseInBack : ModAnimation.AniEase
		{
			// Token: 0x060000F8 RID: 248 RVA: 0x00002BD3 File Offset: 0x00000DD3
			public AniEaseInBack(ModAnimation.AniEasePower Power = ModAnimation.AniEasePower.Middle)
			{
				this.p = 3.0 - (double)Power * 0.5;
			}

			// Token: 0x060000F9 RID: 249 RVA: 0x0000FEAC File Offset: 0x0000E0AC
			public override double GetValue(double t)
			{
				t = ModBase.MathRange(t, 0.0, 1.0);
				return Math.Pow(t, this.p) * Math.Cos(4.71238898038469 * (1.0 - t));
			}

			// Token: 0x04000073 RID: 115
			private readonly double p;
		}

		// Token: 0x0200002B RID: 43
		public class AniEaseOutBack : ModAnimation.AniEase
		{
			// Token: 0x060000FB RID: 251 RVA: 0x00002BF8 File Offset: 0x00000DF8
			public AniEaseOutBack(ModAnimation.AniEasePower Power = ModAnimation.AniEasePower.Middle)
			{
				this.p = 3.0 - (double)Power * 0.5;
			}

			// Token: 0x060000FC RID: 252 RVA: 0x0000FEFC File Offset: 0x0000E0FC
			public override double GetValue(double t)
			{
				t = ModBase.MathRange(t, 0.0, 1.0);
				return 1.0 - Math.Pow(1.0 - t, this.p) * Math.Cos(4.71238898038469 * t);
			}

			// Token: 0x04000074 RID: 116
			private readonly double p;
		}

		// Token: 0x0200002C RID: 44
		public class AniEaseInCar : ModAnimation.AniEase
		{
			// Token: 0x060000FE RID: 254 RVA: 0x00002C1D File Offset: 0x00000E1D
			public AniEaseInCar(double Middle = 0.7, ModAnimation.AniEasePower Power = ModAnimation.AniEasePower.Middle)
			{
				this.identifierState = new ModAnimation.AniEaseInout(new ModAnimation.AniEaseInBack(Power), new ModAnimation.AniEaseOutFluent(Power), Middle);
			}

			// Token: 0x060000FF RID: 255 RVA: 0x00002C3E File Offset: 0x00000E3E
			public override double GetValue(double t)
			{
				return this.identifierState.GetValue(t);
			}

			// Token: 0x04000075 RID: 117
			private ModAnimation.AniEaseInout identifierState;
		}

		// Token: 0x0200002D RID: 45
		public class AniEaseOutCar : ModAnimation.AniEase
		{
			// Token: 0x06000101 RID: 257 RVA: 0x00002C4C File Offset: 0x00000E4C
			public AniEaseOutCar(double Middle = 0.3, ModAnimation.AniEasePower Power = ModAnimation.AniEasePower.Middle)
			{
				this._InstanceState = new ModAnimation.AniEaseInout(new ModAnimation.AniEaseInFluent(Power), new ModAnimation.AniEaseOutBack(Power), Middle);
			}

			// Token: 0x06000102 RID: 258 RVA: 0x00002C6D File Offset: 0x00000E6D
			public override double GetValue(double t)
			{
				return this._InstanceState.GetValue(t);
			}

			// Token: 0x04000076 RID: 118
			private ModAnimation.AniEaseInout _InstanceState;
		}

		// Token: 0x0200002E RID: 46
		public class AniEaseInElastic : ModAnimation.AniEase
		{
			// Token: 0x06000104 RID: 260 RVA: 0x00002C7B File Offset: 0x00000E7B
			public AniEaseInElastic(ModAnimation.AniEasePower Power = ModAnimation.AniEasePower.Middle)
			{
				this.p = (int)(checked(Power + 4));
			}

			// Token: 0x06000105 RID: 261 RVA: 0x0000FF54 File Offset: 0x0000E154
			public override double GetValue(double t)
			{
				t = ModBase.MathRange(t, 0.0, 1.0);
				return Math.Pow(t, (double)(checked(this.p - 1)) * 0.25) * Math.Cos(((double)this.p - 3.5) * 3.141592653589793 * Math.Pow(1.0 - t, 1.5));
			}

			// Token: 0x04000077 RID: 119
			private readonly int p;
		}

		// Token: 0x0200002F RID: 47
		public class AniEaseOutElastic : ModAnimation.AniEase
		{
			// Token: 0x06000107 RID: 263 RVA: 0x00002C8D File Offset: 0x00000E8D
			public AniEaseOutElastic(ModAnimation.AniEasePower Power = ModAnimation.AniEasePower.Middle)
			{
				this.p = (int)(checked(Power + 4));
			}

			// Token: 0x06000108 RID: 264 RVA: 0x0000FFD0 File Offset: 0x0000E1D0
			public override double GetValue(double t)
			{
				t = 1.0 - ModBase.MathRange(t, 0.0, 1.0);
				return 1.0 - Math.Pow(t, (double)(checked(this.p - 1)) * 0.25) * Math.Cos(((double)this.p - 3.5) * 3.141592653589793 * Math.Pow(1.0 - t, 1.5));
			}

			// Token: 0x04000078 RID: 120
			private readonly int p;
		}
	}
}
