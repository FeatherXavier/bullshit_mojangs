﻿using System;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;

namespace PCL
{
	// Token: 0x020000E4 RID: 228
	public class ValidateRegex : Validate
	{
		// Token: 0x060008F2 RID: 2290 RVA: 0x0000667E File Offset: 0x0000487E
		[CompilerGenerated]
		public string InterruptRepository()
		{
			return this._ContainerTag;
		}

		// Token: 0x060008F3 RID: 2291 RVA: 0x00006686 File Offset: 0x00004886
		[CompilerGenerated]
		public void ConcatRepository(string AutoPropertyValue)
		{
			this._ContainerTag = AutoPropertyValue;
		}

		// Token: 0x060008F4 RID: 2292 RVA: 0x0000668F File Offset: 0x0000488F
		[CompilerGenerated]
		public string PublishRepository()
		{
			return this.codeTag;
		}

		// Token: 0x060008F5 RID: 2293 RVA: 0x00006697 File Offset: 0x00004897
		[CompilerGenerated]
		public void UpdateRepository(string AutoPropertyValue)
		{
			this.codeTag = AutoPropertyValue;
		}

		// Token: 0x060008F6 RID: 2294 RVA: 0x000066A0 File Offset: 0x000048A0
		public ValidateRegex()
		{
			this.UpdateRepository("");
		}

		// Token: 0x060008F7 RID: 2295 RVA: 0x000066B4 File Offset: 0x000048B4
		public ValidateRegex(string Regex, string ErrorDescription = "")
		{
			this.UpdateRepository("");
			this.ConcatRepository(Regex);
			this.UpdateRepository(ErrorDescription);
		}

		// Token: 0x060008F8 RID: 2296 RVA: 0x0003F730 File Offset: 0x0003D930
		public override string Validate(string Str)
		{
			string result;
			if (!ModBase.RegexCheck(Str, this.InterruptRepository(), RegexOptions.None))
			{
				result = this.PublishRepository();
			}
			else
			{
				result = "";
			}
			return result;
		}

		// Token: 0x0400045B RID: 1115
		[CompilerGenerated]
		private string _ContainerTag;

		// Token: 0x0400045C RID: 1116
		[CompilerGenerated]
		private string codeTag;
	}
}
