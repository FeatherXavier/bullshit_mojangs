﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using PCL.My;

namespace PCL
{
	// Token: 0x02000127 RID: 295
	[DesignerGenerated]
	public class PageOtherTest : MyPageRight, IComponentConnector
	{
		// Token: 0x06000B05 RID: 2821 RVA: 0x000076F8 File Offset: 0x000058F8
		public PageOtherTest()
		{
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.MeLoaded();
			};
			this.listTag = false;
			this.methodTag = true;
			this.InitializeComponent();
		}

		// Token: 0x06000B06 RID: 2822 RVA: 0x000574AC File Offset: 0x000556AC
		private void MeLoaded()
		{
			if (!this.listTag)
			{
				this.listTag = true;
				this.TextDownloadFolder.Text = Conversions.ToString(ModBase._ParamsState.Get("CacheDownloadFolder", null));
				this.TextDownloadFolder.Validate();
				if (Operators.CompareString(this.TextDownloadFolder.ValidateResult, "", true) != 0 || Operators.CompareString(this.TextDownloadFolder.Text, "", true) == 0)
				{
					this.TextDownloadFolder.Text = ModBase.Path + "PCL\\MyDownload\\";
				}
				this.TextDownloadFolder.Validate();
			}
		}

		// Token: 0x06000B07 RID: 2823 RVA: 0x00007727 File Offset: 0x00005927
		private void SaveCacheDownloadFolder()
		{
			ModBase._ParamsState.Set("CacheDownloadFolder", this.TextDownloadFolder.Text, false, null);
		}

		// Token: 0x06000B08 RID: 2824 RVA: 0x0005754C File Offset: 0x0005574C
		private void StartButtonRefresh()
		{
			this.BtnDownloadStart.IsEnabled = (Operators.CompareString(this.TextDownloadFolder.ValidateResult, "", true) == 0 && Operators.CompareString(this.TextDownloadUrl.ValidateResult, "", true) == 0);
			this.BtnDownloadOpen.IsEnabled = (Operators.CompareString(this.TextDownloadFolder.ValidateResult, "", true) == 0);
		}

		// Token: 0x06000B09 RID: 2825 RVA: 0x00007745 File Offset: 0x00005945
		private void TextDownloadUrl_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Return && this.BtnDownloadStart.IsEnabled)
			{
				this.BtnDownloadStart_Click();
			}
		}

		// Token: 0x06000B0A RID: 2826 RVA: 0x00007763 File Offset: 0x00005963
		private void BtnDownloadStart_Click()
		{
			PageOtherTest.StartCustomDownload(this.TextDownloadUrl.Text, this.TextDownloadFolder.Text);
		}

		// Token: 0x06000B0B RID: 2827 RVA: 0x000575BC File Offset: 0x000557BC
		public static void StartCustomDownload(string Url, string Folder = null)
		{
			try
			{
				string text = "File_" + Conversions.ToString(ModBase.RandomInteger(0, 9999999));
				try
				{
					text = WebUtility.UrlEncode(ModBase.GetFileNameFromPath(Url));
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "自定义下载文件没有文件名", ModBase.LogLevel.Debug, "出现错误");
				}
				if (string.IsNullOrWhiteSpace(Folder))
				{
					Folder = ModBase.SelectAs("选择文件保存位置", text, null, null);
					if (!Folder.Contains("\\"))
					{
						return;
					}
					if (Folder.EndsWith(text))
					{
						Folder = Strings.Mid(Folder, 1, checked(Folder.Length - text.Length));
					}
				}
				Folder = Folder.Replace("/", "\\").TrimEnd(new char[]
				{
					'\\'
				}) + "\\";
				try
				{
					Directory.CreateDirectory(Folder);
					ModBase.CheckPermissionWithException(Folder);
				}
				catch (Exception ex2)
				{
					ModBase.Log(ex2, "访问文件夹失败（" + Folder + "）", ModBase.LogLevel.Hint, "出现错误");
					return;
				}
				ModBase.Log("[Download] 自定义下载文件名：" + text, ModBase.LogLevel.Normal, "出现错误");
				ModBase.Log("[Download] 自定义下载文件目标：" + Folder, ModBase.LogLevel.Normal, "出现错误");
				int uuid = ModBase.GetUuid();
				ModNet.LoaderDownload loaderDownload = new ModNet.LoaderDownload("自定义下载文件：" + text + " ", new List<ModNet.NetFile>
				{
					new ModNet.NetFile(new string[]
					{
						Url
					}, Folder + text, null)
				});
				ModLoader.LoaderCombo<int> loaderCombo = new ModLoader.LoaderCombo<int>("自定义下载 (" + Conversions.ToString(uuid) + ") ", new ModLoader.LoaderBase[]
				{
					loaderDownload
				});
				loaderCombo.OnStateChanged = ((PageOtherTest._Closure$__.$IR7-2 == null) ? (PageOtherTest._Closure$__.$IR7-2 = delegate(ModLoader.LoaderBase a0)
				{
					PageOtherTest.DownloadState((ModLoader.LoaderCombo<int>)a0);
				}) : PageOtherTest._Closure$__.$IR7-2);
				loaderCombo.Start(null, false);
				ModLoader.LoaderTaskbarAdd(loaderCombo);
				ModMain.m_CollectionAccount.BtnExtraDownload.ShowRefresh();
				ModMain.m_CollectionAccount.BtnExtraDownload.Ribble();
			}
			catch (Exception ex3)
			{
				ModBase.Log(ex3, "开始自定义下载失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000B0C RID: 2828 RVA: 0x0005781C File Offset: 0x00055A1C
		private void BtnDownloadSelect_Click(object sender, EventArgs e)
		{
			string text = ModBase.SelectFolder("选择文件夹");
			if (Operators.CompareString(text, "", true) != 0)
			{
				this.TextDownloadFolder.Text = text;
			}
		}

		// Token: 0x06000B0D RID: 2829 RVA: 0x00057850 File Offset: 0x00055A50
		private void BtnDownloadOpen_Click()
		{
			try
			{
				string text = this.TextDownloadFolder.Text;
				Directory.CreateDirectory(text);
				Process.Start(text);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "打开下载文件夹失败", ModBase.LogLevel.Debug, "出现错误");
			}
		}

		// Token: 0x06000B0E RID: 2830 RVA: 0x000578A8 File Offset: 0x00055AA8
		private static void DownloadState(ModLoader.LoaderCombo<int> Loader)
		{
			int num;
			int num4;
			object obj;
			try
			{
				IL_00:
				ProjectData.ClearProjectError();
				num = 1;
				IL_07:
				int num2 = 2;
				switch (Loader.State)
				{
				case ModBase.LoadState.Finished:
					IL_27:
					num2 = 4;
					ModMain.Hint(Loader.Name + "完成！", ModMain.HintType.Finish, true);
					IL_40:
					num2 = 5;
					Interaction.Beep();
					break;
				case ModBase.LoadState.Failed:
					IL_49:
					num2 = 7;
					ModBase.Log(Loader.Error, Loader.Name + "失败", ModBase.LogLevel.Msgbox, "出现错误");
					IL_6C:
					num2 = 8;
					Interaction.Beep();
					break;
				case ModBase.LoadState.Aborted:
					IL_75:
					num2 = 10;
					ModMain.Hint(Loader.Name + "已取消！", ModMain.HintType.Info, true);
					break;
				}
				IL_8F:
				goto IL_10E;
				IL_91:
				int num3 = num4 + 1;
				num4 = 0;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
				IL_CF:
				goto IL_103;
				IL_D1:
				num4 = num2;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
				IL_E1:;
			}
			catch when (endfilter(obj is Exception & num != 0 & num4 == 0))
			{
				Exception ex = (Exception)obj2;
				goto IL_D1;
			}
			IL_103:
			throw ProjectData.CreateProjectError(-2146828237);
			IL_10E:
			if (num4 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		// Token: 0x06000B0F RID: 2831 RVA: 0x000579DC File Offset: 0x00055BDC
		private void BtnClick_Click(object sender, EventArgs e)
		{
			int num;
			int num5;
			object obj;
			try
			{
				IL_00:
				ProjectData.ClearProjectError();
				num = 1;
				IL_07:
				int num2 = 2;
				List<int> list = new List<int>
				{
					ModBase.RandomInteger(0, 6)
				};
				for (;;)
				{
					IL_2D:
					num2 = 4;
					if (ModBase.RandomInteger(0, 1) != 1)
					{
						break;
					}
					IL_1E:
					num2 = 5;
					list.Add(ModBase.RandomInteger(1, 6));
				}
				IL_39:
				num2 = 7;
				if (!list.Contains(1))
				{
					goto IL_7F;
				}
				IL_44:
				num2 = 8;
				if (ModMain.MyMsgBox("当暴露在点击确定后的场景时，有极小部分人群会引发癲痫。这种情形可能是由于某些未查出的癫病症状引起，即使该人员并没有患癫痫病史也有可能造成此类病症。如果您的家人或任何家庭成员曾有过类似症状，请在点击确定前咨询您的医生或医师。如果您在稍后出现任何症状，包括头晕、目眩、眼部或肌肉抽搐、失去意识、失去方向感、抽搐或出现任何自己无法控制的动作，请立即关闭 PCL2 并咨询您的医生或医师。\\n这是最后的警告，是否继续操作？".Replace("\\n", "\r\n"), "警告", "确定", "取消", "", true, true, false) == 2)
				{
					goto IL_4B1;
				}
				goto IL_B3;
				IL_7F:
				num2 = 11;
				ModMain.MyMsgBox("PCL2 作者不会受理由于点击千万别点造成的任何 Bug。\\n这是最后的警告，是否继续操作？".Replace("\\n", "\r\n"), "警告", "确定", "确定", "确定", true, true, false);
				IL_B3:
				num2 = 12;
				List<int>.Enumerator enumerator = list.GetEnumerator();
				checked
				{
					while (enumerator.MoveNext())
					{
						int num3 = enumerator.Current;
						IL_D3:
						num2 = 13;
						switch (num3)
						{
						case 0:
							IL_FF:
							num2 = 15;
							ModMain.m_ObserverAccount = 1;
							IL_108:
							num2 = 16;
							ModMain.CompareTag(-1);
							break;
						case 1:
							IL_116:
							num2 = 18;
							ModMain.m_ObserverAccount = 2;
							IL_11F:
							num2 = 19;
							ModMain.CompareTag(-1);
							break;
						case 2:
							IL_12D:
							num2 = 21;
							if (ModMain.m_CollectionAccount.PanBack.LayoutTransform != null)
							{
								IL_141:
								num2 = 22;
								ModMain.m_CollectionAccount.PanBack.RenderTransformOrigin = new Point(1.25, 1.25);
							}
							IL_16A:
							num2 = 23;
							switch (ModBase.RandomInteger(0, 2))
							{
							case 0:
								IL_18F:
								num2 = 25;
								ModMain.m_CollectionAccount.PanBack.RenderTransform = new ScaleTransform(1.0, -1.0);
								break;
							case 1:
								IL_1BD:
								num2 = 27;
								ModMain.m_CollectionAccount.PanBack.RenderTransform = new ScaleTransform(-1.0, -1.0);
								break;
							case 2:
								IL_1EB:
								num2 = 29;
								ModMain.m_CollectionAccount.PanBack.RenderTransform = new ScaleTransform(-1.0, 1.0);
								break;
							}
							break;
						case 3:
							IL_219:
							num2 = 32;
							ModMain.m_CollectionAccount._RepositoryAccount = false;
							IL_227:
							num2 = 33;
							ModMain.m_CollectionAccount.PanBack.LayoutTransform = new ScaleTransform(2.5, 2.5);
							IL_250:
							num2 = 34;
							ModMain.m_CollectionAccount.Height = (double)(MyWpfExtension.FindModel().Screen.WorkingArea.Height - 200);
							IL_27C:
							num2 = 35;
							ModMain.m_CollectionAccount.Width = (double)(MyWpfExtension.FindModel().Screen.WorkingArea.Width - 200);
							IL_2A8:
							num2 = 36;
							ModMain.m_CollectionAccount.Left = 0.0;
							IL_2BE:
							num2 = 37;
							ModMain.m_CollectionAccount.Top = 0.0;
							IL_2D4:
							num2 = 38;
							ModAnimation.AniStop("Don't Click Scale");
							break;
						case 4:
							IL_2E6:
							num2 = 40;
							ModMain.m_CollectionAccount._RepositoryAccount = false;
							IL_2F4:
							num2 = 41;
							ModMain.m_CollectionAccount.RenderTransform = new ScaleTransform();
							IL_306:
							num2 = 42;
							ModAnimation.AniStart(ModAnimation.AaScaleTransform(ModMain.m_CollectionAccount, -0.85, 5000, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.ExtraStrong), false), "Don't Click Scale", false);
							IL_334:
							num2 = 43;
							ModAnimation.AniStop("Don't Click Rotate");
							break;
						case 5:
							IL_346:
							num2 = 45;
							ModMain.m_CollectionAccount.RenderTransform = new RotateTransform();
							IL_358:
							num2 = 46;
							ModAnimation.AniStart(ModAnimation.AaRotateTransform(ModMain.m_CollectionAccount, Conversions.ToDouble(Operators.MultiplyObject(1000000, ModBase.RandomOne(new int[]
							{
								1,
								-1
							}))), 10000000, 0, null, false), "Don't Click Rotate", false);
							IL_39F:
							num2 = 47;
							ModAnimation.AniStop("Don't Click Scale");
							break;
						case 6:
							IL_3B1:
							num2 = 49;
							ModMain.m_CollectionAccount._RepositoryAccount = false;
							IL_3BF:
							num2 = 50;
							if (ModBase.RandomInteger(0, 1) != 0)
							{
								IL_3CE:
								num2 = 51;
								ModAnimation.AniStart(ModAnimation.AaX(ModMain.m_CollectionAccount, Conversions.ToDouble(Operators.MultiplyObject(10000000, ModBase.RandomOne(new int[]
								{
									1,
									-1
								}))), 30000000, 0, null, false), "Don't Click Move X", false);
							}
							else
							{
								IL_417:
								num2 = 53;
								ModAnimation.AniStart(ModAnimation.AaY(ModMain.m_CollectionAccount, Conversions.ToDouble(Operators.MultiplyObject(10000000, ModBase.RandomOne(new int[]
								{
									1,
									-1
								}))), 50000000, 0, null, false), "Don't Click Move Y", false);
							}
							IL_45E:
							num2 = 54;
							ModBase.RunInThread((PageOtherTest._Closure$__.$I11-0 == null) ? (PageOtherTest._Closure$__.$I11-0 = delegate()
							{
								for (;;)
								{
									ModBase.RunInUi((PageOtherTest._Closure$__.$I11-1 != null) ? PageOtherTest._Closure$__.$I11-1 : (PageOtherTest._Closure$__.$I11-1 = delegate()
									{
										if (ModMain.m_CollectionAccount.Top < unchecked(-ModMain.m_CollectionAccount.Height))
										{
											ModMain.m_CollectionAccount.Top = (double)(MyWpfExtension.FindModel().Screen.Bounds.Height + 49);
										}
										if (ModMain.m_CollectionAccount.Top > (double)(MyWpfExtension.FindModel().Screen.Bounds.Height + 50))
										{
											ModMain.m_CollectionAccount.Top = unchecked(-ModMain.m_CollectionAccount.Height + 1.0);
										}
										if (ModMain.m_CollectionAccount.Left < unchecked(-ModMain.m_CollectionAccount.Width))
										{
											ModMain.m_CollectionAccount.Left = (double)(MyWpfExtension.FindModel().Screen.Bounds.Width + 49);
										}
										if (ModMain.m_CollectionAccount.Left > (double)(MyWpfExtension.FindModel().Screen.Bounds.Width + 50))
										{
											ModMain.m_CollectionAccount.Left = unchecked(-ModMain.m_CollectionAccount.Width + 1.0);
										}
									}), false);
									Thread.Sleep(10);
								}
							}) : PageOtherTest._Closure$__.$I11-0);
							break;
						}
						IL_48A:
						num2 = 56;
					}
					IL_492:
					num2 = 57;
					((IDisposable)enumerator).Dispose();
					IL_4A2:
					num2 = 58;
					this.BtnClick.Visibility = Visibility.Collapsed;
					IL_4B1:
					goto IL_5EF;
					IL_4B6:;
				}
				int num4 = num5 + 1;
				num5 = 0;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num4);
				IL_5B0:
				goto IL_5E4;
				IL_5B2:
				num5 = num2;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
				IL_5C2:;
			}
			catch when (endfilter(obj is Exception & num != 0 & num5 == 0))
			{
				Exception ex = (Exception)obj2;
				goto IL_5B2;
			}
			IL_5E4:
			throw ProjectData.CreateProjectError(-2146828237);
			IL_5EF:
			if (num5 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		// Token: 0x06000B10 RID: 2832 RVA: 0x00057FFC File Offset: 0x000561FC
		private void BtnJrrp_Click(object sender, EventArgs e)
		{
			checked
			{
				int num = (int)Math.Round(Math.Abs(unchecked(ModBase.GetHash(string.Concat(new string[]
				{
					"asdfgbn",
					Conversions.ToString(DateTime.Now.DayOfYear),
					"12#3$45",
					Conversions.ToString(DateTime.Now.Year),
					"IUY"
				}).ToString()) / 3.0 + ModBase.GetHash(string.Concat(new string[]
				{
					"QWERTY",
					ModBase.initializerState,
					"0*8&6",
					Conversions.ToString(DateTime.Now.Day),
					"kjhg"
				})) / 3.0) / 527.0) % 1001.0);
				int num2;
				if (num >= 970)
				{
					num2 = 100;
				}
				else
				{
					num2 = (int)Math.Round(unchecked((double)num / 969.0 * 99.0));
				}
				string str;
				if (num2 == 100)
				{
					str = "！100！100！！！！！" + (ModMain.ThemeUnlock(13, false, null) ? "\r\n隐藏主题 欧皇彩 已解锁！" : "");
				}
				else if (num2 == 99)
				{
					str = "！额，但不是 100……";
				}
				else if (num2 >= 90)
				{
					str = "！好评如潮！";
				}
				else if (num2 >= 60)
				{
					str = "！是不错的一天呢！";
				}
				else if (num2 > 50)
				{
					str = "！还行啦还行啦。";
				}
				else if (num2 == 50)
				{
					str = "！五五开……";
				}
				else if (num2 >= 40)
				{
					str = "！还……还行吧……？";
				}
				else if (num2 >= 11)
				{
					str = "！呜哇……";
				}
				else if (num2 >= 1)
				{
					str = "……（没错，是百分制）";
				}
				else
				{
					str = "……";
					if (ModMain.MyMsgBox("在查看结果前，请先同意以下附加使用条款：\r\n\r\n1. 我知晓并了解 PCL2 的今日人品功能完全没有出 Bug。\r\n2. PCL2 不对使用本软件所间接造成的一切财产损失（如砸电脑等）等负责。", "今日人品 - 附加使用条款", "同意并查看结果", "再见", "", false, true, false) == 2)
					{
						return;
					}
				}
				ModMain.MyMsgBox((ModMain.m_CollectionAccount._ResolverAccount ? "在这个时候，你的人品值会是：" : "你今天的人品值是：") + Conversions.ToString(num2) + str, (ModMain.m_CollectionAccount._ResolverAccount ? "今日人品？- " : "今日人品 - ") + DateTime.Now.ToString("yyyy/M/d"), "我知道了", "", "", false, true, false);
			}
		}

		// Token: 0x06000B11 RID: 2833 RVA: 0x00007780 File Offset: 0x00005980
		private void BtnCave_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://jinshuju.net/f/esXHQF");
		}

		// Token: 0x06000B12 RID: 2834 RVA: 0x0000778C File Offset: 0x0000598C
		private void CaveHand()
		{
			this.BtnCave.Visibility = (ModMain.CreateTag(null) ? Visibility.Visible : Visibility.Collapsed);
		}

		// Token: 0x06000B13 RID: 2835 RVA: 0x00058234 File Offset: 0x00056434
		private void CardCave_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.methodTag)
			{
				string text = ModBase.RandomOne(new object[]
				{
					ModBase.RandomOne(new string[]
					{
						"来硬的！",
						"钻石！",
						"我们需要再深入些！",
						"结束了？",
						"见鬼去吧！",
						"君临天下！",
						"与火共舞！",
						"本地的酿造厂！",
						"为什么会变成这样呢？",
						"信标工程师！",
						"不稳定的同盟！",
						"天空即为极限！",
						"甜蜜的梦！",
						"探索的时光！",
						"狙击手的对决！",
						"这是？工作台！",
						"永恒的伙伴！",
						"腥味十足的生意！",
						"结束了。",
						"开始了？",
						"这交易不错！",
						"你的世界！",
						"/summon Creeper ~ ~ ~ {Fuse:0}",
						"MC-98587!",
						"紫黑格子波纹疾走！",
						"命令方块不适合作为武器！",
						"Minecraft Dungeon!",
						"新增了一堆 Bug！",
						"Also try Sky Factory 4!",
						"这是刻意的游戏设计！",
						"附魔神圣橡胶树树苗！",
						"有频道的 AE 不是好 AE！",
						"你好中国！",
						"/give @a hugs 64",
						"这是特性！",
						"awwwww man!",
						"Creeper?",
						"Minecraft 2.0!",
						"Hello, Herobrine!",
						"Herobrine...xia?",
						"It's a FEATURE! Not a BUG!",
						"我 Mojang 绝不跳票！",
						"苦力怕！不是爬行者！",
						"蠢虫？毒虫？蠹虫？",
						"粉色羊是隐性纯合子！",
						"Can't keep up! Did the system time change or is the server overloaded?",
						"比钻石更强！",
						"BUGJANG!",
						"猪灵劲曲！",
						"床里面藏着 TNT！",
						"午时已到！",
						"钓鱼有风险！",
						"Deadline 是第一生产力！",
						"你的系统反正就是需要更新，你是要重启呢还是重启呢？",
						"找不到对象！",
						"妈的智障！",
						"面露异常！",
						"Nothing is true, everything is feature!",
						"按 [E] 以赛艇！",
						"新名单！新名单！",
						"夹子！",
						"这个游戏没有 SSR！",
						"光敏性癫痫警告！",
						"CO~ CO~ DA~ YO~",
						"众所周知，炉石传说是免费游戏！",
						"你号没了！",
						"王八坨子号！",
						"A 级记忆删除（物理）！",
						"Also try SCP-CN-660-J!",
						"Command Block Logic!",
						"Also try SCP-CN-048-J!",
						"Also try 丰裕之角！",
						"任天堂就是世界的主宰！",
						"不要停下来啊！",
						"To be continued.",
						"脑子放假去了！",
						"抱抱是第一生产力！",
						"滚你！",
						"当你觉得我咕了，但是我没咕，这也是一种咕！",
						"公 主 焊 接",
						"心脏停跳文学社！",
						"我 Forge 打开这么慢一定是你启动器出 Bug 了！",
						"50382 警告！",
						"暴咕无人机！",
						"破喉咙！破喉咙！破喉咙！",
						"吓得我都把基岩挖掉了！",
						"那就当做没有 Bug 好了！",
						"Crazy Boy Love!",
						"向骰子低头！",
						"发出咕咕咕的声音！",
						"破产了启动器！",
						"泡菜龙启动器！",
						"劈柴驴启动器！",
						"碰瓷狼启动器！",
						"可随手机壳变化颜色！",
						"Keep your DETERMINATION.",
						"五十人解密加强连！",
						"PPCCLL!",
						"Let The Bass Kick...",
						"Early Access!"
					}),
					ModBase.RandomOne(new string[]
					{
						"Also try 艾列之书！",
						"Also try Celeste!",
						"Also try The Witness!",
						"Also try gamejam!",
						"RTX ON!",
						"要恰饭的嘛！",
						"爆炸就是艺术，当量就是正义！",
						"帅得体面，猫得明白！",
						"野炊天下第一！",
						"FLAG IS WIN!",
						"凌波微步，快乐的舞步！",
						"超高校级的咕咕咕！",
						"呐呐呐呐呐呐呐呐呐呐呐呐",
						"倒一杯卡布奇诺！",
						"59 区废墟的红刀哥！",
						"Hello, world!",
						"把龙猫拖去祭天！",
						"五颜六色的黑！",
						"五光十色的白！",
						"高 Ping 战士！",
						"一脸玄素！",
						"最强的法术是掉线法术！",
						"我能怎么办啊，我也很绝望啊！",
						"保护我的敌人，痛击我的队友！",
						"掉帧是道具吗！",
						"你不是挂怎么和我们打！",
						"叮叮叮叮！",
						"无阻力滚轮！",
						"发出死了的声音！",
						"打不过就丢人，骂人！",
						"要致富，先撸树！",
						"众所周知，我的世界的开发商是 BugJump。",
						"好臭啊。",
						"据说咕咕叫的鸽子最适合炖，炖起来非常美味。",
						"千 万 别 点",
						"是的，这是一条用来凑数的信息。",
						"IO 效果之箭！",
						"你必封印在众人梦中散布瘟疫的障目之光。",
						"卡其脱离太。",
						"不要停下来啊！",
						"Professional Crush Launcher!",
						"战神与他的文盲老父亲！",
						"锟斤拷锟斤拷烫烫烫！",
						"龙猫战争就是龙猫战争！",
						"我跟你讲你这样是要被夹的！",
						"土豆怎么烹调才好吃？",
						"Missing No.",
						"管管孩子，救救游戏！",
						"Ori2 天下无敌！",
						"气人安卓，在线谈崩。",
						"希望人有事.jpg",
						"卧槽，不是吧，这……",
						"FAKE NEWS!",
						"非法吟诗 ×",
						"禁止套娃 禁止套娃 禁止套娃 awa",
						"这是想上骰子的 SS！",
						"打开浏览器 - 狗屁不通文章生成器 - 随便复制一段",
						"这里可以写广告嘛？",
						"PCL2＝PCL1＋PCL1",
						"欢迎使用嫖娼佬启动器！",
						"不打钱就削土豆！",
						"众所周知，1+1=王！",
						"登录镜像世界，同调生物 阿尔法超活性化，连接！",
						"回声洞草。",
						"PCL2 服务器第一朵蘑菇云始于 Candy_Pink！",
						"因果乃旋转纺车，光彩之多面明镜。浮世苍茫，不过瞬逝幻梦。善恶爱证，皆有定数于命运之轮中。吞噬于黄泉之冥暗。鸣呼，吾乃梦之成人、幻恋之观者。",
						"欢迎使用忘却的旋律启动器！",
						"Minecraft 2.0 正在启动中！",
						"Link Start!",
						"Completely shocked!",
						"林肯死大头！",
						"FBI! OPEN THE DOOR!",
						"时间与空间的交集，聚能与锁钥的紧合，时空横竖之穿，缥缈无定之门，虚无而又现实的世界，吾乃末界之神，听从吾的召唤，超时空逆转！",
						"你所做的一切，都是在重复昨天。",
						"不是每个东北人都会二人转！",
						"但是天津人真的会相声！",
						"有地域歧视的游戏不是好游戏！",
						"麻辣鸡翅真好吃！",
						"MCD 被网易收走了呢。",
						"薅 羊 毛",
						"后浪们已经涌入 pilipili，你还不入海吗？",
						"玩我的世界地下城吗？",
						"麻辣鸡腿也不错，但是太多肉了。",
						"Wake up.",
						"It's time to go to school.",
						"Did you finished your homework?",
						"弓之神的馈赠啊，吾用于击溃敌人的盔甲，将您的神力，附着在这把弓上！风破！",
						"有的人毕业了，有的人还没开学。",
						"在 38 度的太阳底下放寒假。",
						"一条有先见之明的消息对你说了先见之明这四个字。",
						"红鲤鱼与绿鲤鱼与旅驴与铝绿与氯绿……",
						"优质回答：我不知道",
						"大人，食大便了。",
						"不挖坑，毋宁死！",
						"人生无味，夜空无明，原野无火。",
						"高锰酸钾滴眼睛！",
						"丢骰子 2.0！",
						"AMD YES!",
						"啊这……",
						"请不要在给我识别码的时候混进去空格！",
						"oreoreoreorerererereoooooorereoreo",
						"龙猫都写了些什么 233333",
						"《龙猫观察日记》！",
						"过个桥还要上次天。"
					}),
					ModBase.RandomOne(new string[]
					{
						"基岩真好吃！",
						"今日无事可做.jpg",
						"在没有错误日志的情况下诊断任何问题无异于闭眼开车。",
						"PCL2 咕测群！",
						"希望可爱的龙猫猫能更容易看懂自己写的代码。",
						"PCL2 的代码只有龙猫和上帝知道，然而龙猫忘记了。",
						"挖三填一：刚进入 MC 的玩家可能都不知道这个游戏存在危险，只知道东看看西瞅瞅，所以到了晚上的时候才知道 MC 的可怕。",
						"Also try Terraria.",
						"龙猫画的饼很大！",
						"事实证明，乱打序顺会不影响的人阅读。",
						"你知道龙猫 MC 的 ID 是 LTCat 吗？",
						"祝 PCL 越来越好，也希望龙猫身体健康！",
						"获得成就：时代变了（将经验修补附魔书扔入火里）",
						"龙腾猫跃 > 龙猫 > lm",
						"虽然不知道为什么，但是我就是想夹你。",
						"日常踩雷！",
						"龙猫 NB！",
						"生活奇奇怪怪，我得可可爱爱。",
						"不要尝试在岩浆里喝热水！",
						"博士，您还有许多事情需要处理，现在还不能休息哦。",
						"我就是叫紫妈怎么了，有本事从我背后出现然后把我的脸按在键盘aoikxznwgp",
						"Also try Minecraft Dungeons!",
						"Also try Minecraft Earth!",
						"Also try Minecraft with RTX!",
						"public static void main(String[] args) {}",
						"Ctrl + S!",
						"九头蛇万岁！",
						"反手一个超级加倍，闷声发大财。",
						"回声洞好好玩啊 2333",
						"↑↑↓↓←→←→BABA",
						"兽人永不为奴！（除非包吃包住）",
						"在这种困难的抉择下，本人思来想去，寝食难安。既然如何，因何而发生？",
						"咕嚕靈波~（｡•ω•｡)つ━☆.. ・*",
						"建筑，我所欲也，红石，亦我所欲也；二者不可得兼……喊俩大佬就可以得兼了。",
						"我的梦想是天天咕咕咕（逃",
						"锟斤拷锟斤拷䵣笓靹攮濄魊！",
						"* It fills you with determination.",
						"点击千万别点，可以获得所有主题。",
						"I want to play a game.",
						"十七张牌你能秒我？你能秒杀我？",
						"总而言之，这个界面还没做完啦……",
						"韩信带净化，虽然不是同一时间，但是是同一厕所。",
						"MINCERAFT!",
						"lm: 小心夹子",
						"这个启动器是真的好用，下载特别快，有了它，OptiFine、Forge 随便下，真的很香！",
						"雄火龙又双叒叕被绿了。",
						"净他妈扯淡！",
						"乌拉！！！！！",
						"老八蜜汁小憨包。",
						"Welcome to……O…PCL II！",
						"快来试试 PCL2 下载器！",
						"特朗普的红领巾暴露啦！",
						"新的 Bug 删除了，旧的 Bug 增加了。",
						"我知道你想睡觉了，但是，不熬夜游戏不会健康。",
						"Death is not an escape.",
						"PCL2 有外置登录！！！",
						"欸我 10000000 Mods 的整合包打不开了，这启动器不行啊。",
						"玄素黑！",
						"回声~回声~回声~",
						"360：我 TM 觉得你很可疑",
						"龙猫猫的启动器~",
						"爷爷，你关注的龙猫终于更新啦！",
						"rm -rf /*",
						"半命无出三，故吾曰 G 胖不三。PCL 不出三，是龙猫不三乎？曰：非然也。",
						"让人类永远保持理智是一种奢望！",
						"点千万别点会发生好玩的事！",
						"PCL2 是我的世界启动器，不是下载器！",
						"众所周知，PCL2 是一款不错的下载器。",
						"* 你赞助了龙猫，这使你充满了决心",
						"希望开发者的权益不会受到侵害！awa……",
						"KO NO DIO DA!",
						"我可是要成为 Bug 王的游戏！",
						"PCL 是我接触的第一个可以正版的 MC 启动器，但是我居然没有注意它有 2 代，作者的能力真的让我刮目相看，很棒！继续努力！！",
						"哇！金色传说！",
						"PCL2 工具箱！",
						"我绝对不会因为回声洞给龙腾猫跃发电的！",
						"我绝对不会发回声洞的！",
						"爷想被夹！",
						"淡黄的长裙~蓬松的头发~",
						"奇怪的知识增加了！",
						"小朋友，你是否有很多问号？",
						"小问号，你是否有很多朋友？",
						"黑人抬棺。",
						"阿 Sir，不会吧？",
						"老内测了！",
						"祝 PCL 越来越好！%>:<%",
						"Get Over Here!",
						"下周不咕了，真的吗……",
						"震惊龙猫一整天！",
						"你看这个光影多棒啊，开一下试试，反正电脑好，诶我主机怎么烧",
						"PCL2 高速下载器！",
						"右键开始游戏按钮是没有彩蛋的！",
						"> 点此启动内置小游戏 <",
						"衬衫的价格是九镑十五便士。",
						"Right click into the game!",
						"建议用脑壳想想再干事，脑壳别那么铁。——龙腾猫跃",
						"然则天下之事，但知其一，不知其二者多矣，可据理臆断欤？",
						"Java (TM) SE binary 未响应\\n· 尝试恢复此程序\\n· 等待程序响应\\n· 关闭程序",
						"我这里有负荆请罪 IV、弹射物吸引 V、经验腐蚀的钻石甲，要吗？（",
						"Plain musiC pLayer 2!"
					}),
					ModBase.RandomOne(new string[]
					{
						"犹豫，就会白给！",
						"PCL2 YES!",
						"龙猫是龙还是猫？",
						"你吼辣么大声干什么嘛！",
						"我爱吃薯条 awa",
						"我不做人啦！JOJO！！！",
						"哇，这就是回声洞里面的感 juo 吗？",
						"XeKr 打钱！",
						"Press F to enter the tank!",
						"多行不义必自毙。",
						"活跃橙好难拿！",
						"这 PCL 就快的离谱，抱紧我的第三方 QAQ",
						"自从玩了我的世界，牛顿的棺材板就再也合不上了！",
						"不要停下来啊！（指咕咕咕）",
						"逗比水货1256！",
						"咕咕咕鸽鸽鸽嗝！",
						"支持 PCL2，支持龙猫！加油！",
						"因为匆忙制作的 PCL2 启动器，我的身体已经菠萝菠萝哒了！",
						"龙猫 NB！",
						"Minceraft!",
						"你还在用 PCL II？ 我已经用 PCL Max Pro 了！",
						"Nobody knows PCL2 better than me!",
						"lbwnb!",
						"/kill @e[type=creeper]",
						"/gamemode 1",
						"我爱中国！我爱中国！我爱中国！",
						"杀手皇后，第三炸弹，败者食尘！姨妈大！",
						"Mojang 作为英语或瑞典语时的读法不一样哦。",
						"主页自定义看起来很难，但是你仔细研究发现你可以套娃。",
						"龙猫的养老服务器 awa",
						"PCL2 盒子！",
						"你的好友 xxx 正在游戏\\nWallpaper Engine",
						"我曾经也是个冒险家，直到我的膝盖中了一箭！",
						"RTX ON!",
						"破产了 2 启动器，你值得拥有。",
						"这是一个无情的下载器！",
						"您，人？神！砰砰砰！",
						"龙腾猫跃最棒了！トトロが一番跳ねる！",
						"欧皇！！！",
						"* 看到这么多沙雕网友的留言，使你充满了决心",
						"DUANG~",
						"天呐，那是鸡还是鸭！",
						"Mojang 在瑞典语中意思是东西！",
						"所以……我不知道有啥好说的，反正氵一个留言就行了 qwq",
						"众所周知，地狱有水。",
						"Also try 看云模拟器（bushi）！",
						"游戏一小时，看云 59min。",
						"我们需要再深入些。抱歉，今天不行。",
						"NETHER UPDATE!",
						"宫廷玉液酒，一百八一杯！",
						"喵呜~你好可爱~",
						"如果游戏没有声音可以尝试按下 F3+S！",
						"我永远喜欢艾米利亚！！！",
						"犹豫就会白给！",
						"我尝试用石镐挖钻石，最终我认为那是废料！",
						"Mojang AB = Mojang And Bug",
						"放屁不仅仅是一个重大的事件，还可能会改变我的人生。",
						"SCP 基金会已介入调查！",
						"很快就到你家门口挖矿！",
						"10 岁以下的儿童不宜食用小块块！（PS：我的世界 ESRB 分级为 10+）",
						"Removed Herobrine!",
						"PCL2 是个我的世界启动器吗？不，是音乐播放器，Mod 下载器和下载软件。",
						"furry? furry!",
						"一定要点下面那个千万别点！！！",
						"手持两把锟斤拷，口中疾呼烫烫烫。脚踏千朵屯屯屯，笑看万物锘锘锘。",
						"白帝圣剑！御剑跟着我！",
						"今晚，深渊结算。",
						"(let ([s \"(let ([s ~s]) (printf s s)\"]) (printf s s)",
						"花开花落，再灿烂的星光也终将消失。",
						"韩信带净化，只有你们想不到，没有我老八做不到的奥。",
						"欢迎使用史上最复杂的解密启动器！（doge）",
						"你试试点下面的红框 ↓↓↓",
						"某黑客：你会编程吗？龙猫：我不会，PCL 不是我编的。",
						"* (通过对着语音转换系统乱叫，这只龙猫偶然编出了这个软件。)",
						"宇宙多么浩瀚，偏偏我们在此相遇！",
						"你知道吗？Minecraft 在 1.15.2 及以后又新加入了一个隐藏成就！",
						"人品测试，每天一次！",
						"彭翠兰启动器！",
						"生而为人，我很抱歉！（看到这条留言的人一定很温柔吧！）",
						"没错，是百分制√",
						"ckya blyat!",
						"好快の刀！",
						"freedom d↓ve！",
						"B.B.K.K.B.K.K.",
						"泷泽萝拉哒！！！",
						"今天你猫车了吗？",
						"我国有一套完整的未成年人保护法！",
						"在内群有个人经常会把龙猫称为游戏《黎明杀机》里面的夹子杀手……",
						"回声洞 投稿",
						"NICE 大夫~",
						"典明粥的制作配方：花京院典明的爱心宝宝粥*1 + 替身使者 死神13 的便便*1",
						"二次元，金发，吸血鬼，可爱.....没错，这些都是在形容迪奥·布兰度。",
						"我在想为什么没有人一开始就用最强攻击呢？",
						"花儿在绽放，小鸟在歌唱……",
						"就 该 在 地 狱 中 燃 烧",
						"腾讯** 百度网盘**",
						"我的世界一直都不只是一款马赛克游戏！",
						"聆听怒海潮生，长空雷震，獠牙在耳，万籁黄昏，最动人，莫过喧嚣红尘。",
						"这次一定！",
						"America, your emperor has return!"
					}),
					ModBase.RandomOne(new string[]
					{
						"Fabric YES!",
						"秒了，有什么好说的。",
						"打开 ICEY，又是气死旁白的一天呢！",
						"平角裤平角裤",
						"白日放鸽须纵酒，龙猫作伴好还乡。",
						"龙猫说快改完 Bug 了，他一定没改完，就像老婆饼里没有老婆，康师傅牛肉面里没有牛肉。",
						"当你觉得臭鸽子龙猫又要咕咕咕的时候他真的咕咕咕了，这亦是一种不咕。",
						"December=Dec",
						"左手画圆，右手画方！",
						"咕咕咕咕？咕咕咕咕咕咕！咕咕咕咕咕咕咕？？？咕咕咕！（咕咕咕咕咕咕咕咕咕",
						".. -....- .-.. --- ...- . -....- .--. -.-. .-.. ..---",
						"芜湖，起飞！",
						"伞兵一号卢本伟准备就绪！",
						"I see the player you mean.",
						"丢人！你给我退出战场！",
						"精 神 小 伙",
						"总有些话，是反的，是倒的！",
						"大图？高清？",
						"我的世界是好游戏啊，再差的电脑也能带起来，再好的电脑也带不动……",
						"龙猫：太复杂了，不修了，这是特性，特性！",
						"Why do you see this? Shouldn't you play your game!",
						"你给路达哟！不说了开游戏了，林肯死大头！",
						"炮爷出击！",
						"我们是如何走到这一地步的？",
						"有个按钮可以让启动器缩小，旋转……",
						"众所周知，电子游戏不需要视力！",
						"我永远单推谢拉！",
						"还记得第一次玩我的世界的时候吗？那曾是很美好的回忆……",
						"该说什么好呢 说什么好呢 什么好呢 么好呢 好呢 呢 （回声真大",
						"如果你找不到第三方登录的话不要到版本选择点那三个点，更不要点那个设置，就算你点了那千万不要往下翻。",
						"千万别点千万别点！",
						"El Primo!!!",
						"在时间的流逝中，没有什么事是一成不变的。",
						"The Escapists 2？彳亍，开始逃狱！",
						"熬夜对身体不好，所以我建议你们……玩通宵。",
						"啊wee改哈鞥嫦娥我刚不疤痕处哈维楚王嗡阿格王朔！！！",
						"想清楚再反馈，不然给你夹子大套餐！",
						"众所周知，柯南和基德才是真爱！",
						"雷石东直放站！",
						"现在玩的嗨，待会被夹更嗨！",
						"我斑愿称你为最强启动器！",
						"人群当中钻出来一个光！头！",
						"啊呜呜呜~~",
						"伊莉雅：美游来过这里吗？",
						"买不起正版的穷鬼举个爪。",
						"17 张牌你能秒我？你能秒杀我？",
						"有——回——声——吗—— 有-回-声-吗- 有回声吗",
						"Notch is coming back!",
						"夹子启动器！",
						"我不会告诉你，鼠标悬浮在隐藏主题上，会显示出什么不可告人的秘密！",
						"国足 NB！",
						"结束了？不，你还有很多事要做，现在还不能休息哦……",
						"小动物们开酒局，大家都玩的很开心，只有小象很生气。原来这是一个气象局。",
						"握~着~我~的~抱~枕~",
						"我爱吃滑稽果！",
						"跟你们讲一个笑话：龙猫",
						"a_qi 永远的神！",
						"迫害群友需谨慎，不然夹子就离你不远了 awa",
						"Minecraft: Dungeons 又名 我的裤子动了！",
						"100 年清朝老兵，申请出战！",
						"你现在不能睡觉，你的朋友在开派对！",
						"木叶飞舞之处，火亦生生不息！",
						"我爱学习，学习使我妈快乐，我妈快乐，全家快乐！",
						"人被逼急了啥都能做出来，除了数学题！",
						"歪果的启动器不好用！！冲果lm的启动器好用！！！！我爱冲果！！！！",
						"* 保持你的决心，FUCK！",
						"向鸽者文明致敬！",
						"* 今天是多么美好的一天啊。小鸟在歌唱，花朵在绽放。在这样的一天里，像你这样的孩子……应当被龙猫夹起来扔垃圾桶里。",
						"关掉，关掉，一定要关掉！",
						"远古残骸真的存在吗？",
						"啊呦 EVERYBODY 在你头上暴扣！",
						"Plain Craft Launcher→PCL→PC L→电脑 L→电脑垃圾\\n思考.jpg",
						"月色与雪色之间，你是第三种绝色。",
						"群服务器，时不时来群里 Can't keep up！",
						"或许你并不是不想睡觉，而是周围有怪物在游荡！",
						"我们的 LTW 真是太好玩了！",
						"阿瓦达啃大瓜！",
						"非酋该怎么在这个世界上生存（小声）……",
						"妇 科 圣 手",
						"怎么看他是不是 PCL 内测用户？直接给他发句 你想被夹吗 即可！",
						"嗨，同志，您知道列宁格勒和斯大林格勒在哪吗？我在地图上找不到它。",
						"生活就像打电话，不是你先挂就是我先挂！",
						"好好睡一觉， 就是人生的重启方式呀。",
						"为什么披萨会考糊？",
						"老鼠偷了大米，人们说它狡猾；人类偷了蜂蜜，却说蜜蜂勤劳。",
						"千万别点千万别点千万别点！",
						"CHINA!!! CHINA!!! CHINA!!!",
						"看着龙猫的秀发，我不禁陷入沉思……哦！原来龙猫没有头发！",
						"小伙纸，你不讲武德！",
						"咖啡党永不为奴！",
						"再点一下吧！",
						"这个回声洞莫得 CD，定个小目标，点它一亿下！",
						"Caves & Cliffs Update!",
						"到点了，Visual Studio 上号！",
						"人间，处处是仙境，何欲而求天？已有大于未有，莫要失去而追悔莫及！",
						"芜湖~咕咕咕起飞~",
						"死机蓝！",
						"拜振华在 2020 年击败了川建国！",
						"再次点击查看下一位沙雕网友乱七八糟的留言！",
						"咕咕咕——\\n翻译：鸽，下次也不一定。"
					}),
					ModBase.RandomOne(new string[]
					{
						"在 MC 中，沙子可以下落，说明 MC 还是很科学的！（确信",
						"唔咕，要饭大失败……（眼神死",
						"2020 年：AMD 发布个空气，英伟达发布个空气，索尼发布个空气，要不说微软厉害，发布个空气净化器。",
						"这是回声洞~是回声洞~回声洞~声洞~洞~",
						"往往结束才是开始！",
						"年轻人要玩游戏？耗子尾汁！",
						"A1 高闪来一个好吗？秋梨膏！",
						"针不戳，针不戳，这房子盖的针不戳！",
						"好奇怪的罗马数字呢……",
						"Everything that has existed, lingers in the Eternity.",
						"红烧鸡翅我最爱吃！",
						"投稿回声洞的人数为 n，你看到这条的概率是 n 分之一，所以能看到这条的都是欧皇！",
						"希望永远没有男孩暗恋你所暗恋的女孩子。\\n—— By 寒尘（这句话有 4 层含义哦）",
						"不要相信龙猫，一定要点下面的红框！",
						"阿能我老婆！阿噗噜派！",
						"别杀怪物，你这个海豚！",
						"忠告：请不要在喝水的时候看回声洞，否则所造成的一切后果与 PCL II 无关。",
						"生活枯燥无味，龙猫模仿人类！",
						"叛军！老实！逐一发送坦克！",
						"在这个时候，你的人品值会是：100！100！100！！！！！",
						"问：龙猫今天的人品值是多少？\\n答：我连宇宙尽头在哪里都不知道，怎么会知道这个。",
						".--. -.-. .-.. -.-- .. --. . ... .... . -. -- . -. -.. --- ..- -. . -. --. --. .- -. -.. . --.- .. -.. --- -. --. --.- ..",
						"ENDERMAN PENTA KILL! ACE!",
						"如今的中国早已是山河无恙，国富兵强，我们的飞机，再也不用飞第二遍了。",
						"今天，你迁移了吗？",
						"小丑竟是你自己！",
						"哎哟刹不住车了嘿！现在人追着车跑呢嘿！",
						"The cake is a lie.",
						"别戳了，这里没有你想找的东西！",
						"lm：蓝猫",
						"主不在乎。",
						"抱歉，今天不行？不吃这套，谢谢。",
						"做工程是不可能不咕的啦，这辈子都不可能不咕的啦。",
						"挖三填一！",
						"Make Minecraft Great Again!",
						"众所周知，阳光菇不爱阳光。",
						"要是哪一天我电脑打 MC 炸了我都不稀奇！",
						"Oh, Dreeeam~ I~~~ C~~~ U~~~",
						"我们有强大的后勤系统！",
						"炮造毕，何不置珍珠？",
						"有些话倒着读可能会更好！",
						"惊雷撼动着世界的根基！",
						"大地在沉睡，但他并未死去，我行之以咆哮，唤之以雷霆！",
						".. -....- .-.. --- ...- . -....- .--. -.-. .-.. -....- ..---",
						"* 移除了 Herobrine\\n* 修复了一个 Bug\\n* 增加了一个Bug",
						"长官，我们双脚着地，率先踏入地狱！",
						"Plain Craft Launcher 的中文翻译是：普通飞行器发射器！",
						"特别是其搭载 690 战术核显卡的改进版本，一发就可以摧毁一个航母战斗群。",
						"GET STICK BUGGED LOL",
						"要用咕咕对抗咕咕。——鲁迅",
						"哇！碳色非酋！",
						"嘘，不要动，让我们瞧瞧靠近他。一只天然的 LTCat 是普通 Cat 的蛋白质的 5 倍！",
						"下降率大点没事！",
						"快门一按，行车中断，造成事故，移交法办！",
						"中国联通提醒您：警惕移动电信诈骗！",
						"就我个人来说，PCL2 很好用对我的意义，不能不说非常重大。这样看来，就我个人来说，PCL2 很好用对我的意义，不能不说非常重大。而这些并不是完全重要，更加重要的问题是，莎士比亚曾经说过，意志命运往往背道而驰，决心到最后会全部推倒。这句话语虽然很短, 但令我浮想联翩。",
						"夹子，夹子，更多的夹子，夹子在蔓延……",
						"谁言别后终无悔，寒月清宵绮梦回；深知身在情长在，前尘不共彩云飞。",
						"Bugjump 自古特性多，可与育碧争霸王！",
						"众所周知，Bug 修掉一个还会有第二个 Bug 伴随着修掉的 Bug 出现！",
						"芜湖，我直接成为懒狗起飞！",
						"邪王真眼是最强的！",
						"反馈 Bug 前……先想一想这是不是特性！",
						"这是回声洞还是回字洞？",
						"歪比巴卜？",
						"为什么不试试在调试选项中把动画速度调成 0.1x 或是 3x 呢？",
						"神社倒闭之日。",
						"爱丽丝做的布朗尼果然好吃呢！面团口感湿润但却不发黏，有种清爽的甜味。可可粉是用万豪顿牌的吗？",
						"啊啊啊啊啊！我忘记了啊——！",
						"金发的孩子好可怜啊。",
						"获得成就：别人的世界！",
						"蛋白不会做蛋糕！",
						"这是你重来没有玩过的船新版本——PCL2。",
						"初始之音，响彻未来！",
						"都是一棵树引发的问题！",
						"回声洞里面没有米勒星球！",
						"铠约，耶！",
						"春何芳以至悠悠，夏何鸣以对苍穹。",
						"你知道吗：千万别惹玄素，否则会被夹得很惨！",
						"希望人没事！_/ \\_",
						"众所周知，塔科夫是一款恐怖游戏。",
						"NepNep!!!!",
						"问君能有几多愁？恰似一缸龙猫向东流。",
						"这游戏真凡尔赛！",
						"我永远喜欢潮留美海！",
						"Make Minecraft great again!",
						"人活着就是为了秀吉！",
						"这下载速度和蓝冰上划船媲美 awa！",
						"爬虫，是苦力怕！",
						"中继器是直放站！",
						"Hex Dragon！",
						"什么？Java 版不支持光追？显卡白买了……",
						"育碧就是一颗大土豆！",
						"夹了！都给我夹了！",
						"不是不勇敢了，而是那种坦诚过后被抛弃的感觉太可怕太痛苦了。",
						"我起了，一枪秒了，能怎样？",
						"结束了？开始了？不，还没开始呢，咕咕咕！",
						"砍刀是个大帅比！",
						"Dragon Cat！咕咕咕！",
						"虽然下面那个按钮叫千万别点，但是还有好多人去点它！"
					}),
					ModBase.RandomOne(new string[]
					{
						"damedane, dameyo……",
						"量子力学？混沌理论！",
						"哇！白色普通！",
						"PCL2 的蓝色图标是用硫酸铜染色的！",
						"记得使用 Steam 启动 PCL2 哦！",
						"果断，就会白给！",
						"各位同学们，作业写完了吗？",
						"龙猫，我日你先人，给句痛快话，更新不更新！",
						"你不崩谁崩？",
						"可素我有在念书啊！",
						"前有 IDM，后有 XDM，今有 PDM！",
						"玩了红石以后腰不酸了腿不痛了。就是脑袋有点凉。",
						"野蜂飞过，经过了平凡与伟大。却追随着无悔！",
						"竜神の剣を喰らえ！",
						"用尽一生跨过江海，穿越刺林，只为了再次见到你！",
						"您这辈子都别想进入 Grand Theft Auto V 在线模式！",
						"我刚太认真写反馈，结果把笔头含嘴里了！",
						"友谊是魔法！",
						"不懂就问，我要问什么？",
						"年轻人不讲武德！",
						"打五把 CSGO！",
						"* 没人知道龙猫收到多少回声洞投稿。\\n* 没人知道有人投了什么投稿。\\n* 没人知道龙猫的心态。\\n* 因为你根本不在乎龙猫。",
						"巨硬公司™ Hugehard™ Huge hardsoft！",
						"建议您 50 包邮并往里面塞 200 元，更容易卖出！",
						"建议您白送我，更容易卖出！",
						"怎样才能让龙猫选择你的投稿？当然是多发几遍！（bushi",
						"良辰美景奈何天，赏心乐事谁家院？",
						"You should try our sister game, Minceraft!",
						"OOoooOOOoooo! Spooky!",
						"* 你没有看见什么留言，这里只有几根鸽子留下的羽毛。",
						"永远不要问不该问的，永远不要发不该发的，永远不要以为龙猫搞错了！",
						"奇变偶不变，_________！",
						"作业写完了吗？赶紧去写作业！",
						"井底之蛙，不曾见过大海之辽阔，却知晓天空之蓝！",
						"0 errors, 0 warnings!",
						"这个好诶！",
						"我们都是阴沟里的虫子，但总还是得有人仰望星空。",
						"开学愉快！",
						"作业补完了吗？",
						"回首，掏~鬼刀一开，看不见，走位~走位~",
						"我向往自由！我想要谈恋爱！我找不着对象！我去！",
						"温馨提示：按 Alt+F4 有惊喜！",
						"天不生我键盘侠，键道万古如长夜，键来！",
						"E！S！M！跑！！！",
						"你的无畏来源于无知！",
						"我的人品必不可能是 0！系统有 Bug！",
						"二次元，金发，吸血鬼，可爱……没错，这次真的是芙兰朵露了！",
						"祝各位音游人们在今后的打歌过程中好运连连，后宫成群（",
						"生活中，若人出现了，我们就不得不考虑它出现了的事实……",
						"你 要 被 夹"
					}),
					ModBase.RandomOne(new object[]
					{
						ModBase.RandomOne(new string[]
						{
							"灰色是个谎言……",
							"点一下不够就点两下！",
							"今日人品：100！",
							"鱼人节快乐！",
							"滑稽节是一个节日呢！",
							"ASCII 总是三位数！",
							"帮助的英文是 Help！",
							"砸反馈就完事了！",
							"属于宇宙的数字！",
							"众所周知，十大主题一定有十一个！",
							"回声洞能带来灵感！",
							"！读着倒要话候时有",
							"从罗马开始！",
							"MCBBS 的本体是箱子！",
							"化学，文档，网格！",
							"网址就是来路！",
							"越过屏障！",
							"卢恩与去路！",
							"地下埋藏着宝藏！",
							"从老线索中发现新东西！",
							"重组碎片……",
							"橙色线，藏着线和点！",
							"于历史中发掘秘密！",
							"线索在游戏之外！",
							"穷举不能让你变得更强！",
							"OBSIDIAN！",
							"深蓝色的极客！",
							"不要忽视背景！",
							"结束了？开始了。",
							"也许解密得大改一次……"
						}),
						PageOtherTest.GetRandomHint()
					})
				}).ToString().Replace("\\n", "\r\n");
				string text2 = this.LabCave.Text;
				this.LabCave.Text = text;
				this.methodTag = false;
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaOpacity(this.LabCave, -1.0, 5, 0, null, false),
					ModAnimation.AaOpacity(this.LabCave, 1.0, 5, 30, null, false),
					ModAnimation.AaOpacity(this.LabCave, -1.0, 5, 70, null, false),
					ModAnimation.AaOpacity(this.LabCave, 0.9, 5, 85, null, false),
					ModAnimation.AaOpacity(this.LabCave, -1.0, 5, 125, null, false),
					ModAnimation.AaOpacity(this.LabCave, 0.8, 5, 145, null, false),
					ModAnimation.AaOpacity(this.LabCave, -1.0, 5, 165, null, false),
					ModAnimation.AaOpacity(this.LabCave, 0.7, 5, 195, null, false),
					ModAnimation.AaOpacity(this.LabCave, -1.0, 5, 210, null, false),
					ModAnimation.AaOpacity(this.LabCave, 0.5, 5, 235, null, false),
					ModAnimation.AaOpacity(this.LabCave, -1.0, 5, 250, null, false),
					ModAnimation.AaOpacity(this.LabCave, 1.0, 1, 400, null, true),
					ModAnimation.AaTextAppear(this.LabCave, false, true, 60, 400, null, false),
					ModAnimation.AaCode(delegate
					{
						this.methodTag = true;
					}, 0, true)
				}, "Cave", false);
				this.LabCave.Text = text2;
			}
		}

		// Token: 0x06000B14 RID: 2836 RVA: 0x00059CCC File Offset: 0x00057ECC
		public static string GetRandomHint()
		{
			return Conversions.ToString(ModBase.RandomOne(new string[]
			{
				"在版本选择页面右键某个版本也可以进入版本设置页面。",
				"你可以在版本设置的版本分类选项中将某个版本隐藏。",
				"如果游戏没有声音，可以尝试在版本设置中点击 补全文件 按钮。",
				"在第一次启动游戏时，PCL2 会自动将语言设置为中文。",
				"版本设置的服务器选项中可以开启第三方登录验证，这对服主可能会有所帮助。",
				"选择自动配置游戏内存时，PCL2 将会根据剩余内存与当前安装的 Mod 数量动态调整分配的内存！",
				"你可以在版本设置或启动设置的高级设置中关闭游戏启动时的文件校验。",
				"将鼠标悬浮在设置页的左边栏，可以找到重置设置按钮。",
				"PCL2 有许多隐藏主题，将鼠标悬浮在上面就可以看到解锁提示了。",
				"你可以在 Mod 管理页面查看 Mod 详情、进入官网，或是搜索其百科资料。",
				"版本设置只对当前版本生效，而设置页面的设置对所有版本生效。",
				"通过版本选择页面的添加文件夹选项，你可以将已有的 MC 文件夹加入 PCL2。",
				"如果同时安装了 OptiFine 与对应的原版，PCL2 会展示 OptiFine 版本，折叠原版。",
				"PCL2 只会在常规版本中列出最新的一个快照或预发布版。",
				"点击版本右侧的心形就能将该版本加入收藏夹，便于查找。",
				"在版本选择页面右键游戏文件夹可以进行打开、重命名、删除等操作。",
				"直接点击启动页的头像就可以简单快捷地更换皮肤了。",
				"如果你修改了正版皮肤，你需要右键头像选择刷新，头像才能更新。",
				"右键 PCL2 启动页的头像可以保存皮肤文件。",
				"根据游戏版本与环境不同，PCL2 会自动选择合适的 Java。",
				"如果你打开了调试模式，启动页右侧就会显示启动日志。",
				"将鼠标悬浮在下载页的左边栏，可以找到刷新按钮。",
				"将鼠标悬浮在下载页的版本上，可以在右侧找到查看更新日志按钮！",
				"OptiFine 和 Forge 有时候并不兼容，同时安装两者有可能会导致崩溃……",
				"你可以在 PCL 文件夹下新建 hints.txt 来自定义 你知道吗 窗口中的内容，注意编码需要为 UTF-8！",
				"设置中可以自定义离线皮肤，但这只对单人游戏有效。",
				"你可以在设置中选择关闭 PCL2 的部分功能，这对服主或是整合包作者可能会有所帮助。",
				"如果在功能设置中启用游戏更新提示，在 MC 更新时 PCL2 就会弹窗进行提醒。",
				"如果解锁了赞助主题，就能打开回声洞的投稿入口了。",
				"拖拽 PCL2 的窗口边缘就能调整启动器的窗口大小。",
				"PCL2 的第一个内部版本更新于 2018 年 8 月 13 日。",
				"PCL2 的开发者只有龙腾猫跃一个人，并不存在什么开发团队。",
				"据调查，有 90.3% 的用户点击了百宝箱中的千万别点按钮。",
				"PCL2 的隐藏主题中有着一个解密游戏，直到现在通关人数还不到三位数。",
				"PCL2 的开发者龙腾猫跃经常被简称为龙猫，但和那只龙猫没有任何关系。"
			}));
		}

		// Token: 0x17000191 RID: 401
		// (get) Token: 0x06000B15 RID: 2837 RVA: 0x000077A5 File Offset: 0x000059A5
		// (set) Token: 0x06000B16 RID: 2838 RVA: 0x00059E1C File Offset: 0x0005801C
		internal virtual MyCard CardCave
		{
			[CompilerGenerated]
			get
			{
				return this._AnnotationTag;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = new MouseButtonEventHandler(this.CardCave_MouseLeftButtonUp);
				MyCard annotationTag = this._AnnotationTag;
				if (annotationTag != null)
				{
					annotationTag.MouseLeftButtonUp -= value2;
				}
				this._AnnotationTag = value;
				annotationTag = this._AnnotationTag;
				if (annotationTag != null)
				{
					annotationTag.MouseLeftButtonUp += value2;
				}
			}
		}

		// Token: 0x17000192 RID: 402
		// (get) Token: 0x06000B17 RID: 2839 RVA: 0x000077AD File Offset: 0x000059AD
		// (set) Token: 0x06000B18 RID: 2840 RVA: 0x000077B5 File Offset: 0x000059B5
		internal virtual TextBlock LabCave { get; set; }

		// Token: 0x17000193 RID: 403
		// (get) Token: 0x06000B19 RID: 2841 RVA: 0x000077BE File Offset: 0x000059BE
		// (set) Token: 0x06000B1A RID: 2842 RVA: 0x00059E60 File Offset: 0x00058060
		internal virtual MyTextButton BtnCave
		{
			[CompilerGenerated]
			get
			{
				return this.m_RefTag;
			}
			[CompilerGenerated]
			set
			{
				MyTextButton.ClickEventHandler obj = new MyTextButton.ClickEventHandler(this.BtnCave_Click);
				RoutedEventHandler value2 = delegate(object sender, RoutedEventArgs e)
				{
					this.CaveHand();
				};
				MyTextButton refTag = this.m_RefTag;
				if (refTag != null)
				{
					refTag.TestRepository(obj);
					refTag.Loaded -= value2;
				}
				this.m_RefTag = value;
				refTag = this.m_RefTag;
				if (refTag != null)
				{
					refTag.ResolveRepository(obj);
					refTag.Loaded += value2;
				}
			}
		}

		// Token: 0x17000194 RID: 404
		// (get) Token: 0x06000B1B RID: 2843 RVA: 0x000077C6 File Offset: 0x000059C6
		// (set) Token: 0x06000B1C RID: 2844 RVA: 0x00059EC0 File Offset: 0x000580C0
		internal virtual MyButton BtnJrrp
		{
			[CompilerGenerated]
			get
			{
				return this.serverTag;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnJrrp_Click);
				MyButton myButton = this.serverTag;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.serverTag = value;
				myButton = this.serverTag;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000195 RID: 405
		// (get) Token: 0x06000B1D RID: 2845 RVA: 0x000077CE File Offset: 0x000059CE
		// (set) Token: 0x06000B1E RID: 2846 RVA: 0x00059F04 File Offset: 0x00058104
		internal virtual MyButton BtnClick
		{
			[CompilerGenerated]
			get
			{
				return this.serviceTag;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnClick_Click);
				MyButton myButton = this.serviceTag;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.serviceTag = value;
				myButton = this.serviceTag;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000196 RID: 406
		// (get) Token: 0x06000B1F RID: 2847 RVA: 0x000077D6 File Offset: 0x000059D6
		// (set) Token: 0x06000B20 RID: 2848 RVA: 0x00059F48 File Offset: 0x00058148
		internal virtual MyTextBox TextDownloadUrl
		{
			[CompilerGenerated]
			get
			{
				return this.m_ImporterTag;
			}
			[CompilerGenerated]
			set
			{
				MyTextBox.ValidateChangedEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.StartButtonRefresh();
				};
				KeyEventHandler value2 = new KeyEventHandler(this.TextDownloadUrl_KeyUp);
				MyTextBox importerTag = this.m_ImporterTag;
				if (importerTag != null)
				{
					MyTextBox.RevertWrapper(obj);
					importerTag.KeyUp -= value2;
				}
				this.m_ImporterTag = value;
				importerTag = this.m_ImporterTag;
				if (importerTag != null)
				{
					MyTextBox.PostWrapper(obj);
					importerTag.KeyUp += value2;
				}
			}
		}

		// Token: 0x17000197 RID: 407
		// (get) Token: 0x06000B21 RID: 2849 RVA: 0x000077DE File Offset: 0x000059DE
		// (set) Token: 0x06000B22 RID: 2850 RVA: 0x00059FA4 File Offset: 0x000581A4
		internal virtual MyTextBox TextDownloadFolder
		{
			[CompilerGenerated]
			get
			{
				return this.proxyTag;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = delegate(object sender, RoutedEventArgs e)
				{
					this.SaveCacheDownloadFolder();
				};
				MyTextBox.ValidateChangedEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.StartButtonRefresh();
				};
				KeyEventHandler value3 = new KeyEventHandler(this.TextDownloadUrl_KeyUp);
				MyTextBox myTextBox = this.proxyTag;
				if (myTextBox != null)
				{
					myTextBox.FindRepository(value2);
					MyTextBox.RevertWrapper(obj);
					myTextBox.KeyUp -= value3;
				}
				this.proxyTag = value;
				myTextBox = this.proxyTag;
				if (myTextBox != null)
				{
					myTextBox.SetupRepository(value2);
					MyTextBox.PostWrapper(obj);
					myTextBox.KeyUp += value3;
				}
			}
		}

		// Token: 0x17000198 RID: 408
		// (get) Token: 0x06000B23 RID: 2851 RVA: 0x000077E6 File Offset: 0x000059E6
		// (set) Token: 0x06000B24 RID: 2852 RVA: 0x0005A01C File Offset: 0x0005821C
		internal virtual MyTextButton BtnDownloadSelect
		{
			[CompilerGenerated]
			get
			{
				return this.m_ClassTag;
			}
			[CompilerGenerated]
			set
			{
				MyTextButton.ClickEventHandler obj = new MyTextButton.ClickEventHandler(this.BtnDownloadSelect_Click);
				MyTextButton classTag = this.m_ClassTag;
				if (classTag != null)
				{
					classTag.TestRepository(obj);
				}
				this.m_ClassTag = value;
				classTag = this.m_ClassTag;
				if (classTag != null)
				{
					classTag.ResolveRepository(obj);
				}
			}
		}

		// Token: 0x17000199 RID: 409
		// (get) Token: 0x06000B25 RID: 2853 RVA: 0x000077EE File Offset: 0x000059EE
		// (set) Token: 0x06000B26 RID: 2854 RVA: 0x0005A060 File Offset: 0x00058260
		internal virtual MyButton BtnDownloadStart
		{
			[CompilerGenerated]
			get
			{
				return this.m_RegistryTag;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.BtnDownloadStart_Click();
				};
				MyButton registryTag = this.m_RegistryTag;
				if (registryTag != null)
				{
					registryTag.RevertResolver(obj);
				}
				this.m_RegistryTag = value;
				registryTag = this.m_RegistryTag;
				if (registryTag != null)
				{
					registryTag.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700019A RID: 410
		// (get) Token: 0x06000B27 RID: 2855 RVA: 0x000077F6 File Offset: 0x000059F6
		// (set) Token: 0x06000B28 RID: 2856 RVA: 0x0005A0A4 File Offset: 0x000582A4
		internal virtual MyButton BtnDownloadOpen
		{
			[CompilerGenerated]
			get
			{
				return this._ProducerTag;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.BtnDownloadOpen_Click();
				};
				MyButton producerTag = this._ProducerTag;
				if (producerTag != null)
				{
					producerTag.RevertResolver(obj);
				}
				this._ProducerTag = value;
				producerTag = this._ProducerTag;
				if (producerTag != null)
				{
					producerTag.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700019B RID: 411
		// (get) Token: 0x06000B29 RID: 2857 RVA: 0x000077FE File Offset: 0x000059FE
		// (set) Token: 0x06000B2A RID: 2858 RVA: 0x00007806 File Offset: 0x00005A06
		internal virtual MyCard PanEncode { get; set; }

		// Token: 0x1700019C RID: 412
		// (get) Token: 0x06000B2B RID: 2859 RVA: 0x0000780F File Offset: 0x00005A0F
		// (set) Token: 0x06000B2C RID: 2860 RVA: 0x00007817 File Offset: 0x00005A17
		internal virtual MyTextBox txStr { get; set; }

		// Token: 0x1700019D RID: 413
		// (get) Token: 0x06000B2D RID: 2861 RVA: 0x00007820 File Offset: 0x00005A20
		// (set) Token: 0x06000B2E RID: 2862 RVA: 0x00007828 File Offset: 0x00005A28
		internal virtual MyTextBox txKey { get; set; }

		// Token: 0x1700019E RID: 414
		// (get) Token: 0x06000B2F RID: 2863 RVA: 0x00007831 File Offset: 0x00005A31
		// (set) Token: 0x06000B30 RID: 2864 RVA: 0x00007839 File Offset: 0x00005A39
		internal virtual MyButton btnSerAdd { get; set; }

		// Token: 0x1700019F RID: 415
		// (get) Token: 0x06000B31 RID: 2865 RVA: 0x00007842 File Offset: 0x00005A42
		// (set) Token: 0x06000B32 RID: 2866 RVA: 0x0000784A File Offset: 0x00005A4A
		internal virtual MyButton btnSerRemove { get; set; }

		// Token: 0x170001A0 RID: 416
		// (get) Token: 0x06000B33 RID: 2867 RVA: 0x00007853 File Offset: 0x00005A53
		// (set) Token: 0x06000B34 RID: 2868 RVA: 0x0000785B File Offset: 0x00005A5B
		internal virtual MyTextBox txResult { get; set; }

		// Token: 0x06000B35 RID: 2869 RVA: 0x0005A0E8 File Offset: 0x000582E8
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_ProcTag)
			{
				this.m_ProcTag = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pageother/pageothertest.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000B36 RID: 2870 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000B37 RID: 2871 RVA: 0x0005A118 File Offset: 0x00058318
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.CardCave = (MyCard)target;
				return;
			}
			if (connectionId == 2)
			{
				this.LabCave = (TextBlock)target;
				return;
			}
			if (connectionId == 3)
			{
				this.BtnCave = (MyTextButton)target;
				return;
			}
			if (connectionId == 4)
			{
				this.BtnJrrp = (MyButton)target;
				return;
			}
			if (connectionId == 5)
			{
				this.BtnClick = (MyButton)target;
				return;
			}
			if (connectionId == 6)
			{
				this.TextDownloadUrl = (MyTextBox)target;
				return;
			}
			if (connectionId == 7)
			{
				this.TextDownloadFolder = (MyTextBox)target;
				return;
			}
			if (connectionId == 8)
			{
				this.BtnDownloadSelect = (MyTextButton)target;
				return;
			}
			if (connectionId == 9)
			{
				this.BtnDownloadStart = (MyButton)target;
				return;
			}
			if (connectionId == 10)
			{
				this.BtnDownloadOpen = (MyButton)target;
				return;
			}
			if (connectionId == 11)
			{
				this.PanEncode = (MyCard)target;
				return;
			}
			if (connectionId == 12)
			{
				this.txStr = (MyTextBox)target;
				return;
			}
			if (connectionId == 13)
			{
				this.txKey = (MyTextBox)target;
				return;
			}
			if (connectionId == 14)
			{
				this.btnSerAdd = (MyButton)target;
				return;
			}
			if (connectionId == 15)
			{
				this.btnSerRemove = (MyButton)target;
				return;
			}
			if (connectionId == 16)
			{
				this.txResult = (MyTextBox)target;
				return;
			}
			this.m_ProcTag = true;
		}

		// Token: 0x040005CE RID: 1486
		private bool listTag;

		// Token: 0x040005CF RID: 1487
		private bool methodTag;

		// Token: 0x040005D0 RID: 1488
		[CompilerGenerated]
		[AccessedThroughProperty("CardCave")]
		private MyCard _AnnotationTag;

		// Token: 0x040005D1 RID: 1489
		[CompilerGenerated]
		[AccessedThroughProperty("LabCave")]
		private TextBlock interceptorTag;

		// Token: 0x040005D2 RID: 1490
		[CompilerGenerated]
		[AccessedThroughProperty("BtnCave")]
		private MyTextButton m_RefTag;

		// Token: 0x040005D3 RID: 1491
		[CompilerGenerated]
		[AccessedThroughProperty("BtnJrrp")]
		private MyButton serverTag;

		// Token: 0x040005D4 RID: 1492
		[CompilerGenerated]
		[AccessedThroughProperty("BtnClick")]
		private MyButton serviceTag;

		// Token: 0x040005D5 RID: 1493
		[AccessedThroughProperty("TextDownloadUrl")]
		[CompilerGenerated]
		private MyTextBox m_ImporterTag;

		// Token: 0x040005D6 RID: 1494
		[AccessedThroughProperty("TextDownloadFolder")]
		[CompilerGenerated]
		private MyTextBox proxyTag;

		// Token: 0x040005D7 RID: 1495
		[AccessedThroughProperty("BtnDownloadSelect")]
		[CompilerGenerated]
		private MyTextButton m_ClassTag;

		// Token: 0x040005D8 RID: 1496
		[CompilerGenerated]
		[AccessedThroughProperty("BtnDownloadStart")]
		private MyButton m_RegistryTag;

		// Token: 0x040005D9 RID: 1497
		[AccessedThroughProperty("BtnDownloadOpen")]
		[CompilerGenerated]
		private MyButton _ProducerTag;

		// Token: 0x040005DA RID: 1498
		[AccessedThroughProperty("PanEncode")]
		[CompilerGenerated]
		private MyCard m_CandidateTag;

		// Token: 0x040005DB RID: 1499
		[AccessedThroughProperty("txStr")]
		[CompilerGenerated]
		private MyTextBox setterTag;

		// Token: 0x040005DC RID: 1500
		[CompilerGenerated]
		[AccessedThroughProperty("txKey")]
		private MyTextBox _MappingTag;

		// Token: 0x040005DD RID: 1501
		[CompilerGenerated]
		[AccessedThroughProperty("btnSerAdd")]
		private MyButton dispatcherTag;

		// Token: 0x040005DE RID: 1502
		[AccessedThroughProperty("btnSerRemove")]
		[CompilerGenerated]
		private MyButton m_MessageTag;

		// Token: 0x040005DF RID: 1503
		[CompilerGenerated]
		[AccessedThroughProperty("txResult")]
		private MyTextBox statusTag;

		// Token: 0x040005E0 RID: 1504
		private bool m_ProcTag;
	}
}
