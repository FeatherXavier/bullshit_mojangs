﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic.FileIO;
using PCL.My;

namespace PCL
{
	// Token: 0x020000BD RID: 189
	[DesignerGenerated]
	public class PageVersionMod : MyPageRight, IComponentConnector
	{
		// Token: 0x0600071C RID: 1820 RVA: 0x00005BDB File Offset: 0x00003DDB
		public PageVersionMod()
		{
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.PageOther_Loaded();
			};
			base.Initialized += delegate(object sender, EventArgs e)
			{
				this.LoaderInit();
			};
			this._RoleResolver = false;
			this.InitializeComponent();
		}

		// Token: 0x0600071D RID: 1821 RVA: 0x00005C15 File Offset: 0x00003E15
		public void PageOther_Loaded()
		{
			this.PanBack.ScrollToHome();
			this.RefreshList(false);
			if (!this._RoleResolver)
			{
				this._RoleResolver = true;
			}
		}

		// Token: 0x0600071E RID: 1822 RVA: 0x00031F28 File Offset: 0x00030128
		public void RefreshList(bool ForceReload = false)
		{
			if (ModMinecraft.schemaTag.State != ModBase.LoadState.Loading && ModLoader.LoaderFolderRun(ModMinecraft.schemaTag, PageVersionLeft.m_AlgoResolver.CreateComparator() + "mods\\", ForceReload ? ModLoader.LoaderFolderRunType.ForceRun : ModLoader.LoaderFolderRunType.RunOnUpdated, 0, "", false))
			{
				this.PanBack.ScrollToHome();
				this.SearchBox.Text = "";
			}
		}

		// Token: 0x0600071F RID: 1823 RVA: 0x00031F8C File Offset: 0x0003018C
		private void LoaderInit()
		{
			base.PageLoaderInit(this.Load, this.PanLoad, this.PanAllBack, null, ModMinecraft.schemaTag, delegate(ModLoader.LoaderBase a0)
			{
				this.Load_Finish((ModLoader.LoaderTask<string, List<ModMinecraft.McMod>>)a0);
			}, null, false);
		}

		// Token: 0x06000720 RID: 1824 RVA: 0x00005C38 File Offset: 0x00003E38
		private void Load_Click(object sender, MouseButtonEventArgs e)
		{
			if (ModMinecraft.schemaTag.State == ModBase.LoadState.Failed)
			{
				ModLoader.LoaderFolderRun(ModMinecraft.schemaTag, PageVersionLeft.m_AlgoResolver.CreateComparator() + "mods\\", ModLoader.LoaderFolderRunType.ForceRun, 0, "", false);
			}
		}

		// Token: 0x06000721 RID: 1825 RVA: 0x00031FC8 File Offset: 0x000301C8
		private void Load_Finish(ModLoader.LoaderTask<string, List<ModMinecraft.McMod>> Loader)
		{
			List<ModMinecraft.McMod> output = Loader.Output;
			try
			{
				this.PanList.Children.Clear();
				if (output.Count == 0)
				{
					this.PanEmpty.Visibility = Visibility.Visible;
					this.PanBack.Visibility = Visibility.Collapsed;
				}
				else
				{
					this.PanBack.Visibility = Visibility.Visible;
					this.PanEmpty.Visibility = Visibility.Collapsed;
					StackPanel stackPanel = new StackPanel
					{
						Margin = new Thickness(20.0, 40.0, 18.0, (double)((output.Count > 0) ? 20 : 0)),
						VerticalAlignment = VerticalAlignment.Top,
						RenderTransform = new TranslateTransform(0.0, 0.0)
					};
					try
					{
						foreach (ModMinecraft.McMod entry in output)
						{
							stackPanel.Children.Add(this.McModListItem(entry));
						}
					}
					finally
					{
						List<ModMinecraft.McMod>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
					MyCard myCard = new MyCard
					{
						Title = this.McModGetTitle(output),
						Margin = new Thickness(0.0, 0.0, 0.0, 15.0)
					};
					myCard.Children.Add(stackPanel);
					this.PanList.Children.Add(myCard);
					if (Conversions.ToBoolean(output.Count > 0 && Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("HintModDisable", null)))))
					{
						ModBase._ParamsState.Set("HintModDisable", true, false, null);
						ModMain.Hint("直接点击某个 Mod 项即可将它禁用！", ModMain.HintType.Info, true);
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "加载 Mod 列表 UI 失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000722 RID: 1826 RVA: 0x000321D4 File Offset: 0x000303D4
		private string McModGetTitle(List<ModMinecraft.McMod> List)
		{
			int[] array = new int[3];
			try
			{
				foreach (ModMinecraft.McMod mcMod in List)
				{
					int[] array2 = array;
					ModMinecraft.McMod.McModState state = mcMod.State;
					ref int ptr = ref array2[(int)state];
					array2[(int)state] = checked(ptr + 1);
				}
			}
			finally
			{
				List<ModMinecraft.McMod>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			string result;
			if (List.Count == 0)
			{
				result = "未找到任何 Mod";
			}
			else if (array[1] == 0 && array[2] == 0)
			{
				result = "Mod 列表（" + Conversions.ToString(array[0]) + "）";
			}
			else
			{
				List<string> list = new List<string>();
				if (array[0] > 0)
				{
					list.Add("启用 " + Conversions.ToString(array[0]));
				}
				if (array[1] > 0)
				{
					list.Add("禁用 " + Conversions.ToString(array[1]));
				}
				if (array[2] > 0)
				{
					list.Add("错误 " + Conversions.ToString(array[2]));
				}
				result = "Mod 列表（" + ModBase.Join(list, "，") + "）";
			}
			return result;
		}

		// Token: 0x06000723 RID: 1827 RVA: 0x000322F4 File Offset: 0x000304F4
		private MyListItem McModListItem(ModMinecraft.McMod Entry)
		{
			ModMinecraft.McMod.McModState state = Entry.State;
			string logo;
			if (state != ModMinecraft.McMod.McModState.Fine)
			{
				if (state != ModMinecraft.McMod.McModState.Disabled)
				{
					logo = "pack://application:,,,/images/Blocks/RedstoneBlock.png";
				}
				else
				{
					logo = "pack://application:,,,/images/Blocks/RedstoneLampOff.png";
				}
			}
			else
			{
				logo = "pack://application:,,,/images/Blocks/RedstoneLampOn.png";
			}
			string title;
			if (Entry.State == ModMinecraft.McMod.McModState.Disabled)
			{
				title = ModBase.GetFileNameWithoutExtentionFromPath(Entry.Path.Substring(0, checked(Entry.Path.Count<char>() - ".disabled".Count<char>()))) + "（已禁用）";
			}
			else
			{
				title = ModBase.GetFileNameWithoutExtentionFromPath(Entry.Path);
			}
			string info;
			if (Entry.Version != null && Entry.Description == null)
			{
				if (Entry.DefinePrototype())
				{
					info = Entry.Path;
				}
				else
				{
					info = "存在错误 : " + Entry.Path;
				}
			}
			else
			{
				info = Entry.Name + ((Entry.Version == null) ? "" : (" (" + Entry.Version + ")")) + " : " + (Entry.Description ?? Entry.Path);
			}
			return new MyListItem
			{
				Logo = logo,
				SnapsToDevicePixels = true,
				Title = title,
				Info = info,
				Height = 42.0,
				Type = MyListItem.CheckType.Clickable,
				Tag = Entry,
				PaddingRight = (Entry.DefinePrototype() ? 73 : 55),
				_ReponseRequest = new Action<MyListItem, EventArgs>(this.McModContent)
			};
		}

		// Token: 0x06000724 RID: 1828 RVA: 0x0003244C File Offset: 0x0003064C
		private void McModContent(MyListItem sender, EventArgs e)
		{
			ModMinecraft.McMod mcMod = (ModMinecraft.McMod)sender2.Tag;
			sender2.WriteResolver(delegate(object sender, MouseButtonEventArgs e)
			{
				this.Item_Click((MyListItem)sender, e);
			});
			MyIconButton myIconButton = new MyIconButton
			{
				LogoScale = 1.1,
				Logo = "M520.192 0C408.43 0 317.44 82.87 313.563 186.734H52.736c-29.038 0-52.663 21.943-52.663 49.079s23.625 49.152 52.663 49.152h58.075v550.473c0 103.35 75.118 187.757 167.717 187.757h472.43c92.599 0 167.716-83.894 167.716-187.757V285.477h52.59c29.038 0 52.59-21.943 52.663-49.08-0.073-27.135-23.625-49.151-52.663-49.151H726.235C723.237 83.017 631.955 0 520.192 0zM404.846 177.957c3.803-50.03 50.176-89.015 107.447-89.015 57.197 0 103.57 38.985 106.788 89.015H404.92zM284.379 933.669c-33.353 0-69.997-39.351-69.997-95.525v-549.01H833.39v549.522c0 56.247-36.645 95.525-69.998 95.525H284.379v-0.512z M357.23 800.695a48.274 48.274 0 0 0 47.616-49.006V471.7a48.274 48.274 0 0 0-47.543-49.08 48.274 48.274 0 0 0-47.69 49.006V751.69c0 27.282 20.846 49.006 47.617 49.006z m166.62 0a48.274 48.274 0 0 0 47.688-49.006V471.7a48.274 48.274 0 0 0-47.689-49.08 48.274 48.274 0 0 0-47.543 49.006V751.69c0 27.282 21.431 49.006 47.543 49.006z m142.92 0a48.274 48.274 0 0 0 47.543-49.006V471.7a48.274 48.274 0 0 0-47.543-49.08 48.274 48.274 0 0 0-47.616 49.006V751.69c0 27.282 20.773 49.006 47.543 49.006z",
				Tag = sender2
			};
			myIconButton.ToolTip = "删除";
			ToolTipService.SetPlacement(myIconButton, PlacementMode.Center);
			ToolTipService.SetVerticalOffset(myIconButton, 30.0);
			ToolTipService.SetHorizontalOffset(myIconButton, 2.0);
			myIconButton.Click += delegate(object sender, EventArgs e)
			{
				this.Delete_Click((MyIconButton)sender, e);
			};
			MyIconButton myIconButton2 = new MyIconButton
			{
				LogoScale = 1.15,
				Logo = "M889.018182 418.909091H884.363636V316.509091a93.090909 93.090909 0 0 0-99.607272-89.832727h-302.545455l-93.090909-76.334546A46.545455 46.545455 0 0 0 358.865455 139.636364H146.152727A93.090909 93.090909 0 0 0 46.545455 229.469091V837.818182a46.545455 46.545455 0 0 0 46.545454 46.545454 46.545455 46.545455 0 0 0 16.756364-3.258181 109.381818 109.381818 0 0 0 25.134545 3.258181h586.472727a85.178182 85.178182 0 0 0 87.04-63.301818l163.374546-302.545454a46.545455 46.545455 0 0 0 5.585454-21.876364A82.385455 82.385455 0 0 0 889.018182 418.909091z m-744.727273-186.181818h198.283636l93.09091 76.334545a46.545455 46.545455 0 0 0 29.323636 10.705455h319.301818a12.101818 12.101818 0 0 1 6.516364 0V418.909091H302.545455a85.178182 85.178182 0 0 0-87.04 63.301818L139.636364 622.778182V232.727273a19.549091 19.549091 0 0 1 6.516363 0z m578.094546 552.029091a27.461818 27.461818 0 0 0-2.792728 6.516363H154.530909l147.083636-272.290909a27.461818 27.461818 0 0 0 2.792728-6.981818h565.061818z",
				Tag = sender2
			};
			myIconButton2.ToolTip = "打开文件位置";
			ToolTipService.SetPlacement(myIconButton2, PlacementMode.Center);
			ToolTipService.SetVerticalOffset(myIconButton2, 30.0);
			ToolTipService.SetHorizontalOffset(myIconButton2, 2.0);
			myIconButton2.Click += delegate(object sender, EventArgs e)
			{
				this.Open_Click((MyIconButton)sender, e);
			};
			if (mcMod.DefinePrototype())
			{
				MyIconButton myIconButton3 = new MyIconButton
				{
					LogoScale = 1.05,
					Logo = "M512 917.333333c223.861333 0 405.333333-181.472 405.333333-405.333333S735.861333 106.666667 512 106.666667 106.666667 288.138667 106.666667 512s181.472 405.333333 405.333333 405.333333z m0 106.666667C229.226667 1024 0 794.773333 0 512S229.226667 0 512 0s512 229.226667 512 512-229.226667 512-512 512z m-32-597.333333h64a21.333333 21.333333 0 0 1 21.333333 21.333333v320a21.333333 21.333333 0 0 1-21.333333 21.333333h-64a21.333333 21.333333 0 0 1-21.333333-21.333333V448a21.333333 21.333333 0 0 1 21.333333-21.333333z m0-192h64a21.333333 21.333333 0 0 1 21.333333 21.333333v64a21.333333 21.333333 0 0 1-21.333333 21.333333h-64a21.333333 21.333333 0 0 1-21.333333-21.333333v-64a21.333333 21.333333 0 0 1 21.333333-21.333333z",
					Tag = sender2
				};
				myIconButton3.ToolTip = "详情";
				ToolTipService.SetPlacement(myIconButton3, PlacementMode.Center);
				ToolTipService.SetVerticalOffset(myIconButton3, 30.0);
				ToolTipService.SetHorizontalOffset(myIconButton3, 2.0);
				myIconButton3.Click += this.Info_Click;
				sender2.MouseRightButtonDown += new MouseButtonEventHandler(this.Info_Click);
				sender2.Buttons = new MyIconButton[]
				{
					myIconButton3,
					myIconButton2,
					myIconButton
				};
				return;
			}
			sender2.Buttons = new MyIconButton[]
			{
				myIconButton2,
				myIconButton
			};
		}

		// Token: 0x06000725 RID: 1829 RVA: 0x000325FC File Offset: 0x000307FC
		private void BtnManageOpen_Click(object sender, EventArgs e)
		{
			try
			{
				Directory.CreateDirectory(PageVersionLeft.m_AlgoResolver.CreateComparator() + "mods\\");
				ModBase.OpenExplorer("\"" + PageVersionLeft.m_AlgoResolver.CreateComparator() + "mods\\\"");
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "打开 Mods 文件夹失败", ModBase.LogLevel.Msgbox, "出现错误");
			}
		}

		// Token: 0x06000726 RID: 1830 RVA: 0x00032674 File Offset: 0x00030874
		private void BtnManageChange_Click(MyButton sender, EventArgs e)
		{
			bool flag = true;
			try
			{
				bool flag2 = sender.Text.Contains("禁用");
				try
				{
					foreach (ModMinecraft.McMod mcMod in ModMinecraft.schemaTag.Output)
					{
						string text;
						if (mcMod.State == ModMinecraft.McMod.McModState.Fine && flag2)
						{
							text = mcMod.Path + ".disabled";
						}
						else
						{
							if (mcMod.State != ModMinecraft.McMod.McModState.Disabled || flag2)
							{
								continue;
							}
							text = mcMod.Path.Substring(0, checked(mcMod.Path.Count<char>() - ".disabled".Count<char>()));
						}
						try
						{
							if (!File.Exists(mcMod.Path))
							{
								throw new FileNotFoundException("未找到文件：" + mcMod.Path);
							}
							File.Delete(text);
							Microsoft.VisualBasic.FileSystem.Rename(mcMod.Path, text);
						}
						catch (Exception ex)
						{
							ModBase.Log(ex, "全局状态改变中重命名 Mod 失败", ModBase.LogLevel.Debug, "出现错误");
							flag = false;
						}
					}
				}
				finally
				{
					List<ModMinecraft.McMod>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
			}
			catch (Exception ex2)
			{
				ModBase.Log(ex2, "改变全部 Mod 状态失败", ModBase.LogLevel.Msgbox, "出现错误");
				flag = false;
			}
			finally
			{
				if (!flag)
				{
					ModMain.Hint("由于文件被占用，部分 Mod 的状态切换失败，请尝试关闭正在运行的游戏后再试！", ModMain.HintType.Critical, true);
				}
				this.RefreshList(false);
			}
		}

		// Token: 0x06000727 RID: 1831 RVA: 0x00032824 File Offset: 0x00030A24
		public void Item_Click(MyListItem sender, EventArgs e)
		{
			try
			{
				ModMinecraft.McMod mcMod = (ModMinecraft.McMod)sender.Tag;
				string text = null;
				switch (mcMod.State)
				{
				case ModMinecraft.McMod.McModState.Fine:
					if (mcMod.IsPresetMod() && ModMain.MyMsgBox("该 Mod 可能为其他 Mod 的前置，如果禁用可能导致其他 Mod 无法使用。\r\n你确定要继续禁用吗？", "警告", "禁用", "取消", "", false, true, false) == 2)
					{
						return;
					}
					text = mcMod.Path + ".disabled";
					break;
				case ModMinecraft.McMod.McModState.Disabled:
					text = mcMod.Path.Substring(0, checked(mcMod.Path.Count<char>() - ".disabled".Count<char>()));
					break;
				case ModMinecraft.McMod.McModState.Unavaliable:
					ModMain.MyMsgBox("无法读取此 Mod 的信息。\r\n\r\n详细的错误信息：" + ModBase.GetString(mcMod.WritePrototype(), false, false), "Mod 读取失败", "确定", "", "", false, true, false);
					return;
				}
				try
				{
					File.Delete(text);
					Microsoft.VisualBasic.FileSystem.Rename(mcMod.Path, text);
				}
				catch (FileNotFoundException ex)
				{
					ModBase.Log(ex, "未找到理应存在的 Mod 文件（" + mcMod.Path + "）", ModBase.LogLevel.Debug, "出现错误");
					Microsoft.VisualBasic.FileSystem.Rename(text, mcMod.Path);
				}
				ModMinecraft.McMod mcMod2 = new ModMinecraft.McMod(text);
				int index = ModMinecraft.schemaTag.Output.IndexOf(mcMod);
				ModMinecraft.schemaTag.Output.RemoveAt(index);
				ModMinecraft.schemaTag.Output.Insert(index, mcMod2);
				StackPanel stackPanel = (StackPanel)sender.Parent;
				int index2 = stackPanel.Children.IndexOf(sender);
				stackPanel.Children.RemoveAt(index2);
				stackPanel.Children.Insert(index2, this.McModListItem(mcMod2));
				if (string.IsNullOrWhiteSpace(this.SearchBox.Text))
				{
					((MyCard)stackPanel.Parent).Title = this.McModGetTitle(ModMinecraft.schemaTag.Output);
					ModLoader.LoaderFolderRun(ModMinecraft.schemaTag, PageVersionLeft.m_AlgoResolver.CreateComparator() + "mods\\", ModLoader.LoaderFolderRunType.UpdateOnly, 0, "", false);
				}
			}
			catch (Exception ex2)
			{
				ModBase.Log(ex2, "单个状态改变中重命名 Mod 失败", ModBase.LogLevel.Debug, "出现错误");
				ModMain.Hint("切换 Mod 状态失败，请尝试关闭正在运行的游戏后再试！", ModMain.HintType.Info, true);
			}
		}

		// Token: 0x06000728 RID: 1832 RVA: 0x00032A84 File Offset: 0x00030C84
		public void Delete_Click(MyIconButton sender, EventArgs e)
		{
			try
			{
				MyListItem myListItem = (MyListItem)sender.Tag;
				ModMinecraft.McMod mcMod = (ModMinecraft.McMod)myListItem.Tag;
				if (!mcMod.IsPresetMod() || ModMain.MyMsgBox("该 Mod 可能为其他 Mod 的前置，如果删除可能导致其他 Mod 无法使用。\r\n你确定要继续删除吗？", "警告", "删除", "取消", "", true, true, false) != 2)
				{
					if (File.Exists(mcMod.Path))
					{
						MyWpfExtension.FindModel().FileSystem.DeleteFile(mcMod.Path, UIOption.OnlyErrorDialogs, RecycleOption.SendToRecycleBin);
						ModMinecraft.schemaTag.Output.Remove(mcMod);
						StackPanel stackPanel = (StackPanel)myListItem.Parent;
						stackPanel.Children.Remove(myListItem);
						if (stackPanel.Children.Count == 0)
						{
							this.RefreshList(true);
						}
						else
						{
							((MyCard)stackPanel.Parent).Title = this.McModGetTitle(ModMinecraft.schemaTag.Output);
						}
						ModMain.Hint("已将 " + mcMod.GetPrototype() + " 删除到回收站！", ModMain.HintType.Finish, true);
						ModLoader.LoaderFolderRun(ModMinecraft.schemaTag, PageVersionLeft.m_AlgoResolver.CreateComparator() + "mods\\", ModLoader.LoaderFolderRunType.UpdateOnly, 0, "", false);
					}
					else
					{
						ModBase.Log("[System] 需要删除的 Mod 文件不存在（" + mcMod.Path + "）", ModBase.LogLevel.Hint, "出现错误");
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "删除 Mod 失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000729 RID: 1833 RVA: 0x00032C04 File Offset: 0x00030E04
		public void Info_Click(object sender, EventArgs e)
		{
			checked
			{
				try
				{
					ModMinecraft.McMod mcMod = (ModMinecraft.McMod)((MyListItem)((sender is MyIconButton) ? NewLateBinding.LateGet(sender, null, "Tag", new object[0], null, null, null) : sender)).Tag;
					List<string> list = new List<string>();
					if (mcMod.Description != null)
					{
						list.Add(mcMod.Description + "\r\n");
					}
					if (mcMod.LogoutPrototype() != null)
					{
						list.Add("作者：" + mcMod.LogoutPrototype());
					}
					list.Add(string.Concat(new string[]
					{
						"文件：",
						mcMod.GetPrototype(),
						"（",
						ModBase.GetString(new FileInfo(mcMod.Path).Length),
						"）"
					}));
					if (mcMod.Version != null)
					{
						list.Add("版本：" + mcMod.Version);
					}
					if (ModBase._EventState)
					{
						List<string> list2 = new List<string>();
						if (mcMod.PublishPrototype() != null)
						{
							list2.Add("Mod ID：" + mcMod.PublishPrototype());
						}
						if (mcMod.ForgotPrototype().Count > 0)
						{
							list2.Add("依赖于：");
							try
							{
								foreach (KeyValuePair<string, string> keyValuePair in mcMod.ForgotPrototype())
								{
									list2.Add(" - " + keyValuePair.Key + ((keyValuePair.Value == null) ? "" : ("，版本：" + keyValuePair.Value)));
								}
							}
							finally
							{
								Dictionary<string, string>.Enumerator enumerator;
								((IDisposable)enumerator).Dispose();
							}
						}
						if (list2.Count > 0)
						{
							list.Add("\r\n—————— 调试信息 ——————");
							list.AddRange(list2);
						}
					}
					string text = mcMod.Name.Replace(" ", "+");
					string text2 = text.Substring(0, 1);
					int num = text.Count<char>() - 1;
					for (int i = 1; i <= num; i++)
					{
						bool flag = text[i - 1].ToString().ToLower().Equals(text[i - 1].ToString());
						bool flag2 = text[i].ToString().ToLower().Equals(text[i].ToString());
						if (flag && !flag2)
						{
							text2 += "+";
						}
						text2 += Conversions.ToString(text[i]);
					}
					text2 = text2.Replace("++", "+").Replace("pti+Fine", "ptiFine");
					if (mcMod.InsertPrototype() == null)
					{
						if (ModMain.MyMsgBox(ModBase.Join(list, "\r\n"), mcMod.Name, "确定", "百科搜索", "", false, true, false) == 2)
						{
							ModBase.OpenWebsite("https://www.mcmod.cn/s?key=" + text2 + "&site=all&filter=0");
						}
					}
					else
					{
						int num2 = ModMain.MyMsgBox(ModBase.Join(list, "\r\n"), mcMod.Name, "确定", "百科搜索", "打开官网", false, true, false);
						if (num2 != 2)
						{
							if (num2 == 3)
							{
								ModBase.OpenWebsite(mcMod.InsertPrototype());
							}
						}
						else
						{
							ModBase.OpenWebsite("https://www.mcmod.cn/s?key=" + text2 + "&site=all&filter=0");
						}
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "获取 Mod 详情失败", ModBase.LogLevel.Feedback, "出现错误");
				}
			}
		}

		// Token: 0x0600072A RID: 1834 RVA: 0x00032F9C File Offset: 0x0003119C
		public void Open_Click(MyIconButton sender, EventArgs e)
		{
			try
			{
				ModMinecraft.McMod mcMod = (ModMinecraft.McMod)((MyListItem)sender.Tag).Tag;
				ModBase.OpenExplorer("/select,\"" + mcMod.Path + "\"");
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "打开 Mod 文件位置失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x0600072B RID: 1835 RVA: 0x0003300C File Offset: 0x0003120C
		public void SearchRun()
		{
			if (string.IsNullOrWhiteSpace(this.SearchBox.Text))
			{
				ModLoader.LoaderFolderRun(ModMinecraft.schemaTag, PageVersionLeft.m_AlgoResolver.CreateComparator() + "mods\\", ModLoader.LoaderFolderRunType.RunOnUpdated, 0, "", false);
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaOpacity(this.PanSearch, -this.PanSearch.Opacity, 100, 0, null, false),
					ModAnimation.AaCode(delegate
					{
						this.PanSearch.Height = 0.0;
						this.PanSearch.Visibility = Visibility.Collapsed;
						this.PanList.Visibility = Visibility.Visible;
						this.PanManage.Visibility = Visibility.Visible;
					}, 0, true),
					ModAnimation.AaOpacity(this.PanList, 1.0 - this.PanList.Opacity, 150, 30, null, false),
					ModAnimation.AaOpacity(this.PanManage, 1.0 - this.PanManage.Opacity, 150, 30, null, false)
				}, "FrmVersionMod Search Switch", false);
				return;
			}
			List<ModBase.SearchEntry<ModMinecraft.McMod>> list = new List<ModBase.SearchEntry<ModMinecraft.McMod>>();
			try
			{
				foreach (ModMinecraft.McMod mcMod in ModMinecraft.schemaTag.Output)
				{
					list.Add(new ModBase.SearchEntry<ModMinecraft.McMod>
					{
						interceptorParameter = mcMod,
						m_RefParameter = new List<KeyValuePair<string, double>>
						{
							new KeyValuePair<string, double>(mcMod.Name, 1.0),
							new KeyValuePair<string, double>(mcMod.GetPrototype(), 1.0),
							new KeyValuePair<string, double>(mcMod.Description ?? "", 0.5)
						}
					});
				}
			}
			finally
			{
				List<ModMinecraft.McMod>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			List<ModBase.SearchEntry<ModMinecraft.McMod>> list2 = ModBase.Search<ModMinecraft.McMod>(list, this.SearchBox.Text, 5, 0.35);
			this.PanSearchList.Children.Clear();
			if (list2.Count == 0)
			{
				this.PanSearch.Title = "无搜索结果";
				this.PanSearchList.Visibility = Visibility.Collapsed;
			}
			else
			{
				this.PanSearch.Title = "搜索结果";
				try
				{
					foreach (ModBase.SearchEntry<ModMinecraft.McMod> searchEntry in list2)
					{
						MyListItem myListItem = this.McModListItem(searchEntry.interceptorParameter);
						if (ModBase._EventState)
						{
							myListItem.Info = string.Concat(new string[]
							{
								searchEntry.serviceParameter ? "完全匹配，" : "",
								"相似度：",
								Conversions.ToString(Math.Round(searchEntry.serverParameter, 3)),
								"，",
								myListItem.Info
							});
						}
						this.PanSearchList.Children.Add(myListItem);
					}
				}
				finally
				{
					List<ModBase.SearchEntry<ModMinecraft.McMod>>.Enumerator enumerator2;
					((IDisposable)enumerator2).Dispose();
				}
				this.PanSearchList.Visibility = Visibility.Visible;
			}
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaOpacity(this.PanList, -this.PanList.Opacity, 100, 0, null, false),
				ModAnimation.AaOpacity(this.PanManage, -this.PanManage.Opacity, 100, 0, null, false),
				ModAnimation.AaCode(delegate
				{
					this.PanList.Visibility = Visibility.Collapsed;
					this.PanManage.Visibility = Visibility.Collapsed;
					this.PanSearch.Visibility = Visibility.Visible;
					this.PanSearch.TriggerForceResize();
				}, 0, true),
				ModAnimation.AaOpacity(this.PanSearch, 1.0 - this.PanSearch.Opacity, 150, 30, null, false)
			}, "FrmVersionMod Search Switch", false);
		}

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x0600072C RID: 1836 RVA: 0x00005C6E File Offset: 0x00003E6E
		// (set) Token: 0x0600072D RID: 1837 RVA: 0x00005C76 File Offset: 0x00003E76
		internal virtual Grid PanAllBack { get; set; }

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x0600072E RID: 1838 RVA: 0x00005C7F File Offset: 0x00003E7F
		// (set) Token: 0x0600072F RID: 1839 RVA: 0x00005C87 File Offset: 0x00003E87
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x06000730 RID: 1840 RVA: 0x00005C90 File Offset: 0x00003E90
		// (set) Token: 0x06000731 RID: 1841 RVA: 0x00005C98 File Offset: 0x00003E98
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x06000732 RID: 1842 RVA: 0x00005CA1 File Offset: 0x00003EA1
		// (set) Token: 0x06000733 RID: 1843 RVA: 0x00033398 File Offset: 0x00031598
		internal virtual MySearchBox SearchBox
		{
			[CompilerGenerated]
			get
			{
				return this._HelperResolver;
			}
			[CompilerGenerated]
			set
			{
				MySearchBox.TextChangedEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.SearchRun();
				};
				MySearchBox helperResolver = this._HelperResolver;
				if (helperResolver != null)
				{
					helperResolver.PushWrapper(obj);
				}
				this._HelperResolver = value;
				helperResolver = this._HelperResolver;
				if (helperResolver != null)
				{
					helperResolver.RunWrapper(obj);
				}
			}
		}

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x06000734 RID: 1844 RVA: 0x00005CA9 File Offset: 0x00003EA9
		// (set) Token: 0x06000735 RID: 1845 RVA: 0x00005CB1 File Offset: 0x00003EB1
		internal virtual MyCard PanManage { get; set; }

		// Token: 0x17000105 RID: 261
		// (get) Token: 0x06000736 RID: 1846 RVA: 0x00005CBA File Offset: 0x00003EBA
		// (set) Token: 0x06000737 RID: 1847 RVA: 0x000333DC File Offset: 0x000315DC
		internal virtual MyButton BtnManageOpen
		{
			[CompilerGenerated]
			get
			{
				return this.baseResolver;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnManageOpen_Click);
				MyButton myButton = this.baseResolver;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.baseResolver = value;
				myButton = this.baseResolver;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000106 RID: 262
		// (get) Token: 0x06000738 RID: 1848 RVA: 0x00005CC2 File Offset: 0x00003EC2
		// (set) Token: 0x06000739 RID: 1849 RVA: 0x00033420 File Offset: 0x00031620
		internal virtual MyButton BtnManageEnabled
		{
			[CompilerGenerated]
			get
			{
				return this._ProductResolver;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.BtnManageChange_Click((MyButton)sender, e);
				};
				MyButton productResolver = this._ProductResolver;
				if (productResolver != null)
				{
					productResolver.RevertResolver(obj);
				}
				this._ProductResolver = value;
				productResolver = this._ProductResolver;
				if (productResolver != null)
				{
					productResolver.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000107 RID: 263
		// (get) Token: 0x0600073A RID: 1850 RVA: 0x00005CCA File Offset: 0x00003ECA
		// (set) Token: 0x0600073B RID: 1851 RVA: 0x00033464 File Offset: 0x00031664
		internal virtual MyButton BtnManageDisabled
		{
			[CompilerGenerated]
			get
			{
				return this.attrResolver;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.BtnManageChange_Click((MyButton)sender, e);
				};
				MyButton myButton = this.attrResolver;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.attrResolver = value;
				myButton = this.attrResolver;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000108 RID: 264
		// (get) Token: 0x0600073C RID: 1852 RVA: 0x00005CD2 File Offset: 0x00003ED2
		// (set) Token: 0x0600073D RID: 1853 RVA: 0x00005CDA File Offset: 0x00003EDA
		internal virtual MyButton BtnManageCheck { get; set; }

		// Token: 0x17000109 RID: 265
		// (get) Token: 0x0600073E RID: 1854 RVA: 0x00005CE3 File Offset: 0x00003EE3
		// (set) Token: 0x0600073F RID: 1855 RVA: 0x00005CEB File Offset: 0x00003EEB
		internal virtual MyCard PanSearch { get; set; }

		// Token: 0x1700010A RID: 266
		// (get) Token: 0x06000740 RID: 1856 RVA: 0x00005CF4 File Offset: 0x00003EF4
		// (set) Token: 0x06000741 RID: 1857 RVA: 0x00005CFC File Offset: 0x00003EFC
		internal virtual StackPanel PanSearchList { get; set; }

		// Token: 0x1700010B RID: 267
		// (get) Token: 0x06000742 RID: 1858 RVA: 0x00005D05 File Offset: 0x00003F05
		// (set) Token: 0x06000743 RID: 1859 RVA: 0x00005D0D File Offset: 0x00003F0D
		internal virtual StackPanel PanList { get; set; }

		// Token: 0x1700010C RID: 268
		// (get) Token: 0x06000744 RID: 1860 RVA: 0x00005D16 File Offset: 0x00003F16
		// (set) Token: 0x06000745 RID: 1861 RVA: 0x00005D1E File Offset: 0x00003F1E
		internal virtual MyCard PanEmpty { get; set; }

		// Token: 0x1700010D RID: 269
		// (get) Token: 0x06000746 RID: 1862 RVA: 0x00005D27 File Offset: 0x00003F27
		// (set) Token: 0x06000747 RID: 1863 RVA: 0x000334A8 File Offset: 0x000316A8
		internal virtual MyButton BtnHintOpen
		{
			[CompilerGenerated]
			get
			{
				return this.m_ExpressionResolver;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnManageOpen_Click);
				MyButton expressionResolver = this.m_ExpressionResolver;
				if (expressionResolver != null)
				{
					expressionResolver.RevertResolver(obj);
				}
				this.m_ExpressionResolver = value;
				expressionResolver = this.m_ExpressionResolver;
				if (expressionResolver != null)
				{
					expressionResolver.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700010E RID: 270
		// (get) Token: 0x06000748 RID: 1864 RVA: 0x00005D2F File Offset: 0x00003F2F
		// (set) Token: 0x06000749 RID: 1865 RVA: 0x00005D37 File Offset: 0x00003F37
		internal virtual MyCard PanLoad { get; set; }

		// Token: 0x1700010F RID: 271
		// (get) Token: 0x0600074A RID: 1866 RVA: 0x00005D40 File Offset: 0x00003F40
		// (set) Token: 0x0600074B RID: 1867 RVA: 0x000334EC File Offset: 0x000316EC
		internal virtual MyLoading Load
		{
			[CompilerGenerated]
			get
			{
				return this.listenerResolver;
			}
			[CompilerGenerated]
			set
			{
				MyLoading.ClickEventHandler obj = new MyLoading.ClickEventHandler(this.Load_Click);
				MyLoading myLoading = this.listenerResolver;
				if (myLoading != null)
				{
					myLoading.ReflectWrapper(obj);
				}
				this.listenerResolver = value;
				myLoading = this.listenerResolver;
				if (myLoading != null)
				{
					myLoading.PatchWrapper(obj);
				}
			}
		}

		// Token: 0x0600074C RID: 1868 RVA: 0x00033530 File Offset: 0x00031730
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this._IdentifierResolver)
			{
				this._IdentifierResolver = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pageversion/pageversionmod.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x0600074D RID: 1869 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600074E RID: 1870 RVA: 0x00033560 File Offset: 0x00031760
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanAllBack = (Grid)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 3)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			if (connectionId == 4)
			{
				this.SearchBox = (MySearchBox)target;
				return;
			}
			if (connectionId == 5)
			{
				this.PanManage = (MyCard)target;
				return;
			}
			if (connectionId == 6)
			{
				this.BtnManageOpen = (MyButton)target;
				return;
			}
			if (connectionId == 7)
			{
				this.BtnManageEnabled = (MyButton)target;
				return;
			}
			if (connectionId == 8)
			{
				this.BtnManageDisabled = (MyButton)target;
				return;
			}
			if (connectionId == 9)
			{
				this.BtnManageCheck = (MyButton)target;
				return;
			}
			if (connectionId == 10)
			{
				this.PanSearch = (MyCard)target;
				return;
			}
			if (connectionId == 11)
			{
				this.PanSearchList = (StackPanel)target;
				return;
			}
			if (connectionId == 12)
			{
				this.PanList = (StackPanel)target;
				return;
			}
			if (connectionId == 13)
			{
				this.PanEmpty = (MyCard)target;
				return;
			}
			if (connectionId == 14)
			{
				this.BtnHintOpen = (MyButton)target;
				return;
			}
			if (connectionId == 15)
			{
				this.PanLoad = (MyCard)target;
				return;
			}
			if (connectionId == 16)
			{
				this.Load = (MyLoading)target;
				return;
			}
			this._IdentifierResolver = true;
		}

		// Token: 0x0400033B RID: 827
		private bool _RoleResolver;

		// Token: 0x0400033C RID: 828
		[AccessedThroughProperty("PanAllBack")]
		[CompilerGenerated]
		private Grid _ValueResolver;

		// Token: 0x0400033D RID: 829
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyScrollViewer recordResolver;

		// Token: 0x0400033E RID: 830
		[AccessedThroughProperty("PanMain")]
		[CompilerGenerated]
		private StackPanel _VisitorResolver;

		// Token: 0x0400033F RID: 831
		[CompilerGenerated]
		[AccessedThroughProperty("SearchBox")]
		private MySearchBox _HelperResolver;

		// Token: 0x04000340 RID: 832
		[AccessedThroughProperty("PanManage")]
		[CompilerGenerated]
		private MyCard _ParamResolver;

		// Token: 0x04000341 RID: 833
		[AccessedThroughProperty("BtnManageOpen")]
		[CompilerGenerated]
		private MyButton baseResolver;

		// Token: 0x04000342 RID: 834
		[CompilerGenerated]
		[AccessedThroughProperty("BtnManageEnabled")]
		private MyButton _ProductResolver;

		// Token: 0x04000343 RID: 835
		[CompilerGenerated]
		[AccessedThroughProperty("BtnManageDisabled")]
		private MyButton attrResolver;

		// Token: 0x04000344 RID: 836
		[AccessedThroughProperty("BtnManageCheck")]
		[CompilerGenerated]
		private MyButton facadeResolver;

		// Token: 0x04000345 RID: 837
		[AccessedThroughProperty("PanSearch")]
		[CompilerGenerated]
		private MyCard _BridgeResolver;

		// Token: 0x04000346 RID: 838
		[AccessedThroughProperty("PanSearchList")]
		[CompilerGenerated]
		private StackPanel structResolver;

		// Token: 0x04000347 RID: 839
		[CompilerGenerated]
		[AccessedThroughProperty("PanList")]
		private StackPanel _IndexerResolver;

		// Token: 0x04000348 RID: 840
		[CompilerGenerated]
		[AccessedThroughProperty("PanEmpty")]
		private MyCard _TemplateResolver;

		// Token: 0x04000349 RID: 841
		[CompilerGenerated]
		[AccessedThroughProperty("BtnHintOpen")]
		private MyButton m_ExpressionResolver;

		// Token: 0x0400034A RID: 842
		[AccessedThroughProperty("PanLoad")]
		[CompilerGenerated]
		private MyCard getterResolver;

		// Token: 0x0400034B RID: 843
		[AccessedThroughProperty("Load")]
		[CompilerGenerated]
		private MyLoading listenerResolver;

		// Token: 0x0400034C RID: 844
		private bool _IdentifierResolver;
	}
}
