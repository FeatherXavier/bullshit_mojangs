﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.ApplicationServices;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic.Devices;
using Microsoft.VisualBasic.Logging;

namespace PCL.My
{
	// Token: 0x02000009 RID: 9
	[HideModuleName]
	[StandardModule]
	internal sealed class MyWpfExtension
	{
		// Token: 0x06000020 RID: 32 RVA: 0x000023F7 File Offset: 0x000005F7
		internal static Application FillModel()
		{
			return (Application)Application.Current;
		}

		// Token: 0x06000021 RID: 33 RVA: 0x00002403 File Offset: 0x00000603
		internal static Computer FindModel()
		{
			return MyWpfExtension.model.SetupComparator();
		}

		// Token: 0x06000022 RID: 34 RVA: 0x0000240F File Offset: 0x0000060F
		internal static User DestroyModel()
		{
			return MyWpfExtension.wrapper.SetupComparator();
		}

		// Token: 0x06000023 RID: 35 RVA: 0x0000241B File Offset: 0x0000061B
		internal static Log StopModel()
		{
			return MyWpfExtension.resolver.SetupComparator();
		}

		// Token: 0x06000024 RID: 36 RVA: 0x00002427 File Offset: 0x00000627
		internal static MyWpfExtension.MyWindows DisableModel()
		{
			return MyWpfExtension.repository.SetupComparator();
		}

		// Token: 0x04000002 RID: 2
		private static MyProject.ThreadSafeObjectProvider<Computer> model = new MyProject.ThreadSafeObjectProvider<Computer>();

		// Token: 0x04000003 RID: 3
		private static MyProject.ThreadSafeObjectProvider<User> wrapper = new MyProject.ThreadSafeObjectProvider<User>();

		// Token: 0x04000004 RID: 4
		private static MyProject.ThreadSafeObjectProvider<MyWpfExtension.MyWindows> repository = new MyProject.ThreadSafeObjectProvider<MyWpfExtension.MyWindows>();

		// Token: 0x04000005 RID: 5
		private static MyProject.ThreadSafeObjectProvider<Log> resolver = new MyProject.ThreadSafeObjectProvider<Log>();

		// Token: 0x0200000A RID: 10
		[EditorBrowsable(EditorBrowsableState.Never)]
		[MyGroupCollection("System.Windows.Window", "Create__Instance__", "Dispose__Instance__", "My.MyWpfExtenstionModule.Windows")]
		internal sealed class MyWindows
		{
			// Token: 0x06000025 RID: 37 RVA: 0x0000C258 File Offset: 0x0000A458
			private static T Create__Instance__<T>(T Instance) where T : Window, new()
			{
				T result;
				if (Instance == null)
				{
					if (MyWpfExtension.MyWindows.serializerState != null)
					{
						if (MyWpfExtension.MyWindows.serializerState.ContainsKey(typeof(T)))
						{
							throw new InvalidOperationException("The window cannot be accessed via My.Windows from the Window constructor.");
						}
					}
					else
					{
						MyWpfExtension.MyWindows.serializerState = new Hashtable();
					}
					MyWpfExtension.MyWindows.serializerState.Add(typeof(T), null);
					result = Activator.CreateInstance<T>();
				}
				else
				{
					result = Instance;
				}
				return result;
			}

			// Token: 0x06000026 RID: 38 RVA: 0x00002433 File Offset: 0x00000633
			private void Dispose__Instance__<T>(ref T instance) where T : Window
			{
				instance = default(T);
			}

			// Token: 0x06000027 RID: 39 RVA: 0x000023C1 File Offset: 0x000005C1
			[EditorBrowsable(EditorBrowsableState.Never)]
			public MyWindows()
			{
			}

			// Token: 0x06000028 RID: 40 RVA: 0x0000243C File Offset: 0x0000063C
			[EditorBrowsable(EditorBrowsableState.Never)]
			public override bool Equals(object o)
			{
				return base.Equals(RuntimeHelpers.GetObjectValue(o));
			}

			// Token: 0x06000029 RID: 41 RVA: 0x0000244A File Offset: 0x0000064A
			[EditorBrowsable(EditorBrowsableState.Never)]
			public override int GetHashCode()
			{
				return base.GetHashCode();
			}

			// Token: 0x0600002A RID: 42 RVA: 0x00002452 File Offset: 0x00000652
			[EditorBrowsable(EditorBrowsableState.Never)]
			internal new Type GetType()
			{
				return typeof(MyWpfExtension.MyWindows);
			}

			// Token: 0x0600002B RID: 43 RVA: 0x0000245F File Offset: 0x0000065F
			[EditorBrowsable(EditorBrowsableState.Never)]
			public override string ToString()
			{
				return base.ToString();
			}

			// Token: 0x0600002C RID: 44 RVA: 0x00002467 File Offset: 0x00000667
			public FormLoginOAuth ManageComparator()
			{
				this.roleState = MyWpfExtension.MyWindows.Create__Instance__<FormLoginOAuth>(this.roleState);
				return this.roleState;
			}

			// Token: 0x0600002D RID: 45 RVA: 0x00002480 File Offset: 0x00000680
			public FormMain StopComparator()
			{
				this._ValueState = MyWpfExtension.MyWindows.Create__Instance__<FormMain>(this._ValueState);
				return this._ValueState;
			}

			// Token: 0x0600002E RID: 46 RVA: 0x00002499 File Offset: 0x00000699
			public void DestroyComparator(FormLoginOAuth Value)
			{
				if (Value != this.roleState)
				{
					if (Value != null)
					{
						throw new ArgumentException("Property can only be set to Nothing");
					}
					this.Dispose__Instance__<FormLoginOAuth>(ref this.roleState);
				}
			}

			// Token: 0x0600002F RID: 47 RVA: 0x000024BE File Offset: 0x000006BE
			public void PopComparator(FormMain Value)
			{
				if (Value != this._ValueState)
				{
					if (Value != null)
					{
						throw new ArgumentException("Property can only be set to Nothing");
					}
					this.Dispose__Instance__<FormMain>(ref this._ValueState);
				}
			}

			// Token: 0x04000006 RID: 6
			[ThreadStatic]
			private static Hashtable serializerState;

			// Token: 0x04000007 RID: 7
			[EditorBrowsable(EditorBrowsableState.Never)]
			public FormLoginOAuth roleState;

			// Token: 0x04000008 RID: 8
			[EditorBrowsable(EditorBrowsableState.Never)]
			public FormMain _ValueState;
		}
	}
}
