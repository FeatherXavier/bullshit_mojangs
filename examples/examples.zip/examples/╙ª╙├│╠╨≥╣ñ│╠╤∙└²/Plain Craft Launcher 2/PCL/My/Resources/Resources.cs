﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL.My.Resources
{
	// Token: 0x0200000B RID: 11
	[StandardModule]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[HideModuleName]
	internal sealed class Resources
	{
		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000031 RID: 49 RVA: 0x000024E3 File Offset: 0x000006E3
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager TestModel
		{
			get
			{
				if (object.ReferenceEquals(Resources.m_Tag, null))
				{
					Resources.m_Tag = new ResourceManager("PCL.Resources", typeof(Resources).Assembly);
				}
				return Resources.m_Tag;
			}
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000032 RID: 50 RVA: 0x00002516 File Offset: 0x00000716
		// (set) Token: 0x06000033 RID: 51 RVA: 0x0000251D File Offset: 0x0000071D
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo SortModel
		{
			get
			{
				return Resources.comparator;
			}
			set
			{
				Resources.comparator = value;
			}
		}

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x06000034 RID: 52 RVA: 0x00002525 File Offset: 0x00000725
		internal static byte[] Custom
		{
			get
			{
				return (byte[])RuntimeHelpers.GetObjectValue(Resources.TestModel.GetObject("Custom", Resources.comparator));
			}
		}

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x06000035 RID: 53 RVA: 0x00002545 File Offset: 0x00000745
		internal static byte[] Dialogs
		{
			get
			{
				return (byte[])RuntimeHelpers.GetObjectValue(Resources.TestModel.GetObject("Dialogs", Resources.comparator));
			}
		}

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x06000036 RID: 54 RVA: 0x00002565 File Offset: 0x00000765
		internal static byte[] ForgeInstaller
		{
			get
			{
				return (byte[])RuntimeHelpers.GetObjectValue(Resources.TestModel.GetObject("ForgeInstaller", Resources.comparator));
			}
		}

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000037 RID: 55 RVA: 0x00002585 File Offset: 0x00000785
		internal static byte[] Help
		{
			get
			{
				return (byte[])RuntimeHelpers.GetObjectValue(Resources.TestModel.GetObject("Help", Resources.comparator));
			}
		}

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000038 RID: 56 RVA: 0x000025A5 File Offset: 0x000007A5
		internal static byte[] Json
		{
			get
			{
				return (byte[])RuntimeHelpers.GetObjectValue(Resources.TestModel.GetObject("Json", Resources.comparator));
			}
		}

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000039 RID: 57 RVA: 0x000025C5 File Offset: 0x000007C5
		internal static byte[] ModData
		{
			get
			{
				return (byte[])RuntimeHelpers.GetObjectValue(Resources.TestModel.GetObject("ModData", Resources.comparator));
			}
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x0600003A RID: 58 RVA: 0x000025E5 File Offset: 0x000007E5
		internal static byte[] NAudio
		{
			get
			{
				return (byte[])RuntimeHelpers.GetObjectValue(Resources.TestModel.GetObject("NAudio", Resources.comparator));
			}
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x0600003B RID: 59 RVA: 0x00002605 File Offset: 0x00000805
		internal static byte[] STUN
		{
			get
			{
				return (byte[])RuntimeHelpers.GetObjectValue(Resources.TestModel.GetObject("STUN", Resources.comparator));
			}
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x0600003C RID: 60 RVA: 0x00002625 File Offset: 0x00000825
		internal static byte[] Transformer
		{
			get
			{
				return (byte[])RuntimeHelpers.GetObjectValue(Resources.TestModel.GetObject("Transformer", Resources.comparator));
			}
		}

		// Token: 0x04000009 RID: 9
		private static ResourceManager m_Tag;

		// Token: 0x0400000A RID: 10
		private static CultureInfo comparator;
	}
}
