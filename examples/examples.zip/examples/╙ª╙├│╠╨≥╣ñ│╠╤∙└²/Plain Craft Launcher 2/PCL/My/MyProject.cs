﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL.My
{
	// Token: 0x02000007 RID: 7
	[HideModuleName]
	[StandardModule]
	[GeneratedCode("MyTemplate", "11.0.0.0")]
	internal sealed class MyProject
	{
		// Token: 0x02000008 RID: 8
		[EditorBrowsable(EditorBrowsableState.Never)]
		[ComVisible(false)]
		internal sealed class ThreadSafeObjectProvider<T> where T : new()
		{
			// Token: 0x0600001C RID: 28 RVA: 0x000023A4 File Offset: 0x000005A4
			internal T SetupComparator()
			{
				if (MyProject.ThreadSafeObjectProvider<T>.iteratorState == null)
				{
					MyProject.ThreadSafeObjectProvider<T>.iteratorState = Activator.CreateInstance<T>();
				}
				return MyProject.ThreadSafeObjectProvider<T>.iteratorState;
			}

			// Token: 0x0600001D RID: 29 RVA: 0x000023C1 File Offset: 0x000005C1
			[EditorBrowsable(EditorBrowsableState.Never)]
			public ThreadSafeObjectProvider()
			{
			}

			// Token: 0x04000001 RID: 1
			[ThreadStatic]
			[CompilerGenerated]
			private static T iteratorState;
		}
	}
}
