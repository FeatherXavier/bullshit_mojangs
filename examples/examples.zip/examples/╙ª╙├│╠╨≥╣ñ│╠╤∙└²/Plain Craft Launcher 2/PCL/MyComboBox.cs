﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000010 RID: 16
	public class MyComboBox : ComboBox
	{
		// Token: 0x0600004E RID: 78 RVA: 0x0000C2C0 File Offset: 0x0000A4C0
		public MyComboBox()
		{
			base.PreviewMouseLeftButtonDown += this.MyComboBox_PreviewMouseLeftButtonDown;
			base.PreviewMouseLeftButtonUp += new MouseButtonEventHandler(this.MyComboBox_PreviewMouseLeftButtonUp);
			base.MouseLeave += new MouseEventHandler(this.MyComboBox_PreviewMouseLeftButtonUp);
			base.IsEnabledChanged += delegate(object sender, DependencyPropertyChangedEventArgs e)
			{
				this.RefreshColor();
			};
			base.MouseEnter += delegate(object sender, MouseEventArgs e)
			{
				this.RefreshColor();
			};
			base.MouseLeave += delegate(object sender, MouseEventArgs e)
			{
				this.RefreshColor();
			};
			base.PreviewMouseLeftButtonDown += delegate(object sender, MouseButtonEventArgs e)
			{
				this.RefreshColor();
			};
			base.PreviewMouseLeftButtonUp += delegate(object sender, MouseButtonEventArgs e)
			{
				this.RefreshColor();
			};
			base.GotKeyboardFocus += delegate(object sender, KeyboardFocusChangedEventArgs e)
			{
				this.RefreshColor();
			};
			base.DropDownOpened += this.MyComboBox_DropDownOpened;
			base.DropDownClosed += this.MyComboBox_DropDownClosed;
			this.GetModel(new MyComboBox.TextChangedEventHandler(this.MyComboBox_TextChanged));
			this.issuer = ModBase.GetUuid();
			this.HintText = "";
			this.m_Account = Conversions.ToString(base.SelectedItem);
			this._Parameter = false;
			this.reponse = false;
		}

		// Token: 0x0600004F RID: 79 RVA: 0x0000C3E4 File Offset: 0x0000A5E4
		[CompilerGenerated]
		public void GetModel(MyComboBox.TextChangedEventHandler obj)
		{
			MyComboBox.TextChangedEventHandler textChangedEventHandler = this.m_Prototype;
			MyComboBox.TextChangedEventHandler textChangedEventHandler2;
			do
			{
				textChangedEventHandler2 = textChangedEventHandler;
				MyComboBox.TextChangedEventHandler value = (MyComboBox.TextChangedEventHandler)Delegate.Combine(textChangedEventHandler2, obj);
				textChangedEventHandler = Interlocked.CompareExchange<MyComboBox.TextChangedEventHandler>(ref this.m_Prototype, value, textChangedEventHandler2);
			}
			while (textChangedEventHandler != textChangedEventHandler2);
		}

		// Token: 0x06000050 RID: 80 RVA: 0x0000C41C File Offset: 0x0000A61C
		[CompilerGenerated]
		public void VisitModel(MyComboBox.TextChangedEventHandler obj)
		{
			MyComboBox.TextChangedEventHandler textChangedEventHandler = this.m_Prototype;
			MyComboBox.TextChangedEventHandler textChangedEventHandler2;
			do
			{
				textChangedEventHandler2 = textChangedEventHandler;
				MyComboBox.TextChangedEventHandler value = (MyComboBox.TextChangedEventHandler)Delegate.Remove(textChangedEventHandler2, obj);
				textChangedEventHandler = Interlocked.CompareExchange<MyComboBox.TextChangedEventHandler>(ref this.m_Prototype, value, textChangedEventHandler2);
			}
			while (textChangedEventHandler != textChangedEventHandler2);
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x06000051 RID: 81 RVA: 0x0000264C File Offset: 0x0000084C
		// (set) Token: 0x06000052 RID: 82 RVA: 0x00002654 File Offset: 0x00000854
		public string HintText { get; set; }

		// Token: 0x06000053 RID: 83 RVA: 0x0000C454 File Offset: 0x0000A654
		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();
			if (base.IsEditable)
			{
				try
				{
					this.TextBox = (MyTextBox)base.Template.FindName("PART_EditableTextBox", this);
					this.TextBox.AddHandler(UIElement.LostFocusEvent, new RoutedEventHandler(delegate(object sender, RoutedEventArgs e)
					{
						this.RefreshColor();
					}));
					this.TextBox.m_TaskWrapper.Add(delegate(object sender, RoutedEventArgs e)
					{
						MyComboBox.TextChangedEventHandler prototype2 = this.m_Prototype;
						if (prototype2 != null)
						{
							prototype2(RuntimeHelpers.GetObjectValue(sender), (TextChangedEventArgs)e);
						}
					});
					this.TextBox.Tag = RuntimeHelpers.GetObjectValue(base.Tag);
					if (Operators.CompareString(this.Text, "", true) == 0)
					{
						this.TextBox.Text = this.m_Account;
					}
					else
					{
						MyComboBox.TextChangedEventHandler prototype = this.m_Prototype;
						if (prototype != null)
						{
							prototype(this, null);
						}
					}
					if (this.HintText.Length > 0)
					{
						this.TextBox.HintText = this.HintText;
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "初始化可编辑文本框失败（" + base.Name + "）", ModBase.LogLevel.Feedback, "出现错误");
				}
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000054 RID: 84 RVA: 0x0000C578 File Offset: 0x0000A778
		// (set) Token: 0x06000055 RID: 85 RVA: 0x0000265D File Offset: 0x0000085D
		public new string Text
		{
			get
			{
				string result;
				if (base.IsEditable)
				{
					if (this.TextBox == null)
					{
						result = (this.m_Account ?? "");
					}
					else
					{
						result = (this.TextBox.Text ?? "");
					}
				}
				else
				{
					result = (base.SelectedItem ?? "").ToString();
				}
				return result;
			}
			set
			{
				if (!base.IsEditable)
				{
					throw new NotSupportedException("该 ComboBox 不支持修改文本。");
				}
				if (Information.IsNothing(this.TextBox))
				{
					this.m_Account = value;
					return;
				}
				this.TextBox.Text = value;
			}
		}

		// Token: 0x06000056 RID: 86 RVA: 0x00002693 File Offset: 0x00000893
		private void MyComboBox_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			this._Parameter = true;
		}

		// Token: 0x06000057 RID: 87 RVA: 0x0000269C File Offset: 0x0000089C
		private void MyComboBox_PreviewMouseLeftButtonUp(object sender, EventArgs e)
		{
			this._Parameter = false;
		}

		// Token: 0x06000058 RID: 88 RVA: 0x0000C5D4 File Offset: 0x0000A7D4
		public void RefreshColor()
		{
			string text;
			string text2;
			int time;
			if (base.IsEnabled)
			{
				if (Conversions.ToBoolean(base.IsEditable && Conversions.ToBoolean(NewLateBinding.LateGet(base.Template.FindName("PART_EditableTextBox", this), null, "IsFocused", new object[0], null, null, null))))
				{
					text = "ColorBrush4";
					text2 = "ColorBrush9";
					time = 60;
				}
				else if (!this._Parameter && !base.IsDropDownOpen)
				{
					if (base.IsMouseOver)
					{
						text = "ColorBrush3";
						text2 = "ColorBrushHalfWhite";
						time = 100;
					}
					else
					{
						text = "ColorBrush1";
						text2 = "ColorBrushHalfWhite";
						time = 200;
					}
				}
				else
				{
					text = "ColorBrush3";
					text2 = "ColorBrush9";
					time = 60;
				}
			}
			else
			{
				text = "ColorBrushGray4";
				text2 = "ColorBrushHalfWhite";
				time = 200;
			}
			if (base.IsLoaded && ModAnimation.DefineModel() == 0)
			{
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaColor(this, Control.ForegroundProperty, text, time, 0, null, false),
					ModAnimation.AaColor(this, Control.BackgroundProperty, text2, time, 0, null, false)
				}, "MyComboBox Color " + Conversions.ToString(this.issuer), false);
				return;
			}
			ModAnimation.AniStop("MyComboBox Color " + Conversions.ToString(this.issuer));
			base.SetResourceReference(Control.ForegroundProperty, text);
			base.SetResourceReference(Control.BackgroundProperty, text2);
		}

		// Token: 0x06000059 RID: 89 RVA: 0x0000C730 File Offset: 0x0000A930
		private void MyComboBox_DropDownOpened(object sender, EventArgs e)
		{
			this._Authentication = base.Width;
			base.Width = base.ActualWidth;
			try
			{
				((Grid)base.Template.FindName("PanPopup", this)).Opacity = ModMain.m_CollectionAccount.Opacity;
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "设置下拉框透明度失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x0600005A RID: 90 RVA: 0x000026A5 File Offset: 0x000008A5
		private void MyComboBox_DropDownClosed(object sender, EventArgs e)
		{
			base.Width = this._Authentication;
		}

		// Token: 0x0600005B RID: 91 RVA: 0x0000C7AC File Offset: 0x0000A9AC
		private void MyComboBox_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (!this.reponse && base.IsEditable && base.SelectedItem != null && Operators.CompareString(this.Text, base.SelectedItem.ToString(), true) != 0)
			{
				string text = this.Text;
				int selectionStart = this.TextBox.SelectionStart;
				this.reponse = true;
				base.SelectedItem = null;
				this.Text = text;
				this.TextBox.SelectionStart = selectionStart;
				this.reponse = false;
			}
		}

		// Token: 0x0400000B RID: 11
		[CompilerGenerated]
		private MyComboBox.TextChangedEventHandler m_Prototype;

		// Token: 0x0400000C RID: 12
		public int issuer;

		// Token: 0x0400000D RID: 13
		private MyTextBox TextBox;

		// Token: 0x0400000E RID: 14
		[CompilerGenerated]
		private string request;

		// Token: 0x0400000F RID: 15
		private string m_Account;

		// Token: 0x04000010 RID: 16
		private bool _Parameter;

		// Token: 0x04000011 RID: 17
		private double _Authentication;

		// Token: 0x04000012 RID: 18
		private bool reponse;

		// Token: 0x02000011 RID: 17
		// (Invoke) Token: 0x06000068 RID: 104
		public delegate void TextChangedEventHandler(object sender, TextChangedEventArgs e);
	}
}
