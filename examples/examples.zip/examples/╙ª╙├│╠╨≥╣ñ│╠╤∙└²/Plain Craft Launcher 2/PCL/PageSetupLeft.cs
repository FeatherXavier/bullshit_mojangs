﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000153 RID: 339
	[DesignerGenerated]
	public class PageSetupLeft : MyPageLeft, IComponentConnector
	{
		// Token: 0x06000DCA RID: 3530 RVA: 0x00065A9C File Offset: 0x00063C9C
		private void PageSetupLeft_Loaded(object sender, RoutedEventArgs e)
		{
			bool flag = false;
			if (Conversions.ToBoolean(this.ItemLaunch.Checked && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupLaunch", null))))
			{
				flag = true;
			}
			if (Conversions.ToBoolean(this.ItemUI.Checked && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupUi", null))))
			{
				flag = true;
			}
			if (Conversions.ToBoolean(this.ItemSystem.Checked && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupSystem", null))))
			{
				flag = true;
			}
			if (Conversions.ToBoolean(this.ItemLink.Checked && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupLink", null))))
			{
				flag = true;
			}
			if (PageSetupUI.AwakeResolver())
			{
				flag = false;
			}
			if (!this._VisitorPrototype || flag)
			{
				this._VisitorPrototype = true;
				PageSetupUI.HiddenRefresh();
				if (!this.helperPrototype)
				{
					if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenSetupLaunch", null))))
					{
						this.ItemLaunch.SetChecked(true, false, false);
						return;
					}
					if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenSetupUi", null))))
					{
						this.ItemUI.SetChecked(true, false, false);
						return;
					}
					if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenSetupSystem", null))))
					{
						this.ItemSystem.SetChecked(true, false, false);
						return;
					}
					if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenSetupLink", null))))
					{
						this.ItemLink.SetChecked(true, false, false);
						return;
					}
					this.ItemLaunch.SetChecked(true, false, false);
				}
			}
		}

		// Token: 0x06000DCB RID: 3531 RVA: 0x00008D6F File Offset: 0x00006F6F
		private void PageOtherLeft_Unloaded(object sender, RoutedEventArgs e)
		{
			this.helperPrototype = false;
		}

		// Token: 0x06000DCC RID: 3532 RVA: 0x00065C60 File Offset: 0x00063E60
		public PageSetupLeft()
		{
			base.Loaded += this.PageSetupLeft_Loaded;
			base.Unloaded += this.PageOtherLeft_Unloaded;
			this._VisitorPrototype = false;
			this.helperPrototype = false;
			this.InitializeComponent();
			if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenSetupLaunch", null))))
			{
				this._ParamPrototype = FormMain.PageSubType.Default;
				return;
			}
			if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenSetupUi", null))))
			{
				this._ParamPrototype = FormMain.PageSubType.DownloadInstall;
				return;
			}
			if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenSetupSystem", null))))
			{
				this._ParamPrototype = FormMain.PageSubType.SetupSystem;
				return;
			}
			if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenSetupLink", null))))
			{
				this._ParamPrototype = FormMain.PageSubType.SetupLink;
				return;
			}
			this._ParamPrototype = FormMain.PageSubType.Default;
		}

		// Token: 0x06000DCD RID: 3533 RVA: 0x00008D78 File Offset: 0x00006F78
		private void PageCheck(MyListItem sender, EventArgs e)
		{
			if (sender.Tag != null)
			{
				this.PageChange(checked((FormMain.PageSubType)Math.Round(ModBase.Val(RuntimeHelpers.GetObjectValue(sender.Tag)))));
			}
		}

		// Token: 0x06000DCE RID: 3534 RVA: 0x00065D44 File Offset: 0x00063F44
		public object PageGet(FormMain.PageSubType ID = (FormMain.PageSubType)(-1))
		{
			if (ID == (FormMain.PageSubType)(-1))
			{
				ID = this._ParamPrototype;
			}
			object result;
			switch (ID)
			{
			case FormMain.PageSubType.Default:
				if (ModMain.m_MerchantAccount == null)
				{
					ModMain.m_MerchantAccount = new PageSetupLaunch();
				}
				result = ModMain.m_MerchantAccount;
				break;
			case FormMain.PageSubType.DownloadInstall:
				if (ModMain.m_ExporterAccount == null)
				{
					ModMain.m_ExporterAccount = new PageSetupUI();
				}
				result = ModMain.m_ExporterAccount;
				break;
			case FormMain.PageSubType.SetupSystem:
				if (ModMain.queueAccount == null)
				{
					ModMain.queueAccount = new PageSetupSystem();
				}
				result = ModMain.queueAccount;
				break;
			case FormMain.PageSubType.SetupLink:
				if (ModMain.m_GlobalAccount == null)
				{
					ModMain.m_GlobalAccount = new PageSetupLink();
				}
				result = ModMain.m_GlobalAccount;
				break;
			default:
				throw new Exception("未知的设置子页面种类：" + Conversions.ToString((int)ID));
			}
			return result;
		}

		// Token: 0x06000DCF RID: 3535 RVA: 0x00065DF0 File Offset: 0x00063FF0
		public void PageChange(FormMain.PageSubType ID)
		{
			checked
			{
				if (this._ParamPrototype != ID)
				{
					ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
					this.helperPrototype = true;
					try
					{
						switch (ID)
						{
						case FormMain.PageSubType.Default:
							if (Information.IsNothing(ModMain.m_MerchantAccount))
							{
								ModMain.m_MerchantAccount = new PageSetupLaunch();
							}
							PageSetupLeft.PageChangeRun(ModMain.m_MerchantAccount);
							break;
						case FormMain.PageSubType.DownloadInstall:
							if (Information.IsNothing(ModMain.m_ExporterAccount))
							{
								ModMain.m_ExporterAccount = new PageSetupUI();
							}
							PageSetupLeft.PageChangeRun(ModMain.m_ExporterAccount);
							break;
						case FormMain.PageSubType.SetupSystem:
							if (Information.IsNothing(ModMain.queueAccount))
							{
								ModMain.queueAccount = new PageSetupSystem();
							}
							PageSetupLeft.PageChangeRun(ModMain.queueAccount);
							break;
						case FormMain.PageSubType.SetupLink:
							if (Information.IsNothing(ModMain.m_GlobalAccount))
							{
								ModMain.m_GlobalAccount = new PageSetupLink();
							}
							PageSetupLeft.PageChangeRun(ModMain.m_GlobalAccount);
							break;
						default:
							throw new Exception("未知的设置子页面种类：" + Conversions.ToString((int)ID));
						}
						this._ParamPrototype = ID;
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "切换设置分页面失败（ID " + Conversions.ToString((int)ID) + "）", ModBase.LogLevel.Feedback, "出现错误");
					}
					finally
					{
						ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
					}
				}
			}
		}

		// Token: 0x06000DD0 RID: 3536 RVA: 0x00065F34 File Offset: 0x00064134
		private static void PageChangeRun(MyPageRight Target)
		{
			if (Target.Parent != null)
			{
				Target.SetValue(ContentPresenter.ContentProperty, null);
			}
			ModMain.m_CollectionAccount.m_RequestAccount = Target;
			((MyPageRight)ModMain.m_CollectionAccount.PanMainRight.Child).PageOnExit();
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaCode((PageSetupLeft._Closure$__.$I9-0 == null) ? (PageSetupLeft._Closure$__.$I9-0 = delegate()
				{
					((MyPageRight)ModMain.m_CollectionAccount.PanMainRight.Child).PageOnForceExit();
					ModMain.m_CollectionAccount.PanMainRight.Child = ModMain.m_CollectionAccount.m_RequestAccount;
					ModMain.m_CollectionAccount.m_RequestAccount.Opacity = 0.0;
				}) : PageSetupLeft._Closure$__.$I9-0, 130, false),
				ModAnimation.AaCode((PageSetupLeft._Closure$__.$I9-1 == null) ? (PageSetupLeft._Closure$__.$I9-1 = delegate()
				{
					ModMain.m_CollectionAccount.m_RequestAccount.Opacity = 1.0;
					ModMain.m_CollectionAccount.m_RequestAccount.PageOnEnter();
				}) : PageSetupLeft._Closure$__.$I9-1, 30, true)
			}, "PageLeft PageChange", false);
		}

		// Token: 0x06000DD1 RID: 3537 RVA: 0x00065FF4 File Offset: 0x000641F4
		public void Reset(object sender, EventArgs e)
		{
			double num = ModBase.Val(RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(sender, null, "Tag", new object[0], null, null, null)));
			if (num == 0.0)
			{
				if (ModMain.MyMsgBox("是否要初始化启动页的所有设置？该操作不可撤销。", "初始化确认", "确定", "取消", "", true, true, false) == 1)
				{
					if (Information.IsNothing(ModMain.m_MerchantAccount))
					{
						ModMain.m_MerchantAccount = new PageSetupLaunch();
					}
					ModMain.m_MerchantAccount.Reset();
					return;
				}
			}
			else if (num == 1.0)
			{
				if (ModMain.MyMsgBox("是否要初始化个性化页的所有设置？该操作不可撤销。\r\n（背景图片与音乐、自定义主页等外部文件不会被删除）", "初始化确认", "确定", "取消", "", true, true, false) == 1)
				{
					if (Information.IsNothing(ModMain.m_ExporterAccount))
					{
						ModMain.m_ExporterAccount = new PageSetupUI();
					}
					ModMain.m_ExporterAccount.Reset();
					return;
				}
			}
			else if (num == 2.0)
			{
				if (ModMain.MyMsgBox("是否要初始化启动器页的所有设置？该操作不可撤销。", "初始化确认", "确定", "取消", "", true, true, false) == 1)
				{
					if (Information.IsNothing(ModMain.queueAccount))
					{
						ModMain.queueAccount = new PageSetupSystem();
					}
					ModMain.queueAccount.Reset();
					return;
				}
			}
			else if (num == 3.0 && ModMain.MyMsgBox("是否要初始化联机页的所有设置？该操作不可撤销。", "初始化确认", "确定", "取消", "", true, true, false) == 1)
			{
				if (Information.IsNothing(ModMain.m_GlobalAccount))
				{
					ModMain.m_GlobalAccount = new PageSetupLink();
				}
				ModMain.m_GlobalAccount.Reset();
			}
		}

		// Token: 0x17000222 RID: 546
		// (get) Token: 0x06000DD2 RID: 3538 RVA: 0x00008D9E File Offset: 0x00006F9E
		// (set) Token: 0x06000DD3 RID: 3539 RVA: 0x00008DA6 File Offset: 0x00006FA6
		internal virtual StackPanel PanItem { get; set; }

		// Token: 0x17000223 RID: 547
		// (get) Token: 0x06000DD4 RID: 3540 RVA: 0x00008DAF File Offset: 0x00006FAF
		// (set) Token: 0x06000DD5 RID: 3541 RVA: 0x0006616C File Offset: 0x0006436C
		internal virtual MyListItem ItemLaunch
		{
			[CompilerGenerated]
			get
			{
				return this._ProductPrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem productPrototype = this._ProductPrototype;
				if (productPrototype != null)
				{
					productPrototype.Check -= value2;
				}
				this._ProductPrototype = value;
				productPrototype = this._ProductPrototype;
				if (productPrototype != null)
				{
					productPrototype.Check += value2;
				}
			}
		}

		// Token: 0x17000224 RID: 548
		// (get) Token: 0x06000DD6 RID: 3542 RVA: 0x00008DB7 File Offset: 0x00006FB7
		// (set) Token: 0x06000DD7 RID: 3543 RVA: 0x000661B0 File Offset: 0x000643B0
		internal virtual MyListItem ItemUI
		{
			[CompilerGenerated]
			get
			{
				return this._AttrPrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem attrPrototype = this._AttrPrototype;
				if (attrPrototype != null)
				{
					attrPrototype.Check -= value2;
				}
				this._AttrPrototype = value;
				attrPrototype = this._AttrPrototype;
				if (attrPrototype != null)
				{
					attrPrototype.Check += value2;
				}
			}
		}

		// Token: 0x17000225 RID: 549
		// (get) Token: 0x06000DD8 RID: 3544 RVA: 0x00008DBF File Offset: 0x00006FBF
		// (set) Token: 0x06000DD9 RID: 3545 RVA: 0x000661F4 File Offset: 0x000643F4
		internal virtual MyListItem ItemSystem
		{
			[CompilerGenerated]
			get
			{
				return this.m_FacadePrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem facadePrototype = this.m_FacadePrototype;
				if (facadePrototype != null)
				{
					facadePrototype.Check -= value2;
				}
				this.m_FacadePrototype = value;
				facadePrototype = this.m_FacadePrototype;
				if (facadePrototype != null)
				{
					facadePrototype.Check += value2;
				}
			}
		}

		// Token: 0x17000226 RID: 550
		// (get) Token: 0x06000DDA RID: 3546 RVA: 0x00008DC7 File Offset: 0x00006FC7
		// (set) Token: 0x06000DDB RID: 3547 RVA: 0x00066238 File Offset: 0x00064438
		internal virtual MyListItem ItemLink
		{
			[CompilerGenerated]
			get
			{
				return this.m_BridgePrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem bridgePrototype = this.m_BridgePrototype;
				if (bridgePrototype != null)
				{
					bridgePrototype.Check -= value2;
				}
				this.m_BridgePrototype = value;
				bridgePrototype = this.m_BridgePrototype;
				if (bridgePrototype != null)
				{
					bridgePrototype.Check += value2;
				}
			}
		}

		// Token: 0x06000DDC RID: 3548 RVA: 0x0006627C File Offset: 0x0006447C
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.structPrototype)
			{
				this.structPrototype = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagesetup/pagesetupleft.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000DDD RID: 3549 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000DDE RID: 3550 RVA: 0x000662AC File Offset: 0x000644AC
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanItem = (StackPanel)target;
				return;
			}
			if (connectionId == 2)
			{
				this.ItemLaunch = (MyListItem)target;
				return;
			}
			if (connectionId == 3)
			{
				this.ItemUI = (MyListItem)target;
				return;
			}
			if (connectionId == 4)
			{
				this.ItemSystem = (MyListItem)target;
				return;
			}
			if (connectionId == 5)
			{
				this.ItemLink = (MyListItem)target;
				return;
			}
			this.structPrototype = true;
		}

		// Token: 0x040006DF RID: 1759
		private bool _VisitorPrototype;

		// Token: 0x040006E0 RID: 1760
		private bool helperPrototype;

		// Token: 0x040006E1 RID: 1761
		public FormMain.PageSubType _ParamPrototype;

		// Token: 0x040006E2 RID: 1762
		[AccessedThroughProperty("PanItem")]
		[CompilerGenerated]
		private StackPanel m_BasePrototype;

		// Token: 0x040006E3 RID: 1763
		[AccessedThroughProperty("ItemLaunch")]
		[CompilerGenerated]
		private MyListItem _ProductPrototype;

		// Token: 0x040006E4 RID: 1764
		[AccessedThroughProperty("ItemUI")]
		[CompilerGenerated]
		private MyListItem _AttrPrototype;

		// Token: 0x040006E5 RID: 1765
		[CompilerGenerated]
		[AccessedThroughProperty("ItemSystem")]
		private MyListItem m_FacadePrototype;

		// Token: 0x040006E6 RID: 1766
		[CompilerGenerated]
		[AccessedThroughProperty("ItemLink")]
		private MyListItem m_BridgePrototype;

		// Token: 0x040006E7 RID: 1767
		private bool structPrototype;
	}
}
