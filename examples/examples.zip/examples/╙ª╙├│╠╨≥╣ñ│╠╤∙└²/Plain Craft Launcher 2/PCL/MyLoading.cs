﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200004C RID: 76
	[DesignerGenerated]
	public class MyLoading : Grid, IComponentConnector
	{
		// Token: 0x060001D0 RID: 464 RVA: 0x0001525C File Offset: 0x0001345C
		[CompilerGenerated]
		public void UpdateWrapper(MyLoading.IsErrorChangedEventHandler obj)
		{
			MyLoading.IsErrorChangedEventHandler isErrorChangedEventHandler = this._Interpreter;
			MyLoading.IsErrorChangedEventHandler isErrorChangedEventHandler2;
			do
			{
				isErrorChangedEventHandler2 = isErrorChangedEventHandler;
				MyLoading.IsErrorChangedEventHandler value = (MyLoading.IsErrorChangedEventHandler)Delegate.Combine(isErrorChangedEventHandler2, obj);
				isErrorChangedEventHandler = Interlocked.CompareExchange<MyLoading.IsErrorChangedEventHandler>(ref this._Interpreter, value, isErrorChangedEventHandler2);
			}
			while (isErrorChangedEventHandler != isErrorChangedEventHandler2);
		}

		// Token: 0x060001D1 RID: 465 RVA: 0x00015294 File Offset: 0x00013494
		[CompilerGenerated]
		public void ViewWrapper(MyLoading.IsErrorChangedEventHandler obj)
		{
			MyLoading.IsErrorChangedEventHandler isErrorChangedEventHandler = this._Interpreter;
			MyLoading.IsErrorChangedEventHandler isErrorChangedEventHandler2;
			do
			{
				isErrorChangedEventHandler2 = isErrorChangedEventHandler;
				MyLoading.IsErrorChangedEventHandler value = (MyLoading.IsErrorChangedEventHandler)Delegate.Remove(isErrorChangedEventHandler2, obj);
				isErrorChangedEventHandler = Interlocked.CompareExchange<MyLoading.IsErrorChangedEventHandler>(ref this._Interpreter, value, isErrorChangedEventHandler2);
			}
			while (isErrorChangedEventHandler != isErrorChangedEventHandler2);
		}

		// Token: 0x060001D2 RID: 466 RVA: 0x000152CC File Offset: 0x000134CC
		[CompilerGenerated]
		public void InstantiateWrapper(MyLoading.StateChangedEventHandler obj)
		{
			MyLoading.StateChangedEventHandler stateChangedEventHandler = this._Parser;
			MyLoading.StateChangedEventHandler stateChangedEventHandler2;
			do
			{
				stateChangedEventHandler2 = stateChangedEventHandler;
				MyLoading.StateChangedEventHandler value = (MyLoading.StateChangedEventHandler)Delegate.Combine(stateChangedEventHandler2, obj);
				stateChangedEventHandler = Interlocked.CompareExchange<MyLoading.StateChangedEventHandler>(ref this._Parser, value, stateChangedEventHandler2);
			}
			while (stateChangedEventHandler != stateChangedEventHandler2);
		}

		// Token: 0x060001D3 RID: 467 RVA: 0x00015304 File Offset: 0x00013504
		[CompilerGenerated]
		public void RemoveWrapper(MyLoading.StateChangedEventHandler obj)
		{
			MyLoading.StateChangedEventHandler stateChangedEventHandler = this._Parser;
			MyLoading.StateChangedEventHandler stateChangedEventHandler2;
			do
			{
				stateChangedEventHandler2 = stateChangedEventHandler;
				MyLoading.StateChangedEventHandler value = (MyLoading.StateChangedEventHandler)Delegate.Remove(stateChangedEventHandler2, obj);
				stateChangedEventHandler = Interlocked.CompareExchange<MyLoading.StateChangedEventHandler>(ref this._Parser, value, stateChangedEventHandler2);
			}
			while (stateChangedEventHandler != stateChangedEventHandler2);
		}

		// Token: 0x060001D4 RID: 468 RVA: 0x0001533C File Offset: 0x0001353C
		[CompilerGenerated]
		public void PatchWrapper(MyLoading.ClickEventHandler obj)
		{
			MyLoading.ClickEventHandler clickEventHandler = this._Stub;
			MyLoading.ClickEventHandler clickEventHandler2;
			do
			{
				clickEventHandler2 = clickEventHandler;
				MyLoading.ClickEventHandler value = (MyLoading.ClickEventHandler)Delegate.Combine(clickEventHandler2, obj);
				clickEventHandler = Interlocked.CompareExchange<MyLoading.ClickEventHandler>(ref this._Stub, value, clickEventHandler2);
			}
			while (clickEventHandler != clickEventHandler2);
		}

		// Token: 0x060001D5 RID: 469 RVA: 0x00015374 File Offset: 0x00013574
		[CompilerGenerated]
		public void ReflectWrapper(MyLoading.ClickEventHandler obj)
		{
			MyLoading.ClickEventHandler clickEventHandler = this._Stub;
			MyLoading.ClickEventHandler clickEventHandler2;
			do
			{
				clickEventHandler2 = clickEventHandler;
				MyLoading.ClickEventHandler value = (MyLoading.ClickEventHandler)Delegate.Remove(clickEventHandler2, obj);
				clickEventHandler = Interlocked.CompareExchange<MyLoading.ClickEventHandler>(ref this._Stub, value, clickEventHandler2);
			}
			while (clickEventHandler != clickEventHandler2);
		}

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x060001D6 RID: 470 RVA: 0x000032A9 File Offset: 0x000014A9
		// (set) Token: 0x060001D7 RID: 471 RVA: 0x000032B1 File Offset: 0x000014B1
		public bool AutoRun { get; set; }

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x060001D8 RID: 472 RVA: 0x000032BA File Offset: 0x000014BA
		// (set) Token: 0x060001D9 RID: 473 RVA: 0x000032CC File Offset: 0x000014CC
		public SolidColorBrush Foreground
		{
			get
			{
				return (SolidColorBrush)base.GetValue(MyLoading._Strategy);
			}
			set
			{
				base.SetValue(MyLoading._Strategy, value);
			}
		}

		// Token: 0x060001DA RID: 474 RVA: 0x000153AC File Offset: 0x000135AC
		public MyLoading()
		{
			this.UpdateWrapper(delegate(object a0, bool a1)
			{
				this.RefreshText();
			});
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.RefreshText();
			};
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.InitState();
			};
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.RefreshState();
			};
			base.Unloaded += delegate(object sender, RoutedEventArgs e)
			{
				this.RefreshState();
			};
			base.MouseLeftButtonUp += this.Button_MouseUp;
			base.MouseLeftButtonDown += this.Button_MouseDown;
			base.MouseLeave += new MouseEventHandler(this.Button_MouseLeave);
			base.MouseLeftButtonUp += new MouseButtonEventHandler(this.Button_MouseLeave);
			this.AutoRun = true;
			this.tests = ModBase.GetUuid();
			this.InvokeWrapper(false);
			this.m_Worker = "加载中";
			this.m_Dic = "加载失败";
			this.CollectWrapper(true);
			this.NewWrapper(MyLoading.MyLoadingState.Unloaded);
			this.SetWrapper(MyLoading.MyLoadingState.Unloaded);
			this.HasAnimation = true;
			this.queue = false;
			this.global = false;
			this.list = false;
			this.InitializeComponent();
			base.SetResourceReference(MyLoading._Strategy, "ColorBrush3");
		}

		// Token: 0x060001DB RID: 475 RVA: 0x000032DA File Offset: 0x000014DA
		[CompilerGenerated]
		private bool TestWrapper()
		{
			return this.rules;
		}

		// Token: 0x060001DC RID: 476 RVA: 0x000032E2 File Offset: 0x000014E2
		[CompilerGenerated]
		private void InvokeWrapper(bool AutoPropertyValue)
		{
			this.rules = AutoPropertyValue;
		}

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x060001DD RID: 477 RVA: 0x000032EB File Offset: 0x000014EB
		// (set) Token: 0x060001DE RID: 478 RVA: 0x000032F3 File Offset: 0x000014F3
		public bool ShowProgress
		{
			get
			{
				return this.TestWrapper();
			}
			set
			{
				if (this.TestWrapper() != value)
				{
					this.InvokeWrapper(value);
					this.RefreshText();
				}
			}
		}

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x060001DF RID: 479 RVA: 0x0000330B File Offset: 0x0000150B
		// (set) Token: 0x060001E0 RID: 480 RVA: 0x00003313 File Offset: 0x00001513
		public string Text
		{
			get
			{
				return this.m_Worker;
			}
			set
			{
				this.m_Worker = value;
				this.RefreshText();
			}
		}

		// Token: 0x060001E1 RID: 481 RVA: 0x00003322 File Offset: 0x00001522
		public string CalculateWrapper()
		{
			return this.m_Dic;
		}

		// Token: 0x060001E2 RID: 482 RVA: 0x0000332A File Offset: 0x0000152A
		public void ComputeWrapper(string value)
		{
			this.m_Dic = value;
			this.RefreshText();
		}

		// Token: 0x060001E3 RID: 483 RVA: 0x00003339 File Offset: 0x00001539
		[CompilerGenerated]
		public bool LoginWrapper()
		{
			return this._Configuration;
		}

		// Token: 0x060001E4 RID: 484 RVA: 0x00003341 File Offset: 0x00001541
		[CompilerGenerated]
		public void CollectWrapper(bool AutoPropertyValue)
		{
			this._Configuration = AutoPropertyValue;
		}

		// Token: 0x060001E5 RID: 485 RVA: 0x000154D8 File Offset: 0x000136D8
		private void RefreshText()
		{
			if (this.MapWrapper() == MyLoading.MyLoadingState.Error)
			{
				if (!this.LoginWrapper() || !this.State.IsLoader)
				{
					this.LabText.Text = this.CalculateWrapper();
					return;
				}
				Exception ex = (Exception)NewLateBinding.LateGet(this.State, null, "Error", new object[0], null, null, null);
				if (ex == null)
				{
					this.LabText.Text = "未知错误";
					return;
				}
				while (ex.InnerException != null)
				{
					ex = ex.InnerException;
				}
				this.LabText.Text = Conversions.ToString(ModBase.StrTrim(ex.Message, true));
				if (this.LabText.Text.Contains("远程主机强迫关闭了一个现有的连接") || this.LabText.Text.Contains("操作已超时") || this.LabText.Text.Contains("操作超时") || this.LabText.Text.Contains("服务器超时") || this.LabText.Text.Contains("连接超时"))
				{
					this.LabText.Text = "网络环境不佳，请重试或尝试使用 VPN";
					return;
				}
			}
			else
			{
				if (this.ShowProgress && this.State.IsLoader)
				{
					this.LabText.Text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(this.Text + " - ", NewLateBinding.LateGet(null, typeof(Math), "Floor", new object[]
					{
						Operators.MultiplyObject(NewLateBinding.LateGet(this.State, null, "Progress", new object[0], null, null, null), 100)
					}, null, null, null)), "%"));
					return;
				}
				this.LabText.Text = this.Text;
			}
		}

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x060001E6 RID: 486 RVA: 0x0000334A File Offset: 0x0000154A
		// (set) Token: 0x060001E7 RID: 487 RVA: 0x000156A8 File Offset: 0x000138A8
		private virtual ILoadingTrigger _State
		{
			[CompilerGenerated]
			get
			{
				return this.config;
			}
			[CompilerGenerated]
			set
			{
				ILoadingTrigger.LoadingStateChangedEventHandler value2 = delegate(MyLoading.MyLoadingState a0, MyLoading.MyLoadingState a1)
				{
					this.RefreshState();
				};
				ILoadingTrigger loadingTrigger = this.config;
				if (loadingTrigger != null)
				{
					loadingTrigger.LoadingStateChanged -= value2;
				}
				this.config = value;
				loadingTrigger = this.config;
				if (loadingTrigger != null)
				{
					loadingTrigger.LoadingStateChanged += value2;
				}
			}
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x060001E8 RID: 488 RVA: 0x00003352 File Offset: 0x00001552
		// (set) Token: 0x060001E9 RID: 489 RVA: 0x00003360 File Offset: 0x00001560
		public ILoadingTrigger State
		{
			get
			{
				this.InitState();
				return this._State;
			}
			set
			{
				this._State = value;
				this.RefreshState();
			}
		}

		// Token: 0x060001EA RID: 490 RVA: 0x0000336F File Offset: 0x0000156F
		private void InitState()
		{
			if (this._State == null)
			{
				this._State = new MyLoadingStateSimulator();
				if (this.AutoRun)
				{
					this._State.LoadingState = MyLoading.MyLoadingState.Run;
				}
			}
		}

		// Token: 0x060001EB RID: 491 RVA: 0x000156EC File Offset: 0x000138EC
		private void RefreshState()
		{
			if (this._State.LoadingState == MyLoading.MyLoadingState.Run && !base.IsLoaded)
			{
				this.InterruptWrapper(MyLoading.MyLoadingState.Stop);
			}
			this.InterruptWrapper(this._State.LoadingState);
			this.ListWrapper(this._State.LoadingState);
			this.AniLoop();
		}

		// Token: 0x060001EC RID: 492 RVA: 0x00003398 File Offset: 0x00001598
		[CompilerGenerated]
		private MyLoading.MyLoadingState ConnectWrapper()
		{
			return this.m_Rule;
		}

		// Token: 0x060001ED RID: 493 RVA: 0x000033A0 File Offset: 0x000015A0
		[CompilerGenerated]
		private void NewWrapper(MyLoading.MyLoadingState AutoPropertyValue)
		{
			this.m_Rule = AutoPropertyValue;
		}

		// Token: 0x060001EE RID: 494 RVA: 0x000033A9 File Offset: 0x000015A9
		private MyLoading.MyLoadingState VisitWrapper()
		{
			return this.ConnectWrapper();
		}

		// Token: 0x060001EF RID: 495 RVA: 0x00015740 File Offset: 0x00013940
		private void ListWrapper(MyLoading.MyLoadingState value)
		{
			if (this.ConnectWrapper() != value)
			{
				MyLoading.MyLoadingState myLoadingState = this.ConnectWrapper();
				this.NewWrapper(value);
				MyLoading.StateChangedEventHandler parser = this._Parser;
				if (parser != null)
				{
					parser(this, value, myLoadingState);
				}
				if (myLoadingState == MyLoading.MyLoadingState.Error != (value == MyLoading.MyLoadingState.Error))
				{
					MyLoading.IsErrorChangedEventHandler interpreter = this._Interpreter;
					if (interpreter != null)
					{
						interpreter(this, value == MyLoading.MyLoadingState.Error);
					}
				}
			}
		}

		// Token: 0x060001F0 RID: 496 RVA: 0x000033B1 File Offset: 0x000015B1
		[CompilerGenerated]
		private MyLoading.MyLoadingState RateWrapper()
		{
			return this.m_Merchant;
		}

		// Token: 0x060001F1 RID: 497 RVA: 0x000033B9 File Offset: 0x000015B9
		[CompilerGenerated]
		private void SetWrapper(MyLoading.MyLoadingState AutoPropertyValue)
		{
			this.m_Merchant = AutoPropertyValue;
		}

		// Token: 0x060001F2 RID: 498 RVA: 0x000033C2 File Offset: 0x000015C2
		private MyLoading.MyLoadingState MapWrapper()
		{
			return this.RateWrapper();
		}

		// Token: 0x060001F3 RID: 499 RVA: 0x000033CA File Offset: 0x000015CA
		private void InterruptWrapper(MyLoading.MyLoadingState value)
		{
			if (this.RateWrapper() != value)
			{
				int num = (int)this.RateWrapper();
				this.SetWrapper(value);
				this.AniLoop();
				if (num == 2 != (value == MyLoading.MyLoadingState.Error))
				{
					this.ErrorAnimation(this, value == MyLoading.MyLoadingState.Error);
				}
			}
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x060001F4 RID: 500 RVA: 0x000033FC File Offset: 0x000015FC
		// (set) Token: 0x060001F5 RID: 501 RVA: 0x00003404 File Offset: 0x00001604
		public bool HasAnimation { get; set; }

		// Token: 0x060001F6 RID: 502 RVA: 0x00015798 File Offset: 0x00013998
		private void AniLoop()
		{
			if (this.HasAnimation && !this.queue && this.MapWrapper() == MyLoading.MyLoadingState.Run && ModAnimation.m_Test <= 10.0 && base.IsLoaded)
			{
				this.queue = true;
				this.global = true;
				if (this.ShowProgress)
				{
					this.RefreshText();
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaRotateTransform(this.PathPickaxe, -20.0 - ((RotateTransform)this.PathPickaxe.RenderTransform).Angle, 350, 250, new ModAnimation.AniEaseInBack(ModAnimation.AniEasePower.Weak), false),
						ModAnimation.AaCode(new ThreadStart(this.RefreshText), 100, false),
						ModAnimation.AaCode(new ThreadStart(this.RefreshText), 200, false),
						ModAnimation.AaCode(new ThreadStart(this.RefreshText), 300, false),
						ModAnimation.AaCode(new ThreadStart(this.RefreshText), 400, false),
						ModAnimation.AaCode(new ThreadStart(this.RefreshText), 500, false),
						ModAnimation.AaRotateTransform(this.PathPickaxe, 50.0, 900, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), true),
						ModAnimation.AaRotateTransform(this.PathPickaxe, 25.0, 900, 0, new ModAnimation.AniEaseOutElastic(ModAnimation.AniEasePower.Weak), false),
						ModAnimation.AaCode(delegate
						{
							this.PathLeft.Opacity = 1.0;
							this.PathLeft.Margin = new Thickness(7.0, 41.0, 0.0, 0.0);
							this.PathRight.Opacity = 1.0;
							this.PathRight.Margin = new Thickness(14.0, 41.0, 0.0, 0.0);
							this.global = false;
							this.RefreshText();
						}, 0, false),
						ModAnimation.AaCode(new ThreadStart(this.RefreshText), 100, false),
						ModAnimation.AaCode(new ThreadStart(this.RefreshText), 200, false),
						ModAnimation.AaCode(new ThreadStart(this.RefreshText), 300, false),
						ModAnimation.AaCode(new ThreadStart(this.RefreshText), 400, false),
						ModAnimation.AaCode(new ThreadStart(this.RefreshText), 500, false),
						ModAnimation.AaCode(new ThreadStart(this.RefreshText), 600, false),
						ModAnimation.AaCode(new ThreadStart(this.RefreshText), 700, false),
						ModAnimation.AaCode(new ThreadStart(this.RefreshText), 800, false),
						ModAnimation.AaOpacity(this.PathLeft, -1.0, 100, 70, null, false),
						ModAnimation.AaX(this.PathLeft, -5.0, 180, 20, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
						ModAnimation.AaY(this.PathLeft, -6.0, 180, 20, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
						ModAnimation.AaOpacity(this.PathRight, -1.0, 100, 70, null, false),
						ModAnimation.AaX(this.PathRight, 5.0, 180, 20, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
						ModAnimation.AaY(this.PathRight, -6.0, 180, 20, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
						ModAnimation.AaCode(delegate
						{
							this.queue = false;
							this.AniLoop();
						}, 0, true)
					}, "MyLoader Loop " + Conversions.ToString(this.tests) + "/" + Conversions.ToString(ModBase.GetUuid()), false);
					return;
				}
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaRotateTransform(this.PathPickaxe, -20.0 - ((RotateTransform)this.PathPickaxe.RenderTransform).Angle, 350, 250, new ModAnimation.AniEaseInBack(ModAnimation.AniEasePower.Weak), false),
					ModAnimation.AaRotateTransform(this.PathPickaxe, 50.0, 900, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), true),
					ModAnimation.AaRotateTransform(this.PathPickaxe, 25.0, 900, 0, new ModAnimation.AniEaseOutElastic(ModAnimation.AniEasePower.Weak), false),
					ModAnimation.AaCode(delegate
					{
						this.PathLeft.Opacity = 1.0;
						this.PathLeft.Margin = new Thickness(7.0, 41.0, 0.0, 0.0);
						this.PathRight.Opacity = 1.0;
						this.PathRight.Margin = new Thickness(14.0, 41.0, 0.0, 0.0);
						this.global = false;
					}, 0, false),
					ModAnimation.AaOpacity(this.PathLeft, -1.0, 100, 50, null, false),
					ModAnimation.AaX(this.PathLeft, -5.0, 180, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaY(this.PathLeft, -6.0, 180, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaOpacity(this.PathRight, -1.0, 100, 50, null, false),
					ModAnimation.AaX(this.PathRight, 5.0, 180, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaY(this.PathRight, -6.0, 180, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaCode(delegate
					{
						this.queue = false;
						this.AniLoop();
					}, 0, true)
				}, "MyLoader Loop " + Conversions.ToString(this.tests) + "/" + Conversions.ToString(ModBase.GetUuid()), false);
			}
		}

		// Token: 0x060001F7 RID: 503 RVA: 0x00015D4C File Offset: 0x00013F4C
		private void ErrorAnimation(object sender, bool isError)
		{
			if (isError)
			{
				int num = this.global ? 400 : 0;
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaColor(this.PanBack, MyLoading._Strategy, "ColorBrushRedLight", 300, 0, null, false),
					ModAnimation.AaOpacity(this.PathError, 1.0 - this.PathError.Opacity, 100, checked(300 + num), null, false),
					ModAnimation.AaScaleTransform(this.PathError, 1.0 - ((ScaleTransform)this.PathError.RenderTransform).ScaleX, 400, checked(300 + num), new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Middle), false)
				}, "MyLoader Error " + Conversions.ToString(this.tests), false);
				return;
			}
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaOpacity(this.PathError, -this.PathError.Opacity, 100, 0, null, false),
				ModAnimation.AaScaleTransform(this.PathError, 0.5 - ((ScaleTransform)this.PathError.RenderTransform).ScaleX, 200, 0, null, false),
				ModAnimation.AaColor(this.PanBack, MyLoading._Strategy, "ColorBrush3", 300, 0, null, false)
			}, "MyLoader Error " + Conversions.ToString(this.tests), false);
		}

		// Token: 0x060001F8 RID: 504 RVA: 0x00015ED0 File Offset: 0x000140D0
		private void Button_MouseUp(object sender, MouseButtonEventArgs e)
		{
			MyLoading.ClickEventHandler stub = this._Stub;
			if (stub != null)
			{
				stub(RuntimeHelpers.GetObjectValue(sender), e);
			}
		}

		// Token: 0x060001F9 RID: 505 RVA: 0x0000340D File Offset: 0x0000160D
		private void Button_MouseDown(object sender, MouseButtonEventArgs e)
		{
			this.list = true;
		}

		// Token: 0x060001FA RID: 506 RVA: 0x00003416 File Offset: 0x00001616
		private void Button_MouseLeave(object sender, object e)
		{
			this.list = false;
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x060001FB RID: 507 RVA: 0x0000341F File Offset: 0x0000161F
		// (set) Token: 0x060001FC RID: 508 RVA: 0x00003427 File Offset: 0x00001627
		internal virtual MyLoading PanBack { get; set; }

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x060001FD RID: 509 RVA: 0x00003430 File Offset: 0x00001630
		// (set) Token: 0x060001FE RID: 510 RVA: 0x00003438 File Offset: 0x00001638
		internal virtual Path PathPickaxe { get; set; }

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x060001FF RID: 511 RVA: 0x00003441 File Offset: 0x00001641
		// (set) Token: 0x06000200 RID: 512 RVA: 0x00003449 File Offset: 0x00001649
		internal virtual Path PathLeft { get; set; }

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x06000201 RID: 513 RVA: 0x00003452 File Offset: 0x00001652
		// (set) Token: 0x06000202 RID: 514 RVA: 0x0000345A File Offset: 0x0000165A
		internal virtual Path PathRight { get; set; }

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x06000203 RID: 515 RVA: 0x00003463 File Offset: 0x00001663
		// (set) Token: 0x06000204 RID: 516 RVA: 0x0000346B File Offset: 0x0000166B
		internal virtual Path PathError { get; set; }

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x06000205 RID: 517 RVA: 0x00003474 File Offset: 0x00001674
		// (set) Token: 0x06000206 RID: 518 RVA: 0x0000347C File Offset: 0x0000167C
		internal virtual TextBlock LabText { get; set; }

		// Token: 0x06000207 RID: 519 RVA: 0x00015EF4 File Offset: 0x000140F4
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this._Registry)
			{
				this._Registry = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/controls/myloading.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000208 RID: 520 RVA: 0x00015F24 File Offset: 0x00014124
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyLoading)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PathPickaxe = (Path)target;
				return;
			}
			if (connectionId == 3)
			{
				this.PathLeft = (Path)target;
				return;
			}
			if (connectionId == 4)
			{
				this.PathRight = (Path)target;
				return;
			}
			if (connectionId == 5)
			{
				this.PathError = (Path)target;
				return;
			}
			if (connectionId == 6)
			{
				this.LabText = (TextBlock)target;
				return;
			}
			this._Registry = true;
		}

		// Token: 0x040000DD RID: 221
		[CompilerGenerated]
		private MyLoading.IsErrorChangedEventHandler _Interpreter;

		// Token: 0x040000DE RID: 222
		[CompilerGenerated]
		private MyLoading.StateChangedEventHandler _Parser;

		// Token: 0x040000DF RID: 223
		[CompilerGenerated]
		private MyLoading.ClickEventHandler _Stub;

		// Token: 0x040000E0 RID: 224
		[CompilerGenerated]
		private bool m_Exception;

		// Token: 0x040000E1 RID: 225
		private int tests;

		// Token: 0x040000E2 RID: 226
		public static readonly DependencyProperty _Strategy = DependencyProperty.Register("Foreground", typeof(SolidColorBrush), typeof(MyLoading));

		// Token: 0x040000E3 RID: 227
		[CompilerGenerated]
		private bool rules;

		// Token: 0x040000E4 RID: 228
		private string m_Worker;

		// Token: 0x040000E5 RID: 229
		private string m_Dic;

		// Token: 0x040000E6 RID: 230
		[CompilerGenerated]
		private bool _Configuration;

		// Token: 0x040000E7 RID: 231
		[CompilerGenerated]
		[AccessedThroughProperty("_State")]
		private ILoadingTrigger config;

		// Token: 0x040000E8 RID: 232
		[CompilerGenerated]
		private MyLoading.MyLoadingState m_Rule;

		// Token: 0x040000E9 RID: 233
		[CompilerGenerated]
		private MyLoading.MyLoadingState m_Merchant;

		// Token: 0x040000EA RID: 234
		[CompilerGenerated]
		private bool _Exporter;

		// Token: 0x040000EB RID: 235
		private bool queue;

		// Token: 0x040000EC RID: 236
		private bool global;

		// Token: 0x040000ED RID: 237
		private bool list;

		// Token: 0x040000EE RID: 238
		[CompilerGenerated]
		[AccessedThroughProperty("PanBack")]
		private MyLoading method;

		// Token: 0x040000EF RID: 239
		[CompilerGenerated]
		[AccessedThroughProperty("PathPickaxe")]
		private Path m_Interceptor;

		// Token: 0x040000F0 RID: 240
		[CompilerGenerated]
		[AccessedThroughProperty("PathLeft")]
		private Path @ref;

		// Token: 0x040000F1 RID: 241
		[CompilerGenerated]
		[AccessedThroughProperty("PathRight")]
		private Path _Service;

		// Token: 0x040000F2 RID: 242
		[CompilerGenerated]
		[AccessedThroughProperty("PathError")]
		private Path _Importer;

		// Token: 0x040000F3 RID: 243
		[AccessedThroughProperty("LabText")]
		[CompilerGenerated]
		private TextBlock m_Proxy;

		// Token: 0x040000F4 RID: 244
		private bool _Registry;

		// Token: 0x0200004D RID: 77
		// (Invoke) Token: 0x06000216 RID: 534
		public delegate void IsErrorChangedEventHandler(object sender, bool isError);

		// Token: 0x0200004E RID: 78
		// (Invoke) Token: 0x0600021B RID: 539
		public delegate void StateChangedEventHandler(object sender, MyLoading.MyLoadingState newState, MyLoading.MyLoadingState oldState);

		// Token: 0x0200004F RID: 79
		// (Invoke) Token: 0x06000220 RID: 544
		public delegate void ClickEventHandler(object sender, MouseButtonEventArgs e);

		// Token: 0x02000050 RID: 80
		public enum MyLoadingState
		{
			// Token: 0x040000F6 RID: 246
			Unloaded = -1,
			// Token: 0x040000F7 RID: 247
			Run,
			// Token: 0x040000F8 RID: 248
			Stop,
			// Token: 0x040000F9 RID: 249
			Error
		}
	}
}
