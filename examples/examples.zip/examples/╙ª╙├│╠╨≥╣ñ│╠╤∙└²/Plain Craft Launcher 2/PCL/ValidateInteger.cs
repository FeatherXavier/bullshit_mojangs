﻿using System;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x020000E6 RID: 230
	public class ValidateInteger : Validate
	{
		// Token: 0x1700015D RID: 349
		// (get) Token: 0x060008FD RID: 2301 RVA: 0x000066D6 File Offset: 0x000048D6
		// (set) Token: 0x060008FE RID: 2302 RVA: 0x000066DE File Offset: 0x000048DE
		public int Min { get; set; }

		// Token: 0x1700015E RID: 350
		// (get) Token: 0x060008FF RID: 2303 RVA: 0x000066E7 File Offset: 0x000048E7
		// (set) Token: 0x06000900 RID: 2304 RVA: 0x000066EF File Offset: 0x000048EF
		public int Max { get; set; }

		// Token: 0x06000901 RID: 2305 RVA: 0x000066F8 File Offset: 0x000048F8
		public ValidateInteger()
		{
			this.Max = int.MaxValue;
		}

		// Token: 0x06000902 RID: 2306 RVA: 0x0000670C File Offset: 0x0000490C
		public ValidateInteger(int Min, int Max)
		{
			this.Max = int.MaxValue;
			this.Min = Min;
			this.Max = Max;
		}

		// Token: 0x06000903 RID: 2307 RVA: 0x0003F7A4 File Offset: 0x0003D9A4
		public override string Validate(string Str)
		{
			string result;
			if (Str.Length > 9)
			{
				result = "请输入一个大小合理的数字！";
			}
			else if (Operators.CompareString((checked((int)Math.Round(ModBase.Val(Str)))).ToString(), Str, true) != 0)
			{
				result = "请输入一个整数！";
			}
			else if (ModBase.Val(Str) > (double)this.Max)
			{
				result = "不可超过 " + Conversions.ToString(this.Max) + "！";
			}
			else if (ModBase.Val(Str) < (double)this.Min)
			{
				result = "不可低于 " + Conversions.ToString(this.Min) + "！";
			}
			else
			{
				result = "";
			}
			return result;
		}

		// Token: 0x0400045D RID: 1117
		[CompilerGenerated]
		private int tokenizerTag;

		// Token: 0x0400045E RID: 1118
		[CompilerGenerated]
		private int definitionTag;
	}
}
