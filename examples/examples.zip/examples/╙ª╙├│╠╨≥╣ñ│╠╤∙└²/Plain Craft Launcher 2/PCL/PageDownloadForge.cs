﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000121 RID: 289
	[DesignerGenerated]
	public class PageDownloadForge : MyPageRight, IComponentConnector
	{
		// Token: 0x06000A7B RID: 2683 RVA: 0x00007265 File Offset: 0x00005465
		public PageDownloadForge()
		{
			base.Initialized += delegate(object sender, EventArgs e)
			{
				this.LoaderInit();
			};
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.Init();
			};
			this.InitializeComponent();
		}

		// Token: 0x06000A7C RID: 2684 RVA: 0x00055B1C File Offset: 0x00053D1C
		private void LoaderInit()
		{
			base.PageLoaderInit(this.Load, this.PanLoad, this.PanMain, this.CardTip, ModDownload.m_WatcherTag, delegate(ModLoader.LoaderBase a0)
			{
				this.Load_OnFinish();
			}, null, true);
		}

		// Token: 0x06000A7D RID: 2685 RVA: 0x00007298 File Offset: 0x00005498
		private void Init()
		{
			this.PanBack.ScrollToHome();
		}

		// Token: 0x06000A7E RID: 2686 RVA: 0x00055B5C File Offset: 0x00053D5C
		private void Load_OnFinish()
		{
			try
			{
				List<string> list = ModBase.Sort<string>(ModDownload.m_WatcherTag.Output.Value, (PageDownloadForge._Closure$__.$IR3-4 == null) ? (PageDownloadForge._Closure$__.$IR3-4 = ((object a0, object a1) => ModMinecraft.VersionSortBoolean(Conversions.ToString(a0), Conversions.ToString(a1)))) : PageDownloadForge._Closure$__.$IR3-4);
				this.PanMain.Children.Clear();
				try
				{
					foreach (string text in list)
					{
						MyCard myCard = new MyCard();
						myCard.Title = text.Replace("_p", " P");
						myCard.Margin = new Thickness(0.0, 0.0, 0.0, 15.0);
						myCard.CustomizeModel(5);
						MyCard myCard2 = myCard;
						StackPanel stackPanel = new StackPanel
						{
							Margin = new Thickness(20.0, 40.0, 18.0, 0.0),
							VerticalAlignment = VerticalAlignment.Top,
							RenderTransform = new TranslateTransform(0.0, 0.0),
							Tag = text
						};
						myCard2.Children.Add(stackPanel);
						myCard2.m_Decorator = stackPanel;
						myCard2.IsSwaped = true;
						this.PanMain.Children.Add(myCard2);
					}
				}
				finally
				{
					List<string>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "可视化版本列表出错", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000A7F RID: 2687 RVA: 0x000072A5 File Offset: 0x000054A5
		public void Forge_Click(MyLoading sender, MouseButtonEventArgs e)
		{
			if (sender.State.LoadingState == MyLoading.MyLoadingState.Error)
			{
				((ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>)sender.State).Start(null, true);
			}
		}

		// Token: 0x06000A80 RID: 2688 RVA: 0x00055D1C File Offset: 0x00053F1C
		public void Forge_StateChanged(MyLoading sender, MyLoading.MyLoadingState newState, MyLoading.MyLoadingState oldState)
		{
			if (newState == MyLoading.MyLoadingState.Stop)
			{
				MyCard myCard = (MyCard)((FrameworkElement)sender.Parent).Parent;
				ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>> loaderTask = (ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>)sender.State;
				NewLateBinding.LateCall(NewLateBinding.LateGet(myCard.m_Decorator, null, "Children", new object[0], null, null, null), null, "Clear", new object[0], null, null, null, true);
				NewLateBinding.LateSet(myCard.m_Decorator, null, "Tag", new object[]
				{
					loaderTask.Output
				}, null, null);
				myCard.CustomizeModel(6);
				myCard.StackInstall();
			}
		}

		// Token: 0x06000A81 RID: 2689 RVA: 0x000072C7 File Offset: 0x000054C7
		public void DownloadStart(MyListItem sender, object e)
		{
			ModDownloadLib.McDownloadForge((ModDownload.DlForgeVersionEntry)sender.Tag);
		}

		// Token: 0x06000A82 RID: 2690 RVA: 0x000072D9 File Offset: 0x000054D9
		private void BtnWeb_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://files.minecraftforge.net");
		}

		// Token: 0x1700016E RID: 366
		// (get) Token: 0x06000A83 RID: 2691 RVA: 0x000072E5 File Offset: 0x000054E5
		// (set) Token: 0x06000A84 RID: 2692 RVA: 0x000072ED File Offset: 0x000054ED
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x1700016F RID: 367
		// (get) Token: 0x06000A85 RID: 2693 RVA: 0x000072F6 File Offset: 0x000054F6
		// (set) Token: 0x06000A86 RID: 2694 RVA: 0x000072FE File Offset: 0x000054FE
		internal virtual MyCard CardTip { get; set; }

		// Token: 0x17000170 RID: 368
		// (get) Token: 0x06000A87 RID: 2695 RVA: 0x00007307 File Offset: 0x00005507
		// (set) Token: 0x06000A88 RID: 2696 RVA: 0x0000730F File Offset: 0x0000550F
		internal virtual TextBlock LabConnect { get; set; }

		// Token: 0x17000171 RID: 369
		// (get) Token: 0x06000A89 RID: 2697 RVA: 0x00007318 File Offset: 0x00005518
		// (set) Token: 0x06000A8A RID: 2698 RVA: 0x00055DB4 File Offset: 0x00053FB4
		internal virtual MyButton BtnWeb
		{
			[CompilerGenerated]
			get
			{
				return this.m_ObserverTag;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnWeb_Click);
				MyButton observerTag = this.m_ObserverTag;
				if (observerTag != null)
				{
					observerTag.RevertResolver(obj);
				}
				this.m_ObserverTag = value;
				observerTag = this.m_ObserverTag;
				if (observerTag != null)
				{
					observerTag.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000172 RID: 370
		// (get) Token: 0x06000A8B RID: 2699 RVA: 0x00007320 File Offset: 0x00005520
		// (set) Token: 0x06000A8C RID: 2700 RVA: 0x00007328 File Offset: 0x00005528
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x17000173 RID: 371
		// (get) Token: 0x06000A8D RID: 2701 RVA: 0x00007331 File Offset: 0x00005531
		// (set) Token: 0x06000A8E RID: 2702 RVA: 0x00007339 File Offset: 0x00005539
		internal virtual MyCard PanLoad { get; set; }

		// Token: 0x17000174 RID: 372
		// (get) Token: 0x06000A8F RID: 2703 RVA: 0x00007342 File Offset: 0x00005542
		// (set) Token: 0x06000A90 RID: 2704 RVA: 0x0000734A File Offset: 0x0000554A
		internal virtual MyLoading Load { get; set; }

		// Token: 0x06000A91 RID: 2705 RVA: 0x00055DF8 File Offset: 0x00053FF8
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_ConsumerTag)
			{
				this.m_ConsumerTag = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagedownload/pagedownloadforge.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000A92 RID: 2706 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000A93 RID: 2707 RVA: 0x00055E28 File Offset: 0x00054028
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.CardTip = (MyCard)target;
				return;
			}
			if (connectionId == 3)
			{
				this.LabConnect = (TextBlock)target;
				return;
			}
			if (connectionId == 4)
			{
				this.BtnWeb = (MyButton)target;
				return;
			}
			if (connectionId == 5)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			if (connectionId == 6)
			{
				this.PanLoad = (MyCard)target;
				return;
			}
			if (connectionId == 7)
			{
				this.Load = (MyLoading)target;
				return;
			}
			this.m_ConsumerTag = true;
		}

		// Token: 0x040005A3 RID: 1443
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyScrollViewer databaseTag;

		// Token: 0x040005A4 RID: 1444
		[CompilerGenerated]
		[AccessedThroughProperty("CardTip")]
		private MyCard m_CallbackTag;

		// Token: 0x040005A5 RID: 1445
		[CompilerGenerated]
		[AccessedThroughProperty("LabConnect")]
		private TextBlock advisorTag;

		// Token: 0x040005A6 RID: 1446
		[AccessedThroughProperty("BtnWeb")]
		[CompilerGenerated]
		private MyButton m_ObserverTag;

		// Token: 0x040005A7 RID: 1447
		[AccessedThroughProperty("PanMain")]
		[CompilerGenerated]
		private StackPanel m_SingletonTag;

		// Token: 0x040005A8 RID: 1448
		[CompilerGenerated]
		[AccessedThroughProperty("PanLoad")]
		private MyCard m_ContextTag;

		// Token: 0x040005A9 RID: 1449
		[CompilerGenerated]
		[AccessedThroughProperty("Load")]
		private MyLoading _CollectionTag;

		// Token: 0x040005AA RID: 1450
		private bool m_ConsumerTag;
	}
}
