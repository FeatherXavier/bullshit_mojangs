﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000145 RID: 325
	[DesignerGenerated]
	public class PageLaunchRight : MyPageRight, IComponentConnector
	{
		// Token: 0x06000CBE RID: 3262 RVA: 0x00062A60 File Offset: 0x00060C60
		public PageLaunchRight()
		{
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.Init();
			};
			this.testsComparator = "";
			this.m_StrategyComparator = null;
			this._RulesComparator = false;
			this.workerComparator = true;
			this.InitializeComponent();
		}

		// Token: 0x06000CBF RID: 3263 RVA: 0x00062AAC File Offset: 0x00060CAC
		private void Init()
		{
			this.PanBack.ScrollToHome();
			this.PanLog.Visibility = (ModBase._EventState ? Visibility.Visible : Visibility.Collapsed);
			if (this.workerComparator)
			{
				this.workerComparator = false;
				this.RefreshCustom();
			}
			this.PanHint.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000CC0 RID: 3264 RVA: 0x00062AFC File Offset: 0x00060CFC
		private void RefreshCustom()
		{
			if (this._RulesComparator)
			{
				this.workerComparator = true;
				return;
			}
			try
			{
				this._RulesComparator = true;
				this.PanCustom.Children.Clear();
				ModBase.RunInNewThread(delegate
				{
					string FileContent = "";
					object left = ModBase._ParamsState.Get("UiCustomType", null);
					if (!Operators.ConditionalCompareObjectEqual(left, 0, true))
					{
						if (Operators.ConditionalCompareObjectEqual(left, 1, true))
						{
							FileContent = ModBase.ReadFile(ModBase.Path + "PCL\\Custom.xaml");
							ModBase.Log("[System] 尝试从本地文件读取主页自定义数据（" + Conversions.ToString(FileContent.Length) + "）", ModBase.LogLevel.Normal, "出现错误");
						}
						else if (Operators.ConditionalCompareObjectEqual(left, 2, true))
						{
							try
							{
								string text = Conversions.ToString(ModBase._ParamsState.Get("UiCustomNet", null));
								if (Operators.CompareString(text, this.m_StrategyComparator, true) == 0)
								{
									FileContent = this.testsComparator;
									ModBase.Log("[System] 尝试缓存加载主页自定义数据（" + Conversions.ToString(FileContent.Length) + "）", ModBase.LogLevel.Normal, "出现错误");
								}
								else if (!string.IsNullOrWhiteSpace(text))
								{
									ModBase.Log("[System] 开始从网络读取主页自定义数据（" + text + "）", ModBase.LogLevel.Normal, "出现错误");
									FileContent = Conversions.ToString(ModNet.NetGetCodeByRequestRetry(text, null, "", false));
									ModBase.Log("[System] 尝试从网络读取主页自定义数据（" + Conversions.ToString(FileContent.Length) + "）", ModBase.LogLevel.Normal, "出现错误");
								}
								this.m_StrategyComparator = text;
								this.testsComparator = FileContent;
							}
							catch (Exception ex2)
							{
								ModBase.Log(ex2, "获取 PCL2 主页自定义信息失败", ModBase.LogLevel.Msgbox, "出现错误");
								this.m_StrategyComparator = "";
							}
						}
					}
					if (Operators.CompareString(FileContent, "", true) == 0)
					{
						this._RulesComparator = false;
						return;
					}
					FileContent = "<StackPanel xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\" xmlns:local=\"clr-namespace:PCL;assembly=Plain Craft Launcher 2\">" + FileContent + "</StackPanel>";
					FileContent = FileContent.Replace("{path}", ModBase.Path);
					ModBase.RunInUi(delegate()
					{
						try
						{
							ModBase.Log("[System] 加载主页自定义数据", ModBase.LogLevel.Normal, "出现错误");
							this.PanCustom.Children.Add((UIElement)ModBase.GetObjectFromXML(FileContent));
							this._RulesComparator = false;
						}
						catch (Exception ex3)
						{
							this._RulesComparator = false;
							ModBase.Log("[System] 自定义信息内容：\r\n" + FileContent, ModBase.LogLevel.Normal, "出现错误");
							if (ModMain.MyMsgBox(ex3.Message, "加载自定义主页失败", "重试", "取消", "", false, true, false) == 1)
							{
								this.m_StrategyComparator = null;
								this.testsComparator = "";
								this.RefreshCustom();
							}
						}
					}, false);
				}, "主页自定义刷新", ThreadPriority.Normal);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "加载 PCL2 主页自定义信息失败", ModBase.LogLevel.Msgbox, "出现错误");
				this._RulesComparator = false;
			}
		}

		// Token: 0x06000CC1 RID: 3265 RVA: 0x00062B84 File Offset: 0x00060D84
		public void ForceRefresh(bool ShowHint = true)
		{
			this.workerComparator = true;
			this.testsComparator = "";
			this.m_StrategyComparator = null;
			if (ShowHint)
			{
				ModMain.Hint("已刷新主页！", ModMain.HintType.Finish, true);
			}
			ModMain.m_CollectionAccount.PageChange(FormMain.PageType.Launch, FormMain.PageSubType.Default);
			this.Init();
		}

		// Token: 0x06000CC2 RID: 3266 RVA: 0x00062BD0 File Offset: 0x00060DD0
		private void BtnMsStart_Click()
		{
			ModMain.MyMsgBox("在迁移过程中，你可能需要设置你的档案信息。\r\n在输入年龄或生日时，请注意让你的年龄大于 18 岁，否则可能导致无法登录！", "迁移提示", "继续", "", "", false, true, true);
			ModBase.OpenWebsite("https://www.minecraft.net/zh-hans/account-security");
		}

		// Token: 0x06000CC3 RID: 3267 RVA: 0x00008634 File Offset: 0x00006834
		private void BtnMsFaq_Click()
		{
			ModBase.OpenWebsite("https://www.mcbbs.net/thread-1129357-1-9.html");
		}

		// Token: 0x170001E2 RID: 482
		// (get) Token: 0x06000CC4 RID: 3268 RVA: 0x00008640 File Offset: 0x00006840
		// (set) Token: 0x06000CC5 RID: 3269 RVA: 0x00008648 File Offset: 0x00006848
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x170001E3 RID: 483
		// (get) Token: 0x06000CC6 RID: 3270 RVA: 0x00008651 File Offset: 0x00006851
		// (set) Token: 0x06000CC7 RID: 3271 RVA: 0x00008659 File Offset: 0x00006859
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x170001E4 RID: 484
		// (get) Token: 0x06000CC8 RID: 3272 RVA: 0x00008662 File Offset: 0x00006862
		// (set) Token: 0x06000CC9 RID: 3273 RVA: 0x0000866A File Offset: 0x0000686A
		internal virtual StackPanel PanCustom { get; set; }

		// Token: 0x170001E5 RID: 485
		// (get) Token: 0x06000CCA RID: 3274 RVA: 0x00008673 File Offset: 0x00006873
		// (set) Token: 0x06000CCB RID: 3275 RVA: 0x0000867B File Offset: 0x0000687B
		internal virtual MyCard PanMs { get; set; }

		// Token: 0x170001E6 RID: 486
		// (get) Token: 0x06000CCC RID: 3276 RVA: 0x00008684 File Offset: 0x00006884
		// (set) Token: 0x06000CCD RID: 3277 RVA: 0x00062C0C File Offset: 0x00060E0C
		internal virtual MyButton BtnMsStart
		{
			[CompilerGenerated]
			get
			{
				return this._RuleComparator;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.BtnMsStart_Click();
				};
				MyButton ruleComparator = this._RuleComparator;
				if (ruleComparator != null)
				{
					ruleComparator.RevertResolver(obj);
				}
				this._RuleComparator = value;
				ruleComparator = this._RuleComparator;
				if (ruleComparator != null)
				{
					ruleComparator.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001E7 RID: 487
		// (get) Token: 0x06000CCE RID: 3278 RVA: 0x0000868C File Offset: 0x0000688C
		// (set) Token: 0x06000CCF RID: 3279 RVA: 0x00062C50 File Offset: 0x00060E50
		internal virtual MyButton BtnMsFaq
		{
			[CompilerGenerated]
			get
			{
				return this._MerchantComparator;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.BtnMsFaq_Click();
				};
				MyButton merchantComparator = this._MerchantComparator;
				if (merchantComparator != null)
				{
					merchantComparator.RevertResolver(obj);
				}
				this._MerchantComparator = value;
				merchantComparator = this._MerchantComparator;
				if (merchantComparator != null)
				{
					merchantComparator.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001E8 RID: 488
		// (get) Token: 0x06000CD0 RID: 3280 RVA: 0x00008694 File Offset: 0x00006894
		// (set) Token: 0x06000CD1 RID: 3281 RVA: 0x0000869C File Offset: 0x0000689C
		internal virtual MyCard PanHint { get; set; }

		// Token: 0x170001E9 RID: 489
		// (get) Token: 0x06000CD2 RID: 3282 RVA: 0x000086A5 File Offset: 0x000068A5
		// (set) Token: 0x06000CD3 RID: 3283 RVA: 0x000086AD File Offset: 0x000068AD
		internal virtual TextBlock LabHint1 { get; set; }

		// Token: 0x170001EA RID: 490
		// (get) Token: 0x06000CD4 RID: 3284 RVA: 0x000086B6 File Offset: 0x000068B6
		// (set) Token: 0x06000CD5 RID: 3285 RVA: 0x000086BE File Offset: 0x000068BE
		internal virtual TextBlock LabHint2 { get; set; }

		// Token: 0x170001EB RID: 491
		// (get) Token: 0x06000CD6 RID: 3286 RVA: 0x000086C7 File Offset: 0x000068C7
		// (set) Token: 0x06000CD7 RID: 3287 RVA: 0x000086CF File Offset: 0x000068CF
		internal virtual MyCard PanLog { get; set; }

		// Token: 0x170001EC RID: 492
		// (get) Token: 0x06000CD8 RID: 3288 RVA: 0x000086D8 File Offset: 0x000068D8
		// (set) Token: 0x06000CD9 RID: 3289 RVA: 0x000086E0 File Offset: 0x000068E0
		internal virtual TextBlock LabLog { get; set; }

		// Token: 0x06000CDA RID: 3290 RVA: 0x00062C94 File Offset: 0x00060E94
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_AnnotationComparator)
			{
				this.m_AnnotationComparator = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagelaunch/pagelaunchright.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000CDB RID: 3291 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000CDC RID: 3292 RVA: 0x00062CC4 File Offset: 0x00060EC4
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			if (connectionId == 3)
			{
				this.PanCustom = (StackPanel)target;
				return;
			}
			if (connectionId == 4)
			{
				this.PanMs = (MyCard)target;
				return;
			}
			if (connectionId == 5)
			{
				this.BtnMsStart = (MyButton)target;
				return;
			}
			if (connectionId == 6)
			{
				this.BtnMsFaq = (MyButton)target;
				return;
			}
			if (connectionId == 7)
			{
				this.PanHint = (MyCard)target;
				return;
			}
			if (connectionId == 8)
			{
				this.LabHint1 = (TextBlock)target;
				return;
			}
			if (connectionId == 9)
			{
				this.LabHint2 = (TextBlock)target;
				return;
			}
			if (connectionId == 10)
			{
				this.PanLog = (MyCard)target;
				return;
			}
			if (connectionId == 11)
			{
				this.LabLog = (TextBlock)target;
				return;
			}
			this.m_AnnotationComparator = true;
		}

		// Token: 0x0400067D RID: 1661
		private string testsComparator;

		// Token: 0x0400067E RID: 1662
		private string m_StrategyComparator;

		// Token: 0x0400067F RID: 1663
		private bool _RulesComparator;

		// Token: 0x04000680 RID: 1664
		public bool workerComparator;

		// Token: 0x04000681 RID: 1665
		[CompilerGenerated]
		[AccessedThroughProperty("PanBack")]
		private MyScrollViewer _DicComparator;

		// Token: 0x04000682 RID: 1666
		[CompilerGenerated]
		[AccessedThroughProperty("PanMain")]
		private StackPanel _ConfigurationComparator;

		// Token: 0x04000683 RID: 1667
		[CompilerGenerated]
		[AccessedThroughProperty("PanCustom")]
		private StackPanel m_ConfigComparator;

		// Token: 0x04000684 RID: 1668
		[AccessedThroughProperty("PanMs")]
		[CompilerGenerated]
		private MyCard _ManagerComparator;

		// Token: 0x04000685 RID: 1669
		[AccessedThroughProperty("BtnMsStart")]
		[CompilerGenerated]
		private MyButton _RuleComparator;

		// Token: 0x04000686 RID: 1670
		[CompilerGenerated]
		[AccessedThroughProperty("BtnMsFaq")]
		private MyButton _MerchantComparator;

		// Token: 0x04000687 RID: 1671
		[AccessedThroughProperty("PanHint")]
		[CompilerGenerated]
		private MyCard m_ExporterComparator;

		// Token: 0x04000688 RID: 1672
		[AccessedThroughProperty("LabHint1")]
		[CompilerGenerated]
		private TextBlock m_QueueComparator;

		// Token: 0x04000689 RID: 1673
		[CompilerGenerated]
		[AccessedThroughProperty("LabHint2")]
		private TextBlock _GlobalComparator;

		// Token: 0x0400068A RID: 1674
		[AccessedThroughProperty("PanLog")]
		[CompilerGenerated]
		private MyCard m_ListComparator;

		// Token: 0x0400068B RID: 1675
		[AccessedThroughProperty("LabLog")]
		[CompilerGenerated]
		private TextBlock methodComparator;

		// Token: 0x0400068C RID: 1676
		private bool m_AnnotationComparator;
	}
}
