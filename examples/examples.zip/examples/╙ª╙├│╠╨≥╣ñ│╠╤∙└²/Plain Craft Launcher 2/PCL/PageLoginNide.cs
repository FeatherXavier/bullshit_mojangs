﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200012E RID: 302
	[DesignerGenerated]
	public class PageLoginNide : Grid, IComponentConnector
	{
		// Token: 0x06000B7B RID: 2939 RVA: 0x00007AE9 File Offset: 0x00005CE9
		public PageLoginNide()
		{
			this._ParameterComparator = true;
			this.InitializeComponent();
		}

		// Token: 0x06000B7C RID: 2940 RVA: 0x0005B218 File Offset: 0x00059418
		public void Reload(bool KeepInput)
		{
			this.CheckRemember.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("LoginRemember", null));
			if (KeepInput && !this._ParameterComparator)
			{
				string text = this.ComboName.Text;
				this.ComboName.ItemsSource = (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LoginNideEmail", null), "", true) ? null : ModBase._ParamsState.Get("LoginNideEmail", null).ToString().Split(new char[]
				{
					'¨'
				}));
				this.ComboName.Text = text;
			}
			else if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LoginNideEmail", null), "", true))
			{
				this.ComboName.ItemsSource = null;
			}
			else
			{
				this.ComboName.ItemsSource = ModBase._ParamsState.Get("LoginNideEmail", null).ToString().Split(new char[]
				{
					'¨'
				});
				this.ComboName.Text = ModBase._ParamsState.Get("LoginNideEmail", null).ToString().Split(new char[]
				{
					'¨'
				})[0];
				if (Conversions.ToBoolean(ModBase._ParamsState.Get("LoginRemember", null)))
				{
					this.TextPass.Password = ModBase._ParamsState.Get("LoginNidePass", null).ToString().Split(new char[]
					{
						'¨'
					})[0].Trim();
				}
			}
			this._ParameterComparator = false;
		}

		// Token: 0x06000B7D RID: 2941 RVA: 0x0005B3B0 File Offset: 0x000595B0
		public static ModLaunch.McLoginServer GetLoginData()
		{
			string str = Conversions.ToString(Information.IsNothing(ModMinecraft.SetupResolver()) ? ModBase._ParamsState.Get("CacheNideServer", null) : ModBase._ParamsState.Get("VersionServerNide", ModMinecraft.SetupResolver()));
			ModLaunch.McLoginServer result;
			if (ModMain._ProxyAccount == null)
			{
				result = new ModLaunch.McLoginServer(ModLaunch.McLoginType.Nide)
				{
					m_ErrorProccesor = "Nide",
					m_InterpreterProccesor = "",
					_ParserProccesor = "",
					_ExceptionProccesor = "统一通行证",
					Type = ModLaunch.McLoginType.Nide,
					_StubProccesor = "https://auth2.nide8.com:233/" + str + "/authserver"
				};
			}
			else
			{
				result = new ModLaunch.McLoginServer(ModLaunch.McLoginType.Nide)
				{
					m_ErrorProccesor = "Nide",
					m_InterpreterProccesor = ModMain._ProxyAccount.ComboName.Text.Replace("¨", "").Trim(),
					_ParserProccesor = ModMain._ProxyAccount.TextPass.Password.Replace("¨", "").Trim(),
					_ExceptionProccesor = "统一通行证",
					Type = ModLaunch.McLoginType.Nide,
					_StubProccesor = "https://auth2.nide8.com:233/" + str + "/authserver"
				};
			}
			return result;
		}

		// Token: 0x06000B7E RID: 2942 RVA: 0x0002BB18 File Offset: 0x00029D18
		public static string IsVaild(ModLaunch.McLoginServer LoginData)
		{
			string result;
			if (Operators.CompareString(LoginData.m_InterpreterProccesor, "", true) == 0)
			{
				result = "账号不能为空！";
			}
			else if (Operators.CompareString(LoginData._ParserProccesor, "", true) == 0)
			{
				result = "密码不能为空！";
			}
			else
			{
				result = "";
			}
			return result;
		}

		// Token: 0x06000B7F RID: 2943 RVA: 0x00007AFF File Offset: 0x00005CFF
		public string IsVaild()
		{
			return PageLoginNide.IsVaild(PageLoginNide.GetLoginData());
		}

		// Token: 0x06000B80 RID: 2944 RVA: 0x0005B4E0 File Offset: 0x000596E0
		private void ComboName_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (Operators.ConditionalCompareObjectEqual(NewLateBinding.LateGet(sender, null, "Text", new object[0], null, null, null), "", true))
			{
				this.TextPass.Password = "";
			}
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set("CacheNideAccess", "", false, null);
			}
		}

		// Token: 0x06000B81 RID: 2945 RVA: 0x00007B0B File Offset: 0x00005D0B
		private void TextPass_PasswordChanged(object sender, RoutedEventArgs e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set("CacheNideAccess", "", false, null);
			}
		}

		// Token: 0x06000B82 RID: 2946 RVA: 0x0005B53C File Offset: 0x0005973C
		private void ComboName_SelectionChanged(MyComboBox sender, SelectionChangedEventArgs e)
		{
			if (Conversions.ToBoolean(sender.SelectedIndex == -1 || Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("LoginRemember", null)))))
			{
				this.TextPass.Password = "";
				return;
			}
			this.TextPass.Password = ModBase._ParamsState.Get("LoginNidePass", null).ToString().Split(new char[]
			{
				'¨'
			})[sender.SelectedIndex].Trim();
		}

		// Token: 0x06000B83 RID: 2947 RVA: 0x00004F3C File Offset: 0x0000313C
		private void CheckBoxChange(MyCheckBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.Checked, false, null);
			}
		}

		// Token: 0x06000B84 RID: 2948 RVA: 0x00007B2A File Offset: 0x00005D2A
		private void ComboName_TextChanged()
		{
			this.BtnLink.Content = ((Operators.CompareString(this.ComboName.Text, "", true) == 0) ? "注册账号" : "找回密码");
		}

		// Token: 0x06000B85 RID: 2949 RVA: 0x0005B5CC File Offset: 0x000597CC
		private void Btn_Click(object sender, EventArgs e)
		{
			if (Operators.ConditionalCompareObjectEqual(this.BtnLink.Content, "注册账号", true))
			{
				ModBase.OpenWebsite(Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("https://login2.nide8.com:233/", ModBase._ParamsState.Get("VersionServerNide", ModMinecraft.SetupResolver())), "/register")));
				return;
			}
			ModBase.OpenWebsite("https://login2.nide8.com:233/account/login");
		}

		// Token: 0x170001A8 RID: 424
		// (get) Token: 0x06000B86 RID: 2950 RVA: 0x00007B5B File Offset: 0x00005D5B
		// (set) Token: 0x06000B87 RID: 2951 RVA: 0x0005B630 File Offset: 0x00059830
		internal virtual MyComboBox ComboName
		{
			[CompilerGenerated]
			get
			{
				return this.authenticationComparator;
			}
			[CompilerGenerated]
			set
			{
				MyComboBox.TextChangedEventHandler obj = new MyComboBox.TextChangedEventHandler(this.ComboName_TextChanged);
				SelectionChangedEventHandler value2 = delegate(object sender, SelectionChangedEventArgs e)
				{
					this.ComboName_SelectionChanged((MyComboBox)sender, e);
				};
				MyComboBox.TextChangedEventHandler obj2 = delegate(object sender, TextChangedEventArgs e)
				{
					this.ComboName_TextChanged();
				};
				MyComboBox myComboBox = this.authenticationComparator;
				if (myComboBox != null)
				{
					myComboBox.VisitModel(obj);
					myComboBox.SelectionChanged -= value2;
					myComboBox.VisitModel(obj2);
				}
				this.authenticationComparator = value;
				myComboBox = this.authenticationComparator;
				if (myComboBox != null)
				{
					myComboBox.GetModel(obj);
					myComboBox.SelectionChanged += value2;
					myComboBox.GetModel(obj2);
				}
			}
		}

		// Token: 0x170001A9 RID: 425
		// (get) Token: 0x06000B88 RID: 2952 RVA: 0x00007B63 File Offset: 0x00005D63
		// (set) Token: 0x06000B89 RID: 2953 RVA: 0x0005B6AC File Offset: 0x000598AC
		internal virtual PasswordBox TextPass
		{
			[CompilerGenerated]
			get
			{
				return this._ReponseComparator;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = new RoutedEventHandler(this.TextPass_PasswordChanged);
				PasswordBox reponseComparator = this._ReponseComparator;
				if (reponseComparator != null)
				{
					reponseComparator.PasswordChanged -= value2;
				}
				this._ReponseComparator = value;
				reponseComparator = this._ReponseComparator;
				if (reponseComparator != null)
				{
					reponseComparator.PasswordChanged += value2;
				}
			}
		}

		// Token: 0x170001AA RID: 426
		// (get) Token: 0x06000B8A RID: 2954 RVA: 0x00007B6B File Offset: 0x00005D6B
		// (set) Token: 0x06000B8B RID: 2955 RVA: 0x0005B6F0 File Offset: 0x000598F0
		internal virtual MyCheckBox CheckRemember
		{
			[CompilerGenerated]
			get
			{
				return this.containerComparator;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = delegate(object a0, bool a1)
				{
					this.CheckBoxChange((MyCheckBox)a0, a1);
				};
				MyCheckBox myCheckBox = this.containerComparator;
				if (myCheckBox != null)
				{
					myCheckBox.StopTag(obj);
				}
				this.containerComparator = value;
				myCheckBox = this.containerComparator;
				if (myCheckBox != null)
				{
					myCheckBox.CloneTag(obj);
				}
			}
		}

		// Token: 0x170001AB RID: 427
		// (get) Token: 0x06000B8C RID: 2956 RVA: 0x00007B73 File Offset: 0x00005D73
		// (set) Token: 0x06000B8D RID: 2957 RVA: 0x0005B734 File Offset: 0x00059934
		internal virtual MyTextButton BtnLink
		{
			[CompilerGenerated]
			get
			{
				return this.m_CodeComparator;
			}
			[CompilerGenerated]
			set
			{
				MyTextButton.ClickEventHandler obj = new MyTextButton.ClickEventHandler(this.Btn_Click);
				MyTextButton codeComparator = this.m_CodeComparator;
				if (codeComparator != null)
				{
					codeComparator.TestRepository(obj);
				}
				this.m_CodeComparator = value;
				codeComparator = this.m_CodeComparator;
				if (codeComparator != null)
				{
					codeComparator.ResolveRepository(obj);
				}
			}
		}

		// Token: 0x06000B8E RID: 2958 RVA: 0x0005B778 File Offset: 0x00059978
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this._TokenizerComparator)
			{
				this._TokenizerComparator = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagelaunch/pageloginnide.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000B8F RID: 2959 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000B90 RID: 2960 RVA: 0x0005B7A8 File Offset: 0x000599A8
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.ComboName = (MyComboBox)target;
				return;
			}
			if (connectionId == 2)
			{
				this.TextPass = (PasswordBox)target;
				return;
			}
			if (connectionId == 3)
			{
				this.CheckRemember = (MyCheckBox)target;
				return;
			}
			if (connectionId == 4)
			{
				this.BtnLink = (MyTextButton)target;
				return;
			}
			this._TokenizerComparator = true;
		}

		// Token: 0x040005F6 RID: 1526
		private bool _ParameterComparator;

		// Token: 0x040005F7 RID: 1527
		[AccessedThroughProperty("ComboName")]
		[CompilerGenerated]
		private MyComboBox authenticationComparator;

		// Token: 0x040005F8 RID: 1528
		[AccessedThroughProperty("TextPass")]
		[CompilerGenerated]
		private PasswordBox _ReponseComparator;

		// Token: 0x040005F9 RID: 1529
		[AccessedThroughProperty("CheckRemember")]
		[CompilerGenerated]
		private MyCheckBox containerComparator;

		// Token: 0x040005FA RID: 1530
		[CompilerGenerated]
		[AccessedThroughProperty("BtnLink")]
		private MyTextButton m_CodeComparator;

		// Token: 0x040005FB RID: 1531
		private bool _TokenizerComparator;
	}
}
