﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic.FileIO;

namespace PCL
{
	// Token: 0x0200008B RID: 139
	[DesignerGenerated]
	public class MyCfItem : Grid, IComponentConnector
	{
		// Token: 0x060003EE RID: 1006 RVA: 0x00025600 File Offset: 0x00023800
		public MyCfItem()
		{
			base.PreviewMouseLeftButtonUp += this.Button_MouseUp;
			base.PreviewMouseLeftButtonDown += this.Button_MouseDown;
			base.MouseLeave += new MouseEventHandler(this.Button_MouseLeave);
			base.PreviewMouseLeftButtonUp += new MouseButtonEventHandler(this.Button_MouseLeave);
			base.MouseEnter += new MouseEventHandler(this.RefreshColor);
			base.MouseLeave += new MouseEventHandler(this.RefreshColor);
			base.MouseLeftButtonDown += new MouseButtonEventHandler(this.RefreshColor);
			base.MouseLeftButtonUp += new MouseButtonEventHandler(this.RefreshColor);
			this.threadWrapper = ModBase.GetUuid();
			this.connectionWrapper = "";
			this.m_SchemaWrapper = false;
			this.m_DatabaseWrapper = null;
			this.advisorWrapper = true;
			this.InitializeComponent();
		}

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x060003EF RID: 1007 RVA: 0x0000409D File Offset: 0x0000229D
		// (set) Token: 0x060003F0 RID: 1008 RVA: 0x000256D8 File Offset: 0x000238D8
		public string Logo
		{
			get
			{
				return this.connectionWrapper;
			}
			set
			{
				if (Operators.CompareString(this.connectionWrapper, value, true) != 0 && value != null)
				{
					this.connectionWrapper = value;
					string FileAddress = ModBase.attributeState + "CFLogo\\" + Conversions.ToString(ModBase.GetHash(this.connectionWrapper)) + ".png";
					try
					{
						if (this.connectionWrapper.ToLower().StartsWith("http"))
						{
							if (File.Exists(FileAddress))
							{
								this.PathLogo.Source = new MyBitmap(FileAddress);
							}
							else
							{
								this.PathLogo.Source = new MyBitmap("pack://application:,,,/images/Icons/NoIcon.png");
								ModBase.RunInNewThread(delegate
								{
									this.LogoLoader(FileAddress);
								}, "CurseForge Logo Loader " + Conversions.ToString(this.threadWrapper) + "#", ThreadPriority.BelowNormal);
							}
						}
						else
						{
							this.PathLogo.Source = new MyBitmap(this.connectionWrapper);
						}
					}
					catch (IOException ex)
					{
						ModBase.Log(ex, "加载 CurseForge 工程图标时读取失败（" + FileAddress + "）", ModBase.LogLevel.Debug, "出现错误");
					}
					catch (ArgumentException ex2)
					{
						ModBase.Log(ex2, "可视化 CurseForge 工程图标失败（" + FileAddress + "）", ModBase.LogLevel.Debug, "出现错误");
						try
						{
							File.Delete(FileAddress);
							ModBase.Log("[Download] 已清理损坏的 CurseForge 工程图标：" + FileAddress, ModBase.LogLevel.Normal, "出现错误");
						}
						catch (Exception ex3)
						{
							ModBase.Log(ex3, "清理损坏的 CurseForge 工程图标缓存失败（" + FileAddress + "）", ModBase.LogLevel.Hint, "出现错误");
						}
					}
					catch (Exception ex4)
					{
						ModBase.Log(ex4, "加载 CurseForge 工程图标失败（" + value + "）", ModBase.LogLevel.Debug, "出现错误");
					}
				}
			}
		}

		// Token: 0x060003F1 RID: 1009 RVA: 0x00025900 File Offset: 0x00023B00
		private void LogoLoader(string Address)
		{
			MyCfItem._Closure$__6-0 CS$<>8__locals1 = new MyCfItem._Closure$__6-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Me = this;
			CS$<>8__locals1.$VB$Local_Address = Address;
			bool flag = false;
			CS$<>8__locals1.$VB$Local_DownloadEnd = Conversions.ToString(ModBase.GetUuid());
			for (;;)
			{
				try
				{
					ModNet.NetDownload(this.connectionWrapper, CS$<>8__locals1.$VB$Local_Address + CS$<>8__locals1.$VB$Local_DownloadEnd);
					ModBase.RunInUiWait(delegate
					{
						try
						{
							if (Operators.CompareString(CS$<>8__locals1.$VB$Local_Address, ModBase.attributeState + "CFLogo\\" + Conversions.ToString(ModBase.GetHash(CS$<>8__locals1.$VB$Me.connectionWrapper)) + ".png", true) == 0)
							{
								CS$<>8__locals1.$VB$Me.PathLogo.Source = new MyBitmap(CS$<>8__locals1.$VB$Local_Address + CS$<>8__locals1.$VB$Local_DownloadEnd);
							}
						}
						catch (Exception ex2)
						{
							ModBase.Log(ex2, "读取 CurseForge 工程图标失败（" + CS$<>8__locals1.$VB$Local_Address + "）", ModBase.LogLevel.Hint, "出现错误");
						}
					});
					if (File.Exists(CS$<>8__locals1.$VB$Local_Address))
					{
						File.Delete(CS$<>8__locals1.$VB$Local_Address + CS$<>8__locals1.$VB$Local_DownloadEnd);
					}
					else
					{
						FileSystem.MoveFile(CS$<>8__locals1.$VB$Local_Address + CS$<>8__locals1.$VB$Local_DownloadEnd, CS$<>8__locals1.$VB$Local_Address);
					}
					break;
				}
				catch (Exception ex)
				{
					if (flag)
					{
						ModBase.Log(ex, "下载 CurseForge 工程图标失败", ModBase.LogLevel.Debug, "出现错误");
						break;
					}
					flag = true;
				}
			}
		}

		// Token: 0x060003F2 RID: 1010 RVA: 0x000259EC File Offset: 0x00023BEC
		[CompilerGenerated]
		public void CalculateRepository(MyCfItem.ClickEventHandler obj)
		{
			MyCfItem.ClickEventHandler clickEventHandler = this._CustomerWrapper;
			MyCfItem.ClickEventHandler clickEventHandler2;
			do
			{
				clickEventHandler2 = clickEventHandler;
				MyCfItem.ClickEventHandler value = (MyCfItem.ClickEventHandler)Delegate.Combine(clickEventHandler2, obj);
				clickEventHandler = Interlocked.CompareExchange<MyCfItem.ClickEventHandler>(ref this._CustomerWrapper, value, clickEventHandler2);
			}
			while (clickEventHandler != clickEventHandler2);
		}

		// Token: 0x060003F3 RID: 1011 RVA: 0x00025A24 File Offset: 0x00023C24
		[CompilerGenerated]
		public void ComputeRepository(MyCfItem.ClickEventHandler obj)
		{
			MyCfItem.ClickEventHandler clickEventHandler = this._CustomerWrapper;
			MyCfItem.ClickEventHandler clickEventHandler2;
			do
			{
				clickEventHandler2 = clickEventHandler;
				MyCfItem.ClickEventHandler value = (MyCfItem.ClickEventHandler)Delegate.Remove(clickEventHandler2, obj);
				clickEventHandler = Interlocked.CompareExchange<MyCfItem.ClickEventHandler>(ref this._CustomerWrapper, value, clickEventHandler2);
			}
			while (clickEventHandler != clickEventHandler2);
		}

		// Token: 0x060003F4 RID: 1012 RVA: 0x00025A5C File Offset: 0x00023C5C
		private void Button_MouseUp(object sender, MouseButtonEventArgs e)
		{
			if (this.m_SchemaWrapper)
			{
				MyCfItem.ClickEventHandler customerWrapper = this._CustomerWrapper;
				if (customerWrapper != null)
				{
					customerWrapper(RuntimeHelpers.GetObjectValue(sender), e);
				}
				if (!e.Handled)
				{
					ModBase.Log("[Control] 按下 CurseForge 工程列表项：" + this.LabTitle.Text, ModBase.LogLevel.Normal, "出现错误");
				}
			}
		}

		// Token: 0x060003F5 RID: 1013 RVA: 0x000040A5 File Offset: 0x000022A5
		private void Button_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (base.IsMouseOver)
			{
				this.m_SchemaWrapper = true;
			}
		}

		// Token: 0x060003F6 RID: 1014 RVA: 0x000040B6 File Offset: 0x000022B6
		private void Button_MouseLeave(object sender, object e)
		{
			this.m_SchemaWrapper = false;
		}

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x060003F7 RID: 1015 RVA: 0x00025AB0 File Offset: 0x00023CB0
		public Border RectBack
		{
			get
			{
				if (this.m_DatabaseWrapper == null)
				{
					Border border = new Border
					{
						Name = "RectBack",
						CornerRadius = new CornerRadius(3.0),
						RenderTransform = new ScaleTransform(0.8, 0.8),
						RenderTransformOrigin = new Point(0.5, 0.5),
						BorderThickness = new Thickness(ModBase.smethod_4(1.0)),
						SnapsToDevicePixels = true,
						IsHitTestVisible = false,
						Opacity = 0.0
					};
					border.SetResourceReference(Border.BackgroundProperty, "ColorBrush7");
					border.SetResourceReference(Border.BorderBrushProperty, "ColorBrush6");
					Grid.SetColumnSpan(border, 999);
					Grid.SetRowSpan(border, 999);
					base.Children.Insert(0, border);
					this.m_DatabaseWrapper = border;
				}
				return this.m_DatabaseWrapper;
			}
		}

		// Token: 0x060003F8 RID: 1016 RVA: 0x00025BB0 File Offset: 0x00023DB0
		public void RefreshColor(object sender, EventArgs e)
		{
			if (this.advisorWrapper)
			{
				string text;
				int num;
				if (base.IsMouseOver)
				{
					if (this.m_SchemaWrapper)
					{
						text = "MouseDown";
						num = 120;
					}
					else
					{
						text = "MouseOver";
						num = 120;
					}
				}
				else
				{
					text = "Idle";
					num = 180;
				}
				if (Operators.CompareString(this.m_CallbackWrapper, text, true) != 0)
				{
					this.m_CallbackWrapper = text;
					if (base.IsLoaded && ModAnimation.DefineModel() == 0)
					{
						List<ModAnimation.AniData> list = new List<ModAnimation.AniData>();
						if (base.IsMouseOver)
						{
							list.AddRange(new ModAnimation.AniData[]
							{
								ModAnimation.AaColor(this.RectBack, Border.BackgroundProperty, this.m_SchemaWrapper ? "ColorBrush6" : "ColorBrush9", num, 0, null, false),
								ModAnimation.AaOpacity(this.RectBack, 1.0 - this.RectBack.Opacity, num, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false)
							});
							if (this.m_SchemaWrapper)
							{
								list.Add(ModAnimation.AaScaleTransform(this.RectBack, 0.996 - ((ScaleTransform)this.RectBack.RenderTransform).ScaleX, checked((int)Math.Round(unchecked((double)num * 1.2))), 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false));
							}
							else
							{
								list.Add(ModAnimation.AaScaleTransform(this.RectBack, 1.0 - ((ScaleTransform)this.RectBack.RenderTransform).ScaleX, checked((int)Math.Round(unchecked((double)num * 1.2))), 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false));
							}
						}
						else
						{
							list.AddRange(new ModAnimation.AniData[]
							{
								ModAnimation.AaOpacity(this.RectBack, -this.RectBack.Opacity, num, 0, null, false),
								ModAnimation.AaColor(this.RectBack, Border.BackgroundProperty, this.m_SchemaWrapper ? "ColorBrush6" : "ColorBrush7", num, 0, null, false),
								ModAnimation.AaScaleTransform(this.RectBack, 0.996 - ((ScaleTransform)this.RectBack.RenderTransform).ScaleX, num, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
								ModAnimation.AaScaleTransform(this.RectBack, -0.196, 1, 0, null, true)
							});
						}
						ModAnimation.AniStart(list, "CfItem Color " + Conversions.ToString(this.threadWrapper), false);
						return;
					}
					ModAnimation.AniStop("CfItem Color " + Conversions.ToString(this.threadWrapper));
					if (this.m_DatabaseWrapper != null)
					{
						this.RectBack.Opacity = 0.0;
					}
				}
			}
		}

		// Token: 0x060003F9 RID: 1017 RVA: 0x00025E54 File Offset: 0x00024054
		private void LabInfo_MouseEnter(object sender, MouseEventArgs e)
		{
			if (this.IsTextTrimmed(this.LabInfo))
			{
				this.ToolTipInfo.Content = this.LabInfo.Text;
				this.ToolTipInfo.Width = this.LabInfo.ActualWidth + 25.0;
				this.LabInfo.ToolTip = this.ToolTipInfo;
				return;
			}
			this.LabInfo.ToolTip = null;
		}

		// Token: 0x060003FA RID: 1018 RVA: 0x00025EC4 File Offset: 0x000240C4
		private bool IsTextTrimmed(TextBlock textBlock)
		{
			Typeface typeface = new Typeface(textBlock.FontFamily, textBlock.FontStyle, textBlock.FontWeight, textBlock.FontStretch);
			return new FormattedText(textBlock.Text, Thread.CurrentThread.CurrentCulture, textBlock.FlowDirection, typeface, textBlock.FontSize, textBlock.Foreground).Width > textBlock.ActualWidth;
		}

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x060003FB RID: 1019 RVA: 0x000040BF File Offset: 0x000022BF
		// (set) Token: 0x060003FC RID: 1020 RVA: 0x000040C7 File Offset: 0x000022C7
		internal virtual MyCfItem PanBack { get; set; }

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x060003FD RID: 1021 RVA: 0x000040D0 File Offset: 0x000022D0
		// (set) Token: 0x060003FE RID: 1022 RVA: 0x000040D8 File Offset: 0x000022D8
		internal virtual Image PathLogo { get; set; }

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x060003FF RID: 1023 RVA: 0x000040E1 File Offset: 0x000022E1
		// (set) Token: 0x06000400 RID: 1024 RVA: 0x000040E9 File Offset: 0x000022E9
		internal virtual TextBlock LabTitle { get; set; }

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x06000401 RID: 1025 RVA: 0x000040F2 File Offset: 0x000022F2
		// (set) Token: 0x06000402 RID: 1026 RVA: 0x000040FA File Offset: 0x000022FA
		internal virtual TextBlock LabLeft { get; set; }

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x06000403 RID: 1027 RVA: 0x00004103 File Offset: 0x00002303
		// (set) Token: 0x06000404 RID: 1028 RVA: 0x00025F24 File Offset: 0x00024124
		internal virtual TextBlock LabInfo
		{
			[CompilerGenerated]
			get
			{
				return this.m_ConsumerWrapper;
			}
			[CompilerGenerated]
			set
			{
				MouseEventHandler value2 = new MouseEventHandler(this.LabInfo_MouseEnter);
				TextBlock consumerWrapper = this.m_ConsumerWrapper;
				if (consumerWrapper != null)
				{
					consumerWrapper.MouseEnter -= value2;
				}
				this.m_ConsumerWrapper = value;
				consumerWrapper = this.m_ConsumerWrapper;
				if (consumerWrapper != null)
				{
					consumerWrapper.MouseEnter += value2;
				}
			}
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x06000405 RID: 1029 RVA: 0x0000410B File Offset: 0x0000230B
		// (set) Token: 0x06000406 RID: 1030 RVA: 0x00004113 File Offset: 0x00002313
		internal virtual ToolTip ToolTipInfo { get; set; }

		// Token: 0x06000407 RID: 1031 RVA: 0x00025F68 File Offset: 0x00024168
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_ReaderWrapper)
			{
				this.m_ReaderWrapper = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagedownload/mycfitem.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000408 RID: 1032 RVA: 0x00025F98 File Offset: 0x00024198
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyCfItem)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PathLogo = (Image)target;
				return;
			}
			if (connectionId == 3)
			{
				this.LabTitle = (TextBlock)target;
				return;
			}
			if (connectionId == 4)
			{
				this.LabLeft = (TextBlock)target;
				return;
			}
			if (connectionId == 5)
			{
				this.LabInfo = (TextBlock)target;
				return;
			}
			if (connectionId == 6)
			{
				this.ToolTipInfo = (ToolTip)target;
				return;
			}
			this.m_ReaderWrapper = true;
		}

		// Token: 0x040001F7 RID: 503
		public int threadWrapper;

		// Token: 0x040001F8 RID: 504
		private string connectionWrapper;

		// Token: 0x040001F9 RID: 505
		[CompilerGenerated]
		private MyCfItem.ClickEventHandler _CustomerWrapper;

		// Token: 0x040001FA RID: 506
		private bool m_SchemaWrapper;

		// Token: 0x040001FB RID: 507
		private Border m_DatabaseWrapper;

		// Token: 0x040001FC RID: 508
		private string m_CallbackWrapper;

		// Token: 0x040001FD RID: 509
		public bool advisorWrapper;

		// Token: 0x040001FE RID: 510
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyCfItem observerWrapper;

		// Token: 0x040001FF RID: 511
		[CompilerGenerated]
		[AccessedThroughProperty("PathLogo")]
		private Image m_SingletonWrapper;

		// Token: 0x04000200 RID: 512
		[AccessedThroughProperty("LabTitle")]
		[CompilerGenerated]
		private TextBlock m_ContextWrapper;

		// Token: 0x04000201 RID: 513
		[AccessedThroughProperty("LabLeft")]
		[CompilerGenerated]
		private TextBlock m_CollectionWrapper;

		// Token: 0x04000202 RID: 514
		[AccessedThroughProperty("LabInfo")]
		[CompilerGenerated]
		private TextBlock m_ConsumerWrapper;

		// Token: 0x04000203 RID: 515
		[AccessedThroughProperty("ToolTipInfo")]
		[CompilerGenerated]
		private ToolTip m_FilterWrapper;

		// Token: 0x04000204 RID: 516
		private bool m_ReaderWrapper;

		// Token: 0x0200008C RID: 140
		// (Invoke) Token: 0x0600040D RID: 1037
		public delegate void ClickEventHandler(object sender, MouseButtonEventArgs e);
	}
}
