﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;

namespace PCL
{
	// Token: 0x02000053 RID: 83
	public class MyLoadingStateSimulator : ILoadingTrigger
	{
		// Token: 0x0600022C RID: 556 RVA: 0x000034AC File Offset: 0x000016AC
		public MyLoadingStateSimulator()
		{
			this.DefineWrapper(MyLoading.MyLoadingState.Unloaded);
			this.IsLoader = 0;
		}

		// Token: 0x0600022D RID: 557 RVA: 0x000034C3 File Offset: 0x000016C3
		[CompilerGenerated]
		private MyLoading.MyLoadingState PrepareWrapper()
		{
			return this.producer;
		}

		// Token: 0x0600022E RID: 558 RVA: 0x000034CB File Offset: 0x000016CB
		[CompilerGenerated]
		private void DefineWrapper(MyLoading.MyLoadingState AutoPropertyValue)
		{
			this.producer = AutoPropertyValue;
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x0600022F RID: 559 RVA: 0x000034D4 File Offset: 0x000016D4
		// (set) Token: 0x06000230 RID: 560 RVA: 0x000160F0 File Offset: 0x000142F0
		public MyLoading.MyLoadingState LoadingState
		{
			get
			{
				return this.PrepareWrapper();
			}
			set
			{
				if (this.PrepareWrapper() != value)
				{
					MyLoading.MyLoadingState oldState = this.PrepareWrapper();
					this.DefineWrapper(value);
					ILoadingTrigger.LoadingStateChangedEventHandler loadingStateChangedEventHandler = this.setter;
					if (loadingStateChangedEventHandler != null)
					{
						loadingStateChangedEventHandler(value, oldState);
					}
				}
			}
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x06000231 RID: 561 RVA: 0x000034DC File Offset: 0x000016DC
		public bool IsLoader { get; }

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x06000232 RID: 562 RVA: 0x00016128 File Offset: 0x00014328
		// (remove) Token: 0x06000233 RID: 563 RVA: 0x00016160 File Offset: 0x00014360
		public event ILoadingTrigger.LoadingStateChangedEventHandler LoadingStateChanged
		{
			[CompilerGenerated]
			add
			{
				ILoadingTrigger.LoadingStateChangedEventHandler loadingStateChangedEventHandler = this.setter;
				ILoadingTrigger.LoadingStateChangedEventHandler loadingStateChangedEventHandler2;
				do
				{
					loadingStateChangedEventHandler2 = loadingStateChangedEventHandler;
					ILoadingTrigger.LoadingStateChangedEventHandler value2 = (ILoadingTrigger.LoadingStateChangedEventHandler)Delegate.Combine(loadingStateChangedEventHandler2, value);
					loadingStateChangedEventHandler = Interlocked.CompareExchange<ILoadingTrigger.LoadingStateChangedEventHandler>(ref this.setter, value2, loadingStateChangedEventHandler2);
				}
				while (loadingStateChangedEventHandler != loadingStateChangedEventHandler2);
			}
			[CompilerGenerated]
			remove
			{
				ILoadingTrigger.LoadingStateChangedEventHandler loadingStateChangedEventHandler = this.setter;
				ILoadingTrigger.LoadingStateChangedEventHandler loadingStateChangedEventHandler2;
				do
				{
					loadingStateChangedEventHandler2 = loadingStateChangedEventHandler;
					ILoadingTrigger.LoadingStateChangedEventHandler value2 = (ILoadingTrigger.LoadingStateChangedEventHandler)Delegate.Remove(loadingStateChangedEventHandler2, value);
					loadingStateChangedEventHandler = Interlocked.CompareExchange<ILoadingTrigger.LoadingStateChangedEventHandler>(ref this.setter, value2, loadingStateChangedEventHandler2);
				}
				while (loadingStateChangedEventHandler != loadingStateChangedEventHandler2);
			}
		}

		// Token: 0x040000FA RID: 250
		[CompilerGenerated]
		private MyLoading.MyLoadingState producer;

		// Token: 0x040000FB RID: 251
		[CompilerGenerated]
		private bool m_Candidate;

		// Token: 0x040000FC RID: 252
		[CompilerGenerated]
		private ILoadingTrigger.LoadingStateChangedEventHandler setter;
	}
}
