﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200009D RID: 157
	[DesignerGenerated]
	public class PageLoginAuthSkin : Grid, IComponentConnector
	{
		// Token: 0x060005C4 RID: 1476 RVA: 0x00005024 File Offset: 0x00003224
		public PageLoginAuthSkin()
		{
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.PageLoginLegacy_Loaded();
			};
			this.InitializeComponent();
			this.Skin.m_RepositoryComparator = PageLaunchLeft.m_TemplateComparator;
		}

		// Token: 0x060005C5 RID: 1477 RVA: 0x00005055 File Offset: 0x00003255
		private void PageLoginLegacy_Loaded()
		{
			this.Skin.m_RepositoryComparator.Start(null, false);
		}

		// Token: 0x060005C6 RID: 1478 RVA: 0x0002BE84 File Offset: 0x0002A084
		public void Reload(bool KeepInput)
		{
			this.TextName.Text = Conversions.ToString(ModBase._ParamsState.Get("CacheAuthName", null));
			this.TextEmail.Text = Conversions.ToString(ModBase._ParamsState.Get("CacheAuthUsername", null));
			this.TextEmail.Visibility = (Conversions.ToBoolean(ModBase._ParamsState.Get("UiLauncherEmail", null)) ? Visibility.Collapsed : Visibility.Visible);
			this.PageLoginLegacy_Loaded();
		}

		// Token: 0x060005C7 RID: 1479 RVA: 0x0002BF00 File Offset: 0x0002A100
		public static ModLaunch.McLoginServer GetLoginData()
		{
			string stubProccesor = Conversions.ToString(Operators.ConcatenateObject(Information.IsNothing(ModMinecraft.SetupResolver()) ? ModBase._ParamsState.Get("CacheAuthServerServer", null) : ModBase._ParamsState.Get("VersionServerAuthServer", ModMinecraft.SetupResolver()), "/authserver"));
			return new ModLaunch.McLoginServer(ModLaunch.McLoginType.Auth)
			{
				m_ErrorProccesor = "Auth",
				_StubProccesor = stubProccesor,
				m_InterpreterProccesor = Conversions.ToString(ModBase._ParamsState.Get("CacheAuthUsername", null)),
				_ParserProccesor = Conversions.ToString(ModBase._ParamsState.Get("CacheAuthPass", null)),
				_ExceptionProccesor = "Authlib-Injector",
				Type = ModLaunch.McLoginType.Auth
			};
		}

		// Token: 0x060005C8 RID: 1480 RVA: 0x0002BFB0 File Offset: 0x0002A1B0
		private void PageLoginAuthSkin_MouseEnter(object sender, MouseEventArgs e)
		{
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaOpacity(this.BtnEdit, 1.0 - this.BtnEdit.Opacity, 80, 0, null, false),
				ModAnimation.AaHeight(this.BtnEdit, 25.5 - this.BtnEdit.Height, 140, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaHeight(this.BtnEdit, -1.5, 50, 140, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaOpacity(this.BtnExit, 1.0 - this.BtnExit.Opacity, 80, 0, null, false),
				ModAnimation.AaHeight(this.BtnExit, 25.5 - this.BtnExit.Height, 140, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaHeight(this.BtnExit, -1.5, 50, 140, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false)
			}, "PageLoginAuthSkin Button", false);
		}

		// Token: 0x060005C9 RID: 1481 RVA: 0x0002C0E0 File Offset: 0x0002A2E0
		private void PageLoginAuthSkin_MouseLeave(object sender, MouseEventArgs e)
		{
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaOpacity(this.BtnEdit, -this.BtnEdit.Opacity, 120, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaHeight(this.BtnEdit, 14.0 - this.BtnEdit.Height, 120, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaOpacity(this.BtnExit, -this.BtnExit.Opacity, 120, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaHeight(this.BtnExit, 14.0 - this.BtnExit.Height, 120, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false)
			}, "PageLoginAuthSkin Button", false);
		}

		// Token: 0x060005CA RID: 1482 RVA: 0x0002C1B0 File Offset: 0x0002A3B0
		private void BtnEdit_Click(object sender, EventArgs e)
		{
			if (ModLaunch.m_IndexerTag.State != ModBase.LoadState.Loading)
			{
				ModMain.Hint("正在尝试更换，请稍候！", ModMain.HintType.Info, true);
				ModBase._ParamsState.Set("CacheAuthUuid", "", false, null);
				ModBase._ParamsState.Set("CacheAuthName", "", false, null);
				ModBase.RunInThread(delegate
				{
					try
					{
						ModLaunch.McLoginServer loginData = PageLoginAuthSkin.GetLoginData();
						loginData._TestsProccesor = true;
						ModLaunch.m_IndexerTag.WaitForExit(loginData, null, true);
						ModBase.RunInUi(delegate()
						{
							this.Reload(true);
						}, false);
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "更换角色失败", ModBase.LogLevel.Hint, "出现错误");
					}
				});
				return;
			}
			ModBase.Log("[Launch] 要求更换角色，但登录加载器繁忙", ModBase.LogLevel.Debug, "出现错误");
			if (((ModLaunch.McLoginServer)ModLaunch.m_IndexerTag.Input)._TestsProccesor)
			{
				ModMain.Hint("正在尝试更换，请稍候！", ModMain.HintType.Info, true);
				return;
			}
			ModMain.Hint("正在登录中，请稍后再更换角色！", ModMain.HintType.Critical, true);
		}

		// Token: 0x060005CB RID: 1483 RVA: 0x00005069 File Offset: 0x00003269
		private void BtnExit_Click()
		{
			ModBase._ParamsState.Set("CacheAuthAccess", "", false, null);
			ModMain._FilterAccount.RefreshPage(false, true);
		}

		// Token: 0x060005CC RID: 1484 RVA: 0x0002C254 File Offset: 0x0002A454
		private void Skin_Click(object sender, MouseButtonEventArgs e)
		{
			string text = Conversions.ToString((ModMinecraft.SetupResolver() != null) ? ModBase._ParamsState.Get("VersionServerAuthRegister", ModMinecraft.SetupResolver()) : ModBase._ParamsState.Get("CacheAuthServerRegister", null));
			if (string.IsNullOrEmpty(new ValidateHttp().Validate(text)))
			{
				ModBase.OpenWebsite(text);
			}
		}

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x060005CD RID: 1485 RVA: 0x0000508D File Offset: 0x0000328D
		// (set) Token: 0x060005CE RID: 1486 RVA: 0x0002C2AC File Offset: 0x0002A4AC
		internal virtual Grid PanData
		{
			[CompilerGenerated]
			get
			{
				return this.m_TestsRepository;
			}
			[CompilerGenerated]
			set
			{
				MouseEventHandler value2 = new MouseEventHandler(this.PageLoginAuthSkin_MouseEnter);
				MouseEventHandler value3 = new MouseEventHandler(this.PageLoginAuthSkin_MouseLeave);
				Grid testsRepository = this.m_TestsRepository;
				if (testsRepository != null)
				{
					testsRepository.MouseEnter -= value2;
					testsRepository.MouseLeave -= value3;
				}
				this.m_TestsRepository = value;
				testsRepository = this.m_TestsRepository;
				if (testsRepository != null)
				{
					testsRepository.MouseEnter += value2;
					testsRepository.MouseLeave += value3;
				}
			}
		}

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x060005CF RID: 1487 RVA: 0x00005095 File Offset: 0x00003295
		// (set) Token: 0x060005D0 RID: 1488 RVA: 0x0000509D File Offset: 0x0000329D
		internal virtual TextBlock TextName { get; set; }

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x060005D1 RID: 1489 RVA: 0x000050A6 File Offset: 0x000032A6
		// (set) Token: 0x060005D2 RID: 1490 RVA: 0x000050AE File Offset: 0x000032AE
		internal virtual TextBlock TextEmail { get; set; }

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x060005D3 RID: 1491 RVA: 0x000050B7 File Offset: 0x000032B7
		// (set) Token: 0x060005D4 RID: 1492 RVA: 0x0002C30C File Offset: 0x0002A50C
		internal virtual MyIconButton BtnEdit
		{
			[CompilerGenerated]
			get
			{
				return this.m_WorkerRepository;
			}
			[CompilerGenerated]
			set
			{
				MyIconButton.ClickEventHandler value2 = new MyIconButton.ClickEventHandler(this.BtnEdit_Click);
				MyIconButton workerRepository = this.m_WorkerRepository;
				if (workerRepository != null)
				{
					workerRepository.Click -= value2;
				}
				this.m_WorkerRepository = value;
				workerRepository = this.m_WorkerRepository;
				if (workerRepository != null)
				{
					workerRepository.Click += value2;
				}
			}
		}

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x060005D5 RID: 1493 RVA: 0x000050BF File Offset: 0x000032BF
		// (set) Token: 0x060005D6 RID: 1494 RVA: 0x0002C350 File Offset: 0x0002A550
		internal virtual MyIconButton BtnExit
		{
			[CompilerGenerated]
			get
			{
				return this.m_DicRepository;
			}
			[CompilerGenerated]
			set
			{
				MyIconButton.ClickEventHandler value2 = delegate(object sender, EventArgs e)
				{
					this.BtnExit_Click();
				};
				MyIconButton dicRepository = this.m_DicRepository;
				if (dicRepository != null)
				{
					dicRepository.Click -= value2;
				}
				this.m_DicRepository = value;
				dicRepository = this.m_DicRepository;
				if (dicRepository != null)
				{
					dicRepository.Click += value2;
				}
			}
		}

		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x060005D7 RID: 1495 RVA: 0x000050C7 File Offset: 0x000032C7
		// (set) Token: 0x060005D8 RID: 1496 RVA: 0x0002C394 File Offset: 0x0002A594
		internal virtual MySkin Skin
		{
			[CompilerGenerated]
			get
			{
				return this.configurationRepository;
			}
			[CompilerGenerated]
			set
			{
				MySkin.ClickEventHandler obj = new MySkin.ClickEventHandler(this.Skin_Click);
				MySkin mySkin = this.configurationRepository;
				if (mySkin != null)
				{
					mySkin.ResolveResolver(obj);
				}
				this.configurationRepository = value;
				mySkin = this.configurationRepository;
				if (mySkin != null)
				{
					mySkin.VerifyResolver(obj);
				}
			}
		}

		// Token: 0x060005D9 RID: 1497 RVA: 0x0002C3D8 File Offset: 0x0002A5D8
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.configRepository)
			{
				this.configRepository = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagelaunch/pageloginauthskin.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x060005DA RID: 1498 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060005DB RID: 1499 RVA: 0x0002C408 File Offset: 0x0002A608
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanData = (Grid)target;
				return;
			}
			if (connectionId == 2)
			{
				this.TextName = (TextBlock)target;
				return;
			}
			if (connectionId == 3)
			{
				this.TextEmail = (TextBlock)target;
				return;
			}
			if (connectionId == 4)
			{
				this.BtnEdit = (MyIconButton)target;
				return;
			}
			if (connectionId == 5)
			{
				this.BtnExit = (MyIconButton)target;
				return;
			}
			if (connectionId == 6)
			{
				this.Skin = (MySkin)target;
				return;
			}
			this.configRepository = true;
		}

		// Token: 0x040002A6 RID: 678
		[CompilerGenerated]
		[AccessedThroughProperty("PanData")]
		private Grid m_TestsRepository;

		// Token: 0x040002A7 RID: 679
		[AccessedThroughProperty("TextName")]
		[CompilerGenerated]
		private TextBlock m_StrategyRepository;

		// Token: 0x040002A8 RID: 680
		[CompilerGenerated]
		[AccessedThroughProperty("TextEmail")]
		private TextBlock rulesRepository;

		// Token: 0x040002A9 RID: 681
		[AccessedThroughProperty("BtnEdit")]
		[CompilerGenerated]
		private MyIconButton m_WorkerRepository;

		// Token: 0x040002AA RID: 682
		[CompilerGenerated]
		[AccessedThroughProperty("BtnExit")]
		private MyIconButton m_DicRepository;

		// Token: 0x040002AB RID: 683
		[CompilerGenerated]
		[AccessedThroughProperty("Skin")]
		private MySkin configurationRepository;

		// Token: 0x040002AC RID: 684
		private bool configRepository;
	}
}
