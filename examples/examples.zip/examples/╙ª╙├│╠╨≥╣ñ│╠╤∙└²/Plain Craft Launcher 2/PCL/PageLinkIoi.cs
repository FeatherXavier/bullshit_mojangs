﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace PCL
{
	// Token: 0x020000A6 RID: 166
	[DesignerGenerated]
	public class PageLinkIoi : MyPageRight, IComponentConnector
	{
		// Token: 0x0600063F RID: 1599 RVA: 0x0002D824 File Offset: 0x0002BA24
		static PageLinkIoi()
		{
			PageLinkIoi.GetRepository(new ModLoader.LoaderCombo<int>("联机模块初始化", new ModLoader.LoaderBase[]
			{
				new ModLoader.LoaderTask<int, List<ModNet.NetFile>>("初次启动尝试", new Action<ModLoader.LoaderTask<int, List<ModNet.NetFile>>>(PageLinkIoi.InitFirst), null, ThreadPriority.Normal)
				{
					ProgressWeight = 3.0
				},
				new ModNet.LoaderDownload("下载更新文件", new List<ModNet.NetFile>())
				{
					ProgressWeight = 6.0
				},
				new ModLoader.LoaderTask<List<ModNet.NetFile>, bool>("二次启动尝试", new Action<ModLoader.LoaderTask<List<ModNet.NetFile>, bool>>(PageLinkIoi.InitSecond), null, ThreadPriority.Normal)
				{
					ProgressWeight = 2.0
				}
			}));
			PageLinkIoi.repositoryResolver = null;
			PageLinkIoi._ResolverResolver = ModBase.LoadState.Waiting;
			PageLinkIoi.m_TagResolver = 0;
			PageLinkIoi._ComparatorResolver = "";
			PageLinkIoi.m_PrototypeResolver = "";
			PageLinkIoi.issuerResolver = "";
			PageLinkIoi.m_RequestResolver = new Dictionary<string, PageLinkIoi.UserEntry>();
			PageLinkIoi._AccountResolver = new List<PageLinkIoi.RoomEntry>();
		}

		// Token: 0x06000640 RID: 1600 RVA: 0x0000547E File Offset: 0x0000367E
		public PageLinkIoi()
		{
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.MeLoaded();
			};
			base.Initialized += delegate(object sender, EventArgs e)
			{
				this.LoaderInit();
			};
			this._StatusRepository = false;
			this.InitializeComponent();
		}

		// Token: 0x06000641 RID: 1601 RVA: 0x000054B8 File Offset: 0x000036B8
		private void MeLoaded()
		{
			this.PanBack.ScrollToHome();
			this.RefreshUi();
			if (!this._StatusRepository)
			{
				this._StatusRepository = true;
				ModBase.RunInNewThread(delegate
				{
					for (;;)
					{
						Thread.Sleep(200);
						if (ModMain.m_CollectionAccount.comparatorAccount.m_CreatorParameter == FormMain.PageType.Link)
						{
							ModBase.RunInUiWait((PageLinkIoi._Closure$__.$I5-1 == null) ? (PageLinkIoi._Closure$__.$I5-1 = delegate()
							{
								ModMain._ParserAccount.RefreshUi();
							}) : PageLinkIoi._Closure$__.$I5-1);
						}
						this.RefreshWorker();
					}
				}, "Link Timer", ThreadPriority.Normal);
			}
		}

		// Token: 0x06000642 RID: 1602 RVA: 0x0002D904 File Offset: 0x0002BB04
		private void LoaderInit()
		{
			base.PageLoaderInit(this.Load, this.PanLoad, this.PanBack, null, PageLinkIoi.m_ProcRepository, (PageLinkIoi._Closure$__.$IR6-3 == null) ? (PageLinkIoi._Closure$__.$IR6-3 = delegate(ModLoader.LoaderBase a0)
			{
				((PageLinkIoi._Closure$__.$I6-0 == null) ? (PageLinkIoi._Closure$__.$I6-0 = delegate()
				{
				}) : PageLinkIoi._Closure$__.$I6-0)();
			}) : PageLinkIoi._Closure$__.$IR6-3, null, true);
		}

		// Token: 0x06000643 RID: 1603 RVA: 0x000054F2 File Offset: 0x000036F2
		[CompilerGenerated]
		public static ModLoader.LoaderCombo<int> NewRepository()
		{
			return PageLinkIoi.m_ProcRepository;
		}

		// Token: 0x06000644 RID: 1604 RVA: 0x0002D958 File Offset: 0x0002BB58
		[CompilerGenerated]
		public static void GetRepository(ModLoader.LoaderCombo<int> WithEventsValue)
		{
			ModLoader.LoaderBase.OnStateChangedUiEventHandler value = new ModLoader.LoaderBase.OnStateChangedUiEventHandler(PageLinkIoi.ModuleStateChanged);
			ModLoader.LoaderCombo<int> procRepository = PageLinkIoi.m_ProcRepository;
			if (procRepository != null)
			{
				procRepository.OnStateChangedUi -= value;
			}
			PageLinkIoi.m_ProcRepository = WithEventsValue;
			procRepository = PageLinkIoi.m_ProcRepository;
			if (procRepository != null)
			{
				procRepository.OnStateChangedUi += value;
			}
		}

		// Token: 0x06000645 RID: 1605 RVA: 0x0002D998 File Offset: 0x0002BB98
		private static void InitFirst(ModLoader.LoaderTask<int, List<ModNet.NetFile>> Task)
		{
			Task.Progress = 0.1;
			PageLinkIoi.IoiStop(true);
			Task.Progress = 0.2;
			checked
			{
				foreach (IPEndPoint ipendPoint in IPGlobalProperties.GetIPGlobalProperties().GetActiveTcpListeners())
				{
					if (ipendPoint.Port == 55555)
					{
						ModBase.Log("[Link] 发现端口 " + Conversions.ToString(ipendPoint.Port) + " 被占用", ModBase.LogLevel.Normal, "出现错误");
						string[] array = ModBase.ShellAndGetOutput("netstat", "-ano", 30000, null).Split(new string[]
						{
							"\r\n"
						}, StringSplitOptions.RemoveEmptyEntries);
						int j = 0;
						while (j < array.Length)
						{
							string text = array[j];
							if (!text.Contains("127.0.0.1:55555"))
							{
								j++;
							}
							else
							{
								string processName;
								try
								{
									processName = Process.GetProcessById(Conversions.ToInteger(text.Split(new char[]
									{
										' '
									}).Last<string>())).ProcessName;
									goto IL_227;
								}
								catch (Exception ex)
								{
									ModBase.Log(ex, "获取占用端口的进程信息失败，假定进程已结束", ModBase.LogLevel.Debug, "出现错误");
								}
								goto IL_11C;
								IL_227:
								if (Operators.CompareString(processName, "联机模块", true) == 0)
								{
									throw new Exception("由于联机模块的一个已知 Bug，导致其无法被关闭，请在重启电脑后再试");
								}
								throw new Exception("端口被程序 " + processName + " 占用，无法启动联机模块，请在任务管理器关闭此程序后再试");
							}
						}
						goto IL_BD;
						IL_11C:
						if (Operators.ConditionalCompareObjectNotEqual(10, ModBase._ParamsState.Get("LinkIoiVersion", null), true))
						{
							ModBase.Log("[Link] 设置版本强制要求联机模块更新", ModBase.LogLevel.Normal, "出现错误");
							ModBase._ParamsState.Set("LinkIoiVersion", 10, false, null);
						}
						else if (File.Exists(ModBase.attributeState + "联机模块.exe"))
						{
							Task.Progress = 0.3;
							if (PageLinkIoi.IoiStart())
							{
								Task.Output = new List<ModNet.NetFile>();
								return;
							}
							PageLinkIoi.IoiStop(true);
							File.Delete(ModBase.attributeState + "联机模块.exe");
						}
						Task.Progress = 0.8;
						ModBase.Log("[Link] 需要下载联机模块", ModBase.LogLevel.Normal, "出现错误");
						if (File.Exists(ModBase.attributeState + "联机模块.zip"))
						{
							File.Delete(ModBase.attributeState + "联机模块.zip");
						}
						Task.Output = new List<ModNet.NetFile>
						{
							new ModNet.NetFile(new string[]
							{
								"https://pcl2-server-1253424809.file.myqcloud.com/link/ioi_v2_x" + Conversions.ToString(ModBase.m_WriterState ? 32 : 64) + ".zip{CDN}"
							}, ModBase.attributeState + "联机模块.zip", null)
						};
						return;
					}
					IL_BD:;
				}
				goto IL_11C;
			}
		}

		// Token: 0x06000646 RID: 1606 RVA: 0x0002DC40 File Offset: 0x0002BE40
		private static void InitSecond(ModLoader.LoaderTask<List<ModNet.NetFile>, bool> Task)
		{
			if (PageLinkIoi._ResolverResolver != ModBase.LoadState.Finished)
			{
				ModBase.Log("[Link] 解压联机模块以完成下载", ModBase.LogLevel.Normal, "出现错误");
				if (File.Exists(ModBase.attributeState + "ioi.exe"))
				{
					File.Delete(ModBase.attributeState + "ioi.exe");
				}
				if (File.Exists(ModBase.attributeState + "联机模块.exe"))
				{
					File.Delete(ModBase.attributeState + "联机模块.exe");
				}
				ZipFile.ExtractToDirectory(ModBase.attributeState + "联机模块.zip", ModBase.attributeState);
				File.Delete(ModBase.attributeState + "联机模块.zip");
				FileSystem.Rename(ModBase.attributeState + "ioi.exe", ModBase.attributeState + "联机模块.exe");
				Task.Progress = 0.4;
				if (!PageLinkIoi.IoiStart())
				{
					PageLinkIoi.IoiStop(true);
					throw new Exception("联机模块初始化失败");
				}
			}
		}

		// Token: 0x06000647 RID: 1607 RVA: 0x0002DD34 File Offset: 0x0002BF34
		public static bool IoiStop(bool SleepWhenKilled)
		{
			bool result = false;
			checked
			{
				if (PageLinkIoi.repositoryResolver != null && !PageLinkIoi.repositoryResolver.HasExited)
				{
					int num = PageLinkIoi.m_RequestResolver.Count - 1;
					int num2 = 0;
					while (num2 <= num && num2 <= PageLinkIoi.m_RequestResolver.Count - 1)
					{
						PageLinkIoi.SendDisconnectRequest(PageLinkIoi.m_RequestResolver.Values.ElementAtOrDefault(num2), null, false);
						num2++;
					}
				}
				foreach (Process process in Process.GetProcesses())
				{
					if (Operators.CompareString(process.ProcessName, "联机模块", true) == 0)
					{
						result = true;
						try
						{
							process.Kill();
							ModBase.Log("[Link] 已关闭联机模块：" + Conversions.ToString(process.Id), ModBase.LogLevel.Normal, "出现错误");
							if (SleepWhenKilled)
							{
								Thread.Sleep(3000);
							}
						}
						catch (Exception ex)
						{
							ModBase.Log(ex, "关闭联机模块失败（" + Conversions.ToString(process.Id) + "）", ModBase.LogLevel.Debug, "出现错误");
						}
					}
				}
				PageLinkIoi.repositoryResolver = null;
				PageLinkIoi.m_ModelResolver = null;
				PageLinkIoi.m_WrapperResolver = null;
				PageLinkIoi._ResolverResolver = ModBase.LoadState.Waiting;
				PageLinkIoi.m_RequestResolver = new Dictionary<string, PageLinkIoi.UserEntry>();
				PageLinkIoi._AccountResolver = new List<PageLinkIoi.RoomEntry>();
				return result;
			}
		}

		// Token: 0x06000648 RID: 1608 RVA: 0x0002DE7C File Offset: 0x0002C07C
		public static bool IoiStart()
		{
			PageLinkIoi.IoiStop(true);
			PageLinkIoi._ResolverResolver = ModBase.LoadState.Loading;
			ModBase.Log("[Link] 启动联机模块进程", ModBase.LogLevel.Normal, "出现错误");
			ProcessStartInfo startInfo = new ProcessStartInfo
			{
				FileName = ModBase.attributeState + "联机模块.exe",
				UseShellExecute = false,
				CreateNoWindow = true,
				RedirectStandardError = true,
				RedirectStandardOutput = true,
				WorkingDirectory = ModBase.attributeState
			};
			PageLinkIoi.repositoryResolver = new Process
			{
				StartInfo = startInfo
			};
			PageLinkIoi._Closure$__18-0 CS$<>8__locals1 = new PageLinkIoi._Closure$__18-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Local_outputWaitHandle = new AutoResetEvent(false);
			bool result;
			try
			{
				PageLinkIoi._Closure$__18-1 CS$<>8__locals2 = new PageLinkIoi._Closure$__18-1(CS$<>8__locals2);
				CS$<>8__locals2.$VB$Local_errorWaitHandle = new AutoResetEvent(false);
				try
				{
					PageLinkIoi.repositoryResolver.OutputDataReceived += delegate(object sender, DataReceivedEventArgs e)
					{
						base._Lambda$__0(RuntimeHelpers.GetObjectValue(sender), e);
					};
					PageLinkIoi.repositoryResolver.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs e)
					{
						base._Lambda$__1(RuntimeHelpers.GetObjectValue(sender), e);
					};
					PageLinkIoi.repositoryResolver.Start();
					PageLinkIoi.repositoryResolver.BeginOutputReadLine();
					PageLinkIoi.repositoryResolver.BeginErrorReadLine();
					while (!PageLinkIoi.repositoryResolver.HasExited)
					{
						if (PageLinkIoi._ResolverResolver != ModBase.LoadState.Loading)
						{
							break;
						}
						Thread.Sleep(10);
					}
					switch (PageLinkIoi._ResolverResolver)
					{
					case ModBase.LoadState.Finished:
						ModBase.Log("[Link] 联机模块启动成功", ModBase.LogLevel.Normal, "出现错误");
						result = true;
						break;
					case ModBase.LoadState.Failed:
						ModBase.Log("[Link] 联机模块启动出现异常", ModBase.LogLevel.Normal, "出现错误");
						result = false;
						break;
					case ModBase.LoadState.Aborted:
						ModBase.Log("[Link] 联机模块要求更新", ModBase.LogLevel.Normal, "出现错误");
						result = false;
						break;
					default:
						throw new Exception("联机模块启动失败，请检查你的网络连接");
					}
				}
				finally
				{
					if (CS$<>8__locals2.$VB$Local_errorWaitHandle != null)
					{
						((IDisposable)CS$<>8__locals2.$VB$Local_errorWaitHandle).Dispose();
					}
				}
			}
			finally
			{
				if (CS$<>8__locals1.$VB$Local_outputWaitHandle != null)
				{
					((IDisposable)CS$<>8__locals1.$VB$Local_outputWaitHandle).Dispose();
				}
			}
			return result;
		}

		// Token: 0x06000649 RID: 1609 RVA: 0x0002E034 File Offset: 0x0002C234
		private static void IoiLogLine(string Content)
		{
			if (Content.StartsWith("PCL - "))
			{
				try
				{
					string text = WebUtility.UrlDecode(ModBase.RevertTag(Content.Substring(6), ""));
					ModBase.Log("[Link] 接收到数据包：" + text, ModBase.LogLevel.Normal, "出现错误");
					PageLinkIoi.ReceiveJson((JObject)ModBase.GetJson(text));
					return;
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "解码联机数据包失败", ModBase.LogLevel.Debug, "出现错误");
				}
			}
			checked
			{
				if (!Content.Contains(" > http://127.0.0.1:55555/"))
				{
					if (Content.Contains("All done"))
					{
						if (PageLinkIoi.m_ModelResolver != null && PageLinkIoi.m_WrapperResolver != null)
						{
							PageLinkIoi._ResolverResolver = ModBase.LoadState.Finished;
							return;
						}
						ModBase.Log("[Link] 联机模块汇报初始化完成，但未提供账户信息", ModBase.LogLevel.Normal, "出现错误");
						PageLinkIoi._ResolverResolver = ModBase.LoadState.Failed;
						return;
					}
					else
					{
						if (Content.Contains("Password :: "))
						{
							PageLinkIoi.m_WrapperResolver = Content.Split(new string[]
							{
								"Password :: "
							}, StringSplitOptions.None)[1];
							return;
						}
						if (PageLinkIoi.m_TagResolver < (ModBase._EventState ? 5000 : 500))
						{
							PageLinkIoi.m_TagResolver++;
							ModBase.Log("[Link] " + Content, ModBase.LogLevel.Normal, "出现错误");
						}
						if (Content.Contains("ID :: "))
						{
							PageLinkIoi.m_ModelResolver = Content.Split(new string[]
							{
								"ID :: "
							}, StringSplitOptions.None)[1];
						}
						if (Content.Contains("Initialization failed") || Content.Contains("The version is "))
						{
							PageLinkIoi._ResolverResolver = ModBase.LoadState.Aborted;
						}
						if (Content.Contains("'portssub' from "))
						{
							PageLinkIoi._ComparatorResolver = Content.Split(new char[]
							{
								' '
							}).Last<string>();
						}
						if (Content.Contains("Listening tcp ") && PageLinkIoi.m_RequestResolver.ContainsKey(PageLinkIoi._ComparatorResolver))
						{
							ModBase.DictionaryAdd<int, string>(ref PageLinkIoi.m_RequestResolver[PageLinkIoi._ComparatorResolver].m_ReaderState, Conversions.ToInteger(Content.Split(new char[]
							{
								' '
							}).Last<string>()), ModBase.RegexSeek(Content, "(?<=Listening tcp )[^:]+", RegexOptions.None));
						}
					}
				}
			}
		}

		// Token: 0x0600064A RID: 1610 RVA: 0x0002E240 File Offset: 0x0002C440
		public void RefreshUi()
		{
			checked
			{
				try
				{
					string text = ModBase.Join(PageLinkIoi.m_RequestResolver, "\r\n");
					if (Operators.CompareString(text, PageLinkIoi.m_PrototypeResolver, true) != 0)
					{
						PageLinkIoi.m_PrototypeResolver = text;
						this.PanUserList.Children.Clear();
						int num = PageLinkIoi.m_RequestResolver.Count - 1;
						int num2 = 0;
						while (num2 <= num && num2 <= PageLinkIoi.m_RequestResolver.Count - 1)
						{
							this.PanUserList.Children.Add(PageLinkIoi.m_RequestResolver.Values.ElementAtOrDefault(num2).ToListItem());
							num2++;
						}
						this.CardUser.Title = "已连接的玩家 (" + Conversions.ToString(this.PanUserList.Children.Count) + ")";
					}
					try
					{
						foreach (object obj in this.PanUserList.Children)
						{
							MyListItem myListItem = (MyListItem)obj;
							((PageLinkIoi.UserEntry)myListItem.Tag).RefreshUi(myListItem);
						}
					}
					finally
					{
						IEnumerator enumerator;
						if (enumerator is IDisposable)
						{
							(enumerator as IDisposable).Dispose();
						}
					}
					string left = ModBase.Join(this.GetRoomList(), "\r\n");
					if (Operators.CompareString(left, PageLinkIoi.issuerResolver, true) != 0)
					{
						PageLinkIoi.issuerResolver = left;
						this.PanRoom.Children.Clear();
						try
						{
							foreach (PageLinkIoi.RoomEntry roomEntry in this.GetRoomList())
							{
								this.PanRoom.Children.Add(roomEntry.ToListItem());
							}
						}
						finally
						{
							List<PageLinkIoi.RoomEntry>.Enumerator enumerator2;
							((IDisposable)enumerator2).Dispose();
						}
					}
					try
					{
						foreach (object obj2 in this.PanRoom.Children)
						{
							MyListItem myListItem2 = (MyListItem)obj2;
							((PageLinkIoi.RoomEntry)myListItem2.Tag).RefreshUi(myListItem2);
						}
					}
					finally
					{
						IEnumerator enumerator3;
						if (enumerator3 is IDisposable)
						{
							(enumerator3 as IDisposable).Dispose();
						}
					}
					if (PageLinkIoi.m_RequestResolver.Count == 0)
					{
						if (PageLinkIoi._AccountResolver.Count == 0)
						{
							this.LabHint.Text = "若想创建房间，请点击创建房间按钮，并按说明进行操作。\r\n若想加入他人的房间，请点击建立连接，然后输入对方的连接码。";
						}
						else
						{
							this.LabHint.Text = "若想让其他人加入你的房间，请点击复制连接码，然后让你的朋友输入你的连接码以建立连接。";
						}
					}
					else if (this.GetRoomList().Count == 0)
					{
						this.LabHint.Text = "若想创建房间，请点击创建房间按钮，然后输入对局域网开放后 MC 显示的端口号，或本地服务端的端口号。";
					}
					else if (PageLinkIoi._AccountResolver.Count == 0)
					{
						this.LabHint.Text = "若想加入某个房间，直接点击该房间即可获取说明。";
					}
					else
					{
						this.LabHint.Text = "指向你所创建的房间，能在右侧找到修改房间名称、关闭房间等选项。" + ((PageLinkIoi._AccountResolver.Count != this.GetRoomList().Count) ? "\r\n若想加入其他人的房间，直接点击该房间即可获取说明。" : "");
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "联机模块 UI 时钟运行失败", ModBase.LogLevel.Feedback, "出现错误");
				}
			}
		}

		// Token: 0x0600064B RID: 1611 RVA: 0x0002E568 File Offset: 0x0002C768
		public void RefreshWorker()
		{
			checked
			{
				try
				{
					if (PageLinkIoi.m_ProcRepository.State == ModBase.LoadState.Finished && PageLinkIoi.repositoryResolver.HasExited)
					{
						ModBase.Log("[Link] 联机模块出现异常！", ModBase.LogLevel.Hint, "出现错误");
						PageLinkIoi.ModuleStopManually();
					}
					int num = PageLinkIoi.m_RequestResolver.Values.Count - 1;
					for (int i = 0; i <= num; i++)
					{
						PageLinkIoi._Closure$__25-0 CS$<>8__locals1 = new PageLinkIoi._Closure$__25-0(CS$<>8__locals1);
						if (i > PageLinkIoi.m_RequestResolver.Values.Count - 1)
						{
							break;
						}
						CS$<>8__locals1.$VB$Local_User = PageLinkIoi.m_RequestResolver.Values.ElementAtOrDefault(i);
						if (CS$<>8__locals1.$VB$Local_User.m_StubState >= 1.0)
						{
							if (DateTime.Now - CS$<>8__locals1.$VB$Local_User._InterpreterState > new TimeSpan(0, 0, ModBase.RandomInteger(80, 40)))
							{
								ModBase.RunInNewThread(delegate
								{
									try
									{
										PageLinkIoi.SendUpdateRequest(CS$<>8__locals1.$VB$Local_User, 1, -1L);
									}
									catch (Exception ex2)
									{
										ModBase.Log(ex2, "心跳包发送失败（" + CS$<>8__locals1.$VB$Local_User.m_FilterState + "）", ModBase.LogLevel.Normal, "出现错误");
									}
								}, "Link Heartbeat " + CS$<>8__locals1.$VB$Local_User.m_ConsumerState, ThreadPriority.Normal);
							}
							if (DateTime.Now - CS$<>8__locals1.$VB$Local_User.m_ParserState > new TimeSpan(0, 2, 0))
							{
								PageLinkIoi.SendDisconnectRequest(CS$<>8__locals1.$VB$Local_User, null, false);
								ModMain.Hint("与 " + CS$<>8__locals1.$VB$Local_User.m_FilterState + " 的连接已中断！", ModMain.HintType.Info, true);
							}
						}
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "联机模块工作时钟运行失败", ModBase.LogLevel.Feedback, "出现错误");
				}
			}
		}

		// Token: 0x0600064C RID: 1612 RVA: 0x0002E6F8 File Offset: 0x0002C8F8
		private static void SendPortsubRequest(PageLinkIoi.UserEntry User)
		{
			ModBase.Log("[Link] 尝试建立连接：" + User.m_ConsumerState, ModBase.LogLevel.Normal, "出现错误");
			int num = 0;
			string text;
			for (;;)
			{
				JObject jobject = (JObject)ModBase.GetJson(ModNet.NetRequestOnce("http://127.0.0.1:55555/api/link?id=" + User.m_ConsumerState + "&password=" + PageLinkIoi.m_WrapperResolver, "PUT", "", "", 100000, null, true));
				if (jobject["msg"] == null)
				{
					goto IL_25F;
				}
				text = jobject["msg"].ToString();
				string left = text;
				checked
				{
					if (Operators.CompareString(left, "failed to find any peer in table", true) == 0)
					{
						num++;
						text = "我方网络环境不佳，连接失败。";
						ModBase.Log("[Link] 未找到对等机，第 " + Conversions.ToString(num) + " 级重试", ModBase.LogLevel.Normal, "出现错误");
					}
					else if (Operators.CompareString(left, "routing: not found", true) == 0)
					{
						num += 4;
						text = "我方或对方网络环境不佳，或对方已关闭联机模块，未找到路由。";
						ModBase.Log("[Link] 无法连接到路由，第 " + Conversions.ToString(num) + " 级重试", ModBase.LogLevel.Normal, "出现错误");
					}
					else if (Operators.CompareString(left, "you are already connected to specified host", true) == 0)
					{
						num++;
						ModNet.NetRequestOnce("http://127.0.0.1:55555/api/link?id=" + User.m_ConsumerState + "&password=" + PageLinkIoi.m_WrapperResolver, "DELETE", "", "", 100000, null, true);
						text = "已与对方连接。";
						ModBase.Log("[Link] 已与对方连接，尝试中断现有连接，第 " + Conversions.ToString(num) + " 级重试", ModBase.LogLevel.Normal, "出现错误");
					}
					else if (Operators.CompareString(left, "dial backoff", true) == 0)
					{
						num += 20;
						text = "对方网络环境不佳，或对方已关闭联机模块。请尝试让对方主动连接你，而不是你去连接对方。";
						ModBase.Log("[Link] NAT 异常，第 " + Conversions.ToString(num) + " 级重试", ModBase.LogLevel.Normal, "出现错误");
					}
					else if (text.Contains("all dials failed"))
					{
						num += 8;
						text = "我方或对方网络环境不佳，或对方已关闭联机模块，连接失败。";
						ModBase.Log("[Link] 连接失败，第 " + Conversions.ToString(num) + " 级重试", ModBase.LogLevel.Normal, "出现错误");
					}
					else
					{
						num += 8;
						ModBase.Log(string.Concat(new string[]
						{
							"[Link] 未知错误（",
							text,
							"），第 ",
							Conversions.ToString(num),
							" 级重试"
						}), ModBase.LogLevel.Normal, "出现错误");
					}
					if (num > 64)
					{
						break;
					}
				}
				User.m_StubState = (double)num * 0.01 + 0.05;
				Thread.Sleep(3000);
			}
			throw new InvalidOperationException(text);
			IL_25F:
			int num2 = 0;
			while (!User.m_ReaderState.ContainsKey(55555))
			{
				checked
				{
					num2++;
				}
				User.m_StubState = 0.7 + (double)num2 / 200.0 * 0.1;
				if (num2 == 100)
				{
					throw new Exception("连接超时，请尝试重新连接（未收到端口回报）！");
				}
				Thread.Sleep(150);
			}
			User.m_StubState = 0.8;
		}

		// Token: 0x0600064D RID: 1613 RVA: 0x0002E9D4 File Offset: 0x0002CBD4
		private static void SendConnectRequest(PageLinkIoi.UserEntry User)
		{
			JObject jobject = new JObject();
			jobject["version"] = 3;
			jobject["name"] = PageLinkLeft.GetPlayerName();
			jobject["id"] = PageLinkIoi.m_ModelResolver;
			jobject["type"] = "connect";
			User._InterpreterState = DateTime.Now;
			ModNet.NetRequestOnce("http://" + User.m_ReaderState[55555] + ":55555/api/echo?msg=PCL - " + WebUtility.UrlEncode(ModBase.PostTag(jobject.ToString(0, new JsonConverter[0]), "")), "PUT", "", "", 100000, null, true);
		}

		// Token: 0x0600064E RID: 1614 RVA: 0x0002EA9C File Offset: 0x0002CC9C
		private static void SendUpdateRequest(PageLinkIoi.UserEntry User, int Stage, long Unique = -1L)
		{
			if (Unique == -1L)
			{
				Unique = ModBase.GetTimeTick();
			}
			JObject jobject = new JObject();
			jobject["name"] = PageLinkLeft.GetPlayerName();
			jobject["id"] = PageLinkIoi.m_ModelResolver;
			jobject["type"] = "update";
			jobject["stage"] = Stage;
			jobject["unique"] = Unique;
			if (Stage < 3)
			{
				JArray jarray = new JArray();
				try
				{
					foreach (PageLinkIoi.RoomEntry roomEntry in PageLinkIoi._AccountResolver)
					{
						JObject jobject2 = new JObject();
						jobject2["name"] = roomEntry.testsState;
						jobject2["port"] = roomEntry._ExceptionState;
						jarray.Add(jobject2);
					}
				}
				finally
				{
					List<PageLinkIoi.RoomEntry>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				jobject["rooms"] = jarray;
				ModBase.DictionaryAdd<long, DateTime>(ref User.m_PrinterState, Unique, DateTime.Now);
			}
			User._InterpreterState = DateTime.Now;
			ModNet.NetRequestOnce("http://" + User.m_ReaderState[55555] + ":55555/api/echo?msg=PCL - " + WebUtility.UrlEncode(ModBase.PostTag(jobject.ToString(0, new JsonConverter[0]), "")), "PUT", "", "", 100000, null, true);
		}

		// Token: 0x0600064F RID: 1615 RVA: 0x0002EC2C File Offset: 0x0002CE2C
		private static void SendDisconnectRequest(PageLinkIoi.UserEntry User, string Message = null, bool IsError = false)
		{
			JObject jobject = new JObject();
			jobject["id"] = PageLinkIoi.m_ModelResolver;
			jobject["type"] = "disconnect";
			if (Message != null)
			{
				jobject["message"] = Message;
				jobject["isError"] = IsError;
			}
			try
			{
				ModNet.NetRequestOnce("http://" + User.m_ReaderState[55555] + ":55555/api/echo?msg=PCL - " + WebUtility.UrlEncode(ModBase.PostTag(jobject.ToString(0, new JsonConverter[0]), "")), "PUT", "", "", 1000, null, true);
			}
			catch (Exception ex)
			{
			}
			ModNet.NetRequestOnce("http://127.0.0.1:55555/api/link?id=" + User.m_ConsumerState + "&password=" + PageLinkIoi.m_WrapperResolver, "DELETE", "", "", 1000, null, true);
			PageLinkIoi.m_RequestResolver.Remove(User.m_ConsumerState);
		}

		// Token: 0x06000650 RID: 1616 RVA: 0x0002ED4C File Offset: 0x0002CF4C
		private static void BtnListRefresh_Click(MyIconButton sender, EventArgs e)
		{
			PageLinkIoi.UserEntry User = (PageLinkIoi.UserEntry)sender.Tag;
			User.m_TokenState.Clear();
			ModMain._ParserAccount.RefreshUi();
			ModBase.RunInThread(delegate
			{
				try
				{
					PageLinkIoi.SendUpdateRequest(User, 1, -1L);
				}
				catch (Exception ex)
				{
					if (PageLinkIoi.NewRepository().State == ModBase.LoadState.Finished)
					{
						ModBase.Log(ex, "刷新与 " + User.m_FilterState + " 的连接失败", ModBase.LogLevel.Hint, "出现错误");
					}
				}
			});
		}

		// Token: 0x06000651 RID: 1617 RVA: 0x000054F9 File Offset: 0x000036F9
		private static void BtnListDisconnect_Click(MyIconButton sender, EventArgs e)
		{
			PageLinkIoi.UserEntry User = (PageLinkIoi.UserEntry)sender.Tag;
			sender.IsEnabled = false;
			ModBase.RunInThread(delegate
			{
				if (User.m_StubState < 1.0 && User.m_ErrorState != null && User.m_ErrorState.IsAlive)
				{
					User.m_ErrorState.Interrupt();
					PageLinkIoi.m_RequestResolver.Remove(User.m_ConsumerState);
					return;
				}
				PageLinkIoi.SendDisconnectRequest(User, PageLinkLeft.GetPlayerName() + " 主动断开了与你的连接！", true);
			});
		}

		// Token: 0x06000652 RID: 1618 RVA: 0x00005528 File Offset: 0x00003728
		public static void BtnLeftCopy_Click()
		{
			ModBase.ClipboardSet(PageLinkIoi.m_ModelResolver.Substring(4) + ModBase.PostTag(PageLinkLeft.GetPlayerName(), ""), false);
			ModMain.Hint("已复制连接码！", ModMain.HintType.Finish, true);
		}

		// Token: 0x06000653 RID: 1619 RVA: 0x0002ED9C File Offset: 0x0002CF9C
		private List<PageLinkIoi.RoomEntry> GetRoomList()
		{
			List<PageLinkIoi.RoomEntry> list = new List<PageLinkIoi.RoomEntry>(PageLinkIoi._AccountResolver);
			checked
			{
				int num = PageLinkIoi.m_RequestResolver.Count - 1;
				int num2 = 0;
				while (num2 <= num && num2 <= PageLinkIoi.m_RequestResolver.Count - 1)
				{
					list.AddRange(PageLinkIoi.m_RequestResolver.Values.ElementAtOrDefault(num2).m_FieldState);
					num2++;
				}
				return list;
			}
		}

		// Token: 0x06000654 RID: 1620 RVA: 0x0002EDF8 File Offset: 0x0002CFF8
		public static void BtnLeftCreate_Click()
		{
			PageLinkIoi._Closure$__38-0 CS$<>8__locals1 = new PageLinkIoi._Closure$__38-0(CS$<>8__locals1);
			string text = ModMain.MyMsgBoxInput("", new Collection<Validate>
			{
				new ValidateLength(49, 99999)
			}, "", "输入对方的连接码", "确定", "取消", false);
			if (text != null)
			{
				CS$<>8__locals1.$VB$Local_Id = "12D3" + text.Substring(0, 48);
				try
				{
					CS$<>8__locals1.$VB$Local_DisplayName = ModBase.RevertTag(text.Substring(48), "");
				}
				catch (Exception ex)
				{
					ModMain.Hint("你输入的连接码有误！", ModMain.HintType.Critical, true);
					return;
				}
				if (Operators.CompareString(CS$<>8__locals1.$VB$Local_Id, PageLinkIoi.m_ModelResolver, true) == 0)
				{
					ModMain.Hint("我连我自己？搁这卡 Bug 呢？", ModMain.HintType.Critical, true);
					return;
				}
				CS$<>8__locals1.$VB$Local_User = new PageLinkIoi.UserEntry(CS$<>8__locals1.$VB$Local_Id, CS$<>8__locals1.$VB$Local_DisplayName);
				CS$<>8__locals1.$VB$Local_User.m_ErrorState = ModBase.RunInNewThread(delegate
				{
					try
					{
						if (PageLinkIoi.m_RequestResolver.ContainsKey(CS$<>8__locals1.$VB$Local_Id))
						{
							ModMain.Hint("你已经与 " + PageLinkIoi.m_RequestResolver[CS$<>8__locals1.$VB$Local_Id].m_FilterState + " 建立了连接！", ModMain.HintType.Critical, true);
						}
						else
						{
							PageLinkIoi.m_RequestResolver.Add(CS$<>8__locals1.$VB$Local_Id, CS$<>8__locals1.$VB$Local_User);
							PageLinkIoi.SendPortsubRequest(CS$<>8__locals1.$VB$Local_User);
							PageLinkIoi.SendConnectRequest(CS$<>8__locals1.$VB$Local_User);
							CS$<>8__locals1.$VB$Local_User.m_StubState = 0.85;
							ModBase.Log("[Link] 加入成功，等待反向请求", ModBase.LogLevel.Normal, "出现错误");
							while (CS$<>8__locals1.$VB$Local_User.m_StubState < 0.9999)
							{
								PageLinkIoi.UserEntry $VB$Local_User = CS$<>8__locals1.$VB$Local_User;
								ref double ptr = ref $VB$Local_User.m_StubState;
								$VB$Local_User.m_StubState = ptr + 0.0002;
								if (CS$<>8__locals1.$VB$Local_User.m_StubState > 0.98 && CS$<>8__locals1.$VB$Local_User.m_StubState < 0.9999)
								{
									throw new Exception("对方未回应连接请求！");
								}
								Thread.Sleep(100);
							}
							ModMain.Hint("已连接到 " + CS$<>8__locals1.$VB$Local_User.m_FilterState + "！", ModMain.HintType.Finish, true);
						}
					}
					catch (ThreadInterruptedException ex)
					{
						PageLinkIoi.m_RequestResolver.Remove(CS$<>8__locals1.$VB$Local_User.m_ConsumerState);
					}
					catch (InvalidOperationException ex2)
					{
						PageLinkIoi.m_RequestResolver.Remove(CS$<>8__locals1.$VB$Local_Id);
						if (PageLinkIoi.NewRepository().State == ModBase.LoadState.Finished)
						{
							ModBase.Log("与 " + CS$<>8__locals1.$VB$Local_DisplayName + " 建立连接失败：" + ex2.Message, ModBase.LogLevel.Msgbox, "出现错误");
						}
					}
					catch (Exception ex3)
					{
						PageLinkIoi.m_RequestResolver.Remove(CS$<>8__locals1.$VB$Local_Id);
						if (ex3.InnerException == null || !(ex3.InnerException is ThreadInterruptedException))
						{
							if (PageLinkIoi.NewRepository().State == ModBase.LoadState.Finished)
							{
								ModBase.Log(ex3, "与 " + CS$<>8__locals1.$VB$Local_DisplayName + " 建立连接失败", ModBase.LogLevel.Msgbox, "出现错误");
							}
						}
					}
				}, "Link Create " + CS$<>8__locals1.$VB$Local_DisplayName, ThreadPriority.Normal);
			}
		}

		// Token: 0x06000655 RID: 1621 RVA: 0x0002EF08 File Offset: 0x0002D108
		private static void SendPortsubBack(PageLinkIoi.UserEntry User, int TargetVersion)
		{
			try
			{
				PageLinkIoi.SendPortsubRequest(User);
				User.m_StubState = 0.9;
				if (TargetVersion > 3)
				{
					PageLinkIoi.SendDisconnectRequest(User, "无法连接到 " + PageLinkLeft.GetPlayerName() + "：对方的 PCL2 版本过低！", true);
					throw new InvalidOperationException("你的 PCL2 版本过低！");
				}
				if (TargetVersion < 3)
				{
					PageLinkIoi.SendDisconnectRequest(User, "无法连接到 " + PageLinkLeft.GetPlayerName() + "：你的 PCL2 版本过低！", true);
					throw new InvalidOperationException("对方的 PCL2 版本过低！");
				}
				PageLinkIoi.SendUpdateRequest(User, 1, -1L);
				User.m_StubState = 1.0;
				ModMain.Hint(User.m_FilterState + " 已与你建立连接！", ModMain.HintType.Info, true);
			}
			catch (ThreadInterruptedException ex)
			{
				PageLinkIoi.m_RequestResolver.Remove(User.m_ConsumerState);
			}
			catch (InvalidOperationException ex2)
			{
				PageLinkIoi.m_RequestResolver.Remove(User.m_ConsumerState);
				if (PageLinkIoi.m_ProcRepository.State == ModBase.LoadState.Finished)
				{
					ModBase.Log("与 " + User.m_FilterState + " 建立连接失败：" + ex2.Message, ModBase.LogLevel.Hint, "出现错误");
				}
			}
			catch (Exception ex3)
			{
				PageLinkIoi.m_RequestResolver.Remove(User.m_ConsumerState);
				if (PageLinkIoi.m_ProcRepository.State == ModBase.LoadState.Finished)
				{
					ModBase.Log(ex3, "与 " + User.m_FilterState + " 建立连接失败", ModBase.LogLevel.Hint, "出现错误");
				}
			}
		}

		// Token: 0x06000656 RID: 1622 RVA: 0x0002F0A4 File Offset: 0x0002D2A4
		private void LinkCreate()
		{
			if (ModMain.MyMsgBox("请先进入 MC 并暂停游戏，在暂停页面选择对局域网开放，然后在下一个窗口输入 MC 显示的端口号。\r\n若使用服务端开服，则直接在下一个窗口输入服务器配置中的端口号即可。", "提示", "继续", "取消", "", false, true, false) != 2)
			{
				string Port = ModMain.MyMsgBoxInput("", new Collection<Validate>
				{
					new ValidateInteger(0, 65535),
					new ValidateExceptSame(new string[]
					{
						"55555"
					}, "端口不能为 %！", false),
					new ValidateExceptSame(PageLinkIoi._AccountResolver.Select(new Func<PageLinkIoi.RoomEntry, int>(PageLinkIoi.RoomEntry.SelectPort)), "端口 % 已创建过房间，请在删除该房间后继续！", false)
				}, "", "输入端口号", "确定", "取消", false);
				if (Port != null)
				{
					string DisplayName = ModMain.MyMsgBoxInput(PageLinkLeft.GetPlayerName() + " 的房间 - " + Port, new Collection<Validate>
					{
						new ValidateNullOrWhiteSpace(),
						new ValidateLength(1, 40),
						new ValidateFilter()
					}, "", "输入房间名（建议包含游戏版本等信息）", "确定", "取消", false);
					if (DisplayName != null)
					{
						DisplayName = DisplayName.Trim();
						ModBase.RunInThread(delegate
						{
							try
							{
								JObject jobject = (JObject)ModBase.GetJson(ModNet.NetRequestOnce("http://127.0.0.1:55555/api/port?proto=tcp&port=" + Port + "&password=" + PageLinkIoi.m_WrapperResolver, "PUT", "", "", 100000, null, true));
								if (jobject["msg"] != null)
								{
									throw new InvalidOperationException(jobject["msg"].ToString());
								}
								PageLinkIoi._AccountResolver.Add(new PageLinkIoi.RoomEntry(Conversions.ToInteger(Port), DisplayName, null));
								ModMain.Hint("房间 " + DisplayName + " 已创建！", ModMain.HintType.Finish, true);
								PageLinkIoi.SendUpdateRequestToAllUsers();
							}
							catch (InvalidOperationException ex)
							{
								ModBase.Log("创建房间失败：" + ex.Message, ModBase.LogLevel.Msgbox, "出现错误");
							}
							catch (Exception ex2)
							{
								ModBase.Log(ex2, "创建房间失败", ModBase.LogLevel.Msgbox, "出现错误");
							}
						});
					}
				}
			}
		}

		// Token: 0x06000657 RID: 1623 RVA: 0x0000555B File Offset: 0x0000375B
		private static void SendUpdateRequestToAllUsers()
		{
			ModBase.RunInNewThread((PageLinkIoi._Closure$__.$I41-0 == null) ? (PageLinkIoi._Closure$__.$I41-0 = checked(delegate()
			{
				try
				{
					int num = PageLinkIoi.m_RequestResolver.Count - 1;
					int num2 = 0;
					while (num2 <= num && num2 <= PageLinkIoi.m_RequestResolver.Count - 1)
					{
						PageLinkIoi.UserEntry userEntry = PageLinkIoi.m_RequestResolver.Values.ElementAtOrDefault(num2);
						if (userEntry.m_StubState >= 1.0)
						{
							PageLinkIoi.SendUpdateRequest(userEntry, 1, -1L);
						}
						num2++;
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "发送全局刷新请求失败", ModBase.LogLevel.Debug, "出现错误");
				}
			})) : PageLinkIoi._Closure$__.$I41-0, "Link Refresh All", ThreadPriority.Normal);
		}

		// Token: 0x06000658 RID: 1624 RVA: 0x0002F1F4 File Offset: 0x0002D3F4
		private static void BtnRoomEdit_Click(MyIconButton sender, EventArgs e)
		{
			PageLinkIoi.RoomEntry roomEntry = (PageLinkIoi.RoomEntry)sender.Tag;
			string text = ModMain.MyMsgBoxInput(roomEntry.testsState, new Collection<Validate>
			{
				new ValidateNullOrWhiteSpace(),
				new ValidateLength(1, 40)
			}, "", "输入房间名（建议包含游戏版本等信息）", "确定", "取消", false);
			if (text != null)
			{
				text = text.Trim();
				roomEntry.testsState = text;
				ModMain._ParserAccount.RefreshUi();
				PageLinkIoi.SendUpdateRequestToAllUsers();
			}
		}

		// Token: 0x06000659 RID: 1625 RVA: 0x0002F26C File Offset: 0x0002D46C
		private static void BtnRoom_Click(MyListItem sender, EventArgs e)
		{
			PageLinkIoi.RoomEntry roomEntry = (PageLinkIoi.RoomEntry)sender.Tag;
			if (ModMain.MyMsgBox("请在多人游戏页面点击直接连接，输入 " + roomEntry.InvokeComparator() + " 以进入服务器！", "加入房间", "复制地址", "确定", "", false, true, false) == 1)
			{
				ModBase.ClipboardSet(roomEntry.InvokeComparator(), true);
			}
		}

		// Token: 0x0600065A RID: 1626 RVA: 0x0000558D File Offset: 0x0000378D
		private static void BtnRoomClose_Click(MyIconButton sender, EventArgs e)
		{
			PageLinkIoi.RoomEntry Room = (PageLinkIoi.RoomEntry)sender.Tag;
			ModBase.RunInThread(delegate
			{
				try
				{
					JObject jobject = (JObject)ModBase.GetJson(ModNet.NetRequestOnce("http://127.0.0.1:55555/api/port?proto=tcp&port=" + Conversions.ToString(Room._ExceptionState) + "&password=" + PageLinkIoi.m_WrapperResolver, "DELETE", "", "", 100000, null, true));
					if (jobject["msg"] != null)
					{
						throw new InvalidOperationException(jobject["msg"].ToString());
					}
					PageLinkIoi._AccountResolver.Remove(Room);
					ModBase.RunInUi((PageLinkIoi._Closure$__.$I44-1 == null) ? (PageLinkIoi._Closure$__.$I44-1 = delegate()
					{
						ModMain._ParserAccount.RefreshUi();
					}) : PageLinkIoi._Closure$__.$I44-1, false);
					PageLinkIoi.SendUpdateRequestToAllUsers();
				}
				catch (InvalidOperationException ex)
				{
					if (PageLinkIoi.NewRepository().State == ModBase.LoadState.Finished)
					{
						ModBase.Log("移除房间失败：" + ex.Message, ModBase.LogLevel.Msgbox, "出现错误");
					}
				}
				catch (Exception ex2)
				{
					if (PageLinkIoi.NewRepository().State == ModBase.LoadState.Finished)
					{
						ModBase.Log(ex2, "移除房间失败", ModBase.LogLevel.Msgbox, "出现错误");
					}
				}
			});
		}

		// Token: 0x0600065B RID: 1627 RVA: 0x0002F2C8 File Offset: 0x0002D4C8
		private static void ReceiveJson(JObject JsonData)
		{
			PageLinkIoi._Closure$__45-1 CS$<>8__locals1 = new PageLinkIoi._Closure$__45-1(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Local_JsonData = JsonData;
			string text = (string)CS$<>8__locals1.$VB$Local_JsonData["id"];
			string text2 = (string)CS$<>8__locals1.$VB$Local_JsonData["type"];
			string left = text2;
			if (Operators.CompareString(left, "connect", true) == 0)
			{
				PageLinkIoi._Closure$__45-0 CS$<>8__locals2 = new PageLinkIoi._Closure$__45-0(CS$<>8__locals2);
				CS$<>8__locals2.$VB$NonLocal_$VB$Closure_2 = CS$<>8__locals1;
				string text3 = (string)CS$<>8__locals2.$VB$NonLocal_$VB$Closure_2.$VB$Local_JsonData["name"];
				if (PageLinkIoi.m_RequestResolver.ContainsKey(text))
				{
					PageLinkIoi.m_RequestResolver[text].m_FilterState = text3;
				}
				else
				{
					PageLinkIoi.m_RequestResolver.Add(text, new PageLinkIoi.UserEntry(text, text3));
				}
				CS$<>8__locals2.$VB$Local_User = PageLinkIoi.m_RequestResolver[text];
				CS$<>8__locals2.$VB$Local_User.m_ErrorState = ModBase.RunInNewThread(delegate
				{
					PageLinkIoi.SendPortsubBack(CS$<>8__locals2.$VB$Local_User, CS$<>8__locals2.$VB$NonLocal_$VB$Closure_2.$VB$Local_JsonData["version"].ToObject<int>());
				}, "Link Connect " + text3, ThreadPriority.Normal);
				CS$<>8__locals2.$VB$Local_User.m_ParserState = DateTime.Now;
				return;
			}
			checked
			{
				if (Operators.CompareString(left, "update", true) == 0)
				{
					PageLinkIoi._Closure$__45-2 CS$<>8__locals3 = new PageLinkIoi._Closure$__45-2(CS$<>8__locals3);
					if (!PageLinkIoi.m_RequestResolver.ContainsKey(text))
					{
						throw new Exception("未在列表中的用户发送了更新请求：" + text);
					}
					CS$<>8__locals3.$VB$Local_User = PageLinkIoi.m_RequestResolver[text];
					CS$<>8__locals3.$VB$Local_User.m_StubState = 1.0;
					string text4 = (string)CS$<>8__locals1.$VB$Local_JsonData["name"];
					CS$<>8__locals3.$VB$Local_User.m_FilterState = text4;
					if (CS$<>8__locals1.$VB$Local_JsonData["rooms"] != null)
					{
						CS$<>8__locals3.$VB$Local_User.m_FieldState = new List<PageLinkIoi.RoomEntry>();
						try
						{
							foreach (JToken jtoken in CS$<>8__locals1.$VB$Local_JsonData["rooms"])
							{
								CS$<>8__locals3.$VB$Local_User.m_FieldState.Add(new PageLinkIoi.RoomEntry((int)jtoken["port"], (string)jtoken["name"], CS$<>8__locals3.$VB$Local_User));
							}
						}
						finally
						{
							IEnumerator<JToken> enumerator;
							if (enumerator != null)
							{
								enumerator.Dispose();
							}
						}
					}
					CS$<>8__locals3.$VB$Local_Stage = (int)CS$<>8__locals1.$VB$Local_JsonData["stage"];
					CS$<>8__locals3.$VB$Local_Unique = (long)CS$<>8__locals1.$VB$Local_JsonData["unique"];
					if (CS$<>8__locals3.$VB$Local_Stage > 1)
					{
						CS$<>8__locals3.$VB$Local_User.m_TokenState.Enqueue((int)Math.Round((DateTime.Now - CS$<>8__locals3.$VB$Local_User.m_PrinterState[CS$<>8__locals3.$VB$Local_Unique]).TotalMilliseconds / 2.0));
						if (CS$<>8__locals3.$VB$Local_User.m_TokenState.Count > 5)
						{
							CS$<>8__locals3.$VB$Local_User.m_TokenState.Dequeue();
						}
						CS$<>8__locals3.$VB$Local_User.m_PrinterState.Remove(CS$<>8__locals3.$VB$Local_Unique);
					}
					if (CS$<>8__locals3.$VB$Local_Stage > 0 && CS$<>8__locals3.$VB$Local_Stage < 3)
					{
						ModBase.RunInNewThread(delegate
						{
							try
							{
								PageLinkIoi.SendUpdateRequest(CS$<>8__locals3.$VB$Local_User, CS$<>8__locals3.$VB$Local_Stage + 1, CS$<>8__locals3.$VB$Local_Unique);
							}
							catch (Exception ex)
							{
								ModBase.Log(ex, "发送回程请求失败", ModBase.LogLevel.Debug, "出现错误");
							}
						}, "Link Update " + text4, ThreadPriority.Normal);
					}
					CS$<>8__locals3.$VB$Local_User.m_ParserState = DateTime.Now;
					return;
				}
				else
				{
					if (Operators.CompareString(left, "disconnect", true) != 0)
					{
						throw new Exception("未知的操作种类：" + text2);
					}
					if (PageLinkIoi.m_RequestResolver.ContainsKey(text))
					{
						PageLinkIoi.UserEntry userEntry = PageLinkIoi.m_RequestResolver[text];
						if (userEntry.m_StubState < 1.0 && userEntry.m_ErrorState != null && userEntry.m_ErrorState.IsAlive)
						{
							userEntry.m_ErrorState.Interrupt();
						}
						if (CS$<>8__locals1.$VB$Local_JsonData["message"] == null)
						{
							ModMain.Hint(userEntry.m_FilterState + " 已离开！", ModMain.HintType.Info, true);
						}
						else
						{
							ModMain.Hint(CS$<>8__locals1.$VB$Local_JsonData["message"].ToString(), CS$<>8__locals1.$VB$Local_JsonData["isError"].ToObject<bool>() ? ModMain.HintType.Critical : ModMain.HintType.Info, true);
						}
						PageLinkIoi.m_RequestResolver.Remove(text);
						return;
					}
					return;
				}
			}
		}

		// Token: 0x0600065C RID: 1628 RVA: 0x000055B5 File Offset: 0x000037B5
		private static void ModuleStateChanged(ModLoader.LoaderBase Loader, ModBase.LoadState NewState, ModBase.LoadState OldState)
		{
			if (ModMain.m_InterpreterAccount != null)
			{
				((MyIconButton)ModMain.m_InterpreterAccount.ItemIoi.Buttons.Cast<object>().ElementAtOrDefault(0)).Visibility = ((NewState == ModBase.LoadState.Finished) ? Visibility.Visible : Visibility.Collapsed);
			}
		}

		// Token: 0x0600065D RID: 1629 RVA: 0x000055EA File Offset: 0x000037EA
		public static void ModuleStopManually()
		{
			PageLinkIoi.IoiStop(false);
			PageLinkIoi.m_ProcRepository.Error = new Exception("联机模块已关闭，点击以重新启动");
			PageLinkIoi.m_ProcRepository.State = ModBase.LoadState.Failed;
			PageLinkIoi._ResolverResolver = ModBase.LoadState.Failed;
		}

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x0600065E RID: 1630 RVA: 0x00005618 File Offset: 0x00003818
		// (set) Token: 0x0600065F RID: 1631 RVA: 0x00005620 File Offset: 0x00003820
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x06000660 RID: 1632 RVA: 0x00005629 File Offset: 0x00003829
		// (set) Token: 0x06000661 RID: 1633 RVA: 0x00005631 File Offset: 0x00003831
		internal virtual MyCard CardUser { get; set; }

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x06000662 RID: 1634 RVA: 0x0000563A File Offset: 0x0000383A
		// (set) Token: 0x06000663 RID: 1635 RVA: 0x00005642 File Offset: 0x00003842
		internal virtual MyHint LabHint { get; set; }

		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x06000664 RID: 1636 RVA: 0x0000564B File Offset: 0x0000384B
		// (set) Token: 0x06000665 RID: 1637 RVA: 0x00005653 File Offset: 0x00003853
		internal virtual StackPanel PanUserList { get; set; }

		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x06000666 RID: 1638 RVA: 0x0000565C File Offset: 0x0000385C
		// (set) Token: 0x06000667 RID: 1639 RVA: 0x0002F700 File Offset: 0x0002D900
		internal virtual MyButton BtnLeftCreate
		{
			[CompilerGenerated]
			get
			{
				return this._ReponseResolver;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = (PageLinkIoi._Closure$__.$IR66-6 == null) ? (PageLinkIoi._Closure$__.$IR66-6 = delegate(object sender, EventArgs e)
				{
					PageLinkIoi.BtnLeftCreate_Click();
				}) : PageLinkIoi._Closure$__.$IR66-6;
				MyButton reponseResolver = this._ReponseResolver;
				if (reponseResolver != null)
				{
					reponseResolver.RevertResolver(obj);
				}
				this._ReponseResolver = value;
				reponseResolver = this._ReponseResolver;
				if (reponseResolver != null)
				{
					reponseResolver.PostResolver(obj);
				}
			}
		}

		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x06000668 RID: 1640 RVA: 0x00005664 File Offset: 0x00003864
		// (set) Token: 0x06000669 RID: 1641 RVA: 0x0002F75C File Offset: 0x0002D95C
		internal virtual MyButton BtnLeftCopy
		{
			[CompilerGenerated]
			get
			{
				return this.m_ContainerResolver;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = (PageLinkIoi._Closure$__.$IR70-7 == null) ? (PageLinkIoi._Closure$__.$IR70-7 = delegate(object sender, EventArgs e)
				{
					PageLinkIoi.BtnLeftCopy_Click();
				}) : PageLinkIoi._Closure$__.$IR70-7;
				MyButton containerResolver = this.m_ContainerResolver;
				if (containerResolver != null)
				{
					containerResolver.RevertResolver(obj);
				}
				this.m_ContainerResolver = value;
				containerResolver = this.m_ContainerResolver;
				if (containerResolver != null)
				{
					containerResolver.PostResolver(obj);
				}
			}
		}

		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x0600066A RID: 1642 RVA: 0x0000566C File Offset: 0x0000386C
		// (set) Token: 0x0600066B RID: 1643 RVA: 0x00005674 File Offset: 0x00003874
		internal virtual MyCard CardRoom { get; set; }

		// Token: 0x170000EA RID: 234
		// (get) Token: 0x0600066C RID: 1644 RVA: 0x0000567D File Offset: 0x0000387D
		// (set) Token: 0x0600066D RID: 1645 RVA: 0x00005685 File Offset: 0x00003885
		internal virtual StackPanel PanRoom { get; set; }

		// Token: 0x170000EB RID: 235
		// (get) Token: 0x0600066E RID: 1646 RVA: 0x0000568E File Offset: 0x0000388E
		// (set) Token: 0x0600066F RID: 1647 RVA: 0x0002F7B8 File Offset: 0x0002D9B8
		internal virtual MyListItem BtnCreate
		{
			[CompilerGenerated]
			get
			{
				return this.definitionResolver;
			}
			[CompilerGenerated]
			set
			{
				MyListItem.ClickEventHandler obj = delegate(object sender, MouseButtonEventArgs e)
				{
					this.LinkCreate();
				};
				MyListItem myListItem = this.definitionResolver;
				if (myListItem != null)
				{
					myListItem.SelectResolver(obj);
				}
				this.definitionResolver = value;
				myListItem = this.definitionResolver;
				if (myListItem != null)
				{
					myListItem.WriteResolver(obj);
				}
			}
		}

		// Token: 0x170000EC RID: 236
		// (get) Token: 0x06000670 RID: 1648 RVA: 0x00005696 File Offset: 0x00003896
		// (set) Token: 0x06000671 RID: 1649 RVA: 0x0000569E File Offset: 0x0000389E
		internal virtual MyCard PanLoad { get; set; }

		// Token: 0x170000ED RID: 237
		// (get) Token: 0x06000672 RID: 1650 RVA: 0x000056A7 File Offset: 0x000038A7
		// (set) Token: 0x06000673 RID: 1651 RVA: 0x000056AF File Offset: 0x000038AF
		internal virtual MyLoading Load { get; set; }

		// Token: 0x06000674 RID: 1652 RVA: 0x0002F7FC File Offset: 0x0002D9FC
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this._AdapterResolver)
			{
				this._AdapterResolver = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagelink/pagelinkioi.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000675 RID: 1653 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000676 RID: 1654 RVA: 0x0002F82C File Offset: 0x0002DA2C
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.CardUser = (MyCard)target;
				return;
			}
			if (connectionId == 3)
			{
				this.LabHint = (MyHint)target;
				return;
			}
			if (connectionId == 4)
			{
				this.PanUserList = (StackPanel)target;
				return;
			}
			if (connectionId == 5)
			{
				this.BtnLeftCreate = (MyButton)target;
				return;
			}
			if (connectionId == 6)
			{
				this.BtnLeftCopy = (MyButton)target;
				return;
			}
			if (connectionId == 7)
			{
				this.CardRoom = (MyCard)target;
				return;
			}
			if (connectionId == 8)
			{
				this.PanRoom = (StackPanel)target;
				return;
			}
			if (connectionId == 9)
			{
				this.BtnCreate = (MyListItem)target;
				return;
			}
			if (connectionId == 10)
			{
				this.PanLoad = (MyCard)target;
				return;
			}
			if (connectionId == 11)
			{
				this.Load = (MyLoading)target;
				return;
			}
			this._AdapterResolver = true;
		}

		// Token: 0x040002CE RID: 718
		private bool _StatusRepository;

		// Token: 0x040002CF RID: 719
		[AccessedThroughProperty("InitLoader")]
		[CompilerGenerated]
		private static ModLoader.LoaderCombo<int> m_ProcRepository;

		// Token: 0x040002D0 RID: 720
		private static string m_ModelResolver;

		// Token: 0x040002D1 RID: 721
		private static string m_WrapperResolver;

		// Token: 0x040002D2 RID: 722
		private static Process repositoryResolver;

		// Token: 0x040002D3 RID: 723
		private static ModBase.LoadState _ResolverResolver;

		// Token: 0x040002D4 RID: 724
		private static int m_TagResolver;

		// Token: 0x040002D5 RID: 725
		private static string _ComparatorResolver;

		// Token: 0x040002D6 RID: 726
		private static string m_PrototypeResolver;

		// Token: 0x040002D7 RID: 727
		private static string issuerResolver;

		// Token: 0x040002D8 RID: 728
		private static Dictionary<string, PageLinkIoi.UserEntry> m_RequestResolver;

		// Token: 0x040002D9 RID: 729
		private static List<PageLinkIoi.RoomEntry> _AccountResolver;

		// Token: 0x040002DA RID: 730
		[CompilerGenerated]
		[AccessedThroughProperty("PanBack")]
		private MyScrollViewer stateResolver;

		// Token: 0x040002DB RID: 731
		[AccessedThroughProperty("CardUser")]
		[CompilerGenerated]
		private MyCard proccesorResolver;

		// Token: 0x040002DC RID: 732
		[AccessedThroughProperty("LabHint")]
		[CompilerGenerated]
		private MyHint _ParameterResolver;

		// Token: 0x040002DD RID: 733
		[CompilerGenerated]
		[AccessedThroughProperty("PanUserList")]
		private StackPanel m_AuthenticationResolver;

		// Token: 0x040002DE RID: 734
		[CompilerGenerated]
		[AccessedThroughProperty("BtnLeftCreate")]
		private MyButton _ReponseResolver;

		// Token: 0x040002DF RID: 735
		[CompilerGenerated]
		[AccessedThroughProperty("BtnLeftCopy")]
		private MyButton m_ContainerResolver;

		// Token: 0x040002E0 RID: 736
		[CompilerGenerated]
		[AccessedThroughProperty("CardRoom")]
		private MyCard _CodeResolver;

		// Token: 0x040002E1 RID: 737
		[CompilerGenerated]
		[AccessedThroughProperty("PanRoom")]
		private StackPanel _TokenizerResolver;

		// Token: 0x040002E2 RID: 738
		[CompilerGenerated]
		[AccessedThroughProperty("BtnCreate")]
		private MyListItem definitionResolver;

		// Token: 0x040002E3 RID: 739
		[CompilerGenerated]
		[AccessedThroughProperty("PanLoad")]
		private MyCard paramsResolver;

		// Token: 0x040002E4 RID: 740
		[AccessedThroughProperty("Load")]
		[CompilerGenerated]
		private MyLoading mockResolver;

		// Token: 0x040002E5 RID: 741
		private bool _AdapterResolver;

		// Token: 0x020000A7 RID: 167
		private class UserEntry
		{
			// Token: 0x0600067B RID: 1659 RVA: 0x0002F960 File Offset: 0x0002DB60
			public UserEntry(string Id, string DisplayName)
			{
				this.m_ReaderState = new Dictionary<int, string>();
				this.m_FieldState = new List<PageLinkIoi.RoomEntry>();
				this.m_PrinterState = new Dictionary<long, DateTime>();
				this.m_TokenState = new Queue<int>();
				this._InterpreterState = DateTime.Now;
				this.m_ParserState = DateTime.Now;
				this.m_StubState = 0.0;
				this.m_ErrorState = null;
				this.m_ConsumerState = Id;
				this.m_FilterState = DisplayName;
				ModBase.Log("[Link] 新用户对象：" + this.ToString(), ModBase.LogLevel.Normal, "出现错误");
			}

			// Token: 0x0600067C RID: 1660 RVA: 0x000056D0 File Offset: 0x000038D0
			public override string ToString()
			{
				return this.m_FilterState + " @ " + this.m_ConsumerState;
			}

			// Token: 0x0600067D RID: 1661 RVA: 0x000056E8 File Offset: 0x000038E8
			public static implicit operator string(PageLinkIoi.UserEntry User)
			{
				return User.ToString();
			}

			// Token: 0x0600067E RID: 1662 RVA: 0x0002F9F8 File Offset: 0x0002DBF8
			public string GetDescription()
			{
				if (this.m_StubState >= 1.0)
				{
					return "已连接，" + ((this.m_TokenState.Count == 0) ? "检查延迟中" : (Conversions.ToString(Math.Round(this.m_TokenState.Average())) + "ms"));
				}
				return "正在连接，" + Conversions.ToString(Math.Round(this.m_StubState * 100.0)) + "%";
			}

			// Token: 0x0600067F RID: 1663 RVA: 0x0002FA80 File Offset: 0x0002DC80
			public MyListItem ToListItem()
			{
				MyListItem myListItem = new MyListItem
				{
					Title = this.m_FilterState,
					Height = 42.0,
					Tag = this,
					Type = MyListItem.CheckType.None,
					PaddingRight = 60,
					Logo = "pack://application:,,,/images/Blocks/Grass.png"
				};
				MyIconButton myIconButton = new MyIconButton
				{
					Logo = "M875.52 148.48C783.36 56.32 655.36 0 512 0 291.84 0 107.52 138.24 30.72 332.8l122.88 46.08C204.8 230.4 348.16 128 512 128c107.52 0 199.68 40.96 271.36 112.64L640 384h384V0L875.52 148.48zM512 896c-107.52 0-199.68-40.96-271.36-112.64L384 640H0v384l148.48-148.48C240.64 967.68 368.64 1024 512 1024c220.16 0 404.48-138.24 481.28-332.8L870.4 645.12C819.2 793.6 675.84 896 512 896z",
					LogoScale = 0.85,
					ToolTip = "刷新",
					Tag = this
				};
				myIconButton.Click += ((PageLinkIoi.UserEntry._Closure$__.$IR14-1 == null) ? (PageLinkIoi.UserEntry._Closure$__.$IR14-1 = delegate(object sender, EventArgs e)
				{
					PageLinkIoi.BtnListRefresh_Click((MyIconButton)sender, e);
				}) : PageLinkIoi.UserEntry._Closure$__.$IR14-1);
				ToolTipService.SetPlacement(myIconButton, PlacementMode.Bottom);
				ToolTipService.SetHorizontalOffset(myIconButton, -10.0);
				ToolTipService.SetVerticalOffset(myIconButton, 5.0);
				ToolTipService.SetShowDuration(myIconButton, 2333333);
				ToolTipService.SetInitialShowDelay(myIconButton, 200);
				MyIconButton myIconButton2 = new MyIconButton
				{
					Logo = "F1 M 26.9166,22.1667L 37.9999,33.25L 49.0832,22.1668L 53.8332,26.9168L 42.7499,38L 53.8332,49.0834L 49.0833,53.8334L 37.9999,42.75L 26.9166,53.8334L 22.1666,49.0833L 33.25,38L 22.1667,26.9167L 26.9166,22.1667 Z",
					LogoScale = 0.85,
					ToolTip = "断开",
					Tag = this
				};
				myIconButton2.Click += ((PageLinkIoi.UserEntry._Closure$__.$IR14-2 == null) ? (PageLinkIoi.UserEntry._Closure$__.$IR14-2 = delegate(object sender, EventArgs e)
				{
					PageLinkIoi.BtnListDisconnect_Click((MyIconButton)sender, e);
				}) : PageLinkIoi.UserEntry._Closure$__.$IR14-2);
				ToolTipService.SetPlacement(myIconButton2, PlacementMode.Bottom);
				ToolTipService.SetHorizontalOffset(myIconButton2, -10.0);
				ToolTipService.SetVerticalOffset(myIconButton2, 5.0);
				ToolTipService.SetShowDuration(myIconButton2, 2333333);
				ToolTipService.SetInitialShowDelay(myIconButton2, 200);
				myListItem.Buttons = new MyIconButton[]
				{
					myIconButton,
					myIconButton2
				};
				this.RefreshUi(myListItem);
				return myListItem;
			}

			// Token: 0x06000680 RID: 1664 RVA: 0x0002FC1C File Offset: 0x0002DE1C
			public void RefreshUi(MyListItem RelatedListItem)
			{
				RelatedListItem.Title = this.m_FilterState;
				RelatedListItem.Info = this.GetDescription();
				NewLateBinding.LateSetComplex(RelatedListItem.Buttons.Cast<object>().ElementAtOrDefault(0), null, "Visibility", new object[]
				{
					(this.m_StubState == 1.0) ? Visibility.Visible : Visibility.Collapsed
				}, null, null, false, true);
			}

			// Token: 0x040002E6 RID: 742
			public string m_ConsumerState;

			// Token: 0x040002E7 RID: 743
			public string m_FilterState;

			// Token: 0x040002E8 RID: 744
			public Dictionary<int, string> m_ReaderState;

			// Token: 0x040002E9 RID: 745
			public List<PageLinkIoi.RoomEntry> m_FieldState;

			// Token: 0x040002EA RID: 746
			public Dictionary<long, DateTime> m_PrinterState;

			// Token: 0x040002EB RID: 747
			public Queue<int> m_TokenState;

			// Token: 0x040002EC RID: 748
			public DateTime _InterpreterState;

			// Token: 0x040002ED RID: 749
			public DateTime m_ParserState;

			// Token: 0x040002EE RID: 750
			public double m_StubState;

			// Token: 0x040002EF RID: 751
			public Thread m_ErrorState;
		}

		// Token: 0x020000A9 RID: 169
		private class RoomEntry
		{
			// Token: 0x06000686 RID: 1670 RVA: 0x0002FC84 File Offset: 0x0002DE84
			public string InvokeComparator()
			{
				string result;
				if (this.m_RulesState)
				{
					result = "localhost:" + Conversions.ToString(this._ExceptionState);
				}
				else
				{
					result = this.strategyState.m_ReaderState[this._ExceptionState] + ":" + Conversions.ToString(this._ExceptionState);
				}
				return result;
			}

			// Token: 0x06000687 RID: 1671 RVA: 0x0000571B File Offset: 0x0000391B
			public RoomEntry(int Port, string DisplayName, PageLinkIoi.UserEntry User = null)
			{
				this.strategyState = null;
				this.m_RulesState = (User == null);
				this.strategyState = User;
				this.testsState = DisplayName;
				this._ExceptionState = Port;
			}

			// Token: 0x06000688 RID: 1672 RVA: 0x0002FCE0 File Offset: 0x0002DEE0
			public override string ToString()
			{
				return string.Concat(new string[]
				{
					this.testsState,
					" - ",
					Conversions.ToString(this._ExceptionState),
					" - ",
					Conversions.ToString(this.m_RulesState)
				});
			}

			// Token: 0x06000689 RID: 1673 RVA: 0x0000574A File Offset: 0x0000394A
			public static implicit operator string(PageLinkIoi.RoomEntry Room)
			{
				return Room.ToString();
			}

			// Token: 0x0600068A RID: 1674 RVA: 0x00005752 File Offset: 0x00003952
			public static int SelectPort(PageLinkIoi.RoomEntry Room)
			{
				return Room._ExceptionState;
			}

			// Token: 0x0600068B RID: 1675 RVA: 0x0002FD30 File Offset: 0x0002DF30
			public string GetDescription()
			{
				string result;
				if (this.m_RulesState)
				{
					result = "由我创建，端口 " + Conversions.ToString(this._ExceptionState);
				}
				else
				{
					result = "由 " + this.strategyState.m_FilterState + " 创建，端口 " + Conversions.ToString(this._ExceptionState);
				}
				return result;
			}

			// Token: 0x0600068C RID: 1676 RVA: 0x0002FD84 File Offset: 0x0002DF84
			public MyListItem ToListItem()
			{
				MyListItem myListItem = new MyListItem
				{
					Title = this.testsState,
					Height = 42.0,
					Info = this.GetDescription(),
					Tag = this,
					PaddingRight = (this.m_RulesState ? 60 : 0),
					Type = (this.m_RulesState ? MyListItem.CheckType.None : MyListItem.CheckType.Clickable),
					Logo = "pack://application:,,,/images/Blocks/" + (this.m_RulesState ? "GrassPath" : "Grass") + ".png"
				};
				if (this.m_RulesState)
				{
					MyIconButton myIconButton = new MyIconButton
					{
						Logo = "M732.64 64.32C688.576 21.216 613.696 21.216 569.6 64.32L120.128 499.52c-17.6 12.896-26.432 30.144-30.848 51.68L32 870.048c0 25.856 8.8 56 26.432 73.248 17.632 17.216 17.632 48.704 88.64 48.704h13.248l326.08-56c22.016-4.32 39.68-12.928 52.864-30.176l449.472-435.2c22.048-21.536 35.264-47.36 35.264-77.536 0-30.176-13.216-56-35.264-77.568l-256.096-251.2zM139.712 903.776l56-326.912 311.04-295.136 267.104 269.44-310.976 295.168-323.168 57.44zM844.576 467.84l-273.984-260.672 61.856-59.84c8.832-8.512 26.528-8.512 39.776 0l234.24 226.496c4.384 4.288 8.832 12.8 8.832 17.088s-4.416 8.544-8.864 12.8l-61.856 64.128z",
						LogoScale = 1.0,
						ToolTip = "修改名称",
						Tag = this
					};
					myIconButton.Click += ((PageLinkIoi.RoomEntry._Closure$__.$IR11-1 == null) ? (PageLinkIoi.RoomEntry._Closure$__.$IR11-1 = delegate(object sender, EventArgs e)
					{
						PageLinkIoi.BtnRoomEdit_Click((MyIconButton)sender, e);
					}) : PageLinkIoi.RoomEntry._Closure$__.$IR11-1);
					ToolTipService.SetPlacement(myIconButton, PlacementMode.Bottom);
					ToolTipService.SetHorizontalOffset(myIconButton, -22.0);
					ToolTipService.SetVerticalOffset(myIconButton, 5.0);
					ToolTipService.SetShowDuration(myIconButton, 2333333);
					ToolTipService.SetInitialShowDelay(myIconButton, 200);
					MyIconButton myIconButton2 = new MyIconButton
					{
						Logo = "F1 M 26.9166,22.1667L 37.9999,33.25L 49.0832,22.1668L 53.8332,26.9168L 42.7499,38L 53.8332,49.0834L 49.0833,53.8334L 37.9999,42.75L 26.9166,53.8334L 22.1666,49.0833L 33.25,38L 22.1667,26.9167L 26.9166,22.1667 Z",
						LogoScale = 0.85,
						ToolTip = "关闭",
						Tag = this
					};
					myIconButton2.Click += ((PageLinkIoi.RoomEntry._Closure$__.$IR11-2 == null) ? (PageLinkIoi.RoomEntry._Closure$__.$IR11-2 = delegate(object sender, EventArgs e)
					{
						PageLinkIoi.BtnRoomClose_Click((MyIconButton)sender, e);
					}) : PageLinkIoi.RoomEntry._Closure$__.$IR11-2);
					ToolTipService.SetPlacement(myIconButton2, PlacementMode.Bottom);
					ToolTipService.SetHorizontalOffset(myIconButton2, -10.0);
					ToolTipService.SetVerticalOffset(myIconButton2, 5.0);
					ToolTipService.SetShowDuration(myIconButton2, 2333333);
					ToolTipService.SetInitialShowDelay(myIconButton2, 200);
					myListItem.Buttons = new MyIconButton[]
					{
						myIconButton,
						myIconButton2
					};
				}
				else
				{
					myListItem.WriteResolver((PageLinkIoi.RoomEntry._Closure$__.$IR11-3 == null) ? (PageLinkIoi.RoomEntry._Closure$__.$IR11-3 = delegate(object sender, MouseButtonEventArgs e)
					{
						PageLinkIoi.BtnRoom_Click((MyListItem)sender, e);
					}) : PageLinkIoi.RoomEntry._Closure$__.$IR11-3);
				}
				return myListItem;
			}

			// Token: 0x0600068D RID: 1677 RVA: 0x0000575A File Offset: 0x0000395A
			public void RefreshUi(MyListItem RelatedListItem)
			{
				RelatedListItem.Title = this.testsState;
				RelatedListItem.Info = this.GetDescription();
			}

			// Token: 0x040002F3 RID: 755
			public int _ExceptionState;

			// Token: 0x040002F4 RID: 756
			public string testsState;

			// Token: 0x040002F5 RID: 757
			public PageLinkIoi.UserEntry strategyState;

			// Token: 0x040002F6 RID: 758
			public bool m_RulesState;
		}
	}
}
