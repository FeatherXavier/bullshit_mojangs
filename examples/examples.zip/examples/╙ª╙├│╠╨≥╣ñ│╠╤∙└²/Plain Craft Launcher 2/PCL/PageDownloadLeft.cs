﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200014D RID: 333
	[DesignerGenerated]
	public class PageDownloadLeft : MyPageLeft, IComponentConnector
	{
		// Token: 0x06000D5E RID: 3422 RVA: 0x00008A57 File Offset: 0x00006C57
		public PageDownloadLeft()
		{
			this.paramsPrototype = FormMain.PageSubType.DownloadInstall;
			this.InitializeComponent();
		}

		// Token: 0x06000D5F RID: 3423 RVA: 0x00008A6D File Offset: 0x00006C6D
		private void PageCheck(MyListItem sender, ModBase.RouteEventArgs e)
		{
			if (sender.Tag != null)
			{
				this.PageChange(checked((FormMain.PageSubType)Math.Round(ModBase.Val(RuntimeHelpers.GetObjectValue(sender.Tag)))));
			}
		}

		// Token: 0x06000D60 RID: 3424 RVA: 0x000642F4 File Offset: 0x000624F4
		public object PageGet(FormMain.PageSubType ID = (FormMain.PageSubType)(-1))
		{
			if (ID == (FormMain.PageSubType)(-1))
			{
				ID = this.paramsPrototype;
			}
			switch (ID)
			{
			case FormMain.PageSubType.DownloadInstall:
				if (ModMain._TestsAccount == null)
				{
					ModMain._TestsAccount = new PageDownloadInstall();
				}
				return ModMain._TestsAccount;
			case FormMain.PageSubType.DownloadClient:
				if (ModMain.strategyAccount == null)
				{
					ModMain.strategyAccount = new PageDownloadClient();
				}
				return ModMain.strategyAccount;
			case FormMain.PageSubType.DownloadOptiFine:
				if (ModMain._RulesAccount == null)
				{
					ModMain._RulesAccount = new PageDownloadOptiFine();
				}
				return ModMain._RulesAccount;
			case FormMain.PageSubType.DownloadForge:
				if (ModMain._DicAccount == null)
				{
					ModMain._DicAccount = new PageDownloadForge();
				}
				return ModMain._DicAccount;
			case FormMain.PageSubType.DownloadFabric:
				if (ModMain.configurationAccount == null)
				{
					ModMain.configurationAccount = new PageDownloadFabric();
				}
				return ModMain.configurationAccount;
			case FormMain.PageSubType.DownloadLiteLoader:
				if (ModMain._WorkerAccount == null)
				{
					ModMain._WorkerAccount = new PageDownloadLiteLoader();
				}
				return ModMain._WorkerAccount;
			case FormMain.PageSubType.DownloadMod:
				if (ModMain.m_ConfigAccount == null)
				{
					ModMain.m_ConfigAccount = new PageDownloadMod();
				}
				return ModMain.m_ConfigAccount;
			case FormMain.PageSubType.DownloadPack:
				if (ModMain.managerAccount == null)
				{
					ModMain.managerAccount = new PageDownloadPack();
				}
				return ModMain.managerAccount;
			}
			throw new Exception("未知的下载子页面种类：" + Conversions.ToString((int)ID));
		}

		// Token: 0x06000D61 RID: 3425 RVA: 0x00064430 File Offset: 0x00062630
		public void PageChange(FormMain.PageSubType ID)
		{
			checked
			{
				if (this.paramsPrototype != ID)
				{
					ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
					try
					{
						PageDownloadLeft.PageChangeRun((MyPageRight)this.PageGet(ID));
						this.paramsPrototype = ID;
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "切换设置分页面失败（ID " + Conversions.ToString((int)ID) + "）", ModBase.LogLevel.Feedback, "出现错误");
					}
					finally
					{
						ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
					}
				}
			}
		}

		// Token: 0x06000D62 RID: 3426 RVA: 0x000644C4 File Offset: 0x000626C4
		private static void PageChangeRun(MyPageRight Target)
		{
			if (Target.Parent != null)
			{
				Target.SetValue(ContentPresenter.ContentProperty, null);
			}
			ModMain.m_CollectionAccount.m_RequestAccount = Target;
			((MyPageRight)ModMain.m_CollectionAccount.PanMainRight.Child).PageOnExit();
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaCode((PageDownloadLeft._Closure$__.$I5-0 == null) ? (PageDownloadLeft._Closure$__.$I5-0 = delegate()
				{
					((MyPageRight)ModMain.m_CollectionAccount.PanMainRight.Child).PageOnForceExit();
					ModMain.m_CollectionAccount.PanMainRight.Child = ModMain.m_CollectionAccount.m_RequestAccount;
					ModMain.m_CollectionAccount.m_RequestAccount.Opacity = 0.0;
				}) : PageDownloadLeft._Closure$__.$I5-0, 130, false),
				ModAnimation.AaCode((PageDownloadLeft._Closure$__.$I5-1 == null) ? (PageDownloadLeft._Closure$__.$I5-1 = delegate()
				{
					ModMain.m_CollectionAccount.m_RequestAccount.Opacity = 1.0;
					ModMain.m_CollectionAccount.m_RequestAccount.PageOnEnter();
				}) : PageDownloadLeft._Closure$__.$I5-1, 30, true)
			}, "PageLeft PageChange", false);
		}

		// Token: 0x06000D63 RID: 3427 RVA: 0x00064584 File Offset: 0x00062784
		public void Refresh(object sender, EventArgs e)
		{
			double num = ModBase.Val(RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(sender, null, "Tag", new object[0], null, null, null)));
			if (num == 1.0)
			{
				ModDownload.propertyTag.Start(null, true);
				ModDownload.m_AlgoTag.Start(null, true);
				ModDownload.m_WatcherTag.Start(null, true);
				ModDownload.iteratorTag.Start(null, true);
				ModDownload.m_ValueTag.Start(null, true);
				ModDownload._HelperTag.Start(null, true);
				return;
			}
			if (num == 10.0)
			{
				if (ModMain.m_ConfigAccount != null)
				{
					ModMain.m_ConfigAccount.PageLoaderRestart(null, true);
					return;
				}
			}
			else if (num == 11.0)
			{
				if (ModMain.managerAccount != null)
				{
					ModMain.managerAccount.PageLoaderRestart(null, true);
					return;
				}
			}
			else
			{
				if (num == 4.0)
				{
					ModDownload.propertyTag.Start(null, true);
					return;
				}
				if (num == 5.0)
				{
					ModDownload.m_AlgoTag.Start(null, true);
					return;
				}
				if (num == 6.0)
				{
					ModDownload.m_WatcherTag.Start(null, true);
					return;
				}
				if (num == 8.0)
				{
					ModDownload.iteratorTag.Start(null, true);
					return;
				}
				if (num == 7.0)
				{
					ModDownload.m_ValueTag.Start(null, true);
				}
			}
		}

		// Token: 0x06000D64 RID: 3428 RVA: 0x00008A93 File Offset: 0x00006C93
		private void ItemInstall_Click(object sender, MouseButtonEventArgs e)
		{
			if (this.ItemInstall.Checked)
			{
				ModMain._TestsAccount.ExitSelectPage();
			}
		}

		// Token: 0x06000D65 RID: 3429 RVA: 0x000646C8 File Offset: 0x000628C8
		private void ItemHand_Click(object sender, ModBase.RouteEventArgs e)
		{
			checked
			{
				if (this.ItemHand.Checked)
				{
					e.proxyParameter = true;
					ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
					if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("HintHandInstall", null))))
					{
						ModBase._ParamsState.Set("HintHandInstall", true, false, null);
						if (ModMain.MyMsgBox("手动安装包功能提供了 OptiFine、Forge 等组件的 .jar 安装文件下载，但无法自动安装。\r\n在自动安装页面先选择 MC 版本，然后就可以选择 OptiFine、Forge 等组件，让 PCL2 自动进行安装了。", "自动安装提示", "返回自动安装", "继续下载手动安装包", "", false, true, false) == 1)
						{
							ModMain.m_CollectionAccount.PageChange(new FormMain.PageStackData
							{
								m_CreatorParameter = FormMain.PageType.Download
							}, FormMain.PageSubType.DownloadInstall);
							ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
							return;
						}
					}
					this.ItemHand.Visibility = Visibility.Collapsed;
					this.LabGame.Visibility = Visibility.Collapsed;
					this.LabHand.Visibility = Visibility.Visible;
					this.ItemClient.Visibility = Visibility.Visible;
					this.ItemOptiFine.Visibility = Visibility.Visible;
					this.ItemFabric.Visibility = Visibility.Visible;
					this.ItemForge.Visibility = Visibility.Visible;
					this.ItemLiteLoader.Visibility = Visibility.Visible;
					ModBase.RunInThread(delegate
					{
						Thread.Sleep(20);
						ModBase.RunInUiWait(delegate
						{
							this.ItemClient.SetChecked(true, true, true);
						});
						ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
					});
				}
			}
		}

		// Token: 0x06000D66 RID: 3430 RVA: 0x000647E4 File Offset: 0x000629E4
		private void LabHand_Click(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
			checked
			{
				ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
				this.ItemHand.Visibility = Visibility.Visible;
				this.LabGame.Visibility = Visibility.Visible;
				this.LabHand.Visibility = Visibility.Collapsed;
				this.ItemClient.Visibility = Visibility.Collapsed;
				this.ItemOptiFine.Visibility = Visibility.Collapsed;
				this.ItemFabric.Visibility = Visibility.Collapsed;
				this.ItemForge.Visibility = Visibility.Collapsed;
				this.ItemLiteLoader.Visibility = Visibility.Collapsed;
				ModBase.RunInThread(delegate
				{
					Thread.Sleep(20);
					ModBase.RunInUiWait(delegate
					{
						this.ItemInstall.SetChecked(true, true, true);
					});
					ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
				});
			}
		}

		// Token: 0x1700020D RID: 525
		// (get) Token: 0x06000D67 RID: 3431 RVA: 0x00008AAC File Offset: 0x00006CAC
		// (set) Token: 0x06000D68 RID: 3432 RVA: 0x00008AB4 File Offset: 0x00006CB4
		internal virtual StackPanel PanItem { get; set; }

		// Token: 0x1700020E RID: 526
		// (get) Token: 0x06000D69 RID: 3433 RVA: 0x00008ABD File Offset: 0x00006CBD
		// (set) Token: 0x06000D6A RID: 3434 RVA: 0x00008AC5 File Offset: 0x00006CC5
		internal virtual TextBlock LabGame { get; set; }

		// Token: 0x1700020F RID: 527
		// (get) Token: 0x06000D6B RID: 3435 RVA: 0x00008ACE File Offset: 0x00006CCE
		// (set) Token: 0x06000D6C RID: 3436 RVA: 0x00064878 File Offset: 0x00062A78
		internal virtual MyListItem ItemInstall
		{
			[CompilerGenerated]
			get
			{
				return this.initializerPrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem.ClickEventHandler obj = new MyListItem.ClickEventHandler(this.ItemInstall_Click);
				MyListItem myListItem = this.initializerPrototype;
				if (myListItem != null)
				{
					myListItem.Check -= value2;
					myListItem.SelectResolver(obj);
				}
				this.initializerPrototype = value;
				myListItem = this.initializerPrototype;
				if (myListItem != null)
				{
					myListItem.Check += value2;
					myListItem.WriteResolver(obj);
				}
			}
		}

		// Token: 0x17000210 RID: 528
		// (get) Token: 0x06000D6D RID: 3437 RVA: 0x00008AD6 File Offset: 0x00006CD6
		// (set) Token: 0x06000D6E RID: 3438 RVA: 0x000648D8 File Offset: 0x00062AD8
		internal virtual MyListItem ItemHand
		{
			[CompilerGenerated]
			get
			{
				return this.m_SystemPrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.ChangedEventHandler value2 = new IMyRadio.ChangedEventHandler(this.ItemHand_Click);
				MyListItem systemPrototype = this.m_SystemPrototype;
				if (systemPrototype != null)
				{
					systemPrototype.Changed -= value2;
				}
				this.m_SystemPrototype = value;
				systemPrototype = this.m_SystemPrototype;
				if (systemPrototype != null)
				{
					systemPrototype.Changed += value2;
				}
			}
		}

		// Token: 0x17000211 RID: 529
		// (get) Token: 0x06000D6F RID: 3439 RVA: 0x00008ADE File Offset: 0x00006CDE
		// (set) Token: 0x06000D70 RID: 3440 RVA: 0x0006491C File Offset: 0x00062B1C
		internal virtual TextBlock LabHand
		{
			[CompilerGenerated]
			get
			{
				return this.m_WriterPrototype;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = new MouseButtonEventHandler(this.LabHand_Click);
				TextBlock writerPrototype = this.m_WriterPrototype;
				if (writerPrototype != null)
				{
					writerPrototype.MouseLeftButtonUp -= value2;
				}
				this.m_WriterPrototype = value;
				writerPrototype = this.m_WriterPrototype;
				if (writerPrototype != null)
				{
					writerPrototype.MouseLeftButtonUp += value2;
				}
			}
		}

		// Token: 0x17000212 RID: 530
		// (get) Token: 0x06000D71 RID: 3441 RVA: 0x00008AE6 File Offset: 0x00006CE6
		// (set) Token: 0x06000D72 RID: 3442 RVA: 0x00064960 File Offset: 0x00062B60
		internal virtual MyListItem ItemClient
		{
			[CompilerGenerated]
			get
			{
				return this._BroadcasterPrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem broadcasterPrototype = this._BroadcasterPrototype;
				if (broadcasterPrototype != null)
				{
					broadcasterPrototype.Check -= value2;
				}
				this._BroadcasterPrototype = value;
				broadcasterPrototype = this._BroadcasterPrototype;
				if (broadcasterPrototype != null)
				{
					broadcasterPrototype.Check += value2;
				}
			}
		}

		// Token: 0x17000213 RID: 531
		// (get) Token: 0x06000D73 RID: 3443 RVA: 0x00008AEE File Offset: 0x00006CEE
		// (set) Token: 0x06000D74 RID: 3444 RVA: 0x000649A4 File Offset: 0x00062BA4
		internal virtual MyListItem ItemOptiFine
		{
			[CompilerGenerated]
			get
			{
				return this._AttributePrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem attributePrototype = this._AttributePrototype;
				if (attributePrototype != null)
				{
					attributePrototype.Check -= value2;
				}
				this._AttributePrototype = value;
				attributePrototype = this._AttributePrototype;
				if (attributePrototype != null)
				{
					attributePrototype.Check += value2;
				}
			}
		}

		// Token: 0x17000214 RID: 532
		// (get) Token: 0x06000D75 RID: 3445 RVA: 0x00008AF6 File Offset: 0x00006CF6
		// (set) Token: 0x06000D76 RID: 3446 RVA: 0x000649E8 File Offset: 0x00062BE8
		internal virtual MyListItem ItemForge
		{
			[CompilerGenerated]
			get
			{
				return this._SpecificationPrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem specificationPrototype = this._SpecificationPrototype;
				if (specificationPrototype != null)
				{
					specificationPrototype.Check -= value2;
				}
				this._SpecificationPrototype = value;
				specificationPrototype = this._SpecificationPrototype;
				if (specificationPrototype != null)
				{
					specificationPrototype.Check += value2;
				}
			}
		}

		// Token: 0x17000215 RID: 533
		// (get) Token: 0x06000D77 RID: 3447 RVA: 0x00008AFE File Offset: 0x00006CFE
		// (set) Token: 0x06000D78 RID: 3448 RVA: 0x00064A2C File Offset: 0x00062C2C
		internal virtual MyListItem ItemFabric
		{
			[CompilerGenerated]
			get
			{
				return this.predicatePrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem myListItem = this.predicatePrototype;
				if (myListItem != null)
				{
					myListItem.Check -= value2;
				}
				this.predicatePrototype = value;
				myListItem = this.predicatePrototype;
				if (myListItem != null)
				{
					myListItem.Check += value2;
				}
			}
		}

		// Token: 0x17000216 RID: 534
		// (get) Token: 0x06000D79 RID: 3449 RVA: 0x00008B06 File Offset: 0x00006D06
		// (set) Token: 0x06000D7A RID: 3450 RVA: 0x00064A70 File Offset: 0x00062C70
		internal virtual MyListItem ItemLiteLoader
		{
			[CompilerGenerated]
			get
			{
				return this.m_ClientPrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem clientPrototype = this.m_ClientPrototype;
				if (clientPrototype != null)
				{
					clientPrototype.Check -= value2;
				}
				this.m_ClientPrototype = value;
				clientPrototype = this.m_ClientPrototype;
				if (clientPrototype != null)
				{
					clientPrototype.Check += value2;
				}
			}
		}

		// Token: 0x17000217 RID: 535
		// (get) Token: 0x06000D7B RID: 3451 RVA: 0x00008B0E File Offset: 0x00006D0E
		// (set) Token: 0x06000D7C RID: 3452 RVA: 0x00064AB4 File Offset: 0x00062CB4
		internal virtual MyListItem ItemMod
		{
			[CompilerGenerated]
			get
			{
				return this._InfoPrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem infoPrototype = this._InfoPrototype;
				if (infoPrototype != null)
				{
					infoPrototype.Check -= value2;
				}
				this._InfoPrototype = value;
				infoPrototype = this._InfoPrototype;
				if (infoPrototype != null)
				{
					infoPrototype.Check += value2;
				}
			}
		}

		// Token: 0x17000218 RID: 536
		// (get) Token: 0x06000D7D RID: 3453 RVA: 0x00008B16 File Offset: 0x00006D16
		// (set) Token: 0x06000D7E RID: 3454 RVA: 0x00064AF8 File Offset: 0x00062CF8
		internal virtual MyListItem ItemPack
		{
			[CompilerGenerated]
			get
			{
				return this.m_DecoratorPrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem decoratorPrototype = this.m_DecoratorPrototype;
				if (decoratorPrototype != null)
				{
					decoratorPrototype.Check -= value2;
				}
				this.m_DecoratorPrototype = value;
				decoratorPrototype = this.m_DecoratorPrototype;
				if (decoratorPrototype != null)
				{
					decoratorPrototype.Check += value2;
				}
			}
		}

		// Token: 0x06000D7F RID: 3455 RVA: 0x00064B3C File Offset: 0x00062D3C
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_PropertyPrototype)
			{
				this.m_PropertyPrototype = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagedownload/pagedownloadleft.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000D80 RID: 3456 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000D81 RID: 3457 RVA: 0x00064B6C File Offset: 0x00062D6C
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanItem = (StackPanel)target;
				return;
			}
			if (connectionId == 2)
			{
				this.LabGame = (TextBlock)target;
				return;
			}
			if (connectionId == 3)
			{
				this.ItemInstall = (MyListItem)target;
				return;
			}
			if (connectionId == 4)
			{
				this.ItemHand = (MyListItem)target;
				return;
			}
			if (connectionId == 5)
			{
				this.LabHand = (TextBlock)target;
				return;
			}
			if (connectionId == 6)
			{
				this.ItemClient = (MyListItem)target;
				return;
			}
			if (connectionId == 7)
			{
				this.ItemOptiFine = (MyListItem)target;
				return;
			}
			if (connectionId == 8)
			{
				this.ItemForge = (MyListItem)target;
				return;
			}
			if (connectionId == 9)
			{
				this.ItemFabric = (MyListItem)target;
				return;
			}
			if (connectionId == 10)
			{
				this.ItemLiteLoader = (MyListItem)target;
				return;
			}
			if (connectionId == 11)
			{
				this.ItemMod = (MyListItem)target;
				return;
			}
			if (connectionId == 12)
			{
				this.ItemPack = (MyListItem)target;
				return;
			}
			this.m_PropertyPrototype = true;
		}

		// Token: 0x040006BA RID: 1722
		public FormMain.PageSubType paramsPrototype;

		// Token: 0x040006BB RID: 1723
		[CompilerGenerated]
		[AccessedThroughProperty("PanItem")]
		private StackPanel m_MockPrototype;

		// Token: 0x040006BC RID: 1724
		[AccessedThroughProperty("LabGame")]
		[CompilerGenerated]
		private TextBlock m_AdapterPrototype;

		// Token: 0x040006BD RID: 1725
		[AccessedThroughProperty("ItemInstall")]
		[CompilerGenerated]
		private MyListItem initializerPrototype;

		// Token: 0x040006BE RID: 1726
		[AccessedThroughProperty("ItemHand")]
		[CompilerGenerated]
		private MyListItem m_SystemPrototype;

		// Token: 0x040006BF RID: 1727
		[AccessedThroughProperty("LabHand")]
		[CompilerGenerated]
		private TextBlock m_WriterPrototype;

		// Token: 0x040006C0 RID: 1728
		[AccessedThroughProperty("ItemClient")]
		[CompilerGenerated]
		private MyListItem _BroadcasterPrototype;

		// Token: 0x040006C1 RID: 1729
		[CompilerGenerated]
		[AccessedThroughProperty("ItemOptiFine")]
		private MyListItem _AttributePrototype;

		// Token: 0x040006C2 RID: 1730
		[AccessedThroughProperty("ItemForge")]
		[CompilerGenerated]
		private MyListItem _SpecificationPrototype;

		// Token: 0x040006C3 RID: 1731
		[AccessedThroughProperty("ItemFabric")]
		[CompilerGenerated]
		private MyListItem predicatePrototype;

		// Token: 0x040006C4 RID: 1732
		[AccessedThroughProperty("ItemLiteLoader")]
		[CompilerGenerated]
		private MyListItem m_ClientPrototype;

		// Token: 0x040006C5 RID: 1733
		[AccessedThroughProperty("ItemMod")]
		[CompilerGenerated]
		private MyListItem _InfoPrototype;

		// Token: 0x040006C6 RID: 1734
		[AccessedThroughProperty("ItemPack")]
		[CompilerGenerated]
		private MyListItem m_DecoratorPrototype;

		// Token: 0x040006C7 RID: 1735
		private bool m_PropertyPrototype;
	}
}
