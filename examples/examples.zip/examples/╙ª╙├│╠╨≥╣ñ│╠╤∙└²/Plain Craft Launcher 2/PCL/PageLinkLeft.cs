﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using NetFwTypeLib;
using STUN;

namespace PCL
{
	// Token: 0x020000B7 RID: 183
	[DesignerGenerated]
	public class PageLinkLeft : MyPageLeft, IComponentConnector
	{
		// Token: 0x060006C0 RID: 1728 RVA: 0x00030770 File Offset: 0x0002E970
		public PageLinkLeft()
		{
			base.Loaded += this.PageLinkLeft_Loaded;
			base.Unloaded += this.PageOtherLeft_Unloaded;
			this._InitializerResolver = false;
			this.m_SystemResolver = false;
			this._WriterResolver = new ModLoader.LoaderTask<int, string>("网络检测", checked(delegate(ModLoader.LoaderTask<int, string> Loader)
			{
				PageLinkLeft._Closure$__1-0 CS$<>8__locals1 = new PageLinkLeft._Closure$__1-0(CS$<>8__locals1);
				CS$<>8__locals1.$VB$Me = this;
				CS$<>8__locals1.$VB$Local_NatDesc = null;
				try
				{
					ModBase.Log("[Link] Windows 防火墙：检测开始", ModBase.LogLevel.Normal, "出现错误");
					if (PageLinkLeft.FirewallIsBlock())
					{
						if (PageLinkLeft.broadcasterResolver.CurrentProfile.ExceptionsNotAllowed)
						{
							ModMain.MyMsgBox(string.Concat(new string[]
							{
								"由于 Windows 防火墙阻止了所有传入连接，PCL2 无法获取防火墙通行权限。\r\n因此，PCL2 将无法检测你的网络状态，且联机会有更大概率失败。\r\n\r\n请尝试关闭 Windows 防火墙中的 ",
								Conversions.ToString(ModBase.m_PredicateState),
								"阻止所有传入连接",
								Conversions.ToString(ModBase._ClientState),
								" 选项。"
							}), "无法通过防火墙", "确定", "", "", false, true, false);
						}
						else
						{
							if (ModBase.IsAdmin())
							{
								ModBase.Log("[Link] Windows 防火墙：尝试添加防火墙通行权限", ModBase.LogLevel.Normal, "出现错误");
								try
								{
									PageLinkLeft.FirewallAddAuthorized("Plain Craft Launcher 启动器", ModBase.m_CodeState);
									PageLinkLeft.FirewallAddAuthorized("Plain Craft Launcher 启动器（联机模块）", ModBase.attributeState + "联机模块.exe");
									ModMain.Hint("防火墙通行权限添加成功！", ModMain.HintType.Finish, true);
									goto IL_1FB;
								}
								catch (Exception ex)
								{
									ModBase.Log(ex, "Windows 防火墙已开启，但无法添加至白名单", ModBase.LogLevel.Hint, "出现错误");
									goto IL_1A4;
								}
							}
							if (ModMain.MyMsgBox("由于你开启了 Windows 防火墙，PCL2 需要获取防火墙通行权限。\r\n\r\n若继续，PCL2 将尝试以管理员权限重新启动。\r\n若拒绝，PCL2 将无法检测你的网络状态，且联机会有更大概率失败。", "需要管理员权限", "继续", "拒绝", "", false, true, false) == 1)
							{
								ModBase.Log("[Link] Windows 防火墙：尝试提升权限", ModBase.LogLevel.Normal, "出现错误");
								if (ModBase.RerunAsAdmin("--link"))
								{
									ModMain.m_CollectionAccount.EndProgram(false);
								}
								else
								{
									ModMain.Hint(string.Concat(new string[]
									{
										"获取管理员权限失败，请尝试右键 PCL2，选择 ",
										Conversions.ToString(ModBase.m_PredicateState),
										"以管理员身份运行",
										Conversions.ToString(ModBase._ClientState),
										"，然后再进入联机页面！"
									}), ModMain.HintType.Critical, true);
								}
							}
						}
						IL_1A4:
						ModBase.Log("[Link] Windows 防火墙：无防火墙通行权限", ModBase.LogLevel.Normal, "出现错误");
						CS$<>8__locals1.$VB$Local_NatScore = 999;
					}
				}
				catch (Exception ex2)
				{
					ModBase.Log(ex2, "防火墙检测失败", ModBase.LogLevel.Debug, "出现错误");
					CS$<>8__locals1.$VB$Local_NatScore = 999;
				}
				if (Loader.IsAborted)
				{
					throw new ThreadInterruptedException();
				}
				IL_1FB:
				CS$<>8__locals1.$VB$Local_PingDesc = null;
				try
				{
					ModBase.Log("[Link] 网络检测：Ping 服务器 DNS 解析开始", ModBase.LogLevel.Normal, "出现错误");
					IPAddress ipaddress = null;
					IPAddress[] addressList = Dns.GetHostEntry("www.baidu.com").AddressList;
					int i = 0;
					while (i < addressList.Length)
					{
						IPAddress ipaddress2 = addressList[i];
						if (ipaddress2.ToString().Contains(":"))
						{
							i++;
						}
						else
						{
							ipaddress = ipaddress2;
							IL_25A:
							if (ipaddress == null)
							{
								throw new Exception("DNS 解析结果中无可用的 IPv4 地址");
							}
							ModBase.Log("[Link] 网络检测：Ping 检测开始（" + ipaddress.ToString() + "）", ModBase.LogLevel.Normal, "出现错误");
							PingReply pingReply = new Ping().Send(ipaddress);
							if (pingReply.Status == IPStatus.Success)
							{
								ModBase.Log("[Link] 网络检测：Ping 检测成功（" + Conversions.ToString(pingReply.RoundtripTime) + "ms）", ModBase.LogLevel.Normal, "出现错误");
								if (pingReply.RoundtripTime < 50L)
								{
									CS$<>8__locals1.$VB$Local_PingDesc = "网络延迟很低";
									CS$<>8__locals1.$VB$Local_PingScore = 4;
								}
								else if (pingReply.RoundtripTime < 100L)
								{
									CS$<>8__locals1.$VB$Local_PingDesc = "网络延迟较低";
									CS$<>8__locals1.$VB$Local_PingScore = 3;
								}
								else if (pingReply.RoundtripTime < 200L)
								{
									CS$<>8__locals1.$VB$Local_PingDesc = "网络延迟一般";
									CS$<>8__locals1.$VB$Local_PingScore = 3;
								}
								else if (pingReply.RoundtripTime < 400L)
								{
									CS$<>8__locals1.$VB$Local_PingDesc = "网络延迟较高";
									CS$<>8__locals1.$VB$Local_PingScore = 2;
								}
								else if (pingReply.RoundtripTime < 2000L)
								{
									CS$<>8__locals1.$VB$Local_PingDesc = "网络延迟很高";
									CS$<>8__locals1.$VB$Local_PingScore = 1;
								}
								else
								{
									CS$<>8__locals1.$VB$Local_PingDesc = "网络延迟极高";
									CS$<>8__locals1.$VB$Local_PingScore = 0;
								}
							}
							else
							{
								ModBase.Log("[Link] 网络检测：Ping 检测失败（" + ModBase.GetStringFromEnum(pingReply.Status) + "）", ModBase.LogLevel.Normal, "出现错误");
								CS$<>8__locals1.$VB$Local_PingDesc = "网络延迟检测失败（" + ModBase.GetStringFromEnum(pingReply.Status) + "）";
								CS$<>8__locals1.$VB$Local_PingScore = -10;
							}
							goto IL_458;
						}
					}
					goto IL_25A;
				}
				catch (Exception ex3)
				{
					ModBase.Log(ex3, "Ping 检测失败", ModBase.LogLevel.Debug, "出现错误");
					CS$<>8__locals1.$VB$Local_PingDesc = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("网络延迟检测失败（", ModBase.StrTrim(ex3.Message, true)), "）"));
					CS$<>8__locals1.$VB$Local_PingScore = -10;
				}
				IL_458:
				if (Loader.IsAborted)
				{
					throw new ThreadInterruptedException();
				}
				string text = "stun.qq.com";
				bool flag = false;
				try
				{
					if (CS$<>8__locals1.$VB$Local_NatScore != 999)
					{
						STUNQueryResult stunqueryResult;
						for (;;)
						{
							IL_52F:
							ModBase.Log("[Link] 网络检测：NAT 服务器 DNS 解析开始（" + text + "）", ModBase.LogLevel.Normal, "出现错误");
							IPAddress ipaddress3 = null;
							IPAddress[] addressList2 = Dns.GetHostEntry(text).AddressList;
							int j = 0;
							while (j < addressList2.Length)
							{
								IPAddress ipaddress4 = addressList2[j];
								if (ipaddress4.ToString().Contains(":"))
								{
									j++;
								}
								else
								{
									ipaddress3 = ipaddress4;
									IL_4B2:
									if (ipaddress3 == null)
									{
										goto IL_6B3;
									}
									ModBase.Log("[Link] 网络检测：NAT 检测开始（" + ipaddress3.ToString() + "）", ModBase.LogLevel.Normal, "出现错误");
									STUNClient.ReceiveTimeout = 40000;
									stunqueryResult = STUNClient.Query(new IPEndPoint(ipaddress3, 3478), 2, true);
									STUNQueryError queryError = stunqueryResult.QueryError;
									if (queryError == null)
									{
										goto IL_5E8;
									}
									if (queryError != 4)
									{
										goto Block_34;
									}
									if (!flag)
									{
										ModBase.Log("[Link] 网络检测：NAT 检测失败，连接服务器超时，正在重试", ModBase.LogLevel.Normal, "出现错误");
										flag = true;
										text = "stun.ekiga.net";
										goto IL_52F;
									}
									goto IL_5C0;
								}
							}
							goto IL_4B2;
						}
						Block_34:
						ModBase.Log("[Link] 网络检测：NAT 检测失败（" + ModBase.GetStringFromEnum(stunqueryResult.QueryError) + "）", ModBase.LogLevel.Normal, "出现错误");
						CS$<>8__locals1.$VB$Local_NatDesc = "网络环境检测失败（" + ModBase.GetStringFromEnum(stunqueryResult.QueryError) + "）";
						CS$<>8__locals1.$VB$Local_NatScore = -10;
						goto IL_6BE;
						IL_5C0:
						ModBase.Log("[Link] 网络检测：NAT 检测失败，连接服务器超时", ModBase.LogLevel.Normal, "出现错误");
						CS$<>8__locals1.$VB$Local_NatDesc = "网络环境检测失败（连接服务器超时）";
						CS$<>8__locals1.$VB$Local_NatScore = -10;
						goto IL_6BE;
						IL_5E8:
						ModBase.Log("[Link] 网络检测：NAT 检测成功（" + ModBase.GetStringFromEnum(stunqueryResult.NATType) + "）", ModBase.LogLevel.Normal, "出现错误");
						switch (stunqueryResult.NATType)
						{
						case 1:
							CS$<>8__locals1.$VB$Local_NatDesc = "网络环境很好，拥有公网 IP";
							CS$<>8__locals1.$VB$Local_NatScore = 10;
							goto IL_6BE;
						case 2:
							CS$<>8__locals1.$VB$Local_NatDesc = "网络环境良好，NAT 为 A 型（完全）";
							CS$<>8__locals1.$VB$Local_NatScore = 9;
							goto IL_6BE;
						case 3:
							CS$<>8__locals1.$VB$Local_NatDesc = "网络环境一般，NAT 为 B 型（受限）";
							CS$<>8__locals1.$VB$Local_NatScore = 7;
							goto IL_6BE;
						case 4:
							CS$<>8__locals1.$VB$Local_NatDesc = "网络环境较差，NAT 为 C 型（端口受限）";
							CS$<>8__locals1.$VB$Local_NatScore = 4;
							goto IL_6BE;
						case 5:
							CS$<>8__locals1.$VB$Local_NatDesc = "网络环境很差，NAT 为 D 型（对称）";
							CS$<>8__locals1.$VB$Local_NatScore = 1;
							goto IL_6BE;
						default:
							CS$<>8__locals1.$VB$Local_NatDesc = "网络环境极差，NAT 为 D 型（对称）";
							CS$<>8__locals1.$VB$Local_NatScore = 0;
							goto IL_6BE;
						}
						IL_6B3:
						throw new Exception("DNS 解析结果中无可用的 IPv4 地址");
						IL_6BE:;
					}
				}
				catch (Exception ex4)
				{
					ModBase.Log(ex4, "NAT 检测失败", ModBase.LogLevel.Debug, "出现错误");
					CS$<>8__locals1.$VB$Local_NatDesc = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("网络环境检测失败（", ModBase.StrTrim(ex4.Message, true)), "）"));
					CS$<>8__locals1.$VB$Local_NatScore = -10;
				}
				if (Loader.IsAborted)
				{
					throw new ThreadInterruptedException();
				}
				ModBase.RunInUi(delegate()
				{
					NewLateBinding.LateSetComplex(CS$<>8__locals1.$VB$Me.ItemNet.Buttons.Cast<object>().ElementAtOrDefault(0), null, "Visibility", new object[]
					{
						Visibility.Visible
					}, null, null, false, true);
					int num = CS$<>8__locals1.$VB$Local_NatScore + CS$<>8__locals1.$VB$Local_PingScore;
					if (num >= 100)
					{
						CS$<>8__locals1.$VB$Me.ItemNet.Title = "权限不足";
						CS$<>8__locals1.$VB$Me.ItemNet.ToolTip = string.Concat(new string[]
						{
							"PCL2 被 Windows 防火墙拦截，无法检测网络状态，且可能导致联机失败。\r\n请尝试右键 PCL2，选择 ",
							Conversions.ToString(ModBase.m_PredicateState),
							"以管理员身份运行",
							Conversions.ToString(ModBase._ClientState),
							"，然后再进入联机页面。"
						});
					}
					else if (num >= 13)
					{
						CS$<>8__locals1.$VB$Me.ItemNet.Title = "网络优秀";
						CS$<>8__locals1.$VB$Me.ItemNet.ToolTip = "你的网络状态优秀，可以正常联机。";
					}
					else if (num >= 11)
					{
						CS$<>8__locals1.$VB$Me.ItemNet.Title = "网络良好";
						CS$<>8__locals1.$VB$Me.ItemNet.ToolTip = "你的网络状态良好，可以正常联机。";
					}
					else if (num >= 9)
					{
						CS$<>8__locals1.$VB$Me.ItemNet.Title = "网络一般";
						CS$<>8__locals1.$VB$Me.ItemNet.ToolTip = "你的网络状态一般，联机大概率会成功。";
					}
					else if (num >= 6)
					{
						CS$<>8__locals1.$VB$Me.ItemNet.Title = "网络较差";
						CS$<>8__locals1.$VB$Me.ItemNet.ToolTip = "你的网络状态较差，联机有可能失败。";
					}
					else if (num >= 3)
					{
						CS$<>8__locals1.$VB$Me.ItemNet.Title = "网络很差";
						CS$<>8__locals1.$VB$Me.ItemNet.ToolTip = "你的网络状态很差，联机有较大可能失败。";
					}
					else if (num >= -19)
					{
						CS$<>8__locals1.$VB$Me.ItemNet.Title = "检测失败";
						CS$<>8__locals1.$VB$Me.ItemNet.ToolTip = "网络状态测试失败，网络可能存在问题，你也可以尝试重新检测。";
					}
					else
					{
						CS$<>8__locals1.$VB$Me.ItemNet.Title = "无网络连接";
						CS$<>8__locals1.$VB$Me.ItemNet.ToolTip = "你可能没有连接到国内网络，无法与他人联机。";
					}
					if (CS$<>8__locals1.$VB$Local_NatScore + CS$<>8__locals1.$VB$Local_PingScore < 100)
					{
						MyListItem itemNet;
						(itemNet = CS$<>8__locals1.$VB$Me.ItemNet).ToolTip = Operators.AddObject(itemNet.ToolTip, string.Concat(new string[]
						{
							"\r\n详情：",
							CS$<>8__locals1.$VB$Local_PingDesc,
							"，",
							CS$<>8__locals1.$VB$Local_NatDesc,
							"。"
						}));
					}
				}, false);
			}), null, ThreadPriority.Normal);
			this.specificationResolver = FormMain.PageSubType.SetupLink;
			this.InitializeComponent();
		}

		// Token: 0x060006C1 RID: 1729 RVA: 0x00005931 File Offset: 0x00003B31
		private void PageLinkLeft_Loaded(object sender, RoutedEventArgs e)
		{
			if (!this._InitializerResolver)
			{
				this._InitializerResolver = true;
				this._WriterResolver.Start(0, false);
				if (!this.m_SystemResolver)
				{
					this.ItemIoi.SetChecked(true, false, false);
				}
			}
		}

		// Token: 0x060006C2 RID: 1730 RVA: 0x0000596A File Offset: 0x00003B6A
		private void PageOtherLeft_Unloaded(object sender, RoutedEventArgs e)
		{
			this.m_SystemResolver = false;
		}

		// Token: 0x060006C3 RID: 1731 RVA: 0x000307E4 File Offset: 0x0002E9E4
		public void BtnNetRescan_Click(object sender, EventArgs e)
		{
			this._WriterResolver.Start(null, true);
			this.ItemNet.Title = "网络检测中";
			this.ItemNet.ToolTip = "PCL2 正在进行网络检测，请稍候。\r\n通常来说，网络状态越差，检测用时越长。";
			NewLateBinding.LateSetComplex(this.ItemNet.Buttons.Cast<object>().ElementAtOrDefault(0), null, "Visibility", new object[]
			{
				Visibility.Collapsed
			}, null, null, false, true);
		}

		// Token: 0x060006C4 RID: 1732 RVA: 0x00030854 File Offset: 0x0002EA54
		private static bool FirewallIsBlock()
		{
			if (PageLinkLeft.broadcasterResolver == null)
			{
				try
				{
					PageLinkLeft.broadcasterResolver = PageLinkLeft.FirewallPolicyGet();
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "Windows 防火墙：可能关闭得太死了，根本检测不到，笑死", ModBase.LogLevel.Normal, "出现错误");
					return false;
				}
			}
			bool result;
			if (!PageLinkLeft.broadcasterResolver.CurrentProfile.FirewallEnabled)
			{
				ModBase.Log("[Link] Windows 防火墙：关闭", ModBase.LogLevel.Normal, "出现错误");
				result = false;
			}
			else if (PageLinkLeft.broadcasterResolver.CurrentProfile.ExceptionsNotAllowed)
			{
				ModBase.Log("[Link] Windows 防火墙：开启，不允许例外", ModBase.LogLevel.Normal, "出现错误");
				result = true;
			}
			else
			{
				bool flag = false;
				bool flag2 = false;
				try
				{
					foreach (object obj in PageLinkLeft.broadcasterResolver.CurrentProfile.AuthorizedApplications)
					{
						INetFwAuthorizedApplication netFwAuthorizedApplication = (INetFwAuthorizedApplication)obj;
						if (netFwAuthorizedApplication.Enabled)
						{
							if (Operators.CompareString(netFwAuthorizedApplication.ProcessImageFileName, ModBase.attributeState + "联机模块.exe", true) == 0)
							{
								flag = true;
							}
							if (Operators.CompareString(netFwAuthorizedApplication.ProcessImageFileName, ModBase.m_CodeState, true) == 0)
							{
								flag2 = true;
							}
						}
					}
				}
				finally
				{
					IEnumerator enumerator;
					if (enumerator is IDisposable)
					{
						(enumerator as IDisposable).Dispose();
					}
				}
				if (flag && flag2)
				{
					ModBase.Log("[Link] Windows 防火墙：开启，已在白名单中", ModBase.LogLevel.Normal, "出现错误");
					result = false;
				}
				else
				{
					ModBase.Log("[Link] Windows 防火墙：开启，未在白名单中", ModBase.LogLevel.Normal, "出现错误");
					result = true;
				}
			}
			return result;
		}

		// Token: 0x060006C5 RID: 1733 RVA: 0x000309BC File Offset: 0x0002EBBC
		private static void FirewallAddAuthorized(string DisplayName, string FilePath)
		{
			if (PageLinkLeft.broadcasterResolver == null)
			{
				PageLinkLeft.broadcasterResolver = PageLinkLeft.FirewallPolicyGet();
			}
			PageLinkLeft.broadcasterResolver.GetProfileByType(NET_FW_PROFILE_TYPE_.NET_FW_PROFILE_DOMAIN).AuthorizedApplications.Add(new PageLinkLeft.FirewallApp(DisplayName, FilePath));
			PageLinkLeft.broadcasterResolver.GetProfileByType(NET_FW_PROFILE_TYPE_.NET_FW_PROFILE_STANDARD).AuthorizedApplications.Add(new PageLinkLeft.FirewallApp(DisplayName, FilePath));
			PageLinkLeft.broadcasterResolver.CurrentProfile.AuthorizedApplications.Add(new PageLinkLeft.FirewallApp(DisplayName, FilePath));
			ModBase.Log("[Link] Windows 防火墙：已添加通行权限（" + FilePath + "）", ModBase.LogLevel.Normal, "出现错误");
		}

		// Token: 0x060006C6 RID: 1734 RVA: 0x00005973 File Offset: 0x00003B73
		private static INetFwPolicy FirewallPolicyGet()
		{
			return (Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("{304CE942-6E39-40D8-943A-B913C40C9CD4}"))) as INetFwMgr).LocalPolicy;
		}

		// Token: 0x060006C7 RID: 1735 RVA: 0x00030A48 File Offset: 0x0002EC48
		public static string GetPlayerName()
		{
			if (PageLinkLeft.m_AttributeResolver == null)
			{
				if (PageLinkLeft.IsPlayerNameValid(ModLaunch.McLoginName()))
				{
					PageLinkLeft.m_AttributeResolver = ModLaunch.McLoginName();
				}
				else
				{
					PageLinkLeft.m_AttributeResolver = "玩家 " + Convert.ToInt32(decimal.Remainder(new decimal(ModBase.GetHash(ModBase.initializerState ?? "")), 1048576m)).ToString("x5").ToUpper();
				}
			}
			string text = ModBase._ParamsState.Get("LinkName", null).ToString().Trim();
			if (Operators.CompareString(text, "", true) != 0)
			{
				if (PageLinkLeft.IsPlayerNameValid(text))
				{
					return text.Trim();
				}
				ModMain.Hint("你所设置的玩家名存在异常，已被重置！", ModMain.HintType.Critical, true);
				ModBase._ParamsState.Set("LinkName", "", false, null);
			}
			return PageLinkLeft.m_AttributeResolver;
		}

		// Token: 0x060006C8 RID: 1736 RVA: 0x00030B28 File Offset: 0x0002ED28
		private static bool IsPlayerNameValid(string Name)
		{
			object[] array = new object[]
			{
				new ValidateNullOrWhiteSpace(),
				new ValidateLength(0, 20),
				new ValidateFilter()
			};
			checked
			{
				for (int i = 0; i < array.Length; i++)
				{
					if (!string.IsNullOrEmpty(((Validate)array[i]).Validate(Name)))
					{
						return false;
					}
				}
				return true;
			}
		}

		// Token: 0x060006C9 RID: 1737 RVA: 0x00005993 File Offset: 0x00003B93
		private void PageCheck(MyListItem sender, ModBase.RouteEventArgs e)
		{
			if (sender.Tag != null)
			{
				this.PageChange(checked((FormMain.PageSubType)Math.Round(ModBase.Val(RuntimeHelpers.GetObjectValue(sender.Tag)))));
			}
		}

		// Token: 0x060006CA RID: 1738 RVA: 0x00030B84 File Offset: 0x0002ED84
		public object PageGet(FormMain.PageSubType ID = (FormMain.PageSubType)(-1))
		{
			if (ID == (FormMain.PageSubType)(-1))
			{
				ID = this.specificationResolver;
			}
			switch (ID)
			{
			case FormMain.PageSubType.Default:
			case FormMain.PageSubType.SetupLink:
				if (ModMain._ParserAccount == null)
				{
					ModMain._ParserAccount = new PageLinkIoi();
				}
				return ModMain._ParserAccount;
			case FormMain.PageSubType.DownloadOptiFine:
				if (ModMain.m_GlobalAccount == null)
				{
					ModMain.m_GlobalAccount = new PageSetupLink();
				}
				return ModMain.m_GlobalAccount;
			case FormMain.PageSubType.DownloadForge:
				if (ModMain.m_StubAccount == null)
				{
					ModMain.m_StubAccount = PageOtherHelp.GetHelpPage(ModBase.attributeState + "Help\\启动器\\联机.json");
				}
				return ModMain.m_StubAccount;
			case FormMain.PageSubType.DownloadFabric:
				if (ModMain._ErrorAccount == null)
				{
					ModMain._ErrorAccount = new PageLinkFeedback();
				}
				return ModMain._ErrorAccount;
			}
			throw new Exception("未知的更多子页面种类：" + Conversions.ToString((int)ID));
		}

		// Token: 0x060006CB RID: 1739 RVA: 0x00030C50 File Offset: 0x0002EE50
		public void PageChange(FormMain.PageSubType ID)
		{
			checked
			{
				if (this.specificationResolver != ID)
				{
					ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
					this.m_SystemResolver = true;
					try
					{
						PageLinkLeft.PageChangeRun((MyPageRight)this.PageGet(ID));
						this.specificationResolver = ID;
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "切换设置分页面失败（ID " + Conversions.ToString((int)ID) + "）", ModBase.LogLevel.Feedback, "出现错误");
					}
					finally
					{
						ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
					}
				}
			}
		}

		// Token: 0x060006CC RID: 1740 RVA: 0x00030CEC File Offset: 0x0002EEEC
		private static void PageChangeRun(MyPageRight Target)
		{
			if (Target.Parent != null)
			{
				Target.SetValue(ContentPresenter.ContentProperty, null);
			}
			ModMain.m_CollectionAccount.m_RequestAccount = Target;
			((MyPageRight)ModMain.m_CollectionAccount.PanMainRight.Child).PageOnExit();
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaCode((PageLinkLeft._Closure$__.$I20-0 == null) ? (PageLinkLeft._Closure$__.$I20-0 = delegate()
				{
					((MyPageRight)ModMain.m_CollectionAccount.PanMainRight.Child).PageOnForceExit();
					ModMain.m_CollectionAccount.PanMainRight.Child = ModMain.m_CollectionAccount.m_RequestAccount;
					ModMain.m_CollectionAccount.m_RequestAccount.Opacity = 0.0;
				}) : PageLinkLeft._Closure$__.$I20-0, 130, false),
				ModAnimation.AaCode((PageLinkLeft._Closure$__.$I20-1 == null) ? (PageLinkLeft._Closure$__.$I20-1 = delegate()
				{
					ModMain.m_CollectionAccount.m_RequestAccount.Opacity = 1.0;
					ModMain.m_CollectionAccount.m_RequestAccount.PageOnEnter();
				}) : PageLinkLeft._Closure$__.$I20-1, 30, true)
			}, "PageLeft PageChange", false);
		}

		// Token: 0x060006CD RID: 1741 RVA: 0x00030DAC File Offset: 0x0002EFAC
		public void Reset(object sender, EventArgs e)
		{
			if (ModMain.MyMsgBox("是否要初始化联机页的所有设置？该操作不可撤销。", "初始化确认", "确定", "取消", "", true, true, false) == 1)
			{
				if (Information.IsNothing(ModMain.m_GlobalAccount))
				{
					ModMain.m_GlobalAccount = new PageSetupLink();
				}
				ModMain.m_GlobalAccount.Reset();
			}
		}

		// Token: 0x060006CE RID: 1742 RVA: 0x000050F7 File Offset: 0x000032F7
		private void BtnCatoStop_Loaded(object sender, RoutedEventArgs e)
		{
		}

		// Token: 0x060006CF RID: 1743 RVA: 0x000050F7 File Offset: 0x000032F7
		private void BtnCatoStop_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060006D0 RID: 1744 RVA: 0x00030E00 File Offset: 0x0002F000
		private void BtnIoiStop_Loaded(object sender, RoutedEventArgs e)
		{
			NewLateBinding.LateSet(sender, null, "Visibility", new object[]
			{
				(PageLinkIoi.NewRepository().State == ModBase.LoadState.Finished) ? Visibility.Visible : Visibility.Collapsed
			}, null, null);
		}

		// Token: 0x060006D1 RID: 1745 RVA: 0x000059B9 File Offset: 0x00003BB9
		private void BtnIoiStop_Click(object sender, EventArgs e)
		{
			PageLinkIoi.ModuleStopManually();
		}

		// Token: 0x170000EE RID: 238
		// (get) Token: 0x060006D2 RID: 1746 RVA: 0x000059C0 File Offset: 0x00003BC0
		// (set) Token: 0x060006D3 RID: 1747 RVA: 0x000059C8 File Offset: 0x00003BC8
		internal virtual StackPanel PanItem { get; set; }

		// Token: 0x170000EF RID: 239
		// (get) Token: 0x060006D4 RID: 1748 RVA: 0x000059D1 File Offset: 0x00003BD1
		// (set) Token: 0x060006D5 RID: 1749 RVA: 0x000059D9 File Offset: 0x00003BD9
		internal virtual MyListItem ItemNet { get; set; }

		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x060006D6 RID: 1750 RVA: 0x000059E2 File Offset: 0x00003BE2
		// (set) Token: 0x060006D7 RID: 1751 RVA: 0x00030E3C File Offset: 0x0002F03C
		internal virtual MyListItem ItemCato
		{
			[CompilerGenerated]
			get
			{
				return this._InfoResolver;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem infoResolver = this._InfoResolver;
				if (infoResolver != null)
				{
					infoResolver.Check -= value2;
				}
				this._InfoResolver = value;
				infoResolver = this._InfoResolver;
				if (infoResolver != null)
				{
					infoResolver.Check += value2;
				}
			}
		}

		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x060006D8 RID: 1752 RVA: 0x000059EA File Offset: 0x00003BEA
		// (set) Token: 0x060006D9 RID: 1753 RVA: 0x00030E80 File Offset: 0x0002F080
		internal virtual MyListItem ItemIoi
		{
			[CompilerGenerated]
			get
			{
				return this._DecoratorResolver;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem decoratorResolver = this._DecoratorResolver;
				if (decoratorResolver != null)
				{
					decoratorResolver.Check -= value2;
				}
				this._DecoratorResolver = value;
				decoratorResolver = this._DecoratorResolver;
				if (decoratorResolver != null)
				{
					decoratorResolver.Check += value2;
				}
			}
		}

		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x060006DA RID: 1754 RVA: 0x000059F2 File Offset: 0x00003BF2
		// (set) Token: 0x060006DB RID: 1755 RVA: 0x00030EC4 File Offset: 0x0002F0C4
		internal virtual MyListItem ItemSetup
		{
			[CompilerGenerated]
			get
			{
				return this.propertyResolver;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem myListItem = this.propertyResolver;
				if (myListItem != null)
				{
					myListItem.Check -= value2;
				}
				this.propertyResolver = value;
				myListItem = this.propertyResolver;
				if (myListItem != null)
				{
					myListItem.Check += value2;
				}
			}
		}

		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x060006DC RID: 1756 RVA: 0x000059FA File Offset: 0x00003BFA
		// (set) Token: 0x060006DD RID: 1757 RVA: 0x00030F08 File Offset: 0x0002F108
		internal virtual MyListItem ItemHelp
		{
			[CompilerGenerated]
			get
			{
				return this.descriptorResolver;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem myListItem = this.descriptorResolver;
				if (myListItem != null)
				{
					myListItem.Check -= value2;
				}
				this.descriptorResolver = value;
				myListItem = this.descriptorResolver;
				if (myListItem != null)
				{
					myListItem.Check += value2;
				}
			}
		}

		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x060006DE RID: 1758 RVA: 0x00005A02 File Offset: 0x00003C02
		// (set) Token: 0x060006DF RID: 1759 RVA: 0x00030F4C File Offset: 0x0002F14C
		internal virtual MyListItem ItemFeedback
		{
			[CompilerGenerated]
			get
			{
				return this.m_MapResolver;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.PageCheck((MyListItem)sender, e);
				};
				MyListItem mapResolver = this.m_MapResolver;
				if (mapResolver != null)
				{
					mapResolver.Check -= value2;
				}
				this.m_MapResolver = value;
				mapResolver = this.m_MapResolver;
				if (mapResolver != null)
				{
					mapResolver.Check += value2;
				}
			}
		}

		// Token: 0x060006E0 RID: 1760 RVA: 0x00030F90 File Offset: 0x0002F190
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this._EventResolver)
			{
				this._EventResolver = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagelink/pagelinkleft.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x060006E1 RID: 1761 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060006E2 RID: 1762 RVA: 0x00030FC0 File Offset: 0x0002F1C0
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanItem = (StackPanel)target;
				return;
			}
			if (connectionId == 2)
			{
				this.ItemNet = (MyListItem)target;
				return;
			}
			if (connectionId == 3)
			{
				this.ItemCato = (MyListItem)target;
				return;
			}
			if (connectionId == 4)
			{
				this.ItemIoi = (MyListItem)target;
				return;
			}
			if (connectionId == 5)
			{
				this.ItemSetup = (MyListItem)target;
				return;
			}
			if (connectionId == 6)
			{
				this.ItemHelp = (MyListItem)target;
				return;
			}
			if (connectionId == 7)
			{
				this.ItemFeedback = (MyListItem)target;
				return;
			}
			this._EventResolver = true;
		}

		// Token: 0x04000314 RID: 788
		private bool _InitializerResolver;

		// Token: 0x04000315 RID: 789
		private bool m_SystemResolver;

		// Token: 0x04000316 RID: 790
		public ModLoader.LoaderTask<int, string> _WriterResolver;

		// Token: 0x04000317 RID: 791
		private static INetFwPolicy broadcasterResolver = null;

		// Token: 0x04000318 RID: 792
		private static string m_AttributeResolver = null;

		// Token: 0x04000319 RID: 793
		public FormMain.PageSubType specificationResolver;

		// Token: 0x0400031A RID: 794
		[CompilerGenerated]
		[AccessedThroughProperty("PanItem")]
		private StackPanel predicateResolver;

		// Token: 0x0400031B RID: 795
		[AccessedThroughProperty("ItemNet")]
		[CompilerGenerated]
		private MyListItem m_ClientResolver;

		// Token: 0x0400031C RID: 796
		[AccessedThroughProperty("ItemCato")]
		[CompilerGenerated]
		private MyListItem _InfoResolver;

		// Token: 0x0400031D RID: 797
		[CompilerGenerated]
		[AccessedThroughProperty("ItemIoi")]
		private MyListItem _DecoratorResolver;

		// Token: 0x0400031E RID: 798
		[CompilerGenerated]
		[AccessedThroughProperty("ItemSetup")]
		private MyListItem propertyResolver;

		// Token: 0x0400031F RID: 799
		[AccessedThroughProperty("ItemHelp")]
		[CompilerGenerated]
		private MyListItem descriptorResolver;

		// Token: 0x04000320 RID: 800
		[AccessedThroughProperty("ItemFeedback")]
		[CompilerGenerated]
		private MyListItem m_MapResolver;

		// Token: 0x04000321 RID: 801
		private bool _EventResolver;

		// Token: 0x020000B8 RID: 184
		private class FirewallApp : INetFwAuthorizedApplication
		{
			// Token: 0x170000F5 RID: 245
			// (get) Token: 0x060006E9 RID: 1769 RVA: 0x00005A19 File Offset: 0x00003C19
			// (set) Token: 0x060006EA RID: 1770 RVA: 0x00005A21 File Offset: 0x00003C21
			public string Name { get; set; }

			// Token: 0x170000F6 RID: 246
			// (get) Token: 0x060006EB RID: 1771 RVA: 0x00005A2A File Offset: 0x00003C2A
			// (set) Token: 0x060006EC RID: 1772 RVA: 0x00005A32 File Offset: 0x00003C32
			public string ProcessImageFileName { get; set; }

			// Token: 0x170000F7 RID: 247
			// (get) Token: 0x060006ED RID: 1773 RVA: 0x00005A3B File Offset: 0x00003C3B
			// (set) Token: 0x060006EE RID: 1774 RVA: 0x00005A43 File Offset: 0x00003C43
			public NET_FW_IP_VERSION_ IpVersion { get; set; }

			// Token: 0x170000F8 RID: 248
			// (get) Token: 0x060006EF RID: 1775 RVA: 0x00005A4C File Offset: 0x00003C4C
			// (set) Token: 0x060006F0 RID: 1776 RVA: 0x00005A54 File Offset: 0x00003C54
			public NET_FW_SCOPE_ Scope { get; set; }

			// Token: 0x170000F9 RID: 249
			// (get) Token: 0x060006F1 RID: 1777 RVA: 0x00005A5D File Offset: 0x00003C5D
			// (set) Token: 0x060006F2 RID: 1778 RVA: 0x00005A65 File Offset: 0x00003C65
			public string RemoteAddresses { get; set; }

			// Token: 0x170000FA RID: 250
			// (get) Token: 0x060006F3 RID: 1779 RVA: 0x00005A6E File Offset: 0x00003C6E
			// (set) Token: 0x060006F4 RID: 1780 RVA: 0x00005A76 File Offset: 0x00003C76
			public bool Enabled { get; set; }

			// Token: 0x060006F5 RID: 1781 RVA: 0x00005A7F File Offset: 0x00003C7F
			public FirewallApp(string DisplayName, string FilePath)
			{
				this.IpVersion = NET_FW_IP_VERSION_.NET_FW_IP_VERSION_ANY;
				this.Scope = NET_FW_SCOPE_.NET_FW_SCOPE_ALL;
				this.RemoteAddresses = "*";
				this.Enabled = true;
				this.Name = DisplayName;
				this.ProcessImageFileName = FilePath;
			}

			// Token: 0x04000322 RID: 802
			[CompilerGenerated]
			private string m_WorkerState;

			// Token: 0x04000323 RID: 803
			[CompilerGenerated]
			private string dicState;

			// Token: 0x04000324 RID: 804
			[CompilerGenerated]
			private NET_FW_IP_VERSION_ _ConfigurationState;

			// Token: 0x04000325 RID: 805
			[CompilerGenerated]
			private NET_FW_SCOPE_ m_ConfigState;

			// Token: 0x04000326 RID: 806
			[CompilerGenerated]
			private string managerState;

			// Token: 0x04000327 RID: 807
			[CompilerGenerated]
			private bool ruleState;
		}
	}
}
