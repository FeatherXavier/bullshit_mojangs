﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000162 RID: 354
	[DesignerGenerated]
	public class PageSpeedLeft : MyPageLeft, IComponentConnector
	{
		// Token: 0x0600105B RID: 4187 RVA: 0x00009B42 File Offset: 0x00007D42
		public PageSpeedLeft()
		{
			base.Loaded += this.Page_Loaded;
			this.configurationIssuer = false;
			this.m_ConfigIssuer = new Dictionary<string, MyCard>();
			this.InitializeComponent();
		}

		// Token: 0x0600105C RID: 4188 RVA: 0x00070688 File Offset: 0x0006E888
		private void Page_Loaded(object sender, RoutedEventArgs e)
		{
			this.Watcher();
			this.TryReturnToHome();
			if (!this.configurationIssuer)
			{
				this.configurationIssuer = true;
				DispatcherTimer dispatcherTimer = new DispatcherTimer();
				dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 300);
				dispatcherTimer.Tick += delegate(object sender, EventArgs e)
				{
					this.Watcher();
				};
				dispatcherTimer.Start();
				if (!ModBase._EventState)
				{
					base.RowDefinitions[12].Height = new GridLength(0.0);
					base.RowDefinitions[13].Height = new GridLength(0.0);
					base.RowDefinitions[14].Height = new GridLength(0.0);
					base.RowDefinitions[15].Height = new GridLength(0.0);
				}
			}
		}

		// Token: 0x0600105D RID: 4189 RVA: 0x00070770 File Offset: 0x0006E970
		private void Watcher()
		{
			if (ModMain.m_CollectionAccount.comparatorAccount == FormMain.PageType.DownloadManager)
			{
				try
				{
					if (ModLoader.LoaderTaskbar.Count == 0)
					{
						this.LabProgress.Text = "100 %";
						this.LabSpeed.Text = "0 B/s";
						this.LabFile.Text = "0";
						this.LabThread.Text = "0 / " + Conversions.ToString(ModNet.prototypeTag);
					}
					else
					{
						double loaderTaskbarProgress = ModLoader.LoaderTaskbarProgress;
						string text = Conversions.ToString(Math.Floor(loaderTaskbarProgress * 100.0)) + "." + ModBase.StrFill(Conversions.ToString(Math.Floor((loaderTaskbarProgress * 100.0 - Math.Floor(loaderTaskbarProgress * 100.0)) * 100.0)), "0", 2) + " %";
						this.LabProgress.Text = ((loaderTaskbarProgress > 0.999999) ? "100 %" : text);
						this.LabSpeed.Text = ModBase.GetString(ModNet.reponseTag._MapProccesor) + "/s";
						this.LabFile.Text = Conversions.ToString((ModNet.reponseTag._InfoProccesor < 0) ? "0*" : ModNet.reponseTag._InfoProccesor);
						this.LabThread.Text = Conversions.ToString(ModNet.m_ParameterTag) + " / " + Conversions.ToString(ModNet.prototypeTag);
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "下载管理左栏监视出错", ModBase.LogLevel.Feedback, "出现错误");
				}
				checked
				{
					if (ModMain.m_TokenAccount != null && ModMain.m_TokenAccount.PanMain != null)
					{
						try
						{
							object loaderTaskbarLock = ModLoader.LoaderTaskbarLock;
							ObjectFlowControl.CheckForSyncLockOnValueType(loaderTaskbarLock);
							lock (loaderTaskbarLock)
							{
								int num = ModLoader.LoaderTaskbar.Count - 1;
								for (int i = 0; i <= num; i++)
								{
									this.TaskRefresh(ModLoader.LoaderTaskbar[i]);
								}
							}
						}
						catch (Exception ex2)
						{
							ModBase.Log(ex2, "下载管理右栏监视出错", ModBase.LogLevel.Feedback, "出现错误");
						}
					}
				}
			}
		}

		// Token: 0x0600105E RID: 4190 RVA: 0x000709FC File Offset: 0x0006EBFC
		public void TaskRefresh(ModLoader.LoaderBase Loader)
		{
			PageSpeedLeft._Closure$__6-1 CS$<>8__locals1 = new PageSpeedLeft._Closure$__6-1(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Me = this;
			CS$<>8__locals1.$VB$Local_Loader = Loader;
			if (CS$<>8__locals1.$VB$Local_Loader != null && CS$<>8__locals1.$VB$Local_Loader.Show)
			{
				try
				{
					List<ModLoader.LoaderBase> list = (List<ModLoader.LoaderBase>)NewLateBinding.LateGet(CS$<>8__locals1.$VB$Local_Loader, null, "GetLoaderList", new object[0], null, null, null);
					if (this.m_ConfigIssuer.ContainsKey(CS$<>8__locals1.$VB$Local_Loader.Name))
					{
						Grid grid = this.m_ConfigIssuer[CS$<>8__locals1.$VB$Local_Loader.Name];
						double num = CS$<>8__locals1.$VB$Local_Loader.Progress + (double)CS$<>8__locals1.$VB$Local_Loader.State;
						if (ModBase.Val(RuntimeHelpers.GetObjectValue(grid.Tag)) == num)
						{
							return;
						}
						grid.Tag = num;
						if (grid.Children.Count <= 3)
						{
							ModBase.Log("[Watcher] 元素不足的卡片：" + CS$<>8__locals1.$VB$Local_Loader.Name, ModBase.LogLevel.Debug, "出现错误");
							return;
						}
						grid = (Grid)grid.Children[3];
						checked
						{
							try
							{
								switch (CS$<>8__locals1.$VB$Local_Loader.State)
								{
								case ModBase.LoadState.Waiting:
								case ModBase.LoadState.Loading:
									try
									{
										if (grid.Children.Count < list.Count * 2)
										{
											ModBase.Log("刷新下载管理卡片失败：卡片中仅有 " + Conversions.ToString(grid.Children.Count) + " 个子项", ModBase.LogLevel.Debug, "出现错误");
											goto IL_45E;
										}
										int num2 = 0;
										try
										{
											foreach (ModLoader.LoaderBase loaderBase in list)
											{
												switch (loaderBase.State)
												{
												case ModBase.LoadState.Waiting:
													if (Operators.ConditionalCompareObjectNotEqual(((FrameworkElement)grid.Children[num2 * 2]).Tag, "Waiting", true))
													{
														grid.Children.RemoveAt(num2 * 2);
														grid.Children.Insert(num2 * 2, (UIElement)ModBase.GetObjectFromXML("<Path xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\" xmlns:local=\"clr-namespace:PCL;assembly=Plain Craft Launcher 2\" Stretch=\"Uniform\" Tag=\"Waiting\" Data=\"F1 M5,0 a5,5 360 1 0 0,0.0001 m15,0 a5,5 360 1 0 0,0.0001 m15,0 a5,5 360 1 0 0,0.0001 Z\" Width=\"18\" HorizontalAlignment=\"Center\" Grid.Column=\"0\" Grid.Row=\"" + Conversions.ToString(num2) + "\" Fill=\"{DynamicResource ColorBrush3}\" Margin=\"0,7,0,0\" VerticalAlignment=\"Top\" Height=\"6\"/>"));
													}
													break;
												case ModBase.LoadState.Loading:
													if (Operators.ConditionalCompareObjectNotEqual(((FrameworkElement)grid.Children[num2 * 2]).Tag, "Loading", true))
													{
														grid.Children.RemoveAt(num2 * 2);
														grid.Children.Insert(num2 * 2, (UIElement)ModBase.GetObjectFromXML(string.Concat(new string[]
														{
															"<TextBlock xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\" xmlns:local=\"clr-namespace:PCL;assembly=Plain Craft Launcher 2\" Text=\"",
															Conversions.ToString(Math.Floor(unchecked(loaderBase.Progress * 100.0))),
															"%\" Tag=\"Loading\" HorizontalAlignment=\"Center\" Grid.Column=\"0\" Grid.Row=\"",
															Conversions.ToString(num2),
															"\" Foreground=\"{DynamicResource ColorBrush3}\"/>"
														})));
													}
													else
													{
														((TextBlock)grid.Children[num2 * 2]).Text = Conversions.ToString(Math.Floor(unchecked(loaderBase.Progress * 100.0))) + "%";
													}
													break;
												case ModBase.LoadState.Finished:
													if (Operators.ConditionalCompareObjectNotEqual(((FrameworkElement)grid.Children[num2 * 2]).Tag, "Finished", true))
													{
														grid.Children.RemoveAt(num2 * 2);
														grid.Children.Insert(num2 * 2, (UIElement)ModBase.GetObjectFromXML("<Path xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\" xmlns:local=\"clr-namespace:PCL;assembly=Plain Craft Launcher 2\" Stretch=\"Uniform\" Tag=\"Finished\" Data=\"F1 M 23.7501,33.25L 34.8334,44.3333L 52.2499,22.1668L 56.9999,26.9168L 34.8334,53.8333L 19.0001,38L 23.7501,33.25 Z\" Height=\"16\" Width=\"15\" HorizontalAlignment=\"Center\" Grid.Column=\"0\" Grid.Row=\"" + Conversions.ToString(num2) + "\" Fill=\"{DynamicResource ColorBrush3}\" Margin=\"0,3,0,0\" VerticalAlignment=\"Top\"/>"));
													}
													break;
												}
												num2++;
											}
										}
										finally
										{
											List<ModLoader.LoaderBase>.Enumerator enumerator;
											((IDisposable)enumerator).Dispose();
										}
										goto IL_45E;
									}
									catch (Exception ex)
									{
										ModBase.Log(ex, "刷新下载管理卡片失败", ModBase.LogLevel.Feedback, "出现错误");
										goto IL_45E;
									}
									break;
								case ModBase.LoadState.Finished:
									break;
								case ModBase.LoadState.Failed:
								{
									grid.RowDefinitions.Clear();
									grid.Children.Clear();
									grid.Children.Add((UIElement)ModBase.GetObjectFromXML("<Path xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" Stretch=\"Uniform\" Tag=\"Failed\" Data=\"F1 M2.5,0 L0,2.5 7.5,10 0,17.5 2.5,20 10,12.5 17.5,20 20,17.5 12.5,10 20,2.5 17.5,0 10,7.5 2.5,0Z\" Height=\"15\" Width=\"15\" HorizontalAlignment=\"Center\" Grid.Column=\"0\" Grid.Row=\"0\" Fill=\"{DynamicResource ColorBrush3}\" Margin=\"0,1,0,0\" VerticalAlignment=\"Top\"/>"));
									TextBlock textBlock = (TextBlock)ModBase.GetObjectFromXML("<TextBlock xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" TextWrapping=\"Wrap\" HorizontalAlignment=\"Left\" ToolTipService.ShowDuration=\"2333333\" ToolTip=\"单击复制错误详情\" Grid.Column=\"1\" Grid.Row=\"0\" Margin=\"0,0,0,5\" />");
									textBlock.Text = ModBase.GetString(CS$<>8__locals1.$VB$Local_Loader.Error, false, false);
									textBlock.MouseDown += ((PageSpeedLeft._Closure$__.$IR6-2 == null) ? (PageSpeedLeft._Closure$__.$IR6-2 = delegate(object sender, MouseButtonEventArgs e)
									{
										((PageSpeedLeft._Closure$__.$I6-0 == null) ? (PageSpeedLeft._Closure$__.$I6-0 = delegate(TextBlock sender, EventArgs e)
										{
											ModBase.ClipboardSet(sender.Text, false);
											ModMain.Hint("已复制错误详情！", ModMain.HintType.Finish, true);
										}) : PageSpeedLeft._Closure$__.$I6-0)((TextBlock)sender, e);
									}) : PageSpeedLeft._Closure$__.$IR6-2);
									grid.Children.Add(textBlock);
									goto IL_45E;
								}
								default:
									goto IL_45E;
								}
								ModAnimation.AniDispose((MyCard)grid.Parent, true, delegate(object a0)
								{
									this.TryReturnToHome();
								});
								IL_45E:
								goto IL_85D;
							}
							catch (Exception ex2)
							{
								ModBase.Log(ex2, "更新下载管理显示失败（" + CS$<>8__locals1.$VB$Local_Loader.State.ToString() + "）", ModBase.LogLevel.Feedback, "出现错误");
								goto IL_85D;
							}
						}
					}
					if (CS$<>8__locals1.$VB$Local_Loader.State != ModBase.LoadState.Aborted && CS$<>8__locals1.$VB$Local_Loader.State != ModBase.LoadState.Finished)
					{
						try
						{
							PageSpeedLeft._Closure$__6-0 CS$<>8__locals2 = new PageSpeedLeft._Closure$__6-0(CS$<>8__locals2);
							CS$<>8__locals2.$VB$NonLocal_$VB$Closure_2 = CS$<>8__locals1;
							string text = string.Concat(new string[]
							{
								"\r\n                        <local:MyCard xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\" xmlns:local=\"clr-namespace:PCL;assembly=Plain Craft Launcher 2\"\r\n                            Tag=\"",
								Conversions.ToString(CS$<>8__locals2.$VB$NonLocal_$VB$Closure_2.$VB$Local_Loader.Progress + (double)CS$<>8__locals2.$VB$NonLocal_$VB$Closure_2.$VB$Local_Loader.State),
								"\" Title=\"",
								ModBase.smethod_3(CS$<>8__locals2.$VB$NonLocal_$VB$Closure_2.$VB$Local_Loader.Name),
								"\" Margin=\"0,0,0,15\">\r\n                            <Grid Margin=\"14,40,15,10\">\r\n                                <Grid.ColumnDefinitions>\r\n                                    <ColumnDefinition Width=\"50\"/>\r\n                                    <ColumnDefinition/>\r\n                                </Grid.ColumnDefinitions>\r\n                                <Grid.RowDefinitions>"
							});
							try
							{
								foreach (ModLoader.LoaderBase loaderBase2 in list)
								{
									text += "<RowDefinition Height=\"26\"/>";
								}
							}
							finally
							{
								List<ModLoader.LoaderBase>.Enumerator enumerator2;
								((IDisposable)enumerator2).Dispose();
							}
							text += "</Grid.RowDefinitions>";
							int num3 = 0;
							try
							{
								foreach (ModLoader.LoaderBase loaderBase3 in list)
								{
									switch (loaderBase3.State)
									{
									case ModBase.LoadState.Waiting:
										text = text + "<Path Stretch=\"Uniform\" Tag=\"Waiting\" Data=\"F1 M5,0 a5,5 360 1 0 0,0.0001 m15,0 a5,5 360 1 0 0,0.0001 m15,0 a5,5 360 1 0 0,0.0001 Z\" Width=\"18\" HorizontalAlignment=\"Center\" Grid.Column=\"0\" Grid.Row=\"" + Conversions.ToString(num3) + "\" Fill=\"{DynamicResource ColorBrush3}\" Margin=\"0,7,0,0\" VerticalAlignment=\"Top\" Height=\"6\"/>";
										break;
									case ModBase.LoadState.Loading:
										text = string.Concat(new string[]
										{
											text,
											"<TextBlock Text=\"",
											Conversions.ToString(Math.Floor(loaderBase3.Progress * 100.0)),
											"%\" Tag=\"Loading\" HorizontalAlignment=\"Center\" Grid.Column=\"0\" Grid.Row=\"",
											Conversions.ToString(num3),
											"\" Foreground=\"{DynamicResource ColorBrush3}\" />"
										});
										break;
									case ModBase.LoadState.Finished:
										text = text + "<Path Stretch=\"Uniform\" Tag=\"Finished\" Data=\"F1 M 23.7501,33.25L 34.8334,44.3333L 52.2499,22.1668L 56.9999,26.9168L 34.8334,53.8333L 19.0001,38L 23.7501,33.25 Z\" Height=\"16\" Width=\"15\" HorizontalAlignment=\"Center\" Grid.Column=\"0\" Grid.Row=\"" + Conversions.ToString(num3) + "\" Fill=\"{DynamicResource ColorBrush3}\" Margin=\"0,3,0,0\" VerticalAlignment=\"Top\"/>";
										break;
									default:
										text = text + "<Path Stretch=\"Uniform\" Tag=\"Failed\" Data=\"F1 M2.5,0 L0,2.5 7.5,10 0,17.5 2.5,20 10,12.5 17.5,20 20,17.5 12.5,10 20,2.5 17.5,0 10,7.5 2.5,0Z\" Height=\"15\" Width=\"15\" HorizontalAlignment=\"Center\" Grid.Column=\"0\" Grid.Row=\"" + Conversions.ToString(num3) + "\" Fill=\"{DynamicResource ColorBrush3}\" Margin=\"0,1,0,0\" VerticalAlignment=\"Top\"/>";
										break;
									}
									text = string.Concat(new string[]
									{
										text,
										"<TextBlock Text=\"",
										ModBase.smethod_3(loaderBase3.Name),
										"\" HorizontalAlignment=\"Left\" Grid.Column=\"1\" Grid.Row=\"",
										Conversions.ToString(num3),
										"\"/>"
									});
									checked
									{
										num3++;
									}
								}
							}
							finally
							{
								List<ModLoader.LoaderBase>.Enumerator enumerator3;
								((IDisposable)enumerator3).Dispose();
							}
							text += "\r\n                            </Grid>\r\n                        </local:MyCard>";
							try
							{
								CS$<>8__locals2.$VB$Local_Card = (MyCard)ModBase.GetObjectFromXML(text);
							}
							catch (Exception ex3)
							{
								ModBase.Log(ex3, "新建下载管理卡片失败", ModBase.LogLevel.Debug, "出现错误");
								ModBase.Log("出错的卡片内容：\r\n" + text, ModBase.LogLevel.Normal, "出现错误");
								throw;
							}
							ModMain.m_TokenAccount.PanMain.Children.Insert(0, CS$<>8__locals2.$VB$Local_Card);
							this.m_ConfigIssuer.Add(CS$<>8__locals2.$VB$NonLocal_$VB$Closure_2.$VB$Local_Loader.Name, CS$<>8__locals2.$VB$Local_Card);
							MyIconButton myIconButton = new MyIconButton
							{
								Name = "BtnCancel",
								Logo = "F1 M2,0 L0,2 8,10 0,18 2,20 10,12 18,20 20,18 12,10 20,2 18,0 10,8 2,0Z",
								Height = 20.0,
								Margin = new Thickness(0.0, 10.0, 10.0, 0.0),
								LogoScale = 1.1,
								HorizontalAlignment = HorizontalAlignment.Right,
								VerticalAlignment = VerticalAlignment.Top
							};
							CS$<>8__locals2.$VB$Local_Card.Children.Add(myIconButton);
							myIconButton.Click += delegate(object sender, EventArgs e)
							{
								base._Lambda$__1((MyIconButton)sender, e);
							};
							if (CS$<>8__locals2.$VB$NonLocal_$VB$Closure_2.$VB$Local_Loader.State == ModBase.LoadState.Failed)
							{
								CS$<>8__locals2.$VB$Local_Card.Tag = null;
								this.TaskRefresh(CS$<>8__locals2.$VB$NonLocal_$VB$Closure_2.$VB$Local_Loader);
							}
						}
						catch (Exception ex4)
						{
							ModBase.Log(ex4, "添加下载管理卡片失败", ModBase.LogLevel.Feedback, "出现错误");
						}
					}
					IL_85D:;
				}
				catch (Exception ex5)
				{
					ModBase.Log(ex5, "刷新下载管理显示失败", ModBase.LogLevel.Feedback, "出现错误");
				}
			}
		}

		// Token: 0x0600105F RID: 4191 RVA: 0x00071350 File Offset: 0x0006F550
		public void TaskRemove(object Loader)
		{
			if (this.m_ConfigIssuer.ContainsKey(Conversions.ToString(NewLateBinding.LateGet(Loader, null, "Name", new object[0], null, null, null))))
			{
				ModBase.RunInUiWait(delegate
				{
					Grid element = this.m_ConfigIssuer[Conversions.ToString(NewLateBinding.LateGet(Loader, null, "Name", new object[0], null, null, null))];
					ModMain.m_TokenAccount.PanMain.Children.Remove(element);
					this.m_ConfigIssuer.Remove(Conversions.ToString(NewLateBinding.LateGet(Loader, null, "Name", new object[0], null, null, null)));
				});
			}
		}

		// Token: 0x06001060 RID: 4192 RVA: 0x00009B75 File Offset: 0x00007D75
		private void TryReturnToHome()
		{
			if (ModMain.m_TokenAccount.PanMain.Children.Count == 0 && ModMain.m_CollectionAccount.comparatorAccount == FormMain.PageType.DownloadManager)
			{
				ModMain.m_CollectionAccount.PageBack();
			}
		}

		// Token: 0x170002CC RID: 716
		// (get) Token: 0x06001061 RID: 4193 RVA: 0x00009BAE File Offset: 0x00007DAE
		// (set) Token: 0x06001062 RID: 4194 RVA: 0x00009BB6 File Offset: 0x00007DB6
		internal virtual TextBlock LabProgress { get; set; }

		// Token: 0x170002CD RID: 717
		// (get) Token: 0x06001063 RID: 4195 RVA: 0x00009BBF File Offset: 0x00007DBF
		// (set) Token: 0x06001064 RID: 4196 RVA: 0x00009BC7 File Offset: 0x00007DC7
		internal virtual TextBlock LabSpeed { get; set; }

		// Token: 0x170002CE RID: 718
		// (get) Token: 0x06001065 RID: 4197 RVA: 0x00009BD0 File Offset: 0x00007DD0
		// (set) Token: 0x06001066 RID: 4198 RVA: 0x00009BD8 File Offset: 0x00007DD8
		internal virtual TextBlock LabFile { get; set; }

		// Token: 0x170002CF RID: 719
		// (get) Token: 0x06001067 RID: 4199 RVA: 0x00009BE1 File Offset: 0x00007DE1
		// (set) Token: 0x06001068 RID: 4200 RVA: 0x00009BE9 File Offset: 0x00007DE9
		internal virtual TextBlock LabThread { get; set; }

		// Token: 0x06001069 RID: 4201 RVA: 0x000713B0 File Offset: 0x0006F5B0
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_QueueIssuer)
			{
				this.m_QueueIssuer = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagespeedleft.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x0600106A RID: 4202 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600106B RID: 4203 RVA: 0x000713E0 File Offset: 0x0006F5E0
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.LabProgress = (TextBlock)target;
				return;
			}
			if (connectionId == 2)
			{
				this.LabSpeed = (TextBlock)target;
				return;
			}
			if (connectionId == 3)
			{
				this.LabFile = (TextBlock)target;
				return;
			}
			if (connectionId == 4)
			{
				this.LabThread = (TextBlock)target;
				return;
			}
			this.m_QueueIssuer = true;
		}

		// Token: 0x04000813 RID: 2067
		private bool configurationIssuer;

		// Token: 0x04000814 RID: 2068
		private readonly Dictionary<string, MyCard> m_ConfigIssuer;

		// Token: 0x04000815 RID: 2069
		[CompilerGenerated]
		[AccessedThroughProperty("LabProgress")]
		private TextBlock managerIssuer;

		// Token: 0x04000816 RID: 2070
		[CompilerGenerated]
		[AccessedThroughProperty("LabSpeed")]
		private TextBlock m_RuleIssuer;

		// Token: 0x04000817 RID: 2071
		[CompilerGenerated]
		[AccessedThroughProperty("LabFile")]
		private TextBlock merchantIssuer;

		// Token: 0x04000818 RID: 2072
		[CompilerGenerated]
		[AccessedThroughProperty("LabThread")]
		private TextBlock m_ExporterIssuer;

		// Token: 0x04000819 RID: 2073
		private bool m_QueueIssuer;
	}
}
