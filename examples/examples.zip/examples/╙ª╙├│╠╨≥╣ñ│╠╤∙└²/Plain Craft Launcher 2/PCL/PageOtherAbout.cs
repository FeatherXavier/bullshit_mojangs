﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000147 RID: 327
	[DesignerGenerated]
	public class PageOtherAbout : MyPageRight, IComponentConnector
	{
		// Token: 0x06000CE5 RID: 3301 RVA: 0x00008701 File Offset: 0x00006901
		public PageOtherAbout()
		{
			base.Loaded += this.PageOtherAbout_Loaded;
			this._InterceptorComparator = false;
			this.InitializeComponent();
		}

		// Token: 0x06000CE6 RID: 3302 RVA: 0x000630A8 File Offset: 0x000612A8
		private void PageOtherAbout_Loaded(object sender, RoutedEventArgs e)
		{
			this.PanBack.ScrollToHome();
			if (!this._InterceptorComparator)
			{
				this._InterceptorComparator = true;
				this.ItemAboutPcl.Info = this.ItemAboutPcl.Info.Replace("%VERSION%", "Release 2.2.9").Replace("%VERSIONCODE%", Conversions.ToString(246)).Replace("%BRANCH%", "50");
			}
		}

		// Token: 0x06000CE7 RID: 3303 RVA: 0x00008729 File Offset: 0x00006929
		public static void BtnDonateDonate_Click()
		{
			ModBase.OpenWebsite("https://afdian.net/p/8fe6fefefde811e9bda952540025c377");
		}

		// Token: 0x06000CE8 RID: 3304 RVA: 0x00008735 File Offset: 0x00006935
		private void BtnEula_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://shimo.im/docs/rGrd8pY8xWkt6ryW");
		}

		// Token: 0x06000CE9 RID: 3305 RVA: 0x00008741 File Offset: 0x00006941
		private void BtnAboutBmclapi_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://afdian.net/@bangbang93");
		}

		// Token: 0x06000CEA RID: 3306 RVA: 0x0000874D File Offset: 0x0000694D
		private void BtnAboutMcbbs_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://www.mcbbs.net/forum.php");
		}

		// Token: 0x06000CEB RID: 3307 RVA: 0x00008759 File Offset: 0x00006959
		private void BtnAboutTss_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://afdian.net/@TSStudio");
		}

		// Token: 0x06000CEC RID: 3308 RVA: 0x00008765 File Offset: 0x00006965
		private void BtnAboutNoin_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://noin.cn");
		}

		// Token: 0x06000CED RID: 3309 RVA: 0x00008771 File Offset: 0x00006971
		private void BtnAboutWiki_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://www.mcmod.cn");
		}

		// Token: 0x06000CEE RID: 3310 RVA: 0x0000759D File Offset: 0x0000579D
		private void BtnDonateCopy_Click()
		{
			ModBase.ClipboardSet(ModBase.initializerState, true);
		}

		// Token: 0x06000CEF RID: 3311 RVA: 0x00063118 File Offset: 0x00061318
		public static bool? DonateCodeInput()
		{
			ModMain.Hint("正式版无法使用主题功能，若你获得了解锁码，请在快照版中使用！", ModMain.HintType.Info, true);
			bool? result;
			return result;
		}

		// Token: 0x06000CF0 RID: 3312 RVA: 0x0000877D File Offset: 0x0000697D
		private void BtnAudioLicence_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://github.com/naudio/NAudio/blob/master/license.txt");
		}

		// Token: 0x06000CF1 RID: 3313 RVA: 0x00008789 File Offset: 0x00006989
		private void BtnAudioWeb_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://github.com/naudio/NAudio");
		}

		// Token: 0x06000CF2 RID: 3314 RVA: 0x00008795 File Offset: 0x00006995
		private void BtnJsonLicence_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://opensource.org/licenses/MIT");
		}

		// Token: 0x06000CF3 RID: 3315 RVA: 0x000087A1 File Offset: 0x000069A1
		private void BtnJsonWeb_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://www.newtonsoft.com/json");
		}

		// Token: 0x06000CF4 RID: 3316 RVA: 0x000087AD File Offset: 0x000069AD
		private void BtnMonstrLicence_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://iconmonstr.com/license/");
		}

		// Token: 0x06000CF5 RID: 3317 RVA: 0x000087B9 File Offset: 0x000069B9
		private void BtnMonstrWeb_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://iconmonstr.com/");
		}

		// Token: 0x06000CF6 RID: 3318 RVA: 0x000087C5 File Offset: 0x000069C5
		private void BtnDialogLicence_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://github.com/caioproiete/ookii-dialogs-wpf/blob/master/LICENSE");
		}

		// Token: 0x06000CF7 RID: 3319 RVA: 0x000087D1 File Offset: 0x000069D1
		private void BtnDialogWeb_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("http://www.ookii.org/Software/Dialogs/");
		}

		// Token: 0x06000CF8 RID: 3320 RVA: 0x000087DD File Offset: 0x000069DD
		private void BtnFontWeb_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://www.iconfont.cn/");
		}

		// Token: 0x170001ED RID: 493
		// (get) Token: 0x06000CF9 RID: 3321 RVA: 0x000087E9 File Offset: 0x000069E9
		// (set) Token: 0x06000CFA RID: 3322 RVA: 0x000087F1 File Offset: 0x000069F1
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x170001EE RID: 494
		// (get) Token: 0x06000CFB RID: 3323 RVA: 0x000087FA File Offset: 0x000069FA
		// (set) Token: 0x06000CFC RID: 3324 RVA: 0x00008802 File Offset: 0x00006A02
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x170001EF RID: 495
		// (get) Token: 0x06000CFD RID: 3325 RVA: 0x0000880B File Offset: 0x00006A0B
		// (set) Token: 0x06000CFE RID: 3326 RVA: 0x00008813 File Offset: 0x00006A13
		internal virtual MyListItem ItemAboutPcl { get; set; }

		// Token: 0x170001F0 RID: 496
		// (get) Token: 0x06000CFF RID: 3327 RVA: 0x0000881C File Offset: 0x00006A1C
		// (set) Token: 0x06000D00 RID: 3328 RVA: 0x00063134 File Offset: 0x00061334
		internal virtual MyButton BtnAboutDonate
		{
			[CompilerGenerated]
			get
			{
				return this.importerComparator;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = (PageOtherAbout._Closure$__.$IR35-1 == null) ? (PageOtherAbout._Closure$__.$IR35-1 = delegate(object sender, EventArgs e)
				{
					PageOtherAbout.BtnDonateDonate_Click();
				}) : PageOtherAbout._Closure$__.$IR35-1;
				MyButton myButton = this.importerComparator;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.importerComparator = value;
				myButton = this.importerComparator;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001F1 RID: 497
		// (get) Token: 0x06000D01 RID: 3329 RVA: 0x00008824 File Offset: 0x00006A24
		// (set) Token: 0x06000D02 RID: 3330 RVA: 0x00063190 File Offset: 0x00061390
		internal virtual MyButton BtnAboutMcbbs
		{
			[CompilerGenerated]
			get
			{
				return this._ProxyComparator;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnAboutMcbbs_Click);
				MyButton proxyComparator = this._ProxyComparator;
				if (proxyComparator != null)
				{
					proxyComparator.RevertResolver(obj);
				}
				this._ProxyComparator = value;
				proxyComparator = this._ProxyComparator;
				if (proxyComparator != null)
				{
					proxyComparator.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001F2 RID: 498
		// (get) Token: 0x06000D03 RID: 3331 RVA: 0x0000882C File Offset: 0x00006A2C
		// (set) Token: 0x06000D04 RID: 3332 RVA: 0x000631D4 File Offset: 0x000613D4
		internal virtual MyButton BtnAboutBmclapi
		{
			[CompilerGenerated]
			get
			{
				return this._ClassComparator;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnAboutBmclapi_Click);
				MyButton classComparator = this._ClassComparator;
				if (classComparator != null)
				{
					classComparator.RevertResolver(obj);
				}
				this._ClassComparator = value;
				classComparator = this._ClassComparator;
				if (classComparator != null)
				{
					classComparator.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001F3 RID: 499
		// (get) Token: 0x06000D05 RID: 3333 RVA: 0x00008834 File Offset: 0x00006A34
		// (set) Token: 0x06000D06 RID: 3334 RVA: 0x00063218 File Offset: 0x00061418
		internal virtual MyButton BtnAboutTss
		{
			[CompilerGenerated]
			get
			{
				return this._RegistryComparator;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnAboutTss_Click);
				MyButton registryComparator = this._RegistryComparator;
				if (registryComparator != null)
				{
					registryComparator.RevertResolver(obj);
				}
				this._RegistryComparator = value;
				registryComparator = this._RegistryComparator;
				if (registryComparator != null)
				{
					registryComparator.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001F4 RID: 500
		// (get) Token: 0x06000D07 RID: 3335 RVA: 0x0000883C File Offset: 0x00006A3C
		// (set) Token: 0x06000D08 RID: 3336 RVA: 0x0006325C File Offset: 0x0006145C
		internal virtual MyButton BtnAboutNoin
		{
			[CompilerGenerated]
			get
			{
				return this.producerComparator;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnAboutNoin_Click);
				MyButton myButton = this.producerComparator;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.producerComparator = value;
				myButton = this.producerComparator;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001F5 RID: 501
		// (get) Token: 0x06000D09 RID: 3337 RVA: 0x00008844 File Offset: 0x00006A44
		// (set) Token: 0x06000D0A RID: 3338 RVA: 0x000632A0 File Offset: 0x000614A0
		internal virtual MyButton BtnAboutWiki
		{
			[CompilerGenerated]
			get
			{
				return this._CandidateComparator;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnAboutWiki_Click);
				MyButton candidateComparator = this._CandidateComparator;
				if (candidateComparator != null)
				{
					candidateComparator.RevertResolver(obj);
				}
				this._CandidateComparator = value;
				candidateComparator = this._CandidateComparator;
				if (candidateComparator != null)
				{
					candidateComparator.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001F6 RID: 502
		// (get) Token: 0x06000D0B RID: 3339 RVA: 0x0000884C File Offset: 0x00006A4C
		// (set) Token: 0x06000D0C RID: 3340 RVA: 0x00008854 File Offset: 0x00006A54
		internal virtual MyButton BtnDonateOutput { get; set; }

		// Token: 0x170001F7 RID: 503
		// (get) Token: 0x06000D0D RID: 3341 RVA: 0x0000885D File Offset: 0x00006A5D
		// (set) Token: 0x06000D0E RID: 3342 RVA: 0x000632E4 File Offset: 0x000614E4
		internal virtual MyButton BtnDonateDonate
		{
			[CompilerGenerated]
			get
			{
				return this.m_MappingComparator;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = (PageOtherAbout._Closure$__.$IR63-2 == null) ? (PageOtherAbout._Closure$__.$IR63-2 = delegate(object sender, EventArgs e)
				{
					PageOtherAbout.BtnDonateDonate_Click();
				}) : PageOtherAbout._Closure$__.$IR63-2;
				MyButton mappingComparator = this.m_MappingComparator;
				if (mappingComparator != null)
				{
					mappingComparator.RevertResolver(obj);
				}
				this.m_MappingComparator = value;
				mappingComparator = this.m_MappingComparator;
				if (mappingComparator != null)
				{
					mappingComparator.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001F8 RID: 504
		// (get) Token: 0x06000D0F RID: 3343 RVA: 0x00008865 File Offset: 0x00006A65
		// (set) Token: 0x06000D10 RID: 3344 RVA: 0x00063340 File Offset: 0x00061540
		internal virtual MyButton BtnDonateCopy
		{
			[CompilerGenerated]
			get
			{
				return this.dispatcherComparator;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.BtnDonateCopy_Click();
				};
				MyButton myButton = this.dispatcherComparator;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.dispatcherComparator = value;
				myButton = this.dispatcherComparator;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001F9 RID: 505
		// (get) Token: 0x06000D11 RID: 3345 RVA: 0x0000886D File Offset: 0x00006A6D
		// (set) Token: 0x06000D12 RID: 3346 RVA: 0x00063384 File Offset: 0x00061584
		internal virtual MyButton BtnDonateInput
		{
			[CompilerGenerated]
			get
			{
				return this.m_MessageComparator;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = (PageOtherAbout._Closure$__.$IR71-4 == null) ? (PageOtherAbout._Closure$__.$IR71-4 = delegate(object sender, EventArgs e)
				{
					PageOtherAbout.DonateCodeInput();
				}) : PageOtherAbout._Closure$__.$IR71-4;
				MyButton messageComparator = this.m_MessageComparator;
				if (messageComparator != null)
				{
					messageComparator.RevertResolver(obj);
				}
				this.m_MessageComparator = value;
				messageComparator = this.m_MessageComparator;
				if (messageComparator != null)
				{
					messageComparator.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001FA RID: 506
		// (get) Token: 0x06000D13 RID: 3347 RVA: 0x00008875 File Offset: 0x00006A75
		// (set) Token: 0x06000D14 RID: 3348 RVA: 0x000633E0 File Offset: 0x000615E0
		internal virtual MyButton BtnEula
		{
			[CompilerGenerated]
			get
			{
				return this._StatusComparator;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnEula_Click);
				MyButton statusComparator = this._StatusComparator;
				if (statusComparator != null)
				{
					statusComparator.RevertResolver(obj);
				}
				this._StatusComparator = value;
				statusComparator = this._StatusComparator;
				if (statusComparator != null)
				{
					statusComparator.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001FB RID: 507
		// (get) Token: 0x06000D15 RID: 3349 RVA: 0x0000887D File Offset: 0x00006A7D
		// (set) Token: 0x06000D16 RID: 3350 RVA: 0x00063424 File Offset: 0x00061624
		internal virtual MyButton BtnJsonWeb
		{
			[CompilerGenerated]
			get
			{
				return this._ProcComparator;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnJsonWeb_Click);
				MyButton procComparator = this._ProcComparator;
				if (procComparator != null)
				{
					procComparator.RevertResolver(obj);
				}
				this._ProcComparator = value;
				procComparator = this._ProcComparator;
				if (procComparator != null)
				{
					procComparator.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001FC RID: 508
		// (get) Token: 0x06000D17 RID: 3351 RVA: 0x00008885 File Offset: 0x00006A85
		// (set) Token: 0x06000D18 RID: 3352 RVA: 0x00063468 File Offset: 0x00061668
		internal virtual MyButton BtnJsonLicence
		{
			[CompilerGenerated]
			get
			{
				return this.m_ModelPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnJsonLicence_Click);
				MyButton modelPrototype = this.m_ModelPrototype;
				if (modelPrototype != null)
				{
					modelPrototype.RevertResolver(obj);
				}
				this.m_ModelPrototype = value;
				modelPrototype = this.m_ModelPrototype;
				if (modelPrototype != null)
				{
					modelPrototype.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001FD RID: 509
		// (get) Token: 0x06000D19 RID: 3353 RVA: 0x0000888D File Offset: 0x00006A8D
		// (set) Token: 0x06000D1A RID: 3354 RVA: 0x000634AC File Offset: 0x000616AC
		internal virtual MyButton BtnAudioWeb
		{
			[CompilerGenerated]
			get
			{
				return this.wrapperPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnAudioWeb_Click);
				MyButton myButton = this.wrapperPrototype;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.wrapperPrototype = value;
				myButton = this.wrapperPrototype;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001FE RID: 510
		// (get) Token: 0x06000D1B RID: 3355 RVA: 0x00008895 File Offset: 0x00006A95
		// (set) Token: 0x06000D1C RID: 3356 RVA: 0x000634F0 File Offset: 0x000616F0
		internal virtual MyButton BtnAudioLicence
		{
			[CompilerGenerated]
			get
			{
				return this._RepositoryPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnAudioLicence_Click);
				MyButton repositoryPrototype = this._RepositoryPrototype;
				if (repositoryPrototype != null)
				{
					repositoryPrototype.RevertResolver(obj);
				}
				this._RepositoryPrototype = value;
				repositoryPrototype = this._RepositoryPrototype;
				if (repositoryPrototype != null)
				{
					repositoryPrototype.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001FF RID: 511
		// (get) Token: 0x06000D1D RID: 3357 RVA: 0x0000889D File Offset: 0x00006A9D
		// (set) Token: 0x06000D1E RID: 3358 RVA: 0x00063534 File Offset: 0x00061734
		internal virtual MyButton BtnDialogWeb
		{
			[CompilerGenerated]
			get
			{
				return this.m_ResolverPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnDialogWeb_Click);
				MyButton resolverPrototype = this.m_ResolverPrototype;
				if (resolverPrototype != null)
				{
					resolverPrototype.RevertResolver(obj);
				}
				this.m_ResolverPrototype = value;
				resolverPrototype = this.m_ResolverPrototype;
				if (resolverPrototype != null)
				{
					resolverPrototype.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000200 RID: 512
		// (get) Token: 0x06000D1F RID: 3359 RVA: 0x000088A5 File Offset: 0x00006AA5
		// (set) Token: 0x06000D20 RID: 3360 RVA: 0x00063578 File Offset: 0x00061778
		internal virtual MyButton BtnDialogLicence
		{
			[CompilerGenerated]
			get
			{
				return this._TagPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnDialogLicence_Click);
				MyButton tagPrototype = this._TagPrototype;
				if (tagPrototype != null)
				{
					tagPrototype.RevertResolver(obj);
				}
				this._TagPrototype = value;
				tagPrototype = this._TagPrototype;
				if (tagPrototype != null)
				{
					tagPrototype.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000201 RID: 513
		// (get) Token: 0x06000D21 RID: 3361 RVA: 0x000088AD File Offset: 0x00006AAD
		// (set) Token: 0x06000D22 RID: 3362 RVA: 0x000635BC File Offset: 0x000617BC
		internal virtual MyButton BtnMonstrWeb
		{
			[CompilerGenerated]
			get
			{
				return this.m_ComparatorPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnMonstrWeb_Click);
				MyButton comparatorPrototype = this.m_ComparatorPrototype;
				if (comparatorPrototype != null)
				{
					comparatorPrototype.RevertResolver(obj);
				}
				this.m_ComparatorPrototype = value;
				comparatorPrototype = this.m_ComparatorPrototype;
				if (comparatorPrototype != null)
				{
					comparatorPrototype.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000202 RID: 514
		// (get) Token: 0x06000D23 RID: 3363 RVA: 0x000088B5 File Offset: 0x00006AB5
		// (set) Token: 0x06000D24 RID: 3364 RVA: 0x00063600 File Offset: 0x00061800
		internal virtual MyButton BtnMonstrLicence
		{
			[CompilerGenerated]
			get
			{
				return this.m_PrototypePrototype;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnMonstrLicence_Click);
				MyButton prototypePrototype = this.m_PrototypePrototype;
				if (prototypePrototype != null)
				{
					prototypePrototype.RevertResolver(obj);
				}
				this.m_PrototypePrototype = value;
				prototypePrototype = this.m_PrototypePrototype;
				if (prototypePrototype != null)
				{
					prototypePrototype.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000203 RID: 515
		// (get) Token: 0x06000D25 RID: 3365 RVA: 0x000088BD File Offset: 0x00006ABD
		// (set) Token: 0x06000D26 RID: 3366 RVA: 0x00063644 File Offset: 0x00061844
		internal virtual MyButton BtnFontWeb
		{
			[CompilerGenerated]
			get
			{
				return this.issuerPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnFontWeb_Click);
				MyButton myButton = this.issuerPrototype;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.issuerPrototype = value;
				myButton = this.issuerPrototype;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000204 RID: 516
		// (get) Token: 0x06000D27 RID: 3367 RVA: 0x000088C5 File Offset: 0x00006AC5
		// (set) Token: 0x06000D28 RID: 3368 RVA: 0x00063688 File Offset: 0x00061888
		internal virtual MyButton BtnCato
		{
			[CompilerGenerated]
			get
			{
				return this._RequestPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnAboutNoin_Click);
				MyButton requestPrototype = this._RequestPrototype;
				if (requestPrototype != null)
				{
					requestPrototype.RevertResolver(obj);
				}
				this._RequestPrototype = value;
				requestPrototype = this._RequestPrototype;
				if (requestPrototype != null)
				{
					requestPrototype.PostResolver(obj);
				}
			}
		}

		// Token: 0x06000D29 RID: 3369 RVA: 0x000636CC File Offset: 0x000618CC
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.accountPrototype)
			{
				this.accountPrototype = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pageother/pageotherabout.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000D2A RID: 3370 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000D2B RID: 3371 RVA: 0x000636FC File Offset: 0x000618FC
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			if (connectionId == 3)
			{
				this.ItemAboutPcl = (MyListItem)target;
				return;
			}
			if (connectionId == 4)
			{
				this.BtnAboutDonate = (MyButton)target;
				return;
			}
			if (connectionId == 5)
			{
				this.BtnAboutMcbbs = (MyButton)target;
				return;
			}
			if (connectionId == 6)
			{
				this.BtnAboutBmclapi = (MyButton)target;
				return;
			}
			if (connectionId == 7)
			{
				this.BtnAboutTss = (MyButton)target;
				return;
			}
			if (connectionId == 8)
			{
				this.BtnAboutNoin = (MyButton)target;
				return;
			}
			if (connectionId == 9)
			{
				this.BtnAboutWiki = (MyButton)target;
				return;
			}
			if (connectionId == 10)
			{
				this.BtnDonateOutput = (MyButton)target;
				return;
			}
			if (connectionId == 11)
			{
				this.BtnDonateDonate = (MyButton)target;
				return;
			}
			if (connectionId == 12)
			{
				this.BtnDonateCopy = (MyButton)target;
				return;
			}
			if (connectionId == 13)
			{
				this.BtnDonateInput = (MyButton)target;
				return;
			}
			if (connectionId == 14)
			{
				this.BtnEula = (MyButton)target;
				return;
			}
			if (connectionId == 15)
			{
				this.BtnJsonWeb = (MyButton)target;
				return;
			}
			if (connectionId == 16)
			{
				this.BtnJsonLicence = (MyButton)target;
				return;
			}
			if (connectionId == 17)
			{
				this.BtnAudioWeb = (MyButton)target;
				return;
			}
			if (connectionId == 18)
			{
				this.BtnAudioLicence = (MyButton)target;
				return;
			}
			if (connectionId == 19)
			{
				this.BtnDialogWeb = (MyButton)target;
				return;
			}
			if (connectionId == 20)
			{
				this.BtnDialogLicence = (MyButton)target;
				return;
			}
			if (connectionId == 21)
			{
				this.BtnMonstrWeb = (MyButton)target;
				return;
			}
			if (connectionId == 22)
			{
				this.BtnMonstrLicence = (MyButton)target;
				return;
			}
			if (connectionId == 23)
			{
				this.BtnFontWeb = (MyButton)target;
				return;
			}
			if (connectionId == 24)
			{
				this.BtnCato = (MyButton)target;
				return;
			}
			this.accountPrototype = true;
		}

		// Token: 0x0400068F RID: 1679
		private bool _InterceptorComparator;

		// Token: 0x04000690 RID: 1680
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyScrollViewer m_RefComparator;

		// Token: 0x04000691 RID: 1681
		[CompilerGenerated]
		[AccessedThroughProperty("PanMain")]
		private StackPanel m_ServerComparator;

		// Token: 0x04000692 RID: 1682
		[AccessedThroughProperty("ItemAboutPcl")]
		[CompilerGenerated]
		private MyListItem m_ServiceComparator;

		// Token: 0x04000693 RID: 1683
		[CompilerGenerated]
		[AccessedThroughProperty("BtnAboutDonate")]
		private MyButton importerComparator;

		// Token: 0x04000694 RID: 1684
		[AccessedThroughProperty("BtnAboutMcbbs")]
		[CompilerGenerated]
		private MyButton _ProxyComparator;

		// Token: 0x04000695 RID: 1685
		[CompilerGenerated]
		[AccessedThroughProperty("BtnAboutBmclapi")]
		private MyButton _ClassComparator;

		// Token: 0x04000696 RID: 1686
		[AccessedThroughProperty("BtnAboutTss")]
		[CompilerGenerated]
		private MyButton _RegistryComparator;

		// Token: 0x04000697 RID: 1687
		[CompilerGenerated]
		[AccessedThroughProperty("BtnAboutNoin")]
		private MyButton producerComparator;

		// Token: 0x04000698 RID: 1688
		[CompilerGenerated]
		[AccessedThroughProperty("BtnAboutWiki")]
		private MyButton _CandidateComparator;

		// Token: 0x04000699 RID: 1689
		[AccessedThroughProperty("BtnDonateOutput")]
		[CompilerGenerated]
		private MyButton setterComparator;

		// Token: 0x0400069A RID: 1690
		[AccessedThroughProperty("BtnDonateDonate")]
		[CompilerGenerated]
		private MyButton m_MappingComparator;

		// Token: 0x0400069B RID: 1691
		[CompilerGenerated]
		[AccessedThroughProperty("BtnDonateCopy")]
		private MyButton dispatcherComparator;

		// Token: 0x0400069C RID: 1692
		[AccessedThroughProperty("BtnDonateInput")]
		[CompilerGenerated]
		private MyButton m_MessageComparator;

		// Token: 0x0400069D RID: 1693
		[AccessedThroughProperty("BtnEula")]
		[CompilerGenerated]
		private MyButton _StatusComparator;

		// Token: 0x0400069E RID: 1694
		[AccessedThroughProperty("BtnJsonWeb")]
		[CompilerGenerated]
		private MyButton _ProcComparator;

		// Token: 0x0400069F RID: 1695
		[AccessedThroughProperty("BtnJsonLicence")]
		[CompilerGenerated]
		private MyButton m_ModelPrototype;

		// Token: 0x040006A0 RID: 1696
		[AccessedThroughProperty("BtnAudioWeb")]
		[CompilerGenerated]
		private MyButton wrapperPrototype;

		// Token: 0x040006A1 RID: 1697
		[CompilerGenerated]
		[AccessedThroughProperty("BtnAudioLicence")]
		private MyButton _RepositoryPrototype;

		// Token: 0x040006A2 RID: 1698
		[AccessedThroughProperty("BtnDialogWeb")]
		[CompilerGenerated]
		private MyButton m_ResolverPrototype;

		// Token: 0x040006A3 RID: 1699
		[AccessedThroughProperty("BtnDialogLicence")]
		[CompilerGenerated]
		private MyButton _TagPrototype;

		// Token: 0x040006A4 RID: 1700
		[AccessedThroughProperty("BtnMonstrWeb")]
		[CompilerGenerated]
		private MyButton m_ComparatorPrototype;

		// Token: 0x040006A5 RID: 1701
		[CompilerGenerated]
		[AccessedThroughProperty("BtnMonstrLicence")]
		private MyButton m_PrototypePrototype;

		// Token: 0x040006A6 RID: 1702
		[CompilerGenerated]
		[AccessedThroughProperty("BtnFontWeb")]
		private MyButton issuerPrototype;

		// Token: 0x040006A7 RID: 1703
		[CompilerGenerated]
		[AccessedThroughProperty("BtnCato")]
		private MyButton _RequestPrototype;

		// Token: 0x040006A8 RID: 1704
		private bool accountPrototype;
	}
}
