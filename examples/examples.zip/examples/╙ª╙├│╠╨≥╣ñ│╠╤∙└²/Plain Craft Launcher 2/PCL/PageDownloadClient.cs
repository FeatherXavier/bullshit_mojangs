﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using Microsoft.VisualBasic.CompilerServices;
using Newtonsoft.Json.Linq;

namespace PCL
{
	// Token: 0x0200014F RID: 335
	[DesignerGenerated]
	public class PageDownloadClient : MyPageRight, IComponentConnector
	{
		// Token: 0x06000D93 RID: 3475 RVA: 0x00008BA8 File Offset: 0x00006DA8
		public PageDownloadClient()
		{
			base.Initialized += delegate(object sender, EventArgs e)
			{
				this.LoaderInit();
			};
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.Init();
			};
			this.InitializeComponent();
		}

		// Token: 0x06000D94 RID: 3476 RVA: 0x00064C50 File Offset: 0x00062E50
		private void LoaderInit()
		{
			base.PageLoaderInit(this.Load, this.PanLoad, this.PanBack, null, ModDownload.propertyTag, delegate(ModLoader.LoaderBase a0)
			{
				this.Load_OnFinish();
			}, null, true);
		}

		// Token: 0x06000D95 RID: 3477 RVA: 0x00008BDB File Offset: 0x00006DDB
		private void Init()
		{
			this.PanBack.ScrollToHome();
		}

		// Token: 0x06000D96 RID: 3478 RVA: 0x00064C8C File Offset: 0x00062E8C
		private void Load_OnFinish()
		{
			checked
			{
				try
				{
					Dictionary<string, List<JObject>> dictionary = new Dictionary<string, List<JObject>>
					{
						{
							"正式版",
							new List<JObject>()
						},
						{
							"预览版",
							new List<JObject>()
						},
						{
							"远古版",
							new List<JObject>()
						},
						{
							"愚人节版",
							new List<JObject>()
						}
					};
					JArray jarray = (JArray)ModDownload.propertyTag.Output.Value["versions"];
					try
					{
						foreach (JToken jtoken in jarray)
						{
							JObject jobject = (JObject)jtoken;
							string text = (string)jobject["type"];
							string left = text;
							if (Operators.CompareString(left, "release", true) == 0)
							{
								text = "正式版";
							}
							else if (Operators.CompareString(left, "snapshot", true) == 0)
							{
								text = "预览版";
								if (jobject["id"].ToString().StartsWith("1.") && !jobject["id"].ToString().ToLower().Contains("combat") && !jobject["id"].ToString().ToLower().Contains("rc") && !jobject["id"].ToString().ToLower().Contains("experimental") && !jobject["id"].ToString().ToLower().Contains("pre"))
								{
									text = "正式版";
									jobject["type"] = "release";
								}
								string left2 = jobject["id"].ToString().ToLower();
								if (Operators.CompareString(left2, "20w14infinite", true) != 0 && Operators.CompareString(left2, "20w14∞", true) != 0)
								{
									if (Operators.CompareString(left2, "3d shareware v1.34", true) == 0 || Operators.CompareString(left2, "1.rv-pre1", true) == 0 || Operators.CompareString(left2, "15w14a", true) == 0 || Operators.CompareString(left2, "2.0", true) == 0)
									{
										text = "愚人节版";
										jobject["type"] = "special";
										jobject.Add("lore", ModMinecraft.GetMcFoolName((string)jobject["id"]));
									}
								}
								else
								{
									text = "愚人节版";
									jobject["id"] = "20w14∞";
									jobject["type"] = "special";
									jobject.Add("lore", ModMinecraft.GetMcFoolName((string)jobject["id"]));
								}
							}
							else if (Operators.CompareString(left, "special", true) == 0)
							{
								text = "愚人节版";
							}
							else
							{
								text = "远古版";
							}
							dictionary[text].Add(jobject);
						}
					}
					finally
					{
						IEnumerator<JToken> enumerator;
						if (enumerator != null)
						{
							enumerator.Dispose();
						}
					}
					int num = dictionary.Keys.Count - 1;
					for (int i = 0; i <= num; i++)
					{
						dictionary[dictionary.Keys.ElementAtOrDefault(i)] = ModBase.Sort<JObject>(dictionary.Values.ElementAtOrDefault(i), (PageDownloadClient._Closure$__.$IR3-4 == null) ? (PageDownloadClient._Closure$__.$IR3-4 = ((object a0, object a1) => ((PageDownloadClient._Closure$__.$I3-0 == null) ? (PageDownloadClient._Closure$__.$I3-0 = ((JObject Left, JObject Right) => DateTime.Compare(Extensions.Value<DateTime>(Left["releaseTime"]), Extensions.Value<DateTime>(Right["releaseTime"])) > 0)) : PageDownloadClient._Closure$__.$I3-0)((JObject)a0, (JObject)a1))) : PageDownloadClient._Closure$__.$IR3-4);
					}
					this.PanMain.Children.Clear();
					MyCard myCard = new MyCard();
					myCard.Title = "最新版本";
					myCard.Margin = new Thickness(0.0, 0.0, 0.0, 15.0);
					myCard.CustomizeModel(2);
					MyCard myCard2 = myCard;
					List<JObject> list = new List<JObject>();
					JObject jobject2 = (JObject)dictionary["正式版"][0].DeepClone();
					jobject2["lore"] = "最新正式版，发布于 " + jobject2["releaseTime"].ToString();
					list.Add(jobject2);
					if (DateTime.Compare(Extensions.Value<DateTime>(dictionary["正式版"][0]["releaseTime"]), Extensions.Value<DateTime>(dictionary["预览版"][0]["releaseTime"])) < 0)
					{
						JObject jobject3 = (JObject)dictionary["预览版"][0].DeepClone();
						jobject3["lore"] = "最新预览版，发布于 " + jobject3["releaseTime"].ToString();
						list.Add(jobject3);
					}
					StackPanel element = new StackPanel
					{
						Margin = new Thickness(20.0, 40.0, 18.0, 0.0),
						VerticalAlignment = VerticalAlignment.Top,
						RenderTransform = new TranslateTransform(0.0, 0.0),
						Tag = list
					};
					MyCard.StackInstall(ref element, 2, "");
					myCard2.Children.Add(element);
					this.PanMain.Children.Add(myCard2);
					try
					{
						foreach (KeyValuePair<string, List<JObject>> keyValuePair in dictionary)
						{
							if (keyValuePair.Value.Count != 0)
							{
								MyCard myCard3 = new MyCard();
								myCard3.Title = keyValuePair.Key + " (" + Conversions.ToString(keyValuePair.Value.Count) + ")";
								myCard3.Margin = new Thickness(0.0, 0.0, 0.0, 15.0);
								myCard3.CustomizeModel(2);
								MyCard myCard4 = myCard3;
								StackPanel stackPanel = new StackPanel
								{
									Margin = new Thickness(20.0, 40.0, 18.0, 0.0),
									VerticalAlignment = VerticalAlignment.Top,
									RenderTransform = new TranslateTransform(0.0, 0.0),
									Tag = keyValuePair.Value
								};
								myCard4.Children.Add(stackPanel);
								myCard4.m_Decorator = stackPanel;
								myCard4.IsSwaped = true;
								this.PanMain.Children.Add(myCard4);
							}
						}
					}
					finally
					{
						Dictionary<string, List<JObject>>.Enumerator enumerator2;
						((IDisposable)enumerator2).Dispose();
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "可视化版本列表出错", ModBase.LogLevel.Feedback, "出现错误");
				}
			}
		}

		// Token: 0x06000D97 RID: 3479 RVA: 0x00008BE8 File Offset: 0x00006DE8
		public void DownloadStart(MyListItem sender, object e)
		{
			ModDownloadLib.McDownloadClient(ModNet.NetPreDownloadBehaviour.HintWhileExists, sender.Title, NewLateBinding.LateIndexGet(sender.Tag, new object[]
			{
				"url"
			}, null).ToString());
		}

		// Token: 0x17000219 RID: 537
		// (get) Token: 0x06000D98 RID: 3480 RVA: 0x00008C16 File Offset: 0x00006E16
		// (set) Token: 0x06000D99 RID: 3481 RVA: 0x00008C1E File Offset: 0x00006E1E
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x1700021A RID: 538
		// (get) Token: 0x06000D9A RID: 3482 RVA: 0x00008C27 File Offset: 0x00006E27
		// (set) Token: 0x06000D9B RID: 3483 RVA: 0x00008C2F File Offset: 0x00006E2F
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x1700021B RID: 539
		// (get) Token: 0x06000D9C RID: 3484 RVA: 0x00008C38 File Offset: 0x00006E38
		// (set) Token: 0x06000D9D RID: 3485 RVA: 0x00008C40 File Offset: 0x00006E40
		internal virtual MyCard PanLoad { get; set; }

		// Token: 0x1700021C RID: 540
		// (get) Token: 0x06000D9E RID: 3486 RVA: 0x00008C49 File Offset: 0x00006E49
		// (set) Token: 0x06000D9F RID: 3487 RVA: 0x00008C51 File Offset: 0x00006E51
		internal virtual MyLoading Load { get; set; }

		// Token: 0x06000DA0 RID: 3488 RVA: 0x00065388 File Offset: 0x00063588
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.poolPrototype)
			{
				this.poolPrototype = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagedownload/pagedownloadclient.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000DA1 RID: 3489 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000DA2 RID: 3490 RVA: 0x000653B8 File Offset: 0x000635B8
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			if (connectionId == 3)
			{
				this.PanLoad = (MyCard)target;
				return;
			}
			if (connectionId == 4)
			{
				this.Load = (MyLoading)target;
				return;
			}
			this.poolPrototype = true;
		}

		// Token: 0x040006CB RID: 1739
		[CompilerGenerated]
		[AccessedThroughProperty("PanBack")]
		private MyScrollViewer m_DescriptorPrototype;

		// Token: 0x040006CC RID: 1740
		[AccessedThroughProperty("PanMain")]
		[CompilerGenerated]
		private StackPanel mapPrototype;

		// Token: 0x040006CD RID: 1741
		[CompilerGenerated]
		[AccessedThroughProperty("PanLoad")]
		private MyCard eventPrototype;

		// Token: 0x040006CE RID: 1742
		[AccessedThroughProperty("Load")]
		[CompilerGenerated]
		private MyLoading _AlgoPrototype;

		// Token: 0x040006CF RID: 1743
		private bool poolPrototype;
	}
}
