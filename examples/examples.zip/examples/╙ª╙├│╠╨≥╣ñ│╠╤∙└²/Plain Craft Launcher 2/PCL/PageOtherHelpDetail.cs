﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x020000A5 RID: 165
	[DesignerGenerated]
	public class PageOtherHelpDetail : MyPageRight, IComponentConnector
	{
		// Token: 0x06000634 RID: 1588 RVA: 0x00005403 File Offset: 0x00003603
		public PageOtherHelpDetail()
		{
			base.Loaded += this.PageOtherHelpDetail_Loaded;
			this.InitializeComponent();
		}

		// Token: 0x06000635 RID: 1589 RVA: 0x00005424 File Offset: 0x00003624
		private void PageOtherHelpDetail_Loaded(object sender, RoutedEventArgs e)
		{
			this.PanBack.ScrollToTop();
		}

		// Token: 0x06000636 RID: 1590 RVA: 0x0002D728 File Offset: 0x0002B928
		public bool Init(ModMain.HelpEntry Entry)
		{
			string text = "<StackPanel xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\" xmlns:local=\"clr-namespace:PCL;assembly=Plain Craft Launcher 2\">" + Entry._TestsParameter + "</StackPanel>";
			bool result;
			try
			{
				if (string.IsNullOrEmpty(Entry._TestsParameter))
				{
					throw new Exception("帮助 xaml 文件为空");
				}
				this.m_SetterRepository = Entry;
				this.PanCustom.Children.Clear();
				text = text.Replace("{path}", ModBase.Path);
				this.PanCustom.Children.Add((UIElement)ModBase.GetObjectFromXML(text));
				result = true;
			}
			catch (Exception ex)
			{
				ModBase.Log("[System] 自定义信息内容：\r\n" + text, ModBase.LogLevel.Normal, "出现错误");
				ModBase.Log(ex, "加载帮助 xaml 文件失败", ModBase.LogLevel.Msgbox, "出现错误");
				result = false;
			}
			return result;
		}

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x06000637 RID: 1591 RVA: 0x00005431 File Offset: 0x00003631
		// (set) Token: 0x06000638 RID: 1592 RVA: 0x00005439 File Offset: 0x00003639
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x06000639 RID: 1593 RVA: 0x00005442 File Offset: 0x00003642
		// (set) Token: 0x0600063A RID: 1594 RVA: 0x0000544A File Offset: 0x0000364A
		internal virtual StackPanel PanCustom { get; set; }

		// Token: 0x0600063B RID: 1595 RVA: 0x0002D7F4 File Offset: 0x0002B9F4
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_MessageRepository)
			{
				this.m_MessageRepository = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pageother/pageotherhelpdetail.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x0600063C RID: 1596 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600063D RID: 1597 RVA: 0x00005453 File Offset: 0x00003653
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanCustom = (StackPanel)target;
				return;
			}
			this.m_MessageRepository = true;
		}

		// Token: 0x040002CA RID: 714
		public ModMain.HelpEntry m_SetterRepository;

		// Token: 0x040002CB RID: 715
		[CompilerGenerated]
		[AccessedThroughProperty("PanBack")]
		private MyScrollViewer m_MappingRepository;

		// Token: 0x040002CC RID: 716
		[CompilerGenerated]
		[AccessedThroughProperty("PanCustom")]
		private StackPanel dispatcherRepository;

		// Token: 0x040002CD RID: 717
		private bool m_MessageRepository;
	}
}
