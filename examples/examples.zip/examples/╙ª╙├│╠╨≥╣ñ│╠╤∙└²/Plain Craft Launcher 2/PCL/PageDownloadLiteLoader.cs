﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000123 RID: 291
	[DesignerGenerated]
	public class PageDownloadLiteLoader : MyPageRight, IComponentConnector
	{
		// Token: 0x06000A9B RID: 2715 RVA: 0x0000737A File Offset: 0x0000557A
		public PageDownloadLiteLoader()
		{
			base.Initialized += delegate(object sender, EventArgs e)
			{
				this.LoaderInit();
			};
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.Init();
			};
			this.InitializeComponent();
		}

		// Token: 0x06000A9C RID: 2716 RVA: 0x00055EB4 File Offset: 0x000540B4
		private void LoaderInit()
		{
			base.PageLoaderInit(this.Load, this.PanLoad, this.PanMain, this.CardTip, ModDownload.iteratorTag, delegate(ModLoader.LoaderBase a0)
			{
				this.Load_OnFinish();
			}, null, true);
		}

		// Token: 0x06000A9D RID: 2717 RVA: 0x000073AD File Offset: 0x000055AD
		private void Init()
		{
			this.PanBack.ScrollToHome();
		}

		// Token: 0x06000A9E RID: 2718 RVA: 0x00055EF4 File Offset: 0x000540F4
		private void Load_OnFinish()
		{
			checked
			{
				try
				{
					Dictionary<string, List<ModDownload.DlLiteLoaderListEntry>> dictionary = new Dictionary<string, List<ModDownload.DlLiteLoaderListEntry>>();
					int num = 30;
					do
					{
						dictionary.Add("1." + Conversions.ToString(num), new List<ModDownload.DlLiteLoaderListEntry>());
						num += -1;
					}
					while (num >= 0);
					dictionary.Add("未知版本", new List<ModDownload.DlLiteLoaderListEntry>());
					try
					{
						foreach (ModDownload.DlLiteLoaderListEntry dlLiteLoaderListEntry in ModDownload.iteratorTag.Output.Value)
						{
							string key = "1." + dlLiteLoaderListEntry.Inherit.Split(new char[]
							{
								'.'
							})[1];
							if (dictionary.ContainsKey(key))
							{
								dictionary[key].Add(dlLiteLoaderListEntry);
							}
							else
							{
								dictionary["未知版本"].Add(dlLiteLoaderListEntry);
							}
						}
					}
					finally
					{
						List<ModDownload.DlLiteLoaderListEntry>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
					this.PanMain.Children.Clear();
					try
					{
						foreach (KeyValuePair<string, List<ModDownload.DlLiteLoaderListEntry>> keyValuePair in dictionary)
						{
							if (keyValuePair.Value.Count != 0)
							{
								MyCard myCard = new MyCard();
								myCard.Title = keyValuePair.Key + " (" + Conversions.ToString(keyValuePair.Value.Count) + ")";
								myCard.Margin = new Thickness(0.0, 0.0, 0.0, 15.0);
								myCard.CustomizeModel(10);
								MyCard myCard2 = myCard;
								StackPanel stackPanel = new StackPanel
								{
									Margin = new Thickness(20.0, 40.0, 18.0, 0.0),
									VerticalAlignment = VerticalAlignment.Top,
									RenderTransform = new TranslateTransform(0.0, 0.0),
									Tag = keyValuePair.Value
								};
								myCard2.Children.Add(stackPanel);
								myCard2.m_Decorator = stackPanel;
								myCard2.IsSwaped = true;
								this.PanMain.Children.Add(myCard2);
							}
						}
					}
					finally
					{
						Dictionary<string, List<ModDownload.DlLiteLoaderListEntry>>.Enumerator enumerator2;
						((IDisposable)enumerator2).Dispose();
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "可视化版本列表出错", ModBase.LogLevel.Feedback, "出现错误");
				}
			}
		}

		// Token: 0x06000A9F RID: 2719 RVA: 0x000073BA File Offset: 0x000055BA
		public void DownloadStart(MyListItem sender, object e)
		{
			ModDownloadLib.McDownloadLiteLoader((ModDownload.DlLiteLoaderListEntry)sender.Tag);
		}

		// Token: 0x06000AA0 RID: 2720 RVA: 0x0005618C File Offset: 0x0005438C
		private static void DownloadState(ModLoader.LoaderCombo<ModDownload.DlLiteLoaderListEntry> Loader)
		{
			int num;
			int num4;
			object obj;
			try
			{
				IL_00:
				ProjectData.ClearProjectError();
				num = 1;
				IL_07:
				int num2 = 2;
				switch (Loader.State)
				{
				case ModBase.LoadState.Loading:
					IL_A2:
					goto IL_128;
				case ModBase.LoadState.Finished:
					IL_2B:
					num2 = 4;
					ModMain.Hint(Loader.Name + "成功！", ModMain.HintType.Finish, true);
					break;
				case ModBase.LoadState.Failed:
					IL_46:
					num2 = 6;
					ModMain.Hint(Loader.Name + "失败：" + ModBase.GetString(Loader.Error, true, false), ModMain.HintType.Critical, true);
					break;
				case ModBase.LoadState.Aborted:
					IL_6E:
					num2 = 8;
					ModMain.Hint(Loader.Name + "已取消！", ModMain.HintType.Info, true);
					break;
				}
				IL_87:
				num2 = 12;
				ModLoader.LoaderFolderRun(ModMinecraft.threadTag, ModMinecraft._MapperTag, ModLoader.LoaderFolderRunType.ForceRun, 1, "versions\\", false);
				goto IL_A2;
				IL_A7:
				int num3 = num4 + 1;
				num4 = 0;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
				IL_E9:
				goto IL_11D;
				IL_EB:
				num4 = num2;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
				IL_FB:;
			}
			catch when (endfilter(obj is Exception & num != 0 & num4 == 0))
			{
				Exception ex = (Exception)obj2;
				goto IL_EB;
			}
			IL_11D:
			throw ProjectData.CreateProjectError(-2146828237);
			IL_128:
			if (num4 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		// Token: 0x06000AA1 RID: 2721 RVA: 0x000073CC File Offset: 0x000055CC
		private void BtnWeb_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://www.liteloader.com");
		}

		// Token: 0x17000175 RID: 373
		// (get) Token: 0x06000AA2 RID: 2722 RVA: 0x000073D8 File Offset: 0x000055D8
		// (set) Token: 0x06000AA3 RID: 2723 RVA: 0x000073E0 File Offset: 0x000055E0
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x17000176 RID: 374
		// (get) Token: 0x06000AA4 RID: 2724 RVA: 0x000073E9 File Offset: 0x000055E9
		// (set) Token: 0x06000AA5 RID: 2725 RVA: 0x000073F1 File Offset: 0x000055F1
		internal virtual MyCard CardTip { get; set; }

		// Token: 0x17000177 RID: 375
		// (get) Token: 0x06000AA6 RID: 2726 RVA: 0x000073FA File Offset: 0x000055FA
		// (set) Token: 0x06000AA7 RID: 2727 RVA: 0x00007402 File Offset: 0x00005602
		internal virtual TextBlock LabConnect { get; set; }

		// Token: 0x17000178 RID: 376
		// (get) Token: 0x06000AA8 RID: 2728 RVA: 0x0000740B File Offset: 0x0000560B
		// (set) Token: 0x06000AA9 RID: 2729 RVA: 0x000562DC File Offset: 0x000544DC
		internal virtual MyButton BtnWeb
		{
			[CompilerGenerated]
			get
			{
				return this._BtnWeb;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnWeb_Click);
				MyButton btnWeb = this._BtnWeb;
				if (btnWeb != null)
				{
					btnWeb.RevertResolver(obj);
				}
				this._BtnWeb = value;
				btnWeb = this._BtnWeb;
				if (btnWeb != null)
				{
					btnWeb.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000179 RID: 377
		// (get) Token: 0x06000AAA RID: 2730 RVA: 0x00007413 File Offset: 0x00005613
		// (set) Token: 0x06000AAB RID: 2731 RVA: 0x0000741B File Offset: 0x0000561B
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x1700017A RID: 378
		// (get) Token: 0x06000AAC RID: 2732 RVA: 0x00007424 File Offset: 0x00005624
		// (set) Token: 0x06000AAD RID: 2733 RVA: 0x0000742C File Offset: 0x0000562C
		internal virtual MyCard PanLoad { get; set; }

		// Token: 0x1700017B RID: 379
		// (get) Token: 0x06000AAE RID: 2734 RVA: 0x00007435 File Offset: 0x00005635
		// (set) Token: 0x06000AAF RID: 2735 RVA: 0x0000743D File Offset: 0x0000563D
		internal virtual MyLoading Load { get; set; }

		// Token: 0x06000AB0 RID: 2736 RVA: 0x00056320 File Offset: 0x00054520
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this._contentLoaded)
			{
				this._contentLoaded = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagedownload/pagedownloadliteloader.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000AB1 RID: 2737 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000AB2 RID: 2738 RVA: 0x00056350 File Offset: 0x00054550
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.CardTip = (MyCard)target;
				return;
			}
			if (connectionId == 3)
			{
				this.LabConnect = (TextBlock)target;
				return;
			}
			if (connectionId == 4)
			{
				this.BtnWeb = (MyButton)target;
				return;
			}
			if (connectionId == 5)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			if (connectionId == 6)
			{
				this.PanLoad = (MyCard)target;
				return;
			}
			if (connectionId == 7)
			{
				this.Load = (MyLoading)target;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x040005B4 RID: 1460
		private bool _contentLoaded;
	}
}
