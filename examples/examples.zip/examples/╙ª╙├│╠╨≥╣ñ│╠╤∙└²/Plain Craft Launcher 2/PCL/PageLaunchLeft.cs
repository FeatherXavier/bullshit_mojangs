﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200013F RID: 319
	[DesignerGenerated]
	public class PageLaunchLeft : MyPageLeft, IComponentConnector
	{
		// Token: 0x06000C42 RID: 3138 RVA: 0x0005F9B0 File Offset: 0x0005DBB0
		public PageLaunchLeft()
		{
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.PageLaunchLeft_Loaded();
			};
			this.baseComparator = false;
			this._ProductComparator = false;
			this._AttrComparator = PageLaunchLeft.PageType.None;
			this.getterComparator = 0;
			this._ListenerComparator = null;
			this._IdentifierComparator = 0.0;
			this.m_InstanceComparator = false;
			this.objectComparator = false;
			this.InitializeComponent();
		}

		// Token: 0x06000C43 RID: 3139 RVA: 0x0005FA1C File Offset: 0x0005DC1C
		public void PageLaunchLeft_Loaded()
		{
			if (this.baseComparator)
			{
				this.RefreshPage(true, false);
			}
			this.AprilPosTrans.X = 0.0;
			this.AprilPosTrans.Y = 0.0;
			checked
			{
				if (!this.baseComparator)
				{
					this.baseComparator = true;
					ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
					ModMinecraft.threadTag.LoadingStateChanged += delegate(MyLoading.MyLoadingState a0, MyLoading.MyLoadingState a1)
					{
						this.RefreshButtonsUI();
					};
					ModMinecraft._ProcessTag.LoadingStateChanged += delegate(MyLoading.MyLoadingState a0, MyLoading.MyLoadingState a1)
					{
						this.RefreshButtonsUI();
					};
					this.RefreshButtonsUI();
					ModBase.RunInNewThread(delegate
					{
						ModMinecraft._MapperTag = ModBase._ParamsState.Get("LaunchFolderSelect", null).ToString().Replace("$", ModBase.Path);
						if (Operators.CompareString(ModMinecraft._MapperTag, "", true) == 0 || !Directory.Exists(ModMinecraft._MapperTag))
						{
							if (Operators.CompareString(ModMinecraft._MapperTag, "", true) == 0)
							{
								ModBase.Log("[Launch] 没有已储存的 Minecraft 文件夹", ModBase.LogLevel.Normal, "出现错误");
							}
							else
							{
								ModBase.Log("[Launch] Minecraft 文件夹无效：" + ModMinecraft._MapperTag, ModBase.LogLevel.Debug, "出现错误");
							}
							ModMinecraft._ProcessTag.WaitForExit(0, null, false);
							ModBase._ParamsState.Set("LaunchFolderSelect", ModMinecraft._FactoryTag[0].Path.Replace(ModBase.Path, "$"), false, null);
						}
						ModBase.Log("[Launch] Minecraft 文件夹：" + ModMinecraft._MapperTag, ModBase.LogLevel.Normal, "出现错误");
						if (Conversions.ToBoolean(ModBase._ParamsState.Get("SystemDebugDelay", null)))
						{
							Thread.Sleep(ModBase.RandomInteger(500, 3000));
						}
						string text = Conversions.ToString(ModBase._ParamsState.Get("LaunchVersionSelect", null));
						ModMinecraft.McVersion Version;
						if (Operators.CompareString(text, "", true) == 0)
						{
							Version = null;
						}
						else
						{
							Version = new ModMinecraft.McVersion(text);
						}
						if (Information.IsNothing(Version) || !Version.Path.StartsWith(ModMinecraft._MapperTag) || !Version.Check())
						{
							ModBase.Log("[Launch] Minecraft 版本无效" + (Information.IsNothing(Version) ? "，没有有效版本" : ("：" + Version.Path)), Information.IsNothing(Version) ? ModBase.LogLevel.Normal : ModBase.LogLevel.Debug, "出现错误");
							if (ModMinecraft.threadTag.State != ModBase.LoadState.Finished)
							{
								ModLoader.LoaderFolderRun(ModMinecraft.threadTag, ModMinecraft._MapperTag, ModLoader.LoaderFolderRunType.ForceRun, 1, "versions\\", true);
							}
							if (ModMinecraft._OrderTag.Count != 0 && !ModMinecraft._OrderTag.First<KeyValuePair<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>>>().Value[0].registryProccesor.Contains("RedstoneBlock"))
							{
								Version = ModMinecraft._OrderTag.First<KeyValuePair<ModMinecraft.McVersionCardType, List<ModMinecraft.McVersion>>>().Value[0];
								ModBase._ParamsState.Set("LaunchVersionSelect", Version.Name, false, null);
								ModBase.Log("[Launch] 自动选择 Minecraft 版本：" + Version.Path, ModBase.LogLevel.Normal, "出现错误");
							}
							else
							{
								Version = null;
								ModBase._ParamsState.Set("LaunchVersionSelect", "", false, null);
								ModBase.Log("[Launch] 无可用 Minecraft 版本", ModBase.LogLevel.Normal, "出现错误");
							}
						}
						ModBase.RunInUi(delegate()
						{
							ModMinecraft.FindResolver(Version);
							this._ProductComparator = true;
							this.RefreshButtonsUI();
							this.RefreshPage(false, false);
							if (Operators.CompareString(ModLaunch.McLoginAble(), "", true) == 0)
							{
								ModLaunch.m_IndexerTag.Start(null, false);
							}
						}, false);
					}, "Version Check", ThreadPriority.AboveNormal);
					ModLaunch.McLoginType mcLoginType = (ModLaunch.McLoginType)Conversions.ToInteger(ModBase._ParamsState.Get("LoginType", null));
					if (mcLoginType == ModLaunch.McLoginType.Legacy || mcLoginType == ModLaunch.McLoginType.Mojang || mcLoginType == ModLaunch.McLoginType.Ms)
					{
						((MyRadioButton)base.FindName("RadioLoginType" + Conversions.ToString((int)mcLoginType))).Checked = true;
					}
					this.RefreshPage(false, false);
					ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
				}
			}
		}

		// Token: 0x06000C44 RID: 3140 RVA: 0x0005FB20 File Offset: 0x0005DD20
		public void PageChangeToLaunching()
		{
			this.LaunchingPreload();
			this.PanInput.IsHitTestVisible = false;
			this.PanLaunching.IsHitTestVisible = false;
			this.LoadLaunching.State.LoadingState = MyLoading.MyLoadingState.Run;
			this.PanLaunching.Visibility = Visibility.Visible;
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaOpacity(this.PanInput, 0.0, 50, 0, null, false),
				ModAnimation.AaOpacity(this.PanInput, -this.PanInput.Opacity, 110, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), true),
				ModAnimation.AaScaleTransform(this.PanInput, 1.2 - ((ScaleTransform)this.PanInput.RenderTransform).ScaleX, 160, 0, null, false),
				ModAnimation.AaOpacity(this.PanLaunching, 1.0 - this.PanLaunching.Opacity, 150, 100, null, false),
				ModAnimation.AaScaleTransform(this.PanLaunching, 1.0 - ((ScaleTransform)this.PanLaunching.RenderTransform).ScaleX, 500, 100, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Weak), false),
				ModAnimation.AaCode(delegate
				{
					this.PanLaunching.IsHitTestVisible = true;
				}, 150, false)
			}, "Launch State Page", false);
		}

		// Token: 0x06000C45 RID: 3141 RVA: 0x0005FC88 File Offset: 0x0005DE88
		public void PageChangeToLogin()
		{
			NewLateBinding.LateCall(this.PageGet(this._AttrComparator), null, "Reload", new object[]
			{
				false
			}, new string[]
			{
				"KeepInput"
			}, null, null, true);
			this.PanInput.IsHitTestVisible = false;
			this.PanLaunching.IsHitTestVisible = false;
			this.LoadLaunching.State.LoadingState = MyLoading.MyLoadingState.Stop;
			this.PanInput.Visibility = Visibility.Visible;
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaOpacity(this.PanLaunching, -this.PanLaunching.Opacity, 150, 0, null, false),
				ModAnimation.AaScaleTransform(this.PanLaunching, 0.8 - ((ScaleTransform)this.PanLaunching.RenderTransform).ScaleX, 150, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Weak), false),
				ModAnimation.AaOpacity(this.PanInput, 1.0 - this.PanInput.Opacity, 250, 50, null, false),
				ModAnimation.AaScaleTransform(this.PanInput, 1.0 - ((ScaleTransform)this.PanInput.RenderTransform).ScaleX, 300, 50, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Weak), false),
				ModAnimation.AaCode(delegate
				{
					this.PanInput.IsHitTestVisible = true;
				}, 200, false)
			}, "Launch State Page", true);
		}

		// Token: 0x06000C46 RID: 3142 RVA: 0x0005FE04 File Offset: 0x0005E004
		private object PageGet(PageLaunchLeft.PageType Type)
		{
			object result;
			switch (Type)
			{
			case PageLaunchLeft.PageType.Mojang:
				if (Information.IsNothing(ModMain._ServerAccount))
				{
					ModMain._ServerAccount = new PageLoginMojang();
				}
				result = ModMain._ServerAccount;
				break;
			case PageLaunchLeft.PageType.MojangSkin:
				if (Information.IsNothing(ModMain.serviceAccount))
				{
					ModMain.serviceAccount = new PageLoginMojangSkin();
				}
				result = ModMain.serviceAccount;
				break;
			case PageLaunchLeft.PageType.Legacy:
				if (Information.IsNothing(ModMain._ImporterAccount))
				{
					ModMain._ImporterAccount = new PageLoginLegacy();
				}
				result = ModMain._ImporterAccount;
				break;
			case PageLaunchLeft.PageType.Nide:
				if (Information.IsNothing(ModMain._ProxyAccount))
				{
					ModMain._ProxyAccount = new PageLoginNide();
				}
				result = ModMain._ProxyAccount;
				break;
			case PageLaunchLeft.PageType.NideSkin:
				if (Information.IsNothing(ModMain._ClassAccount))
				{
					ModMain._ClassAccount = new PageLoginNideSkin();
				}
				result = ModMain._ClassAccount;
				break;
			case PageLaunchLeft.PageType.Auth:
				if (Information.IsNothing(ModMain.m_RegistryAccount))
				{
					ModMain.m_RegistryAccount = new PageLoginAuth();
				}
				result = ModMain.m_RegistryAccount;
				break;
			case PageLaunchLeft.PageType.AuthSkin:
				if (Information.IsNothing(ModMain.m_ProducerAccount))
				{
					ModMain.m_ProducerAccount = new PageLoginAuthSkin();
				}
				result = ModMain.m_ProducerAccount;
				break;
			case PageLaunchLeft.PageType.Ms:
				if (Information.IsNothing(ModMain.candidateAccount))
				{
					ModMain.candidateAccount = new PageLoginMs();
				}
				result = ModMain.candidateAccount;
				break;
			case PageLaunchLeft.PageType.MsSkin:
				if (Information.IsNothing(ModMain._SetterAccount))
				{
					ModMain._SetterAccount = new PageLoginMsSkin();
				}
				result = ModMain._SetterAccount;
				break;
			default:
				throw new ArgumentOutOfRangeException("Type", "即将切换的登录分页编号越界");
			}
			return result;
		}

		// Token: 0x06000C47 RID: 3143 RVA: 0x0005FF68 File Offset: 0x0005E168
		private object PageChange(PageLaunchLeft.PageType Type, bool Anim)
		{
			PageLoginMojang PageNew = ModMain._ServerAccount;
			checked
			{
				object $VB$Local_PageNew;
				try
				{
					if (this._AttrComparator == Type)
					{
						$VB$Local_PageNew = PageNew;
					}
					else
					{
						PageNew = RuntimeHelpers.GetObjectValue(this.PageGet(Type));
						ModAnimation.AniStop("FrmLogin PageChange");
						if (!Information.IsNothing(RuntimeHelpers.GetObjectValue(PageNew)) && !Information.IsNothing(RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(PageNew, null, "Parent", new object[0], null, null, null))))
						{
							object $VB$Local_PageNew2 = PageNew;
							Type type = null;
							string memberName = "SetValue";
							object[] array = new object[2];
							array[0] = ContentPresenter.ContentProperty;
							NewLateBinding.LateCall($VB$Local_PageNew2, type, memberName, array, null, null, null, true);
						}
						if (Anim)
						{
							ThreadStart $I1;
							base.Dispatcher.Invoke(delegate()
							{
								ModAnimation.AniStart(new ModAnimation.AniData[]
								{
									ModAnimation.AaOpacity(this.PanLogin, unchecked(-this.PanLogin.Opacity), 100, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
									ModAnimation.AaCode(($I1 == null) ? ($I1 = delegate()
									{
										ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
										this.PanLogin.Children.Clear();
										this.PanLogin.Children.Add((UIElement)PageNew);
										ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
									}) : $I1, 100, false),
									ModAnimation.AaOpacity(this.PanLogin, 1.0, 100, 120, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false)
								}, "FrmLogin PageChange", false);
							}, DispatcherPriority.Render);
						}
						else
						{
							ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
							this.PanLogin.Children.Clear();
							this.PanLogin.Children.Add((UIElement)PageNew);
							ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
						}
						this._AttrComparator = Type;
						$VB$Local_PageNew = PageNew;
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "切换登录分页失败（" + ModBase.GetStringFromEnum(Type) + "）", ModBase.LogLevel.Feedback, "出现错误");
					$VB$Local_PageNew = PageNew;
				}
				return $VB$Local_PageNew;
			}
		}

		// Token: 0x06000C48 RID: 3144 RVA: 0x000600D8 File Offset: 0x0005E2D8
		public void RefreshPage(bool KeepInput, bool Anim)
		{
			int num;
			if (ModMinecraft.SetupResolver() != null)
			{
				num = Conversions.ToInteger(ModBase._ParamsState.Get("VersionServerLogin", ModMinecraft.SetupResolver()));
				ModBase._ParamsState.Set("LoginPageType", num, false, null);
			}
			else
			{
				num = Conversions.ToInteger(ModBase._ParamsState.Get("LoginPageType", null));
			}
			PageLaunchLeft.PageType pageType;
			switch (num)
			{
			case 0:
				break;
			case 1:
				if (this.RadioLoginType5.Checked)
				{
					if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("CacheMsAccess", null), "", true))
					{
						pageType = PageLaunchLeft.PageType.Ms;
					}
					else
					{
						pageType = PageLaunchLeft.PageType.MsSkin;
					}
					ModBase._ParamsState.Set("LoginType", ModLaunch.McLoginType.Ms, false, null);
				}
				else
				{
					if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("CacheMojangAccess", null), "", true))
					{
						pageType = PageLaunchLeft.PageType.Mojang;
					}
					else
					{
						pageType = PageLaunchLeft.PageType.MojangSkin;
					}
					ModBase._ParamsState.Set("LoginType", ModLaunch.McLoginType.Mojang, false, null);
				}
				this.PanType.Visibility = Visibility.Visible;
				this.PanTypeOne.Visibility = Visibility.Collapsed;
				this.RadioLoginType1.Visibility = Visibility.Visible;
				this.RadioLoginType5.Visibility = Visibility.Visible;
				this.RadioLoginType0.Visibility = Visibility.Collapsed;
				goto IL_3F8;
			case 2:
				pageType = PageLaunchLeft.PageType.Legacy;
				ModBase._ParamsState.Set("LoginType", ModLaunch.McLoginType.Legacy, false, null);
				this.PanType.Visibility = Visibility.Collapsed;
				this.PanTypeOne.Visibility = Visibility.Visible;
				this.PathTypeOne.Data = (Geometry)new GeometryConverter().ConvertFromString("M660.338 528.065c63.61-46.825 105.131-121.964 105.131-206.83 0-141.7-115.29-256.987-256.997-256.987-141.706 0-256.998 115.288-256.998 256.987 0 85.901 42.52 161.887 107.456 208.562-152.1 59.92-260.185 207.961-260.185 381.077 0 21.276 17.253 38.53 38.53 38.53 21.278 0 38.53-17.254 38.53-38.53 0-183.426 149.232-332.671 332.667-332.671 1.589 0 3.113-0.207 4.694-0.244 0.8 0.056 1.553 0.244 2.362 0.244 183.434 0 332.664 149.245 332.664 332.671 0 21.276 17.255 38.53 38.533 38.53 21.277 0 38.53-17.254 38.53-38.53 0-174.885-110.354-324.13-264.917-382.809z m-331.803-206.83c0-99.22 80.72-179.927 179.935-179.927s179.937 80.708 179.937 179.927c0 99.203-80.721 179.91-179.937 179.91s-179.935-80.708-179.935-179.91z");
				this.LabTypeOne.Text = "离线登录";
				goto IL_3F8;
			case 3:
				if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("CacheNideAccess", null), "", true))
				{
					pageType = PageLaunchLeft.PageType.Nide;
				}
				else
				{
					pageType = PageLaunchLeft.PageType.NideSkin;
				}
				ModBase._ParamsState.Set("LoginType", ModLaunch.McLoginType.Nide, false, null);
				this.PanType.Visibility = Visibility.Collapsed;
				this.PanTypeOne.Visibility = Visibility.Visible;
				this.PathTypeOne.Data = (Geometry)new GeometryConverter().ConvertFromString("M834.5 684.1c-31.2-70.4-98.9-120.9-179.1-127.3 63.5-8.5 112.6-63 112.6-128.8 0-71.8-58.2-130-130-130s-130 58.2-130 130c0 65.9 49 120.3 112.6 128.8-80.2 6.4-148 57-179.1 127.3-8.7 19.7 6 42 27.6 42 12.1 0 22.7-7.5 27.7-18.5 24.3-53.9 78.5-91.5 141.3-91.5s117 37.6 141.3 91.5c5 11.1 15.6 18.5 27.7 18.5 21.4 0 36.1-22.3 27.4-42zM567.9 427.9c0-38.6 31.4-70 70-70s70 31.4 70 70-31.4 70-70 70-70-31.4-70-70zM460.3 347.9H216.9c-16.6 0-30 13.4-30 30s13.4 30 30 30h243.3c16.6 0 30-13.4 30-30 0.1-16.5-13.4-30-29.9-30zM367.4 459.6H216.9c-16.6 0-30 13.4-30 30s13.4 30 30 30h150.4c16.6 0 30-13.4 30-30 0.1-16.6-13.4-30-29.9-30zM297.4 571.2H217c-16.6 0-30 13.4-30 30s13.4 30 30 30h80.4c16.6 0 30-13.4 30-30 0-16.5-13.5-30-30-30zM900 236v552H124V236h776m0-60H124c-33.1 0-60 26.9-60 60v552c0 33.1 26.9 60 60 60h776c33.1 0 60-26.9 60-60V236c0-33.1-26.9-60-60-60z");
				this.LabTypeOne.Text = "统一通行证登录";
				goto IL_3F8;
			case 4:
				if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("CacheAuthAccess", null), "", true))
				{
					pageType = PageLaunchLeft.PageType.Auth;
				}
				else
				{
					pageType = PageLaunchLeft.PageType.AuthSkin;
				}
				ModBase._ParamsState.Set("LoginType", ModLaunch.McLoginType.Auth, false, null);
				this.PanType.Visibility = Visibility.Collapsed;
				this.PanTypeOne.Visibility = Visibility.Visible;
				this.PathTypeOne.Data = (Geometry)new GeometryConverter().ConvertFromString("M834.5 684.1c-31.2-70.4-98.9-120.9-179.1-127.3 63.5-8.5 112.6-63 112.6-128.8 0-71.8-58.2-130-130-130s-130 58.2-130 130c0 65.9 49 120.3 112.6 128.8-80.2 6.4-148 57-179.1 127.3-8.7 19.7 6 42 27.6 42 12.1 0 22.7-7.5 27.7-18.5 24.3-53.9 78.5-91.5 141.3-91.5s117 37.6 141.3 91.5c5 11.1 15.6 18.5 27.7 18.5 21.4 0 36.1-22.3 27.4-42zM567.9 427.9c0-38.6 31.4-70 70-70s70 31.4 70 70-31.4 70-70 70-70-31.4-70-70zM460.3 347.9H216.9c-16.6 0-30 13.4-30 30s13.4 30 30 30h243.3c16.6 0 30-13.4 30-30 0.1-16.5-13.4-30-29.9-30zM367.4 459.6H216.9c-16.6 0-30 13.4-30 30s13.4 30 30 30h150.4c16.6 0 30-13.4 30-30 0.1-16.6-13.4-30-29.9-30zM297.4 571.2H217c-16.6 0-30 13.4-30 30s13.4 30 30 30h80.4c16.6 0 30-13.4 30-30 0-16.5-13.5-30-30-30zM900 236v552H124V236h776m0-60H124c-33.1 0-60 26.9-60 60v552c0 33.1 26.9 60 60 60h776c33.1 0 60-26.9 60-60V236c0-33.1-26.9-60-60-60z");
				this.LabTypeOne.Text = Conversions.ToString((ModMinecraft.SetupResolver() == null) ? ModBase._ParamsState.Get("CacheAuthServerName", null) : ModBase._ParamsState.Get("VersionServerAuthName", ModMinecraft.SetupResolver()));
				if (Operators.CompareString(this.LabTypeOne.Text, "", true) == 0)
				{
					this.LabTypeOne.Text = "第三方登录";
					goto IL_3F8;
				}
				goto IL_3F8;
			default:
				ModBase.Log("[Control] 未知的登录页面：" + Conversions.ToString(num), ModBase.LogLevel.Hint, "出现错误");
				break;
			}
			if (this.RadioLoginType1.Checked)
			{
				if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("CacheMojangAccess", null), "", true))
				{
					pageType = PageLaunchLeft.PageType.Mojang;
				}
				else
				{
					pageType = PageLaunchLeft.PageType.MojangSkin;
				}
				ModBase._ParamsState.Set("LoginType", ModLaunch.McLoginType.Mojang, false, null);
			}
			else if (this.RadioLoginType5.Checked)
			{
				if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("CacheMsAccess", null), "", true))
				{
					pageType = PageLaunchLeft.PageType.Ms;
				}
				else
				{
					pageType = PageLaunchLeft.PageType.MsSkin;
				}
				ModBase._ParamsState.Set("LoginType", ModLaunch.McLoginType.Ms, false, null);
			}
			else
			{
				pageType = PageLaunchLeft.PageType.Legacy;
				ModBase._ParamsState.Set("LoginType", ModLaunch.McLoginType.Legacy, false, null);
			}
			this.PanType.Visibility = Visibility.Visible;
			this.PanTypeOne.Visibility = Visibility.Collapsed;
			this.RadioLoginType1.Visibility = Visibility.Visible;
			this.RadioLoginType5.Visibility = Visibility.Visible;
			this.RadioLoginType0.Visibility = Visibility.Visible;
			IL_3F8:
			if (this._AttrComparator != pageType)
			{
				object[] array;
				bool[] array2;
				NewLateBinding.LateCall(this.PageChange(pageType, Anim), null, "Reload", array = new object[]
				{
					KeepInput
				}, null, null, array2 = new bool[]
				{
					true
				}, true);
				if (array2[0])
				{
					KeepInput = (bool)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array[0]), typeof(bool));
				}
				MyRadioButton myRadioButton = (MyRadioButton)base.FindName(Conversions.ToString(Operators.ConcatenateObject("RadioLoginType", ModBase._ParamsState.Get("LoginType", null))));
				if (myRadioButton != null)
				{
					myRadioButton.Checked = true;
				}
			}
		}

		// Token: 0x06000C49 RID: 3145 RVA: 0x00008191 File Offset: 0x00006391
		private void RadioLoginType_Change(object sender, bool raiseByMouse)
		{
			if (raiseByMouse)
			{
				this.RefreshPage(true, true);
			}
		}

		// Token: 0x06000C4A RID: 3146 RVA: 0x0000819E File Offset: 0x0000639E
		private static ModBase.EqualableList<string> SkinMojangInput()
		{
			return new ModBase.EqualableList<string>
			{
				Conversions.ToString(ModBase._ParamsState.Get("CacheMojangName", null)),
				Conversions.ToString(ModBase._ParamsState.Get("CacheMojangUuid", null))
			};
		}

		// Token: 0x06000C4B RID: 3147 RVA: 0x00060578 File Offset: 0x0005E778
		private static void SkinMojangLoad(ModLoader.LoaderTask<ModBase.EqualableList<string>, string> Data)
		{
			ModBase.RunInUi((PageLaunchLeft._Closure$__.$I15-0 == null) ? (PageLaunchLeft._Closure$__.$I15-0 = delegate()
			{
				if (ModMain.serviceAccount != null && ModMain.serviceAccount.Skin != null)
				{
					ModMain.serviceAccount.Skin.Clear();
				}
			}) : PageLaunchLeft._Closure$__.$I15-0, false);
			string text = Data.Input[0];
			string uuid = Data.Input[1];
			if (Operators.CompareString(text, "", true) == 0)
			{
				Data.Output = ModBase._TokenizerState + "Skins/" + ModMinecraft.McSkinSex(Conversions.ToString(ModLaunch.McLoginLegacyUuid(text))) + ".png";
				ModBase.Log("[Minecraft] 获取正版皮肤失败，ID 为空", ModBase.LogLevel.Normal, "出现错误");
			}
			else
			{
				try
				{
					string text2 = ModMinecraft.McSkinGetAddress(uuid, "Mojang");
					if (Data.IsAborted)
					{
						throw new ThreadInterruptedException("当前任务已取消：" + text);
					}
					text2 = ModMinecraft.McSkinDownload(text2);
					if (Data.IsAborted)
					{
						throw new ThreadInterruptedException("当前任务已取消：" + text);
					}
					Data.Output = text2;
				}
				catch (Exception ex)
				{
					if (Operators.CompareString(ex.GetType().Name, "ThreadInterruptedException", true) == 0)
					{
						Data.Output = "";
						return;
					}
					if (ModBase.GetString(ex, true, false).Contains("429"))
					{
						Data.Output = ModBase._TokenizerState + "Skins/" + ModMinecraft.McSkinSex(Conversions.ToString(ModLaunch.McLoginLegacyUuid(text))) + ".png";
						ModBase.Log("[Minecraft] 获取正版皮肤失败（" + text + "）：获取皮肤太过频繁，请 5 分钟后再试！", ModBase.LogLevel.Hint, "出现错误");
					}
					else if (ModBase.GetString(ex, true, false).Contains("可能是未设置自定义皮肤的用户"))
					{
						Data.Output = ModBase._TokenizerState + "Skins/" + ModMinecraft.McSkinSex(Conversions.ToString(ModLaunch.McLoginLegacyUuid(text))) + ".png";
						ModBase.Log("[Minecraft] 用户未设置自定义皮肤，跳过皮肤加载", ModBase.LogLevel.Normal, "出现错误");
					}
					else
					{
						Data.Output = ModBase._TokenizerState + "Skins/" + ModMinecraft.McSkinSex(Conversions.ToString(ModLaunch.McLoginLegacyUuid(text))) + ".png";
						ModBase.Log(ex, "获取正版皮肤失败（" + text + "）", ModBase.LogLevel.Hint, "出现错误");
					}
				}
			}
			if (ModMain.serviceAccount != null)
			{
				ModBase.RunInUi(new Action(ModMain.serviceAccount.Skin.Load), false);
				return;
			}
			if (!Data.IsAborted)
			{
				Data.Input = null;
			}
		}

		// Token: 0x06000C4C RID: 3148 RVA: 0x000081DB File Offset: 0x000063DB
		private static ModBase.EqualableList<string> SkinMsInput()
		{
			return new ModBase.EqualableList<string>
			{
				Conversions.ToString(ModBase._ParamsState.Get("CacheMsName", null)),
				Conversions.ToString(ModBase._ParamsState.Get("CacheMsUuid", null))
			};
		}

		// Token: 0x06000C4D RID: 3149 RVA: 0x000607E8 File Offset: 0x0005E9E8
		private static void SkinMsLoad(ModLoader.LoaderTask<ModBase.EqualableList<string>, string> Data)
		{
			ModBase.RunInUi((PageLaunchLeft._Closure$__.$I18-0 == null) ? (PageLaunchLeft._Closure$__.$I18-0 = delegate()
			{
				if (ModMain._SetterAccount != null && ModMain._SetterAccount.Skin != null)
				{
					ModMain._SetterAccount.Skin.Clear();
				}
			}) : PageLaunchLeft._Closure$__.$I18-0, false);
			string text = Data.Input[0];
			string uuid = Data.Input[1];
			if (Operators.CompareString(text, "", true) == 0)
			{
				Data.Output = ModBase._TokenizerState + "Skins/" + ModMinecraft.McSkinSex(Conversions.ToString(ModLaunch.McLoginLegacyUuid(text))) + ".png";
				ModBase.Log("[Minecraft] 获取微软正版皮肤失败，ID 为空", ModBase.LogLevel.Normal, "出现错误");
			}
			else
			{
				try
				{
					string text2 = ModMinecraft.McSkinGetAddress(uuid, "Ms");
					if (Data.IsAborted)
					{
						throw new ThreadInterruptedException("当前任务已取消：" + text);
					}
					text2 = ModMinecraft.McSkinDownload(text2);
					if (Data.IsAborted)
					{
						throw new ThreadInterruptedException("当前任务已取消：" + text);
					}
					Data.Output = text2;
				}
				catch (Exception ex)
				{
					if (Operators.CompareString(ex.GetType().Name, "ThreadInterruptedException", true) == 0)
					{
						Data.Output = "";
						return;
					}
					if (ModBase.GetString(ex, true, false).Contains("429"))
					{
						Data.Output = ModBase._TokenizerState + "Skins/" + ModMinecraft.McSkinSex(Conversions.ToString(ModLaunch.McLoginLegacyUuid(text))) + ".png";
						ModBase.Log("[Minecraft] 获取正版皮肤失败（" + text + "）：获取皮肤太过频繁，请 5 分钟后再试！", ModBase.LogLevel.Hint, "出现错误");
					}
					else if (ModBase.GetString(ex, true, false).Contains("可能是未设置自定义皮肤的用户"))
					{
						Data.Output = ModBase._TokenizerState + "Skins/" + ModMinecraft.McSkinSex(Conversions.ToString(ModLaunch.McLoginLegacyUuid(text))) + ".png";
						ModBase.Log("[Minecraft] 用户未设置自定义皮肤，跳过皮肤加载", ModBase.LogLevel.Normal, "出现错误");
					}
					else
					{
						Data.Output = ModBase._TokenizerState + "Skins/" + ModMinecraft.McSkinSex(Conversions.ToString(ModLaunch.McLoginLegacyUuid(text))) + ".png";
						ModBase.Log(ex, "获取微软正版皮肤失败（" + text + "）", ModBase.LogLevel.Hint, "出现错误");
					}
				}
			}
			if (ModMain._SetterAccount != null)
			{
				ModBase.RunInUi(new Action(ModMain._SetterAccount.Skin.Load), false);
				return;
			}
			if (!Data.IsAborted)
			{
				Data.Input = null;
			}
		}

		// Token: 0x06000C4E RID: 3150 RVA: 0x00060A58 File Offset: 0x0005EC58
		private static ModBase.EqualableList<string> SkinLegacyInput()
		{
			int num = Conversions.ToInteger(ModBase._ParamsState.Get("LaunchSkinType", null));
			ModBase.EqualableList<string> result;
			if (num != 0)
			{
				if (num != 3)
				{
					result = new ModBase.EqualableList<string>
					{
						Conversions.ToString(num)
					};
				}
				else
				{
					result = new ModBase.EqualableList<string>
					{
						Conversions.ToString(3),
						Conversions.ToString(ModBase._ParamsState.Get("LaunchSkinID", null))
					};
				}
			}
			else if (ModMain._ImporterAccount != null && ModMain._ImporterAccount.definitionComparator)
			{
				result = new ModBase.EqualableList<string>
				{
					Conversions.ToString(0),
					ModMain._ImporterAccount.ComboName.Text ?? ""
				};
			}
			else if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LoginLegacyName", null), "", true))
			{
				result = new ModBase.EqualableList<string>
				{
					Conversions.ToString(0),
					""
				};
			}
			else
			{
				result = new ModBase.EqualableList<string>
				{
					Conversions.ToString(0),
					ModBase._ParamsState.Get("LoginLegacyName", null).ToString().Split(new char[]
					{
						'¨'
					})[0] ?? ""
				};
			}
			return result;
		}

		// Token: 0x06000C4F RID: 3151 RVA: 0x00060BA0 File Offset: 0x0005EDA0
		private static void SkinLegacyLoad(ModLoader.LoaderTask<ModBase.EqualableList<string>, string> Data)
		{
			ModBase.RunInUi((PageLaunchLeft._Closure$__.$I21-0 == null) ? (PageLaunchLeft._Closure$__.$I21-0 = delegate()
			{
				if (ModMain._ImporterAccount != null && ModMain._ImporterAccount.Skin != null)
				{
					ModMain._ImporterAccount.Skin.Clear();
				}
			}) : PageLaunchLeft._Closure$__.$I21-0, false);
			string left = Data.Input[0];
			if (Operators.CompareString(left, Conversions.ToString(0), true) == 0)
			{
				Data.Output = ModBase._TokenizerState + "Skins/" + ModMinecraft.McSkinSex(Conversions.ToString(ModLaunch.McLoginLegacyUuid(Data.Input[1]))) + ".png";
			}
			else
			{
				if (Operators.CompareString(left, Conversions.ToString(1), true) != 0)
				{
					if (Operators.CompareString(left, Conversions.ToString(2), true) == 0)
					{
						Data.Output = ModBase._TokenizerState + "Skins/Alex.png";
						goto IL_2C3;
					}
					if (Operators.CompareString(left, Conversions.ToString(3), true) == 0)
					{
						string text = Data.Input[1];
						try
						{
							if (text.Count<char>() < 2)
							{
								Data.Output = ModBase._TokenizerState + "Skins/Steve.png";
							}
							else
							{
								string text2 = Conversions.ToString(ModLaunch.McLoginMojangUuid(text, true));
								if (Data.IsAborted)
								{
									throw new ThreadInterruptedException("当前任务已取消：" + text);
								}
								text2 = ModMinecraft.McSkinGetAddress(text2, "Mojang");
								if (Data.IsAborted)
								{
									throw new ThreadInterruptedException("当前任务已取消：" + text);
								}
								text2 = ModMinecraft.McSkinDownload(text2);
								if (Data.IsAborted)
								{
									throw new ThreadInterruptedException("当前任务已取消：" + text);
								}
								Data.Output = text2;
							}
							goto IL_2C3;
						}
						catch (Exception ex)
						{
							if (Operators.CompareString(ex.GetType().Name, "ThreadInterruptedException", true) == 0)
							{
								Data.Output = "";
								return;
							}
							if (ModBase.GetString(ex, true, false).Contains("429"))
							{
								Data.Output = ModBase._TokenizerState + "Skins/" + ModMinecraft.McSkinSex(Conversions.ToString(ModLaunch.McLoginLegacyUuid(text))) + ".png";
								ModBase.Log("获取离线登录使用的正版皮肤失败（" + text + "）：获取皮肤太过频繁，请 5 分钟后再试！", ModBase.LogLevel.Normal, "出现错误");
							}
							else
							{
								Data.Output = ModBase._TokenizerState + "Skins/" + ModMinecraft.McSkinSex(Conversions.ToString(ModLaunch.McLoginLegacyUuid(text))) + ".png";
								ModBase.Log(ex, "获取离线登录使用的正版皮肤失败（" + text + "）", ModBase.LogLevel.Debug, "出现错误");
							}
							goto IL_2C3;
						}
					}
					if (Operators.CompareString(left, Conversions.ToString(4), true) != 0)
					{
						goto IL_2C3;
					}
					if (File.Exists(ModBase.attributeState + "CustomSkin.png"))
					{
						Data.Output = ModBase.attributeState + "CustomSkin.png";
						goto IL_2C3;
					}
					ModMain.Hint("未找到离线皮肤自定义文件，可能它已被删除。PCL2 将使用默认的 Steve 皮肤！", ModMain.HintType.Info, true);
					ModBase._ParamsState.Set("LaunchSkinType", 1, false, null);
				}
				Data.Output = ModBase._TokenizerState + "Skins/Steve.png";
			}
			IL_2C3:
			if (ModMain._ImporterAccount != null)
			{
				ModBase.RunInUi(new Action(ModMain._ImporterAccount.Skin.Load), false);
				return;
			}
			if (!Data.IsAborted)
			{
				Data.Input = null;
			}
		}

		// Token: 0x06000C50 RID: 3152 RVA: 0x00008218 File Offset: 0x00006418
		private static ModBase.EqualableList<string> SkinNideInput()
		{
			return new ModBase.EqualableList<string>
			{
				Conversions.ToString(ModBase._ParamsState.Get("CacheNideName", null)),
				Conversions.ToString(ModBase._ParamsState.Get("CacheNideUuid", null))
			};
		}

		// Token: 0x06000C51 RID: 3153 RVA: 0x00060EB4 File Offset: 0x0005F0B4
		private static void SkinNideLoad(ModLoader.LoaderTask<ModBase.EqualableList<string>, string> Data)
		{
			ModBase.RunInUi((PageLaunchLeft._Closure$__.$I24-0 == null) ? (PageLaunchLeft._Closure$__.$I24-0 = delegate()
			{
				if (ModMain._ClassAccount != null && ModMain._ClassAccount.Skin != null)
				{
					ModMain._ClassAccount.Skin.Clear();
				}
			}) : PageLaunchLeft._Closure$__.$I24-0, false);
			string text = Data.Input[0];
			string uuid = Data.Input[1];
			if (Operators.CompareString(text, "", true) == 0)
			{
				Data.Output = ModBase._TokenizerState + "Skins/" + ModMinecraft.McSkinSex(Conversions.ToString(ModLaunch.McLoginLegacyUuid(text))) + ".png";
				ModBase.Log("[Minecraft] 获取统一通行证皮肤失败，ID 为空", ModBase.LogLevel.Normal, "出现错误");
			}
			else
			{
				try
				{
					string text2 = ModMinecraft.McSkinGetAddress(uuid, "Nide");
					if (Data.IsAborted)
					{
						throw new ThreadInterruptedException("当前任务已取消：" + text);
					}
					text2 = ModMinecraft.McSkinDownload(text2);
					if (Data.IsAborted)
					{
						throw new ThreadInterruptedException("当前任务已取消：" + text);
					}
					Data.Output = text2;
				}
				catch (Exception ex)
				{
					if (Operators.CompareString(ex.GetType().Name, "ThreadInterruptedException", true) == 0)
					{
						Data.Output = "";
						return;
					}
					if (ModBase.GetString(ex, true, false).Contains("429"))
					{
						Data.Output = ModBase._TokenizerState + "Skins/Steve.png";
						ModBase.Log("[Minecraft] 获取统一通行证皮肤失败（" + text + "）：获取皮肤太过频繁，请 5 分钟后再试！", ModBase.LogLevel.Hint, "出现错误");
					}
					else if (ModBase.GetString(ex, true, false).Contains("可能是未设置自定义皮肤的用户"))
					{
						Data.Output = ModBase._TokenizerState + "Skins/Steve.png";
						ModBase.Log("[Minecraft] 用户未设置自定义皮肤，跳过皮肤加载", ModBase.LogLevel.Normal, "出现错误");
					}
					else
					{
						Data.Output = ModBase._TokenizerState + "Skins/Steve.png";
						ModBase.Log(ex, "获取统一通行证皮肤失败（" + text + "）", ModBase.LogLevel.Hint, "出现错误");
					}
				}
			}
			if (ModMain._ClassAccount != null)
			{
				ModBase.RunInUi(new Action(ModMain._ClassAccount.Skin.Load), false);
				return;
			}
			if (!Data.IsAborted)
			{
				Data.Input = null;
			}
		}

		// Token: 0x06000C52 RID: 3154 RVA: 0x00008255 File Offset: 0x00006455
		private static ModBase.EqualableList<string> SkinAuthInput()
		{
			return new ModBase.EqualableList<string>
			{
				Conversions.ToString(ModBase._ParamsState.Get("CacheAuthName", null)),
				Conversions.ToString(ModBase._ParamsState.Get("CacheAuthUuid", null))
			};
		}

		// Token: 0x06000C53 RID: 3155 RVA: 0x000610D4 File Offset: 0x0005F2D4
		private static void SkinAuthLoad(ModLoader.LoaderTask<ModBase.EqualableList<string>, string> Data)
		{
			ModBase.RunInUi((PageLaunchLeft._Closure$__.$I27-0 == null) ? (PageLaunchLeft._Closure$__.$I27-0 = delegate()
			{
				if (ModMain.m_ProducerAccount != null && ModMain.m_ProducerAccount.Skin != null)
				{
					ModMain.m_ProducerAccount.Skin.Clear();
				}
			}) : PageLaunchLeft._Closure$__.$I27-0, false);
			string text = Data.Input[0];
			string uuid = Data.Input[1];
			if (Operators.CompareString(text, "", true) == 0)
			{
				Data.Output = ModBase._TokenizerState + "Skins/Steve.png";
				ModBase.Log("[Minecraft] 获取 Authlib-Injector 皮肤失败，ID 为空", ModBase.LogLevel.Normal, "出现错误");
			}
			else
			{
				try
				{
					string text2 = ModMinecraft.McSkinGetAddress(uuid, "Auth");
					if (Data.IsAborted)
					{
						throw new ThreadInterruptedException("当前任务已取消：" + text);
					}
					text2 = ModMinecraft.McSkinDownload(text2);
					if (Data.IsAborted)
					{
						throw new ThreadInterruptedException("当前任务已取消：" + text);
					}
					Data.Output = text2;
				}
				catch (Exception ex)
				{
					if (Operators.CompareString(ex.GetType().Name, "ThreadInterruptedException", true) == 0)
					{
						Data.Output = "";
						return;
					}
					if (ModBase.GetString(ex, true, false).Contains("429"))
					{
						Data.Output = ModBase._TokenizerState + "Skins/Steve.png";
						ModBase.Log("[Minecraft] 获取 Authlib-Injector 皮肤失败（" + text + "）：获取皮肤太过频繁，请 5 分钟后再试！", ModBase.LogLevel.Hint, "出现错误");
					}
					else if (ModBase.GetString(ex, true, false).Contains("可能是未设置自定义皮肤的用户"))
					{
						Data.Output = ModBase._TokenizerState + "Skins/Steve.png";
						ModBase.Log("[Minecraft] 用户未设置自定义皮肤，跳过皮肤加载", ModBase.LogLevel.Normal, "出现错误");
					}
					else
					{
						Data.Output = ModBase._TokenizerState + "Skins/Steve.png";
						ModBase.Log(ex, "获取 Authlib-Injector 皮肤失败（" + text + "）", ModBase.LogLevel.Hint, "出现错误");
					}
				}
			}
			if (ModMain.m_ProducerAccount != null)
			{
				ModBase.RunInUi(new Action(ModMain.m_ProducerAccount.Skin.Load), false);
				return;
			}
			if (!Data.IsAborted)
			{
				Data.Input = null;
			}
		}

		// Token: 0x06000C54 RID: 3156 RVA: 0x00008292 File Offset: 0x00006492
		private void BtnVersion_Click(object sender, EventArgs e)
		{
			ModMain.m_CollectionAccount.PageChange(FormMain.PageType.VersionSelect, FormMain.PageSubType.Default);
		}

		// Token: 0x06000C55 RID: 3157 RVA: 0x000082A5 File Offset: 0x000064A5
		private void BtnLaunch_Click()
		{
			this.LaunchButtonClick("");
		}

		// Token: 0x06000C56 RID: 3158 RVA: 0x000612E0 File Offset: 0x0005F4E0
		public void LaunchButtonClick(string ServerIp = "")
		{
			if (this.BtnLaunch.IsEnabled && this.BtnLaunch.Visibility == Visibility.Visible && this.BtnLaunch.IsHitTestVisible)
			{
				if (Operators.CompareString(this.BtnLaunch.Text, "启动游戏", true) == 0)
				{
					ModLaunch._AttrTag.Start(ServerIp, false);
				}
				else if (Operators.CompareString(this.BtnLaunch.Text, "下载游戏", true) == 0)
				{
					ModMain.m_CollectionAccount.PageChange(FormMain.PageType.Download, FormMain.PageSubType.DownloadInstall);
				}
				if (ModMain.m_ComparatorState && !ModMain.m_PrototypeState)
				{
					ModMain.ThemeUnlock(12, false, "隐藏主题 滑稽彩 已解锁！");
					ModMain.m_PrototypeState = true;
					ModMain._FilterAccount.AprilScaleTrans.ScaleX = 1.0;
					ModMain._FilterAccount.AprilScaleTrans.ScaleY = 1.0;
					ModMain.m_CollectionAccount.BtnExtraApril.ShowRefresh();
				}
			}
		}

		// Token: 0x06000C57 RID: 3159 RVA: 0x000613D0 File Offset: 0x0005F5D0
		public void RefreshButtonsUI()
		{
			if (this.BtnLaunch.IsLoaded)
			{
				int num;
				if (this._ProductComparator && ModMinecraft.threadTag.State != ModBase.LoadState.Loading)
				{
					if (ModMinecraft._ProcessTag.State != ModBase.LoadState.Loading)
					{
						if (ModMinecraft.SetupResolver() != null)
						{
							num = 3;
							goto IL_78;
						}
						if (Conversions.ToBoolean(Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenPageDownload", null)) && !PageSetupUI.AwakeResolver()))
						{
							num = 1;
							goto IL_78;
						}
						num = 2;
						goto IL_78;
					}
				}
				num = 0;
				IL_78:
				if (num != this.getterComparator || Operators.CompareString((ModMinecraft.SetupResolver() == null) ? "" : ModMinecraft.SetupResolver().Path, (this._ListenerComparator == null) ? "" : this._ListenerComparator.Path, true) != 0)
				{
					this._ListenerComparator = ModMinecraft.SetupResolver();
					this.getterComparator = num;
					switch (num)
					{
					case 0:
						ModBase.Log("[Minecraft] 启动按钮：正在加载 Minecraft 版本", ModBase.LogLevel.Normal, "出现错误");
						ModMain._FilterAccount.BtnLaunch.Text = "正在加载";
						ModMain._FilterAccount.BtnLaunch.IsEnabled = false;
						ModMain._FilterAccount.LabVersion.Text = "正在加载版本列表，请稍候";
						ModMain._FilterAccount.BtnVersion.IsEnabled = false;
						ModMain._FilterAccount.BtnMore.Visibility = Visibility.Collapsed;
						break;
					case 1:
						ModBase.Log("[Minecraft] 启动按钮：无 Minecraft 版本，下载已禁用", ModBase.LogLevel.Normal, "出现错误");
						ModMain._FilterAccount.BtnLaunch.Text = "启动游戏";
						ModMain._FilterAccount.BtnLaunch.IsEnabled = false;
						ModMain._FilterAccount.LabVersion.Text = "未找到可用的游戏版本";
						ModMain._FilterAccount.BtnVersion.IsEnabled = true;
						ModMain._FilterAccount.BtnMore.Visibility = Visibility.Collapsed;
						break;
					case 2:
						ModBase.Log("[Minecraft] 启动按钮：无 Minecraft 版本，要求下载", ModBase.LogLevel.Normal, "出现错误");
						ModMain._FilterAccount.BtnLaunch.Text = "下载游戏";
						ModMain._FilterAccount.BtnLaunch.IsEnabled = true;
						ModMain._FilterAccount.LabVersion.Text = "未找到可用的游戏版本";
						ModMain._FilterAccount.BtnVersion.IsEnabled = true;
						ModMain._FilterAccount.BtnMore.Visibility = Visibility.Collapsed;
						break;
					case 3:
						ModBase.Log("[Minecraft] 启动按钮：Minecraft 版本：" + ModMinecraft.SetupResolver().Path, ModBase.LogLevel.Normal, "出现错误");
						ModMain._FilterAccount.BtnLaunch.Text = "启动游戏";
						ModMain._FilterAccount.BtnVersion.IsEnabled = true;
						ModMain._FilterAccount.BtnLaunch.IsEnabled = true;
						ModMain._FilterAccount.LabVersion.Text = ModMinecraft.SetupResolver().Name;
						break;
					}
				}
				ModMain._FilterAccount.BtnVersion.Visibility = (Conversions.ToBoolean(!PageSetupUI.AwakeResolver() && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenFunctionSelect", null))) ? Visibility.Collapsed : Visibility.Visible);
				if (num == 3)
				{
					ModMain._FilterAccount.BtnMore.Visibility = ModMain._FilterAccount.BtnVersion.Visibility;
				}
			}
		}

		// Token: 0x06000C58 RID: 3160 RVA: 0x000616DC File Offset: 0x0005F8DC
		private void BtnCancel_Click()
		{
			if (ModLaunch.facadeTag != null)
			{
				ModLaunch.facadeTag.Abort();
				ModLaunch.McLaunchLog("已取消启动");
				try
				{
					if (ModLaunch.m_StructTag != null)
					{
						ModLaunch.m_StructTag.Kill();
					}
					else if (ModLaunch.m_BridgeTag != null && !ModLaunch.m_BridgeTag.HasExited)
					{
						ModLaunch.m_BridgeTag.Kill();
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "取消启动结束进程失败", ModBase.LogLevel.Hint, "出现错误");
				}
			}
		}

		// Token: 0x06000C59 RID: 3161 RVA: 0x000082B2 File Offset: 0x000064B2
		private void BtnMore_Click(object sender, EventArgs e)
		{
			ModMinecraft.SetupResolver().Load();
			PageVersionLeft.m_AlgoResolver = ModMinecraft.SetupResolver();
			ModMain.m_CollectionAccount.PageChange(FormMain.PageType.VersionSetup, FormMain.PageSubType.Default);
		}

		// Token: 0x06000C5A RID: 3162 RVA: 0x00061768 File Offset: 0x0005F968
		public void LaunchingPreload()
		{
			object left = ModBase._ParamsState.Get("LoginType", null);
			if (Operators.ConditionalCompareObjectEqual(left, ModLaunch.McLoginType.Legacy, true))
			{
				this.LabLaunchingMethod.Text = "离线登录";
			}
			else if (Operators.ConditionalCompareObjectEqual(left, ModLaunch.McLoginType.Mojang, true))
			{
				this.LabLaunchingMethod.Text = "Mojang 正版登录";
			}
			else if (Operators.ConditionalCompareObjectEqual(left, ModLaunch.McLoginType.Ms, true))
			{
				this.LabLaunchingMethod.Text = "微软正版登录";
			}
			else if (Operators.ConditionalCompareObjectEqual(left, ModLaunch.McLoginType.Nide, true))
			{
				this.LabLaunchingMethod.Text = "统一通行证";
			}
			else if (Operators.ConditionalCompareObjectEqual(left, ModLaunch.McLoginType.Auth, true))
			{
				this.LabLaunchingMethod.Text = "Authlib-Injector";
			}
			this.LabLaunchingName.Text = ModMinecraft.SetupResolver().Name;
			this.LabLaunchingStage.Text = "初始化";
			this.LabLaunchingTitle.Text = "正在启动游戏";
			this.LabLaunchingProgress.Text = "0.00 %";
			this.LabLaunchingProgress.Opacity = 1.0;
			this.LabLaunchingDownload.Visibility = Visibility.Visible;
			this.LabLaunchingProgressLeft.Opacity = 0.6;
			this.LabLaunchingDownload.Visibility = Visibility.Visible;
			this.LabLaunchingDownload.Text = "0 B/s";
			this.LabLaunchingDownload.Opacity = 0.0;
			this.LabLaunchingDownload.Visibility = Visibility.Collapsed;
			this.LabLaunchingDownloadLeft.Opacity = 0.0;
			this.LabLaunchingDownloadLeft.Visibility = Visibility.Collapsed;
			this.ProgressLaunchingFinished.Width = new GridLength(0.0, GridUnitType.Star);
			this.ProgressLaunchingUnfinished.Width = new GridLength(1.0, GridUnitType.Star);
			this.PanLaunchingHint.Opacity = 0.0;
			this.PanLaunchingHint.Visibility = Visibility.Collapsed;
			this.PanLaunchingInfo.Width = double.NaN;
			ModLaunch.m_BridgeTag = null;
			ModLaunch.m_StructTag = null;
			string text = PageOtherTest.GetRandomHint();
			try
			{
				string[] array = Array.FindAll<string>(ModBase.ReadFile(ModBase.Path + "PCL\\hints.txt").Replace("\n", "").Split(new char[]
				{
					'\r'
				}), (PageLaunchLeft._Closure$__.$I37-0 == null) ? (PageLaunchLeft._Closure$__.$I37-0 = ((string Input) => !string.IsNullOrWhiteSpace(Input))) : PageLaunchLeft._Closure$__.$I37-0);
				if (array.Count<string>() > 0)
				{
					text = Conversions.ToString(ModBase.RandomOne(array));
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "获取自定义 你知道吗 提示失败", ModBase.LogLevel.Hint, "出现错误");
			}
			this.LabLaunchingHint.Text = text;
		}

		// Token: 0x06000C5B RID: 3163 RVA: 0x00061A2C File Offset: 0x0005FC2C
		public void LaunchingRefresh()
		{
			try
			{
				PageLaunchLeft._Closure$__39-0 CS$<>8__locals1 = new PageLaunchLeft._Closure$__39-0(CS$<>8__locals1);
				CS$<>8__locals1.$VB$Me = this;
				if (ModLaunch.facadeTag.State != ModBase.LoadState.Aborted)
				{
					bool flag = false;
					try
					{
						try
						{
							foreach (ModLoader.LoaderBase loaderBase in ModLaunch.facadeTag.GetLoaderList(false))
							{
								if (loaderBase.State == ModBase.LoadState.Loading)
								{
									this.LabLaunchingStage.Text = loaderBase.Name;
									flag = (Operators.CompareString(loaderBase.Name, "等待游戏窗口出现", true) == 0 || Operators.CompareString(loaderBase.Name, "结束处理", true) == 0);
									goto IL_DC;
								}
							}
						}
						finally
						{
							List<ModLoader.LoaderBase>.Enumerator enumerator;
							((IDisposable)enumerator).Dispose();
						}
						this.LabLaunchingStage.Text = "未知";
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "获取是否启动完成失败，可能是由于启动状态改变导致集合已修改", ModBase.LogLevel.Debug, "出现错误");
						return;
					}
					IL_DC:
					if (ModAnimation.AniIsRun("Launch State Page"))
					{
						flag = false;
					}
					double progress = ModLaunch.facadeTag.Progress;
					if (progress >= this._IdentifierComparator)
					{
						ref double ptr = ref this._IdentifierComparator;
						this._IdentifierComparator = ptr + ((progress - this._IdentifierComparator) * 0.2 + 0.005);
					}
					if (progress <= this._IdentifierComparator)
					{
						this._IdentifierComparator = progress;
					}
					if (flag)
					{
						this._IdentifierComparator = 1.0;
					}
					this.LabLaunchingTitle.Text = (flag ? "已启动游戏" : "正在启动游戏");
					this.LabLaunchingProgress.Text = ModBase.StrFillNum(this._IdentifierComparator * 100.0, 2) + " %";
					CS$<>8__locals1.$VB$Local_HasLaunchDownloader = false;
					try
					{
						try
						{
							foreach (ModNet.LoaderDownload loaderDownload in ModNet.reponseTag._AttributeProccesor)
							{
								if (loaderDownload.RealParent != null && Operators.CompareString(loaderDownload.RealParent.Name, "Minecraft 启动", true) == 0 && loaderDownload.State == ModBase.LoadState.Loading)
								{
									CS$<>8__locals1.$VB$Local_HasLaunchDownloader = true;
								}
							}
						}
						finally
						{
							List<ModNet.LoaderDownload>.Enumerator enumerator2;
							((IDisposable)enumerator2).Dispose();
						}
					}
					catch (Exception ex2)
					{
						ModBase.Log(ex2, "获取 Minecraft 启动下载器失败，可能是因为启动被取消", ModBase.LogLevel.Debug, "出现错误");
						CS$<>8__locals1.$VB$Local_HasLaunchDownloader = false;
					}
					this.LabLaunchingDownload.Text = ModBase.GetString(ModNet.reponseTag._MapProccesor) + "/s";
					List<ModAnimation.AniData> list = new List<ModAnimation.AniData>
					{
						ModAnimation.AaGridLengthWidth(this.ProgressLaunchingFinished, this._IdentifierComparator - this.ProgressLaunchingFinished.Width.Value, 260, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
						ModAnimation.AaGridLengthWidth(this.ProgressLaunchingUnfinished, 1.0 - this._IdentifierComparator - this.ProgressLaunchingUnfinished.Width.Value, 260, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false)
					};
					if (CS$<>8__locals1.$VB$Local_HasLaunchDownloader == (this.LabLaunchingDownload.Visibility == Visibility.Collapsed))
					{
						this.LabLaunchingDownload.Visibility = Visibility.Visible;
						this.LabLaunchingDownloadLeft.Visibility = Visibility.Visible;
						list.AddRange(new ModAnimation.AniData[]
						{
							ModAnimation.AaOpacity(this.LabLaunchingDownload, (double)(CS$<>8__locals1.$VB$Local_HasLaunchDownloader ? 1 : 0) - this.LabLaunchingDownload.Opacity, 100, 0, null, false),
							ModAnimation.AaOpacity(this.LabLaunchingDownloadLeft, (CS$<>8__locals1.$VB$Local_HasLaunchDownloader ? 0.5 : 0.0) - this.LabLaunchingDownloadLeft.Opacity, 100, 0, null, false),
							ModAnimation.AaCode(delegate
							{
								if (!CS$<>8__locals1.$VB$Local_HasLaunchDownloader)
								{
									CS$<>8__locals1.$VB$Me.LabLaunchingDownload.Visibility = Visibility.Collapsed;
									CS$<>8__locals1.$VB$Me.LabLaunchingDownloadLeft.Visibility = Visibility.Collapsed;
								}
							}, 110, false)
						});
					}
					if (!flag == (this.LabLaunchingProgress.Visibility == Visibility.Collapsed))
					{
						this.LabLaunchingProgress.Visibility = Visibility.Visible;
						this.LabLaunchingProgressLeft.Visibility = Visibility.Visible;
						if (flag)
						{
							this.PanLaunchingHint.Visibility = Visibility.Visible;
						}
						list.AddRange(new ModAnimation.AniData[]
						{
							ModAnimation.AaOpacity(this.LabLaunchingProgress, (double)((!flag) ? 1 : 0) - this.LabLaunchingProgress.Opacity, 100, 0, null, false),
							ModAnimation.AaOpacity(this.LabLaunchingProgressLeft, ((!flag) ? 0.5 : 0.0) - this.LabLaunchingProgressLeft.Opacity, 100, 0, null, false),
							ModAnimation.AaOpacity(this.PanLaunchingHint, (double)(flag ? 1 : 0) - this.PanLaunchingHint.Opacity, 100, 0, null, false)
						});
					}
					ModAnimation.AniStart(list, "Launching Progress", false);
				}
			}
			catch (Exception ex3)
			{
				ModBase.Log(ex3, "刷新启动信息失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000C5C RID: 3164 RVA: 0x00061F58 File Offset: 0x00060158
		private void PanLaunchingInfo_SizeChangedW(object sender, SizeChangedEventArgs e)
		{
			double value = e.NewSize.Width - e.PreviousSize.Width;
			if (e.PreviousSize.Width != 0.0 && !this.m_InstanceComparator && Math.Abs(value) >= 1.0 && this.PanLaunchingInfo.ActualWidth != 0.0)
			{
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaWidth(this.PanLaunchingInfo, value, 180, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaCode(delegate
					{
						this.m_InstanceComparator = false;
						this.PanLaunchingInfo.Width = this.m_CreatorComparator;
					}, 0, true)
				}, "Launching Info Width", false);
				this.m_InstanceComparator = true;
				this.m_CreatorComparator = this.PanLaunchingInfo.Width;
				this.PanLaunchingInfo.Width = e.PreviousSize.Width;
			}
		}

		// Token: 0x06000C5D RID: 3165 RVA: 0x00062050 File Offset: 0x00060250
		private void PanLaunchingInfo_SizeChangedH(object sender, SizeChangedEventArgs e)
		{
			double value = e.NewSize.Height - e.PreviousSize.Height;
			if (e.PreviousSize.Height != 0.0 && !this.objectComparator && Math.Abs(value) >= 1.0 && this.PanLaunchingInfo.ActualHeight != 0.0)
			{
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaHeight(this.PanLaunchingInfo, value, 180, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaCode(delegate
					{
						this.objectComparator = false;
						this.PanLaunchingInfo.Height = this._RegComparator;
					}, 0, true)
				}, "Launching Info Height", false);
				this.objectComparator = true;
				this._RegComparator = this.PanLaunchingInfo.Height;
				this.PanLaunchingInfo.Height = e.PreviousSize.Height;
			}
		}

		// Token: 0x170001C2 RID: 450
		// (get) Token: 0x06000C5E RID: 3166 RVA: 0x000082DA File Offset: 0x000064DA
		// (set) Token: 0x06000C5F RID: 3167 RVA: 0x000082E2 File Offset: 0x000064E2
		internal virtual PageLaunchLeft PanBack { get; set; }

		// Token: 0x170001C3 RID: 451
		// (get) Token: 0x06000C60 RID: 3168 RVA: 0x000082EB File Offset: 0x000064EB
		// (set) Token: 0x06000C61 RID: 3169 RVA: 0x000082F3 File Offset: 0x000064F3
		internal virtual Grid PanInput { get; set; }

		// Token: 0x170001C4 RID: 452
		// (get) Token: 0x06000C62 RID: 3170 RVA: 0x000082FC File Offset: 0x000064FC
		// (set) Token: 0x06000C63 RID: 3171 RVA: 0x00062148 File Offset: 0x00060348
		internal virtual MyButton BtnVersion
		{
			[CompilerGenerated]
			get
			{
				return this.itemComparator;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnVersion_Click);
				MyButton myButton = this.itemComparator;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.itemComparator = value;
				myButton = this.itemComparator;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001C5 RID: 453
		// (get) Token: 0x06000C64 RID: 3172 RVA: 0x00008304 File Offset: 0x00006504
		// (set) Token: 0x06000C65 RID: 3173 RVA: 0x0006218C File Offset: 0x0006038C
		internal virtual MyButton BtnMore
		{
			[CompilerGenerated]
			get
			{
				return this.mapperComparator;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnMore_Click);
				MyButton myButton = this.mapperComparator;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.mapperComparator = value;
				myButton = this.mapperComparator;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x170001C6 RID: 454
		// (get) Token: 0x06000C66 RID: 3174 RVA: 0x0000830C File Offset: 0x0000650C
		// (set) Token: 0x06000C67 RID: 3175 RVA: 0x00008314 File Offset: 0x00006514
		internal virtual Grid PanLogin { get; set; }

		// Token: 0x170001C7 RID: 455
		// (get) Token: 0x06000C68 RID: 3176 RVA: 0x0000831D File Offset: 0x0000651D
		// (set) Token: 0x06000C69 RID: 3177 RVA: 0x00008325 File Offset: 0x00006525
		internal virtual Grid PanTypeOne { get; set; }

		// Token: 0x170001C8 RID: 456
		// (get) Token: 0x06000C6A RID: 3178 RVA: 0x0000832E File Offset: 0x0000652E
		// (set) Token: 0x06000C6B RID: 3179 RVA: 0x00008336 File Offset: 0x00006536
		internal virtual System.Windows.Shapes.Path PathTypeOne { get; set; }

		// Token: 0x170001C9 RID: 457
		// (get) Token: 0x06000C6C RID: 3180 RVA: 0x0000833F File Offset: 0x0000653F
		// (set) Token: 0x06000C6D RID: 3181 RVA: 0x00008347 File Offset: 0x00006547
		internal virtual TextBlock LabTypeOne { get; set; }

		// Token: 0x170001CA RID: 458
		// (get) Token: 0x06000C6E RID: 3182 RVA: 0x00008350 File Offset: 0x00006550
		// (set) Token: 0x06000C6F RID: 3183 RVA: 0x00008358 File Offset: 0x00006558
		internal virtual Grid PanType { get; set; }

		// Token: 0x170001CB RID: 459
		// (get) Token: 0x06000C70 RID: 3184 RVA: 0x00008361 File Offset: 0x00006561
		// (set) Token: 0x06000C71 RID: 3185 RVA: 0x000621D0 File Offset: 0x000603D0
		internal virtual MyRadioButton RadioLoginType1
		{
			[CompilerGenerated]
			get
			{
				return this.policyComparator;
			}
			[CompilerGenerated]
			set
			{
				MyRadioButton.CheckEventHandler obj = new MyRadioButton.CheckEventHandler(this.RadioLoginType_Change);
				MyRadioButton myRadioButton = this.policyComparator;
				if (myRadioButton != null)
				{
					myRadioButton.AddTag(obj);
				}
				this.policyComparator = value;
				myRadioButton = this.policyComparator;
				if (myRadioButton != null)
				{
					myRadioButton.CountTag(obj);
				}
			}
		}

		// Token: 0x170001CC RID: 460
		// (get) Token: 0x06000C72 RID: 3186 RVA: 0x00008369 File Offset: 0x00006569
		// (set) Token: 0x06000C73 RID: 3187 RVA: 0x00062214 File Offset: 0x00060414
		internal virtual MyRadioButton RadioLoginType5
		{
			[CompilerGenerated]
			get
			{
				return this._ThreadComparator;
			}
			[CompilerGenerated]
			set
			{
				MyRadioButton.CheckEventHandler obj = new MyRadioButton.CheckEventHandler(this.RadioLoginType_Change);
				MyRadioButton threadComparator = this._ThreadComparator;
				if (threadComparator != null)
				{
					threadComparator.AddTag(obj);
				}
				this._ThreadComparator = value;
				threadComparator = this._ThreadComparator;
				if (threadComparator != null)
				{
					threadComparator.CountTag(obj);
				}
			}
		}

		// Token: 0x170001CD RID: 461
		// (get) Token: 0x06000C74 RID: 3188 RVA: 0x00008371 File Offset: 0x00006571
		// (set) Token: 0x06000C75 RID: 3189 RVA: 0x00062258 File Offset: 0x00060458
		internal virtual MyRadioButton RadioLoginType0
		{
			[CompilerGenerated]
			get
			{
				return this.m_ConnectionComparator;
			}
			[CompilerGenerated]
			set
			{
				MyRadioButton.CheckEventHandler obj = new MyRadioButton.CheckEventHandler(this.RadioLoginType_Change);
				MyRadioButton connectionComparator = this.m_ConnectionComparator;
				if (connectionComparator != null)
				{
					connectionComparator.AddTag(obj);
				}
				this.m_ConnectionComparator = value;
				connectionComparator = this.m_ConnectionComparator;
				if (connectionComparator != null)
				{
					connectionComparator.CountTag(obj);
				}
			}
		}

		// Token: 0x170001CE RID: 462
		// (get) Token: 0x06000C76 RID: 3190 RVA: 0x00008379 File Offset: 0x00006579
		// (set) Token: 0x06000C77 RID: 3191 RVA: 0x00008381 File Offset: 0x00006581
		internal virtual ScaleTransform AprilScaleTrans { get; set; }

		// Token: 0x170001CF RID: 463
		// (get) Token: 0x06000C78 RID: 3192 RVA: 0x0000838A File Offset: 0x0000658A
		// (set) Token: 0x06000C79 RID: 3193 RVA: 0x00008392 File Offset: 0x00006592
		internal virtual TranslateTransform AprilPosTrans { get; set; }

		// Token: 0x170001D0 RID: 464
		// (get) Token: 0x06000C7A RID: 3194 RVA: 0x0000839B File Offset: 0x0000659B
		// (set) Token: 0x06000C7B RID: 3195 RVA: 0x0006229C File Offset: 0x0006049C
		internal virtual MyButton BtnLaunch
		{
			[CompilerGenerated]
			get
			{
				return this.databaseComparator;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.BtnLaunch_Click();
				};
				RoutedEventHandler value2 = delegate(object sender, RoutedEventArgs e)
				{
					this.RefreshButtonsUI();
				};
				MyButton myButton = this.databaseComparator;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
					myButton.Loaded -= value2;
				}
				this.databaseComparator = value;
				myButton = this.databaseComparator;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
					myButton.Loaded += value2;
				}
			}
		}

		// Token: 0x170001D1 RID: 465
		// (get) Token: 0x06000C7C RID: 3196 RVA: 0x000083A3 File Offset: 0x000065A3
		// (set) Token: 0x06000C7D RID: 3197 RVA: 0x000083AB File Offset: 0x000065AB
		internal virtual TextBlock LabVersion { get; set; }

		// Token: 0x170001D2 RID: 466
		// (get) Token: 0x06000C7E RID: 3198 RVA: 0x000083B4 File Offset: 0x000065B4
		// (set) Token: 0x06000C7F RID: 3199 RVA: 0x000083BC File Offset: 0x000065BC
		internal virtual Grid PanLaunching { get; set; }

		// Token: 0x170001D3 RID: 467
		// (get) Token: 0x06000C80 RID: 3200 RVA: 0x000083C5 File Offset: 0x000065C5
		// (set) Token: 0x06000C81 RID: 3201 RVA: 0x000083CD File Offset: 0x000065CD
		internal virtual MyLoading LoadLaunching { get; set; }

		// Token: 0x170001D4 RID: 468
		// (get) Token: 0x06000C82 RID: 3202 RVA: 0x000083D6 File Offset: 0x000065D6
		// (set) Token: 0x06000C83 RID: 3203 RVA: 0x000083DE File Offset: 0x000065DE
		internal virtual TextBlock LabLaunchingTitle { get; set; }

		// Token: 0x170001D5 RID: 469
		// (get) Token: 0x06000C84 RID: 3204 RVA: 0x000083E7 File Offset: 0x000065E7
		// (set) Token: 0x06000C85 RID: 3205 RVA: 0x000083EF File Offset: 0x000065EF
		internal virtual TextBlock LabLaunchingName { get; set; }

		// Token: 0x170001D6 RID: 470
		// (get) Token: 0x06000C86 RID: 3206 RVA: 0x000083F8 File Offset: 0x000065F8
		// (set) Token: 0x06000C87 RID: 3207 RVA: 0x00008400 File Offset: 0x00006600
		internal virtual ColumnDefinition ProgressLaunchingFinished { get; set; }

		// Token: 0x170001D7 RID: 471
		// (get) Token: 0x06000C88 RID: 3208 RVA: 0x00008409 File Offset: 0x00006609
		// (set) Token: 0x06000C89 RID: 3209 RVA: 0x00008411 File Offset: 0x00006611
		internal virtual ColumnDefinition ProgressLaunchingUnfinished { get; set; }

		// Token: 0x170001D8 RID: 472
		// (get) Token: 0x06000C8A RID: 3210 RVA: 0x0000841A File Offset: 0x0000661A
		// (set) Token: 0x06000C8B RID: 3211 RVA: 0x000622FC File Offset: 0x000604FC
		internal virtual Grid PanLaunchingInfo
		{
			[CompilerGenerated]
			get
			{
				return this.filterComparator;
			}
			[CompilerGenerated]
			set
			{
				SizeChangedEventHandler value2 = new SizeChangedEventHandler(this.PanLaunchingInfo_SizeChangedW);
				SizeChangedEventHandler value3 = new SizeChangedEventHandler(this.PanLaunchingInfo_SizeChangedH);
				Grid grid = this.filterComparator;
				if (grid != null)
				{
					grid.SizeChanged -= value2;
					grid.SizeChanged -= value3;
				}
				this.filterComparator = value;
				grid = this.filterComparator;
				if (grid != null)
				{
					grid.SizeChanged += value2;
					grid.SizeChanged += value3;
				}
			}
		}

		// Token: 0x170001D9 RID: 473
		// (get) Token: 0x06000C8C RID: 3212 RVA: 0x00008422 File Offset: 0x00006622
		// (set) Token: 0x06000C8D RID: 3213 RVA: 0x0000842A File Offset: 0x0000662A
		internal virtual TextBlock LabLaunchingStage { get; set; }

		// Token: 0x170001DA RID: 474
		// (get) Token: 0x06000C8E RID: 3214 RVA: 0x00008433 File Offset: 0x00006633
		// (set) Token: 0x06000C8F RID: 3215 RVA: 0x0000843B File Offset: 0x0000663B
		internal virtual TextBlock LabLaunchingMethod { get; set; }

		// Token: 0x170001DB RID: 475
		// (get) Token: 0x06000C90 RID: 3216 RVA: 0x00008444 File Offset: 0x00006644
		// (set) Token: 0x06000C91 RID: 3217 RVA: 0x0000844C File Offset: 0x0000664C
		internal virtual TextBlock LabLaunchingProgressLeft { get; set; }

		// Token: 0x170001DC RID: 476
		// (get) Token: 0x06000C92 RID: 3218 RVA: 0x00008455 File Offset: 0x00006655
		// (set) Token: 0x06000C93 RID: 3219 RVA: 0x0000845D File Offset: 0x0000665D
		internal virtual TextBlock LabLaunchingProgress { get; set; }

		// Token: 0x170001DD RID: 477
		// (get) Token: 0x06000C94 RID: 3220 RVA: 0x00008466 File Offset: 0x00006666
		// (set) Token: 0x06000C95 RID: 3221 RVA: 0x0000846E File Offset: 0x0000666E
		internal virtual TextBlock LabLaunchingDownloadLeft { get; set; }

		// Token: 0x170001DE RID: 478
		// (get) Token: 0x06000C96 RID: 3222 RVA: 0x00008477 File Offset: 0x00006677
		// (set) Token: 0x06000C97 RID: 3223 RVA: 0x0000847F File Offset: 0x0000667F
		internal virtual TextBlock LabLaunchingDownload { get; set; }

		// Token: 0x170001DF RID: 479
		// (get) Token: 0x06000C98 RID: 3224 RVA: 0x00008488 File Offset: 0x00006688
		// (set) Token: 0x06000C99 RID: 3225 RVA: 0x00008490 File Offset: 0x00006690
		internal virtual Grid PanLaunchingHint { get; set; }

		// Token: 0x170001E0 RID: 480
		// (get) Token: 0x06000C9A RID: 3226 RVA: 0x00008499 File Offset: 0x00006699
		// (set) Token: 0x06000C9B RID: 3227 RVA: 0x000084A1 File Offset: 0x000066A1
		internal virtual TextBlock LabLaunchingHint { get; set; }

		// Token: 0x170001E1 RID: 481
		// (get) Token: 0x06000C9C RID: 3228 RVA: 0x000084AA File Offset: 0x000066AA
		// (set) Token: 0x06000C9D RID: 3229 RVA: 0x0006235C File Offset: 0x0006055C
		internal virtual MyButton BtnCancel
		{
			[CompilerGenerated]
			get
			{
				return this.errorComparator;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.BtnCancel_Click();
				};
				MyButton myButton = this.errorComparator;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.errorComparator = value;
				myButton = this.errorComparator;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x06000C9E RID: 3230 RVA: 0x000623A0 File Offset: 0x000605A0
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.exceptionComparator)
			{
				this.exceptionComparator = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagelaunch/pagelaunchleft.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000C9F RID: 3231 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000CA0 RID: 3232 RVA: 0x000623D0 File Offset: 0x000605D0
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (PageLaunchLeft)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanInput = (Grid)target;
				return;
			}
			if (connectionId == 3)
			{
				this.BtnVersion = (MyButton)target;
				return;
			}
			if (connectionId == 4)
			{
				this.BtnMore = (MyButton)target;
				return;
			}
			if (connectionId == 5)
			{
				this.PanLogin = (Grid)target;
				return;
			}
			if (connectionId == 6)
			{
				this.PanTypeOne = (Grid)target;
				return;
			}
			if (connectionId == 7)
			{
				this.PathTypeOne = (System.Windows.Shapes.Path)target;
				return;
			}
			if (connectionId == 8)
			{
				this.LabTypeOne = (TextBlock)target;
				return;
			}
			if (connectionId == 9)
			{
				this.PanType = (Grid)target;
				return;
			}
			if (connectionId == 10)
			{
				this.RadioLoginType1 = (MyRadioButton)target;
				return;
			}
			if (connectionId == 11)
			{
				this.RadioLoginType5 = (MyRadioButton)target;
				return;
			}
			if (connectionId == 12)
			{
				this.RadioLoginType0 = (MyRadioButton)target;
				return;
			}
			if (connectionId == 13)
			{
				this.AprilScaleTrans = (ScaleTransform)target;
				return;
			}
			if (connectionId == 14)
			{
				this.AprilPosTrans = (TranslateTransform)target;
				return;
			}
			if (connectionId == 15)
			{
				this.BtnLaunch = (MyButton)target;
				return;
			}
			if (connectionId == 16)
			{
				this.LabVersion = (TextBlock)target;
				return;
			}
			if (connectionId == 17)
			{
				this.PanLaunching = (Grid)target;
				return;
			}
			if (connectionId == 18)
			{
				this.LoadLaunching = (MyLoading)target;
				return;
			}
			if (connectionId == 19)
			{
				this.LabLaunchingTitle = (TextBlock)target;
				return;
			}
			if (connectionId == 20)
			{
				this.LabLaunchingName = (TextBlock)target;
				return;
			}
			if (connectionId == 21)
			{
				this.ProgressLaunchingFinished = (ColumnDefinition)target;
				return;
			}
			if (connectionId == 22)
			{
				this.ProgressLaunchingUnfinished = (ColumnDefinition)target;
				return;
			}
			if (connectionId == 23)
			{
				this.PanLaunchingInfo = (Grid)target;
				return;
			}
			if (connectionId == 24)
			{
				this.LabLaunchingStage = (TextBlock)target;
				return;
			}
			if (connectionId == 25)
			{
				this.LabLaunchingMethod = (TextBlock)target;
				return;
			}
			if (connectionId == 26)
			{
				this.LabLaunchingProgressLeft = (TextBlock)target;
				return;
			}
			if (connectionId == 27)
			{
				this.LabLaunchingProgress = (TextBlock)target;
				return;
			}
			if (connectionId == 28)
			{
				this.LabLaunchingDownloadLeft = (TextBlock)target;
				return;
			}
			if (connectionId == 29)
			{
				this.LabLaunchingDownload = (TextBlock)target;
				return;
			}
			if (connectionId == 30)
			{
				this.PanLaunchingHint = (Grid)target;
				return;
			}
			if (connectionId == 31)
			{
				this.LabLaunchingHint = (TextBlock)target;
				return;
			}
			if (connectionId == 32)
			{
				this.BtnCancel = (MyButton)target;
				return;
			}
			this.exceptionComparator = true;
		}

		// Token: 0x04000633 RID: 1587
		private bool baseComparator;

		// Token: 0x04000634 RID: 1588
		private bool _ProductComparator;

		// Token: 0x04000635 RID: 1589
		private PageLaunchLeft.PageType _AttrComparator;

		// Token: 0x04000636 RID: 1590
		public static ModLoader.LoaderTask<ModBase.EqualableList<string>, string> facadeComparator = new ModLoader.LoaderTask<ModBase.EqualableList<string>, string>("Loader Skin Mojang", new Action<ModLoader.LoaderTask<ModBase.EqualableList<string>, string>>(PageLaunchLeft.SkinMojangLoad), new Func<ModBase.EqualableList<string>>(PageLaunchLeft.SkinMojangInput), ThreadPriority.AboveNormal);

		// Token: 0x04000637 RID: 1591
		public static ModLoader.LoaderTask<ModBase.EqualableList<string>, string> m_BridgeComparator = new ModLoader.LoaderTask<ModBase.EqualableList<string>, string>("Loader Skin Ms", new Action<ModLoader.LoaderTask<ModBase.EqualableList<string>, string>>(PageLaunchLeft.SkinMsLoad), new Func<ModBase.EqualableList<string>>(PageLaunchLeft.SkinMsInput), ThreadPriority.AboveNormal);

		// Token: 0x04000638 RID: 1592
		public static ModLoader.LoaderTask<ModBase.EqualableList<string>, string> _StructComparator = new ModLoader.LoaderTask<ModBase.EqualableList<string>, string>("Loader Skin Legacy", new Action<ModLoader.LoaderTask<ModBase.EqualableList<string>, string>>(PageLaunchLeft.SkinLegacyLoad), new Func<ModBase.EqualableList<string>>(PageLaunchLeft.SkinLegacyInput), ThreadPriority.AboveNormal);

		// Token: 0x04000639 RID: 1593
		public static ModLoader.LoaderTask<ModBase.EqualableList<string>, string> m_IndexerComparator = new ModLoader.LoaderTask<ModBase.EqualableList<string>, string>("Loader Skin Nide", new Action<ModLoader.LoaderTask<ModBase.EqualableList<string>, string>>(PageLaunchLeft.SkinNideLoad), new Func<ModBase.EqualableList<string>>(PageLaunchLeft.SkinNideInput), ThreadPriority.AboveNormal);

		// Token: 0x0400063A RID: 1594
		public static ModLoader.LoaderTask<ModBase.EqualableList<string>, string> m_TemplateComparator = new ModLoader.LoaderTask<ModBase.EqualableList<string>, string>("Loader Skin Auth", new Action<ModLoader.LoaderTask<ModBase.EqualableList<string>, string>>(PageLaunchLeft.SkinAuthLoad), new Func<ModBase.EqualableList<string>>(PageLaunchLeft.SkinAuthInput), ThreadPriority.AboveNormal);

		// Token: 0x0400063B RID: 1595
		public static List<ModLoader.LoaderTask<ModBase.EqualableList<string>, string>> _ExpressionComparator = new List<ModLoader.LoaderTask<ModBase.EqualableList<string>, string>>
		{
			PageLaunchLeft.facadeComparator,
			PageLaunchLeft.m_BridgeComparator,
			PageLaunchLeft._StructComparator,
			PageLaunchLeft.m_IndexerComparator,
			PageLaunchLeft.m_TemplateComparator
		};

		// Token: 0x0400063C RID: 1596
		private int getterComparator;

		// Token: 0x0400063D RID: 1597
		private ModMinecraft.McVersion _ListenerComparator;

		// Token: 0x0400063E RID: 1598
		private double _IdentifierComparator;

		// Token: 0x0400063F RID: 1599
		private bool m_InstanceComparator;

		// Token: 0x04000640 RID: 1600
		private double m_CreatorComparator;

		// Token: 0x04000641 RID: 1601
		private bool objectComparator;

		// Token: 0x04000642 RID: 1602
		private double _RegComparator;

		// Token: 0x04000643 RID: 1603
		[CompilerGenerated]
		[AccessedThroughProperty("PanBack")]
		private PageLaunchLeft _InvocationComparator;

		// Token: 0x04000644 RID: 1604
		[CompilerGenerated]
		[AccessedThroughProperty("PanInput")]
		private Grid _ComposerComparator;

		// Token: 0x04000645 RID: 1605
		[AccessedThroughProperty("BtnVersion")]
		[CompilerGenerated]
		private MyButton itemComparator;

		// Token: 0x04000646 RID: 1606
		[CompilerGenerated]
		[AccessedThroughProperty("BtnMore")]
		private MyButton mapperComparator;

		// Token: 0x04000647 RID: 1607
		[CompilerGenerated]
		[AccessedThroughProperty("PanLogin")]
		private Grid _FactoryComparator;

		// Token: 0x04000648 RID: 1608
		[AccessedThroughProperty("PanTypeOne")]
		[CompilerGenerated]
		private Grid m_ProcessComparator;

		// Token: 0x04000649 RID: 1609
		[CompilerGenerated]
		[AccessedThroughProperty("PathTypeOne")]
		private System.Windows.Shapes.Path valComparator;

		// Token: 0x0400064A RID: 1610
		[AccessedThroughProperty("LabTypeOne")]
		[CompilerGenerated]
		private TextBlock _UtilsComparator;

		// Token: 0x0400064B RID: 1611
		[CompilerGenerated]
		[AccessedThroughProperty("PanType")]
		private Grid m_OrderComparator;

		// Token: 0x0400064C RID: 1612
		[AccessedThroughProperty("RadioLoginType1")]
		[CompilerGenerated]
		private MyRadioButton policyComparator;

		// Token: 0x0400064D RID: 1613
		[AccessedThroughProperty("RadioLoginType5")]
		[CompilerGenerated]
		private MyRadioButton _ThreadComparator;

		// Token: 0x0400064E RID: 1614
		[AccessedThroughProperty("RadioLoginType0")]
		[CompilerGenerated]
		private MyRadioButton m_ConnectionComparator;

		// Token: 0x0400064F RID: 1615
		[CompilerGenerated]
		[AccessedThroughProperty("AprilScaleTrans")]
		private ScaleTransform _CustomerComparator;

		// Token: 0x04000650 RID: 1616
		[AccessedThroughProperty("AprilPosTrans")]
		[CompilerGenerated]
		private TranslateTransform schemaComparator;

		// Token: 0x04000651 RID: 1617
		[AccessedThroughProperty("BtnLaunch")]
		[CompilerGenerated]
		private MyButton databaseComparator;

		// Token: 0x04000652 RID: 1618
		[AccessedThroughProperty("LabVersion")]
		[CompilerGenerated]
		private TextBlock _CallbackComparator;

		// Token: 0x04000653 RID: 1619
		[AccessedThroughProperty("PanLaunching")]
		[CompilerGenerated]
		private Grid advisorComparator;

		// Token: 0x04000654 RID: 1620
		[AccessedThroughProperty("LoadLaunching")]
		[CompilerGenerated]
		private MyLoading m_ObserverComparator;

		// Token: 0x04000655 RID: 1621
		[CompilerGenerated]
		[AccessedThroughProperty("LabLaunchingTitle")]
		private TextBlock m_SingletonComparator;

		// Token: 0x04000656 RID: 1622
		[CompilerGenerated]
		[AccessedThroughProperty("LabLaunchingName")]
		private TextBlock _ContextComparator;

		// Token: 0x04000657 RID: 1623
		[AccessedThroughProperty("ProgressLaunchingFinished")]
		[CompilerGenerated]
		private ColumnDefinition m_CollectionComparator;

		// Token: 0x04000658 RID: 1624
		[AccessedThroughProperty("ProgressLaunchingUnfinished")]
		[CompilerGenerated]
		private ColumnDefinition _ConsumerComparator;

		// Token: 0x04000659 RID: 1625
		[CompilerGenerated]
		[AccessedThroughProperty("PanLaunchingInfo")]
		private Grid filterComparator;

		// Token: 0x0400065A RID: 1626
		[AccessedThroughProperty("LabLaunchingStage")]
		[CompilerGenerated]
		private TextBlock _ReaderComparator;

		// Token: 0x0400065B RID: 1627
		[CompilerGenerated]
		[AccessedThroughProperty("LabLaunchingMethod")]
		private TextBlock _FieldComparator;

		// Token: 0x0400065C RID: 1628
		[CompilerGenerated]
		[AccessedThroughProperty("LabLaunchingProgressLeft")]
		private TextBlock m_PageComparator;

		// Token: 0x0400065D RID: 1629
		[AccessedThroughProperty("LabLaunchingProgress")]
		[CompilerGenerated]
		private TextBlock printerComparator;

		// Token: 0x0400065E RID: 1630
		[AccessedThroughProperty("LabLaunchingDownloadLeft")]
		[CompilerGenerated]
		private TextBlock _TokenComparator;

		// Token: 0x0400065F RID: 1631
		[AccessedThroughProperty("LabLaunchingDownload")]
		[CompilerGenerated]
		private TextBlock interpreterComparator;

		// Token: 0x04000660 RID: 1632
		[AccessedThroughProperty("PanLaunchingHint")]
		[CompilerGenerated]
		private Grid parserComparator;

		// Token: 0x04000661 RID: 1633
		[CompilerGenerated]
		[AccessedThroughProperty("LabLaunchingHint")]
		private TextBlock _StubComparator;

		// Token: 0x04000662 RID: 1634
		[CompilerGenerated]
		[AccessedThroughProperty("BtnCancel")]
		private MyButton errorComparator;

		// Token: 0x04000663 RID: 1635
		private bool exceptionComparator;

		// Token: 0x02000140 RID: 320
		private enum PageType
		{
			// Token: 0x04000665 RID: 1637
			None,
			// Token: 0x04000666 RID: 1638
			Mojang,
			// Token: 0x04000667 RID: 1639
			MojangSkin,
			// Token: 0x04000668 RID: 1640
			Legacy,
			// Token: 0x04000669 RID: 1641
			Nide,
			// Token: 0x0400066A RID: 1642
			NideSkin,
			// Token: 0x0400066B RID: 1643
			Auth,
			// Token: 0x0400066C RID: 1644
			AuthSkin,
			// Token: 0x0400066D RID: 1645
			Ms,
			// Token: 0x0400066E RID: 1646
			MsSkin
		}
	}
}
