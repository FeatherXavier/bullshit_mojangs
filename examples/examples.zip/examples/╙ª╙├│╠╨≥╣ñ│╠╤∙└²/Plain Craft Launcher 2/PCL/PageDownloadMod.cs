﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200008F RID: 143
	[DesignerGenerated]
	public class PageDownloadMod : MyPageRight, IComponentConnector
	{
		// Token: 0x06000416 RID: 1046 RVA: 0x0000418B File Offset: 0x0000238B
		public PageDownloadMod()
		{
			base.Initialized += this.PageDownloadMod_Inited;
			this.InitializeComponent();
		}

		// Token: 0x06000417 RID: 1047 RVA: 0x000260C8 File Offset: 0x000242C8
		private void PageDownloadMod_Inited(object sender, EventArgs e)
		{
			base.PageLoaderInit(this.Load, this.PanLoad, this.CardProjects, this.PanAlways, PageDownloadMod.m_FieldWrapper, delegate(ModLoader.LoaderBase a0)
			{
				this.Load_OnFinish();
			}, new Func<object>(PageDownloadMod.LoaderInput), true);
		}

		// Token: 0x06000418 RID: 1048 RVA: 0x000041AC File Offset: 0x000023AC
		private static ModDownload.DlCfProjectRequest LoaderInput()
		{
			return new ModDownload.DlCfProjectRequest
			{
				identifierProccesor = false
			};
		}

		// Token: 0x06000419 RID: 1049 RVA: 0x00026114 File Offset: 0x00024314
		private void Load_OnFinish()
		{
			try
			{
				this.PanProjects.Children.Clear();
				if (Operators.CompareString(PageDownloadMod.m_FieldWrapper.Input.m_ObjectProccesor, "", true) == 0)
				{
					this.CardProjects.Title = "热门 Mod";
				}
				else
				{
					this.CardProjects.Title = "搜索结果 (" + Conversions.ToString(PageDownloadMod.m_FieldWrapper.Output.m_CallbackProccesor.Count) + (((long)PageDownloadMod.m_FieldWrapper.Output.m_CallbackProccesor.Count < PageDownloadMod.m_FieldWrapper.Output._ObserverProccesor) ? "+" : "") + ")";
				}
				try
				{
					foreach (ModDownload.DlCfProject dlCfProject in PageDownloadMod.m_FieldWrapper.Output.m_CallbackProccesor)
					{
						this.PanProjects.Children.Add(dlCfProject.ToCfItem(delegate(object sender, MouseButtonEventArgs e)
						{
							this.ProjectClick((MyCfItem)sender, e);
						}));
					}
				}
				finally
				{
					List<ModDownload.DlCfProject>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "可视化 Mod 列表出错", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x0600041A RID: 1050 RVA: 0x00026278 File Offset: 0x00024478
		private void Load_State(object sender, MyLoading.MyLoadingState state, MyLoading.MyLoadingState oldState)
		{
			ModBase.LoadState state2 = PageDownloadMod.m_FieldWrapper.State;
			if (state2 == ModBase.LoadState.Failed)
			{
				string text = "";
				if (ModDownload.m_ProductTag.Error != null)
				{
					text = ModDownload.m_ProductTag.Error.Message;
				}
				if (text.Contains("不是有效的 Json 文件"))
				{
					ModBase.Log("[Download] 下载的 Mod 列表 Json 文件损坏，已自动重试", ModBase.LogLevel.Debug, "出现错误");
					base.PageLoaderRestart(null, true);
				}
			}
		}

		// Token: 0x0600041B RID: 1051 RVA: 0x000041BA File Offset: 0x000023BA
		public void ProjectClick(MyCfItem sender, EventArgs e)
		{
			ModMain.m_CollectionAccount.PageChange(new FormMain.PageStackData
			{
				m_CreatorParameter = FormMain.PageType.CfDetail,
				m_ObjectParameter = RuntimeHelpers.GetObjectValue(sender.Tag)
			}, FormMain.PageSubType.Default);
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x000041E4 File Offset: 0x000023E4
		private void TextSearchName_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Return)
			{
				this.StartSearch();
			}
		}

		// Token: 0x0600041D RID: 1053 RVA: 0x000262DC File Offset: 0x000244DC
		private void StartSearch()
		{
			string text = this.TextSearchName.Text;
			ModBase.Log("[Control] Mod 搜索请求输入文本：" + text, ModBase.LogLevel.Normal, "出现错误");
			ModDownload.DlCfProjectRequest input = checked(new ModDownload.DlCfProjectRequest
			{
				m_ObjectProccesor = text,
				_InstanceProccesor = this.TextSearchVersion.Text,
				_ListenerProccesor = (int)Math.Round(ModBase.Val(RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(this.ComboSearchTag.SelectedItem, null, "Tag", new object[0], null, null, null)))),
				identifierProccesor = false,
				_InvocationProccesor = new int?((int)Math.Round(ModBase.Val(RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(this.ComboSearchLoader.SelectedItem, null, "Tag", new object[0], null, null, null)))))
			});
			base.PageLoaderRestart(input, false);
		}

		// Token: 0x0600041E RID: 1054 RVA: 0x000263A8 File Offset: 0x000245A8
		private void BtnSearchReset_Click(object sender, EventArgs e)
		{
			this.TextSearchName.Text = "";
			this.TextSearchVersion.SelectedIndex = 0;
			this.TextSearchVersion.Text = "";
			this.ComboSearchTag.SelectedIndex = 0;
			this.ComboSearchLoader.SelectedIndex = 0;
			PageDownloadMod.m_FieldWrapper.LastFinishedTime = 0L;
		}

		// Token: 0x0600041F RID: 1055 RVA: 0x0002640C File Offset: 0x0002460C
		private void TextSearchVersion_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (Operators.CompareString(this.TextSearchVersion.Text, "", true) == 0)
			{
				this.ComboSearchLoader.Visibility = Visibility.Collapsed;
				Grid.SetColumnSpan(this.TextSearchVersion, 2);
				this.ComboSearchLoader.SelectedIndex = 0;
				return;
			}
			this.ComboSearchLoader.Visibility = Visibility.Visible;
			Grid.SetColumnSpan(this.TextSearchVersion, 1);
		}

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x06000420 RID: 1056 RVA: 0x000041F5 File Offset: 0x000023F5
		// (set) Token: 0x06000421 RID: 1057 RVA: 0x000041FD File Offset: 0x000023FD
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x06000422 RID: 1058 RVA: 0x00004206 File Offset: 0x00002406
		// (set) Token: 0x06000423 RID: 1059 RVA: 0x0000420E File Offset: 0x0000240E
		internal virtual MyCard PanAlways { get; set; }

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x06000424 RID: 1060 RVA: 0x00004217 File Offset: 0x00002417
		// (set) Token: 0x06000425 RID: 1061 RVA: 0x00026470 File Offset: 0x00024670
		internal virtual MyTextBox TextSearchName
		{
			[CompilerGenerated]
			get
			{
				return this.m_TokenWrapper;
			}
			[CompilerGenerated]
			set
			{
				KeyEventHandler value2 = new KeyEventHandler(this.TextSearchName_KeyUp);
				MyTextBox tokenWrapper = this.m_TokenWrapper;
				if (tokenWrapper != null)
				{
					tokenWrapper.KeyUp -= value2;
				}
				this.m_TokenWrapper = value;
				tokenWrapper = this.m_TokenWrapper;
				if (tokenWrapper != null)
				{
					tokenWrapper.KeyUp += value2;
				}
			}
		}

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x06000426 RID: 1062 RVA: 0x0000421F File Offset: 0x0000241F
		// (set) Token: 0x06000427 RID: 1063 RVA: 0x00004227 File Offset: 0x00002427
		internal virtual MyComboBox ComboSearchTag { get; set; }

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x06000428 RID: 1064 RVA: 0x00004230 File Offset: 0x00002430
		// (set) Token: 0x06000429 RID: 1065 RVA: 0x000264B4 File Offset: 0x000246B4
		internal virtual MyComboBox TextSearchVersion
		{
			[CompilerGenerated]
			get
			{
				return this.m_ParserWrapper;
			}
			[CompilerGenerated]
			set
			{
				KeyEventHandler value2 = new KeyEventHandler(this.TextSearchName_KeyUp);
				MyComboBox.TextChangedEventHandler obj = new MyComboBox.TextChangedEventHandler(this.TextSearchVersion_TextChanged);
				MyComboBox parserWrapper = this.m_ParserWrapper;
				if (parserWrapper != null)
				{
					parserWrapper.KeyUp -= value2;
					parserWrapper.VisitModel(obj);
				}
				this.m_ParserWrapper = value;
				parserWrapper = this.m_ParserWrapper;
				if (parserWrapper != null)
				{
					parserWrapper.KeyUp += value2;
					parserWrapper.GetModel(obj);
				}
			}
		}

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x0600042A RID: 1066 RVA: 0x00004238 File Offset: 0x00002438
		// (set) Token: 0x0600042B RID: 1067 RVA: 0x00004240 File Offset: 0x00002440
		internal virtual MyComboBox ComboSearchLoader { get; set; }

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x0600042C RID: 1068 RVA: 0x00004249 File Offset: 0x00002449
		// (set) Token: 0x0600042D RID: 1069 RVA: 0x00026514 File Offset: 0x00024714
		internal virtual MyButton BtnSearchRun
		{
			[CompilerGenerated]
			get
			{
				return this._ErrorWrapper;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.StartSearch();
				};
				MyButton errorWrapper = this._ErrorWrapper;
				if (errorWrapper != null)
				{
					errorWrapper.RevertResolver(obj);
				}
				this._ErrorWrapper = value;
				errorWrapper = this._ErrorWrapper;
				if (errorWrapper != null)
				{
					errorWrapper.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x0600042E RID: 1070 RVA: 0x00004251 File Offset: 0x00002451
		// (set) Token: 0x0600042F RID: 1071 RVA: 0x00026558 File Offset: 0x00024758
		internal virtual MyButton BtnSearchReset
		{
			[CompilerGenerated]
			get
			{
				return this.m_ExceptionWrapper;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnSearchReset_Click);
				MyButton exceptionWrapper = this.m_ExceptionWrapper;
				if (exceptionWrapper != null)
				{
					exceptionWrapper.RevertResolver(obj);
				}
				this.m_ExceptionWrapper = value;
				exceptionWrapper = this.m_ExceptionWrapper;
				if (exceptionWrapper != null)
				{
					exceptionWrapper.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x06000430 RID: 1072 RVA: 0x00004259 File Offset: 0x00002459
		// (set) Token: 0x06000431 RID: 1073 RVA: 0x00004261 File Offset: 0x00002461
		internal virtual MyCard CardProjects { get; set; }

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x06000432 RID: 1074 RVA: 0x0000426A File Offset: 0x0000246A
		// (set) Token: 0x06000433 RID: 1075 RVA: 0x00004272 File Offset: 0x00002472
		internal virtual StackPanel PanProjects { get; set; }

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x06000434 RID: 1076 RVA: 0x0000427B File Offset: 0x0000247B
		// (set) Token: 0x06000435 RID: 1077 RVA: 0x00004283 File Offset: 0x00002483
		internal virtual MyCard PanLoad { get; set; }

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x06000436 RID: 1078 RVA: 0x0000428C File Offset: 0x0000248C
		// (set) Token: 0x06000437 RID: 1079 RVA: 0x0002659C File Offset: 0x0002479C
		internal virtual MyLoading Load
		{
			[CompilerGenerated]
			get
			{
				return this.workerWrapper;
			}
			[CompilerGenerated]
			set
			{
				MyLoading.StateChangedEventHandler obj = new MyLoading.StateChangedEventHandler(this.Load_State);
				MyLoading myLoading = this.workerWrapper;
				if (myLoading != null)
				{
					myLoading.RemoveWrapper(obj);
				}
				this.workerWrapper = value;
				myLoading = this.workerWrapper;
				if (myLoading != null)
				{
					myLoading.InstantiateWrapper(obj);
				}
			}
		}

		// Token: 0x06000438 RID: 1080 RVA: 0x000265E0 File Offset: 0x000247E0
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_DicWrapper)
			{
				this.m_DicWrapper = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagedownload/pagedownloadmod.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000439 RID: 1081 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600043A RID: 1082 RVA: 0x00026610 File Offset: 0x00024810
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanAlways = (MyCard)target;
				return;
			}
			if (connectionId == 3)
			{
				this.TextSearchName = (MyTextBox)target;
				return;
			}
			if (connectionId == 4)
			{
				this.ComboSearchTag = (MyComboBox)target;
				return;
			}
			if (connectionId == 5)
			{
				this.TextSearchVersion = (MyComboBox)target;
				return;
			}
			if (connectionId == 6)
			{
				this.ComboSearchLoader = (MyComboBox)target;
				return;
			}
			if (connectionId == 7)
			{
				this.BtnSearchRun = (MyButton)target;
				return;
			}
			if (connectionId == 8)
			{
				this.BtnSearchReset = (MyButton)target;
				return;
			}
			if (connectionId == 9)
			{
				this.CardProjects = (MyCard)target;
				return;
			}
			if (connectionId == 10)
			{
				this.PanProjects = (StackPanel)target;
				return;
			}
			if (connectionId == 11)
			{
				this.PanLoad = (MyCard)target;
				return;
			}
			if (connectionId == 12)
			{
				this.Load = (MyLoading)target;
				return;
			}
			this.m_DicWrapper = true;
		}

		// Token: 0x0400020A RID: 522
		private static ModLoader.LoaderTask<ModDownload.DlCfProjectRequest, ModDownload.DlCfProjectResult> m_FieldWrapper = new ModLoader.LoaderTask<ModDownload.DlCfProjectRequest, ModDownload.DlCfProjectResult>("DlCfProject Mod", new Action<ModLoader.LoaderTask<ModDownload.DlCfProjectRequest, ModDownload.DlCfProjectResult>>(ModDownload.DlCfProjectSub), new Func<ModDownload.DlCfProjectRequest>(PageDownloadMod.LoaderInput), ThreadPriority.Normal)
		{
			ReloadTimeout = 60000
		};

		// Token: 0x0400020B RID: 523
		[CompilerGenerated]
		[AccessedThroughProperty("PanBack")]
		private MyScrollViewer m_PageWrapper;

		// Token: 0x0400020C RID: 524
		[CompilerGenerated]
		[AccessedThroughProperty("PanAlways")]
		private MyCard printerWrapper;

		// Token: 0x0400020D RID: 525
		[AccessedThroughProperty("TextSearchName")]
		[CompilerGenerated]
		private MyTextBox m_TokenWrapper;

		// Token: 0x0400020E RID: 526
		[CompilerGenerated]
		[AccessedThroughProperty("ComboSearchTag")]
		private MyComboBox m_InterpreterWrapper;

		// Token: 0x0400020F RID: 527
		[CompilerGenerated]
		[AccessedThroughProperty("TextSearchVersion")]
		private MyComboBox m_ParserWrapper;

		// Token: 0x04000210 RID: 528
		[AccessedThroughProperty("ComboSearchLoader")]
		[CompilerGenerated]
		private MyComboBox stubWrapper;

		// Token: 0x04000211 RID: 529
		[AccessedThroughProperty("BtnSearchRun")]
		[CompilerGenerated]
		private MyButton _ErrorWrapper;

		// Token: 0x04000212 RID: 530
		[AccessedThroughProperty("BtnSearchReset")]
		[CompilerGenerated]
		private MyButton m_ExceptionWrapper;

		// Token: 0x04000213 RID: 531
		[AccessedThroughProperty("CardProjects")]
		[CompilerGenerated]
		private MyCard _TestsWrapper;

		// Token: 0x04000214 RID: 532
		[AccessedThroughProperty("PanProjects")]
		[CompilerGenerated]
		private StackPanel m_StrategyWrapper;

		// Token: 0x04000215 RID: 533
		[AccessedThroughProperty("PanLoad")]
		[CompilerGenerated]
		private MyCard rulesWrapper;

		// Token: 0x04000216 RID: 534
		[AccessedThroughProperty("Load")]
		[CompilerGenerated]
		private MyLoading workerWrapper;

		// Token: 0x04000217 RID: 535
		private bool m_DicWrapper;
	}
}
