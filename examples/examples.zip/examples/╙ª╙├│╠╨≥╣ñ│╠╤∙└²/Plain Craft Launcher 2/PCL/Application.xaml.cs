﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Windows;
using System.Windows.Threading;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.ApplicationServices;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000168 RID: 360
	public partial class Application : Application
	{
		// Token: 0x0600108B RID: 4235 RVA: 0x000715E8 File Offset: 0x0006F7E8
		public Application()
		{
			base.Startup += this.Application_Startup;
			base.SessionEnding += this.Application_SessionEnding;
			base.DispatcherUnhandledException += this.Application_DispatcherUnhandledException;
			this.m_AnnotationIssuer = false;
		}

		// Token: 0x0600108C RID: 4236 RVA: 0x00071638 File Offset: 0x0006F838
		private void Application_Startup(object sender, System.Windows.StartupEventArgs e)
		{
			ModBase._MockState = ModBase.GetTimeTick();
			if (new FileInfo(ModBase.Path + AppDomain.CurrentDomain.SetupInformation.ApplicationName).Length > 3145728L)
			{
				Environment.Exit(0);
			}
			Thread.CurrentThread.Priority = ThreadPriority.Highest;
			base.Dispatcher.InvokeAsync((Application._Closure$__.$I2-0 == null) ? (Application._Closure$__.$I2-0 = delegate()
			{
			}) : Application._Closure$__.$I2-0);
			if (!ModBase.CheckPermission(ModBase.Path))
			{
				Interaction.MsgBox("PCL2 没有当前文件夹的写入权限，请尝试：\r\n1. 将 PCL2 移动到其他文件夹" + (ModBase.Path.StartsWith("C:") ? "，例如 C 盘和桌面以外的其他位置。" : "。") + "\r\n2. 右键 PCL2 文件选择属性，打开 兼容性 中的 以管理员身份运行此程序。", MsgBoxStyle.Critical, "运行环境错误");
				Environment.Exit(4);
			}
			Directory.CreateDirectory(ModBase.Path + "PCL");
			if (!ModBase.CheckPermission(ModBase.Path + "PCL"))
			{
				Interaction.MsgBox("PCL2 没有对 PCL 文件夹的写入权限，请尝试：\r\n1. 将 PCL2 移动到其他文件夹" + (ModBase.Path.StartsWith("C:") ? "，例如 C 盘和桌面以外的其他位置。" : "。") + "\r\n2. 删除当前目录中的 PCL 文件夹，然后再试。\r\n3. 右键 PCL 选择属性，打开 兼容性 中的 以管理员身份运行此程序。", MsgBoxStyle.Critical, "运行环境错误");
				Environment.Exit(4);
			}
			ModBase._InfoState = ModBase._InfoState + "qgaq".ToUpper() + "1S";
			checked
			{
				try
				{
					if (e.Args.Length > 0)
					{
						if (Operators.CompareString(e.Args[0], "--update", true) == 0)
						{
							ModMain.UpdateReplace(Conversions.ToInteger(e.Args[1]), e.Args[2].Trim(new char[]
							{
								'"'
							}), e.Args[3].Trim(new char[]
							{
								'"'
							}), Conversions.ToBoolean(e.Args[4]));
							Environment.Exit(4);
							return;
						}
						if (Operators.CompareString(e.Args[0], "--link", true) == 0)
						{
							Thread.Sleep(1000);
							FormMain._ModelAccount = true;
						}
					}
					Directory.CreateDirectory(ModBase.Path + "PCL\\Pictures");
					Directory.CreateDirectory(ModBase.Path + "PCL\\Musics");
					try
					{
						Directory.CreateDirectory(ModBase.attributeState);
						if (!ModBase.CheckPermission(ModBase.attributeState))
						{
							throw new Exception("PCL2 没有对 " + ModBase.attributeState + " 的访问权限");
						}
					}
					catch (Exception ex)
					{
						ModMain.MyMsgBox("手动设置的缓存文件夹不可用，PCL2 将使用默认缓存文件夹。\r\n错误原因：" + ModBase.GetString(ex, false, false), "缓存文件夹不可用", "确定", "", "", false, true, false);
						ModBase._ParamsState.Set("SystemSystemCache", "", false, null);
						ModBase.attributeState = Path.GetTempPath() + "PCL\\";
					}
					Directory.CreateDirectory(ModBase.attributeState + "Cache");
					Directory.CreateDirectory(ModBase.attributeState + "Download");
					string text = null;
					string text2 = "Plain Craft Launcher 2\u3000";
					IntPtr intPtr = ModMain.FindWindowA(ref text, ref text2);
					if (intPtr != IntPtr.Zero)
					{
						ModMain.ShowWindowToTop(intPtr);
						Interaction.Beep();
						Environment.Exit(4);
					}
					else
					{
						if (Conversions.ToBoolean(Conversions.ToBoolean(ModBase._ParamsState.Get("UiLauncherLogo", null)) && !FormMain._ModelAccount))
						{
							ModMain.consumerAccount = new SplashScreen("Images\\icon.ico");
							ModMain.consumerAccount.Show(false, true);
						}
						AppDomain.CurrentDomain.AssemblyResolve += Application.AssemblyResolve;
						ModBase.LogStart();
						ModBase.Log("[Start] 程序版本：Release 2.2.9（" + Conversions.ToString(246) + "）", ModBase.LogLevel.Normal, "出现错误");
						ModBase.Log("[Start] 识别码：" + ModBase.initializerState + (ModMain.AssetTag(9) ? "，已解锁反馈主题" : ""), ModBase.LogLevel.Normal, "出现错误");
						ModBase.Log("[Start] 程序路径：" + ModBase.Path, ModBase.LogLevel.Normal, "出现错误");
						if (ModBase.Path.Contains(Path.GetTempPath()) || ModBase.Path.Contains("AppData\\Local\\Temp\\"))
						{
							ModBase.Log("[Start] PCL2 正在临时文件夹运行，设置、游戏存档等很可能无法保存，且部分功能将无法使用。\r\n请将 PCL2 从压缩文件中解压，或是更换文件夹后再继续使用！", ModBase.LogLevel.Msgbox, "警告");
						}
						ModBase._ParamsState.Load("SystemDebugMode", false, null);
						ModBase._ParamsState.Load("SystemDebugAnim", false, null);
						ModBase._ParamsState.Load("ToolDownloadThread", false, null);
						ServicePointManager.SecurityProtocol = (SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12);
						ServicePointManager.DefaultConnectionLimit = 1024;
						ServicePointManager.ServerCertificateValidationCallback = ((Application._Closure$__.$IR2-1 == null) ? (Application._Closure$__.$IR2-1 = ((object a0, X509Certificate a1, X509Chain a2, SslPolicyErrors a3) => ((Application._Closure$__.$I2-1 == null) ? (Application._Closure$__.$I2-1 = (() => true)) : Application._Closure$__.$I2-1)())) : Application._Closure$__.$IR2-1);
						ModBase.Log("[Start] 第一阶段加载用时：" + Conversions.ToString(ModBase.GetTimeTick() - ModBase._MockState) + " ms", ModBase.LogLevel.Normal, "出现错误");
						ModBase._MockState = ModBase.GetTimeTick();
						ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
					}
				}
				catch (Exception ex2)
				{
					Interaction.MsgBox(ModBase.GetString(ex2, false, true), MsgBoxStyle.Critical, "PCL2 初始化错误");
					FormMain.EndProgramForce(ModBase.Result.Exception);
				}
			}
		}

		// Token: 0x0600108D RID: 4237 RVA: 0x00003CD2 File Offset: 0x00001ED2
		private void Application_SessionEnding(object sender, SessionEndingCancelEventArgs e)
		{
			ModMain.m_CollectionAccount.EndProgram(false);
		}

		// Token: 0x0600108E RID: 4238 RVA: 0x00071B70 File Offset: 0x0006FD70
		private void Application_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
		{
			int num;
			int num4;
			object obj;
			try
			{
				IL_00:
				ProjectData.ClearProjectError();
				num = 1;
				IL_07:
				int num2 = 2;
				e.Handled = true;
				IL_10:
				num2 = 3;
				if (ModBase.m_SystemState)
				{
					goto IL_D2;
				}
				IL_1C:
				num2 = 5;
				if (!this.m_AnnotationIssuer)
				{
					goto IL_33;
				}
				IL_26:
				num2 = 6;
				FormMain.EndProgramForce(ModBase.Result.Exception);
				goto IL_D2;
				IL_33:
				num2 = 8;
				this.m_AnnotationIssuer = true;
				IL_3C:
				num2 = 9;
				string @string = ModBase.GetString(e.Exception, false, true);
				IL_4D:
				num2 = 10;
				if (@string.Contains("System.Windows.Threading.Dispatcher.Invoke") || @string.Contains("MS.Internal.AppModel.ITaskbarList.HrInit") || @string.Contains(".Net Framework 4.5") || @string.Contains("未能加载文件或程序集"))
				{
					goto IL_A7;
				}
				IL_84:
				num2 = 15;
				ModBase.FeedbackInfo();
				IL_8C:
				num2 = 16;
				ModBase.Log(e.Exception, "程序出现未知错误", ModBase.LogLevel.Assert, "锟斤拷烫烫烫");
				goto IL_D2;
				IL_A7:
				num2 = 11;
				ModBase.OpenWebsite("https://www.microsoft.com/zh-CN/download/details.aspx?id=30653");
				IL_B4:
				num2 = 12;
				Interaction.MsgBox("你的 .Net Framework 版本过低或损坏，请在打开的网页中重新下载并安装 .Net Framework 4.5 后重试！", MsgBoxStyle.Information, "运行环境错误");
				IL_C9:
				num2 = 13;
				FormMain.EndProgramForce(ModBase.Result.Cancel);
				IL_D2:
				goto IL_168;
				IL_D7:
				int num3 = num4 + 1;
				num4 = 0;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
				IL_129:
				goto IL_15D;
				IL_12B:
				num4 = num2;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
				IL_13B:;
			}
			catch when (endfilter(obj is Exception & num != 0 & num4 == 0))
			{
				Exception ex = (Exception)obj2;
				goto IL_12B;
			}
			IL_15D:
			throw ProjectData.CreateProjectError(-2146828237);
			IL_168:
			if (num4 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		// Token: 0x0600108F RID: 4239 RVA: 0x00071D0C File Offset: 0x0006FF0C
		public static Assembly AssemblyResolve(object sender, ResolveEventArgs args)
		{
			if (args.Name.StartsWith("NAudio"))
			{
				object proxyIssuer = Application.m_ProxyIssuer;
				ObjectFlowControl.CheckForSyncLockOnValueType(proxyIssuer);
				lock (proxyIssuer)
				{
					if (Application.refIssuer == null)
					{
						ModBase.Log("[Start] 加载 DLL：NAudio", ModBase.LogLevel.Normal, "出现错误");
						Application.refIssuer = Assembly.Load(ModBase.GetResources("NAudio"));
					}
					return Application.refIssuer;
				}
			}
			if (args.Name.StartsWith("Newtonsoft.Json"))
			{
				object obj = Application.classIssuer;
				ObjectFlowControl.CheckForSyncLockOnValueType(obj);
				lock (obj)
				{
					if (Application.m_ServerIssuer == null)
					{
						ModBase.Log("[Start] 加载 DLL：Json", ModBase.LogLevel.Normal, "出现错误");
						Application.m_ServerIssuer = Assembly.Load(ModBase.GetResources("Json"));
					}
					return Application.m_ServerIssuer;
				}
			}
			if (args.Name.StartsWith("Ookii.Dialogs.Wpf"))
			{
				object obj2 = Application.registryIssuer;
				ObjectFlowControl.CheckForSyncLockOnValueType(obj2);
				lock (obj2)
				{
					if (Application.serviceIssuer == null)
					{
						ModBase.Log("[Start] 加载 DLL：Dialogs", ModBase.LogLevel.Normal, "出现错误");
						Application.serviceIssuer = Assembly.Load(ModBase.GetResources("Dialogs"));
					}
					return Application.serviceIssuer;
				}
			}
			if (args.Name.StartsWith("STUN"))
			{
				object importerIssuer = Application._ImporterIssuer;
				ObjectFlowControl.CheckForSyncLockOnValueType(importerIssuer);
				lock (importerIssuer)
				{
					if (Application.m_InterceptorIssuer == null)
					{
						ModBase.Log("[Start] 加载 DLL：STUN", ModBase.LogLevel.Normal, "出现错误");
						Application.m_InterceptorIssuer = Assembly.Load(ModBase.GetResources("STUN"));
					}
					return Application.m_InterceptorIssuer;
				}
			}
			return null;
		}

		// Token: 0x06001090 RID: 4240 RVA: 0x00071EF8 File Offset: 0x000700F8
		private void MyIconButton_Click(object sender, EventArgs e)
		{
			if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LoginType", null), ModLaunch.McLoginType.Legacy, true))
			{
				List<string> list = new List<string>();
				list.AddRange(ModBase._ParamsState.Get("LoginLegacyName", null).ToString().Split(new char[]
				{
					'¨'
				}));
				list.Remove(Conversions.ToString(NewLateBinding.LateGet(sender, null, "Tag", new object[0], null, null, null)));
				ModBase._ParamsState.Set("LoginLegacyName", ModBase.Join(list, "¨"), false, null);
				ModMain._ImporterAccount.ComboName.ItemsSource = list;
				ModMain._ImporterAccount.ComboName.Text = ((list.Count > 0) ? list[0] : "");
				return;
			}
			string stringFromEnum = ModBase.GetStringFromEnum((Enum)ModBase._ParamsState.Get("LoginType", null));
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			List<string> list2 = new List<string>();
			List<string> list3 = new List<string>();
			if (Conversions.ToBoolean(Operators.NotObject(Operators.CompareObjectEqual(ModBase._ParamsState.Get("Login" + stringFromEnum + "Email", null), "", true))))
			{
				list2.AddRange(ModBase._ParamsState.Get("Login" + stringFromEnum + "Email", null).ToString().Split(new char[]
				{
					'¨'
				}));
			}
			if (Conversions.ToBoolean(Operators.NotObject(Operators.CompareObjectEqual(ModBase._ParamsState.Get("Login" + stringFromEnum + "Pass", null), "", true))))
			{
				list3.AddRange(ModBase._ParamsState.Get("Login" + stringFromEnum + "Pass", null).ToString().Split(new char[]
				{
					'¨'
				}));
			}
			checked
			{
				int num = list2.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					dictionary.Add(list2[i], list3[i]);
				}
				dictionary.Remove(Conversions.ToString(NewLateBinding.LateGet(sender, null, "Tag", new object[0], null, null, null)));
				ModBase._ParamsState.Set("Login" + stringFromEnum + "Email", ModBase.Join(dictionary.Keys.ToArray<string>(), "¨"), false, null);
				ModBase._ParamsState.Set("Login" + stringFromEnum + "Pass", ModBase.Join(dictionary.Values.ToArray<string>(), "¨"), false, null);
				string left = stringFromEnum;
				if (Operators.CompareString(left, "Mojang", true) == 0)
				{
					ModMain._ServerAccount.ComboName.ItemsSource = dictionary.Keys;
					ModMain._ServerAccount.ComboName.Text = ((dictionary.Keys.Count > 0) ? dictionary.Keys.ElementAtOrDefault(0) : "");
					ModMain._ServerAccount.TextPass.Password = ((dictionary.Values.Count > 0) ? dictionary.Values.ElementAtOrDefault(0) : "");
					return;
				}
				if (Operators.CompareString(left, "Nide", true) == 0)
				{
					ModMain._ProxyAccount.ComboName.ItemsSource = dictionary.Keys;
					ModMain._ProxyAccount.ComboName.Text = ((dictionary.Keys.Count > 0) ? dictionary.Keys.ElementAtOrDefault(0) : "");
					ModMain._ProxyAccount.TextPass.Password = ((dictionary.Values.Count > 0) ? dictionary.Values.ElementAtOrDefault(0) : "");
					return;
				}
				if (Operators.CompareString(left, "Auth", true) == 0)
				{
					ModMain.m_RegistryAccount.ComboName.ItemsSource = dictionary.Keys;
					ModMain.m_RegistryAccount.ComboName.Text = ((dictionary.Keys.Count > 0) ? dictionary.Keys.ElementAtOrDefault(0) : "");
					ModMain.m_RegistryAccount.TextPass.Password = ((dictionary.Values.Count > 0) ? dictionary.Values.ElementAtOrDefault(0) : "");
					return;
				}
				ModBase.DebugAssert(true);
			}
		}

		// Token: 0x170002D2 RID: 722
		// (get) Token: 0x06001091 RID: 4241 RVA: 0x00009D57 File Offset: 0x00007F57
		internal AssemblyInfo Info
		{
			get
			{
				return new AssemblyInfo(Assembly.GetExecutingAssembly());
			}
		}

		// Token: 0x04000829 RID: 2089
		private bool m_AnnotationIssuer;

		// Token: 0x0400082A RID: 2090
		private static Assembly m_InterceptorIssuer;

		// Token: 0x0400082B RID: 2091
		private static Assembly refIssuer;

		// Token: 0x0400082C RID: 2092
		private static Assembly m_ServerIssuer;

		// Token: 0x0400082D RID: 2093
		private static Assembly serviceIssuer;

		// Token: 0x0400082E RID: 2094
		private static readonly object _ImporterIssuer = RuntimeHelpers.GetObjectValue(new object());

		// Token: 0x0400082F RID: 2095
		private static readonly object m_ProxyIssuer = RuntimeHelpers.GetObjectValue(new object());

		// Token: 0x04000830 RID: 2096
		private static readonly object classIssuer = RuntimeHelpers.GetObjectValue(new object());

		// Token: 0x04000831 RID: 2097
		private static readonly object registryIssuer = RuntimeHelpers.GetObjectValue(new object());
	}
}
