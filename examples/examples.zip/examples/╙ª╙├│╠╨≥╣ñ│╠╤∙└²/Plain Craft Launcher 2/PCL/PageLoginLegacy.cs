﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200012F RID: 303
	[DesignerGenerated]
	public class PageLoginLegacy : Grid, IComponentConnector
	{
		// Token: 0x06000B95 RID: 2965 RVA: 0x00007BA6 File Offset: 0x00005DA6
		public PageLoginLegacy()
		{
			base.Loaded += this.PageLoginLegacy_Loaded;
			this.definitionComparator = false;
			this.InitializeComponent();
			this.Skin.m_RepositoryComparator = PageLaunchLeft._StructComparator;
		}

		// Token: 0x06000B96 RID: 2966 RVA: 0x00007BDE File Offset: 0x00005DDE
		private void PageLoginLegacy_Loaded(object sender, RoutedEventArgs e)
		{
			this.Skin.m_RepositoryComparator.Start(null, false);
		}

		// Token: 0x06000B97 RID: 2967 RVA: 0x0005B800 File Offset: 0x00059A00
		public void Reload(bool KeepInput)
		{
			if (KeepInput && this.definitionComparator)
			{
				string text = this.ComboName.Text;
				this.ComboName.ItemsSource = (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LoginLegacyName", null), "", true) ? null : ModBase._ParamsState.Get("LoginLegacyName", null).ToString().Split(new char[]
				{
					'¨'
				}));
				this.ComboName.Text = text;
			}
			else if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LoginLegacyName", null), "", true))
			{
				this.ComboName.ItemsSource = null;
			}
			else
			{
				this.ComboName.ItemsSource = ModBase._ParamsState.Get("LoginLegacyName", null).ToString().Split(new char[]
				{
					'¨'
				});
				this.ComboName.Text = ModBase._ParamsState.Get("LoginLegacyName", null).ToString().Split(new char[]
				{
					'¨'
				})[0];
			}
			this.definitionComparator = true;
		}

		// Token: 0x06000B98 RID: 2968 RVA: 0x0005B924 File Offset: 0x00059B24
		public static ModLaunch.McLoginLegacy GetLoginData()
		{
			ModLaunch.McLoginLegacy result;
			if (ModMain._ImporterAccount == null)
			{
				result = new ModLaunch.McLoginLegacy
				{
					_ConfigurationProccesor = "",
					m_ConfigProccesor = Conversions.ToInteger(ModBase._ParamsState.Get("LaunchSkinType", null)),
					managerProccesor = Conversions.ToString(ModBase._ParamsState.Get("LaunchSkinID", null))
				};
			}
			else
			{
				result = new ModLaunch.McLoginLegacy
				{
					_ConfigurationProccesor = ModMain._ImporterAccount.ComboName.Text.Replace("¨", "").Trim(),
					m_ConfigProccesor = Conversions.ToInteger(ModBase._ParamsState.Get("LaunchSkinType", null)),
					managerProccesor = Conversions.ToString(ModBase._ParamsState.Get("LaunchSkinID", null))
				};
			}
			return result;
		}

		// Token: 0x06000B99 RID: 2969 RVA: 0x0005B9E8 File Offset: 0x00059BE8
		public static string IsVaild(ModLaunch.McLoginLegacy LoginData)
		{
			string result;
			if (Operators.CompareString(LoginData._ConfigurationProccesor.Trim(), "", true) == 0)
			{
				result = "玩家名不能为空！";
			}
			else if (LoginData._ConfigurationProccesor.Contains("\""))
			{
				result = "玩家名不能包含英文引号！";
			}
			else
			{
				result = "";
			}
			return result;
		}

		// Token: 0x06000B9A RID: 2970 RVA: 0x00007BF2 File Offset: 0x00005DF2
		public string IsVaild()
		{
			return PageLoginLegacy.IsVaild(PageLoginLegacy.GetLoginData());
		}

		// Token: 0x06000B9B RID: 2971 RVA: 0x00007BFE File Offset: 0x00005DFE
		private void ComboLegacy_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LaunchSkinType", null), 0, true))
			{
				PageLaunchLeft._StructComparator.Start(null, true);
			}
		}

		// Token: 0x06000B9C RID: 2972 RVA: 0x0005BA38 File Offset: 0x00059C38
		private void Skin_Click()
		{
			if (Conversions.ToBoolean((Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenPageSetup", null)) || Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupLaunch", null))) && !PageSetupUI.AwakeResolver()))
			{
				ModMain.Hint("启动设置已被禁用！", ModMain.HintType.Critical, true);
				return;
			}
			ModMain.m_CollectionAccount.PageChange(FormMain.PageType.Setup, FormMain.PageSubType.Default);
		}

		// Token: 0x170001AC RID: 428
		// (get) Token: 0x06000B9D RID: 2973 RVA: 0x00007C2A File Offset: 0x00005E2A
		// (set) Token: 0x06000B9E RID: 2974 RVA: 0x0005BAA8 File Offset: 0x00059CA8
		internal virtual MyComboBox ComboName
		{
			[CompilerGenerated]
			get
			{
				return this.paramsComparator;
			}
			[CompilerGenerated]
			set
			{
				MyComboBox.TextChangedEventHandler obj = new MyComboBox.TextChangedEventHandler(this.ComboLegacy_TextChanged);
				MyComboBox myComboBox = this.paramsComparator;
				if (myComboBox != null)
				{
					myComboBox.VisitModel(obj);
				}
				this.paramsComparator = value;
				myComboBox = this.paramsComparator;
				if (myComboBox != null)
				{
					myComboBox.GetModel(obj);
				}
			}
		}

		// Token: 0x170001AD RID: 429
		// (get) Token: 0x06000B9F RID: 2975 RVA: 0x00007C32 File Offset: 0x00005E32
		// (set) Token: 0x06000BA0 RID: 2976 RVA: 0x0005BAEC File Offset: 0x00059CEC
		internal virtual MySkin Skin
		{
			[CompilerGenerated]
			get
			{
				return this._MockComparator;
			}
			[CompilerGenerated]
			set
			{
				MySkin.ClickEventHandler obj = delegate(object sender, MouseButtonEventArgs e)
				{
					this.Skin_Click();
				};
				MySkin mockComparator = this._MockComparator;
				if (mockComparator != null)
				{
					mockComparator.ResolveResolver(obj);
				}
				this._MockComparator = value;
				mockComparator = this._MockComparator;
				if (mockComparator != null)
				{
					mockComparator.VerifyResolver(obj);
				}
			}
		}

		// Token: 0x06000BA1 RID: 2977 RVA: 0x0005BB30 File Offset: 0x00059D30
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.adapterComparator)
			{
				this.adapterComparator = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagelaunch/pageloginlegacy.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000BA2 RID: 2978 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000BA3 RID: 2979 RVA: 0x00007C3A File Offset: 0x00005E3A
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.ComboName = (MyComboBox)target;
				return;
			}
			if (connectionId == 2)
			{
				this.Skin = (MySkin)target;
				return;
			}
			this.adapterComparator = true;
		}

		// Token: 0x040005FC RID: 1532
		public bool definitionComparator;

		// Token: 0x040005FD RID: 1533
		[CompilerGenerated]
		[AccessedThroughProperty("ComboName")]
		private MyComboBox paramsComparator;

		// Token: 0x040005FE RID: 1534
		[AccessedThroughProperty("Skin")]
		[CompilerGenerated]
		private MySkin _MockComparator;

		// Token: 0x040005FF RID: 1535
		private bool adapterComparator;
	}
}
