﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000124 RID: 292
	[DesignerGenerated]
	public class PageDownloadOptiFine : MyPageRight, IComponentConnector
	{
		// Token: 0x06000AB7 RID: 2743 RVA: 0x0000745E File Offset: 0x0000565E
		public PageDownloadOptiFine()
		{
			base.Initialized += delegate(object sender, EventArgs e)
			{
				this.LoaderInit();
			};
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.Init();
			};
			this.InitializeComponent();
		}

		// Token: 0x06000AB8 RID: 2744 RVA: 0x000563DC File Offset: 0x000545DC
		private void LoaderInit()
		{
			base.PageLoaderInit(this.Load, this.PanLoad, this.PanMain, this.CardTip, ModDownload.m_AlgoTag, delegate(ModLoader.LoaderBase a0)
			{
				this.Load_OnFinish();
			}, null, true);
		}

		// Token: 0x06000AB9 RID: 2745 RVA: 0x00007491 File Offset: 0x00005691
		private void Init()
		{
			this.PanBack.ScrollToHome();
		}

		// Token: 0x06000ABA RID: 2746 RVA: 0x0005641C File Offset: 0x0005461C
		private void Load_OnFinish()
		{
			checked
			{
				try
				{
					Dictionary<string, List<ModDownload.DlOptiFineListEntry>> dictionary = new Dictionary<string, List<ModDownload.DlOptiFineListEntry>>();
					dictionary.Add("快照版本", new List<ModDownload.DlOptiFineListEntry>());
					int num = 30;
					do
					{
						dictionary.Add("1." + Conversions.ToString(num), new List<ModDownload.DlOptiFineListEntry>());
						num += -1;
					}
					while (num >= 0);
					try
					{
						foreach (ModDownload.DlOptiFineListEntry dlOptiFineListEntry in ModDownload.m_AlgoTag.Output.Value)
						{
							if (dlOptiFineListEntry.CustomizeComparator().StartsWith("1."))
							{
								string key = "1." + dlOptiFineListEntry.m_SerializerProccesor.Split(new char[]
								{
									'.'
								})[1].Split(new char[]
								{
									' '
								})[0];
								if (dictionary.ContainsKey(key))
								{
									dictionary[key].Add(dlOptiFineListEntry);
								}
								else
								{
									dictionary["快照版本"].Add(dlOptiFineListEntry);
								}
							}
							else
							{
								dictionary["快照版本"].Add(dlOptiFineListEntry);
							}
						}
					}
					finally
					{
						List<ModDownload.DlOptiFineListEntry>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
					this.PanMain.Children.Clear();
					try
					{
						foreach (KeyValuePair<string, List<ModDownload.DlOptiFineListEntry>> keyValuePair in dictionary)
						{
							if (keyValuePair.Value.Count != 0)
							{
								MyCard myCard = new MyCard();
								myCard.Title = keyValuePair.Key + " (" + Conversions.ToString(keyValuePair.Value.Count) + ")";
								myCard.Margin = new Thickness(0.0, 0.0, 0.0, 15.0);
								myCard.CustomizeModel(3);
								MyCard myCard2 = myCard;
								StackPanel stackPanel = new StackPanel
								{
									Margin = new Thickness(20.0, 40.0, 18.0, 0.0),
									VerticalAlignment = VerticalAlignment.Top,
									RenderTransform = new TranslateTransform(0.0, 0.0),
									Tag = keyValuePair.Value
								};
								myCard2.Children.Add(stackPanel);
								myCard2.m_Decorator = stackPanel;
								myCard2.IsSwaped = true;
								this.PanMain.Children.Add(myCard2);
							}
						}
					}
					finally
					{
						Dictionary<string, List<ModDownload.DlOptiFineListEntry>>.Enumerator enumerator2;
						((IDisposable)enumerator2).Dispose();
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "可视化版本列表出错", ModBase.LogLevel.Feedback, "出现错误");
				}
			}
		}

		// Token: 0x06000ABB RID: 2747 RVA: 0x0000749E File Offset: 0x0000569E
		public void DownloadStart(MyListItem sender, object e)
		{
			ModDownloadLib.McDownloadOptiFine((ModDownload.DlOptiFineListEntry)sender.Tag);
		}

		// Token: 0x06000ABC RID: 2748 RVA: 0x000074B0 File Offset: 0x000056B0
		private void BtnWeb_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://www.optifine.net/");
		}

		// Token: 0x06000ABD RID: 2749 RVA: 0x000074BC File Offset: 0x000056BC
		private void BtnChina_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://optifine.cn/home");
		}

		// Token: 0x1700017C RID: 380
		// (get) Token: 0x06000ABE RID: 2750 RVA: 0x000074C8 File Offset: 0x000056C8
		// (set) Token: 0x06000ABF RID: 2751 RVA: 0x000074D0 File Offset: 0x000056D0
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x1700017D RID: 381
		// (get) Token: 0x06000AC0 RID: 2752 RVA: 0x000074D9 File Offset: 0x000056D9
		// (set) Token: 0x06000AC1 RID: 2753 RVA: 0x000074E1 File Offset: 0x000056E1
		internal virtual MyCard CardTip { get; set; }

		// Token: 0x1700017E RID: 382
		// (get) Token: 0x06000AC2 RID: 2754 RVA: 0x000074EA File Offset: 0x000056EA
		// (set) Token: 0x06000AC3 RID: 2755 RVA: 0x000074F2 File Offset: 0x000056F2
		internal virtual TextBlock LabConnect { get; set; }

		// Token: 0x1700017F RID: 383
		// (get) Token: 0x06000AC4 RID: 2756 RVA: 0x000074FB File Offset: 0x000056FB
		// (set) Token: 0x06000AC5 RID: 2757 RVA: 0x000566F0 File Offset: 0x000548F0
		internal virtual MyButton BtnChina
		{
			[CompilerGenerated]
			get
			{
				return this.pageTag;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnChina_Click);
				MyButton myButton = this.pageTag;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.pageTag = value;
				myButton = this.pageTag;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000180 RID: 384
		// (get) Token: 0x06000AC6 RID: 2758 RVA: 0x00007503 File Offset: 0x00005703
		// (set) Token: 0x06000AC7 RID: 2759 RVA: 0x00056734 File Offset: 0x00054934
		internal virtual MyButton BtnWeb
		{
			[CompilerGenerated]
			get
			{
				return this.m_PrinterTag;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnWeb_Click);
				MyButton printerTag = this.m_PrinterTag;
				if (printerTag != null)
				{
					printerTag.RevertResolver(obj);
				}
				this.m_PrinterTag = value;
				printerTag = this.m_PrinterTag;
				if (printerTag != null)
				{
					printerTag.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000181 RID: 385
		// (get) Token: 0x06000AC8 RID: 2760 RVA: 0x0000750B File Offset: 0x0000570B
		// (set) Token: 0x06000AC9 RID: 2761 RVA: 0x00007513 File Offset: 0x00005713
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x17000182 RID: 386
		// (get) Token: 0x06000ACA RID: 2762 RVA: 0x0000751C File Offset: 0x0000571C
		// (set) Token: 0x06000ACB RID: 2763 RVA: 0x00007524 File Offset: 0x00005724
		internal virtual MyCard PanLoad { get; set; }

		// Token: 0x17000183 RID: 387
		// (get) Token: 0x06000ACC RID: 2764 RVA: 0x0000752D File Offset: 0x0000572D
		// (set) Token: 0x06000ACD RID: 2765 RVA: 0x00007535 File Offset: 0x00005735
		internal virtual MyLoading Load { get; set; }

		// Token: 0x06000ACE RID: 2766 RVA: 0x00056778 File Offset: 0x00054978
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this._StubTag)
			{
				this._StubTag = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagedownload/pagedownloadoptifine.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000ACF RID: 2767 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000AD0 RID: 2768 RVA: 0x000567A8 File Offset: 0x000549A8
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.CardTip = (MyCard)target;
				return;
			}
			if (connectionId == 3)
			{
				this.LabConnect = (TextBlock)target;
				return;
			}
			if (connectionId == 4)
			{
				this.BtnChina = (MyButton)target;
				return;
			}
			if (connectionId == 5)
			{
				this.BtnWeb = (MyButton)target;
				return;
			}
			if (connectionId == 6)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			if (connectionId == 7)
			{
				this.PanLoad = (MyCard)target;
				return;
			}
			if (connectionId == 8)
			{
				this.Load = (MyLoading)target;
				return;
			}
			this._StubTag = true;
		}

		// Token: 0x040005B5 RID: 1461
		[CompilerGenerated]
		[AccessedThroughProperty("PanBack")]
		private MyScrollViewer _FilterTag;

		// Token: 0x040005B6 RID: 1462
		[CompilerGenerated]
		[AccessedThroughProperty("CardTip")]
		private MyCard m_ReaderTag;

		// Token: 0x040005B7 RID: 1463
		[AccessedThroughProperty("LabConnect")]
		[CompilerGenerated]
		private TextBlock m_FieldTag;

		// Token: 0x040005B8 RID: 1464
		[CompilerGenerated]
		[AccessedThroughProperty("BtnChina")]
		private MyButton pageTag;

		// Token: 0x040005B9 RID: 1465
		[CompilerGenerated]
		[AccessedThroughProperty("BtnWeb")]
		private MyButton m_PrinterTag;

		// Token: 0x040005BA RID: 1466
		[AccessedThroughProperty("PanMain")]
		[CompilerGenerated]
		private StackPanel m_TokenTag;

		// Token: 0x040005BB RID: 1467
		[AccessedThroughProperty("PanLoad")]
		[CompilerGenerated]
		private MyCard _InterpreterTag;

		// Token: 0x040005BC RID: 1468
		[AccessedThroughProperty("Load")]
		[CompilerGenerated]
		private MyLoading m_ParserTag;

		// Token: 0x040005BD RID: 1469
		private bool _StubTag;
	}
}
