﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic.FileIO;
using PCL.My;

namespace PCL
{
	// Token: 0x02000160 RID: 352
	[DesignerGenerated]
	public class PageSetupUI : MyPageRight, IComponentConnector
	{
		// Token: 0x06000F23 RID: 3875 RVA: 0x0006C670 File Offset: 0x0006A870
		public PageSetupUI()
		{
			base.Loaded += this.PageSetupUI_Loaded;
			base.Loaded += ((PageSetupUI._Closure$__.$IR1-1 == null) ? (PageSetupUI._Closure$__.$IR1-1 = delegate(object sender, RoutedEventArgs e)
			{
				PageSetupUI.HiddenRefresh();
			}) : PageSetupUI._Closure$__.$IR1-1);
			this._RequestIssuer = false;
			this.InitializeComponent();
		}

		// Token: 0x06000F24 RID: 3876 RVA: 0x0006C6D0 File Offset: 0x0006A8D0
		private void PageSetupUI_Loaded(object sender, RoutedEventArgs e)
		{
			this.PanBack.ScrollToHome();
			ModMain.SearchTag(true);
			if (ModMain.m_ObserverAccount != 0)
			{
				int observerAccount = ModMain.m_ObserverAccount;
				string text;
				if (observerAccount != 1)
				{
					if (observerAccount != 2)
					{
						text = "？？？";
					}
					else
					{
						text = "真·滑稽彩";
					}
				}
				else
				{
					text = "眼瞎白";
				}
				try
				{
					foreach (object obj in this.PanLauncherTheme.Children)
					{
						object objectValue = RuntimeHelpers.GetObjectValue(obj);
						if (objectValue is MyRadioBox && ((MyRadioBox)objectValue).IsEnabled)
						{
							((MyRadioBox)objectValue).Text = text;
						}
					}
				}
				finally
				{
					IEnumerator enumerator;
					if (enumerator is IDisposable)
					{
						(enumerator as IDisposable).Dispose();
					}
				}
			}
			checked
			{
				if (!this._RequestIssuer)
				{
					this._RequestIssuer = true;
					ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
					this.SliderLoad();
					this.Reload();
					ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
					this.PanLauncherHide.Visibility = Visibility.Visible;
					this.CheckHiddenOtherFeedback.Visibility = Visibility.Collapsed;
					if (!this.RadioLauncherTheme8.IsEnabled)
					{
						this.LabLauncherTheme8Copy.ToolTip = "累积赞助达到 ¥23.33 后，将识别码发送给作者以解锁。\r\n右键打开赞助页面，如果觉得 PCL2 做得还不错就支持一下吧 =w=！";
					}
					this.RadioLauncherTheme8.ToolTip = "累积赞助达到 ¥23.33 后，将识别码发送给作者以解锁";
					if (!this.RadioLauncherTheme9.IsEnabled)
					{
						this.LabLauncherTheme9Copy.ToolTip = "· PCL2 内群群活动中可以获得\r\n· 反馈一个 Bug，在龙猫标记为已处理后自动解锁（右键打开反馈页面）\r\n· 向帮助库提交 Pull Request，在龙猫合并后解锁";
					}
					this.RadioLauncherTheme9.ToolTip = "· PCL2 内群群活动中可以获得\r\n· 反馈一个 Bug，在龙猫标记为已处理后自动解锁\r\n· 向帮助库提交 Pull Request，在龙猫合并后解锁";
				}
			}
		}

		// Token: 0x06000F25 RID: 3877 RVA: 0x0006C834 File Offset: 0x0006AA34
		public void Reload()
		{
			this.SliderLauncherOpacity.Value = Conversions.ToInteger(ModBase._ParamsState.Get("UiLauncherTransparent", null));
			this.SliderLauncherHue.Value = Conversions.ToInteger(ModBase._ParamsState.Get("UiLauncherHue", null));
			this.SliderLauncherSat.Value = Conversions.ToInteger(ModBase._ParamsState.Get("UiLauncherSat", null));
			this.SliderLauncherDelta.Value = Conversions.ToInteger(ModBase._ParamsState.Get("UiLauncherDelta", null));
			this.SliderLauncherLight.Value = Conversions.ToInteger(ModBase._ParamsState.Get("UiLauncherLight", null));
			if (Operators.ConditionalCompareObjectLessEqual(ModBase._ParamsState.Get("UiLauncherTheme", null), 14, true))
			{
				((MyRadioBox)base.FindName(Conversions.ToString(Operators.ConcatenateObject("RadioLauncherTheme", ModBase._ParamsState.Get("UiLauncherTheme", null))))).Checked = true;
			}
			this.CheckLauncherLogo.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiLauncherLogo", null));
			this.CheckLauncherEmail.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiLauncherEmail", null));
			this.SliderBackgroundOpacity.Value = Conversions.ToInteger(ModBase._ParamsState.Get("UiBackgroundOpacity", null));
			this.SliderBackgroundBlur.Value = Conversions.ToInteger(ModBase._ParamsState.Get("UiBackgroundBlur", null));
			this.ComboBackgroundSuit.SelectedIndex = Conversions.ToInteger(ModBase._ParamsState.Get("UiBackgroundSuit", null));
			this.CheckBackgroundColorful.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiBackgroundColorful", null));
			ModMain.BackgroundRefresh(false, false);
			((MyRadioBox)base.FindName(Conversions.ToString(Operators.ConcatenateObject("RadioLogoType", ModBase._ParamsState.Get("UiLogoType", null))))).Checked = true;
			this.CheckLogoLeft.Visibility = (this.RadioLogoType0.Checked ? Visibility.Visible : Visibility.Collapsed);
			this.PanLogoText.Visibility = (this.RadioLogoType2.Checked ? Visibility.Visible : Visibility.Collapsed);
			this.PanLogoChange.Visibility = (this.RadioLogoType3.Checked ? Visibility.Visible : Visibility.Collapsed);
			this.TextLogoText.Text = Conversions.ToString(ModBase._ParamsState.Get("UiLogoText", null));
			this.CheckLogoLeft.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiLogoLeft", null));
			this.CheckMusicAuto.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiMusicAuto", null));
			this.CheckMusicStop.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiMusicStop", null));
			this.CheckMusicStart.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiMusicStart", null));
			this.SliderMusicVolume.Value = Conversions.ToInteger(ModBase._ParamsState.Get("UiMusicVolume", null));
			this.MusicRefreshUI();
			((MyRadioBox)base.FindName(Conversions.ToString(Operators.ConcatenateObject("RadioCustomType", ModBase._ParamsState.Load("UiCustomType", false, null))))).Checked = true;
			this.TextCustomNet.Text = Conversions.ToString(ModBase._ParamsState.Get("UiCustomNet", null));
			this.CheckHiddenPageDownload.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenPageDownload", null));
			this.CheckHiddenPageLink.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenPageLink", null));
			this.CheckHiddenPageSetup.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenPageSetup", null));
			this.CheckHiddenPageOther.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenPageOther", null));
			this.CheckHiddenFunctionSelect.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenFunctionSelect", null));
			this.CheckHiddenFunctionHidden.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenFunctionHidden", null));
			this.CheckHiddenSetupLaunch.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupLaunch", null));
			this.CheckHiddenSetupUI.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupUi", null));
			this.CheckHiddenSetupTool.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupLink", null));
			this.CheckHiddenSetupSystem.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupSystem", null));
			this.CheckHiddenOtherAbout.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherAbout", null));
			this.CheckHiddenOtherFeedback.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherFeedback", null));
			this.CheckHiddenOtherHelp.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherHelp", null));
			this.CheckHiddenOtherTest.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherTest", null));
			this.HiddenSetupEntry(null, false);
			this.HiddenOtherEntry(null, false);
		}

		// Token: 0x06000F26 RID: 3878 RVA: 0x0006CD64 File Offset: 0x0006AF64
		public void Reset()
		{
			try
			{
				ModBase._ParamsState.Reset("UiLauncherTransparent", false, null);
				ModBase._ParamsState.Reset("UiLauncherTheme", false, null);
				ModBase._ParamsState.Reset("UiLauncherLogo", false, null);
				ModBase._ParamsState.Reset("UiLauncherHue", false, null);
				ModBase._ParamsState.Reset("UiLauncherSat", false, null);
				ModBase._ParamsState.Reset("UiLauncherDelta", false, null);
				ModBase._ParamsState.Reset("UiLauncherLight", false, null);
				ModBase._ParamsState.Reset("UiLauncherEmail", false, null);
				ModBase._ParamsState.Reset("UiBackgroundColorful", false, null);
				ModBase._ParamsState.Reset("UiBackgroundOpacity", false, null);
				ModBase._ParamsState.Reset("UiBackgroundBlur", false, null);
				ModBase._ParamsState.Reset("UiBackgroundSuit", false, null);
				ModBase._ParamsState.Reset("UiLogoType", false, null);
				ModBase._ParamsState.Reset("UiLogoText", false, null);
				ModBase._ParamsState.Reset("UiLogoLeft", false, null);
				ModBase._ParamsState.Reset("UiMusicVolume", false, null);
				ModBase._ParamsState.Reset("UiMusicStop", false, null);
				ModBase._ParamsState.Reset("UiMusicStart", false, null);
				ModBase._ParamsState.Reset("UiMusicAuto", false, null);
				ModBase._ParamsState.Reset("UiCustomType", false, null);
				ModBase._ParamsState.Reset("UiCustomNet", false, null);
				ModBase._ParamsState.Reset("UiHiddenPageDownload", false, null);
				ModBase._ParamsState.Reset("UiHiddenPageLink", false, null);
				ModBase._ParamsState.Reset("UiHiddenPageSetup", false, null);
				ModBase._ParamsState.Reset("UiHiddenPageOther", false, null);
				ModBase._ParamsState.Reset("UiHiddenFunctionSelect", false, null);
				ModBase._ParamsState.Reset("UiHiddenFunctionHidden", false, null);
				ModBase._ParamsState.Reset("UiHiddenSetupLaunch", false, null);
				ModBase._ParamsState.Reset("UiHiddenSetupUi", false, null);
				ModBase._ParamsState.Reset("UiHiddenSetupLink", false, null);
				ModBase._ParamsState.Reset("UiHiddenSetupSystem", false, null);
				ModBase._ParamsState.Reset("UiHiddenOtherAbout", false, null);
				ModBase._ParamsState.Reset("UiHiddenOtherFeedback", false, null);
				ModBase._ParamsState.Reset("UiHiddenOtherHelp", false, null);
				ModBase._ParamsState.Reset("UiHiddenOtherTest", false, null);
				ModBase.Log("[Setup] 已初始化个性化设置！", ModBase.LogLevel.Normal, "出现错误");
				ModMain.Hint("已初始化个性化设置", ModMain.HintType.Finish, false);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "初始化个性化设置失败", ModBase.LogLevel.Msgbox, "出现错误");
			}
			this.Reload();
		}

		// Token: 0x06000F27 RID: 3879 RVA: 0x00008F64 File Offset: 0x00007164
		private static void SliderChange(MySlider sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.Value, false, null);
			}
		}

		// Token: 0x06000F28 RID: 3880 RVA: 0x00008F8F File Offset: 0x0000718F
		private static void ComboChange(MyComboBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.SelectedIndex, false, null);
			}
		}

		// Token: 0x06000F29 RID: 3881 RVA: 0x00008FBA File Offset: 0x000071BA
		private static void CheckBoxChange(MyCheckBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.Checked, false, null);
			}
		}

		// Token: 0x06000F2A RID: 3882 RVA: 0x00008F3E File Offset: 0x0000713E
		private static void TextBoxChange(MyTextBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.Text, false, null);
			}
		}

		// Token: 0x06000F2B RID: 3883 RVA: 0x00068FA4 File Offset: 0x000671A4
		private static void RadioBoxChange(MyRadioBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(sender.Tag.ToString().Split(new char[]
				{
					'/'
				})[0], ModBase.Val(sender.Tag.ToString().Split(new char[]
				{
					'/'
				})[1]), false, null);
			}
		}

		// Token: 0x06000F2C RID: 3884 RVA: 0x00009595 File Offset: 0x00007795
		private void BtnUIBgOpen_Click(object sender, EventArgs e)
		{
			ModBase.OpenExplorer("\"" + ModBase.Path + "PCL\\Pictures\"");
		}

		// Token: 0x06000F2D RID: 3885 RVA: 0x000095B0 File Offset: 0x000077B0
		private void BtnBackgroundRefresh_Click(object sender, EventArgs e)
		{
			ModMain.BackgroundRefresh(true, true);
		}

		// Token: 0x06000F2E RID: 3886 RVA: 0x0006D024 File Offset: 0x0006B224
		public void BackgroundRefreshUI(bool Show, int Count)
		{
			if (!Information.IsNothing(this.PanBackgroundOpacity))
			{
				if (Show)
				{
					this.PanBackgroundOpacity.Visibility = Visibility.Visible;
					this.PanBackgroundBlur.Visibility = Visibility.Visible;
					this.PanBackgroundSuit.Visibility = Visibility.Visible;
					this.BtnBackgroundClear.Visibility = Visibility.Visible;
					this.CardBackground.Title = "背景图片（" + Conversions.ToString(Count) + "）";
				}
				else
				{
					this.PanBackgroundOpacity.Visibility = Visibility.Collapsed;
					this.PanBackgroundBlur.Visibility = Visibility.Collapsed;
					this.PanBackgroundSuit.Visibility = Visibility.Collapsed;
					this.BtnBackgroundClear.Visibility = Visibility.Collapsed;
					this.CardBackground.Title = "背景图片";
				}
				this.CardBackground.TriggerForceResize();
			}
		}

		// Token: 0x06000F2F RID: 3887 RVA: 0x0006D0E4 File Offset: 0x0006B2E4
		private void BtnBackgroundClear_Click(object sender, EventArgs e)
		{
			if (ModMain.MyMsgBox("即将删除背景图片文件夹中的所有文件。\r\n此操作不可撤销，是否确定？", "警告", "确定", "取消", "", true, true, false) == 1)
			{
				try
				{
					foreach (FileInfo fileInfo in new DirectoryInfo(ModBase.Path + "PCL\\Pictures").EnumerateFiles())
					{
						try
						{
							fileInfo.Delete();
						}
						catch (Exception ex)
						{
							ModBase.Log(ex, "删除文件失败（" + fileInfo.Name + "）", ModBase.LogLevel.Msgbox, "出现错误");
							return;
						}
					}
				}
				finally
				{
					IEnumerator<FileInfo> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				ModMain.BackgroundRefresh(false, true);
				ModMain.Hint("背景图片已清空！", ModMain.HintType.Finish, true);
			}
		}

		// Token: 0x06000F30 RID: 3888 RVA: 0x0006D1BC File Offset: 0x0006B3BC
		private void BtnLogoChange_Click(object sender, EventArgs e)
		{
			string text = ModBase.SelectFile("常用图片文件(*.png;*.jpg;*.gif)|*.png;*.jpg;*.gif", "选择图片");
			if (Operators.CompareString(text, "", true) != 0)
			{
				try
				{
					File.Delete(ModBase.Path + "PCL\\Logo.png");
					File.Copy(text, ModBase.Path + "PCL\\Logo.png");
					ModMain.m_CollectionAccount.ImageTitleLogo.Source = new MyBitmap(ModBase.Path + "PCL\\Logo.png");
				}
				catch (Exception ex)
				{
					if (ex.Message.Contains("参数无效"))
					{
						ModBase.Log("改变标题栏图片失败，该图片文件可能并非标准格式。\r\n你可以尝试使用画图打开该文件并重新保存，这会让图片变为标准格式。", ModBase.LogLevel.Msgbox, "出现错误");
					}
					else
					{
						ModBase.Log(ex, "设置标题栏图片失败", ModBase.LogLevel.Msgbox, "出现错误");
					}
					ModMain.m_CollectionAccount.ImageTitleLogo.Source = null;
				}
			}
		}

		// Token: 0x06000F31 RID: 3889 RVA: 0x0006D2A4 File Offset: 0x0006B4A4
		private void RadioLogoType3_Check(object sender, ModBase.RouteEventArgs e)
		{
			if (ModAnimation.DefineModel() == 0 && e.m_ImporterParameter)
			{
				if (File.Exists(ModBase.Path + "PCL\\Logo.png"))
				{
					try
					{
						ModMain.m_CollectionAccount.ImageTitleLogo.Source = new MyBitmap(ModBase.Path + "PCL\\Logo.png");
						return;
					}
					catch (Exception ex)
					{
						if (ex.Message.Contains("参数无效"))
						{
							ModBase.Log("调整标题栏图片失败，该图片文件可能并非标准格式。\r\n你可以尝试使用画图打开该文件并重新保存，这会让图片变为标准格式。", ModBase.LogLevel.Msgbox, "出现错误");
						}
						else
						{
							ModBase.Log(ex, "调整标题栏图片失败", ModBase.LogLevel.Msgbox, "出现错误");
						}
						ModMain.m_CollectionAccount.ImageTitleLogo.Source = null;
						e.proxyParameter = true;
						return;
					}
				}
				string text = ModBase.SelectFile("常用图片文件(*.png;*.jpg;*.gif)|*.png;*.jpg;*.gif", "选择图片");
				if (Operators.CompareString(text, "", true) == 0)
				{
					ModMain.m_CollectionAccount.ImageTitleLogo.Source = null;
					e.proxyParameter = true;
					return;
				}
				try
				{
					File.Delete(ModBase.Path + "PCL\\Logo.png");
					File.Copy(text, ModBase.Path + "PCL\\Logo.png");
					ModMain.m_CollectionAccount.ImageTitleLogo.Source = new MyBitmap(ModBase.Path + "PCL\\Logo.png");
				}
				catch (Exception ex2)
				{
					if (ex2.Message.Contains("参数无效"))
					{
						ModBase.Log("设置标题栏图片失败，该图片文件可能并非标准格式。\r\n你可以尝试使用画图打开该文件并重新保存，这会让图片变为标准格式。", ModBase.LogLevel.Msgbox, "出现错误");
					}
					else
					{
						ModBase.Log(ex2, "设置标题栏图片失败", ModBase.LogLevel.Msgbox, "出现错误");
					}
					ModMain.m_CollectionAccount.ImageTitleLogo.Source = null;
					e.proxyParameter = true;
				}
			}
		}

		// Token: 0x06000F32 RID: 3890 RVA: 0x0006D46C File Offset: 0x0006B66C
		private void BtnLogoDelete_Click(object sender, EventArgs e)
		{
			try
			{
				File.Delete(ModBase.Path + "PCL\\Logo.png");
				this.RadioLogoType1.SetChecked(true, true, true);
				ModMain.Hint("标题栏图片已清空！", ModMain.HintType.Finish, true);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "清空标题栏图片失败", ModBase.LogLevel.Msgbox, "出现错误");
			}
		}

		// Token: 0x06000F33 RID: 3891 RVA: 0x000095B9 File Offset: 0x000077B9
		private void BtnMusicOpen_Click(object sender, EventArgs e)
		{
			ModBase.OpenExplorer("\"" + ModBase.Path + "PCL\\Musics\"");
		}

		// Token: 0x06000F34 RID: 3892 RVA: 0x000095D4 File Offset: 0x000077D4
		private void BtnMusicRefresh_Click(object sender, EventArgs e)
		{
			ModMusic.MusicRefreshPlay(true, false);
		}

		// Token: 0x06000F35 RID: 3893 RVA: 0x0006D4D8 File Offset: 0x0006B6D8
		public void MusicRefreshUI()
		{
			if (this.PanBackgroundOpacity != null)
			{
				if (ModMusic.m_RegWrapper.Count > 0)
				{
					this.PanMusicVolume.Visibility = Visibility.Visible;
					this.CheckMusicAuto.Visibility = Visibility.Visible;
					this.CheckMusicStop.Visibility = Visibility.Visible;
					this.CheckMusicStart.Visibility = Visibility.Visible;
					this.BtnMusicClear.Visibility = Visibility.Visible;
					this.CardMusic.Title = "背景音乐（" + Conversions.ToString(MyWpfExtension.FindModel().FileSystem.GetFiles(ModBase.Path + "PCL\\Musics\\", Microsoft.VisualBasic.FileIO.SearchOption.SearchAllSubDirectories, new string[]
					{
						"*.*"
					}).Count) + "）";
				}
				else
				{
					this.PanMusicVolume.Visibility = Visibility.Collapsed;
					this.CheckMusicAuto.Visibility = Visibility.Collapsed;
					this.CheckMusicStop.Visibility = Visibility.Collapsed;
					this.CheckMusicStart.Visibility = Visibility.Collapsed;
					this.BtnMusicClear.Visibility = Visibility.Collapsed;
					this.CardMusic.Title = "背景音乐";
				}
				this.CardMusic.TriggerForceResize();
			}
		}

		// Token: 0x06000F36 RID: 3894 RVA: 0x0006D5E8 File Offset: 0x0006B7E8
		private void BtnMusicClear_Click(object sender, EventArgs e)
		{
			if (ModMain.MyMsgBox("即将删除背景音乐文件夹中的所有文件。\r\n此操作不可撤销，是否确定？", "警告", "确定", "取消", "", true, true, false) == 1)
			{
				ModBase.RunInThread((PageSetupUI._Closure$__.$I21-0 == null) ? (PageSetupUI._Closure$__.$I21-0 = delegate()
				{
					ModMain.Hint("正在删除背景音乐……", ModMain.HintType.Info, true);
					ModMusic._InvocationWrapper = null;
					ModMusic.m_ObjectWrapper = new List<string>();
					ModMusic.m_RegWrapper = new List<string>();
					Thread.Sleep(200);
					try
					{
						ModBase.DeleteDirectory(ModBase.Path + "PCL\\Musics", false);
						ModMain.Hint("背景音乐已删除！", ModMain.HintType.Finish, true);
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "删除背景音乐失败", ModBase.LogLevel.Msgbox, "出现错误");
					}
					try
					{
						Directory.CreateDirectory(ModBase.Path + "PCL\\Musics");
						ModBase.RunInUi((PageSetupUI._Closure$__.$I21-1 == null) ? (PageSetupUI._Closure$__.$I21-1 = delegate()
						{
							ModMusic.MusicRefreshPlay(false, false);
						}) : PageSetupUI._Closure$__.$I21-1, false);
					}
					catch (Exception ex2)
					{
						ModBase.Log(ex2, "重建背景音乐文件夹失败", ModBase.LogLevel.Msgbox, "出现错误");
					}
				}) : PageSetupUI._Closure$__.$I21-0);
			}
		}

		// Token: 0x06000F37 RID: 3895 RVA: 0x000095DD File Offset: 0x000077DD
		private void CheckMusicStart_Change()
		{
			if (ModAnimation.DefineModel() == 0 && this.CheckMusicStart.Checked)
			{
				this.CheckMusicStop.Checked = false;
			}
		}

		// Token: 0x06000F38 RID: 3896 RVA: 0x000095FF File Offset: 0x000077FF
		private void CheckMusicStop_Change()
		{
			if (ModAnimation.DefineModel() == 0 && this.CheckMusicStop.Checked)
			{
				this.CheckMusicStart.Checked = false;
			}
		}

		// Token: 0x06000F39 RID: 3897 RVA: 0x0006D644 File Offset: 0x0006B844
		private void BtnCustomFile_Click(object sender, EventArgs e)
		{
			ModMain._ReaderAccount.workerComparator = true;
			try
			{
				if (!File.Exists(ModBase.Path + "PCL\\Custom.xaml") || ModMain.MyMsgBox("当前已存在布局文件，继续生成教学文件将会覆盖现有布局文件！", "覆盖确认", "继续", "取消", "", true, true, false) != 2)
				{
					ModBase.WriteFile(ModBase.Path + "PCL\\Custom.xaml", ModBase.GetResources("Custom"), false);
					ModMain.Hint("教学文件已生成！", ModMain.HintType.Finish, true);
					Process.Start("explorer", "/select," + ModBase.Path + "PCL\\Custom.xaml");
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "生成教学文件失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000F3A RID: 3898 RVA: 0x00009621 File Offset: 0x00007821
		private void BtnCustomRefresh_Click()
		{
			ModMain._ReaderAccount.ForceRefresh(true);
		}

		// Token: 0x06000F3B RID: 3899 RVA: 0x0006D714 File Offset: 0x0006B914
		private void BtnCustomTutorial_Click(object sender, EventArgs e)
		{
			ModMain.MyMsgBox("1. 点击 生成教学文件 按钮，这会在 PCL 文件夹下生成 Custom.xaml 布局文件。\r\n2. 使用记事本等工具打开这个文件并进行修改，修改完记得保存。\r\n3. 点击 刷新主页 按钮，查看主页现在长啥样了。\r\n\r\n你可以在生成教学文件后直接刷新主页，对照着进行修改，更有助于理解。\r\n如果要关闭主页自定义，删除 PCL 文件夹下的 Custom.xaml 文件即可。", "主页自定义教程", "确定", "", "", false, true, false);
		}

		// Token: 0x06000F3C RID: 3900 RVA: 0x0006D744 File Offset: 0x0006B944
		private void LabLauncherTheme5Unlock_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			MyRadioBox myRadioBox;
			(myRadioBox = this.RadioLauncherTheme5Gray).Opacity = myRadioBox.Opacity - 0.23;
			(myRadioBox = this.RadioLauncherTheme5).Opacity = myRadioBox.Opacity + 0.23;
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaOpacity(this.RadioLauncherTheme5Gray, 1.0, 1000, 0, null, false),
				ModAnimation.AaOpacity(this.RadioLauncherTheme5, -1.0, 1000, 0, null, false)
			}, "ThemeUnlock", false);
			if (this.RadioLauncherTheme5Gray.Opacity < 0.08)
			{
				ModMain.ThemeUnlock(5, true, "隐藏主题 玄素黑 已解锁！");
				ModAnimation.AniStop("ThemeUnlock");
				this.RadioLauncherTheme5.Checked = true;
			}
		}

		// Token: 0x06000F3D RID: 3901 RVA: 0x0006D81C File Offset: 0x0006BA1C
		private void LabLauncherTheme11Click_MouseLeftButtonUp()
		{
			if ((this.LabLauncherTheme11Click.Visibility == Visibility.Collapsed || this.LabLauncherTheme11Click.ToolTip.ToString().Contains("点击")) && ModMain.MyMsgBox("1. 不爬取或攻击相关服务或网站，不盗取相关账号，没有谜题可以或需要以此来解决。\r\n2. 不得篡改或损毁相关公开信息，请尽量让它们保持原状。\r\n3. 在你感到迷茫的时候，看看回声洞可能会给你带来惊喜。\r\n\r\n若违规，可能会被从任意相关群中踢出！", "解密游戏的基本规则", "我知道了", "恕我拒绝", "", false, true, false) == 1)
			{
				ModMain.MyMsgBox("你需要用自己的智慧来找到下一步的线索……\r\n初始线索：gnp.dorC61\\60\\20\\0202\\moc.x1xa.2s\\\\:sptth", "解密游戏", "确定", "", "", false, true, false);
			}
		}

		// Token: 0x06000F3E RID: 3902 RVA: 0x00008729 File Offset: 0x00006929
		private void LabLauncherTheme8Copy_MouseRightButtonUp()
		{
			ModBase.OpenWebsite("https://afdian.net/p/8fe6fefefde811e9bda952540025c377");
		}

		// Token: 0x06000F3F RID: 3903 RVA: 0x0000962E File Offset: 0x0000782E
		private void LabLauncherTheme9Copy_MouseRightButtonUp()
		{
			ModMain.m_CollectionAccount.PageChange(FormMain.PageType.Other, FormMain.PageSubType.SetupLink);
		}

		// Token: 0x06000F40 RID: 3904 RVA: 0x0006D89C File Offset: 0x0006BA9C
		private void RadioLauncherTheme14_Change(object sender, ModBase.RouteEventArgs e)
		{
			if (this.MyRadioBox_4.Checked)
			{
				if (this.LabLauncherHue.Visibility == Visibility.Visible)
				{
					return;
				}
				this.LabLauncherHue.Visibility = Visibility.Visible;
				this.SliderLauncherHue.Visibility = Visibility.Visible;
				this.LabLauncherSat.Visibility = Visibility.Visible;
				this.SliderLauncherSat.Visibility = Visibility.Visible;
				this.LabLauncherDelta.Visibility = Visibility.Visible;
				this.SliderLauncherDelta.Visibility = Visibility.Visible;
				this.LabLauncherLight.Visibility = Visibility.Visible;
				this.SliderLauncherLight.Visibility = Visibility.Visible;
			}
			else
			{
				if (this.LabLauncherHue.Visibility == Visibility.Collapsed)
				{
					return;
				}
				this.LabLauncherHue.Visibility = Visibility.Collapsed;
				this.SliderLauncherHue.Visibility = Visibility.Collapsed;
				this.LabLauncherSat.Visibility = Visibility.Collapsed;
				this.SliderLauncherSat.Visibility = Visibility.Collapsed;
				this.LabLauncherDelta.Visibility = Visibility.Collapsed;
				this.SliderLauncherDelta.Visibility = Visibility.Collapsed;
				this.LabLauncherLight.Visibility = Visibility.Collapsed;
				this.SliderLauncherLight.Visibility = Visibility.Collapsed;
			}
			this.CardLauncher.TriggerForceResize();
		}

		// Token: 0x06000F41 RID: 3905 RVA: 0x00009641 File Offset: 0x00007841
		private void HSL_Change()
		{
			if (ModAnimation.DefineModel() == 0 && this.SliderLauncherSat != null && this.SliderLauncherSat.IsLoaded)
			{
				ModMain.CompareTag(-1);
			}
		}

		// Token: 0x06000F42 RID: 3906 RVA: 0x00009665 File Offset: 0x00007865
		public static bool AwakeResolver()
		{
			return PageSetupUI.accountIssuer;
		}

		// Token: 0x06000F43 RID: 3907 RVA: 0x0000966C File Offset: 0x0000786C
		public static void SortResolver(bool value)
		{
			PageSetupUI.accountIssuer = value;
			PageSetupUI.HiddenRefresh();
		}

		// Token: 0x06000F44 RID: 3908 RVA: 0x0006D9A4 File Offset: 0x0006BBA4
		public static void HiddenRefresh()
		{
			checked
			{
				if (ModMain.m_CollectionAccount.PanTitleSelect != null && ModMain.m_CollectionAccount.PanTitleSelect.IsLoaded)
				{
					try
					{
						if (Conversions.ToBoolean(!PageSetupUI.accountIssuer && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenPageDownload", null)) && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenPageLink", null)) && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenPageSetup", null)) && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenPageOther", null))))
						{
							ModMain.m_CollectionAccount.PanTitleSelect.Visibility = Visibility.Collapsed;
						}
						else
						{
							ModMain.m_CollectionAccount.PanTitleSelect.Visibility = Visibility.Visible;
							ModMain.m_CollectionAccount.BtnTitleSelect1.Visibility = (Conversions.ToBoolean(!PageSetupUI.accountIssuer && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenPageDownload", null))) ? Visibility.Collapsed : Visibility.Visible);
							ModMain.m_CollectionAccount.BtnTitleSelect2.Visibility = (Conversions.ToBoolean(!PageSetupUI.accountIssuer && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenPageLink", null))) ? Visibility.Collapsed : Visibility.Visible);
							ModMain.m_CollectionAccount.BtnTitleSelect3.Visibility = (Conversions.ToBoolean(!PageSetupUI.accountIssuer && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenPageSetup", null))) ? Visibility.Collapsed : Visibility.Visible);
							ModMain.m_CollectionAccount.BtnTitleSelect4.Visibility = (Conversions.ToBoolean(!PageSetupUI.accountIssuer && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenPageOther", null))) ? Visibility.Collapsed : Visibility.Visible);
						}
						ModMain._FilterAccount.RefreshButtonsUI();
						if (ModMain.m_ExporterAccount != null)
						{
							ModMain.m_ExporterAccount.CardSwitch.Visibility = (Conversions.ToBoolean(!PageSetupUI.accountIssuer && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenFunctionHidden", null))) ? Visibility.Collapsed : Visibility.Visible);
						}
						if (ModMain._RuleAccount != null)
						{
							ModMain._RuleAccount.ItemLaunch.Visibility = (Conversions.ToBoolean(!PageSetupUI.accountIssuer && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupLaunch", null))) ? Visibility.Collapsed : Visibility.Visible);
							ModMain._RuleAccount.ItemUI.Visibility = (Conversions.ToBoolean(!PageSetupUI.accountIssuer && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupUi", null))) ? Visibility.Collapsed : Visibility.Visible);
							ModMain._RuleAccount.ItemSystem.Visibility = (Conversions.ToBoolean(!PageSetupUI.accountIssuer && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupSystem", null))) ? Visibility.Collapsed : Visibility.Visible);
							int num = 0;
							if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenSetupLaunch", null))))
							{
								num++;
							}
							if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenSetupUi", null))))
							{
								num++;
							}
							if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenSetupSystem", null))))
							{
								num++;
							}
							ModMain._RuleAccount.PanItem.Visibility = ((num >= 2 || PageSetupUI.accountIssuer) ? Visibility.Visible : Visibility.Collapsed);
						}
						int num2 = 0;
						if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenOtherHelp", null))))
						{
							num2++;
						}
						if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenOtherFeedback", null))))
						{
							num2++;
						}
						if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenOtherAbout", null))))
						{
							num2++;
						}
						if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenOtherTest", null))))
						{
							num2++;
						}
						if (ModMain.m_ListAccount != null)
						{
							ModMain.m_ListAccount.ItemHelp.Visibility = (Conversions.ToBoolean(!PageSetupUI.accountIssuer && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherHelp", null))) ? Visibility.Collapsed : Visibility.Visible);
							ModMain.m_ListAccount.ItemFeedback.Visibility = Visibility.Collapsed;
							ModMain.m_ListAccount.ItemAbout.Visibility = (Conversions.ToBoolean(!PageSetupUI.accountIssuer && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherAbout", null))) ? Visibility.Collapsed : Visibility.Visible);
							ModMain.m_ListAccount.ItemTest.Visibility = (Conversions.ToBoolean(!PageSetupUI.accountIssuer && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherTest", null))) ? Visibility.Collapsed : Visibility.Visible);
							ModMain.m_ListAccount.PanItem.Visibility = ((num2 >= 2 || PageSetupUI.accountIssuer) ? Visibility.Visible : Visibility.Collapsed);
						}
						if (num2 == 1 && !PageSetupUI.accountIssuer)
						{
							if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenOtherHelp", null))))
							{
								ModMain.m_CollectionAccount.BtnTitleSelect4.Text = "帮助";
							}
							else if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenOtherFeedback", null))))
							{
								ModMain.m_CollectionAccount.BtnTitleSelect4.Text = "反馈";
							}
							else if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenOtherAbout", null))))
							{
								ModMain.m_CollectionAccount.BtnTitleSelect4.Text = "关于";
							}
							else
							{
								ModMain.m_CollectionAccount.BtnTitleSelect4.Text = "百宝箱";
							}
						}
						else
						{
							ModMain.m_CollectionAccount.BtnTitleSelect4.Text = "更多";
						}
						if (ModMain.m_CollectionAccount.comparatorAccount == FormMain.PageType.VersionSelect)
						{
							ModMain._PageAccount.BtnEmptyDownload_Loaded();
						}
						if (ModMain.m_CollectionAccount.comparatorAccount == FormMain.PageType.Launch)
						{
							ModMain._FilterAccount.RefreshButtonsUI();
						}
						if (ModMain.m_CollectionAccount.comparatorAccount == FormMain.PageType.VersionSetup && ModMain.m_StatusAccount != null)
						{
							ModMain.m_StatusAccount.BtnDownload_Loaded();
						}
						if (ModMain.m_ExporterAccount != null)
						{
							ModMain.m_ExporterAccount.CardSwitch.Title = (PageSetupUI.accountIssuer ? "功能隐藏（已暂时关闭，按 F12 以重新启用）" : "功能隐藏");
						}
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "刷新功能隐藏项目失败", ModBase.LogLevel.Feedback, "出现错误");
					}
				}
			}
		}

		// Token: 0x06000F45 RID: 3909 RVA: 0x0006E010 File Offset: 0x0006C210
		private void HiddenOtherAll()
		{
			if (Conversions.ToBoolean(Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherHelp", null)) && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherAbout", null)) && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherTest", null)) && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherFeedback", null))))
			{
				this.CheckHiddenPageOther.SetChecked(true, true, true);
			}
		}

		// Token: 0x06000F46 RID: 3910 RVA: 0x0006E094 File Offset: 0x0006C294
		private void HiddenOtherEntry(object sender, bool user)
		{
			this.CheckHiddenOtherAbout.IsEnabled = Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenPageOther", null)));
			this.CheckHiddenOtherTest.IsEnabled = Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenPageOther", null)));
			this.CheckHiddenOtherFeedback.IsEnabled = Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenPageOther", null)));
			this.CheckHiddenOtherHelp.IsEnabled = Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenPageOther", null)));
			if (Conversions.ToBoolean(sender != null && !this.CheckHiddenPageOther.Checked && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherHelp", null)) && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherFeedback", null)) && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherTest", null)) && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenOtherAbout", null))))
			{
				this.CheckHiddenOtherAbout.SetChecked(false, true, true);
				this.CheckHiddenOtherTest.SetChecked(false, true, true);
				this.CheckHiddenOtherFeedback.SetChecked(false, true, true);
				this.CheckHiddenOtherHelp.SetChecked(false, true, true);
			}
		}

		// Token: 0x06000F47 RID: 3911 RVA: 0x0006E1E8 File Offset: 0x0006C3E8
		private void HiddenSetupAll()
		{
			if (Conversions.ToBoolean(Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupLaunch", null)) && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupUi", null)) && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupSystem", null))))
			{
				this.CheckHiddenPageSetup.SetChecked(true, true, true);
			}
		}

		// Token: 0x06000F48 RID: 3912 RVA: 0x0006E258 File Offset: 0x0006C458
		private void HiddenSetupEntry(object sender, bool user)
		{
			this.CheckHiddenSetupLaunch.IsEnabled = Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenPageSetup", null)));
			this.CheckHiddenSetupSystem.IsEnabled = Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenPageSetup", null)));
			this.CheckHiddenSetupUI.IsEnabled = Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("UiHiddenPageSetup", null)));
			if (Conversions.ToBoolean(sender != null && !this.CheckHiddenPageSetup.Checked && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupLaunch", null)) && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupUi", null)) && Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenSetupSystem", null))))
			{
				this.CheckHiddenSetupLaunch.SetChecked(false, true, true);
				this.CheckHiddenSetupSystem.SetChecked(false, true, true);
				this.CheckHiddenSetupUI.SetChecked(false, true, true);
			}
		}

		// Token: 0x06000F49 RID: 3913 RVA: 0x00009679 File Offset: 0x00007879
		private void HiddenHint(object sender, bool user)
		{
			if (Conversions.ToBoolean(ModAnimation.DefineModel() == 0 && Conversions.ToBoolean(NewLateBinding.LateGet(sender, null, "Checked", new object[0], null, null, null))))
			{
				ModMain.Hint("按 F12 即可暂时关闭功能隐藏设置。千万别忘了，要不然设置就改不回来了……", ModMain.HintType.Info, true);
			}
		}

		// Token: 0x06000F4A RID: 3914 RVA: 0x00008729 File Offset: 0x00006929
		private void BtnLauncherDonate_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://afdian.net/p/8fe6fefefde811e9bda952540025c377");
		}

		// Token: 0x06000F4B RID: 3915 RVA: 0x0006E360 File Offset: 0x0006C560
		private void SliderLoad()
		{
			this.SliderLauncherHue.merchantRequest = ((PageSetupUI._Closure$__.$I44-0 == null) ? (PageSetupUI._Closure$__.$I44-0 = ((int Value) => Conversions.ToString(Value) + "°")) : PageSetupUI._Closure$__.$I44-0);
			this.SliderLauncherSat.merchantRequest = ((PageSetupUI._Closure$__.$I44-1 == null) ? (PageSetupUI._Closure$__.$I44-1 = ((int Value) => Conversions.ToString(Value) + "%")) : PageSetupUI._Closure$__.$I44-1);
			checked
			{
				this.SliderLauncherDelta.merchantRequest = ((PageSetupUI._Closure$__.$I44-2 == null) ? (PageSetupUI._Closure$__.$I44-2 = delegate(int Value)
				{
					object result;
					if (Value > 90)
					{
						result = "+" + Conversions.ToString(Value - 90);
					}
					else if (Value == 90)
					{
						result = 0;
					}
					else
					{
						result = Value - 90;
					}
					return result;
				}) : PageSetupUI._Closure$__.$I44-2);
				this.SliderLauncherLight.merchantRequest = ((PageSetupUI._Closure$__.$I44-3 == null) ? (PageSetupUI._Closure$__.$I44-3 = delegate(int Value)
				{
					object result;
					if (Value > 20)
					{
						result = "+" + Conversions.ToString(Value - 20);
					}
					else if (Value == 20)
					{
						result = 0;
					}
					else
					{
						result = Value - 20;
					}
					return result;
				}) : PageSetupUI._Closure$__.$I44-3);
			}
		}

		// Token: 0x1700026F RID: 623
		// (get) Token: 0x06000F4C RID: 3916 RVA: 0x000096B7 File Offset: 0x000078B7
		// (set) Token: 0x06000F4D RID: 3917 RVA: 0x000096BF File Offset: 0x000078BF
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x17000270 RID: 624
		// (get) Token: 0x06000F4E RID: 3918 RVA: 0x000096C8 File Offset: 0x000078C8
		// (set) Token: 0x06000F4F RID: 3919 RVA: 0x000096D0 File Offset: 0x000078D0
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x17000271 RID: 625
		// (get) Token: 0x06000F50 RID: 3920 RVA: 0x000096D9 File Offset: 0x000078D9
		// (set) Token: 0x06000F51 RID: 3921 RVA: 0x000096E1 File Offset: 0x000078E1
		internal virtual MyCard CardLauncher { get; set; }

		// Token: 0x17000272 RID: 626
		// (get) Token: 0x06000F52 RID: 3922 RVA: 0x000096EA File Offset: 0x000078EA
		// (set) Token: 0x06000F53 RID: 3923 RVA: 0x0006E42C File Offset: 0x0006C62C
		internal virtual MySlider SliderLauncherOpacity
		{
			[CompilerGenerated]
			get
			{
				return this.authenticationIssuer;
			}
			[CompilerGenerated]
			set
			{
				MySlider.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR59-2 == null) ? (PageSetupUI._Closure$__.$IR59-2 = delegate(object a0, bool a1)
				{
					PageSetupUI.SliderChange((MySlider)a0, a1);
				}) : PageSetupUI._Closure$__.$IR59-2;
				MySlider mySlider = this.authenticationIssuer;
				if (mySlider != null)
				{
					mySlider.ViewTag(obj);
				}
				this.authenticationIssuer = value;
				mySlider = this.authenticationIssuer;
				if (mySlider != null)
				{
					mySlider.UpdateTag(obj);
				}
			}
		}

		// Token: 0x17000273 RID: 627
		// (get) Token: 0x06000F54 RID: 3924 RVA: 0x000096F2 File Offset: 0x000078F2
		// (set) Token: 0x06000F55 RID: 3925 RVA: 0x000096FA File Offset: 0x000078FA
		internal virtual TextBlock LabLauncherHue { get; set; }

		// Token: 0x17000274 RID: 628
		// (get) Token: 0x06000F56 RID: 3926 RVA: 0x00009703 File Offset: 0x00007903
		// (set) Token: 0x06000F57 RID: 3927 RVA: 0x0006E488 File Offset: 0x0006C688
		internal virtual MySlider SliderLauncherHue
		{
			[CompilerGenerated]
			get
			{
				return this.m_ContainerIssuer;
			}
			[CompilerGenerated]
			set
			{
				MySlider.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR67-3 == null) ? (PageSetupUI._Closure$__.$IR67-3 = delegate(object a0, bool a1)
				{
					PageSetupUI.SliderChange((MySlider)a0, a1);
				}) : PageSetupUI._Closure$__.$IR67-3;
				MySlider.ChangeEventHandler obj2 = delegate(object a0, bool a1)
				{
					this.HSL_Change();
				};
				MySlider containerIssuer = this.m_ContainerIssuer;
				if (containerIssuer != null)
				{
					containerIssuer.ViewTag(obj);
					containerIssuer.ViewTag(obj2);
				}
				this.m_ContainerIssuer = value;
				containerIssuer = this.m_ContainerIssuer;
				if (containerIssuer != null)
				{
					containerIssuer.UpdateTag(obj);
					containerIssuer.UpdateTag(obj2);
				}
			}
		}

		// Token: 0x17000275 RID: 629
		// (get) Token: 0x06000F58 RID: 3928 RVA: 0x0000970B File Offset: 0x0000790B
		// (set) Token: 0x06000F59 RID: 3929 RVA: 0x00009713 File Offset: 0x00007913
		internal virtual TextBlock LabLauncherDelta { get; set; }

		// Token: 0x17000276 RID: 630
		// (get) Token: 0x06000F5A RID: 3930 RVA: 0x0000971C File Offset: 0x0000791C
		// (set) Token: 0x06000F5B RID: 3931 RVA: 0x0006E500 File Offset: 0x0006C700
		internal virtual MySlider SliderLauncherDelta
		{
			[CompilerGenerated]
			get
			{
				return this._TokenizerIssuer;
			}
			[CompilerGenerated]
			set
			{
				MySlider.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR75-5 == null) ? (PageSetupUI._Closure$__.$IR75-5 = delegate(object a0, bool a1)
				{
					PageSetupUI.SliderChange((MySlider)a0, a1);
				}) : PageSetupUI._Closure$__.$IR75-5;
				MySlider.ChangeEventHandler obj2 = delegate(object a0, bool a1)
				{
					this.HSL_Change();
				};
				MySlider tokenizerIssuer = this._TokenizerIssuer;
				if (tokenizerIssuer != null)
				{
					tokenizerIssuer.ViewTag(obj);
					tokenizerIssuer.ViewTag(obj2);
				}
				this._TokenizerIssuer = value;
				tokenizerIssuer = this._TokenizerIssuer;
				if (tokenizerIssuer != null)
				{
					tokenizerIssuer.UpdateTag(obj);
					tokenizerIssuer.UpdateTag(obj2);
				}
			}
		}

		// Token: 0x17000277 RID: 631
		// (get) Token: 0x06000F5C RID: 3932 RVA: 0x00009724 File Offset: 0x00007924
		// (set) Token: 0x06000F5D RID: 3933 RVA: 0x0000972C File Offset: 0x0000792C
		internal virtual TextBlock LabLauncherSat { get; set; }

		// Token: 0x17000278 RID: 632
		// (get) Token: 0x06000F5E RID: 3934 RVA: 0x00009735 File Offset: 0x00007935
		// (set) Token: 0x06000F5F RID: 3935 RVA: 0x0006E578 File Offset: 0x0006C778
		internal virtual MySlider SliderLauncherSat
		{
			[CompilerGenerated]
			get
			{
				return this.paramsIssuer;
			}
			[CompilerGenerated]
			set
			{
				MySlider.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR83-7 == null) ? (PageSetupUI._Closure$__.$IR83-7 = delegate(object a0, bool a1)
				{
					PageSetupUI.SliderChange((MySlider)a0, a1);
				}) : PageSetupUI._Closure$__.$IR83-7;
				MySlider.ChangeEventHandler obj2 = delegate(object a0, bool a1)
				{
					this.HSL_Change();
				};
				MySlider mySlider = this.paramsIssuer;
				if (mySlider != null)
				{
					mySlider.ViewTag(obj);
					mySlider.ViewTag(obj2);
				}
				this.paramsIssuer = value;
				mySlider = this.paramsIssuer;
				if (mySlider != null)
				{
					mySlider.UpdateTag(obj);
					mySlider.UpdateTag(obj2);
				}
			}
		}

		// Token: 0x17000279 RID: 633
		// (get) Token: 0x06000F60 RID: 3936 RVA: 0x0000973D File Offset: 0x0000793D
		// (set) Token: 0x06000F61 RID: 3937 RVA: 0x00009745 File Offset: 0x00007945
		internal virtual TextBlock LabLauncherLight { get; set; }

		// Token: 0x1700027A RID: 634
		// (get) Token: 0x06000F62 RID: 3938 RVA: 0x0000974E File Offset: 0x0000794E
		// (set) Token: 0x06000F63 RID: 3939 RVA: 0x0006E5F0 File Offset: 0x0006C7F0
		internal virtual MySlider SliderLauncherLight
		{
			[CompilerGenerated]
			get
			{
				return this._AdapterIssuer;
			}
			[CompilerGenerated]
			set
			{
				MySlider.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR91-9 == null) ? (PageSetupUI._Closure$__.$IR91-9 = delegate(object a0, bool a1)
				{
					PageSetupUI.SliderChange((MySlider)a0, a1);
				}) : PageSetupUI._Closure$__.$IR91-9;
				MySlider.ChangeEventHandler obj2 = delegate(object a0, bool a1)
				{
					this.HSL_Change();
				};
				MySlider adapterIssuer = this._AdapterIssuer;
				if (adapterIssuer != null)
				{
					adapterIssuer.ViewTag(obj);
					adapterIssuer.ViewTag(obj2);
				}
				this._AdapterIssuer = value;
				adapterIssuer = this._AdapterIssuer;
				if (adapterIssuer != null)
				{
					adapterIssuer.UpdateTag(obj);
					adapterIssuer.UpdateTag(obj2);
				}
			}
		}

		// Token: 0x1700027B RID: 635
		// (get) Token: 0x06000F64 RID: 3940 RVA: 0x00009756 File Offset: 0x00007956
		// (set) Token: 0x06000F65 RID: 3941 RVA: 0x0000975E File Offset: 0x0000795E
		internal virtual Grid PanLauncherTheme { get; set; }

		// Token: 0x1700027C RID: 636
		// (get) Token: 0x06000F66 RID: 3942 RVA: 0x00009767 File Offset: 0x00007967
		// (set) Token: 0x06000F67 RID: 3943 RVA: 0x0006E668 File Offset: 0x0006C868
		internal virtual MyRadioBox RadioLauncherTheme0
		{
			[CompilerGenerated]
			get
			{
				return this._SystemIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR99-11 == null) ? (PageSetupUI._Closure$__.$IR99-11 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR99-11;
				MyRadioBox systemIssuer = this._SystemIssuer;
				if (systemIssuer != null)
				{
					systemIssuer.Check -= value2;
				}
				this._SystemIssuer = value;
				systemIssuer = this._SystemIssuer;
				if (systemIssuer != null)
				{
					systemIssuer.Check += value2;
				}
			}
		}

		// Token: 0x1700027D RID: 637
		// (get) Token: 0x06000F68 RID: 3944 RVA: 0x0000976F File Offset: 0x0000796F
		// (set) Token: 0x06000F69 RID: 3945 RVA: 0x0006E6C4 File Offset: 0x0006C8C4
		internal virtual MyRadioBox RadioLauncherTheme1
		{
			[CompilerGenerated]
			get
			{
				return this.m_WriterIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR103-12 == null) ? (PageSetupUI._Closure$__.$IR103-12 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR103-12;
				MyRadioBox writerIssuer = this.m_WriterIssuer;
				if (writerIssuer != null)
				{
					writerIssuer.Check -= value2;
				}
				this.m_WriterIssuer = value;
				writerIssuer = this.m_WriterIssuer;
				if (writerIssuer != null)
				{
					writerIssuer.Check += value2;
				}
			}
		}

		// Token: 0x1700027E RID: 638
		// (get) Token: 0x06000F6A RID: 3946 RVA: 0x00009777 File Offset: 0x00007977
		// (set) Token: 0x06000F6B RID: 3947 RVA: 0x0006E720 File Offset: 0x0006C920
		internal virtual MyRadioBox RadioLauncherTheme2
		{
			[CompilerGenerated]
			get
			{
				return this._BroadcasterIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR107-13 == null) ? (PageSetupUI._Closure$__.$IR107-13 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR107-13;
				MyRadioBox broadcasterIssuer = this._BroadcasterIssuer;
				if (broadcasterIssuer != null)
				{
					broadcasterIssuer.Check -= value2;
				}
				this._BroadcasterIssuer = value;
				broadcasterIssuer = this._BroadcasterIssuer;
				if (broadcasterIssuer != null)
				{
					broadcasterIssuer.Check += value2;
				}
			}
		}

		// Token: 0x1700027F RID: 639
		// (get) Token: 0x06000F6C RID: 3948 RVA: 0x0000977F File Offset: 0x0000797F
		// (set) Token: 0x06000F6D RID: 3949 RVA: 0x0006E77C File Offset: 0x0006C97C
		internal virtual MyRadioBox RadioLauncherTheme3
		{
			[CompilerGenerated]
			get
			{
				return this._AttributeIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR111-14 == null) ? (PageSetupUI._Closure$__.$IR111-14 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR111-14;
				MyRadioBox attributeIssuer = this._AttributeIssuer;
				if (attributeIssuer != null)
				{
					attributeIssuer.Check -= value2;
				}
				this._AttributeIssuer = value;
				attributeIssuer = this._AttributeIssuer;
				if (attributeIssuer != null)
				{
					attributeIssuer.Check += value2;
				}
			}
		}

		// Token: 0x17000280 RID: 640
		// (get) Token: 0x06000F6E RID: 3950 RVA: 0x00009787 File Offset: 0x00007987
		// (set) Token: 0x06000F6F RID: 3951 RVA: 0x0006E7D8 File Offset: 0x0006C9D8
		internal virtual MyRadioBox RadioLauncherTheme4
		{
			[CompilerGenerated]
			get
			{
				return this.specificationIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR115-15 == null) ? (PageSetupUI._Closure$__.$IR115-15 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR115-15;
				MyRadioBox myRadioBox = this.specificationIssuer;
				if (myRadioBox != null)
				{
					myRadioBox.Check -= value2;
				}
				this.specificationIssuer = value;
				myRadioBox = this.specificationIssuer;
				if (myRadioBox != null)
				{
					myRadioBox.Check += value2;
				}
			}
		}

		// Token: 0x17000281 RID: 641
		// (get) Token: 0x06000F70 RID: 3952 RVA: 0x0000978F File Offset: 0x0000798F
		// (set) Token: 0x06000F71 RID: 3953 RVA: 0x0006E834 File Offset: 0x0006CA34
		internal virtual MyRadioBox RadioLauncherTheme5
		{
			[CompilerGenerated]
			get
			{
				return this._PredicateIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR119-16 == null) ? (PageSetupUI._Closure$__.$IR119-16 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR119-16;
				MyRadioBox predicateIssuer = this._PredicateIssuer;
				if (predicateIssuer != null)
				{
					predicateIssuer.Check -= value2;
				}
				this._PredicateIssuer = value;
				predicateIssuer = this._PredicateIssuer;
				if (predicateIssuer != null)
				{
					predicateIssuer.Check += value2;
				}
			}
		}

		// Token: 0x17000282 RID: 642
		// (get) Token: 0x06000F72 RID: 3954 RVA: 0x00009797 File Offset: 0x00007997
		// (set) Token: 0x06000F73 RID: 3955 RVA: 0x0000979F File Offset: 0x0000799F
		internal virtual MyRadioBox RadioLauncherTheme5Gray { get; set; }

		// Token: 0x17000283 RID: 643
		// (get) Token: 0x06000F74 RID: 3956 RVA: 0x000097A8 File Offset: 0x000079A8
		// (set) Token: 0x06000F75 RID: 3957 RVA: 0x0006E890 File Offset: 0x0006CA90
		internal virtual TextBlock LabLauncherTheme5Unlock
		{
			[CompilerGenerated]
			get
			{
				return this.infoIssuer;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = new MouseButtonEventHandler(this.LabLauncherTheme5Unlock_MouseLeftButtonUp);
				TextBlock textBlock = this.infoIssuer;
				if (textBlock != null)
				{
					textBlock.MouseLeftButtonUp -= value2;
				}
				this.infoIssuer = value;
				textBlock = this.infoIssuer;
				if (textBlock != null)
				{
					textBlock.MouseLeftButtonUp += value2;
				}
			}
		}

		// Token: 0x17000284 RID: 644
		// (get) Token: 0x06000F76 RID: 3958 RVA: 0x000097B0 File Offset: 0x000079B0
		// (set) Token: 0x06000F77 RID: 3959 RVA: 0x0006E8D4 File Offset: 0x0006CAD4
		internal virtual MyRadioBox MyRadioBox_0
		{
			[CompilerGenerated]
			get
			{
				return this._DecoratorIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR131-17 == null) ? (PageSetupUI._Closure$__.$IR131-17 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR131-17;
				MyRadioBox decoratorIssuer = this._DecoratorIssuer;
				if (decoratorIssuer != null)
				{
					decoratorIssuer.Check -= value2;
				}
				this._DecoratorIssuer = value;
				decoratorIssuer = this._DecoratorIssuer;
				if (decoratorIssuer != null)
				{
					decoratorIssuer.Check += value2;
				}
			}
		}

		// Token: 0x17000285 RID: 645
		// (get) Token: 0x06000F78 RID: 3960 RVA: 0x000097B8 File Offset: 0x000079B8
		// (set) Token: 0x06000F79 RID: 3961 RVA: 0x0006E930 File Offset: 0x0006CB30
		internal virtual MyRadioBox RadioLauncherTheme6
		{
			[CompilerGenerated]
			get
			{
				return this._PropertyIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR135-18 == null) ? (PageSetupUI._Closure$__.$IR135-18 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR135-18;
				MyRadioBox propertyIssuer = this._PropertyIssuer;
				if (propertyIssuer != null)
				{
					propertyIssuer.Check -= value2;
				}
				this._PropertyIssuer = value;
				propertyIssuer = this._PropertyIssuer;
				if (propertyIssuer != null)
				{
					propertyIssuer.Check += value2;
				}
			}
		}

		// Token: 0x17000286 RID: 646
		// (get) Token: 0x06000F7A RID: 3962 RVA: 0x000097C0 File Offset: 0x000079C0
		// (set) Token: 0x06000F7B RID: 3963 RVA: 0x0006E98C File Offset: 0x0006CB8C
		internal virtual MyRadioBox RadioLauncherTheme7
		{
			[CompilerGenerated]
			get
			{
				return this.descriptorIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR139-19 == null) ? (PageSetupUI._Closure$__.$IR139-19 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR139-19;
				MyRadioBox myRadioBox = this.descriptorIssuer;
				if (myRadioBox != null)
				{
					myRadioBox.Check -= value2;
				}
				this.descriptorIssuer = value;
				myRadioBox = this.descriptorIssuer;
				if (myRadioBox != null)
				{
					myRadioBox.Check += value2;
				}
			}
		}

		// Token: 0x17000287 RID: 647
		// (get) Token: 0x06000F7C RID: 3964 RVA: 0x000097C8 File Offset: 0x000079C8
		// (set) Token: 0x06000F7D RID: 3965 RVA: 0x0006E9E8 File Offset: 0x0006CBE8
		internal virtual MyRadioBox MyRadioBox_1
		{
			[CompilerGenerated]
			get
			{
				return this.m_MapIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR143-20 == null) ? (PageSetupUI._Closure$__.$IR143-20 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR143-20;
				MyRadioBox mapIssuer = this.m_MapIssuer;
				if (mapIssuer != null)
				{
					mapIssuer.Check -= value2;
				}
				this.m_MapIssuer = value;
				mapIssuer = this.m_MapIssuer;
				if (mapIssuer != null)
				{
					mapIssuer.Check += value2;
				}
			}
		}

		// Token: 0x17000288 RID: 648
		// (get) Token: 0x06000F7E RID: 3966 RVA: 0x000097D0 File Offset: 0x000079D0
		// (set) Token: 0x06000F7F RID: 3967 RVA: 0x0006EA44 File Offset: 0x0006CC44
		internal virtual MyRadioBox RadioLauncherTheme8
		{
			[CompilerGenerated]
			get
			{
				return this._EventIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR147-21 == null) ? (PageSetupUI._Closure$__.$IR147-21 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR147-21;
				MyRadioBox eventIssuer = this._EventIssuer;
				if (eventIssuer != null)
				{
					eventIssuer.Check -= value2;
				}
				this._EventIssuer = value;
				eventIssuer = this._EventIssuer;
				if (eventIssuer != null)
				{
					eventIssuer.Check += value2;
				}
			}
		}

		// Token: 0x17000289 RID: 649
		// (get) Token: 0x06000F80 RID: 3968 RVA: 0x000097D8 File Offset: 0x000079D8
		// (set) Token: 0x06000F81 RID: 3969 RVA: 0x0006EAA0 File Offset: 0x0006CCA0
		internal virtual TextBlock LabLauncherTheme8Copy
		{
			[CompilerGenerated]
			get
			{
				return this._AlgoIssuer;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = delegate(object sender, MouseButtonEventArgs e)
				{
					this.LabLauncherTheme8Copy_MouseRightButtonUp();
				};
				TextBlock algoIssuer = this._AlgoIssuer;
				if (algoIssuer != null)
				{
					algoIssuer.MouseRightButtonUp -= value2;
				}
				this._AlgoIssuer = value;
				algoIssuer = this._AlgoIssuer;
				if (algoIssuer != null)
				{
					algoIssuer.MouseRightButtonUp += value2;
				}
			}
		}

		// Token: 0x1700028A RID: 650
		// (get) Token: 0x06000F82 RID: 3970 RVA: 0x000097E0 File Offset: 0x000079E0
		// (set) Token: 0x06000F83 RID: 3971 RVA: 0x0006EAE4 File Offset: 0x0006CCE4
		internal virtual MyRadioBox RadioLauncherTheme9
		{
			[CompilerGenerated]
			get
			{
				return this.m_PoolIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR155-23 == null) ? (PageSetupUI._Closure$__.$IR155-23 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR155-23;
				MyRadioBox poolIssuer = this.m_PoolIssuer;
				if (poolIssuer != null)
				{
					poolIssuer.Check -= value2;
				}
				this.m_PoolIssuer = value;
				poolIssuer = this.m_PoolIssuer;
				if (poolIssuer != null)
				{
					poolIssuer.Check += value2;
				}
			}
		}

		// Token: 0x1700028B RID: 651
		// (get) Token: 0x06000F84 RID: 3972 RVA: 0x000097E8 File Offset: 0x000079E8
		// (set) Token: 0x06000F85 RID: 3973 RVA: 0x0006EB40 File Offset: 0x0006CD40
		internal virtual TextBlock LabLauncherTheme9Copy
		{
			[CompilerGenerated]
			get
			{
				return this._PublisherIssuer;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = delegate(object sender, MouseButtonEventArgs e)
				{
					this.LabLauncherTheme9Copy_MouseRightButtonUp();
				};
				TextBlock publisherIssuer = this._PublisherIssuer;
				if (publisherIssuer != null)
				{
					publisherIssuer.MouseRightButtonUp -= value2;
				}
				this._PublisherIssuer = value;
				publisherIssuer = this._PublisherIssuer;
				if (publisherIssuer != null)
				{
					publisherIssuer.MouseRightButtonUp += value2;
				}
			}
		}

		// Token: 0x1700028C RID: 652
		// (get) Token: 0x06000F86 RID: 3974 RVA: 0x000097F0 File Offset: 0x000079F0
		// (set) Token: 0x06000F87 RID: 3975 RVA: 0x0006EB84 File Offset: 0x0006CD84
		internal virtual MyRadioBox MyRadioBox_2
		{
			[CompilerGenerated]
			get
			{
				return this.m_WatcherIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR163-25 == null) ? (PageSetupUI._Closure$__.$IR163-25 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR163-25;
				MyRadioBox watcherIssuer = this.m_WatcherIssuer;
				if (watcherIssuer != null)
				{
					watcherIssuer.Check -= value2;
				}
				this.m_WatcherIssuer = value;
				watcherIssuer = this.m_WatcherIssuer;
				if (watcherIssuer != null)
				{
					watcherIssuer.Check += value2;
				}
			}
		}

		// Token: 0x1700028D RID: 653
		// (get) Token: 0x06000F88 RID: 3976 RVA: 0x000097F8 File Offset: 0x000079F8
		// (set) Token: 0x06000F89 RID: 3977 RVA: 0x0006EBE0 File Offset: 0x0006CDE0
		internal virtual MyRadioBox MyRadioBox_3
		{
			[CompilerGenerated]
			get
			{
				return this.testIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR167-26 == null) ? (PageSetupUI._Closure$__.$IR167-26 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR167-26;
				MouseButtonEventHandler value3 = delegate(object sender, MouseButtonEventArgs e)
				{
					this.LabLauncherTheme11Click_MouseLeftButtonUp();
				};
				MyRadioBox myRadioBox = this.testIssuer;
				if (myRadioBox != null)
				{
					myRadioBox.Check -= value2;
					myRadioBox.MouseRightButtonUp -= value3;
				}
				this.testIssuer = value;
				myRadioBox = this.testIssuer;
				if (myRadioBox != null)
				{
					myRadioBox.Check += value2;
					myRadioBox.MouseRightButtonUp += value3;
				}
			}
		}

		// Token: 0x1700028E RID: 654
		// (get) Token: 0x06000F8A RID: 3978 RVA: 0x00009800 File Offset: 0x00007A00
		// (set) Token: 0x06000F8B RID: 3979 RVA: 0x0006EC58 File Offset: 0x0006CE58
		internal virtual TextBlock LabLauncherTheme11Click
		{
			[CompilerGenerated]
			get
			{
				return this.m_TaskIssuer;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = delegate(object sender, MouseButtonEventArgs e)
				{
					this.LabLauncherTheme11Click_MouseLeftButtonUp();
				};
				TextBlock taskIssuer = this.m_TaskIssuer;
				if (taskIssuer != null)
				{
					taskIssuer.MouseLeftButtonUp -= value2;
				}
				this.m_TaskIssuer = value;
				taskIssuer = this.m_TaskIssuer;
				if (taskIssuer != null)
				{
					taskIssuer.MouseLeftButtonUp += value2;
				}
			}
		}

		// Token: 0x1700028F RID: 655
		// (get) Token: 0x06000F8C RID: 3980 RVA: 0x00009808 File Offset: 0x00007A08
		// (set) Token: 0x06000F8D RID: 3981 RVA: 0x0006EC9C File Offset: 0x0006CE9C
		internal virtual MyRadioBox MyRadioBox_4
		{
			[CompilerGenerated]
			get
			{
				return this.m_IteratorIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR175-29 == null) ? (PageSetupUI._Closure$__.$IR175-29 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR175-29;
				IMyRadio.ChangedEventHandler value3 = new IMyRadio.ChangedEventHandler(this.RadioLauncherTheme14_Change);
				MyRadioBox iteratorIssuer = this.m_IteratorIssuer;
				if (iteratorIssuer != null)
				{
					iteratorIssuer.Check -= value2;
					iteratorIssuer.Changed -= value3;
				}
				this.m_IteratorIssuer = value;
				iteratorIssuer = this.m_IteratorIssuer;
				if (iteratorIssuer != null)
				{
					iteratorIssuer.Check += value2;
					iteratorIssuer.Changed += value3;
				}
			}
		}

		// Token: 0x17000290 RID: 656
		// (get) Token: 0x06000F8E RID: 3982 RVA: 0x00009810 File Offset: 0x00007A10
		// (set) Token: 0x06000F8F RID: 3983 RVA: 0x0006ED14 File Offset: 0x0006CF14
		internal virtual MyCheckBox CheckLauncherLogo
		{
			[CompilerGenerated]
			get
			{
				return this.serializerIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR179-30 == null) ? (PageSetupUI._Closure$__.$IR179-30 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR179-30;
				MyCheckBox myCheckBox = this.serializerIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.StopTag(obj);
				}
				this.serializerIssuer = value;
				myCheckBox = this.serializerIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.CloneTag(obj);
				}
			}
		}

		// Token: 0x17000291 RID: 657
		// (get) Token: 0x06000F90 RID: 3984 RVA: 0x00009818 File Offset: 0x00007A18
		// (set) Token: 0x06000F91 RID: 3985 RVA: 0x00009820 File Offset: 0x00007A20
		internal virtual Border PanLauncherHide { get; set; }

		// Token: 0x17000292 RID: 658
		// (get) Token: 0x06000F92 RID: 3986 RVA: 0x00009829 File Offset: 0x00007A29
		// (set) Token: 0x06000F93 RID: 3987 RVA: 0x0006ED70 File Offset: 0x0006CF70
		internal virtual MyButton BtnLauncherDonate
		{
			[CompilerGenerated]
			get
			{
				return this.valueIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnLauncherDonate_Click);
				MyButton myButton = this.valueIssuer;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.valueIssuer = value;
				myButton = this.valueIssuer;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000293 RID: 659
		// (get) Token: 0x06000F94 RID: 3988 RVA: 0x00009831 File Offset: 0x00007A31
		// (set) Token: 0x06000F95 RID: 3989 RVA: 0x00009839 File Offset: 0x00007A39
		internal virtual MyCard CardBackground { get; set; }

		// Token: 0x17000294 RID: 660
		// (get) Token: 0x06000F96 RID: 3990 RVA: 0x00009842 File Offset: 0x00007A42
		// (set) Token: 0x06000F97 RID: 3991 RVA: 0x0000984A File Offset: 0x00007A4A
		internal virtual Grid PanBackgroundSuit { get; set; }

		// Token: 0x17000295 RID: 661
		// (get) Token: 0x06000F98 RID: 3992 RVA: 0x00009853 File Offset: 0x00007A53
		// (set) Token: 0x06000F99 RID: 3993 RVA: 0x0006EDB4 File Offset: 0x0006CFB4
		internal virtual MyComboBox ComboBackgroundSuit
		{
			[CompilerGenerated]
			get
			{
				return this.helperIssuer;
			}
			[CompilerGenerated]
			set
			{
				SelectionChangedEventHandler value2 = (PageSetupUI._Closure$__.$IR199-31 == null) ? (PageSetupUI._Closure$__.$IR199-31 = delegate(object sender, SelectionChangedEventArgs e)
				{
					PageSetupUI.ComboChange((MyComboBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR199-31;
				MyComboBox myComboBox = this.helperIssuer;
				if (myComboBox != null)
				{
					myComboBox.SelectionChanged -= value2;
				}
				this.helperIssuer = value;
				myComboBox = this.helperIssuer;
				if (myComboBox != null)
				{
					myComboBox.SelectionChanged += value2;
				}
			}
		}

		// Token: 0x17000296 RID: 662
		// (get) Token: 0x06000F9A RID: 3994 RVA: 0x0000985B File Offset: 0x00007A5B
		// (set) Token: 0x06000F9B RID: 3995 RVA: 0x00009863 File Offset: 0x00007A63
		internal virtual Grid PanBackgroundOpacity { get; set; }

		// Token: 0x17000297 RID: 663
		// (get) Token: 0x06000F9C RID: 3996 RVA: 0x0000986C File Offset: 0x00007A6C
		// (set) Token: 0x06000F9D RID: 3997 RVA: 0x0006EE10 File Offset: 0x0006D010
		internal virtual MySlider SliderBackgroundOpacity
		{
			[CompilerGenerated]
			get
			{
				return this.m_BaseIssuer;
			}
			[CompilerGenerated]
			set
			{
				MySlider.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR207-32 == null) ? (PageSetupUI._Closure$__.$IR207-32 = delegate(object a0, bool a1)
				{
					PageSetupUI.SliderChange((MySlider)a0, a1);
				}) : PageSetupUI._Closure$__.$IR207-32;
				MySlider baseIssuer = this.m_BaseIssuer;
				if (baseIssuer != null)
				{
					baseIssuer.ViewTag(obj);
				}
				this.m_BaseIssuer = value;
				baseIssuer = this.m_BaseIssuer;
				if (baseIssuer != null)
				{
					baseIssuer.UpdateTag(obj);
				}
			}
		}

		// Token: 0x17000298 RID: 664
		// (get) Token: 0x06000F9E RID: 3998 RVA: 0x00009874 File Offset: 0x00007A74
		// (set) Token: 0x06000F9F RID: 3999 RVA: 0x0000987C File Offset: 0x00007A7C
		internal virtual Grid PanBackgroundBlur { get; set; }

		// Token: 0x17000299 RID: 665
		// (get) Token: 0x06000FA0 RID: 4000 RVA: 0x00009885 File Offset: 0x00007A85
		// (set) Token: 0x06000FA1 RID: 4001 RVA: 0x0006EE6C File Offset: 0x0006D06C
		internal virtual MySlider SliderBackgroundBlur
		{
			[CompilerGenerated]
			get
			{
				return this._AttrIssuer;
			}
			[CompilerGenerated]
			set
			{
				MySlider.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR215-33 == null) ? (PageSetupUI._Closure$__.$IR215-33 = delegate(object a0, bool a1)
				{
					PageSetupUI.SliderChange((MySlider)a0, a1);
				}) : PageSetupUI._Closure$__.$IR215-33;
				MySlider attrIssuer = this._AttrIssuer;
				if (attrIssuer != null)
				{
					attrIssuer.ViewTag(obj);
				}
				this._AttrIssuer = value;
				attrIssuer = this._AttrIssuer;
				if (attrIssuer != null)
				{
					attrIssuer.UpdateTag(obj);
				}
			}
		}

		// Token: 0x1700029A RID: 666
		// (get) Token: 0x06000FA2 RID: 4002 RVA: 0x0000988D File Offset: 0x00007A8D
		// (set) Token: 0x06000FA3 RID: 4003 RVA: 0x0006EEC8 File Offset: 0x0006D0C8
		internal virtual MyCheckBox CheckBackgroundColorful
		{
			[CompilerGenerated]
			get
			{
				return this.m_FacadeIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR219-34 == null) ? (PageSetupUI._Closure$__.$IR219-34 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR219-34;
				MyCheckBox facadeIssuer = this.m_FacadeIssuer;
				if (facadeIssuer != null)
				{
					facadeIssuer.StopTag(obj);
				}
				this.m_FacadeIssuer = value;
				facadeIssuer = this.m_FacadeIssuer;
				if (facadeIssuer != null)
				{
					facadeIssuer.CloneTag(obj);
				}
			}
		}

		// Token: 0x1700029B RID: 667
		// (get) Token: 0x06000FA4 RID: 4004 RVA: 0x00009895 File Offset: 0x00007A95
		// (set) Token: 0x06000FA5 RID: 4005 RVA: 0x0006EF24 File Offset: 0x0006D124
		internal virtual MyButton BtnBackgroundOpen
		{
			[CompilerGenerated]
			get
			{
				return this._BridgeIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnUIBgOpen_Click);
				MyButton bridgeIssuer = this._BridgeIssuer;
				if (bridgeIssuer != null)
				{
					bridgeIssuer.RevertResolver(obj);
				}
				this._BridgeIssuer = value;
				bridgeIssuer = this._BridgeIssuer;
				if (bridgeIssuer != null)
				{
					bridgeIssuer.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700029C RID: 668
		// (get) Token: 0x06000FA6 RID: 4006 RVA: 0x0000989D File Offset: 0x00007A9D
		// (set) Token: 0x06000FA7 RID: 4007 RVA: 0x0006EF68 File Offset: 0x0006D168
		internal virtual MyButton BtnBackgroundRefresh
		{
			[CompilerGenerated]
			get
			{
				return this._StructIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnBackgroundRefresh_Click);
				MyButton structIssuer = this._StructIssuer;
				if (structIssuer != null)
				{
					structIssuer.RevertResolver(obj);
				}
				this._StructIssuer = value;
				structIssuer = this._StructIssuer;
				if (structIssuer != null)
				{
					structIssuer.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700029D RID: 669
		// (get) Token: 0x06000FA8 RID: 4008 RVA: 0x000098A5 File Offset: 0x00007AA5
		// (set) Token: 0x06000FA9 RID: 4009 RVA: 0x0006EFAC File Offset: 0x0006D1AC
		internal virtual MyButton BtnBackgroundClear
		{
			[CompilerGenerated]
			get
			{
				return this.m_IndexerIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnBackgroundClear_Click);
				MyButton indexerIssuer = this.m_IndexerIssuer;
				if (indexerIssuer != null)
				{
					indexerIssuer.RevertResolver(obj);
				}
				this.m_IndexerIssuer = value;
				indexerIssuer = this.m_IndexerIssuer;
				if (indexerIssuer != null)
				{
					indexerIssuer.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700029E RID: 670
		// (get) Token: 0x06000FAA RID: 4010 RVA: 0x000098AD File Offset: 0x00007AAD
		// (set) Token: 0x06000FAB RID: 4011 RVA: 0x000098B5 File Offset: 0x00007AB5
		internal virtual MyCard CardMusic { get; set; }

		// Token: 0x1700029F RID: 671
		// (get) Token: 0x06000FAC RID: 4012 RVA: 0x000098BE File Offset: 0x00007ABE
		// (set) Token: 0x06000FAD RID: 4013 RVA: 0x000098C6 File Offset: 0x00007AC6
		internal virtual Grid PanMusicVolume { get; set; }

		// Token: 0x170002A0 RID: 672
		// (get) Token: 0x06000FAE RID: 4014 RVA: 0x000098CF File Offset: 0x00007ACF
		// (set) Token: 0x06000FAF RID: 4015 RVA: 0x0006EFF0 File Offset: 0x0006D1F0
		internal virtual MySlider SliderMusicVolume
		{
			[CompilerGenerated]
			get
			{
				return this._GetterIssuer;
			}
			[CompilerGenerated]
			set
			{
				MySlider.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR243-35 == null) ? (PageSetupUI._Closure$__.$IR243-35 = delegate(object a0, bool a1)
				{
					PageSetupUI.SliderChange((MySlider)a0, a1);
				}) : PageSetupUI._Closure$__.$IR243-35;
				MySlider getterIssuer = this._GetterIssuer;
				if (getterIssuer != null)
				{
					getterIssuer.ViewTag(obj);
				}
				this._GetterIssuer = value;
				getterIssuer = this._GetterIssuer;
				if (getterIssuer != null)
				{
					getterIssuer.UpdateTag(obj);
				}
			}
		}

		// Token: 0x170002A1 RID: 673
		// (get) Token: 0x06000FB0 RID: 4016 RVA: 0x000098D7 File Offset: 0x00007AD7
		// (set) Token: 0x06000FB1 RID: 4017 RVA: 0x0006F04C File Offset: 0x0006D24C
		internal virtual MyCheckBox CheckMusicAuto
		{
			[CompilerGenerated]
			get
			{
				return this.m_ListenerIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR247-36 == null) ? (PageSetupUI._Closure$__.$IR247-36 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR247-36;
				MyCheckBox listenerIssuer = this.m_ListenerIssuer;
				if (listenerIssuer != null)
				{
					listenerIssuer.StopTag(obj);
				}
				this.m_ListenerIssuer = value;
				listenerIssuer = this.m_ListenerIssuer;
				if (listenerIssuer != null)
				{
					listenerIssuer.CloneTag(obj);
				}
			}
		}

		// Token: 0x170002A2 RID: 674
		// (get) Token: 0x06000FB2 RID: 4018 RVA: 0x000098DF File Offset: 0x00007ADF
		// (set) Token: 0x06000FB3 RID: 4019 RVA: 0x0006F0A8 File Offset: 0x0006D2A8
		internal virtual MyCheckBox CheckMusicStart
		{
			[CompilerGenerated]
			get
			{
				return this._IdentifierIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR251-37 == null) ? (PageSetupUI._Closure$__.$IR251-37 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR251-37;
				MyCheckBox.ChangeEventHandler obj2 = delegate(object a0, bool a1)
				{
					this.CheckMusicStart_Change();
				};
				MyCheckBox identifierIssuer = this._IdentifierIssuer;
				if (identifierIssuer != null)
				{
					identifierIssuer.StopTag(obj);
					identifierIssuer.StopTag(obj2);
				}
				this._IdentifierIssuer = value;
				identifierIssuer = this._IdentifierIssuer;
				if (identifierIssuer != null)
				{
					identifierIssuer.CloneTag(obj);
					identifierIssuer.CloneTag(obj2);
				}
			}
		}

		// Token: 0x170002A3 RID: 675
		// (get) Token: 0x06000FB4 RID: 4020 RVA: 0x000098E7 File Offset: 0x00007AE7
		// (set) Token: 0x06000FB5 RID: 4021 RVA: 0x0006F120 File Offset: 0x0006D320
		internal virtual MyCheckBox CheckMusicStop
		{
			[CompilerGenerated]
			get
			{
				return this.m_InstanceIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR255-39 == null) ? (PageSetupUI._Closure$__.$IR255-39 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR255-39;
				MyCheckBox.ChangeEventHandler obj2 = delegate(object a0, bool a1)
				{
					this.CheckMusicStop_Change();
				};
				MyCheckBox instanceIssuer = this.m_InstanceIssuer;
				if (instanceIssuer != null)
				{
					instanceIssuer.StopTag(obj);
					instanceIssuer.StopTag(obj2);
				}
				this.m_InstanceIssuer = value;
				instanceIssuer = this.m_InstanceIssuer;
				if (instanceIssuer != null)
				{
					instanceIssuer.CloneTag(obj);
					instanceIssuer.CloneTag(obj2);
				}
			}
		}

		// Token: 0x170002A4 RID: 676
		// (get) Token: 0x06000FB6 RID: 4022 RVA: 0x000098EF File Offset: 0x00007AEF
		// (set) Token: 0x06000FB7 RID: 4023 RVA: 0x0006F198 File Offset: 0x0006D398
		internal virtual MyButton BtnMusicOpen
		{
			[CompilerGenerated]
			get
			{
				return this._CreatorIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnMusicOpen_Click);
				MyButton creatorIssuer = this._CreatorIssuer;
				if (creatorIssuer != null)
				{
					creatorIssuer.RevertResolver(obj);
				}
				this._CreatorIssuer = value;
				creatorIssuer = this._CreatorIssuer;
				if (creatorIssuer != null)
				{
					creatorIssuer.PostResolver(obj);
				}
			}
		}

		// Token: 0x170002A5 RID: 677
		// (get) Token: 0x06000FB8 RID: 4024 RVA: 0x000098F7 File Offset: 0x00007AF7
		// (set) Token: 0x06000FB9 RID: 4025 RVA: 0x0006F1DC File Offset: 0x0006D3DC
		internal virtual MyButton BtnMusicRefresh
		{
			[CompilerGenerated]
			get
			{
				return this.objectIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnMusicRefresh_Click);
				MyButton myButton = this.objectIssuer;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.objectIssuer = value;
				myButton = this.objectIssuer;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x170002A6 RID: 678
		// (get) Token: 0x06000FBA RID: 4026 RVA: 0x000098FF File Offset: 0x00007AFF
		// (set) Token: 0x06000FBB RID: 4027 RVA: 0x0006F220 File Offset: 0x0006D420
		internal virtual MyButton BtnMusicClear
		{
			[CompilerGenerated]
			get
			{
				return this._RegIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnMusicClear_Click);
				MyButton regIssuer = this._RegIssuer;
				if (regIssuer != null)
				{
					regIssuer.RevertResolver(obj);
				}
				this._RegIssuer = value;
				regIssuer = this._RegIssuer;
				if (regIssuer != null)
				{
					regIssuer.PostResolver(obj);
				}
			}
		}

		// Token: 0x170002A7 RID: 679
		// (get) Token: 0x06000FBC RID: 4028 RVA: 0x00009907 File Offset: 0x00007B07
		// (set) Token: 0x06000FBD RID: 4029 RVA: 0x0000990F File Offset: 0x00007B0F
		internal virtual MyCard CardLogo { get; set; }

		// Token: 0x170002A8 RID: 680
		// (get) Token: 0x06000FBE RID: 4030 RVA: 0x00009918 File Offset: 0x00007B18
		// (set) Token: 0x06000FBF RID: 4031 RVA: 0x0006F264 File Offset: 0x0006D464
		internal virtual MyRadioBox RadioLogoType0
		{
			[CompilerGenerated]
			get
			{
				return this.composerIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR275-41 == null) ? (PageSetupUI._Closure$__.$IR275-41 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR275-41;
				MyRadioBox myRadioBox = this.composerIssuer;
				if (myRadioBox != null)
				{
					myRadioBox.Check -= value2;
				}
				this.composerIssuer = value;
				myRadioBox = this.composerIssuer;
				if (myRadioBox != null)
				{
					myRadioBox.Check += value2;
				}
			}
		}

		// Token: 0x170002A9 RID: 681
		// (get) Token: 0x06000FC0 RID: 4032 RVA: 0x00009920 File Offset: 0x00007B20
		// (set) Token: 0x06000FC1 RID: 4033 RVA: 0x0006F2C0 File Offset: 0x0006D4C0
		internal virtual MyRadioBox RadioLogoType1
		{
			[CompilerGenerated]
			get
			{
				return this._ItemIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR279-42 == null) ? (PageSetupUI._Closure$__.$IR279-42 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR279-42;
				MyRadioBox itemIssuer = this._ItemIssuer;
				if (itemIssuer != null)
				{
					itemIssuer.Check -= value2;
				}
				this._ItemIssuer = value;
				itemIssuer = this._ItemIssuer;
				if (itemIssuer != null)
				{
					itemIssuer.Check += value2;
				}
			}
		}

		// Token: 0x170002AA RID: 682
		// (get) Token: 0x06000FC2 RID: 4034 RVA: 0x00009928 File Offset: 0x00007B28
		// (set) Token: 0x06000FC3 RID: 4035 RVA: 0x0006F31C File Offset: 0x0006D51C
		internal virtual MyRadioBox RadioLogoType2
		{
			[CompilerGenerated]
			get
			{
				return this.mapperIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR283-43 == null) ? (PageSetupUI._Closure$__.$IR283-43 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR283-43;
				MyRadioBox myRadioBox = this.mapperIssuer;
				if (myRadioBox != null)
				{
					myRadioBox.Check -= value2;
				}
				this.mapperIssuer = value;
				myRadioBox = this.mapperIssuer;
				if (myRadioBox != null)
				{
					myRadioBox.Check += value2;
				}
			}
		}

		// Token: 0x170002AB RID: 683
		// (get) Token: 0x06000FC4 RID: 4036 RVA: 0x00009930 File Offset: 0x00007B30
		// (set) Token: 0x06000FC5 RID: 4037 RVA: 0x0006F378 File Offset: 0x0006D578
		internal virtual MyRadioBox RadioLogoType3
		{
			[CompilerGenerated]
			get
			{
				return this.factoryIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR287-44 == null) ? (PageSetupUI._Closure$__.$IR287-44 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR287-44;
				MyRadioBox.PreviewCheckEventHandler obj = new MyRadioBox.PreviewCheckEventHandler(this.RadioLogoType3_Check);
				MyRadioBox myRadioBox = this.factoryIssuer;
				if (myRadioBox != null)
				{
					myRadioBox.Check -= value2;
					myRadioBox.NewTag(obj);
				}
				this.factoryIssuer = value;
				myRadioBox = this.factoryIssuer;
				if (myRadioBox != null)
				{
					myRadioBox.Check += value2;
					myRadioBox.ConnectTag(obj);
				}
			}
		}

		// Token: 0x170002AC RID: 684
		// (get) Token: 0x06000FC6 RID: 4038 RVA: 0x00009938 File Offset: 0x00007B38
		// (set) Token: 0x06000FC7 RID: 4039 RVA: 0x0006F3F0 File Offset: 0x0006D5F0
		internal virtual MyCheckBox CheckLogoLeft
		{
			[CompilerGenerated]
			get
			{
				return this.processIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR291-45 == null) ? (PageSetupUI._Closure$__.$IR291-45 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR291-45;
				MyCheckBox myCheckBox = this.processIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.StopTag(obj);
				}
				this.processIssuer = value;
				myCheckBox = this.processIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.CloneTag(obj);
				}
			}
		}

		// Token: 0x170002AD RID: 685
		// (get) Token: 0x06000FC8 RID: 4040 RVA: 0x00009940 File Offset: 0x00007B40
		// (set) Token: 0x06000FC9 RID: 4041 RVA: 0x00009948 File Offset: 0x00007B48
		internal virtual Grid PanLogoText { get; set; }

		// Token: 0x170002AE RID: 686
		// (get) Token: 0x06000FCA RID: 4042 RVA: 0x00009951 File Offset: 0x00007B51
		// (set) Token: 0x06000FCB RID: 4043 RVA: 0x0006F44C File Offset: 0x0006D64C
		internal virtual MyTextBox TextLogoText
		{
			[CompilerGenerated]
			get
			{
				return this.m_UtilsIssuer;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageSetupUI._Closure$__.$IR299-46 == null) ? (PageSetupUI._Closure$__.$IR299-46 = delegate(object sender, RoutedEventArgs e)
				{
					PageSetupUI.TextBoxChange((MyTextBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR299-46;
				MyTextBox utilsIssuer = this.m_UtilsIssuer;
				if (utilsIssuer != null)
				{
					utilsIssuer.FindRepository(value2);
				}
				this.m_UtilsIssuer = value;
				utilsIssuer = this.m_UtilsIssuer;
				if (utilsIssuer != null)
				{
					utilsIssuer.SetupRepository(value2);
				}
			}
		}

		// Token: 0x170002AF RID: 687
		// (get) Token: 0x06000FCC RID: 4044 RVA: 0x00009959 File Offset: 0x00007B59
		// (set) Token: 0x06000FCD RID: 4045 RVA: 0x00009961 File Offset: 0x00007B61
		internal virtual Grid PanLogoChange { get; set; }

		// Token: 0x170002B0 RID: 688
		// (get) Token: 0x06000FCE RID: 4046 RVA: 0x0000996A File Offset: 0x00007B6A
		// (set) Token: 0x06000FCF RID: 4047 RVA: 0x0006F4A8 File Offset: 0x0006D6A8
		internal virtual MyButton BtnLogoChange
		{
			[CompilerGenerated]
			get
			{
				return this.m_PolicyIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnLogoChange_Click);
				MyButton policyIssuer = this.m_PolicyIssuer;
				if (policyIssuer != null)
				{
					policyIssuer.RevertResolver(obj);
				}
				this.m_PolicyIssuer = value;
				policyIssuer = this.m_PolicyIssuer;
				if (policyIssuer != null)
				{
					policyIssuer.PostResolver(obj);
				}
			}
		}

		// Token: 0x170002B1 RID: 689
		// (get) Token: 0x06000FD0 RID: 4048 RVA: 0x00009972 File Offset: 0x00007B72
		// (set) Token: 0x06000FD1 RID: 4049 RVA: 0x0006F4EC File Offset: 0x0006D6EC
		internal virtual MyButton BtnLogoDelete
		{
			[CompilerGenerated]
			get
			{
				return this.m_ThreadIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnLogoDelete_Click);
				MyButton threadIssuer = this.m_ThreadIssuer;
				if (threadIssuer != null)
				{
					threadIssuer.RevertResolver(obj);
				}
				this.m_ThreadIssuer = value;
				threadIssuer = this.m_ThreadIssuer;
				if (threadIssuer != null)
				{
					threadIssuer.PostResolver(obj);
				}
			}
		}

		// Token: 0x170002B2 RID: 690
		// (get) Token: 0x06000FD2 RID: 4050 RVA: 0x0000997A File Offset: 0x00007B7A
		// (set) Token: 0x06000FD3 RID: 4051 RVA: 0x00009982 File Offset: 0x00007B82
		internal virtual MyCard CardCustom { get; set; }

		// Token: 0x170002B3 RID: 691
		// (get) Token: 0x06000FD4 RID: 4052 RVA: 0x0000998B File Offset: 0x00007B8B
		// (set) Token: 0x06000FD5 RID: 4053 RVA: 0x0006F530 File Offset: 0x0006D730
		internal virtual MyRadioBox RadioCustomType0
		{
			[CompilerGenerated]
			get
			{
				return this._CustomerIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR319-47 == null) ? (PageSetupUI._Closure$__.$IR319-47 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR319-47;
				MyRadioBox customerIssuer = this._CustomerIssuer;
				if (customerIssuer != null)
				{
					customerIssuer.Check -= value2;
				}
				this._CustomerIssuer = value;
				customerIssuer = this._CustomerIssuer;
				if (customerIssuer != null)
				{
					customerIssuer.Check += value2;
				}
			}
		}

		// Token: 0x170002B4 RID: 692
		// (get) Token: 0x06000FD6 RID: 4054 RVA: 0x00009993 File Offset: 0x00007B93
		// (set) Token: 0x06000FD7 RID: 4055 RVA: 0x0006F58C File Offset: 0x0006D78C
		internal virtual MyRadioBox RadioCustomType1
		{
			[CompilerGenerated]
			get
			{
				return this.m_SchemaIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR323-48 == null) ? (PageSetupUI._Closure$__.$IR323-48 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR323-48;
				MyRadioBox schemaIssuer = this.m_SchemaIssuer;
				if (schemaIssuer != null)
				{
					schemaIssuer.Check -= value2;
				}
				this.m_SchemaIssuer = value;
				schemaIssuer = this.m_SchemaIssuer;
				if (schemaIssuer != null)
				{
					schemaIssuer.Check += value2;
				}
			}
		}

		// Token: 0x170002B5 RID: 693
		// (get) Token: 0x06000FD8 RID: 4056 RVA: 0x0000999B File Offset: 0x00007B9B
		// (set) Token: 0x06000FD9 RID: 4057 RVA: 0x0006F5E8 File Offset: 0x0006D7E8
		internal virtual MyRadioBox RadioCustomType2
		{
			[CompilerGenerated]
			get
			{
				return this.databaseIssuer;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupUI._Closure$__.$IR327-49 == null) ? (PageSetupUI._Closure$__.$IR327-49 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupUI.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR327-49;
				MyRadioBox myRadioBox = this.databaseIssuer;
				if (myRadioBox != null)
				{
					myRadioBox.Check -= value2;
				}
				this.databaseIssuer = value;
				myRadioBox = this.databaseIssuer;
				if (myRadioBox != null)
				{
					myRadioBox.Check += value2;
				}
			}
		}

		// Token: 0x170002B6 RID: 694
		// (get) Token: 0x06000FDA RID: 4058 RVA: 0x000099A3 File Offset: 0x00007BA3
		// (set) Token: 0x06000FDB RID: 4059 RVA: 0x000099AB File Offset: 0x00007BAB
		internal virtual Grid PanCustomLocal { get; set; }

		// Token: 0x170002B7 RID: 695
		// (get) Token: 0x06000FDC RID: 4060 RVA: 0x000099B4 File Offset: 0x00007BB4
		// (set) Token: 0x06000FDD RID: 4061 RVA: 0x0006F644 File Offset: 0x0006D844
		internal virtual MyButton BtnCustomRefresh
		{
			[CompilerGenerated]
			get
			{
				return this.m_AdvisorIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.BtnCustomRefresh_Click();
				};
				MyButton advisorIssuer = this.m_AdvisorIssuer;
				if (advisorIssuer != null)
				{
					advisorIssuer.RevertResolver(obj);
				}
				this.m_AdvisorIssuer = value;
				advisorIssuer = this.m_AdvisorIssuer;
				if (advisorIssuer != null)
				{
					advisorIssuer.PostResolver(obj);
				}
			}
		}

		// Token: 0x170002B8 RID: 696
		// (get) Token: 0x06000FDE RID: 4062 RVA: 0x000099BC File Offset: 0x00007BBC
		// (set) Token: 0x06000FDF RID: 4063 RVA: 0x0006F688 File Offset: 0x0006D888
		internal virtual MyButton BtnCustomFile
		{
			[CompilerGenerated]
			get
			{
				return this.m_ObserverIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnCustomFile_Click);
				MyButton observerIssuer = this.m_ObserverIssuer;
				if (observerIssuer != null)
				{
					observerIssuer.RevertResolver(obj);
				}
				this.m_ObserverIssuer = value;
				observerIssuer = this.m_ObserverIssuer;
				if (observerIssuer != null)
				{
					observerIssuer.PostResolver(obj);
				}
			}
		}

		// Token: 0x170002B9 RID: 697
		// (get) Token: 0x06000FE0 RID: 4064 RVA: 0x000099C4 File Offset: 0x00007BC4
		// (set) Token: 0x06000FE1 RID: 4065 RVA: 0x0006F6CC File Offset: 0x0006D8CC
		internal virtual MyButton BtnCustomTutorial
		{
			[CompilerGenerated]
			get
			{
				return this.m_SingletonIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnCustomTutorial_Click);
				MyButton singletonIssuer = this.m_SingletonIssuer;
				if (singletonIssuer != null)
				{
					singletonIssuer.RevertResolver(obj);
				}
				this.m_SingletonIssuer = value;
				singletonIssuer = this.m_SingletonIssuer;
				if (singletonIssuer != null)
				{
					singletonIssuer.PostResolver(obj);
				}
			}
		}

		// Token: 0x170002BA RID: 698
		// (get) Token: 0x06000FE2 RID: 4066 RVA: 0x000099CC File Offset: 0x00007BCC
		// (set) Token: 0x06000FE3 RID: 4067 RVA: 0x000099D4 File Offset: 0x00007BD4
		internal virtual Grid PanCustomNet { get; set; }

		// Token: 0x170002BB RID: 699
		// (get) Token: 0x06000FE4 RID: 4068 RVA: 0x000099DD File Offset: 0x00007BDD
		// (set) Token: 0x06000FE5 RID: 4069 RVA: 0x0006F710 File Offset: 0x0006D910
		internal virtual MyTextBox TextCustomNet
		{
			[CompilerGenerated]
			get
			{
				return this._CollectionIssuer;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageSetupUI._Closure$__.$IR351-51 == null) ? (PageSetupUI._Closure$__.$IR351-51 = delegate(object sender, RoutedEventArgs e)
				{
					PageSetupUI.TextBoxChange((MyTextBox)sender, e);
				}) : PageSetupUI._Closure$__.$IR351-51;
				MyTextBox collectionIssuer = this._CollectionIssuer;
				if (collectionIssuer != null)
				{
					collectionIssuer.FindRepository(value2);
				}
				this._CollectionIssuer = value;
				collectionIssuer = this._CollectionIssuer;
				if (collectionIssuer != null)
				{
					collectionIssuer.SetupRepository(value2);
				}
			}
		}

		// Token: 0x170002BC RID: 700
		// (get) Token: 0x06000FE6 RID: 4070 RVA: 0x000099E5 File Offset: 0x00007BE5
		// (set) Token: 0x06000FE7 RID: 4071 RVA: 0x000099ED File Offset: 0x00007BED
		internal virtual MyCard CardSwitch { get; set; }

		// Token: 0x170002BD RID: 701
		// (get) Token: 0x06000FE8 RID: 4072 RVA: 0x000099F6 File Offset: 0x00007BF6
		// (set) Token: 0x06000FE9 RID: 4073 RVA: 0x0006F76C File Offset: 0x0006D96C
		internal virtual MyCheckBox CheckHiddenPageDownload
		{
			[CompilerGenerated]
			get
			{
				return this.filterIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR359-52 == null) ? (PageSetupUI._Closure$__.$IR359-52 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR359-52;
				MyCheckBox myCheckBox = this.filterIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.StopTag(obj);
				}
				this.filterIssuer = value;
				myCheckBox = this.filterIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.CloneTag(obj);
				}
			}
		}

		// Token: 0x170002BE RID: 702
		// (get) Token: 0x06000FEA RID: 4074 RVA: 0x000099FE File Offset: 0x00007BFE
		// (set) Token: 0x06000FEB RID: 4075 RVA: 0x0006F7C8 File Offset: 0x0006D9C8
		internal virtual MyCheckBox CheckHiddenPageLink
		{
			[CompilerGenerated]
			get
			{
				return this.readerIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR363-53 == null) ? (PageSetupUI._Closure$__.$IR363-53 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR363-53;
				MyCheckBox myCheckBox = this.readerIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.StopTag(obj);
				}
				this.readerIssuer = value;
				myCheckBox = this.readerIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.CloneTag(obj);
				}
			}
		}

		// Token: 0x170002BF RID: 703
		// (get) Token: 0x06000FEC RID: 4076 RVA: 0x00009A06 File Offset: 0x00007C06
		// (set) Token: 0x06000FED RID: 4077 RVA: 0x0006F824 File Offset: 0x0006DA24
		internal virtual MyCheckBox CheckHiddenPageSetup
		{
			[CompilerGenerated]
			get
			{
				return this.fieldIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR367-54 == null) ? (PageSetupUI._Closure$__.$IR367-54 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR367-54;
				MyCheckBox.ChangeEventHandler obj2 = new MyCheckBox.ChangeEventHandler(this.HiddenSetupEntry);
				MyCheckBox.ChangeEventHandler obj3 = new MyCheckBox.ChangeEventHandler(this.HiddenHint);
				MyCheckBox myCheckBox = this.fieldIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.StopTag(obj);
					myCheckBox.StopTag(obj2);
					myCheckBox.StopTag(obj3);
				}
				this.fieldIssuer = value;
				myCheckBox = this.fieldIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.CloneTag(obj);
					myCheckBox.CloneTag(obj2);
					myCheckBox.CloneTag(obj3);
				}
			}
		}

		// Token: 0x170002C0 RID: 704
		// (get) Token: 0x06000FEE RID: 4078 RVA: 0x00009A0E File Offset: 0x00007C0E
		// (set) Token: 0x06000FEF RID: 4079 RVA: 0x0006F8B8 File Offset: 0x0006DAB8
		internal virtual MyCheckBox CheckHiddenPageOther
		{
			[CompilerGenerated]
			get
			{
				return this.pageIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR371-55 == null) ? (PageSetupUI._Closure$__.$IR371-55 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR371-55;
				MyCheckBox.ChangeEventHandler obj2 = new MyCheckBox.ChangeEventHandler(this.HiddenOtherEntry);
				MyCheckBox myCheckBox = this.pageIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.StopTag(obj);
					myCheckBox.StopTag(obj2);
				}
				this.pageIssuer = value;
				myCheckBox = this.pageIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.CloneTag(obj);
					myCheckBox.CloneTag(obj2);
				}
			}
		}

		// Token: 0x170002C1 RID: 705
		// (get) Token: 0x06000FF0 RID: 4080 RVA: 0x00009A16 File Offset: 0x00007C16
		// (set) Token: 0x06000FF1 RID: 4081 RVA: 0x0006F930 File Offset: 0x0006DB30
		internal virtual MyCheckBox CheckHiddenSetupLaunch
		{
			[CompilerGenerated]
			get
			{
				return this.m_PrinterIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR375-56 == null) ? (PageSetupUI._Closure$__.$IR375-56 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR375-56;
				MyCheckBox.ChangeEventHandler obj2 = delegate(object a0, bool a1)
				{
					this.HiddenSetupAll();
				};
				MyCheckBox printerIssuer = this.m_PrinterIssuer;
				if (printerIssuer != null)
				{
					printerIssuer.StopTag(obj);
					printerIssuer.StopTag(obj2);
				}
				this.m_PrinterIssuer = value;
				printerIssuer = this.m_PrinterIssuer;
				if (printerIssuer != null)
				{
					printerIssuer.CloneTag(obj);
					printerIssuer.CloneTag(obj2);
				}
			}
		}

		// Token: 0x170002C2 RID: 706
		// (get) Token: 0x06000FF2 RID: 4082 RVA: 0x00009A1E File Offset: 0x00007C1E
		// (set) Token: 0x06000FF3 RID: 4083 RVA: 0x0006F9A8 File Offset: 0x0006DBA8
		internal virtual MyCheckBox CheckHiddenSetupUI
		{
			[CompilerGenerated]
			get
			{
				return this._TokenIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR379-58 == null) ? (PageSetupUI._Closure$__.$IR379-58 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR379-58;
				MyCheckBox.ChangeEventHandler obj2 = delegate(object a0, bool a1)
				{
					this.HiddenSetupAll();
				};
				MyCheckBox.ChangeEventHandler obj3 = new MyCheckBox.ChangeEventHandler(this.HiddenHint);
				MyCheckBox tokenIssuer = this._TokenIssuer;
				if (tokenIssuer != null)
				{
					tokenIssuer.StopTag(obj);
					tokenIssuer.StopTag(obj2);
					tokenIssuer.StopTag(obj3);
				}
				this._TokenIssuer = value;
				tokenIssuer = this._TokenIssuer;
				if (tokenIssuer != null)
				{
					tokenIssuer.CloneTag(obj);
					tokenIssuer.CloneTag(obj2);
					tokenIssuer.CloneTag(obj3);
				}
			}
		}

		// Token: 0x170002C3 RID: 707
		// (get) Token: 0x06000FF4 RID: 4084 RVA: 0x00009A26 File Offset: 0x00007C26
		// (set) Token: 0x06000FF5 RID: 4085 RVA: 0x0006FA3C File Offset: 0x0006DC3C
		internal virtual MyCheckBox CheckHiddenSetupSystem
		{
			[CompilerGenerated]
			get
			{
				return this.interpreterIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR383-60 == null) ? (PageSetupUI._Closure$__.$IR383-60 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR383-60;
				MyCheckBox.ChangeEventHandler obj2 = delegate(object a0, bool a1)
				{
					this.HiddenSetupAll();
				};
				MyCheckBox myCheckBox = this.interpreterIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.StopTag(obj);
					myCheckBox.StopTag(obj2);
				}
				this.interpreterIssuer = value;
				myCheckBox = this.interpreterIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.CloneTag(obj);
					myCheckBox.CloneTag(obj2);
				}
			}
		}

		// Token: 0x170002C4 RID: 708
		// (get) Token: 0x06000FF6 RID: 4086 RVA: 0x00009A2E File Offset: 0x00007C2E
		// (set) Token: 0x06000FF7 RID: 4087 RVA: 0x0006FAB4 File Offset: 0x0006DCB4
		internal virtual MyCheckBox CheckHiddenSetupTool
		{
			[CompilerGenerated]
			get
			{
				return this.m_ParserIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR387-62 == null) ? (PageSetupUI._Closure$__.$IR387-62 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR387-62;
				MyCheckBox.ChangeEventHandler obj2 = delegate(object a0, bool a1)
				{
					this.HiddenSetupAll();
				};
				MyCheckBox parserIssuer = this.m_ParserIssuer;
				if (parserIssuer != null)
				{
					parserIssuer.StopTag(obj);
					parserIssuer.StopTag(obj2);
				}
				this.m_ParserIssuer = value;
				parserIssuer = this.m_ParserIssuer;
				if (parserIssuer != null)
				{
					parserIssuer.CloneTag(obj);
					parserIssuer.CloneTag(obj2);
				}
			}
		}

		// Token: 0x170002C5 RID: 709
		// (get) Token: 0x06000FF8 RID: 4088 RVA: 0x00009A36 File Offset: 0x00007C36
		// (set) Token: 0x06000FF9 RID: 4089 RVA: 0x0006FB2C File Offset: 0x0006DD2C
		internal virtual MyCheckBox CheckHiddenOtherHelp
		{
			[CompilerGenerated]
			get
			{
				return this._StubIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR391-64 == null) ? (PageSetupUI._Closure$__.$IR391-64 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR391-64;
				MyCheckBox.ChangeEventHandler obj2 = delegate(object a0, bool a1)
				{
					this.HiddenOtherAll();
				};
				MyCheckBox stubIssuer = this._StubIssuer;
				if (stubIssuer != null)
				{
					stubIssuer.StopTag(obj);
					stubIssuer.StopTag(obj2);
				}
				this._StubIssuer = value;
				stubIssuer = this._StubIssuer;
				if (stubIssuer != null)
				{
					stubIssuer.CloneTag(obj);
					stubIssuer.CloneTag(obj2);
				}
			}
		}

		// Token: 0x170002C6 RID: 710
		// (get) Token: 0x06000FFA RID: 4090 RVA: 0x00009A3E File Offset: 0x00007C3E
		// (set) Token: 0x06000FFB RID: 4091 RVA: 0x0006FBA4 File Offset: 0x0006DDA4
		internal virtual MyCheckBox CheckHiddenOtherAbout
		{
			[CompilerGenerated]
			get
			{
				return this.errorIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR395-66 == null) ? (PageSetupUI._Closure$__.$IR395-66 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR395-66;
				MyCheckBox.ChangeEventHandler obj2 = delegate(object a0, bool a1)
				{
					this.HiddenOtherAll();
				};
				MyCheckBox myCheckBox = this.errorIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.StopTag(obj);
					myCheckBox.StopTag(obj2);
				}
				this.errorIssuer = value;
				myCheckBox = this.errorIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.CloneTag(obj);
					myCheckBox.CloneTag(obj2);
				}
			}
		}

		// Token: 0x170002C7 RID: 711
		// (get) Token: 0x06000FFC RID: 4092 RVA: 0x00009A46 File Offset: 0x00007C46
		// (set) Token: 0x06000FFD RID: 4093 RVA: 0x0006FC1C File Offset: 0x0006DE1C
		internal virtual MyCheckBox CheckHiddenOtherTest
		{
			[CompilerGenerated]
			get
			{
				return this.exceptionIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR399-68 == null) ? (PageSetupUI._Closure$__.$IR399-68 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR399-68;
				MyCheckBox.ChangeEventHandler obj2 = delegate(object a0, bool a1)
				{
					this.HiddenOtherAll();
				};
				MyCheckBox myCheckBox = this.exceptionIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.StopTag(obj);
					myCheckBox.StopTag(obj2);
				}
				this.exceptionIssuer = value;
				myCheckBox = this.exceptionIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.CloneTag(obj);
					myCheckBox.CloneTag(obj2);
				}
			}
		}

		// Token: 0x170002C8 RID: 712
		// (get) Token: 0x06000FFE RID: 4094 RVA: 0x00009A4E File Offset: 0x00007C4E
		// (set) Token: 0x06000FFF RID: 4095 RVA: 0x0006FC94 File Offset: 0x0006DE94
		internal virtual MyCheckBox CheckHiddenOtherFeedback
		{
			[CompilerGenerated]
			get
			{
				return this.testsIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR403-70 == null) ? (PageSetupUI._Closure$__.$IR403-70 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR403-70;
				MyCheckBox.ChangeEventHandler obj2 = delegate(object a0, bool a1)
				{
					this.HiddenOtherAll();
				};
				MyCheckBox myCheckBox = this.testsIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.StopTag(obj);
					myCheckBox.StopTag(obj2);
				}
				this.testsIssuer = value;
				myCheckBox = this.testsIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.CloneTag(obj);
					myCheckBox.CloneTag(obj2);
				}
			}
		}

		// Token: 0x170002C9 RID: 713
		// (get) Token: 0x06001000 RID: 4096 RVA: 0x00009A56 File Offset: 0x00007C56
		// (set) Token: 0x06001001 RID: 4097 RVA: 0x0006FD0C File Offset: 0x0006DF0C
		internal virtual MyCheckBox CheckLauncherEmail
		{
			[CompilerGenerated]
			get
			{
				return this._StrategyIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR407-72 == null) ? (PageSetupUI._Closure$__.$IR407-72 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR407-72;
				MyCheckBox strategyIssuer = this._StrategyIssuer;
				if (strategyIssuer != null)
				{
					strategyIssuer.StopTag(obj);
				}
				this._StrategyIssuer = value;
				strategyIssuer = this._StrategyIssuer;
				if (strategyIssuer != null)
				{
					strategyIssuer.CloneTag(obj);
				}
			}
		}

		// Token: 0x170002CA RID: 714
		// (get) Token: 0x06001002 RID: 4098 RVA: 0x00009A5E File Offset: 0x00007C5E
		// (set) Token: 0x06001003 RID: 4099 RVA: 0x0006FD68 File Offset: 0x0006DF68
		internal virtual MyCheckBox CheckHiddenFunctionSelect
		{
			[CompilerGenerated]
			get
			{
				return this.m_RulesIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR411-73 == null) ? (PageSetupUI._Closure$__.$IR411-73 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR411-73;
				MyCheckBox rulesIssuer = this.m_RulesIssuer;
				if (rulesIssuer != null)
				{
					rulesIssuer.StopTag(obj);
				}
				this.m_RulesIssuer = value;
				rulesIssuer = this.m_RulesIssuer;
				if (rulesIssuer != null)
				{
					rulesIssuer.CloneTag(obj);
				}
			}
		}

		// Token: 0x170002CB RID: 715
		// (get) Token: 0x06001004 RID: 4100 RVA: 0x00009A66 File Offset: 0x00007C66
		// (set) Token: 0x06001005 RID: 4101 RVA: 0x0006FDC4 File Offset: 0x0006DFC4
		internal virtual MyCheckBox CheckHiddenFunctionHidden
		{
			[CompilerGenerated]
			get
			{
				return this.workerIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupUI._Closure$__.$IR415-74 == null) ? (PageSetupUI._Closure$__.$IR415-74 = delegate(object a0, bool a1)
				{
					PageSetupUI.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupUI._Closure$__.$IR415-74;
				MyCheckBox.ChangeEventHandler obj2 = new MyCheckBox.ChangeEventHandler(this.HiddenHint);
				MyCheckBox myCheckBox = this.workerIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.StopTag(obj);
					myCheckBox.StopTag(obj2);
				}
				this.workerIssuer = value;
				myCheckBox = this.workerIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.CloneTag(obj);
					myCheckBox.CloneTag(obj2);
				}
			}
		}

		// Token: 0x06001006 RID: 4102 RVA: 0x0006FE3C File Offset: 0x0006E03C
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_DicIssuer)
			{
				this.m_DicIssuer = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagesetup/pagesetupui.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06001007 RID: 4103 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06001008 RID: 4104 RVA: 0x0006FE6C File Offset: 0x0006E06C
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			if (connectionId == 3)
			{
				this.CardLauncher = (MyCard)target;
				return;
			}
			if (connectionId == 4)
			{
				this.SliderLauncherOpacity = (MySlider)target;
				return;
			}
			if (connectionId == 5)
			{
				this.LabLauncherHue = (TextBlock)target;
				return;
			}
			if (connectionId == 6)
			{
				this.SliderLauncherHue = (MySlider)target;
				return;
			}
			if (connectionId == 7)
			{
				this.LabLauncherDelta = (TextBlock)target;
				return;
			}
			if (connectionId == 8)
			{
				this.SliderLauncherDelta = (MySlider)target;
				return;
			}
			if (connectionId == 9)
			{
				this.LabLauncherSat = (TextBlock)target;
				return;
			}
			if (connectionId == 10)
			{
				this.SliderLauncherSat = (MySlider)target;
				return;
			}
			if (connectionId == 11)
			{
				this.LabLauncherLight = (TextBlock)target;
				return;
			}
			if (connectionId == 12)
			{
				this.SliderLauncherLight = (MySlider)target;
				return;
			}
			if (connectionId == 13)
			{
				this.PanLauncherTheme = (Grid)target;
				return;
			}
			if (connectionId == 14)
			{
				this.RadioLauncherTheme0 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 15)
			{
				this.RadioLauncherTheme1 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 16)
			{
				this.RadioLauncherTheme2 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 17)
			{
				this.RadioLauncherTheme3 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 18)
			{
				this.RadioLauncherTheme4 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 19)
			{
				this.RadioLauncherTheme5 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 20)
			{
				this.RadioLauncherTheme5Gray = (MyRadioBox)target;
				return;
			}
			if (connectionId == 21)
			{
				this.LabLauncherTheme5Unlock = (TextBlock)target;
				return;
			}
			if (connectionId == 22)
			{
				this.MyRadioBox_0 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 23)
			{
				this.RadioLauncherTheme6 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 24)
			{
				this.RadioLauncherTheme7 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 25)
			{
				this.MyRadioBox_1 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 26)
			{
				this.RadioLauncherTheme8 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 27)
			{
				this.LabLauncherTheme8Copy = (TextBlock)target;
				return;
			}
			if (connectionId == 28)
			{
				this.RadioLauncherTheme9 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 29)
			{
				this.LabLauncherTheme9Copy = (TextBlock)target;
				return;
			}
			if (connectionId == 30)
			{
				this.MyRadioBox_2 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 31)
			{
				this.MyRadioBox_3 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 32)
			{
				this.LabLauncherTheme11Click = (TextBlock)target;
				return;
			}
			if (connectionId == 33)
			{
				this.MyRadioBox_4 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 34)
			{
				this.CheckLauncherLogo = (MyCheckBox)target;
				return;
			}
			if (connectionId == 35)
			{
				this.PanLauncherHide = (Border)target;
				return;
			}
			if (connectionId == 36)
			{
				this.BtnLauncherDonate = (MyButton)target;
				return;
			}
			if (connectionId == 37)
			{
				this.CardBackground = (MyCard)target;
				return;
			}
			if (connectionId == 38)
			{
				this.PanBackgroundSuit = (Grid)target;
				return;
			}
			if (connectionId == 39)
			{
				this.ComboBackgroundSuit = (MyComboBox)target;
				return;
			}
			if (connectionId == 40)
			{
				this.PanBackgroundOpacity = (Grid)target;
				return;
			}
			if (connectionId == 41)
			{
				this.SliderBackgroundOpacity = (MySlider)target;
				return;
			}
			if (connectionId == 42)
			{
				this.PanBackgroundBlur = (Grid)target;
				return;
			}
			if (connectionId == 43)
			{
				this.SliderBackgroundBlur = (MySlider)target;
				return;
			}
			if (connectionId == 44)
			{
				this.CheckBackgroundColorful = (MyCheckBox)target;
				return;
			}
			if (connectionId == 45)
			{
				this.BtnBackgroundOpen = (MyButton)target;
				return;
			}
			if (connectionId == 46)
			{
				this.BtnBackgroundRefresh = (MyButton)target;
				return;
			}
			if (connectionId == 47)
			{
				this.BtnBackgroundClear = (MyButton)target;
				return;
			}
			if (connectionId == 48)
			{
				this.CardMusic = (MyCard)target;
				return;
			}
			if (connectionId == 49)
			{
				this.PanMusicVolume = (Grid)target;
				return;
			}
			if (connectionId == 50)
			{
				this.SliderMusicVolume = (MySlider)target;
				return;
			}
			if (connectionId == 51)
			{
				this.CheckMusicAuto = (MyCheckBox)target;
				return;
			}
			if (connectionId == 52)
			{
				this.CheckMusicStart = (MyCheckBox)target;
				return;
			}
			if (connectionId == 53)
			{
				this.CheckMusicStop = (MyCheckBox)target;
				return;
			}
			if (connectionId == 54)
			{
				this.BtnMusicOpen = (MyButton)target;
				return;
			}
			if (connectionId == 55)
			{
				this.BtnMusicRefresh = (MyButton)target;
				return;
			}
			if (connectionId == 56)
			{
				this.BtnMusicClear = (MyButton)target;
				return;
			}
			if (connectionId == 57)
			{
				this.CardLogo = (MyCard)target;
				return;
			}
			if (connectionId == 58)
			{
				this.RadioLogoType0 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 59)
			{
				this.RadioLogoType1 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 60)
			{
				this.RadioLogoType2 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 61)
			{
				this.RadioLogoType3 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 62)
			{
				this.CheckLogoLeft = (MyCheckBox)target;
				return;
			}
			if (connectionId == 63)
			{
				this.PanLogoText = (Grid)target;
				return;
			}
			if (connectionId == 64)
			{
				this.TextLogoText = (MyTextBox)target;
				return;
			}
			if (connectionId == 65)
			{
				this.PanLogoChange = (Grid)target;
				return;
			}
			if (connectionId == 66)
			{
				this.BtnLogoChange = (MyButton)target;
				return;
			}
			if (connectionId == 67)
			{
				this.BtnLogoDelete = (MyButton)target;
				return;
			}
			if (connectionId == 68)
			{
				this.CardCustom = (MyCard)target;
				return;
			}
			if (connectionId == 69)
			{
				this.RadioCustomType0 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 70)
			{
				this.RadioCustomType1 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 71)
			{
				this.RadioCustomType2 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 72)
			{
				this.PanCustomLocal = (Grid)target;
				return;
			}
			if (connectionId == 73)
			{
				this.BtnCustomRefresh = (MyButton)target;
				return;
			}
			if (connectionId == 74)
			{
				this.BtnCustomFile = (MyButton)target;
				return;
			}
			if (connectionId == 75)
			{
				this.BtnCustomTutorial = (MyButton)target;
				return;
			}
			if (connectionId == 76)
			{
				this.PanCustomNet = (Grid)target;
				return;
			}
			if (connectionId == 77)
			{
				this.TextCustomNet = (MyTextBox)target;
				return;
			}
			if (connectionId == 78)
			{
				this.CardSwitch = (MyCard)target;
				return;
			}
			if (connectionId == 79)
			{
				this.CheckHiddenPageDownload = (MyCheckBox)target;
				return;
			}
			if (connectionId == 80)
			{
				this.CheckHiddenPageLink = (MyCheckBox)target;
				return;
			}
			if (connectionId == 81)
			{
				this.CheckHiddenPageSetup = (MyCheckBox)target;
				return;
			}
			if (connectionId == 82)
			{
				this.CheckHiddenPageOther = (MyCheckBox)target;
				return;
			}
			if (connectionId == 83)
			{
				this.CheckHiddenSetupLaunch = (MyCheckBox)target;
				return;
			}
			if (connectionId == 84)
			{
				this.CheckHiddenSetupUI = (MyCheckBox)target;
				return;
			}
			if (connectionId == 85)
			{
				this.CheckHiddenSetupSystem = (MyCheckBox)target;
				return;
			}
			if (connectionId == 86)
			{
				this.CheckHiddenSetupTool = (MyCheckBox)target;
				return;
			}
			if (connectionId == 87)
			{
				this.CheckHiddenOtherHelp = (MyCheckBox)target;
				return;
			}
			if (connectionId == 88)
			{
				this.CheckHiddenOtherAbout = (MyCheckBox)target;
				return;
			}
			if (connectionId == 89)
			{
				this.CheckHiddenOtherTest = (MyCheckBox)target;
				return;
			}
			if (connectionId == 90)
			{
				this.CheckHiddenOtherFeedback = (MyCheckBox)target;
				return;
			}
			if (connectionId == 91)
			{
				this.CheckLauncherEmail = (MyCheckBox)target;
				return;
			}
			if (connectionId == 92)
			{
				this.CheckHiddenFunctionSelect = (MyCheckBox)target;
				return;
			}
			if (connectionId == 93)
			{
				this.CheckHiddenFunctionHidden = (MyCheckBox)target;
				return;
			}
			this.m_DicIssuer = true;
		}

		// Token: 0x04000775 RID: 1909
		public bool _RequestIssuer;

		// Token: 0x04000776 RID: 1910
		private static bool accountIssuer = false;

		// Token: 0x04000777 RID: 1911
		[CompilerGenerated]
		[AccessedThroughProperty("PanBack")]
		private MyScrollViewer _StateIssuer;

		// Token: 0x04000778 RID: 1912
		[CompilerGenerated]
		[AccessedThroughProperty("PanMain")]
		private StackPanel m_ProccesorIssuer;

		// Token: 0x04000779 RID: 1913
		[CompilerGenerated]
		[AccessedThroughProperty("CardLauncher")]
		private MyCard _ParameterIssuer;

		// Token: 0x0400077A RID: 1914
		[AccessedThroughProperty("SliderLauncherOpacity")]
		[CompilerGenerated]
		private MySlider authenticationIssuer;

		// Token: 0x0400077B RID: 1915
		[CompilerGenerated]
		[AccessedThroughProperty("LabLauncherHue")]
		private TextBlock reponseIssuer;

		// Token: 0x0400077C RID: 1916
		[CompilerGenerated]
		[AccessedThroughProperty("SliderLauncherHue")]
		private MySlider m_ContainerIssuer;

		// Token: 0x0400077D RID: 1917
		[CompilerGenerated]
		[AccessedThroughProperty("LabLauncherDelta")]
		private TextBlock _CodeIssuer;

		// Token: 0x0400077E RID: 1918
		[AccessedThroughProperty("SliderLauncherDelta")]
		[CompilerGenerated]
		private MySlider _TokenizerIssuer;

		// Token: 0x0400077F RID: 1919
		[CompilerGenerated]
		[AccessedThroughProperty("LabLauncherSat")]
		private TextBlock _DefinitionIssuer;

		// Token: 0x04000780 RID: 1920
		[CompilerGenerated]
		[AccessedThroughProperty("SliderLauncherSat")]
		private MySlider paramsIssuer;

		// Token: 0x04000781 RID: 1921
		[AccessedThroughProperty("LabLauncherLight")]
		[CompilerGenerated]
		private TextBlock m_MockIssuer;

		// Token: 0x04000782 RID: 1922
		[AccessedThroughProperty("SliderLauncherLight")]
		[CompilerGenerated]
		private MySlider _AdapterIssuer;

		// Token: 0x04000783 RID: 1923
		[AccessedThroughProperty("PanLauncherTheme")]
		[CompilerGenerated]
		private Grid m_InitializerIssuer;

		// Token: 0x04000784 RID: 1924
		[AccessedThroughProperty("RadioLauncherTheme0")]
		[CompilerGenerated]
		private MyRadioBox _SystemIssuer;

		// Token: 0x04000785 RID: 1925
		[CompilerGenerated]
		[AccessedThroughProperty("RadioLauncherTheme1")]
		private MyRadioBox m_WriterIssuer;

		// Token: 0x04000786 RID: 1926
		[CompilerGenerated]
		[AccessedThroughProperty("RadioLauncherTheme2")]
		private MyRadioBox _BroadcasterIssuer;

		// Token: 0x04000787 RID: 1927
		[AccessedThroughProperty("RadioLauncherTheme3")]
		[CompilerGenerated]
		private MyRadioBox _AttributeIssuer;

		// Token: 0x04000788 RID: 1928
		[CompilerGenerated]
		[AccessedThroughProperty("RadioLauncherTheme4")]
		private MyRadioBox specificationIssuer;

		// Token: 0x04000789 RID: 1929
		[CompilerGenerated]
		[AccessedThroughProperty("RadioLauncherTheme5")]
		private MyRadioBox _PredicateIssuer;

		// Token: 0x0400078A RID: 1930
		[CompilerGenerated]
		[AccessedThroughProperty("RadioLauncherTheme5Gray")]
		private MyRadioBox clientIssuer;

		// Token: 0x0400078B RID: 1931
		[AccessedThroughProperty("LabLauncherTheme5Unlock")]
		[CompilerGenerated]
		private TextBlock infoIssuer;

		// Token: 0x0400078C RID: 1932
		[CompilerGenerated]
		[AccessedThroughProperty("RadioLauncherTheme12")]
		private MyRadioBox _DecoratorIssuer;

		// Token: 0x0400078D RID: 1933
		[CompilerGenerated]
		[AccessedThroughProperty("RadioLauncherTheme6")]
		private MyRadioBox _PropertyIssuer;

		// Token: 0x0400078E RID: 1934
		[CompilerGenerated]
		[AccessedThroughProperty("RadioLauncherTheme7")]
		private MyRadioBox descriptorIssuer;

		// Token: 0x0400078F RID: 1935
		[CompilerGenerated]
		[AccessedThroughProperty("RadioLauncherTheme13")]
		private MyRadioBox m_MapIssuer;

		// Token: 0x04000790 RID: 1936
		[CompilerGenerated]
		[AccessedThroughProperty("RadioLauncherTheme8")]
		private MyRadioBox _EventIssuer;

		// Token: 0x04000791 RID: 1937
		[AccessedThroughProperty("LabLauncherTheme8Copy")]
		[CompilerGenerated]
		private TextBlock _AlgoIssuer;

		// Token: 0x04000792 RID: 1938
		[AccessedThroughProperty("RadioLauncherTheme9")]
		[CompilerGenerated]
		private MyRadioBox m_PoolIssuer;

		// Token: 0x04000793 RID: 1939
		[AccessedThroughProperty("LabLauncherTheme9Copy")]
		[CompilerGenerated]
		private TextBlock _PublisherIssuer;

		// Token: 0x04000794 RID: 1940
		[AccessedThroughProperty("RadioLauncherTheme10")]
		[CompilerGenerated]
		private MyRadioBox m_WatcherIssuer;

		// Token: 0x04000795 RID: 1941
		[AccessedThroughProperty("RadioLauncherTheme11")]
		[CompilerGenerated]
		private MyRadioBox testIssuer;

		// Token: 0x04000796 RID: 1942
		[AccessedThroughProperty("LabLauncherTheme11Click")]
		[CompilerGenerated]
		private TextBlock m_TaskIssuer;

		// Token: 0x04000797 RID: 1943
		[CompilerGenerated]
		[AccessedThroughProperty("RadioLauncherTheme14")]
		private MyRadioBox m_IteratorIssuer;

		// Token: 0x04000798 RID: 1944
		[CompilerGenerated]
		[AccessedThroughProperty("CheckLauncherLogo")]
		private MyCheckBox serializerIssuer;

		// Token: 0x04000799 RID: 1945
		[CompilerGenerated]
		[AccessedThroughProperty("PanLauncherHide")]
		private Border roleIssuer;

		// Token: 0x0400079A RID: 1946
		[AccessedThroughProperty("BtnLauncherDonate")]
		[CompilerGenerated]
		private MyButton valueIssuer;

		// Token: 0x0400079B RID: 1947
		[CompilerGenerated]
		[AccessedThroughProperty("CardBackground")]
		private MyCard _RecordIssuer;

		// Token: 0x0400079C RID: 1948
		[AccessedThroughProperty("PanBackgroundSuit")]
		[CompilerGenerated]
		private Grid visitorIssuer;

		// Token: 0x0400079D RID: 1949
		[AccessedThroughProperty("ComboBackgroundSuit")]
		[CompilerGenerated]
		private MyComboBox helperIssuer;

		// Token: 0x0400079E RID: 1950
		[CompilerGenerated]
		[AccessedThroughProperty("PanBackgroundOpacity")]
		private Grid paramIssuer;

		// Token: 0x0400079F RID: 1951
		[CompilerGenerated]
		[AccessedThroughProperty("SliderBackgroundOpacity")]
		private MySlider m_BaseIssuer;

		// Token: 0x040007A0 RID: 1952
		[AccessedThroughProperty("PanBackgroundBlur")]
		[CompilerGenerated]
		private Grid _ProductIssuer;

		// Token: 0x040007A1 RID: 1953
		[AccessedThroughProperty("SliderBackgroundBlur")]
		[CompilerGenerated]
		private MySlider _AttrIssuer;

		// Token: 0x040007A2 RID: 1954
		[CompilerGenerated]
		[AccessedThroughProperty("CheckBackgroundColorful")]
		private MyCheckBox m_FacadeIssuer;

		// Token: 0x040007A3 RID: 1955
		[AccessedThroughProperty("BtnBackgroundOpen")]
		[CompilerGenerated]
		private MyButton _BridgeIssuer;

		// Token: 0x040007A4 RID: 1956
		[CompilerGenerated]
		[AccessedThroughProperty("BtnBackgroundRefresh")]
		private MyButton _StructIssuer;

		// Token: 0x040007A5 RID: 1957
		[AccessedThroughProperty("BtnBackgroundClear")]
		[CompilerGenerated]
		private MyButton m_IndexerIssuer;

		// Token: 0x040007A6 RID: 1958
		[CompilerGenerated]
		[AccessedThroughProperty("CardMusic")]
		private MyCard _TemplateIssuer;

		// Token: 0x040007A7 RID: 1959
		[CompilerGenerated]
		[AccessedThroughProperty("PanMusicVolume")]
		private Grid _ExpressionIssuer;

		// Token: 0x040007A8 RID: 1960
		[CompilerGenerated]
		[AccessedThroughProperty("SliderMusicVolume")]
		private MySlider _GetterIssuer;

		// Token: 0x040007A9 RID: 1961
		[AccessedThroughProperty("CheckMusicAuto")]
		[CompilerGenerated]
		private MyCheckBox m_ListenerIssuer;

		// Token: 0x040007AA RID: 1962
		[AccessedThroughProperty("CheckMusicStart")]
		[CompilerGenerated]
		private MyCheckBox _IdentifierIssuer;

		// Token: 0x040007AB RID: 1963
		[CompilerGenerated]
		[AccessedThroughProperty("CheckMusicStop")]
		private MyCheckBox m_InstanceIssuer;

		// Token: 0x040007AC RID: 1964
		[CompilerGenerated]
		[AccessedThroughProperty("BtnMusicOpen")]
		private MyButton _CreatorIssuer;

		// Token: 0x040007AD RID: 1965
		[AccessedThroughProperty("BtnMusicRefresh")]
		[CompilerGenerated]
		private MyButton objectIssuer;

		// Token: 0x040007AE RID: 1966
		[CompilerGenerated]
		[AccessedThroughProperty("BtnMusicClear")]
		private MyButton _RegIssuer;

		// Token: 0x040007AF RID: 1967
		[AccessedThroughProperty("CardLogo")]
		[CompilerGenerated]
		private MyCard invocationIssuer;

		// Token: 0x040007B0 RID: 1968
		[CompilerGenerated]
		[AccessedThroughProperty("RadioLogoType0")]
		private MyRadioBox composerIssuer;

		// Token: 0x040007B1 RID: 1969
		[AccessedThroughProperty("RadioLogoType1")]
		[CompilerGenerated]
		private MyRadioBox _ItemIssuer;

		// Token: 0x040007B2 RID: 1970
		[AccessedThroughProperty("RadioLogoType2")]
		[CompilerGenerated]
		private MyRadioBox mapperIssuer;

		// Token: 0x040007B3 RID: 1971
		[AccessedThroughProperty("RadioLogoType3")]
		[CompilerGenerated]
		private MyRadioBox factoryIssuer;

		// Token: 0x040007B4 RID: 1972
		[AccessedThroughProperty("CheckLogoLeft")]
		[CompilerGenerated]
		private MyCheckBox processIssuer;

		// Token: 0x040007B5 RID: 1973
		[CompilerGenerated]
		[AccessedThroughProperty("PanLogoText")]
		private Grid valIssuer;

		// Token: 0x040007B6 RID: 1974
		[AccessedThroughProperty("TextLogoText")]
		[CompilerGenerated]
		private MyTextBox m_UtilsIssuer;

		// Token: 0x040007B7 RID: 1975
		[CompilerGenerated]
		[AccessedThroughProperty("PanLogoChange")]
		private Grid _OrderIssuer;

		// Token: 0x040007B8 RID: 1976
		[CompilerGenerated]
		[AccessedThroughProperty("BtnLogoChange")]
		private MyButton m_PolicyIssuer;

		// Token: 0x040007B9 RID: 1977
		[AccessedThroughProperty("BtnLogoDelete")]
		[CompilerGenerated]
		private MyButton m_ThreadIssuer;

		// Token: 0x040007BA RID: 1978
		[AccessedThroughProperty("CardCustom")]
		[CompilerGenerated]
		private MyCard connectionIssuer;

		// Token: 0x040007BB RID: 1979
		[CompilerGenerated]
		[AccessedThroughProperty("RadioCustomType0")]
		private MyRadioBox _CustomerIssuer;

		// Token: 0x040007BC RID: 1980
		[AccessedThroughProperty("RadioCustomType1")]
		[CompilerGenerated]
		private MyRadioBox m_SchemaIssuer;

		// Token: 0x040007BD RID: 1981
		[AccessedThroughProperty("RadioCustomType2")]
		[CompilerGenerated]
		private MyRadioBox databaseIssuer;

		// Token: 0x040007BE RID: 1982
		[CompilerGenerated]
		[AccessedThroughProperty("PanCustomLocal")]
		private Grid callbackIssuer;

		// Token: 0x040007BF RID: 1983
		[AccessedThroughProperty("BtnCustomRefresh")]
		[CompilerGenerated]
		private MyButton m_AdvisorIssuer;

		// Token: 0x040007C0 RID: 1984
		[CompilerGenerated]
		[AccessedThroughProperty("BtnCustomFile")]
		private MyButton m_ObserverIssuer;

		// Token: 0x040007C1 RID: 1985
		[AccessedThroughProperty("BtnCustomTutorial")]
		[CompilerGenerated]
		private MyButton m_SingletonIssuer;

		// Token: 0x040007C2 RID: 1986
		[AccessedThroughProperty("PanCustomNet")]
		[CompilerGenerated]
		private Grid m_ContextIssuer;

		// Token: 0x040007C3 RID: 1987
		[CompilerGenerated]
		[AccessedThroughProperty("TextCustomNet")]
		private MyTextBox _CollectionIssuer;

		// Token: 0x040007C4 RID: 1988
		[CompilerGenerated]
		[AccessedThroughProperty("CardSwitch")]
		private MyCard consumerIssuer;

		// Token: 0x040007C5 RID: 1989
		[AccessedThroughProperty("CheckHiddenPageDownload")]
		[CompilerGenerated]
		private MyCheckBox filterIssuer;

		// Token: 0x040007C6 RID: 1990
		[CompilerGenerated]
		[AccessedThroughProperty("CheckHiddenPageLink")]
		private MyCheckBox readerIssuer;

		// Token: 0x040007C7 RID: 1991
		[CompilerGenerated]
		[AccessedThroughProperty("CheckHiddenPageSetup")]
		private MyCheckBox fieldIssuer;

		// Token: 0x040007C8 RID: 1992
		[AccessedThroughProperty("CheckHiddenPageOther")]
		[CompilerGenerated]
		private MyCheckBox pageIssuer;

		// Token: 0x040007C9 RID: 1993
		[AccessedThroughProperty("CheckHiddenSetupLaunch")]
		[CompilerGenerated]
		private MyCheckBox m_PrinterIssuer;

		// Token: 0x040007CA RID: 1994
		[CompilerGenerated]
		[AccessedThroughProperty("CheckHiddenSetupUI")]
		private MyCheckBox _TokenIssuer;

		// Token: 0x040007CB RID: 1995
		[CompilerGenerated]
		[AccessedThroughProperty("CheckHiddenSetupSystem")]
		private MyCheckBox interpreterIssuer;

		// Token: 0x040007CC RID: 1996
		[AccessedThroughProperty("CheckHiddenSetupTool")]
		[CompilerGenerated]
		private MyCheckBox m_ParserIssuer;

		// Token: 0x040007CD RID: 1997
		[AccessedThroughProperty("CheckHiddenOtherHelp")]
		[CompilerGenerated]
		private MyCheckBox _StubIssuer;

		// Token: 0x040007CE RID: 1998
		[CompilerGenerated]
		[AccessedThroughProperty("CheckHiddenOtherAbout")]
		private MyCheckBox errorIssuer;

		// Token: 0x040007CF RID: 1999
		[AccessedThroughProperty("CheckHiddenOtherTest")]
		[CompilerGenerated]
		private MyCheckBox exceptionIssuer;

		// Token: 0x040007D0 RID: 2000
		[AccessedThroughProperty("CheckHiddenOtherFeedback")]
		[CompilerGenerated]
		private MyCheckBox testsIssuer;

		// Token: 0x040007D1 RID: 2001
		[CompilerGenerated]
		[AccessedThroughProperty("CheckLauncherEmail")]
		private MyCheckBox _StrategyIssuer;

		// Token: 0x040007D2 RID: 2002
		[AccessedThroughProperty("CheckHiddenFunctionSelect")]
		[CompilerGenerated]
		private MyCheckBox m_RulesIssuer;

		// Token: 0x040007D3 RID: 2003
		[AccessedThroughProperty("CheckHiddenFunctionHidden")]
		[CompilerGenerated]
		private MyCheckBox workerIssuer;

		// Token: 0x040007D4 RID: 2004
		private bool m_DicIssuer;
	}
}
