﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.VisualBasic.CompilerServices;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PCL.My;

namespace PCL
{
	// Token: 0x0200015A RID: 346
	[DesignerGenerated]
	public class PageSetupLaunch : MyPageRight, IComponentConnector
	{
		// Token: 0x06000E1D RID: 3613 RVA: 0x00008F08 File Offset: 0x00007108
		public PageSetupLaunch()
		{
			base.Loaded += this.PageSetupLaunch_Loaded;
			this.templatePrototype = false;
			this.m_ExpressionPrototype = 2;
			this.m_GetterPrototype = 1;
			this.InitializeComponent();
		}

		// Token: 0x06000E1E RID: 3614 RVA: 0x00068B3C File Offset: 0x00066D3C
		private void PageSetupLaunch_Loaded(object sender, RoutedEventArgs e)
		{
			this.PanBack.ScrollToHome();
			this.RefreshRam(false);
			checked
			{
				if (!this.templatePrototype)
				{
					this.templatePrototype = true;
					ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
					this.Reload();
					ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
					DispatcherTimer dispatcherTimer = new DispatcherTimer();
					dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 1);
					dispatcherTimer.Tick += delegate(object sender, EventArgs e)
					{
						this.RefreshRam();
					};
					dispatcherTimer.Start();
				}
			}
		}

		// Token: 0x06000E1F RID: 3615 RVA: 0x00068BB4 File Offset: 0x00066DB4
		public void Reload()
		{
			try
			{
				((MyRadioBox)base.FindName(Conversions.ToString(Operators.ConcatenateObject("RadioSkinType", ModBase._ParamsState.Load("LaunchSkinType", false, null))))).Checked = true;
				this.TextSkinID.Text = Conversions.ToString(ModBase._ParamsState.Get("LaunchSkinID", null));
				this.TextArgumentTitle.Text = Conversions.ToString(ModBase._ParamsState.Get("LaunchArgumentTitle", null));
				this.TextArgumentInfo.Text = Conversions.ToString(ModBase._ParamsState.Get("LaunchArgumentInfo", null));
				this.ComboArgumentIndie.SelectedIndex = Conversions.ToInteger(ModBase._ParamsState.Get("LaunchArgumentIndie", null));
				this.ComboArgumentVisibie.SelectedIndex = Conversions.ToInteger(ModBase._ParamsState.Get("LaunchArgumentVisible", null));
				this.ComboArgumentPriority.SelectedIndex = Conversions.ToInteger(ModBase._ParamsState.Get("LaunchArgumentPriority", null));
				this.ComboArgumentWindowType.SelectedIndex = Conversions.ToInteger(ModBase._ParamsState.Get("LaunchArgumentWindowType", null));
				this.TextArgumentWindowWidth.Text = Conversions.ToString(ModBase._ParamsState.Get("LaunchArgumentWindowWidth", null));
				this.TextArgumentWindowHeight.Text = Conversions.ToString(ModBase._ParamsState.Get("LaunchArgumentWindowHeight", null));
				this.RefreshJavaComboBox();
				((MyRadioBox)base.FindName(Conversions.ToString(Operators.ConcatenateObject("RadioRamType", ModBase._ParamsState.Load("LaunchRamType", false, null))))).Checked = true;
				this.SliderRamCustom.Value = Conversions.ToInteger(ModBase._ParamsState.Get("LaunchRamCustom", null));
				this.TextAdvanceJvm.Text = Conversions.ToString(ModBase._ParamsState.Get("LaunchAdvanceJvm", null));
				this.TextAdvanceGame.Text = Conversions.ToString(ModBase._ParamsState.Get("LaunchAdvanceGame", null));
				this.CheckAdvanceAssets.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("LaunchAdvanceAssets", null));
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "重载启动设置时出错", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000E20 RID: 3616 RVA: 0x00068E08 File Offset: 0x00067008
		public void Reset()
		{
			try
			{
				ModBase._ParamsState.Reset("LaunchArgumentTitle", false, null);
				ModBase._ParamsState.Reset("LaunchArgumentInfo", false, null);
				ModBase._ParamsState.Reset("LaunchArgumentIndie", false, null);
				ModBase._ParamsState.Reset("LaunchArgumentVisible", false, null);
				ModBase._ParamsState.Reset("LaunchArgumentWindowType", false, null);
				ModBase._ParamsState.Reset("LaunchArgumentWindowWidth", false, null);
				ModBase._ParamsState.Reset("LaunchArgumentWindowHeight", false, null);
				ModBase._ParamsState.Reset("LaunchArgumentPriority", false, null);
				ModBase._ParamsState.Reset("LaunchRamType", false, null);
				ModBase._ParamsState.Reset("LaunchRamCustom", false, null);
				ModBase._ParamsState.Reset("LaunchSkinType", false, null);
				ModBase._ParamsState.Reset("LaunchSkinID", false, null);
				ModBase._ParamsState.Reset("LaunchAdvanceJvm", false, null);
				ModBase._ParamsState.Reset("LaunchAdvanceGame", false, null);
				ModBase._ParamsState.Reset("LaunchAdvanceAssets", false, null);
				ModBase._ParamsState.Reset("LaunchArgumentJavaAll", false, null);
				ModBase._ParamsState.Reset("LaunchArgumentJavaSelect", false, null);
				ModMinecraft.composerTag.Start(null, true);
				ModBase.Log("[Setup] 已初始化启动设置", ModBase.LogLevel.Normal, "出现错误");
				ModMain.Hint("已初始化启动设置！", ModMain.HintType.Finish, false);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "初始化启动设置失败", ModBase.LogLevel.Msgbox, "出现错误");
			}
			this.Reload();
		}

		// Token: 0x06000E21 RID: 3617 RVA: 0x00068FA4 File Offset: 0x000671A4
		private static void RadioBoxChange(MyRadioBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(sender.Tag.ToString().Split(new char[]
				{
					'/'
				})[0], ModBase.Val(sender.Tag.ToString().Split(new char[]
				{
					'/'
				})[1]), false, null);
			}
		}

		// Token: 0x06000E22 RID: 3618 RVA: 0x00008F3E File Offset: 0x0000713E
		private static void TextBoxChange(MyTextBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.Text, false, null);
			}
		}

		// Token: 0x06000E23 RID: 3619 RVA: 0x00008F64 File Offset: 0x00007164
		private static void SliderChange(MySlider sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.Value, false, null);
			}
		}

		// Token: 0x06000E24 RID: 3620 RVA: 0x00008F8F File Offset: 0x0000718F
		private static void ComboChange(MyComboBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.SelectedIndex, false, null);
			}
		}

		// Token: 0x06000E25 RID: 3621 RVA: 0x00008FBA File Offset: 0x000071BA
		private static void CheckBoxChange(MyCheckBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.Checked, false, null);
			}
		}

		// Token: 0x06000E26 RID: 3622 RVA: 0x00069008 File Offset: 0x00067208
		private void BtnSkinChange_Click(object sender, EventArgs e)
		{
			ModMinecraft.McSkinInfo mcSkinInfo = ModMinecraft.McSkinSelect(true);
			if (mcSkinInfo._CodeParameter)
			{
				try
				{
					File.Delete(ModBase.attributeState + "CustomSkin.png");
					File.Copy(mcSkinInfo.m_ContainerParameter, ModBase.attributeState + "CustomSkin.png");
					ModBase._ParamsState.Set("LaunchSkinSlim", mcSkinInfo.m_ReponseParameter, false, null);
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "设置离线皮肤失败", ModBase.LogLevel.Msgbox, "出现错误");
				}
				finally
				{
					PageLaunchLeft._StructComparator.Start(null, true);
				}
			}
		}

		// Token: 0x06000E27 RID: 3623 RVA: 0x000690BC File Offset: 0x000672BC
		private void RadioSkinType3_Check(object sender, ModBase.RouteEventArgs e)
		{
			if (ModAnimation.DefineModel() == 0 && e.m_ImporterParameter)
			{
				try
				{
					if (!File.Exists(ModBase.attributeState + "CustomSkin.png"))
					{
						ModMinecraft.McSkinInfo mcSkinInfo = ModMinecraft.McSkinSelect(true);
						if (!mcSkinInfo._CodeParameter)
						{
							e.proxyParameter = true;
						}
						else
						{
							File.Delete(ModBase.attributeState + "CustomSkin.png");
							File.Copy(mcSkinInfo.m_ContainerParameter, ModBase.attributeState + "CustomSkin.png");
							ModBase._ParamsState.Set("LaunchSkinSlim", mcSkinInfo.m_ReponseParameter, false, null);
						}
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "设置离线皮肤失败", ModBase.LogLevel.Msgbox, "出现错误");
					e.proxyParameter = true;
				}
				finally
				{
					PageLaunchLeft._StructComparator.Start(null, true);
				}
			}
		}

		// Token: 0x06000E28 RID: 3624 RVA: 0x000691B0 File Offset: 0x000673B0
		private void BtnSkinDelete_Click(object sender, EventArgs e)
		{
			try
			{
				File.Delete(ModBase.attributeState + "CustomSkin.png");
				this.RadioSkinType0.SetChecked(true, true, true);
				ModMain.Hint("离线皮肤已清空！", ModMain.HintType.Finish, true);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "清空离线皮肤失败", ModBase.LogLevel.Msgbox, "出现错误");
			}
		}

		// Token: 0x06000E29 RID: 3625 RVA: 0x00008FE5 File Offset: 0x000071E5
		private void BtnSkinSave_Click(object sender, EventArgs e)
		{
			MySkin.Save(PageLaunchLeft._StructComparator);
		}

		// Token: 0x06000E2A RID: 3626 RVA: 0x00008FF1 File Offset: 0x000071F1
		private void BtnSkinCache_Click(object sender, EventArgs e)
		{
			MySkin.RefreshCache(null);
		}

		// Token: 0x06000E2B RID: 3627 RVA: 0x00008FF9 File Offset: 0x000071F9
		public void RamType(int Type)
		{
			if (this.SliderRamCustom != null)
			{
				this.SliderRamCustom.IsEnabled = (Type == 1);
			}
		}

		// Token: 0x06000E2C RID: 3628 RVA: 0x0006921C File Offset: 0x0006741C
		public void RefreshRam(bool ShowAnim)
		{
			if (this.LabRamGame != null && this.LabRamUsed != null && !(ModMain.m_CollectionAccount.comparatorAccount != FormMain.PageType.Setup) && ModMain._RuleAccount._ParamPrototype == FormMain.PageSubType.Default)
			{
				double ram = PageSetupLaunch.GetRam(ModMinecraft.SetupResolver(), false);
				double num = Math.Round(MyWpfExtension.FindModel().Info.TotalPhysicalMemory / 1024.0 / 1024.0 / 1024.0 * 10.0) / 10.0;
				double num2 = Math.Round(MyWpfExtension.FindModel().Info.AvailablePhysicalMemory / 1024.0 / 1024.0 / 1024.0 * 10.0) / 10.0;
				double num3 = Math.Min(ram, num2);
				double num4 = num - num2;
				double num5 = Math.Round(ModBase.MathRange(num - num4 - ram, 0.0, 1000.0) * 10.0) / 10.0;
				checked
				{
					if (num <= 1.5)
					{
						this.SliderRamCustom.MaxValue = (int)Math.Round(Math.Max(Math.Floor(unchecked(num - 0.3) / 0.1), 1.0));
					}
					else if (num <= 8.0)
					{
						this.SliderRamCustom.MaxValue = (int)Math.Round(unchecked(Math.Floor((num - 1.5) / 0.5) + 12.0));
					}
					else if (num <= 16.0)
					{
						this.SliderRamCustom.MaxValue = (int)Math.Round(unchecked(Math.Floor((num - 8.0) / 1.0) + 25.0));
					}
					else if (num <= 32.0)
					{
						this.SliderRamCustom.MaxValue = (int)Math.Round(unchecked(Math.Floor((num - 16.0) / 2.0) + 33.0));
					}
					else
					{
						this.SliderRamCustom.MaxValue = (int)Math.Round(Math.Min(unchecked(Math.Floor((num - 32.0) / 4.0) + 41.0), 49.0));
					}
					this.LabRamGame.Text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject((ram == Math.Floor(ram)) ? (Conversions.ToString(ram) + ".0") : ram, " GB"), (ram != num3) ? Operators.ConcatenateObject(Operators.ConcatenateObject(" (可用 ", (num3 == Math.Floor(num3)) ? (Conversions.ToString(num3) + ".0") : num3), " GB)") : ""));
					this.LabRamUsed.Text = Conversions.ToString(Operators.ConcatenateObject((num4 == Math.Floor(num4)) ? (Conversions.ToString(num4) + ".0") : num4, " GB"));
					this.LabRamTotal.Text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(" / ", (num == Math.Floor(num)) ? (Conversions.ToString(num) + ".0") : num), " GB"));
					this.LabRamWarn.Visibility = ((ram != 1.0 || ModMinecraft.JavaUse64Bit(null) || ModBase.m_WriterState) ? Visibility.Collapsed : Visibility.Visible);
				}
				if (ShowAnim)
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaGridLengthWidth(this.ColumnRamUsed, num4 - this.ColumnRamUsed.Width.Value, 800, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false),
						ModAnimation.AaGridLengthWidth(this.ColumnRamGame, num3 - this.ColumnRamGame.Width.Value, 800, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false),
						ModAnimation.AaGridLengthWidth(this.ColumnRamEmpty, num5 - this.ColumnRamEmpty.Width.Value, 800, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false)
					}, "SetupLaunch Ram Grid", false);
					return;
				}
				this.ColumnRamUsed.Width = new GridLength(num4, GridUnitType.Star);
				this.ColumnRamGame.Width = new GridLength(num3, GridUnitType.Star);
				this.ColumnRamEmpty.Width = new GridLength(num5, GridUnitType.Star);
			}
		}

		// Token: 0x06000E2D RID: 3629 RVA: 0x00009012 File Offset: 0x00007212
		private void RefreshRam()
		{
			this.RefreshRam(true);
		}

		// Token: 0x06000E2E RID: 3630 RVA: 0x000696C8 File Offset: 0x000678C8
		private void RefreshRamText()
		{
			double actualWidth = this.RectRamUsed.ActualWidth;
			double actualWidth2 = this.PanRamDisplay.ActualWidth;
			double actualWidth3 = this.LabRamGame.ActualWidth;
			double actualWidth4 = this.LabRamUsed.ActualWidth;
			double actualWidth5 = this.LabRamTotal.ActualWidth;
			double actualWidth6 = this.LabRamGameTitle.ActualWidth;
			double actualWidth7 = this.LabRamUsedTitle.ActualWidth;
			int num;
			if (actualWidth - 30.0 >= actualWidth4 && actualWidth - 30.0 >= actualWidth7)
			{
				if (actualWidth - 25.0 < actualWidth4 + actualWidth5)
				{
					num = 1;
				}
				else
				{
					num = 2;
				}
			}
			else
			{
				num = 0;
			}
			if (this.m_ExpressionPrototype != num)
			{
				this.m_ExpressionPrototype = num;
				switch (num)
				{
				case 0:
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaOpacity(this.LabRamUsed, -this.LabRamUsed.Opacity, 100, 0, null, false),
						ModAnimation.AaOpacity(this.LabRamTotal, -this.LabRamTotal.Opacity, 100, 0, null, false),
						ModAnimation.AaOpacity(this.LabRamUsedTitle, -this.LabRamUsedTitle.Opacity, 100, 0, null, false)
					}, "SetupLaunch Ram TextLeft", false);
					break;
				case 1:
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaOpacity(this.LabRamUsed, 1.0 - this.LabRamUsed.Opacity, 100, 0, null, false),
						ModAnimation.AaOpacity(this.LabRamTotal, -this.LabRamTotal.Opacity, 100, 0, null, false),
						ModAnimation.AaOpacity(this.LabRamUsedTitle, 0.7 - this.LabRamUsedTitle.Opacity, 100, 0, null, false)
					}, "SetupLaunch Ram TextLeft", false);
					break;
				case 2:
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaOpacity(this.LabRamUsed, 1.0 - this.LabRamUsed.Opacity, 100, 0, null, false),
						ModAnimation.AaOpacity(this.LabRamTotal, 1.0 - this.LabRamTotal.Opacity, 100, 0, null, false),
						ModAnimation.AaOpacity(this.LabRamUsedTitle, 0.7 - this.LabRamUsedTitle.Opacity, 100, 0, null, false)
					}, "SetupLaunch Ram TextLeft", false);
					break;
				}
			}
			int num2;
			if (actualWidth2 >= actualWidth3 + 2.0 + actualWidth && actualWidth2 >= actualWidth6 + 2.0 + actualWidth)
			{
				num2 = 1;
			}
			else
			{
				num2 = 0;
			}
			if (num2 == 0)
			{
				if (ModAnimation.DefineModel() == 0 && (this.m_GetterPrototype != num2 || ModAnimation.AniIsRun("SetupLaunch Ram TextRight")))
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaX(this.LabRamGame, actualWidth2 - actualWidth3 - this.LabRamGame.Margin.Left, 100, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Weak), false),
						ModAnimation.AaX(this.LabRamGameTitle, actualWidth2 - actualWidth6 - this.LabRamGameTitle.Margin.Left, 100, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Weak), false)
					}, "SetupLaunch Ram TextRight", false);
				}
				else
				{
					this.LabRamGame.Margin = new Thickness(actualWidth2 - actualWidth3, 3.0, 0.0, 0.0);
					this.LabRamGameTitle.Margin = new Thickness(actualWidth2 - actualWidth6, 0.0, 0.0, 5.0);
				}
			}
			else if (ModAnimation.DefineModel() == 0 && (this.m_GetterPrototype != num2 || ModAnimation.AniIsRun("SetupLaunch Ram TextRight")))
			{
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaX(this.LabRamGame, 2.0 + actualWidth - this.LabRamGame.Margin.Left, 100, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Weak), false),
					ModAnimation.AaX(this.LabRamGameTitle, 2.0 + actualWidth - this.LabRamGameTitle.Margin.Left, 100, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Weak), false)
				}, "SetupLaunch Ram TextRight", false);
			}
			else
			{
				this.LabRamGame.Margin = new Thickness(2.0 + actualWidth, 3.0, 0.0, 0.0);
				this.LabRamGameTitle.Margin = new Thickness(2.0 + actualWidth, 0.0, 0.0, 5.0);
			}
			this.m_GetterPrototype = num2;
		}

		// Token: 0x06000E2F RID: 3631 RVA: 0x00069B90 File Offset: 0x00067D90
		public static double GetRam(ModMinecraft.McVersion Version, bool UseVersionJavaSetup)
		{
			double num7;
			if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LaunchRamType", null), 0, true))
			{
				double num = Math.Round(MyWpfExtension.FindModel().Info.AvailablePhysicalMemory / 1024.0 / 1024.0 / 1024.0 * 10.0) / 10.0;
				if (Version != null && !Version._WrapperParameter)
				{
					Version.Load();
				}
				double val;
				double num3;
				double num4;
				double num5;
				if (Version != null && Version.Version.CalculatePrototype())
				{
					DirectoryInfo directoryInfo = new DirectoryInfo(Version.CreateComparator() + "mods\\");
					int num2 = directoryInfo.Exists ? directoryInfo.GetFiles().Length : 0;
					val = 0.4 + (double)num2 / 150.0;
					num3 = 1.5 + (double)num2 / 100.0;
					num4 = 3.0 + (double)num2 / 60.0;
					num5 = 6.0 + (double)num2 / 30.0;
				}
				else if (Version != null && Version.Version.m_PrototypeParameter)
				{
					val = 0.3;
					num3 = 1.5;
					num4 = 3.0;
					num5 = 6.0;
				}
				else
				{
					val = 0.3;
					num3 = 1.5;
					num4 = 2.5;
					num5 = 4.0;
				}
				double num6 = num3;
				num = Math.Max(0.0, num - 0.1);
				num7 += Math.Min(num * 1.0, num6);
				num -= num6 / 1.0 + 0.1;
				if (num >= 0.1)
				{
					num6 = num4 - num3;
					num = Math.Max(0.0, num - 0.1);
					num7 += Math.Min(num * 0.8, num6);
					num -= num6 / 0.8 + 0.1;
					if (num >= 0.1)
					{
						num6 = num5 - num4;
						num = Math.Max(0.0, num - 0.2);
						num7 += Math.Min(num * 0.6, num6);
						num -= num6 / 0.6 + 0.2;
						if (num >= 0.1)
						{
							num6 = num5;
							num = Math.Max(0.0, num - 0.3);
							num7 += Math.Min(num * 0.4, num6);
							num -= num6 / 0.4 + 0.3;
						}
					}
				}
				num7 = Math.Round(Math.Max(num7, val), 1);
			}
			else
			{
				int num8 = Conversions.ToInteger(ModBase._ParamsState.Get("LaunchRamCustom", null));
				if (num8 <= 12)
				{
					num7 = (double)num8 * 0.1 + 0.3;
				}
				else if (num8 <= 25)
				{
					num7 = (double)(checked(num8 - 12)) * 0.5 + 1.5;
				}
				else if (num8 <= 33)
				{
					num7 = (double)(checked((num8 - 25) * 1 + 8));
				}
				else if (num8 <= 41)
				{
					num7 = (double)(checked((num8 - 33) * 2 + 16));
				}
				else
				{
					num7 = (double)(checked((num8 - 41) * 4 + 32));
				}
			}
			if (!ModMinecraft.JavaUse64Bit(UseVersionJavaSetup ? Version : null))
			{
				num7 = Math.Min(1.0, num7);
			}
			return num7;
		}

		// Token: 0x06000E30 RID: 3632 RVA: 0x00069F44 File Offset: 0x00068144
		public void RefreshJavaComboBox()
		{
			if (this.ComboArgumentJava != null)
			{
				this.ComboArgumentJava.Items.Clear();
				this.ComboArgumentJava.Items.Add(new MyComboBoxItem
				{
					Content = "自动选择适合所选游戏版本的 Java",
					Tag = "自动选择"
				});
				MyComboBoxItem myComboBoxItem = null;
				string text = Conversions.ToString(ModBase._ParamsState.Get("LaunchArgumentJavaSelect", null));
				try
				{
					try
					{
						foreach (ModMinecraft.JavaEntry javaEntry in ModMinecraft._RegTag)
						{
							MyComboBoxItem myComboBoxItem2 = new MyComboBoxItem
							{
								Content = javaEntry.ToString(),
								ToolTip = javaEntry.m_ListProccesor,
								Tag = javaEntry
							};
							ToolTipService.SetPlacement(myComboBoxItem2, PlacementMode.Right);
							ToolTipService.SetHorizontalOffset(myComboBoxItem2, 5.0);
							this.ComboArgumentJava.Items.Add(myComboBoxItem2);
							if (Operators.CompareString(text, "", true) != 0 && Operators.CompareString(ModMinecraft.JavaEntry.FromJson((JObject)ModBase.GetJson(text)).m_ListProccesor, javaEntry.m_ListProccesor, true) == 0)
							{
								myComboBoxItem = myComboBoxItem2;
							}
						}
					}
					finally
					{
						List<ModMinecraft.JavaEntry>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
				}
				catch (Exception ex)
				{
					ModBase._ParamsState.Set("LaunchArgumentJavaSelect", "", false, null);
					ModBase.Log(ex, "更新设置 Java 下拉框失败", ModBase.LogLevel.Feedback, "出现错误");
				}
				if (myComboBoxItem == null && ModMinecraft._RegTag.Count > 0)
				{
					myComboBoxItem = (MyComboBoxItem)this.ComboArgumentJava.Items[0];
				}
				this.ComboArgumentJava.SelectedItem = myComboBoxItem;
				if (myComboBoxItem == null)
				{
					this.ComboArgumentJava.Items.Clear();
					this.ComboArgumentJava.Items.Add(new ComboBoxItem
					{
						Content = "未找到可用的 Java",
						IsSelected = true
					});
				}
				this.RefreshRam(true);
			}
		}

		// Token: 0x06000E31 RID: 3633 RVA: 0x0006A134 File Offset: 0x00068334
		private void ComboArgumentJava_DropDownOpened(object sender, EventArgs e)
		{
			if (this.ComboArgumentJava.SelectedItem == null || Operators.ConditionalCompareObjectEqual(NewLateBinding.LateGet(this.ComboArgumentJava.Items[0], null, "Content", new object[0], null, null, null), "未找到可用的 Java", true) || Operators.ConditionalCompareObjectEqual(NewLateBinding.LateGet(this.ComboArgumentJava.Items[0], null, "Content", new object[0], null, null, null), "加载中……", true))
			{
				this.ComboArgumentJava.IsDropDownOpen = false;
			}
		}

		// Token: 0x06000E32 RID: 3634 RVA: 0x0006A1C0 File Offset: 0x000683C0
		private void JavaSelectionUpdate()
		{
			if (ModAnimation.DefineModel() == 0 && this.ComboArgumentJava.SelectedItem != null && NewLateBinding.LateGet(this.ComboArgumentJava.SelectedItem, null, "Tag", new object[0], null, null, null) != null)
			{
				object objectValue = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(this.ComboArgumentJava.SelectedItem, null, "Tag", new object[0], null, null, null));
				if ("自动选择".Equals(RuntimeHelpers.GetObjectValue(objectValue)))
				{
					ModBase._ParamsState.Set("LaunchArgumentJavaSelect", "", false, null);
					ModBase.Log("[Java] 修改 Java 选择设置：自动选择", ModBase.LogLevel.Normal, "出现错误");
				}
				else
				{
					ModBase._ParamsState.Set("LaunchArgumentJavaSelect", ((JObject)NewLateBinding.LateGet(objectValue, null, "ToJson", new object[0], null, null, null)).ToString(0, new JsonConverter[0]), false, null);
					ModBase.Log("[Java] 修改 Java 选择设置：" + objectValue.ToString(), ModBase.LogLevel.Normal, "出现错误");
				}
				this.RefreshRam(true);
			}
		}

		// Token: 0x06000E33 RID: 3635 RVA: 0x0006A2C4 File Offset: 0x000684C4
		private void BtnArgumentJavaSelect_Click(object sender, EventArgs e)
		{
			if (ModMinecraft.composerTag.State == ModBase.LoadState.Loading)
			{
				ModMain.Hint("正在搜索 Java，请稍候！", ModMain.HintType.Critical, true);
				return;
			}
			string text = ModBase.SelectFile("javaw.exe|javaw.exe", "选择 javaw.exe 文件");
			if (Operators.CompareString(text, "", true) != 0)
			{
				if (!text.ToLower().EndsWith("javaw.exe"))
				{
					ModMain.Hint("请选择 bin 文件夹中的 javaw.exe 文件！", ModMain.HintType.Critical, true);
					return;
				}
				text = ModBase.GetPathFromFullPath(text);
				try
				{
					ModMinecraft.JavaEntry javaEntry = new ModMinecraft.JavaEntry(text, true);
					javaEntry.Check();
					JArray jarray = new JArray();
					jarray.Add(javaEntry.ToJson());
					JArray jarray2 = jarray;
					try
					{
						foreach (object obj in ((IEnumerable)ModBase.GetJson(Conversions.ToString(ModBase._ParamsState.Get("LaunchArgumentJavaAll", null)))))
						{
							object objectValue = RuntimeHelpers.GetObjectValue(obj);
							if (Operators.CompareString(ModMinecraft.JavaEntry.FromJson((JObject)objectValue).m_ListProccesor, javaEntry.m_ListProccesor, true) != 0)
							{
								jarray2.Add(RuntimeHelpers.GetObjectValue(objectValue));
							}
						}
					}
					finally
					{
						IEnumerator enumerator;
						if (enumerator is IDisposable)
						{
							(enumerator as IDisposable).Dispose();
						}
					}
					ModBase._ParamsState.Set("LaunchArgumentJavaAll", jarray2.ToString(0, new JsonConverter[0]), false, null);
					ModBase._ParamsState.Set("LaunchArgumentJavaSelect", javaEntry.ToJson().ToString(0, new JsonConverter[0]), false, null);
					ModMinecraft.composerTag.Start(null, true);
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "该 Java 存在异常，无法使用", ModBase.LogLevel.Msgbox, "异常的 Java");
				}
			}
		}

		// Token: 0x06000E34 RID: 3636 RVA: 0x0006A45C File Offset: 0x0006865C
		private void BtnArgumentJavaSearch_Click(object sender, EventArgs e)
		{
			if (ModMinecraft.composerTag.State == ModBase.LoadState.Loading)
			{
				ModMain.Hint("正在搜索 Java，请稍候！", ModMain.HintType.Critical, true);
				return;
			}
			ModBase.RunInThread((PageSetupLaunch._Closure$__.$I26-0 == null) ? (PageSetupLaunch._Closure$__.$I26-0 = delegate()
			{
				ModMain.Hint("正在搜索 Java！", ModMain.HintType.Info, true);
				ModMinecraft.composerTag.WaitForExit(ModBase.GetUuid(), null, false);
				if (ModMinecraft._RegTag.Count == 0)
				{
					ModMain.Hint("未找到可用的 Java！", ModMain.HintType.Critical, true);
					return;
				}
				ModMain.Hint("已找到 " + Conversions.ToString(ModMinecraft._RegTag.Count) + " 个 Java，请检查下拉框查看列表！", ModMain.HintType.Finish, true);
			}) : PageSetupLaunch._Closure$__.$I26-0);
		}

		// Token: 0x06000E35 RID: 3637 RVA: 0x0006A4AC File Offset: 0x000686AC
		private void method_0()
		{
			if (this.ComboArgumentWindowType != null)
			{
				if (this.ComboArgumentWindowType.SelectedIndex == 3 && this.LabArgumentWindowMiddle != null && this.LabArgumentWindowMiddle.Visibility == Visibility.Collapsed)
				{
					this.LabArgumentWindowMiddle.Visibility = Visibility.Visible;
					this.TextArgumentWindowHeight.Visibility = Visibility.Visible;
					this.TextArgumentWindowWidth.Visibility = Visibility.Visible;
					return;
				}
				if (this.ComboArgumentWindowType.SelectedIndex != 3 && this.LabArgumentWindowMiddle != null && this.LabArgumentWindowMiddle.Visibility == Visibility.Visible)
				{
					this.LabArgumentWindowMiddle.Visibility = Visibility.Collapsed;
					this.TextArgumentWindowHeight.Visibility = Visibility.Collapsed;
					this.TextArgumentWindowWidth.Visibility = Visibility.Collapsed;
				}
			}
		}

		// Token: 0x06000E36 RID: 3638 RVA: 0x0006A554 File Offset: 0x00068754
		private void ComboArgumentVisibie_SizeChanged(object sender, SelectionChangedEventArgs e)
		{
			if (ModAnimation.DefineModel() == 0 && this.ComboArgumentVisibie.SelectedIndex == 0 && ModMain.MyMsgBox("若在游戏启动后立即关闭启动器，崩溃检测、更改游戏标题等功能将失效。\r\n如果想保留这些功能，可以选择让启动器在游戏启动后隐藏，游戏退出后自动关闭。", "提示", "继续", "取消", "", false, true, false) == 2)
			{
				this.ComboArgumentVisibie.SelectedItem = RuntimeHelpers.GetObjectValue(e.RemovedItems[0]);
			}
		}

		// Token: 0x17000227 RID: 551
		// (get) Token: 0x06000E37 RID: 3639 RVA: 0x0000901B File Offset: 0x0000721B
		// (set) Token: 0x06000E38 RID: 3640 RVA: 0x00009023 File Offset: 0x00007223
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x17000228 RID: 552
		// (get) Token: 0x06000E39 RID: 3641 RVA: 0x0000902C File Offset: 0x0000722C
		// (set) Token: 0x06000E3A RID: 3642 RVA: 0x00009034 File Offset: 0x00007234
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x17000229 RID: 553
		// (get) Token: 0x06000E3B RID: 3643 RVA: 0x0000903D File Offset: 0x0000723D
		// (set) Token: 0x06000E3C RID: 3644 RVA: 0x00009045 File Offset: 0x00007245
		internal virtual MyCard CardSkin { get; set; }

		// Token: 0x1700022A RID: 554
		// (get) Token: 0x06000E3D RID: 3645 RVA: 0x0000904E File Offset: 0x0000724E
		// (set) Token: 0x06000E3E RID: 3646 RVA: 0x0006A5B8 File Offset: 0x000687B8
		internal virtual MyRadioBox RadioSkinType0
		{
			[CompilerGenerated]
			get
			{
				return this._CreatorPrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupLaunch._Closure$__.$IR43-2 == null) ? (PageSetupLaunch._Closure$__.$IR43-2 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupLaunch.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR43-2;
				MyRadioBox creatorPrototype = this._CreatorPrototype;
				if (creatorPrototype != null)
				{
					creatorPrototype.Check -= value2;
				}
				this._CreatorPrototype = value;
				creatorPrototype = this._CreatorPrototype;
				if (creatorPrototype != null)
				{
					creatorPrototype.Check += value2;
				}
			}
		}

		// Token: 0x1700022B RID: 555
		// (get) Token: 0x06000E3F RID: 3647 RVA: 0x00009056 File Offset: 0x00007256
		// (set) Token: 0x06000E40 RID: 3648 RVA: 0x0006A614 File Offset: 0x00068814
		internal virtual MyRadioBox RadioSkinType1
		{
			[CompilerGenerated]
			get
			{
				return this.m_ObjectPrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupLaunch._Closure$__.$IR47-3 == null) ? (PageSetupLaunch._Closure$__.$IR47-3 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupLaunch.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR47-3;
				MyRadioBox objectPrototype = this.m_ObjectPrototype;
				if (objectPrototype != null)
				{
					objectPrototype.Check -= value2;
				}
				this.m_ObjectPrototype = value;
				objectPrototype = this.m_ObjectPrototype;
				if (objectPrototype != null)
				{
					objectPrototype.Check += value2;
				}
			}
		}

		// Token: 0x1700022C RID: 556
		// (get) Token: 0x06000E41 RID: 3649 RVA: 0x0000905E File Offset: 0x0000725E
		// (set) Token: 0x06000E42 RID: 3650 RVA: 0x0006A670 File Offset: 0x00068870
		internal virtual MyRadioBox RadioSkinType2
		{
			[CompilerGenerated]
			get
			{
				return this._RegPrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupLaunch._Closure$__.$IR51-4 == null) ? (PageSetupLaunch._Closure$__.$IR51-4 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupLaunch.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR51-4;
				MyRadioBox regPrototype = this._RegPrototype;
				if (regPrototype != null)
				{
					regPrototype.Check -= value2;
				}
				this._RegPrototype = value;
				regPrototype = this._RegPrototype;
				if (regPrototype != null)
				{
					regPrototype.Check += value2;
				}
			}
		}

		// Token: 0x1700022D RID: 557
		// (get) Token: 0x06000E43 RID: 3651 RVA: 0x00009066 File Offset: 0x00007266
		// (set) Token: 0x06000E44 RID: 3652 RVA: 0x0006A6CC File Offset: 0x000688CC
		internal virtual MyRadioBox RadioSkinType3
		{
			[CompilerGenerated]
			get
			{
				return this.m_InvocationPrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupLaunch._Closure$__.$IR55-5 == null) ? (PageSetupLaunch._Closure$__.$IR55-5 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupLaunch.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR55-5;
				MyRadioBox invocationPrototype = this.m_InvocationPrototype;
				if (invocationPrototype != null)
				{
					invocationPrototype.Check -= value2;
				}
				this.m_InvocationPrototype = value;
				invocationPrototype = this.m_InvocationPrototype;
				if (invocationPrototype != null)
				{
					invocationPrototype.Check += value2;
				}
			}
		}

		// Token: 0x1700022E RID: 558
		// (get) Token: 0x06000E45 RID: 3653 RVA: 0x0000906E File Offset: 0x0000726E
		// (set) Token: 0x06000E46 RID: 3654 RVA: 0x0006A728 File Offset: 0x00068928
		internal virtual MyRadioBox RadioSkinType4
		{
			[CompilerGenerated]
			get
			{
				return this.m_ComposerPrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupLaunch._Closure$__.$IR59-6 == null) ? (PageSetupLaunch._Closure$__.$IR59-6 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupLaunch.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR59-6;
				MyRadioBox.PreviewCheckEventHandler obj = new MyRadioBox.PreviewCheckEventHandler(this.RadioSkinType3_Check);
				MyRadioBox composerPrototype = this.m_ComposerPrototype;
				if (composerPrototype != null)
				{
					composerPrototype.Check -= value2;
					composerPrototype.NewTag(obj);
				}
				this.m_ComposerPrototype = value;
				composerPrototype = this.m_ComposerPrototype;
				if (composerPrototype != null)
				{
					composerPrototype.Check += value2;
					composerPrototype.ConnectTag(obj);
				}
			}
		}

		// Token: 0x1700022F RID: 559
		// (get) Token: 0x06000E47 RID: 3655 RVA: 0x00009076 File Offset: 0x00007276
		// (set) Token: 0x06000E48 RID: 3656 RVA: 0x0000907E File Offset: 0x0000727E
		internal virtual Grid PanSkinID { get; set; }

		// Token: 0x17000230 RID: 560
		// (get) Token: 0x06000E49 RID: 3657 RVA: 0x00009087 File Offset: 0x00007287
		// (set) Token: 0x06000E4A RID: 3658 RVA: 0x0006A7A0 File Offset: 0x000689A0
		internal virtual MyTextBox TextSkinID
		{
			[CompilerGenerated]
			get
			{
				return this._MapperPrototype;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageSetupLaunch._Closure$__.$IR67-7 == null) ? (PageSetupLaunch._Closure$__.$IR67-7 = delegate(object sender, RoutedEventArgs e)
				{
					PageSetupLaunch.TextBoxChange((MyTextBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR67-7;
				MyTextBox mapperPrototype = this._MapperPrototype;
				if (mapperPrototype != null)
				{
					mapperPrototype.FindRepository(value2);
				}
				this._MapperPrototype = value;
				mapperPrototype = this._MapperPrototype;
				if (mapperPrototype != null)
				{
					mapperPrototype.SetupRepository(value2);
				}
			}
		}

		// Token: 0x17000231 RID: 561
		// (get) Token: 0x06000E4B RID: 3659 RVA: 0x0000908F File Offset: 0x0000728F
		// (set) Token: 0x06000E4C RID: 3660 RVA: 0x0006A7FC File Offset: 0x000689FC
		internal virtual MyButton BtnSkinSave
		{
			[CompilerGenerated]
			get
			{
				return this.factoryPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnSkinSave_Click);
				MyButton myButton = this.factoryPrototype;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.factoryPrototype = value;
				myButton = this.factoryPrototype;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000232 RID: 562
		// (get) Token: 0x06000E4D RID: 3661 RVA: 0x00009097 File Offset: 0x00007297
		// (set) Token: 0x06000E4E RID: 3662 RVA: 0x0006A840 File Offset: 0x00068A40
		internal virtual MyButton BtnSkinCache
		{
			[CompilerGenerated]
			get
			{
				return this._ProcessPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnSkinCache_Click);
				MyButton processPrototype = this._ProcessPrototype;
				if (processPrototype != null)
				{
					processPrototype.RevertResolver(obj);
				}
				this._ProcessPrototype = value;
				processPrototype = this._ProcessPrototype;
				if (processPrototype != null)
				{
					processPrototype.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000233 RID: 563
		// (get) Token: 0x06000E4F RID: 3663 RVA: 0x0000909F File Offset: 0x0000729F
		// (set) Token: 0x06000E50 RID: 3664 RVA: 0x000090A7 File Offset: 0x000072A7
		internal virtual Grid PanSkinChange { get; set; }

		// Token: 0x17000234 RID: 564
		// (get) Token: 0x06000E51 RID: 3665 RVA: 0x000090B0 File Offset: 0x000072B0
		// (set) Token: 0x06000E52 RID: 3666 RVA: 0x0006A884 File Offset: 0x00068A84
		internal virtual MyButton BtnSkinChange
		{
			[CompilerGenerated]
			get
			{
				return this.utilsPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnSkinChange_Click);
				MyButton myButton = this.utilsPrototype;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.utilsPrototype = value;
				myButton = this.utilsPrototype;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000235 RID: 565
		// (get) Token: 0x06000E53 RID: 3667 RVA: 0x000090B8 File Offset: 0x000072B8
		// (set) Token: 0x06000E54 RID: 3668 RVA: 0x0006A8C8 File Offset: 0x00068AC8
		internal virtual MyButton BtnSkinDelete
		{
			[CompilerGenerated]
			get
			{
				return this._OrderPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnSkinDelete_Click);
				MyButton orderPrototype = this._OrderPrototype;
				if (orderPrototype != null)
				{
					orderPrototype.RevertResolver(obj);
				}
				this._OrderPrototype = value;
				orderPrototype = this._OrderPrototype;
				if (orderPrototype != null)
				{
					orderPrototype.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000236 RID: 566
		// (get) Token: 0x06000E55 RID: 3669 RVA: 0x000090C0 File Offset: 0x000072C0
		// (set) Token: 0x06000E56 RID: 3670 RVA: 0x000090C8 File Offset: 0x000072C8
		internal virtual MyCard CardArgument { get; set; }

		// Token: 0x17000237 RID: 567
		// (get) Token: 0x06000E57 RID: 3671 RVA: 0x000090D1 File Offset: 0x000072D1
		// (set) Token: 0x06000E58 RID: 3672 RVA: 0x0006A90C File Offset: 0x00068B0C
		internal virtual MyTextBox TextArgumentTitle
		{
			[CompilerGenerated]
			get
			{
				return this.m_ThreadPrototype;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageSetupLaunch._Closure$__.$IR95-8 == null) ? (PageSetupLaunch._Closure$__.$IR95-8 = delegate(object sender, RoutedEventArgs e)
				{
					PageSetupLaunch.TextBoxChange((MyTextBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR95-8;
				MyTextBox threadPrototype = this.m_ThreadPrototype;
				if (threadPrototype != null)
				{
					threadPrototype.FindRepository(value2);
				}
				this.m_ThreadPrototype = value;
				threadPrototype = this.m_ThreadPrototype;
				if (threadPrototype != null)
				{
					threadPrototype.SetupRepository(value2);
				}
			}
		}

		// Token: 0x17000238 RID: 568
		// (get) Token: 0x06000E59 RID: 3673 RVA: 0x000090D9 File Offset: 0x000072D9
		// (set) Token: 0x06000E5A RID: 3674 RVA: 0x0006A968 File Offset: 0x00068B68
		internal virtual MyTextBox TextArgumentInfo
		{
			[CompilerGenerated]
			get
			{
				return this.connectionPrototype;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageSetupLaunch._Closure$__.$IR99-9 == null) ? (PageSetupLaunch._Closure$__.$IR99-9 = delegate(object sender, RoutedEventArgs e)
				{
					PageSetupLaunch.TextBoxChange((MyTextBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR99-9;
				MyTextBox myTextBox = this.connectionPrototype;
				if (myTextBox != null)
				{
					myTextBox.FindRepository(value2);
				}
				this.connectionPrototype = value;
				myTextBox = this.connectionPrototype;
				if (myTextBox != null)
				{
					myTextBox.SetupRepository(value2);
				}
			}
		}

		// Token: 0x17000239 RID: 569
		// (get) Token: 0x06000E5B RID: 3675 RVA: 0x000090E1 File Offset: 0x000072E1
		// (set) Token: 0x06000E5C RID: 3676 RVA: 0x0006A9C4 File Offset: 0x00068BC4
		internal virtual MyComboBox ComboArgumentIndie
		{
			[CompilerGenerated]
			get
			{
				return this._CustomerPrototype;
			}
			[CompilerGenerated]
			set
			{
				SelectionChangedEventHandler value2 = (PageSetupLaunch._Closure$__.$IR103-10 == null) ? (PageSetupLaunch._Closure$__.$IR103-10 = delegate(object sender, SelectionChangedEventArgs e)
				{
					PageSetupLaunch.ComboChange((MyComboBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR103-10;
				MyComboBox customerPrototype = this._CustomerPrototype;
				if (customerPrototype != null)
				{
					customerPrototype.SelectionChanged -= value2;
				}
				this._CustomerPrototype = value;
				customerPrototype = this._CustomerPrototype;
				if (customerPrototype != null)
				{
					customerPrototype.SelectionChanged += value2;
				}
			}
		}

		// Token: 0x1700023A RID: 570
		// (get) Token: 0x06000E5D RID: 3677 RVA: 0x000090E9 File Offset: 0x000072E9
		// (set) Token: 0x06000E5E RID: 3678 RVA: 0x0006AA20 File Offset: 0x00068C20
		internal virtual MyComboBox ComboArgumentVisibie
		{
			[CompilerGenerated]
			get
			{
				return this.schemaPrototype;
			}
			[CompilerGenerated]
			set
			{
				SelectionChangedEventHandler value2 = (PageSetupLaunch._Closure$__.$IR107-11 == null) ? (PageSetupLaunch._Closure$__.$IR107-11 = delegate(object sender, SelectionChangedEventArgs e)
				{
					PageSetupLaunch.ComboChange((MyComboBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR107-11;
				SelectionChangedEventHandler value3 = new SelectionChangedEventHandler(this.ComboArgumentVisibie_SizeChanged);
				MyComboBox myComboBox = this.schemaPrototype;
				if (myComboBox != null)
				{
					myComboBox.SelectionChanged -= value2;
					myComboBox.SelectionChanged -= value3;
				}
				this.schemaPrototype = value;
				myComboBox = this.schemaPrototype;
				if (myComboBox != null)
				{
					myComboBox.SelectionChanged += value2;
					myComboBox.SelectionChanged += value3;
				}
			}
		}

		// Token: 0x1700023B RID: 571
		// (get) Token: 0x06000E5F RID: 3679 RVA: 0x000090F1 File Offset: 0x000072F1
		// (set) Token: 0x06000E60 RID: 3680 RVA: 0x0006AA98 File Offset: 0x00068C98
		internal virtual MyComboBox ComboArgumentPriority
		{
			[CompilerGenerated]
			get
			{
				return this.databasePrototype;
			}
			[CompilerGenerated]
			set
			{
				SelectionChangedEventHandler value2 = (PageSetupLaunch._Closure$__.$IR111-12 == null) ? (PageSetupLaunch._Closure$__.$IR111-12 = delegate(object sender, SelectionChangedEventArgs e)
				{
					PageSetupLaunch.ComboChange((MyComboBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR111-12;
				MyComboBox myComboBox = this.databasePrototype;
				if (myComboBox != null)
				{
					myComboBox.SelectionChanged -= value2;
				}
				this.databasePrototype = value;
				myComboBox = this.databasePrototype;
				if (myComboBox != null)
				{
					myComboBox.SelectionChanged += value2;
				}
			}
		}

		// Token: 0x1700023C RID: 572
		// (get) Token: 0x06000E61 RID: 3681 RVA: 0x000090F9 File Offset: 0x000072F9
		// (set) Token: 0x06000E62 RID: 3682 RVA: 0x00009101 File Offset: 0x00007301
		internal virtual Grid PanArgumentWindow { get; set; }

		// Token: 0x1700023D RID: 573
		// (get) Token: 0x06000E63 RID: 3683 RVA: 0x0000910A File Offset: 0x0000730A
		// (set) Token: 0x06000E64 RID: 3684 RVA: 0x0006AAF4 File Offset: 0x00068CF4
		internal virtual MyComboBox ComboArgumentWindowType
		{
			[CompilerGenerated]
			get
			{
				return this.m_AdvisorPrototype;
			}
			[CompilerGenerated]
			set
			{
				SelectionChangedEventHandler value2 = (PageSetupLaunch._Closure$__.$IR119-13 == null) ? (PageSetupLaunch._Closure$__.$IR119-13 = delegate(object sender, SelectionChangedEventArgs e)
				{
					PageSetupLaunch.ComboChange((MyComboBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR119-13;
				SelectionChangedEventHandler value3 = delegate(object sender, SelectionChangedEventArgs e)
				{
					this.method_0();
				};
				MyComboBox advisorPrototype = this.m_AdvisorPrototype;
				if (advisorPrototype != null)
				{
					advisorPrototype.SelectionChanged -= value2;
					advisorPrototype.SelectionChanged -= value3;
				}
				this.m_AdvisorPrototype = value;
				advisorPrototype = this.m_AdvisorPrototype;
				if (advisorPrototype != null)
				{
					advisorPrototype.SelectionChanged += value2;
					advisorPrototype.SelectionChanged += value3;
				}
			}
		}

		// Token: 0x1700023E RID: 574
		// (get) Token: 0x06000E65 RID: 3685 RVA: 0x00009112 File Offset: 0x00007312
		// (set) Token: 0x06000E66 RID: 3686 RVA: 0x0006AB6C File Offset: 0x00068D6C
		internal virtual MyTextBox TextArgumentWindowWidth
		{
			[CompilerGenerated]
			get
			{
				return this.m_ObserverPrototype;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageSetupLaunch._Closure$__.$IR123-15 == null) ? (PageSetupLaunch._Closure$__.$IR123-15 = delegate(object sender, RoutedEventArgs e)
				{
					PageSetupLaunch.TextBoxChange((MyTextBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR123-15;
				MyTextBox observerPrototype = this.m_ObserverPrototype;
				if (observerPrototype != null)
				{
					observerPrototype.FindRepository(value2);
				}
				this.m_ObserverPrototype = value;
				observerPrototype = this.m_ObserverPrototype;
				if (observerPrototype != null)
				{
					observerPrototype.SetupRepository(value2);
				}
			}
		}

		// Token: 0x1700023F RID: 575
		// (get) Token: 0x06000E67 RID: 3687 RVA: 0x0000911A File Offset: 0x0000731A
		// (set) Token: 0x06000E68 RID: 3688 RVA: 0x00009122 File Offset: 0x00007322
		internal virtual TextBlock LabArgumentWindowMiddle { get; set; }

		// Token: 0x17000240 RID: 576
		// (get) Token: 0x06000E69 RID: 3689 RVA: 0x0000912B File Offset: 0x0000732B
		// (set) Token: 0x06000E6A RID: 3690 RVA: 0x0006ABC8 File Offset: 0x00068DC8
		internal virtual MyTextBox TextArgumentWindowHeight
		{
			[CompilerGenerated]
			get
			{
				return this.contextPrototype;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageSetupLaunch._Closure$__.$IR131-16 == null) ? (PageSetupLaunch._Closure$__.$IR131-16 = delegate(object sender, RoutedEventArgs e)
				{
					PageSetupLaunch.TextBoxChange((MyTextBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR131-16;
				MyTextBox myTextBox = this.contextPrototype;
				if (myTextBox != null)
				{
					myTextBox.FindRepository(value2);
				}
				this.contextPrototype = value;
				myTextBox = this.contextPrototype;
				if (myTextBox != null)
				{
					myTextBox.SetupRepository(value2);
				}
			}
		}

		// Token: 0x17000241 RID: 577
		// (get) Token: 0x06000E6B RID: 3691 RVA: 0x00009133 File Offset: 0x00007333
		// (set) Token: 0x06000E6C RID: 3692 RVA: 0x0006AC24 File Offset: 0x00068E24
		internal virtual MyComboBox ComboArgumentJava
		{
			[CompilerGenerated]
			get
			{
				return this.collectionPrototype;
			}
			[CompilerGenerated]
			set
			{
				EventHandler value2 = new EventHandler(this.ComboArgumentJava_DropDownOpened);
				SelectionChangedEventHandler value3 = delegate(object sender, SelectionChangedEventArgs e)
				{
					this.JavaSelectionUpdate();
				};
				MyComboBox myComboBox = this.collectionPrototype;
				if (myComboBox != null)
				{
					myComboBox.DropDownOpened -= value2;
					myComboBox.SelectionChanged -= value3;
				}
				this.collectionPrototype = value;
				myComboBox = this.collectionPrototype;
				if (myComboBox != null)
				{
					myComboBox.DropDownOpened += value2;
					myComboBox.SelectionChanged += value3;
				}
			}
		}

		// Token: 0x17000242 RID: 578
		// (get) Token: 0x06000E6D RID: 3693 RVA: 0x0000913B File Offset: 0x0000733B
		// (set) Token: 0x06000E6E RID: 3694 RVA: 0x0006AC84 File Offset: 0x00068E84
		internal virtual MyTextButton BtnArgumentJavaSearch
		{
			[CompilerGenerated]
			get
			{
				return this.consumerPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyTextButton.ClickEventHandler obj = new MyTextButton.ClickEventHandler(this.BtnArgumentJavaSearch_Click);
				MyTextButton myTextButton = this.consumerPrototype;
				if (myTextButton != null)
				{
					myTextButton.TestRepository(obj);
				}
				this.consumerPrototype = value;
				myTextButton = this.consumerPrototype;
				if (myTextButton != null)
				{
					myTextButton.ResolveRepository(obj);
				}
			}
		}

		// Token: 0x17000243 RID: 579
		// (get) Token: 0x06000E6F RID: 3695 RVA: 0x00009143 File Offset: 0x00007343
		// (set) Token: 0x06000E70 RID: 3696 RVA: 0x0006ACC8 File Offset: 0x00068EC8
		internal virtual MyTextButton BtnArgumentJavaSelect
		{
			[CompilerGenerated]
			get
			{
				return this._FilterPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyTextButton.ClickEventHandler obj = new MyTextButton.ClickEventHandler(this.BtnArgumentJavaSelect_Click);
				MyTextButton filterPrototype = this._FilterPrototype;
				if (filterPrototype != null)
				{
					filterPrototype.TestRepository(obj);
				}
				this._FilterPrototype = value;
				filterPrototype = this._FilterPrototype;
				if (filterPrototype != null)
				{
					filterPrototype.ResolveRepository(obj);
				}
			}
		}

		// Token: 0x17000244 RID: 580
		// (get) Token: 0x06000E71 RID: 3697 RVA: 0x0000914B File Offset: 0x0000734B
		// (set) Token: 0x06000E72 RID: 3698 RVA: 0x00009153 File Offset: 0x00007353
		internal virtual MyHint LabRamWarn { get; set; }

		// Token: 0x17000245 RID: 581
		// (get) Token: 0x06000E73 RID: 3699 RVA: 0x0000915C File Offset: 0x0000735C
		// (set) Token: 0x06000E74 RID: 3700 RVA: 0x0006AD0C File Offset: 0x00068F0C
		internal virtual MyRadioBox RadioRamType0
		{
			[CompilerGenerated]
			get
			{
				return this._FieldPrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupLaunch._Closure$__.$IR151-18 == null) ? (PageSetupLaunch._Closure$__.$IR151-18 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupLaunch.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR151-18;
				IMyRadio.CheckEventHandler value3 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.RefreshRam();
				};
				MyRadioBox fieldPrototype = this._FieldPrototype;
				if (fieldPrototype != null)
				{
					fieldPrototype.Check -= value2;
					fieldPrototype.Check -= value3;
				}
				this._FieldPrototype = value;
				fieldPrototype = this._FieldPrototype;
				if (fieldPrototype != null)
				{
					fieldPrototype.Check += value2;
					fieldPrototype.Check += value3;
				}
			}
		}

		// Token: 0x17000246 RID: 582
		// (get) Token: 0x06000E75 RID: 3701 RVA: 0x00009164 File Offset: 0x00007364
		// (set) Token: 0x06000E76 RID: 3702 RVA: 0x0006AD84 File Offset: 0x00068F84
		internal virtual MyRadioBox RadioRamType1
		{
			[CompilerGenerated]
			get
			{
				return this._PagePrototype;
			}
			[CompilerGenerated]
			set
			{
				IMyRadio.CheckEventHandler value2 = (PageSetupLaunch._Closure$__.$IR155-20 == null) ? (PageSetupLaunch._Closure$__.$IR155-20 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					PageSetupLaunch.RadioBoxChange((MyRadioBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR155-20;
				IMyRadio.CheckEventHandler value3 = delegate(object sender, ModBase.RouteEventArgs e)
				{
					this.RefreshRam();
				};
				MyRadioBox pagePrototype = this._PagePrototype;
				if (pagePrototype != null)
				{
					pagePrototype.Check -= value2;
					pagePrototype.Check -= value3;
				}
				this._PagePrototype = value;
				pagePrototype = this._PagePrototype;
				if (pagePrototype != null)
				{
					pagePrototype.Check += value2;
					pagePrototype.Check += value3;
				}
			}
		}

		// Token: 0x17000247 RID: 583
		// (get) Token: 0x06000E77 RID: 3703 RVA: 0x0000916C File Offset: 0x0000736C
		// (set) Token: 0x06000E78 RID: 3704 RVA: 0x0006ADFC File Offset: 0x00068FFC
		internal virtual MySlider SliderRamCustom
		{
			[CompilerGenerated]
			get
			{
				return this.printerPrototype;
			}
			[CompilerGenerated]
			set
			{
				MySlider.ChangeEventHandler obj = (PageSetupLaunch._Closure$__.$IR159-22 == null) ? (PageSetupLaunch._Closure$__.$IR159-22 = delegate(object a0, bool a1)
				{
					PageSetupLaunch.SliderChange((MySlider)a0, a1);
				}) : PageSetupLaunch._Closure$__.$IR159-22;
				MySlider.ChangeEventHandler obj2 = delegate(object a0, bool a1)
				{
					this.RefreshRam();
				};
				MySlider mySlider = this.printerPrototype;
				if (mySlider != null)
				{
					mySlider.ViewTag(obj);
					mySlider.ViewTag(obj2);
				}
				this.printerPrototype = value;
				mySlider = this.printerPrototype;
				if (mySlider != null)
				{
					mySlider.UpdateTag(obj);
					mySlider.UpdateTag(obj2);
				}
			}
		}

		// Token: 0x17000248 RID: 584
		// (get) Token: 0x06000E79 RID: 3705 RVA: 0x00009174 File Offset: 0x00007374
		// (set) Token: 0x06000E7A RID: 3706 RVA: 0x0000917C File Offset: 0x0000737C
		internal virtual Grid PanRamDisplay { get; set; }

		// Token: 0x17000249 RID: 585
		// (get) Token: 0x06000E7B RID: 3707 RVA: 0x00009185 File Offset: 0x00007385
		// (set) Token: 0x06000E7C RID: 3708 RVA: 0x0000918D File Offset: 0x0000738D
		internal virtual ColumnDefinition ColumnRamUsed { get; set; }

		// Token: 0x1700024A RID: 586
		// (get) Token: 0x06000E7D RID: 3709 RVA: 0x00009196 File Offset: 0x00007396
		// (set) Token: 0x06000E7E RID: 3710 RVA: 0x0000919E File Offset: 0x0000739E
		internal virtual ColumnDefinition ColumnRamGame { get; set; }

		// Token: 0x1700024B RID: 587
		// (get) Token: 0x06000E7F RID: 3711 RVA: 0x000091A7 File Offset: 0x000073A7
		// (set) Token: 0x06000E80 RID: 3712 RVA: 0x000091AF File Offset: 0x000073AF
		internal virtual ColumnDefinition ColumnRamEmpty { get; set; }

		// Token: 0x1700024C RID: 588
		// (get) Token: 0x06000E81 RID: 3713 RVA: 0x000091B8 File Offset: 0x000073B8
		// (set) Token: 0x06000E82 RID: 3714 RVA: 0x000091C0 File Offset: 0x000073C0
		internal virtual Rectangle RectRamUsed { get; set; }

		// Token: 0x1700024D RID: 589
		// (get) Token: 0x06000E83 RID: 3715 RVA: 0x000091C9 File Offset: 0x000073C9
		// (set) Token: 0x06000E84 RID: 3716 RVA: 0x0006AE74 File Offset: 0x00069074
		internal virtual Rectangle RectRamGame
		{
			[CompilerGenerated]
			get
			{
				return this.exceptionPrototype;
			}
			[CompilerGenerated]
			set
			{
				SizeChangedEventHandler value2 = delegate(object sender, SizeChangedEventArgs e)
				{
					this.RefreshRamText();
				};
				Rectangle rectangle = this.exceptionPrototype;
				if (rectangle != null)
				{
					rectangle.SizeChanged -= value2;
				}
				this.exceptionPrototype = value;
				rectangle = this.exceptionPrototype;
				if (rectangle != null)
				{
					rectangle.SizeChanged += value2;
				}
			}
		}

		// Token: 0x1700024E RID: 590
		// (get) Token: 0x06000E85 RID: 3717 RVA: 0x000091D1 File Offset: 0x000073D1
		// (set) Token: 0x06000E86 RID: 3718 RVA: 0x0006AEB8 File Offset: 0x000690B8
		internal virtual Rectangle RectRamEmpty
		{
			[CompilerGenerated]
			get
			{
				return this.testsPrototype;
			}
			[CompilerGenerated]
			set
			{
				SizeChangedEventHandler value2 = delegate(object sender, SizeChangedEventArgs e)
				{
					this.RefreshRamText();
				};
				Rectangle rectangle = this.testsPrototype;
				if (rectangle != null)
				{
					rectangle.SizeChanged -= value2;
				}
				this.testsPrototype = value;
				rectangle = this.testsPrototype;
				if (rectangle != null)
				{
					rectangle.SizeChanged += value2;
				}
			}
		}

		// Token: 0x1700024F RID: 591
		// (get) Token: 0x06000E87 RID: 3719 RVA: 0x000091D9 File Offset: 0x000073D9
		// (set) Token: 0x06000E88 RID: 3720 RVA: 0x000091E1 File Offset: 0x000073E1
		internal virtual TextBlock LabRamUsedTitle { get; set; }

		// Token: 0x17000250 RID: 592
		// (get) Token: 0x06000E89 RID: 3721 RVA: 0x000091EA File Offset: 0x000073EA
		// (set) Token: 0x06000E8A RID: 3722 RVA: 0x000091F2 File Offset: 0x000073F2
		internal virtual TextBlock LabRamGameTitle { get; set; }

		// Token: 0x17000251 RID: 593
		// (get) Token: 0x06000E8B RID: 3723 RVA: 0x000091FB File Offset: 0x000073FB
		// (set) Token: 0x06000E8C RID: 3724 RVA: 0x00009203 File Offset: 0x00007403
		internal virtual TextBlock LabRamUsed { get; set; }

		// Token: 0x17000252 RID: 594
		// (get) Token: 0x06000E8D RID: 3725 RVA: 0x0000920C File Offset: 0x0000740C
		// (set) Token: 0x06000E8E RID: 3726 RVA: 0x00009214 File Offset: 0x00007414
		internal virtual TextBlock LabRamTotal { get; set; }

		// Token: 0x17000253 RID: 595
		// (get) Token: 0x06000E8F RID: 3727 RVA: 0x0000921D File Offset: 0x0000741D
		// (set) Token: 0x06000E90 RID: 3728 RVA: 0x0006AEFC File Offset: 0x000690FC
		internal virtual TextBlock LabRamGame
		{
			[CompilerGenerated]
			get
			{
				return this._ConfigurationPrototype;
			}
			[CompilerGenerated]
			set
			{
				SizeChangedEventHandler value2 = delegate(object sender, SizeChangedEventArgs e)
				{
					this.RefreshRamText();
				};
				TextBlock configurationPrototype = this._ConfigurationPrototype;
				if (configurationPrototype != null)
				{
					configurationPrototype.SizeChanged -= value2;
				}
				this._ConfigurationPrototype = value;
				configurationPrototype = this._ConfigurationPrototype;
				if (configurationPrototype != null)
				{
					configurationPrototype.SizeChanged += value2;
				}
			}
		}

		// Token: 0x17000254 RID: 596
		// (get) Token: 0x06000E91 RID: 3729 RVA: 0x00009225 File Offset: 0x00007425
		// (set) Token: 0x06000E92 RID: 3730 RVA: 0x0006AF40 File Offset: 0x00069140
		internal virtual MyTextBox TextAdvanceJvm
		{
			[CompilerGenerated]
			get
			{
				return this.configPrototype;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageSetupLaunch._Closure$__.$IR211-27 == null) ? (PageSetupLaunch._Closure$__.$IR211-27 = delegate(object sender, RoutedEventArgs e)
				{
					PageSetupLaunch.TextBoxChange((MyTextBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR211-27;
				MyTextBox myTextBox = this.configPrototype;
				if (myTextBox != null)
				{
					myTextBox.FindRepository(value2);
				}
				this.configPrototype = value;
				myTextBox = this.configPrototype;
				if (myTextBox != null)
				{
					myTextBox.SetupRepository(value2);
				}
			}
		}

		// Token: 0x17000255 RID: 597
		// (get) Token: 0x06000E93 RID: 3731 RVA: 0x0000922D File Offset: 0x0000742D
		// (set) Token: 0x06000E94 RID: 3732 RVA: 0x0006AF9C File Offset: 0x0006919C
		internal virtual MyTextBox TextAdvanceGame
		{
			[CompilerGenerated]
			get
			{
				return this._ManagerPrototype;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageSetupLaunch._Closure$__.$IR215-28 == null) ? (PageSetupLaunch._Closure$__.$IR215-28 = delegate(object sender, RoutedEventArgs e)
				{
					PageSetupLaunch.TextBoxChange((MyTextBox)sender, e);
				}) : PageSetupLaunch._Closure$__.$IR215-28;
				MyTextBox managerPrototype = this._ManagerPrototype;
				if (managerPrototype != null)
				{
					managerPrototype.FindRepository(value2);
				}
				this._ManagerPrototype = value;
				managerPrototype = this._ManagerPrototype;
				if (managerPrototype != null)
				{
					managerPrototype.SetupRepository(value2);
				}
			}
		}

		// Token: 0x17000256 RID: 598
		// (get) Token: 0x06000E95 RID: 3733 RVA: 0x00009235 File Offset: 0x00007435
		// (set) Token: 0x06000E96 RID: 3734 RVA: 0x0006AFF8 File Offset: 0x000691F8
		internal virtual MyCheckBox CheckAdvanceAssets
		{
			[CompilerGenerated]
			get
			{
				return this.m_RulePrototype;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupLaunch._Closure$__.$IR219-29 == null) ? (PageSetupLaunch._Closure$__.$IR219-29 = delegate(object a0, bool a1)
				{
					PageSetupLaunch.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupLaunch._Closure$__.$IR219-29;
				MyCheckBox rulePrototype = this.m_RulePrototype;
				if (rulePrototype != null)
				{
					rulePrototype.StopTag(obj);
				}
				this.m_RulePrototype = value;
				rulePrototype = this.m_RulePrototype;
				if (rulePrototype != null)
				{
					rulePrototype.CloneTag(obj);
				}
			}
		}

		// Token: 0x06000E97 RID: 3735 RVA: 0x0006B054 File Offset: 0x00069254
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_MerchantPrototype)
			{
				this.m_MerchantPrototype = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagesetup/pagesetuplaunch.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000E98 RID: 3736 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000E99 RID: 3737 RVA: 0x0006B084 File Offset: 0x00069284
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			if (connectionId == 3)
			{
				this.CardSkin = (MyCard)target;
				return;
			}
			if (connectionId == 4)
			{
				this.RadioSkinType0 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 5)
			{
				this.RadioSkinType1 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 6)
			{
				this.RadioSkinType2 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 7)
			{
				this.RadioSkinType3 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 8)
			{
				this.RadioSkinType4 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 9)
			{
				this.PanSkinID = (Grid)target;
				return;
			}
			if (connectionId == 10)
			{
				this.TextSkinID = (MyTextBox)target;
				return;
			}
			if (connectionId == 11)
			{
				this.BtnSkinSave = (MyButton)target;
				return;
			}
			if (connectionId == 12)
			{
				this.BtnSkinCache = (MyButton)target;
				return;
			}
			if (connectionId == 13)
			{
				this.PanSkinChange = (Grid)target;
				return;
			}
			if (connectionId == 14)
			{
				this.BtnSkinChange = (MyButton)target;
				return;
			}
			if (connectionId == 15)
			{
				this.BtnSkinDelete = (MyButton)target;
				return;
			}
			if (connectionId == 16)
			{
				this.CardArgument = (MyCard)target;
				return;
			}
			if (connectionId == 17)
			{
				this.TextArgumentTitle = (MyTextBox)target;
				return;
			}
			if (connectionId == 18)
			{
				this.TextArgumentInfo = (MyTextBox)target;
				return;
			}
			if (connectionId == 19)
			{
				this.ComboArgumentIndie = (MyComboBox)target;
				return;
			}
			if (connectionId == 20)
			{
				this.ComboArgumentVisibie = (MyComboBox)target;
				return;
			}
			if (connectionId == 21)
			{
				this.ComboArgumentPriority = (MyComboBox)target;
				return;
			}
			if (connectionId == 22)
			{
				this.PanArgumentWindow = (Grid)target;
				return;
			}
			if (connectionId == 23)
			{
				this.ComboArgumentWindowType = (MyComboBox)target;
				return;
			}
			if (connectionId == 24)
			{
				this.TextArgumentWindowWidth = (MyTextBox)target;
				return;
			}
			if (connectionId == 25)
			{
				this.LabArgumentWindowMiddle = (TextBlock)target;
				return;
			}
			if (connectionId == 26)
			{
				this.TextArgumentWindowHeight = (MyTextBox)target;
				return;
			}
			if (connectionId == 27)
			{
				this.ComboArgumentJava = (MyComboBox)target;
				return;
			}
			if (connectionId == 28)
			{
				this.BtnArgumentJavaSearch = (MyTextButton)target;
				return;
			}
			if (connectionId == 29)
			{
				this.BtnArgumentJavaSelect = (MyTextButton)target;
				return;
			}
			if (connectionId == 30)
			{
				this.LabRamWarn = (MyHint)target;
				return;
			}
			if (connectionId == 31)
			{
				this.RadioRamType0 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 32)
			{
				this.RadioRamType1 = (MyRadioBox)target;
				return;
			}
			if (connectionId == 33)
			{
				this.SliderRamCustom = (MySlider)target;
				return;
			}
			if (connectionId == 34)
			{
				this.PanRamDisplay = (Grid)target;
				return;
			}
			if (connectionId == 35)
			{
				this.ColumnRamUsed = (ColumnDefinition)target;
				return;
			}
			if (connectionId == 36)
			{
				this.ColumnRamGame = (ColumnDefinition)target;
				return;
			}
			if (connectionId == 37)
			{
				this.ColumnRamEmpty = (ColumnDefinition)target;
				return;
			}
			if (connectionId == 38)
			{
				this.RectRamUsed = (Rectangle)target;
				return;
			}
			if (connectionId == 39)
			{
				this.RectRamGame = (Rectangle)target;
				return;
			}
			if (connectionId == 40)
			{
				this.RectRamEmpty = (Rectangle)target;
				return;
			}
			if (connectionId == 41)
			{
				this.LabRamUsedTitle = (TextBlock)target;
				return;
			}
			if (connectionId == 42)
			{
				this.LabRamGameTitle = (TextBlock)target;
				return;
			}
			if (connectionId == 43)
			{
				this.LabRamUsed = (TextBlock)target;
				return;
			}
			if (connectionId == 44)
			{
				this.LabRamTotal = (TextBlock)target;
				return;
			}
			if (connectionId == 45)
			{
				this.LabRamGame = (TextBlock)target;
				return;
			}
			if (connectionId == 46)
			{
				this.TextAdvanceJvm = (MyTextBox)target;
				return;
			}
			if (connectionId == 47)
			{
				this.TextAdvanceGame = (MyTextBox)target;
				return;
			}
			if (connectionId == 48)
			{
				this.CheckAdvanceAssets = (MyCheckBox)target;
				return;
			}
			this.m_MerchantPrototype = true;
		}

		// Token: 0x040006F9 RID: 1785
		private bool templatePrototype;

		// Token: 0x040006FA RID: 1786
		private int m_ExpressionPrototype;

		// Token: 0x040006FB RID: 1787
		private int m_GetterPrototype;

		// Token: 0x040006FC RID: 1788
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyScrollViewer listenerPrototype;

		// Token: 0x040006FD RID: 1789
		[CompilerGenerated]
		[AccessedThroughProperty("PanMain")]
		private StackPanel _IdentifierPrototype;

		// Token: 0x040006FE RID: 1790
		[CompilerGenerated]
		[AccessedThroughProperty("CardSkin")]
		private MyCard m_InstancePrototype;

		// Token: 0x040006FF RID: 1791
		[CompilerGenerated]
		[AccessedThroughProperty("RadioSkinType0")]
		private MyRadioBox _CreatorPrototype;

		// Token: 0x04000700 RID: 1792
		[CompilerGenerated]
		[AccessedThroughProperty("RadioSkinType1")]
		private MyRadioBox m_ObjectPrototype;

		// Token: 0x04000701 RID: 1793
		[CompilerGenerated]
		[AccessedThroughProperty("RadioSkinType2")]
		private MyRadioBox _RegPrototype;

		// Token: 0x04000702 RID: 1794
		[CompilerGenerated]
		[AccessedThroughProperty("RadioSkinType3")]
		private MyRadioBox m_InvocationPrototype;

		// Token: 0x04000703 RID: 1795
		[AccessedThroughProperty("RadioSkinType4")]
		[CompilerGenerated]
		private MyRadioBox m_ComposerPrototype;

		// Token: 0x04000704 RID: 1796
		[AccessedThroughProperty("PanSkinID")]
		[CompilerGenerated]
		private Grid itemPrototype;

		// Token: 0x04000705 RID: 1797
		[CompilerGenerated]
		[AccessedThroughProperty("TextSkinID")]
		private MyTextBox _MapperPrototype;

		// Token: 0x04000706 RID: 1798
		[AccessedThroughProperty("BtnSkinSave")]
		[CompilerGenerated]
		private MyButton factoryPrototype;

		// Token: 0x04000707 RID: 1799
		[AccessedThroughProperty("BtnSkinCache")]
		[CompilerGenerated]
		private MyButton _ProcessPrototype;

		// Token: 0x04000708 RID: 1800
		[AccessedThroughProperty("PanSkinChange")]
		[CompilerGenerated]
		private Grid _ValPrototype;

		// Token: 0x04000709 RID: 1801
		[CompilerGenerated]
		[AccessedThroughProperty("BtnSkinChange")]
		private MyButton utilsPrototype;

		// Token: 0x0400070A RID: 1802
		[CompilerGenerated]
		[AccessedThroughProperty("BtnSkinDelete")]
		private MyButton _OrderPrototype;

		// Token: 0x0400070B RID: 1803
		[AccessedThroughProperty("CardArgument")]
		[CompilerGenerated]
		private MyCard policyPrototype;

		// Token: 0x0400070C RID: 1804
		[CompilerGenerated]
		[AccessedThroughProperty("TextArgumentTitle")]
		private MyTextBox m_ThreadPrototype;

		// Token: 0x0400070D RID: 1805
		[AccessedThroughProperty("TextArgumentInfo")]
		[CompilerGenerated]
		private MyTextBox connectionPrototype;

		// Token: 0x0400070E RID: 1806
		[CompilerGenerated]
		[AccessedThroughProperty("ComboArgumentIndie")]
		private MyComboBox _CustomerPrototype;

		// Token: 0x0400070F RID: 1807
		[CompilerGenerated]
		[AccessedThroughProperty("ComboArgumentVisibie")]
		private MyComboBox schemaPrototype;

		// Token: 0x04000710 RID: 1808
		[CompilerGenerated]
		[AccessedThroughProperty("ComboArgumentPriority")]
		private MyComboBox databasePrototype;

		// Token: 0x04000711 RID: 1809
		[CompilerGenerated]
		[AccessedThroughProperty("PanArgumentWindow")]
		private Grid callbackPrototype;

		// Token: 0x04000712 RID: 1810
		[AccessedThroughProperty("ComboArgumentWindowType")]
		[CompilerGenerated]
		private MyComboBox m_AdvisorPrototype;

		// Token: 0x04000713 RID: 1811
		[AccessedThroughProperty("TextArgumentWindowWidth")]
		[CompilerGenerated]
		private MyTextBox m_ObserverPrototype;

		// Token: 0x04000714 RID: 1812
		[AccessedThroughProperty("LabArgumentWindowMiddle")]
		[CompilerGenerated]
		private TextBlock singletonPrototype;

		// Token: 0x04000715 RID: 1813
		[AccessedThroughProperty("TextArgumentWindowHeight")]
		[CompilerGenerated]
		private MyTextBox contextPrototype;

		// Token: 0x04000716 RID: 1814
		[AccessedThroughProperty("ComboArgumentJava")]
		[CompilerGenerated]
		private MyComboBox collectionPrototype;

		// Token: 0x04000717 RID: 1815
		[CompilerGenerated]
		[AccessedThroughProperty("BtnArgumentJavaSearch")]
		private MyTextButton consumerPrototype;

		// Token: 0x04000718 RID: 1816
		[CompilerGenerated]
		[AccessedThroughProperty("BtnArgumentJavaSelect")]
		private MyTextButton _FilterPrototype;

		// Token: 0x04000719 RID: 1817
		[AccessedThroughProperty("LabRamWarn")]
		[CompilerGenerated]
		private MyHint readerPrototype;

		// Token: 0x0400071A RID: 1818
		[CompilerGenerated]
		[AccessedThroughProperty("RadioRamType0")]
		private MyRadioBox _FieldPrototype;

		// Token: 0x0400071B RID: 1819
		[CompilerGenerated]
		[AccessedThroughProperty("RadioRamType1")]
		private MyRadioBox _PagePrototype;

		// Token: 0x0400071C RID: 1820
		[AccessedThroughProperty("SliderRamCustom")]
		[CompilerGenerated]
		private MySlider printerPrototype;

		// Token: 0x0400071D RID: 1821
		[CompilerGenerated]
		[AccessedThroughProperty("PanRamDisplay")]
		private Grid m_TokenPrototype;

		// Token: 0x0400071E RID: 1822
		[AccessedThroughProperty("ColumnRamUsed")]
		[CompilerGenerated]
		private ColumnDefinition interpreterPrototype;

		// Token: 0x0400071F RID: 1823
		[CompilerGenerated]
		[AccessedThroughProperty("ColumnRamGame")]
		private ColumnDefinition _ParserPrototype;

		// Token: 0x04000720 RID: 1824
		[CompilerGenerated]
		[AccessedThroughProperty("ColumnRamEmpty")]
		private ColumnDefinition stubPrototype;

		// Token: 0x04000721 RID: 1825
		[AccessedThroughProperty("RectRamUsed")]
		[CompilerGenerated]
		private Rectangle _ErrorPrototype;

		// Token: 0x04000722 RID: 1826
		[CompilerGenerated]
		[AccessedThroughProperty("RectRamGame")]
		private Rectangle exceptionPrototype;

		// Token: 0x04000723 RID: 1827
		[CompilerGenerated]
		[AccessedThroughProperty("RectRamEmpty")]
		private Rectangle testsPrototype;

		// Token: 0x04000724 RID: 1828
		[CompilerGenerated]
		[AccessedThroughProperty("LabRamUsedTitle")]
		private TextBlock strategyPrototype;

		// Token: 0x04000725 RID: 1829
		[CompilerGenerated]
		[AccessedThroughProperty("LabRamGameTitle")]
		private TextBlock _RulesPrototype;

		// Token: 0x04000726 RID: 1830
		[AccessedThroughProperty("LabRamUsed")]
		[CompilerGenerated]
		private TextBlock _WorkerPrototype;

		// Token: 0x04000727 RID: 1831
		[AccessedThroughProperty("LabRamTotal")]
		[CompilerGenerated]
		private TextBlock dicPrototype;

		// Token: 0x04000728 RID: 1832
		[CompilerGenerated]
		[AccessedThroughProperty("LabRamGame")]
		private TextBlock _ConfigurationPrototype;

		// Token: 0x04000729 RID: 1833
		[AccessedThroughProperty("TextAdvanceJvm")]
		[CompilerGenerated]
		private MyTextBox configPrototype;

		// Token: 0x0400072A RID: 1834
		[CompilerGenerated]
		[AccessedThroughProperty("TextAdvanceGame")]
		private MyTextBox _ManagerPrototype;

		// Token: 0x0400072B RID: 1835
		[CompilerGenerated]
		[AccessedThroughProperty("CheckAdvanceAssets")]
		private MyCheckBox m_RulePrototype;

		// Token: 0x0400072C RID: 1836
		private bool m_MerchantPrototype;
	}
}
