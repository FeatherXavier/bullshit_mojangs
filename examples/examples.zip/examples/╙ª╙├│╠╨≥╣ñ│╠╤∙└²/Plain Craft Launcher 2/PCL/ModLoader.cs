﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Shell;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x020000C5 RID: 197
	[StandardModule]
	public sealed class ModLoader
	{
		// Token: 0x06000835 RID: 2101 RVA: 0x00037EF0 File Offset: 0x000360F0
		public static void LoaderTaskbarAdd(ModLoader.LoaderBase Loader)
		{
			if (ModMain._PrinterAccount != null)
			{
				ModMain._PrinterAccount.TaskRemove(Loader);
			}
			object loaderTaskbarLock = ModLoader.LoaderTaskbarLock;
			ObjectFlowControl.CheckForSyncLockOnValueType(loaderTaskbarLock);
			lock (loaderTaskbarLock)
			{
				ModLoader.LoaderTaskbar.Add(Loader);
			}
		}

		// Token: 0x06000836 RID: 2102 RVA: 0x00037F4C File Offset: 0x0003614C
		public static void LoaderTaskbarProgressRefresh()
		{
			try
			{
				double num = ModLoader.LoaderTaskbarProgressGet();
				object loaderTaskbarLock = ModLoader.LoaderTaskbarLock;
				ObjectFlowControl.CheckForSyncLockOnValueType(loaderTaskbarLock);
				checked
				{
					lock (loaderTaskbarLock)
					{
						bool flag2 = true;
						try
						{
							foreach (ModLoader.LoaderBase loaderBase in ModLoader.LoaderTaskbar)
							{
								if (loaderBase.Show && loaderBase.State == ModBase.LoadState.Loading)
								{
									flag2 = false;
								}
							}
						}
						finally
						{
							List<ModLoader.LoaderBase>.Enumerator enumerator;
							((IDisposable)enumerator).Dispose();
						}
						List<ModLoader.LoaderBase> list = new List<ModLoader.LoaderBase>();
						int num2 = ModLoader.LoaderTaskbar.Count - 1;
						for (int i = 0; i <= num2; i++)
						{
							if ((flag2 || ModLoader.LoaderTaskbar[i].State == ModBase.LoadState.Aborted) && ModLoader.LoaderTaskbar[i].Show)
							{
								if (ModMain._PrinterAccount != null)
								{
									ModMain._PrinterAccount.TaskRefresh(ModLoader.LoaderTaskbar[i]);
								}
								list.Add(ModLoader.LoaderTaskbar[i]);
							}
						}
						try
						{
							foreach (ModLoader.LoaderBase item in list)
							{
								ModLoader.LoaderTaskbar.Remove(item);
							}
						}
						finally
						{
							List<ModLoader.LoaderBase>.Enumerator enumerator2;
							((IDisposable)enumerator2).Dispose();
						}
					}
				}
				if (num > 0.0 && num < 1.0 && ModLoader.LoaderTaskbarProgress <= num)
				{
					ModLoader.LoaderTaskbarProgress = ModLoader.LoaderTaskbarProgress * 0.9 + num * 0.1;
				}
				else
				{
					ModLoader.LoaderTaskbarProgress = num;
				}
				TaskbarItemProgressState taskbarItemProgressState;
				if (ModLoader.LoaderTaskbar.Count != 0)
				{
					if (ModLoader.LoaderTaskbarProgress != 1.0)
					{
						if (ModLoader.LoaderTaskbarProgress < 0.015)
						{
							taskbarItemProgressState = TaskbarItemProgressState.Indeterminate;
							goto IL_1C2;
						}
						taskbarItemProgressState = TaskbarItemProgressState.Normal;
						ModMain.m_CollectionAccount.TaskbarItemInfo.ProgressValue = ModLoader.LoaderTaskbarProgress;
						goto IL_1C2;
					}
				}
				taskbarItemProgressState = TaskbarItemProgressState.None;
				IL_1C2:
				if (ModLoader.LoaderTaskbarProgressLast != taskbarItemProgressState)
				{
					ModLoader.LoaderTaskbarProgressLast = taskbarItemProgressState;
					ModMain.m_CollectionAccount.TaskbarItemInfo.ProgressState = taskbarItemProgressState;
					ModMain.m_CollectionAccount.BtnExtraDownload.ShowRefresh();
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "刷新任务栏进度显示失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000837 RID: 2103 RVA: 0x000381D0 File Offset: 0x000363D0
		public static double LoaderTaskbarProgressGet()
		{
			checked
			{
				double result;
				try
				{
					double num = 0.0;
					int num2 = 0;
					object loaderTaskbarLock = ModLoader.LoaderTaskbarLock;
					ObjectFlowControl.CheckForSyncLockOnValueType(loaderTaskbarLock);
					lock (loaderTaskbarLock)
					{
						int num3 = ModLoader.LoaderTaskbar.Count - 1;
						for (int i = 0; i <= num3; i++)
						{
							unchecked
							{
								num += ModLoader.LoaderTaskbar[i].Progress;
							}
							num2++;
						}
					}
					if (num2 == 0)
					{
						result = 1.0;
					}
					else
					{
						result = ModBase.MathRange(num / (double)num2, 0.0, 1.0);
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "获取任务栏进度出错", ModBase.LogLevel.Feedback, "出现错误");
					result = 0.5;
				}
				return result;
			}
		}

		// Token: 0x06000838 RID: 2104 RVA: 0x000382BC File Offset: 0x000364BC
		public static bool LoaderFolderRun(ModLoader.LoaderBase Loader, string FolderPath, ModLoader.LoaderFolderRunType Type, int MaxDepth = 0, string ExtraPath = "", bool WaitForExit = false)
		{
			ModLoader.LoaderFolderDictionaryEntry value = default(ModLoader.LoaderFolderDictionaryEntry);
			value.FolderPath = FolderPath + ExtraPath;
			value.LastCheckTime = null;
			try
			{
				DirectoryInfo directoryInfo = new DirectoryInfo(FolderPath + ExtraPath);
				value.LastCheckTime = (directoryInfo.Exists ? new DateTime?(ModLoader.GetActualLastWriteTimeUtc(directoryInfo, MaxDepth)) : ((DateTime?)null));
				if (Type == ModLoader.LoaderFolderRunType.RunOnUpdated && ModLoader.LoaderFolderDictionary.ContainsKey(Loader))
				{
					if (directoryInfo.Exists)
					{
						ModLoader.LoaderFolderDictionaryEntry loaderFolderDictionaryEntry = ModLoader.LoaderFolderDictionary[Loader];
						if (loaderFolderDictionaryEntry.LastCheckTime != null && value.Equals(ModLoader.LoaderFolderDictionary[Loader]))
						{
							return false;
						}
					}
					else
					{
						ModLoader.LoaderFolderDictionaryEntry loaderFolderDictionaryEntry = ModLoader.LoaderFolderDictionary[Loader];
						if (loaderFolderDictionaryEntry.LastCheckTime == null)
						{
							return false;
						}
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "文件夹加载器启动检测出错", ModBase.LogLevel.Debug, "出现错误");
			}
			ModBase.DictionaryAdd<ModLoader.LoaderBase, ModLoader.LoaderFolderDictionaryEntry>(ref ModLoader.LoaderFolderDictionary, Loader, value);
			bool result;
			if (Type == ModLoader.LoaderFolderRunType.UpdateOnly)
			{
				result = false;
			}
			else
			{
				if (WaitForExit)
				{
					Loader.WaitForExit(FolderPath, null, true);
				}
				else
				{
					Loader.Start(FolderPath, true);
				}
				result = true;
			}
			return result;
		}

		// Token: 0x06000839 RID: 2105 RVA: 0x000383F4 File Offset: 0x000365F4
		private static DateTime GetActualLastWriteTimeUtc(DirectoryInfo FolderInfo, int MaxDepth)
		{
			DateTime dateTime = FolderInfo.LastWriteTimeUtc;
			if (MaxDepth > 0)
			{
				try
				{
					foreach (DirectoryInfo folderInfo in FolderInfo.EnumerateDirectories())
					{
						DateTime actualLastWriteTimeUtc = ModLoader.GetActualLastWriteTimeUtc(folderInfo, checked(MaxDepth - 1));
						if (DateTime.Compare(actualLastWriteTimeUtc, dateTime) > 0)
						{
							dateTime = actualLastWriteTimeUtc;
						}
					}
				}
				finally
				{
					IEnumerator<DirectoryInfo> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
			}
			return dateTime;
		}

		// Token: 0x040003B4 RID: 948
		public static object LoaderTaskbarLock = RuntimeHelpers.GetObjectValue(new object());

		// Token: 0x040003B5 RID: 949
		public static List<ModLoader.LoaderBase> LoaderTaskbar = new List<ModLoader.LoaderBase>();

		// Token: 0x040003B6 RID: 950
		public static double LoaderTaskbarProgress = 0.0;

		// Token: 0x040003B7 RID: 951
		private static TaskbarItemProgressState LoaderTaskbarProgressLast = TaskbarItemProgressState.None;

		// Token: 0x040003B8 RID: 952
		private static Dictionary<ModLoader.LoaderBase, ModLoader.LoaderFolderDictionaryEntry> LoaderFolderDictionary = new Dictionary<ModLoader.LoaderBase, ModLoader.LoaderFolderDictionaryEntry>();

		// Token: 0x020000C6 RID: 198
		public abstract class LoaderBase : ILoadingTrigger
		{
			// Token: 0x0600083A RID: 2106 RVA: 0x0003845C File Offset: 0x0003665C
			protected LoaderBase()
			{
				this.IsLoader = 1;
				this.Uuid = ModBase.GetUuid();
				this.Name = "未命名任务 " + Conversions.ToString(this.Uuid) + "#";
				this.LockState = RuntimeHelpers.GetObjectValue(new object());
				this.Parent = null;
				this.HasOnStateChangedThread = false;
				this._State = ModBase.LoadState.Waiting;
				this._LoadingState = MyLoading.MyLoadingState.Stop;
				this.Error = null;
				this.Block = true;
				this.Show = true;
				this.IsForceRestarting = false;
				this._Progress = -1.0;
				this.ProgressWeight = 1.0;
			}

			// Token: 0x1700014E RID: 334
			// (get) Token: 0x0600083B RID: 2107 RVA: 0x0000640C File Offset: 0x0000460C
			public bool IsLoader { get; }

			// Token: 0x1700014F RID: 335
			// (get) Token: 0x0600083C RID: 2108 RVA: 0x00038508 File Offset: 0x00036708
			public ModLoader.LoaderBase RealParent
			{
				get
				{
					ModLoader.LoaderBase loaderBase;
					try
					{
						loaderBase = this.Parent;
						while (loaderBase != null && loaderBase.Parent != null)
						{
							loaderBase = loaderBase.Parent;
						}
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "获取父加载器失败（" + this.Name + "）", ModBase.LogLevel.Feedback, "出现错误");
						loaderBase = null;
					}
					return loaderBase;
				}
			}

			// Token: 0x0600083D RID: 2109 RVA: 0x00006414 File Offset: 0x00004614
			public virtual void InitParent(ModLoader.LoaderBase Parent)
			{
				this.Parent = Parent;
			}

			// Token: 0x14000005 RID: 5
			// (add) Token: 0x0600083E RID: 2110 RVA: 0x00038574 File Offset: 0x00036774
			// (remove) Token: 0x0600083F RID: 2111 RVA: 0x000385AC File Offset: 0x000367AC
			public event ModLoader.LoaderBase.OnStateChangedThreadEventHandler OnStateChangedThread;

			// Token: 0x14000006 RID: 6
			// (add) Token: 0x06000840 RID: 2112 RVA: 0x000385E4 File Offset: 0x000367E4
			// (remove) Token: 0x06000841 RID: 2113 RVA: 0x0003861C File Offset: 0x0003681C
			public event ModLoader.LoaderBase.OnStateChangedUiEventHandler OnStateChangedUi;

			// Token: 0x17000150 RID: 336
			// (set) Token: 0x06000842 RID: 2114 RVA: 0x00038654 File Offset: 0x00036854
			public Action<ModLoader.LoaderBase> OnStateChanged
			{
				set
				{
					this.OnStateChangedUi += delegate(ModLoader.LoaderBase Loader, ModBase.LoadState NewState, ModBase.LoadState OldState)
					{
						value(Loader);
					};
				}
			}

			// Token: 0x14000007 RID: 7
			// (add) Token: 0x06000843 RID: 2115 RVA: 0x00038680 File Offset: 0x00036880
			// (remove) Token: 0x06000844 RID: 2116 RVA: 0x000386B8 File Offset: 0x000368B8
			public event ModLoader.LoaderBase.PreviewFinishEventHandler PreviewFinish;

			// Token: 0x06000845 RID: 2117 RVA: 0x000386F0 File Offset: 0x000368F0
			protected void RaisePreviewFinish()
			{
				ModLoader.LoaderBase.PreviewFinishEventHandler previewFinishEvent = this.PreviewFinishEvent;
				if (previewFinishEvent != null)
				{
					previewFinishEvent(this);
				}
			}

			// Token: 0x17000151 RID: 337
			// (get) Token: 0x06000846 RID: 2118 RVA: 0x0000641D File Offset: 0x0000461D
			// (set) Token: 0x06000847 RID: 2119 RVA: 0x00038710 File Offset: 0x00036910
			public ModBase.LoadState State
			{
				get
				{
					return this._State;
				}
				set
				{
					if (this._State != value)
					{
						ModBase.LoadState OldState = this._State;
						if (Conversions.ToBoolean(value == ModBase.LoadState.Loading && Conversions.ToBoolean(ModBase._ParamsState.Get("SystemDebugDelay", null))))
						{
							Thread.Sleep(ModBase.RandomInteger(100, 2000));
						}
						this._State = value;
						ModBase.Log("[Loader] 加载器 " + this.Name + " 状态改变：" + ModBase.GetStringFromEnum(value), ModBase.LogLevel.Normal, "出现错误");
						ModBase.RunInUi(delegate()
						{
							ModBase.LoadState $VB$Local_value = value;
							if ($VB$Local_value != ModBase.LoadState.Loading)
							{
								if ($VB$Local_value != ModBase.LoadState.Failed)
								{
									this.LoadingState = MyLoading.MyLoadingState.Stop;
								}
								else
								{
									this.LoadingState = MyLoading.MyLoadingState.Error;
								}
							}
							else
							{
								this.LoadingState = MyLoading.MyLoadingState.Run;
							}
							ModLoader.LoaderBase.OnStateChangedUiEventHandler onStateChangedUiEvent = this.OnStateChangedUiEvent;
							if (onStateChangedUiEvent != null)
							{
								onStateChangedUiEvent(this, value, OldState);
							}
						}, false);
						if (this.HasOnStateChangedThread)
						{
							ModBase.RunInThread(delegate
							{
								ModLoader.LoaderBase.OnStateChangedThreadEventHandler onStateChangedThreadEvent = this.OnStateChangedThreadEvent;
								if (onStateChangedThreadEvent != null)
								{
									onStateChangedThreadEvent(this, value, OldState);
								}
							});
						}
					}
				}
			}

			// Token: 0x17000152 RID: 338
			// (get) Token: 0x06000848 RID: 2120 RVA: 0x00006425 File Offset: 0x00004625
			// (set) Token: 0x06000849 RID: 2121 RVA: 0x000387F4 File Offset: 0x000369F4
			public MyLoading.MyLoadingState LoadingState
			{
				get
				{
					return this._LoadingState;
				}
				set
				{
					if (this._LoadingState != value)
					{
						MyLoading.MyLoadingState loadingState = this._LoadingState;
						this._LoadingState = value;
						ILoadingTrigger.LoadingStateChangedEventHandler loadingStateChangedEvent = this.LoadingStateChangedEvent;
						if (loadingStateChangedEvent != null)
						{
							loadingStateChangedEvent(value, loadingState);
						}
					}
				}
			}

			// Token: 0x14000008 RID: 8
			// (add) Token: 0x0600084A RID: 2122 RVA: 0x0003882C File Offset: 0x00036A2C
			// (remove) Token: 0x0600084B RID: 2123 RVA: 0x00038864 File Offset: 0x00036A64
			public event ILoadingTrigger.LoadingStateChangedEventHandler LoadingStateChanged;

			// Token: 0x17000153 RID: 339
			// (get) Token: 0x0600084C RID: 2124 RVA: 0x0000642D File Offset: 0x0000462D
			// (set) Token: 0x0600084D RID: 2125 RVA: 0x00006435 File Offset: 0x00004635
			public Exception Error { get; set; }

			// Token: 0x17000154 RID: 340
			// (get) Token: 0x0600084E RID: 2126 RVA: 0x0003889C File Offset: 0x00036A9C
			// (set) Token: 0x0600084F RID: 2127 RVA: 0x0000643E File Offset: 0x0000463E
			public virtual double Progress
			{
				get
				{
					ModBase.LoadState state = this.State;
					double result;
					if (state != ModBase.LoadState.Waiting)
					{
						if (state != ModBase.LoadState.Loading)
						{
							result = 1.0;
						}
						else
						{
							result = ((this._Progress == -1.0) ? 0.02 : this._Progress);
						}
					}
					else
					{
						result = 0.0;
					}
					return result;
				}
				set
				{
					this._Progress = value;
				}
			}

			// Token: 0x17000155 RID: 341
			// (get) Token: 0x06000850 RID: 2128 RVA: 0x00006447 File Offset: 0x00004647
			// (set) Token: 0x06000851 RID: 2129 RVA: 0x0000644F File Offset: 0x0000464F
			public double ProgressWeight { get; set; }

			// Token: 0x06000852 RID: 2130
			public abstract void Start(object Input = null, bool IsForceRestart = false);

			// Token: 0x06000853 RID: 2131
			public abstract void Abort();

			// Token: 0x06000854 RID: 2132 RVA: 0x000388F4 File Offset: 0x00036AF4
			public void WaitForExit(object Input = null, ModLoader.LoaderBase LoaderToSyncProgress = null, bool IsForceRestart = false)
			{
				this.Start(RuntimeHelpers.GetObjectValue(Input), IsForceRestart);
				while (this.State == ModBase.LoadState.Loading)
				{
					if (LoaderToSyncProgress != null)
					{
						LoaderToSyncProgress.Progress = this.Progress;
					}
					Thread.Sleep(10);
				}
				if (this.State == ModBase.LoadState.Finished)
				{
					return;
				}
				if (this.State == ModBase.LoadState.Aborted)
				{
					throw new ThreadInterruptedException("加载器执行已中断。");
				}
				if (Information.IsNothing(this.Error))
				{
					throw new Exception("未知错误！");
				}
				throw new Exception(this.Error.Message, this.Error);
			}

			// Token: 0x06000855 RID: 2133 RVA: 0x0003897C File Offset: 0x00036B7C
			public void WaitForExitTime(int Timeout, object Input = null, string TimeoutMessage = "等待加载器执行超时。", object LoaderToSyncProgress = null, bool IsForceRestart = false)
			{
				this.Start(RuntimeHelpers.GetObjectValue(Input), IsForceRestart);
				checked
				{
					while (this.State == ModBase.LoadState.Loading)
					{
						if (LoaderToSyncProgress != null)
						{
							NewLateBinding.LateSet(LoaderToSyncProgress, null, "Progress", new object[]
							{
								this.Progress
							}, null, null);
						}
						Thread.Sleep(10);
						Timeout -= 10;
						if (Timeout < 0)
						{
							throw new TimeoutException(TimeoutMessage);
						}
					}
					if (this.State == ModBase.LoadState.Finished)
					{
						return;
					}
					if (this.State == ModBase.LoadState.Aborted)
					{
						throw new ThreadInterruptedException("加载器执行已中断。");
					}
					if (Information.IsNothing(this.Error))
					{
						throw new Exception("未知错误！");
					}
					throw this.Error;
				}
			}

			// Token: 0x06000856 RID: 2134 RVA: 0x00038A20 File Offset: 0x00036C20
			public override bool Equals(object obj)
			{
				ModLoader.LoaderBase loaderBase = obj as ModLoader.LoaderBase;
				return loaderBase != null && this.Uuid == loaderBase.Uuid;
			}

			// Token: 0x040003BA RID: 954
			public int Uuid;

			// Token: 0x040003BB RID: 955
			public string Name;

			// Token: 0x040003BC RID: 956
			public readonly object LockState;

			// Token: 0x040003BD RID: 957
			public ModLoader.LoaderBase Parent;

			// Token: 0x040003BF RID: 959
			public bool HasOnStateChangedThread;

			// Token: 0x040003C2 RID: 962
			private ModBase.LoadState _State;

			// Token: 0x040003C3 RID: 963
			private MyLoading.MyLoadingState _LoadingState;

			// Token: 0x040003C6 RID: 966
			public bool Block;

			// Token: 0x040003C7 RID: 967
			public bool Show;

			// Token: 0x040003C8 RID: 968
			public bool IsForceRestarting;

			// Token: 0x040003C9 RID: 969
			private double _Progress;

			// Token: 0x020000C7 RID: 199
			// (Invoke) Token: 0x0600085B RID: 2139
			public delegate void OnStateChangedThreadEventHandler(ModLoader.LoaderBase Loader, ModBase.LoadState NewState, ModBase.LoadState OldState);

			// Token: 0x020000C8 RID: 200
			// (Invoke) Token: 0x06000860 RID: 2144
			public delegate void OnStateChangedUiEventHandler(ModLoader.LoaderBase Loader, ModBase.LoadState NewState, ModBase.LoadState OldState);

			// Token: 0x020000C9 RID: 201
			// (Invoke) Token: 0x06000865 RID: 2149
			public delegate void PreviewFinishEventHandler(ModLoader.LoaderBase Loader);
		}

		// Token: 0x020000CC RID: 204
		public class LoaderTask<InputType, OutputType> : ModLoader.LoaderBase
		{
			// Token: 0x17000156 RID: 342
			// (get) Token: 0x0600086E RID: 2158 RVA: 0x00006466 File Offset: 0x00004666
			public bool IsAborted
			{
				get
				{
					return this.LastRunningThread == null || !object.ReferenceEquals(Thread.CurrentThread, this.LastRunningThread);
				}
			}

			// Token: 0x0600086F RID: 2159 RVA: 0x00038AE8 File Offset: 0x00036CE8
			public InputType StartGetInput(InputType Input = default(InputType), Func<object> InputDelegate = null)
			{
				if (InputDelegate == null)
				{
					InputDelegate = this.InputDelegate;
				}
				InputType inputType = default(InputType);
				if ((Input == null || (inputType != null && Input.Equals(inputType))) && InputDelegate != null)
				{
					ModBase.RunInUiWait(delegate
					{
						Input = Conversions.ToGenericParameter<InputType>(InputDelegate());
					});
				}
				return Input;
			}

			// Token: 0x06000870 RID: 2160 RVA: 0x00038B74 File Offset: 0x00036D74
			public bool ShouldStart(ref object Input, bool IsForceRestart = false)
			{
				try
				{
					Input = this.StartGetInput(Conversions.ToGenericParameter<InputType>(Input), null);
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "加载输入获取失败（" + this.Name + "）", ModBase.LogLevel.Hint, "出现错误");
					base.Error = ex;
					object lockState = this.LockState;
					ObjectFlowControl.CheckForSyncLockOnValueType(lockState);
					lock (lockState)
					{
						base.State = ModBase.LoadState.Failed;
					}
				}
				return IsForceRestart || ((Input == null || !Input.Equals(this.Input)) && (Input != null || this.Input != null)) || (base.State != ModBase.LoadState.Loading && base.State != ModBase.LoadState.Finished) || (this.ReloadTimeout != -1 && checked(ModBase.GetTimeTick() - this.LastFinishedTime) >= (long)this.ReloadTimeout);
			}

			// Token: 0x06000871 RID: 2161 RVA: 0x00038C78 File Offset: 0x00036E78
			public override void Start(object Input = null, bool IsForceRestart = false)
			{
				if (this.ShouldStart(ref Input, IsForceRestart))
				{
					if (base.State == ModBase.LoadState.Loading)
					{
						this.TriggerThreadAbort();
					}
					this.Input = Conversions.ToGenericParameter<InputType>(Input);
					object lockState = this.LockState;
					ObjectFlowControl.CheckForSyncLockOnValueType(lockState);
					lock (lockState)
					{
						base.State = ModBase.LoadState.Loading;
					}
					this.LastRunningThread = new Thread(delegate()
					{
						try
						{
							this.IsForceRestarting = IsForceRestart;
							if (ModBase._EventState)
							{
								ModBase.Log(string.Concat(new string[]
								{
									"[Loader] 加载线程 ",
									this.Name,
									" (",
									Conversions.ToString(Thread.CurrentThread.ManagedThreadId),
									") 已启动"
								}), ModBase.LogLevel.Normal, "出现错误");
							}
							this.LoadDelegate(this);
							if (this.IsAborted)
							{
								ModBase.Log(string.Concat(new string[]
								{
									"[Loader] 加载线程 ",
									this.Name,
									" (",
									Conversions.ToString(Thread.CurrentThread.ManagedThreadId),
									") 已中断但线程正常运行至结束，输出被弃用（最新线程：",
									Conversions.ToString((this.LastRunningThread == null) ? -1 : this.LastRunningThread.ManagedThreadId),
									"）"
								}), ModBase.LogLevel.Developer, "出现错误");
							}
							else
							{
								this.RaisePreviewFinish();
								this.State = ModBase.LoadState.Finished;
								this.LastFinishedTime = ModBase.GetTimeTick();
							}
						}
						catch (ThreadInterruptedException ex)
						{
							if (ModBase._EventState)
							{
								ModBase.Log(ex, string.Concat(new string[]
								{
									"加载线程 ",
									this.Name,
									" (",
									Conversions.ToString(Thread.CurrentThread.ManagedThreadId),
									") 已触发线程中断"
								}), ModBase.LogLevel.Debug, "出现错误");
							}
						}
						catch (Exception ex2)
						{
							if (!this.IsAborted)
							{
								ModBase.Log(ex2, string.Concat(new string[]
								{
									"加载线程 ",
									this.Name,
									" (",
									Conversions.ToString(Thread.CurrentThread.ManagedThreadId),
									") 发生运行时错误"
								}), ModBase.LogLevel.Developer, "出现错误");
								this.Error = ex2;
								this.State = ModBase.LoadState.Failed;
							}
						}
					})
					{
						Name = this.Name,
						Priority = this.ThreadPriority
					};
					this.LastRunningThread.Start();
				}
			}

			// Token: 0x06000872 RID: 2162 RVA: 0x00038D38 File Offset: 0x00036F38
			public override void Abort()
			{
				if (base.State == ModBase.LoadState.Loading)
				{
					object lockState = this.LockState;
					ObjectFlowControl.CheckForSyncLockOnValueType(lockState);
					lock (lockState)
					{
						base.State = ModBase.LoadState.Aborted;
					}
					this.TriggerThreadAbort();
				}
			}

			// Token: 0x06000873 RID: 2163 RVA: 0x00038D90 File Offset: 0x00036F90
			private void TriggerThreadAbort()
			{
				if (this.LastRunningThread != null)
				{
					if (ModBase._EventState)
					{
						ModBase.Log(string.Concat(new string[]
						{
							"[Loader] 加载线程 ",
							this.Name,
							" (",
							Conversions.ToString(this.LastRunningThread.ManagedThreadId),
							") 已中断"
						}), ModBase.LogLevel.Normal, "出现错误");
					}
					if (this.LastRunningThread.IsAlive)
					{
						this.LastRunningThread.Interrupt();
					}
					this.LastRunningThread = null;
				}
			}

			// Token: 0x06000874 RID: 2164 RVA: 0x00006485 File Offset: 0x00004685
			public LoaderTask()
			{
				this.ReloadTimeout = -1;
				this.LastFinishedTime = 0L;
				this.LastRunningThread = null;
				this.Input = default(InputType);
				this.Output = default(OutputType);
			}

			// Token: 0x06000875 RID: 2165 RVA: 0x00038E18 File Offset: 0x00037018
			public LoaderTask(string Name, Action<ModLoader.LoaderTask<InputType, OutputType>> LoadDelegate, Func<InputType> InputDelegate = null, ThreadPriority Priority = ThreadPriority.Normal)
			{
				this.ReloadTimeout = -1;
				this.LastFinishedTime = 0L;
				this.LastRunningThread = null;
				this.Input = default(InputType);
				this.Output = default(OutputType);
				this.Name = Name;
				this.LoadDelegate = LoadDelegate;
				this.InputDelegate = InputDelegate;
				this.ThreadPriority = Priority;
			}

			// Token: 0x040003CF RID: 975
			protected internal ThreadPriority ThreadPriority;

			// Token: 0x040003D0 RID: 976
			protected internal Action<ModLoader.LoaderTask<InputType, OutputType>> LoadDelegate;

			// Token: 0x040003D1 RID: 977
			protected internal Func<object> InputDelegate;

			// Token: 0x040003D2 RID: 978
			public int ReloadTimeout;

			// Token: 0x040003D3 RID: 979
			public long LastFinishedTime;

			// Token: 0x040003D4 RID: 980
			public Thread LastRunningThread;

			// Token: 0x040003D5 RID: 981
			public InputType Input;

			// Token: 0x040003D6 RID: 982
			public OutputType Output;
		}

		// Token: 0x020000CF RID: 207
		public class LoaderCombo<InputType> : ModLoader.LoaderBase
		{
			// Token: 0x17000157 RID: 343
			// (get) Token: 0x0600087D RID: 2173 RVA: 0x000390EC File Offset: 0x000372EC
			// (set) Token: 0x0600087E RID: 2174 RVA: 0x000064DB File Offset: 0x000046DB
			public override double Progress
			{
				get
				{
					ModBase.LoadState state = base.State;
					double result;
					if (state != ModBase.LoadState.Waiting)
					{
						if (state != ModBase.LoadState.Loading)
						{
							result = 1.0;
						}
						else
						{
							double num = 0.0;
							double num2 = 0.0;
							try
							{
								foreach (ModLoader.LoaderBase loaderBase in this.Loaders)
								{
									num += loaderBase.ProgressWeight;
									num2 += loaderBase.ProgressWeight * loaderBase.Progress;
								}
							}
							finally
							{
								List<ModLoader.LoaderBase>.Enumerator enumerator;
								((IDisposable)enumerator).Dispose();
							}
							if (num == 0.0)
							{
								result = 0.0;
							}
							else
							{
								result = num2 / num;
							}
						}
					}
					else
					{
						result = 0.0;
					}
					return result;
				}
				set
				{
					throw new Exception("多重加载器不支持设置进度");
				}
			}

			// Token: 0x0600087F RID: 2175 RVA: 0x000391B4 File Offset: 0x000373B4
			public LoaderCombo(string Name, IEnumerable<ModLoader.LoaderBase> Loaders)
			{
				this.Loaders = new List<ModLoader.LoaderBase>();
				this.Loaders.Clear();
				try
				{
					foreach (ModLoader.LoaderBase loaderBase in Loaders)
					{
						if (loaderBase != null)
						{
							this.Loaders.Add(loaderBase);
							loaderBase.OnStateChangedThread += this.SubTaskStateChanged;
							loaderBase.HasOnStateChangedThread = true;
						}
					}
				}
				finally
				{
					IEnumerator<ModLoader.LoaderBase> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				this.InitParent(null);
				this.Name = Name;
			}

			// Token: 0x06000880 RID: 2176 RVA: 0x00039248 File Offset: 0x00037448
			public override void InitParent(ModLoader.LoaderBase Parent)
			{
				this.Parent = Parent;
				try
				{
					foreach (ModLoader.LoaderBase loaderBase in this.Loaders)
					{
						loaderBase.InitParent(this);
					}
				}
				finally
				{
					List<ModLoader.LoaderBase>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
			}

			// Token: 0x06000881 RID: 2177 RVA: 0x000392A0 File Offset: 0x000374A0
			public override void Start(object Input = null, bool IsForceRestart = false)
			{
				this.IsForceRestarting = IsForceRestart;
				object lockState = this.LockState;
				ObjectFlowControl.CheckForSyncLockOnValueType(lockState);
				lock (lockState)
				{
					if (base.State == ModBase.LoadState.Loading)
					{
						return;
					}
					base.State = ModBase.LoadState.Loading;
				}
				this.Input = Conversions.ToGenericParameter<InputType>(Input);
				if (IsForceRestart)
				{
					try
					{
						foreach (ModLoader.LoaderBase loaderBase in this.Loaders)
						{
							loaderBase.State = ModBase.LoadState.Waiting;
						}
					}
					finally
					{
						List<ModLoader.LoaderBase>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
				}
				this.Update();
			}

			// Token: 0x06000882 RID: 2178 RVA: 0x00039350 File Offset: 0x00037550
			public override void Abort()
			{
				object lockState = this.LockState;
				ObjectFlowControl.CheckForSyncLockOnValueType(lockState);
				lock (lockState)
				{
					if (base.State != ModBase.LoadState.Loading && base.State != ModBase.LoadState.Waiting)
					{
						return;
					}
					base.State = ModBase.LoadState.Aborted;
				}
				ModBase.RunInThread(delegate
				{
					try
					{
						foreach (ModLoader.LoaderBase loaderBase in this.Loaders)
						{
							loaderBase.Abort();
						}
					}
					finally
					{
						List<ModLoader.LoaderBase>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
					object loaderTaskbarLock = ModLoader.LoaderTaskbarLock;
					ObjectFlowControl.CheckForSyncLockOnValueType(loaderTaskbarLock);
					lock (loaderTaskbarLock)
					{
						if (ModLoader.LoaderTaskbar.Contains(this))
						{
							ModLoader.LoaderTaskbar.Remove(this);
						}
					}
				});
			}

			// Token: 0x06000883 RID: 2179 RVA: 0x000393BC File Offset: 0x000375BC
			private void SubTaskStateChanged(ModLoader.LoaderBase Loader, ModBase.LoadState NewState, ModBase.LoadState OldState)
			{
				switch (NewState)
				{
				case ModBase.LoadState.Waiting:
				case ModBase.LoadState.Loading:
					return;
				case ModBase.LoadState.Finished:
					this.Update();
					return;
				case ModBase.LoadState.Aborted:
					this.Abort();
					return;
				}
				object lockState = this.LockState;
				ObjectFlowControl.CheckForSyncLockOnValueType(lockState);
				lock (lockState)
				{
					if (base.State >= ModBase.LoadState.Finished)
					{
						return;
					}
					base.Error = new Exception(Loader.Name + "失败", Loader.Error);
					base.State = Loader.State;
				}
				try
				{
					List<ModLoader.LoaderBase>.Enumerator enumerator = this.Loaders.GetEnumerator();
					while (enumerator.MoveNext())
					{
						Loader = enumerator.Current;
						Loader.Abort();
					}
				}
				finally
				{
					List<ModLoader.LoaderBase>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				ModMain.m_CollectionAccount.BtnExtraDownload.ShowRefresh();
			}

			// Token: 0x06000884 RID: 2180 RVA: 0x000394B4 File Offset: 0x000376B4
			private void Update()
			{
				if (base.State != ModBase.LoadState.Finished && base.State != ModBase.LoadState.Failed && base.State != ModBase.LoadState.Aborted)
				{
					bool flag = true;
					bool flag2 = false;
					object obj = this.Input;
					try
					{
						foreach (ModLoader.LoaderBase loaderBase in this.Loaders)
						{
							ModBase.LoadState state = loaderBase.State;
							if (state != ModBase.LoadState.Loading)
							{
								if (state == ModBase.LoadState.Finished)
								{
									if (loaderBase.GetType().Name.StartsWith("LoaderTask"))
									{
										object instance = loaderBase;
										Type type = null;
										string memberName = "ShouldStart";
										object[] array = new object[1];
										int num = 0;
										if (obj == null)
										{
											goto IL_B4;
										}
										if (loaderBase.GetType().GenericTypeArguments.First<Type>() != obj.GetType())
										{
											goto IL_B4;
										}
										object obj2 = obj;
										IL_B5:
										array[num] = obj2;
										if (!Conversions.ToBoolean(NewLateBinding.LateGet(instance, type, memberName, array, null, null, null)))
										{
											obj = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(loaderBase, null, "Output", new object[0], null, null, null));
											continue;
										}
										if (ModBase._EventState)
										{
											ModBase.Log("[Loader] 由于输入条件变更，重启加载器 " + loaderBase.Name, ModBase.LogLevel.Normal, "出现错误");
											goto IL_10B;
										}
										goto IL_10B;
										IL_B4:
										obj2 = null;
										goto IL_B5;
									}
									continue;
								}
								IL_10B:
								flag = false;
								if (!flag2)
								{
									if (obj != null)
									{
										string name = loaderBase.GetType().Name;
										if (!name.StartsWith("LoaderTask") && !name.StartsWith("LoaderCombo"))
										{
											if (!name.StartsWith("LoaderDownload"))
											{
												throw new Exception("未知的加载器类型（" + name + "）");
											}
											loaderBase.Start(RuntimeHelpers.GetObjectValue((obj is List<ModNet.NetFile>) ? obj : null), this.IsForceRestarting);
										}
										else
										{
											loaderBase.Start(RuntimeHelpers.GetObjectValue((loaderBase.GetType().GenericTypeArguments.First<Type>() == obj.GetType()) ? obj : null), this.IsForceRestarting);
										}
									}
									else
									{
										loaderBase.Start(null, this.IsForceRestarting);
									}
									if (loaderBase.Block)
									{
										flag2 = true;
									}
								}
							}
							else
							{
								flag = false;
								flag2 = true;
							}
						}
					}
					finally
					{
						List<ModLoader.LoaderBase>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
					if (flag)
					{
						base.RaisePreviewFinish();
						base.State = ModBase.LoadState.Finished;
						ModMain.m_CollectionAccount.BtnExtraDownload.ShowRefresh();
					}
				}
			}

			// Token: 0x06000885 RID: 2181 RVA: 0x000396F4 File Offset: 0x000378F4
			public static void GetLoaderList(object Loader, ref List<ModLoader.LoaderBase> List, bool RequireShow = true)
			{
				try
				{
					foreach (object obj in ((IEnumerable)NewLateBinding.LateGet(Loader, null, "Loaders", new object[0], null, null, null)))
					{
						object objectValue = RuntimeHelpers.GetObjectValue(obj);
						if (Conversions.ToBoolean(Conversions.ToBoolean(NewLateBinding.LateGet(objectValue, null, "Show", new object[0], null, null, null)) || !RequireShow))
						{
							List.Add((ModLoader.LoaderBase)objectValue);
						}
						if (objectValue.GetType().Name.StartsWith("LoaderCombo"))
						{
							ModLoader.LoaderCombo<InputType>.GetLoaderList(RuntimeHelpers.GetObjectValue(objectValue), ref List, true);
						}
					}
				}
				finally
				{
					IEnumerator enumerator;
					if (enumerator is IDisposable)
					{
						(enumerator as IDisposable).Dispose();
					}
				}
			}

			// Token: 0x06000886 RID: 2182 RVA: 0x000064E7 File Offset: 0x000046E7
			public void GetLoaderList(ref List<ModLoader.LoaderBase> List, bool RequireShow = true)
			{
				ModLoader.LoaderCombo<InputType>.GetLoaderList(this, ref List, RequireShow);
			}

			// Token: 0x06000887 RID: 2183 RVA: 0x000397C0 File Offset: 0x000379C0
			public List<ModLoader.LoaderBase> GetLoaderList(bool RequireShow = true)
			{
				List<ModLoader.LoaderBase> result = new List<ModLoader.LoaderBase>();
				this.GetLoaderList(ref result, RequireShow);
				return result;
			}

			// Token: 0x040003DB RID: 987
			public List<ModLoader.LoaderBase> Loaders;

			// Token: 0x040003DC RID: 988
			public InputType Input;
		}

		// Token: 0x020000D0 RID: 208
		private struct LoaderFolderDictionaryEntry
		{
			// Token: 0x0600088A RID: 2186 RVA: 0x00039878 File Offset: 0x00037A78
			public override bool Equals(object obj)
			{
				bool result;
				if (!(obj is ModLoader.LoaderFolderDictionaryEntry))
				{
					result = false;
				}
				else
				{
					ModLoader.LoaderFolderDictionaryEntry loaderFolderDictionaryEntry = (ModLoader.LoaderFolderDictionaryEntry)obj;
					result = (EqualityComparer<DateTime?>.Default.Equals(this.LastCheckTime, loaderFolderDictionaryEntry.LastCheckTime) && Operators.CompareString(this.FolderPath, loaderFolderDictionaryEntry.FolderPath, true) == 0);
				}
				return result;
			}

			// Token: 0x040003DD RID: 989
			public DateTime? LastCheckTime;

			// Token: 0x040003DE RID: 990
			public string FolderPath;
		}

		// Token: 0x020000D1 RID: 209
		public enum LoaderFolderRunType
		{
			// Token: 0x040003E0 RID: 992
			RunOnUpdated,
			// Token: 0x040003E1 RID: 993
			ForceRun,
			// Token: 0x040003E2 RID: 994
			UpdateOnly
		}
	}
}
