﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200015C RID: 348
	[DesignerGenerated]
	public class PageSetupSystem : MyPageRight, IComponentConnector
	{
		// Token: 0x06000EBB RID: 3771 RVA: 0x000092BC File Offset: 0x000074BC
		public PageSetupSystem()
		{
			base.Loaded += this.PageSetupSystem_Loaded;
			this._ExporterPrototype = false;
			this.m_QueuePrototype = false;
			this._GlobalPrototype = false;
			this.InitializeComponent();
		}

		// Token: 0x06000EBC RID: 3772 RVA: 0x000092F2 File Offset: 0x000074F2
		private void PageSetupSystem_Loaded(object sender, RoutedEventArgs e)
		{
			this.PanBack.ScrollToHome();
			checked
			{
				if (!this._ExporterPrototype)
				{
					this._ExporterPrototype = true;
					ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
					this.Reload();
					this.SliderLoad();
					ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
				}
			}
		}

		// Token: 0x06000EBD RID: 3773 RVA: 0x0006B460 File Offset: 0x00069660
		public void Reload()
		{
			this.SliderDownloadThread.Value = Conversions.ToInteger(ModBase._ParamsState.Get("ToolDownloadThread", null));
			this.SliderDownloadSpeed.Value = Conversions.ToInteger(ModBase._ParamsState.Get("ToolDownloadSpeed", null));
			this.ComboDownloadVersion.SelectedIndex = Conversions.ToInteger(ModBase._ParamsState.Get("ToolDownloadVersion", null));
			this.CheckUpdateRelease.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("ToolUpdateRelease", null));
			this.CheckUpdateSnapshot.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("ToolUpdateSnapshot", null));
			this.CheckHelpChinese.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("ToolHelpChinese", null));
			this.ComboSystemUpdate.SelectedIndex = Conversions.ToInteger(ModBase._ParamsState.Get("SystemSystemUpdate", null));
			this.ComboSystemActivity.SelectedIndex = Conversions.ToInteger(ModBase._ParamsState.Get("SystemSystemActivity", null));
			this.TextSystemCache.Text = Conversions.ToString(ModBase._ParamsState.Get("SystemSystemCache", null));
			this.CheckDebugMode.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("SystemDebugMode", null));
			this.SliderDebugAnim.Value = Conversions.ToInteger(ModBase._ParamsState.Get("SystemDebugAnim", null));
			this.CheckDebugDelay.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("SystemDebugDelay", null));
			this.CheckDebugSkipCopy.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("SystemDebugSkipCopy", null));
		}

		// Token: 0x06000EBE RID: 3774 RVA: 0x0006B610 File Offset: 0x00069810
		public void Reset()
		{
			try
			{
				ModBase._ParamsState.Reset("ToolDownloadThread", false, null);
				ModBase._ParamsState.Reset("ToolDownloadSpeed", false, null);
				ModBase._ParamsState.Reset("ToolDownloadVersion", false, null);
				ModBase._ParamsState.Reset("ToolUpdateRelease", false, null);
				ModBase._ParamsState.Reset("ToolUpdateSnapshot", false, null);
				ModBase._ParamsState.Reset("ToolHelpChinese", false, null);
				ModBase._ParamsState.Reset("SystemDebugMode", false, null);
				ModBase._ParamsState.Reset("SystemDebugAnim", false, null);
				ModBase._ParamsState.Reset("SystemDebugDelay", false, null);
				ModBase._ParamsState.Reset("SystemDebugSkipCopy", false, null);
				ModBase._ParamsState.Reset("SystemSystemCache", false, null);
				ModBase._ParamsState.Reset("SystemSystemUpdate", false, null);
				ModBase._ParamsState.Reset("SystemSystemActivity", false, null);
				ModBase.Log("[Setup] 已初始化启动器页设置", ModBase.LogLevel.Normal, "出现错误");
				ModMain.Hint("已初始化启动器页设置！", ModMain.HintType.Finish, false);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "初始化启动器页设置失败", ModBase.LogLevel.Msgbox, "出现错误");
			}
			this.Reload();
		}

		// Token: 0x06000EBF RID: 3775 RVA: 0x00008FBA File Offset: 0x000071BA
		private static void CheckBoxChange(MyCheckBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.Checked, false, null);
			}
		}

		// Token: 0x06000EC0 RID: 3776 RVA: 0x00008F64 File Offset: 0x00007164
		private static void SliderChange(MySlider sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.Value, false, null);
			}
		}

		// Token: 0x06000EC1 RID: 3777 RVA: 0x00008F8F File Offset: 0x0000718F
		private static void ComboChange(MyComboBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.SelectedIndex, false, null);
			}
		}

		// Token: 0x06000EC2 RID: 3778 RVA: 0x00008F3E File Offset: 0x0000713E
		private static void TextBoxChange(MyTextBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.Text, false, null);
			}
		}

		// Token: 0x06000EC3 RID: 3779 RVA: 0x0006B750 File Offset: 0x00069950
		private void SliderLoad()
		{
			this.SliderDownloadThread.merchantRequest = ((PageSetupSystem._Closure$__.$I9-0 == null) ? (PageSetupSystem._Closure$__.$I9-0 = ((int Value) => checked(Value + 1))) : PageSetupSystem._Closure$__.$I9-0);
			this.SliderDownloadSpeed.merchantRequest = ((PageSetupSystem._Closure$__.$I9-1 == null) ? (PageSetupSystem._Closure$__.$I9-1 = delegate(int Value)
			{
				string result;
				if (Value <= 14)
				{
					result = Conversions.ToString((double)(checked(Value + 1)) * 0.1) + " M/s";
				}
				else if (Value <= 31)
				{
					result = Conversions.ToString((double)(checked(Value - 11)) * 0.5) + " M/s";
				}
				else if (Value <= 41)
				{
					result = Conversions.ToString(checked(Value - 21)) + " M/s";
				}
				else
				{
					result = "无限制";
				}
				return result;
			}) : PageSetupSystem._Closure$__.$I9-1);
			this.SliderDebugAnim.merchantRequest = ((PageSetupSystem._Closure$__.$I9-2 == null) ? (PageSetupSystem._Closure$__.$I9-2 = delegate(int Value)
			{
				if (Value <= 29)
				{
					return Conversions.ToString((double)Value / 10.0 + 0.1) + "x";
				}
				return "关闭";
			}) : PageSetupSystem._Closure$__.$I9-2);
		}

		// Token: 0x06000EC4 RID: 3780 RVA: 0x0006B7EC File Offset: 0x000699EC
		private void SliderDownloadThread_PreviewChange(object sender, ModBase.RouteEventArgs e)
		{
			if (this.SliderDownloadThread.Value >= 100 && Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("HintDownloadThread", null))))
			{
				ModBase._ParamsState.Set("HintDownloadThread", true, false, null);
				ModMain.MyMsgBox("如果设置过多的下载线程，可能会导致下载时出现非常严重的卡顿。\r\n一般设置 64 线程即可满足大多数下载需求，除非你知道你在干什么，否则不建议设置更多的线程数！", "警告", "我知道了", "", "", true, true, false);
			}
		}

		// Token: 0x06000EC5 RID: 3781 RVA: 0x00009332 File Offset: 0x00007532
		private void CheckDebugMode_Change()
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModMain.Hint("部分调试信息将在刷新或启动器重启后切换显示！", ModMain.HintType.Info, false);
			}
		}

		// Token: 0x06000EC6 RID: 3782 RVA: 0x0006B860 File Offset: 0x00069A60
		private void BtnSystemCacheClear_Click(object sender, EventArgs e)
		{
			if (ModNet.HasDownloadingTask(false))
			{
				ModMain.Hint("请在所有下载任务完成后再清理缓存！", ModMain.HintType.Critical, true);
				return;
			}
			if (ModMain.MyMsgBox("你确定要清理缓存吗？\r\n在清理缓存后，PCL2 会被强制关闭，以避免缓存缺失带来的异常。", "清理缓存", "确定", "取消", "", false, true, false) != 2 && !this.m_QueuePrototype)
			{
				this.m_QueuePrototype = true;
				try
				{
					ulong num = this.DeleteCacheDirectory(ModBase.attributeState, 0UL);
					if (decimal.Compare(new decimal(num), 0m) <= 0)
					{
						ModMain.Hint("没有可清理的缓存！", ModMain.HintType.Info, true);
					}
					else
					{
						ModMain.MyMsgBox("已清理 " + ModBase.GetString(checked((long)num)) + " 缓存！\r\nPCL2 即将自动关闭。", "缓存已清理", "确定", "", "", false, true, true);
						ModMain.m_CollectionAccount.EndProgram(false);
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "清理缓存失败", ModBase.LogLevel.Hint, "出现错误");
				}
				finally
				{
					this.m_QueuePrototype = false;
				}
			}
		}

		// Token: 0x06000EC7 RID: 3783 RVA: 0x0006B974 File Offset: 0x00069B74
		private ulong DeleteCacheDirectory(string Path, ulong TotalSize = 0UL)
		{
			checked
			{
				ulong result;
				if (!Directory.Exists(Path))
				{
					result = TotalSize;
				}
				else
				{
					foreach (string text in Directory.GetFiles(Path))
					{
						try
						{
							FileInfo fileInfo = new FileInfo(text);
							double num = unchecked(Math.Ceiling((double)fileInfo.Length / 4096.0) * 4096.0);
							fileInfo.Delete();
							TotalSize = (ulong)Math.Round(unchecked(TotalSize + num));
						}
						catch (Exception ex)
						{
							ModBase.Log(ex, "删除失败的缓存文件（" + text + "）", ModBase.LogLevel.Debug, "出现错误");
						}
					}
					foreach (string path in Directory.GetDirectories(Path))
					{
						TotalSize += this.DeleteCacheDirectory(path, 0UL);
					}
					result = TotalSize;
				}
				return result;
			}
		}

		// Token: 0x06000EC8 RID: 3784 RVA: 0x0006BA5C File Offset: 0x00069C5C
		private void ComboSystemActivity_SizeChanged(object sender, SelectionChangedEventArgs e)
		{
			if (ModAnimation.DefineModel() == 0 && this.ComboSystemActivity.SelectedIndex == 2 && ModMain.MyMsgBox("若选择此项，即使在将来出现严重问题时，你也无法获取相关通知。\r\n例如，如果发现某个版本游戏存在严重 Bug，你可能就会因为无法得到通知而导致无法预知的后果。\r\n\r\n一般选择 仅在有重要通知时显示公告 就可以让你尽量不受打扰了。\r\n除非你在制作服务器整合包，或时常手动更新启动器，否则极度不推荐选择此项！", "警告", "继续", "取消", "", false, true, false) == 2)
			{
				this.ComboSystemActivity.SelectedItem = RuntimeHelpers.GetObjectValue(e.RemovedItems[0]);
			}
		}

		// Token: 0x06000EC9 RID: 3785 RVA: 0x0006BAC0 File Offset: 0x00069CC0
		private void ComboSystemUpdate_SizeChanged(object sender, SelectionChangedEventArgs e)
		{
			if (ModAnimation.DefineModel() == 0 && this.ComboSystemUpdate.SelectedIndex == 3 && ModMain.MyMsgBox("若选择此项，即使在启动器将来出现严重问题时，你也无法获取更新并获得修复。\r\n例如，如果官方修改了登录方式，从而导致现有启动器无法登录，你可能就会因为无法更新而无法开始游戏。\r\n\r\n一般选择 仅在有重大漏洞更新时显示提示 就可以让你尽量不受打扰了。\r\n除非你在制作服务器整合包，或时常手动更新启动器，否则极度不推荐选择此项！", "警告", "继续", "取消", "", false, true, false) == 2)
			{
				this.ComboSystemUpdate.SelectedItem = RuntimeHelpers.GetObjectValue(e.RemovedItems[0]);
			}
		}

		// Token: 0x06000ECA RID: 3786 RVA: 0x00009347 File Offset: 0x00007547
		private void BtnSystemUpdate_Click(object sender, EventArgs e)
		{
			if (!this._GlobalPrototype)
			{
				this._GlobalPrototype = true;
				ModBase.RunInThread(delegate
				{
					try
					{
						bool? flag = PageSetupSystem.IsLauncherNewest();
						if (flag == null)
						{
							ModMain.Hint("连接 PCL2 服务器失败，请确认系统时间与北京时间一致，或尝试关闭杀毒软件，然后重启 PCL2 再试！", ModMain.HintType.Critical, true);
						}
						else if (flag.GetValueOrDefault())
						{
							ModMain.Hint("当前启动器已为最新版！", ModMain.HintType.Finish, true);
						}
						else
						{
							ModMain.Hint("正在检查更新，请稍候！", ModMain.HintType.Info, true);
							if (ModMain.MyMsgBox("发现了启动器更新，是否下载？", "启动器更新", "确定", "取消", "", false, true, false) != 2)
							{
								ModMain.UpdateStart("http://pcl2-server-1253424809.file.myqcloud.com/update/{KEY}.zip{CDN}", false, null, false);
							}
						}
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "尝试手动开始更新失败", ModBase.LogLevel.Feedback, "出现错误");
					}
					finally
					{
						this._GlobalPrototype = false;
					}
				});
			}
		}

		// Token: 0x06000ECB RID: 3787 RVA: 0x0006BB24 File Offset: 0x00069D24
		public static bool? IsLauncherNewest()
		{
			bool? result;
			try
			{
				string text = ModBase.ReadFile(ModBase.attributeState + "Cache\\Notice.cfg");
				if (text.Split(new char[]
				{
					'|'
				}).Count<string>() < 3)
				{
					result = null;
				}
				else
				{
					int num = Conversions.ToInteger(text.Split(new char[]
					{
						'|'
					})[2]);
					result = new bool?(num <= 246);
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "确认启动器更新失败", ModBase.LogLevel.Feedback, "出现错误");
				result = null;
			}
			return result;
		}

		// Token: 0x17000257 RID: 599
		// (get) Token: 0x06000ECC RID: 3788 RVA: 0x00009369 File Offset: 0x00007569
		// (set) Token: 0x06000ECD RID: 3789 RVA: 0x00009371 File Offset: 0x00007571
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x17000258 RID: 600
		// (get) Token: 0x06000ECE RID: 3790 RVA: 0x0000937A File Offset: 0x0000757A
		// (set) Token: 0x06000ECF RID: 3791 RVA: 0x00009382 File Offset: 0x00007582
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x17000259 RID: 601
		// (get) Token: 0x06000ED0 RID: 3792 RVA: 0x0000938B File Offset: 0x0000758B
		// (set) Token: 0x06000ED1 RID: 3793 RVA: 0x0006BBD0 File Offset: 0x00069DD0
		internal virtual MyComboBox ComboDownloadVersion
		{
			[CompilerGenerated]
			get
			{
				return this.annotationPrototype;
			}
			[CompilerGenerated]
			set
			{
				SelectionChangedEventHandler value2 = (PageSetupSystem._Closure$__.$IR30-1 == null) ? (PageSetupSystem._Closure$__.$IR30-1 = delegate(object sender, SelectionChangedEventArgs e)
				{
					PageSetupSystem.ComboChange((MyComboBox)sender, e);
				}) : PageSetupSystem._Closure$__.$IR30-1;
				MyComboBox myComboBox = this.annotationPrototype;
				if (myComboBox != null)
				{
					myComboBox.SelectionChanged -= value2;
				}
				this.annotationPrototype = value;
				myComboBox = this.annotationPrototype;
				if (myComboBox != null)
				{
					myComboBox.SelectionChanged += value2;
				}
			}
		}

		// Token: 0x1700025A RID: 602
		// (get) Token: 0x06000ED2 RID: 3794 RVA: 0x00009393 File Offset: 0x00007593
		// (set) Token: 0x06000ED3 RID: 3795 RVA: 0x0006BC2C File Offset: 0x00069E2C
		internal virtual MySlider SliderDownloadThread
		{
			[CompilerGenerated]
			get
			{
				return this.m_InterceptorPrototype;
			}
			[CompilerGenerated]
			set
			{
				MySlider.ChangeEventHandler obj = (PageSetupSystem._Closure$__.$IR34-2 == null) ? (PageSetupSystem._Closure$__.$IR34-2 = delegate(object a0, bool a1)
				{
					PageSetupSystem.SliderChange((MySlider)a0, a1);
				}) : PageSetupSystem._Closure$__.$IR34-2;
				MySlider.PreviewChangeEventHandler obj2 = new MySlider.PreviewChangeEventHandler(this.SliderDownloadThread_PreviewChange);
				MySlider interceptorPrototype = this.m_InterceptorPrototype;
				if (interceptorPrototype != null)
				{
					interceptorPrototype.ViewTag(obj);
					interceptorPrototype.RemoveTag(obj2);
				}
				this.m_InterceptorPrototype = value;
				interceptorPrototype = this.m_InterceptorPrototype;
				if (interceptorPrototype != null)
				{
					interceptorPrototype.UpdateTag(obj);
					interceptorPrototype.InstantiateTag(obj2);
				}
			}
		}

		// Token: 0x1700025B RID: 603
		// (get) Token: 0x06000ED4 RID: 3796 RVA: 0x0000939B File Offset: 0x0000759B
		// (set) Token: 0x06000ED5 RID: 3797 RVA: 0x0006BCA4 File Offset: 0x00069EA4
		internal virtual MySlider SliderDownloadSpeed
		{
			[CompilerGenerated]
			get
			{
				return this.refPrototype;
			}
			[CompilerGenerated]
			set
			{
				MySlider.ChangeEventHandler obj = (PageSetupSystem._Closure$__.$IR38-3 == null) ? (PageSetupSystem._Closure$__.$IR38-3 = delegate(object a0, bool a1)
				{
					PageSetupSystem.SliderChange((MySlider)a0, a1);
				}) : PageSetupSystem._Closure$__.$IR38-3;
				MySlider mySlider = this.refPrototype;
				if (mySlider != null)
				{
					mySlider.ViewTag(obj);
				}
				this.refPrototype = value;
				mySlider = this.refPrototype;
				if (mySlider != null)
				{
					mySlider.UpdateTag(obj);
				}
			}
		}

		// Token: 0x1700025C RID: 604
		// (get) Token: 0x06000ED6 RID: 3798 RVA: 0x000093A3 File Offset: 0x000075A3
		// (set) Token: 0x06000ED7 RID: 3799 RVA: 0x0006BD00 File Offset: 0x00069F00
		internal virtual MyCheckBox CheckUpdateRelease
		{
			[CompilerGenerated]
			get
			{
				return this.m_ServerPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupSystem._Closure$__.$IR42-4 == null) ? (PageSetupSystem._Closure$__.$IR42-4 = delegate(object a0, bool a1)
				{
					PageSetupSystem.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupSystem._Closure$__.$IR42-4;
				MyCheckBox serverPrototype = this.m_ServerPrototype;
				if (serverPrototype != null)
				{
					serverPrototype.StopTag(obj);
				}
				this.m_ServerPrototype = value;
				serverPrototype = this.m_ServerPrototype;
				if (serverPrototype != null)
				{
					serverPrototype.CloneTag(obj);
				}
			}
		}

		// Token: 0x1700025D RID: 605
		// (get) Token: 0x06000ED8 RID: 3800 RVA: 0x000093AB File Offset: 0x000075AB
		// (set) Token: 0x06000ED9 RID: 3801 RVA: 0x0006BD5C File Offset: 0x00069F5C
		internal virtual MyCheckBox CheckUpdateSnapshot
		{
			[CompilerGenerated]
			get
			{
				return this._ServicePrototype;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupSystem._Closure$__.$IR46-5 == null) ? (PageSetupSystem._Closure$__.$IR46-5 = delegate(object a0, bool a1)
				{
					PageSetupSystem.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupSystem._Closure$__.$IR46-5;
				MyCheckBox servicePrototype = this._ServicePrototype;
				if (servicePrototype != null)
				{
					servicePrototype.StopTag(obj);
				}
				this._ServicePrototype = value;
				servicePrototype = this._ServicePrototype;
				if (servicePrototype != null)
				{
					servicePrototype.CloneTag(obj);
				}
			}
		}

		// Token: 0x1700025E RID: 606
		// (get) Token: 0x06000EDA RID: 3802 RVA: 0x000093B3 File Offset: 0x000075B3
		// (set) Token: 0x06000EDB RID: 3803 RVA: 0x0006BDB8 File Offset: 0x00069FB8
		internal virtual MyCheckBox CheckHelpChinese
		{
			[CompilerGenerated]
			get
			{
				return this._ImporterPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupSystem._Closure$__.$IR50-6 == null) ? (PageSetupSystem._Closure$__.$IR50-6 = delegate(object a0, bool a1)
				{
					PageSetupSystem.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupSystem._Closure$__.$IR50-6;
				MyCheckBox importerPrototype = this._ImporterPrototype;
				if (importerPrototype != null)
				{
					importerPrototype.StopTag(obj);
				}
				this._ImporterPrototype = value;
				importerPrototype = this._ImporterPrototype;
				if (importerPrototype != null)
				{
					importerPrototype.CloneTag(obj);
				}
			}
		}

		// Token: 0x1700025F RID: 607
		// (get) Token: 0x06000EDC RID: 3804 RVA: 0x000093BB File Offset: 0x000075BB
		// (set) Token: 0x06000EDD RID: 3805 RVA: 0x0006BE14 File Offset: 0x0006A014
		internal virtual MyComboBox ComboSystemUpdate
		{
			[CompilerGenerated]
			get
			{
				return this.proxyPrototype;
			}
			[CompilerGenerated]
			set
			{
				SelectionChangedEventHandler value2 = (PageSetupSystem._Closure$__.$IR54-7 == null) ? (PageSetupSystem._Closure$__.$IR54-7 = delegate(object sender, SelectionChangedEventArgs e)
				{
					PageSetupSystem.ComboChange((MyComboBox)sender, e);
				}) : PageSetupSystem._Closure$__.$IR54-7;
				SelectionChangedEventHandler value3 = new SelectionChangedEventHandler(this.ComboSystemUpdate_SizeChanged);
				MyComboBox myComboBox = this.proxyPrototype;
				if (myComboBox != null)
				{
					myComboBox.SelectionChanged -= value2;
					myComboBox.SelectionChanged -= value3;
				}
				this.proxyPrototype = value;
				myComboBox = this.proxyPrototype;
				if (myComboBox != null)
				{
					myComboBox.SelectionChanged += value2;
					myComboBox.SelectionChanged += value3;
				}
			}
		}

		// Token: 0x17000260 RID: 608
		// (get) Token: 0x06000EDE RID: 3806 RVA: 0x000093C3 File Offset: 0x000075C3
		// (set) Token: 0x06000EDF RID: 3807 RVA: 0x000093CB File Offset: 0x000075CB
		internal virtual MyComboBoxItem ItemSystemUpdateDownload { get; set; }

		// Token: 0x17000261 RID: 609
		// (get) Token: 0x06000EE0 RID: 3808 RVA: 0x000093D4 File Offset: 0x000075D4
		// (set) Token: 0x06000EE1 RID: 3809 RVA: 0x0006BE8C File Offset: 0x0006A08C
		internal virtual MyComboBox ComboSystemActivity
		{
			[CompilerGenerated]
			get
			{
				return this.m_RegistryPrototype;
			}
			[CompilerGenerated]
			set
			{
				SelectionChangedEventHandler value2 = (PageSetupSystem._Closure$__.$IR62-8 == null) ? (PageSetupSystem._Closure$__.$IR62-8 = delegate(object sender, SelectionChangedEventArgs e)
				{
					PageSetupSystem.ComboChange((MyComboBox)sender, e);
				}) : PageSetupSystem._Closure$__.$IR62-8;
				SelectionChangedEventHandler value3 = new SelectionChangedEventHandler(this.ComboSystemActivity_SizeChanged);
				MyComboBox registryPrototype = this.m_RegistryPrototype;
				if (registryPrototype != null)
				{
					registryPrototype.SelectionChanged -= value2;
					registryPrototype.SelectionChanged -= value3;
				}
				this.m_RegistryPrototype = value;
				registryPrototype = this.m_RegistryPrototype;
				if (registryPrototype != null)
				{
					registryPrototype.SelectionChanged += value2;
					registryPrototype.SelectionChanged += value3;
				}
			}
		}

		// Token: 0x17000262 RID: 610
		// (get) Token: 0x06000EE2 RID: 3810 RVA: 0x000093DC File Offset: 0x000075DC
		// (set) Token: 0x06000EE3 RID: 3811 RVA: 0x0006BF04 File Offset: 0x0006A104
		internal virtual MyTextBox TextSystemCache
		{
			[CompilerGenerated]
			get
			{
				return this.m_ProducerPrototype;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageSetupSystem._Closure$__.$IR66-9 == null) ? (PageSetupSystem._Closure$__.$IR66-9 = delegate(object sender, RoutedEventArgs e)
				{
					PageSetupSystem.TextBoxChange((MyTextBox)sender, e);
				}) : PageSetupSystem._Closure$__.$IR66-9;
				MyTextBox producerPrototype = this.m_ProducerPrototype;
				if (producerPrototype != null)
				{
					producerPrototype.FindRepository(value2);
				}
				this.m_ProducerPrototype = value;
				producerPrototype = this.m_ProducerPrototype;
				if (producerPrototype != null)
				{
					producerPrototype.SetupRepository(value2);
				}
			}
		}

		// Token: 0x17000263 RID: 611
		// (get) Token: 0x06000EE4 RID: 3812 RVA: 0x000093E4 File Offset: 0x000075E4
		// (set) Token: 0x06000EE5 RID: 3813 RVA: 0x0006BF60 File Offset: 0x0006A160
		internal virtual MyButton BtnSystemUpdate
		{
			[CompilerGenerated]
			get
			{
				return this.candidatePrototype;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnSystemUpdate_Click);
				MyButton myButton = this.candidatePrototype;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.candidatePrototype = value;
				myButton = this.candidatePrototype;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000264 RID: 612
		// (get) Token: 0x06000EE6 RID: 3814 RVA: 0x000093EC File Offset: 0x000075EC
		// (set) Token: 0x06000EE7 RID: 3815 RVA: 0x0006BFA4 File Offset: 0x0006A1A4
		internal virtual MyButton BtnSystemCacheClear
		{
			[CompilerGenerated]
			get
			{
				return this.setterPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnSystemCacheClear_Click);
				MyButton myButton = this.setterPrototype;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.setterPrototype = value;
				myButton = this.setterPrototype;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000265 RID: 613
		// (get) Token: 0x06000EE8 RID: 3816 RVA: 0x000093F4 File Offset: 0x000075F4
		// (set) Token: 0x06000EE9 RID: 3817 RVA: 0x000093FC File Offset: 0x000075FC
		internal virtual MyCard CardDebug { get; set; }

		// Token: 0x17000266 RID: 614
		// (get) Token: 0x06000EEA RID: 3818 RVA: 0x00009405 File Offset: 0x00007605
		// (set) Token: 0x06000EEB RID: 3819 RVA: 0x0000940D File Offset: 0x0000760D
		internal virtual Grid PanDebugAnim { get; set; }

		// Token: 0x17000267 RID: 615
		// (get) Token: 0x06000EEC RID: 3820 RVA: 0x00009416 File Offset: 0x00007616
		// (set) Token: 0x06000EED RID: 3821 RVA: 0x0006BFE8 File Offset: 0x0006A1E8
		internal virtual MySlider SliderDebugAnim
		{
			[CompilerGenerated]
			get
			{
				return this._MessagePrototype;
			}
			[CompilerGenerated]
			set
			{
				MySlider.ChangeEventHandler obj = (PageSetupSystem._Closure$__.$IR86-10 == null) ? (PageSetupSystem._Closure$__.$IR86-10 = delegate(object a0, bool a1)
				{
					PageSetupSystem.SliderChange((MySlider)a0, a1);
				}) : PageSetupSystem._Closure$__.$IR86-10;
				MySlider messagePrototype = this._MessagePrototype;
				if (messagePrototype != null)
				{
					messagePrototype.ViewTag(obj);
				}
				this._MessagePrototype = value;
				messagePrototype = this._MessagePrototype;
				if (messagePrototype != null)
				{
					messagePrototype.UpdateTag(obj);
				}
			}
		}

		// Token: 0x17000268 RID: 616
		// (get) Token: 0x06000EEE RID: 3822 RVA: 0x0000941E File Offset: 0x0000761E
		// (set) Token: 0x06000EEF RID: 3823 RVA: 0x0006C044 File Offset: 0x0006A244
		internal virtual MyCheckBox CheckDebugSkipCopy
		{
			[CompilerGenerated]
			get
			{
				return this.m_StatusPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupSystem._Closure$__.$IR90-11 == null) ? (PageSetupSystem._Closure$__.$IR90-11 = delegate(object a0, bool a1)
				{
					PageSetupSystem.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupSystem._Closure$__.$IR90-11;
				MyCheckBox statusPrototype = this.m_StatusPrototype;
				if (statusPrototype != null)
				{
					statusPrototype.StopTag(obj);
				}
				this.m_StatusPrototype = value;
				statusPrototype = this.m_StatusPrototype;
				if (statusPrototype != null)
				{
					statusPrototype.CloneTag(obj);
				}
			}
		}

		// Token: 0x17000269 RID: 617
		// (get) Token: 0x06000EF0 RID: 3824 RVA: 0x00009426 File Offset: 0x00007626
		// (set) Token: 0x06000EF1 RID: 3825 RVA: 0x0006C0A0 File Offset: 0x0006A2A0
		internal virtual MyCheckBox CheckDebugMode
		{
			[CompilerGenerated]
			get
			{
				return this._ProcPrototype;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupSystem._Closure$__.$IR94-12 == null) ? (PageSetupSystem._Closure$__.$IR94-12 = delegate(object a0, bool a1)
				{
					PageSetupSystem.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupSystem._Closure$__.$IR94-12;
				MyCheckBox.ChangeEventHandler obj2 = delegate(object a0, bool a1)
				{
					this.CheckDebugMode_Change();
				};
				MyCheckBox procPrototype = this._ProcPrototype;
				if (procPrototype != null)
				{
					procPrototype.StopTag(obj);
					procPrototype.StopTag(obj2);
				}
				this._ProcPrototype = value;
				procPrototype = this._ProcPrototype;
				if (procPrototype != null)
				{
					procPrototype.CloneTag(obj);
					procPrototype.CloneTag(obj2);
				}
			}
		}

		// Token: 0x1700026A RID: 618
		// (get) Token: 0x06000EF2 RID: 3826 RVA: 0x0000942E File Offset: 0x0000762E
		// (set) Token: 0x06000EF3 RID: 3827 RVA: 0x0006C118 File Offset: 0x0006A318
		internal virtual MyCheckBox CheckDebugDelay
		{
			[CompilerGenerated]
			get
			{
				return this.modelIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupSystem._Closure$__.$IR98-14 == null) ? (PageSetupSystem._Closure$__.$IR98-14 = delegate(object a0, bool a1)
				{
					PageSetupSystem.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupSystem._Closure$__.$IR98-14;
				MyCheckBox myCheckBox = this.modelIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.StopTag(obj);
				}
				this.modelIssuer = value;
				myCheckBox = this.modelIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.CloneTag(obj);
				}
			}
		}

		// Token: 0x06000EF4 RID: 3828 RVA: 0x0006C174 File Offset: 0x0006A374
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this._WrapperIssuer)
			{
				this._WrapperIssuer = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagesetup/pagesetupsystem.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000EF5 RID: 3829 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000EF6 RID: 3830 RVA: 0x0006C1A4 File Offset: 0x0006A3A4
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			if (connectionId == 3)
			{
				this.ComboDownloadVersion = (MyComboBox)target;
				return;
			}
			if (connectionId == 4)
			{
				this.SliderDownloadThread = (MySlider)target;
				return;
			}
			if (connectionId == 5)
			{
				this.SliderDownloadSpeed = (MySlider)target;
				return;
			}
			if (connectionId == 6)
			{
				this.CheckUpdateRelease = (MyCheckBox)target;
				return;
			}
			if (connectionId == 7)
			{
				this.CheckUpdateSnapshot = (MyCheckBox)target;
				return;
			}
			if (connectionId == 8)
			{
				this.CheckHelpChinese = (MyCheckBox)target;
				return;
			}
			if (connectionId == 9)
			{
				this.ComboSystemUpdate = (MyComboBox)target;
				return;
			}
			if (connectionId == 10)
			{
				this.ItemSystemUpdateDownload = (MyComboBoxItem)target;
				return;
			}
			if (connectionId == 11)
			{
				this.ComboSystemActivity = (MyComboBox)target;
				return;
			}
			if (connectionId == 12)
			{
				this.TextSystemCache = (MyTextBox)target;
				return;
			}
			if (connectionId == 13)
			{
				this.BtnSystemUpdate = (MyButton)target;
				return;
			}
			if (connectionId == 14)
			{
				this.BtnSystemCacheClear = (MyButton)target;
				return;
			}
			if (connectionId == 15)
			{
				this.CardDebug = (MyCard)target;
				return;
			}
			if (connectionId == 16)
			{
				this.PanDebugAnim = (Grid)target;
				return;
			}
			if (connectionId == 17)
			{
				this.SliderDebugAnim = (MySlider)target;
				return;
			}
			if (connectionId == 18)
			{
				this.CheckDebugSkipCopy = (MyCheckBox)target;
				return;
			}
			if (connectionId == 19)
			{
				this.CheckDebugMode = (MyCheckBox)target;
				return;
			}
			if (connectionId == 20)
			{
				this.CheckDebugDelay = (MyCheckBox)target;
				return;
			}
			this._WrapperIssuer = true;
		}

		// Token: 0x04000743 RID: 1859
		private bool _ExporterPrototype;

		// Token: 0x04000744 RID: 1860
		private bool m_QueuePrototype;

		// Token: 0x04000745 RID: 1861
		private bool _GlobalPrototype;

		// Token: 0x04000746 RID: 1862
		[CompilerGenerated]
		[AccessedThroughProperty("PanBack")]
		private MyScrollViewer listPrototype;

		// Token: 0x04000747 RID: 1863
		[CompilerGenerated]
		[AccessedThroughProperty("PanMain")]
		private StackPanel m_MethodPrototype;

		// Token: 0x04000748 RID: 1864
		[CompilerGenerated]
		[AccessedThroughProperty("ComboDownloadVersion")]
		private MyComboBox annotationPrototype;

		// Token: 0x04000749 RID: 1865
		[CompilerGenerated]
		[AccessedThroughProperty("SliderDownloadThread")]
		private MySlider m_InterceptorPrototype;

		// Token: 0x0400074A RID: 1866
		[AccessedThroughProperty("SliderDownloadSpeed")]
		[CompilerGenerated]
		private MySlider refPrototype;

		// Token: 0x0400074B RID: 1867
		[CompilerGenerated]
		[AccessedThroughProperty("CheckUpdateRelease")]
		private MyCheckBox m_ServerPrototype;

		// Token: 0x0400074C RID: 1868
		[CompilerGenerated]
		[AccessedThroughProperty("CheckUpdateSnapshot")]
		private MyCheckBox _ServicePrototype;

		// Token: 0x0400074D RID: 1869
		[AccessedThroughProperty("CheckHelpChinese")]
		[CompilerGenerated]
		private MyCheckBox _ImporterPrototype;

		// Token: 0x0400074E RID: 1870
		[CompilerGenerated]
		[AccessedThroughProperty("ComboSystemUpdate")]
		private MyComboBox proxyPrototype;

		// Token: 0x0400074F RID: 1871
		[AccessedThroughProperty("ItemSystemUpdateDownload")]
		[CompilerGenerated]
		private MyComboBoxItem m_ClassPrototype;

		// Token: 0x04000750 RID: 1872
		[CompilerGenerated]
		[AccessedThroughProperty("ComboSystemActivity")]
		private MyComboBox m_RegistryPrototype;

		// Token: 0x04000751 RID: 1873
		[CompilerGenerated]
		[AccessedThroughProperty("TextSystemCache")]
		private MyTextBox m_ProducerPrototype;

		// Token: 0x04000752 RID: 1874
		[CompilerGenerated]
		[AccessedThroughProperty("BtnSystemUpdate")]
		private MyButton candidatePrototype;

		// Token: 0x04000753 RID: 1875
		[AccessedThroughProperty("BtnSystemCacheClear")]
		[CompilerGenerated]
		private MyButton setterPrototype;

		// Token: 0x04000754 RID: 1876
		[CompilerGenerated]
		[AccessedThroughProperty("CardDebug")]
		private MyCard _MappingPrototype;

		// Token: 0x04000755 RID: 1877
		[CompilerGenerated]
		[AccessedThroughProperty("PanDebugAnim")]
		private Grid dispatcherPrototype;

		// Token: 0x04000756 RID: 1878
		[CompilerGenerated]
		[AccessedThroughProperty("SliderDebugAnim")]
		private MySlider _MessagePrototype;

		// Token: 0x04000757 RID: 1879
		[CompilerGenerated]
		[AccessedThroughProperty("CheckDebugSkipCopy")]
		private MyCheckBox m_StatusPrototype;

		// Token: 0x04000758 RID: 1880
		[CompilerGenerated]
		[AccessedThroughProperty("CheckDebugMode")]
		private MyCheckBox _ProcPrototype;

		// Token: 0x04000759 RID: 1881
		[AccessedThroughProperty("CheckDebugDelay")]
		[CompilerGenerated]
		private MyCheckBox modelIssuer;

		// Token: 0x0400075A RID: 1882
		private bool _WrapperIssuer;
	}
}
