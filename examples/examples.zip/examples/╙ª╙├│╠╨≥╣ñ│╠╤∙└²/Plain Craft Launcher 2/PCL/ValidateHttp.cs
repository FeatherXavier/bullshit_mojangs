﻿using System;
using System.Text.RegularExpressions;

namespace PCL
{
	// Token: 0x020000E5 RID: 229
	public class ValidateHttp : Validate
	{
		// Token: 0x060008FB RID: 2299 RVA: 0x0003F75C File Offset: 0x0003D95C
		public override string Validate(string Str)
		{
			if (Str.EndsWith("/"))
			{
				Str = Str.Substring(0, checked(Str.Length - 1));
			}
			string result;
			if (!ModBase.RegexCheck(Str, "^(http[s]?)\\://", RegexOptions.None))
			{
				result = "输入的网址无效！";
			}
			else
			{
				result = "";
			}
			return result;
		}
	}
}
