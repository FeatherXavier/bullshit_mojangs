﻿using System;
using Microsoft.VisualBasic;

namespace PCL
{
	// Token: 0x020000E2 RID: 226
	public class ValidateNullOrEmpty : Validate
	{
		// Token: 0x060008ED RID: 2285 RVA: 0x0003F6D8 File Offset: 0x0003D8D8
		public override string Validate(string Str)
		{
			string result;
			if (!Information.IsNothing(Str) && !string.IsNullOrEmpty(Str))
			{
				result = "";
			}
			else
			{
				result = "输入内容不能为空！";
			}
			return result;
		}
	}
}
