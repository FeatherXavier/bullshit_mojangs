﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Microsoft.VisualBasic.CompilerServices;
using Newtonsoft.Json.Linq;
using PCL.My;

namespace PCL
{
	// Token: 0x0200003D RID: 61
	[StandardModule]
	public sealed class ModModpack
	{
		// Token: 0x0600014E RID: 334 RVA: 0x00011884 File Offset: 0x0000FA84
		public static void ModpackInstall()
		{
			string File = ModBase.SelectFile("压缩包文件(*.rar;*.zip)|*.rar;*.zip", "选择整合包压缩文件");
			if (!string.IsNullOrEmpty(File))
			{
				ModBase.RunInThread(delegate
				{
					ModModpack.ModpackInstall(File, null, true);
				});
			}
		}

		// Token: 0x0600014F RID: 335 RVA: 0x000118CC File Offset: 0x0000FACC
		public static bool ModpackInstall(string File, string VersionName = null, bool ShowHint = true)
		{
			ModBase.Log("[ModPack] 整合包安装请求：" + (File ?? "null"), ModBase.LogLevel.Normal, "出现错误");
			ZipArchive zipArchive = null;
			string archiveBaseFolder = "";
			bool result;
			try
			{
				int num = -1;
				try
				{
					zipArchive = new ZipArchive(new FileStream(File, FileMode.Open));
					if (zipArchive.GetEntry("mcbbs.packmeta") != null)
					{
						num = 3;
					}
					else if (zipArchive.GetEntry("manifest.json") != null)
					{
						if (((JObject)ModBase.GetJson(ModBase.ReadFile(zipArchive.GetEntry("manifest.json").Open(), Encoding.UTF8)))["addons"] == null)
						{
							num = 0;
						}
						else
						{
							num = 3;
						}
					}
					else if (zipArchive.GetEntry("modpack.json") != null)
					{
						num = 1;
					}
					else if (zipArchive.GetEntry("mmc-pack.json") != null)
					{
						num = 2;
					}
					else
					{
						try
						{
							foreach (ZipArchiveEntry zipArchiveEntry in zipArchive.Entries)
							{
								string[] array = zipArchiveEntry.FullName.Split(new char[]
								{
									'/'
								});
								archiveBaseFolder = array[0] + "/";
								if (zipArchiveEntry.FullName.EndsWith("/versions/") && array.Count<string>() == 3)
								{
									num = 9;
									break;
								}
								if (array.Count<string>() == 2)
								{
									if (Operators.CompareString(array[1], "mcbbs.packmeta", true) == 0)
									{
										num = 3;
										break;
									}
									if (Operators.CompareString(array[1], "manifest.json", true) != 0)
									{
										if (Operators.CompareString(array[1], "modpack.json", true) == 0)
										{
											num = 1;
											break;
										}
										if (Operators.CompareString(array[1], "mmc-pack.json", true) == 0)
										{
											num = 2;
											break;
										}
									}
									else
									{
										if (((JObject)ModBase.GetJson(ModBase.ReadFile(zipArchiveEntry.Open(), Encoding.UTF8)))["addons"] == null)
										{
											num = 0;
											break;
										}
										num = 3;
										archiveBaseFolder = "overrides/";
										break;
									}
								}
							}
						}
						finally
						{
							IEnumerator<ZipArchiveEntry> enumerator;
							if (enumerator != null)
							{
								enumerator.Dispose();
							}
						}
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "打开整合包文件失败，文件可能损坏或为不支持的压缩包格式", ShowHint ? ModBase.LogLevel.Hint : ModBase.LogLevel.Normal, "出现错误");
					return false;
				}
				switch (num)
				{
				case 0:
					ModBase.Log("[ModPack] 整合包种类：CurseForge", ModBase.LogLevel.Normal, "出现错误");
					ModModpack.InstallPackCurseForge(File, zipArchive, archiveBaseFolder, VersionName);
					break;
				case 1:
					ModBase.Log("[ModPack] 整合包种类：HMCL", ModBase.LogLevel.Normal, "出现错误");
					ModModpack.InstallPackHMCL(File, zipArchive, archiveBaseFolder);
					break;
				case 2:
					ModBase.Log("[ModPack] 整合包种类：MMC", ModBase.LogLevel.Normal, "出现错误");
					ModModpack.InstallPackMMC(File, zipArchive, archiveBaseFolder);
					break;
				case 3:
					ModBase.Log("[ModPack] 整合包种类：MCBBS", ModBase.LogLevel.Normal, "出现错误");
					ModModpack.InstallPackMCBBS(File, zipArchive, archiveBaseFolder);
					break;
				default:
					if (num != 9)
					{
						if (ShowHint)
						{
							ModMain.Hint("未能识别该整合包的种类，无法安装！", ModMain.HintType.Critical, true);
						}
						else
						{
							ModBase.Log("[ModPack] 未能识别该整合包的种类，无法安装！", ModBase.LogLevel.Normal, "出现错误");
						}
						return false;
					}
					ModBase.Log("[ModPack] 整合包种类：压缩包", ModBase.LogLevel.Normal, "出现错误");
					zipArchive.Dispose();
					zipArchive = null;
					ModModpack.InstallPackCompress(File, archiveBaseFolder);
					break;
				}
				result = true;
			}
			catch (Exception ex2)
			{
				ModBase.Log(ex2, "准备安装整合包失败", ModBase.LogLevel.Feedback, "出现错误");
				result = false;
			}
			finally
			{
				if (zipArchive != null)
				{
					zipArchive.Dispose();
				}
			}
			return result;
		}

		// Token: 0x06000150 RID: 336 RVA: 0x00011C3C File Offset: 0x0000FE3C
		private static void UnpackFiles(string InstallTemp, string FileAddress)
		{
			if (!ModModpack.m_Creator)
			{
				ModModpack.m_Creator = true;
				ModModpack._Object = true;
				try
				{
					ModBase.Log("[ModPack] 开始清理整合包安装缓存", ModBase.LogLevel.Normal, "出现错误");
					ModBase.DeleteDirectory(ModBase.attributeState + "PackInstall\\", false);
					ModBase.Log("[ModPack] 已清理整合包安装缓存", ModBase.LogLevel.Normal, "出现错误");
					goto IL_87;
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "清理整合包安装缓存失败", ModBase.LogLevel.Debug, "出现错误");
					goto IL_87;
				}
				finally
				{
					ModModpack._Object = false;
				}
			}
			if (ModModpack._Object)
			{
				while (ModModpack._Object)
				{
					Thread.Sleep(1);
				}
			}
			IL_87:
			int num = 1;
			Encoding entryNameEncoding = Encoding.Default;
			checked
			{
				try
				{
					IL_8F:
					Directory.CreateDirectory(InstallTemp);
					ModBase.DeleteDirectory(InstallTemp, false);
					ZipFile.ExtractToDirectory(FileAddress, InstallTemp, entryNameEncoding);
				}
				catch (Exception ex2)
				{
					ModBase.Log(ex2, "第 " + Conversions.ToString(num) + " 次解压尝试失败", ModBase.LogLevel.Debug, "出现错误");
					if (ex2 is ArgumentException)
					{
						entryNameEncoding = Encoding.UTF8;
						ModBase.Log("[ModPack] 已切换压缩包解压编码为 UTF8", ModBase.LogLevel.Normal, "出现错误");
					}
					if (num >= 5)
					{
						throw;
					}
					Thread.Sleep(num * 2000);
					num++;
					goto IL_8F;
				}
			}
		}

		// Token: 0x06000151 RID: 337 RVA: 0x00011D7C File Offset: 0x0000FF7C
		private static ModLoader.LoaderCombo<string> InstallPackCurseForgeLoader(string FileAddress, ZipArchive Archive, string ArchiveBaseFolder, string VersionName)
		{
			ModModpack._Closure$__6-0 CS$<>8__locals1 = new ModModpack._Closure$__6-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Local_FileAddress = FileAddress;
			CS$<>8__locals1.$VB$Local_ArchiveBaseFolder = ArchiveBaseFolder;
			CS$<>8__locals1.$VB$Local_VersionName = VersionName;
			JObject jobject;
			try
			{
				jobject = (JObject)ModBase.GetJson(ModBase.ReadFile(Archive.GetEntry(CS$<>8__locals1.$VB$Local_ArchiveBaseFolder + "manifest.json").Open(), null));
				if (jobject["minecraft"] == null || jobject["minecraft"]["version"] == null)
				{
					throw new Exception("整合包未提供 Minecraft 版本信息");
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "整合包安装信息存在问题", ModBase.LogLevel.Hint, "出现错误");
				return null;
			}
			string advisorState = null;
			string singletonState = null;
			try
			{
				foreach (JToken jtoken in (jobject["minecraft"]["modLoaders"] ?? new byte[0]))
				{
					string text = (jtoken["id"] ?? "").ToString().ToLower();
					if (text.StartsWith("forge-"))
					{
						if (text.Contains("recommended"))
						{
							ModBase.Log("[ModPack] 该整合包版本过老，已不支持进行安装！", ModBase.LogLevel.Hint, "出现错误");
							return null;
						}
						try
						{
							ModBase.Log("[ModPack] 整合包 Forge 版本：" + text, ModBase.LogLevel.Normal, "出现错误");
							advisorState = text.Split(new char[]
							{
								'-'
							})[1];
							break;
						}
						catch (Exception ex2)
						{
							ModBase.Log(ex2, "读取整合包 Forge 版本失败：" + text, ModBase.LogLevel.Debug, "出现错误");
							continue;
						}
					}
					if (text.StartsWith("fabric-"))
					{
						try
						{
							ModBase.Log("[ModPack] 整合包 Fabric 版本：" + text, ModBase.LogLevel.Normal, "出现错误");
							singletonState = text.Split(new char[]
							{
								'-'
							})[1];
							break;
						}
						catch (Exception ex3)
						{
							ModBase.Log(ex3, "读取整合包 Fabric 版本失败：" + text, ModBase.LogLevel.Debug, "出现错误");
						}
					}
				}
			}
			finally
			{
				IEnumerator<JToken> enumerator;
				if (enumerator != null)
				{
					enumerator.Dispose();
				}
			}
			CS$<>8__locals1.$VB$Local_InstallTemp = ModBase.attributeState + "PackInstall\\" + Conversions.ToString(ModBase.RandomInteger(0, 100000)) + "\\";
			List<ModLoader.LoaderBase> list = new List<ModLoader.LoaderBase>();
			CS$<>8__locals1.$VB$Local_OverrideHome = (string)(jobject["overrides"] ?? "");
			if (Operators.CompareString(CS$<>8__locals1.$VB$Local_OverrideHome, "", true) != 0)
			{
				list.Add(new ModLoader.LoaderTask<string, int>("解压整合包文件", delegate(ModLoader.LoaderTask<string, int> Task)
				{
					ModModpack.UnpackFiles(CS$<>8__locals1.$VB$Local_InstallTemp, CS$<>8__locals1.$VB$Local_FileAddress);
					Task.Progress = 0.5;
					if (Directory.Exists(CS$<>8__locals1.$VB$Local_InstallTemp + CS$<>8__locals1.$VB$Local_ArchiveBaseFolder + CS$<>8__locals1.$VB$Local_OverrideHome))
					{
						MyWpfExtension.FindModel().FileSystem.CopyDirectory(CS$<>8__locals1.$VB$Local_InstallTemp + CS$<>8__locals1.$VB$Local_ArchiveBaseFolder + CS$<>8__locals1.$VB$Local_OverrideHome, ModMinecraft._MapperTag + "versions\\" + CS$<>8__locals1.$VB$Local_VersionName);
					}
					else
					{
						ModBase.Log("[ModPack] 整合包中未找到 override 目录，已跳过", ModBase.LogLevel.Normal, "出现错误");
					}
					Task.Progress = 0.9;
					ModBase.WriteIni(ModMinecraft._MapperTag + "versions\\" + CS$<>8__locals1.$VB$Local_VersionName + "\\PCL\\Setup.ini", "VersionArgumentIndie", Conversions.ToString(1));
				}, null, ThreadPriority.Normal)
				{
					ProgressWeight = (double)new FileInfo(CS$<>8__locals1.$VB$Local_FileAddress).Length / 1024.0 / 1024.0 / 6.0,
					Block = false
				});
			}
			CS$<>8__locals1.$VB$Local_ModFileList = new List<int>();
			try
			{
				foreach (JToken jtoken2 in (jobject["files"] ?? new byte[0]))
				{
					if (jtoken2["projectID"] != null && jtoken2["fileID"] != null)
					{
						if (jtoken2["required"] == null || jtoken2["required"].ToObject<bool>())
						{
							CS$<>8__locals1.$VB$Local_ModFileList.Add((int)jtoken2["fileID"]);
						}
					}
					else
					{
						ModMain.Hint("某项 Mod 缺少必要信息，已跳过：" + jtoken2.ToString(), ModMain.HintType.Info, true);
					}
				}
			}
			finally
			{
				IEnumerator<JToken> enumerator2;
				if (enumerator2 != null)
				{
					enumerator2.Dispose();
				}
			}
			if (CS$<>8__locals1.$VB$Local_ModFileList.Count > 0)
			{
				list.Add(new ModLoader.LoaderTask<int, JArray>("获取 Mod 下载信息", delegate(ModLoader.LoaderTask<int, JArray> Task)
				{
					Task.Output = (JArray)NewLateBinding.LateIndexGet(ModBase.GetJson(ModNet.NetRequestRetry("https://api.curseforge.com/v1/mods/files", "POST", "{\"fileIds\": [" + ModBase.Join(CS$<>8__locals1.$VB$Local_ModFileList, ",") + "]}", "application/json", true, null)), new object[]
					{
						"data"
					}, null);
				}, null, ThreadPriority.Normal)
				{
					ProgressWeight = (double)CS$<>8__locals1.$VB$Local_ModFileList.Count / 10.0
				});
				list.Add(new ModLoader.LoaderTask<JArray, List<ModNet.NetFile>>("构造 Mod 下载信息", delegate(ModLoader.LoaderTask<JArray, List<ModNet.NetFile>> Task)
				{
					List<ModNet.NetFile> list5 = new List<ModNet.NetFile>();
					try
					{
						foreach (JToken jtoken3 in Task.Input)
						{
							list5.Add(new ModDownload.DlCfFile((JObject)jtoken3, false).GetDownloadFile(ModMinecraft._MapperTag + "versions\\" + CS$<>8__locals1.$VB$Local_VersionName + "\\mods\\", false));
							Task.Progress += 1.0 / (double)(checked(1 + CS$<>8__locals1.$VB$Local_ModFileList.Count));
						}
					}
					finally
					{
						IEnumerator<JToken> enumerator5;
						if (enumerator5 != null)
						{
							enumerator5.Dispose();
						}
					}
					Task.Output = list5;
				}, null, ThreadPriority.Normal)
				{
					ProgressWeight = (double)CS$<>8__locals1.$VB$Local_ModFileList.Count / 200.0,
					Show = false
				});
				list.Add(new ModNet.LoaderDownload("下载 Mod", new List<ModNet.NetFile>())
				{
					ProgressWeight = (double)CS$<>8__locals1.$VB$Local_ModFileList.Count * 1.5
				});
			}
			ModDownloadLib.McInstallRequest request = new ModDownloadLib.McInstallRequest
			{
				_ConnectionState = CS$<>8__locals1.$VB$Local_VersionName,
				customerState = jobject["minecraft"]["version"].ToString(),
				_AdvisorState = advisorState,
				_SingletonState = singletonState
			};
			double num = 0.0;
			try
			{
				foreach (ModLoader.LoaderBase loaderBase in list)
				{
					num += loaderBase.ProgressWeight;
				}
			}
			finally
			{
				List<ModLoader.LoaderBase>.Enumerator enumerator3;
				((IDisposable)enumerator3).Dispose();
			}
			List<ModLoader.LoaderBase> list2 = ModDownloadLib.McInstallLoader(request, true);
			ModLoader.LoaderCombo<string> result;
			if (list2 == null)
			{
				result = null;
			}
			else
			{
				double num2 = 0.0;
				try
				{
					foreach (ModLoader.LoaderBase loaderBase2 in list2)
					{
						num2 += loaderBase2.ProgressWeight;
					}
				}
				finally
				{
					List<ModLoader.LoaderBase>.Enumerator enumerator4;
					((IDisposable)enumerator4).Dispose();
				}
				List<ModLoader.LoaderBase> list3 = new List<ModLoader.LoaderBase>();
				list3.Add(new ModLoader.LoaderTask<string, List<ModNet.NetFile>>("分析游戏支持库文件（副加载器）", delegate(ModLoader.LoaderTask<string, List<ModNet.NetFile>> Task)
				{
					Task.Output = ModMinecraft.McLibFix(new ModMinecraft.McVersion(CS$<>8__locals1.$VB$Local_VersionName), false);
				}, null, ThreadPriority.Normal)
				{
					ProgressWeight = 1.0,
					Show = false
				});
				list3.Add(new ModNet.LoaderDownload("下载游戏支持库文件（副加载器）", new List<ModNet.NetFile>())
				{
					ProgressWeight = 7.0,
					Show = false
				});
				List<ModLoader.LoaderBase> list4 = new List<ModLoader.LoaderBase>();
				list4.Add(new ModLoader.LoaderCombo<string>("整合包安装", list)
				{
					Show = false,
					Block = false,
					ProgressWeight = num
				});
				list4.Add(new ModLoader.LoaderCombo<string>("游戏安装", list2)
				{
					Show = false,
					ProgressWeight = num2
				});
				list4.Add(new ModLoader.LoaderCombo<string>("下载游戏支持库文件", list3)
				{
					ProgressWeight = 8.0
				});
				string text2 = "CurseForge 整合包安装：" + CS$<>8__locals1.$VB$Local_VersionName + " ";
				object loaderTaskbarLock = ModLoader.LoaderTaskbarLock;
				ObjectFlowControl.CheckForSyncLockOnValueType(loaderTaskbarLock);
				checked
				{
					lock (loaderTaskbarLock)
					{
						int num3 = ModLoader.LoaderTaskbar.Count - 1;
						for (int i = 0; i <= num3; i++)
						{
							if (Operators.CompareString(ModLoader.LoaderTaskbar[i].Name, text2, true) == 0)
							{
								ModMain.Hint("该整合包正在安装中！", ModMain.HintType.Critical, true);
								return null;
							}
						}
					}
					result = new ModLoader.LoaderCombo<string>(text2, list4)
					{
						OnStateChanged = new Action<ModLoader.LoaderBase>(ModDownloadLib.McInstallState)
					};
				}
			}
			return result;
		}

		// Token: 0x06000152 RID: 338 RVA: 0x00012504 File Offset: 0x00010704
		private static void InstallPackCurseForge(string FileAddress, ZipArchive Archive, string ArchiveBaseFolder, string VersionName = null)
		{
			bool flag = VersionName == null;
			if (VersionName == null)
			{
				JObject jobject;
				try
				{
					jobject = (JObject)ModBase.GetJson(ModBase.ReadFile(Archive.GetEntry(ArchiveBaseFolder + "manifest.json").Open(), null));
					if (jobject["minecraft"] == null || jobject["minecraft"]["version"] == null)
					{
						throw new Exception("整合包未提供 Minecraft 版本信息");
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "整合包安装信息存在问题", ModBase.LogLevel.Hint, "出现错误");
					return;
				}
				string text = (string)(jobject["name"] ?? "");
				ValidateFolderName validateFolderName = new ValidateFolderName(ModMinecraft._MapperTag + "versions", true, true);
				if (Operators.CompareString(validateFolderName.Validate(text), "", true) != 0)
				{
					text = "";
				}
				VersionName = ModMain.MyMsgBoxInput(text, new Collection<Validate>
				{
					validateFolderName
				}, "", "输入版本名", "确定", "取消", false);
				if (string.IsNullOrEmpty(VersionName))
				{
					return;
				}
			}
			ModLoader.LoaderCombo<string> loaderCombo = ModModpack.InstallPackCurseForgeLoader(FileAddress, Archive, ArchiveBaseFolder, VersionName);
			if (loaderCombo != null)
			{
				loaderCombo.Start(ModMinecraft._MapperTag + "versions\\" + VersionName + "\\", false);
				ModLoader.LoaderTaskbarAdd(loaderCombo);
				ModMain.m_CollectionAccount.BtnExtraDownload.ShowRefresh();
				if (flag)
				{
					ModMain.m_CollectionAccount.BtnExtraDownload.Ribble();
				}
			}
		}

		// Token: 0x06000153 RID: 339 RVA: 0x0001267C File Offset: 0x0001087C
		private static void InstallPackHMCL(string FileAddress, ZipArchive Archive, string ArchiveBaseFolder)
		{
			ModModpack._Closure$__8-0 CS$<>8__locals1 = new ModModpack._Closure$__8-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Local_FileAddress = FileAddress;
			CS$<>8__locals1.$VB$Local_ArchiveBaseFolder = ArchiveBaseFolder;
			JObject jobject;
			try
			{
				jobject = (JObject)ModBase.GetJson(ModBase.ReadFile(Archive.GetEntry(CS$<>8__locals1.$VB$Local_ArchiveBaseFolder + "modpack.json").Open(), Encoding.UTF8));
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "整合包安装信息存在问题", ModBase.LogLevel.Hint, "出现错误");
				return;
			}
			string text = (string)(jobject["name"] ?? "");
			ValidateFolderName validateFolderName = new ValidateFolderName(ModMinecraft._MapperTag + "versions", true, true);
			if (Operators.CompareString(validateFolderName.Validate(text), "", true) != 0)
			{
				text = "";
			}
			CS$<>8__locals1.$VB$Local_VersionName = ModMain.MyMsgBoxInput(text, new Collection<Validate>
			{
				validateFolderName
			}, "", "输入版本名", "确定", "取消", false);
			if (CS$<>8__locals1.$VB$Local_VersionName != null)
			{
				CS$<>8__locals1.$VB$Local_InstallTemp = ModBase.attributeState + "PackInstall\\" + Conversions.ToString(ModBase.RandomInteger(0, 100000)) + "\\";
				List<ModLoader.LoaderBase> list = new List<ModLoader.LoaderBase>();
				list.Add(new ModLoader.LoaderTask<string, int>("解压整合包文件", delegate(ModLoader.LoaderTask<string, int> Task)
				{
					ModModpack.UnpackFiles(CS$<>8__locals1.$VB$Local_InstallTemp, CS$<>8__locals1.$VB$Local_FileAddress);
					Task.Progress = 0.5;
					if (Directory.Exists(CS$<>8__locals1.$VB$Local_InstallTemp + CS$<>8__locals1.$VB$Local_ArchiveBaseFolder + "minecraft"))
					{
						MyWpfExtension.FindModel().FileSystem.CopyDirectory(CS$<>8__locals1.$VB$Local_InstallTemp + CS$<>8__locals1.$VB$Local_ArchiveBaseFolder + "minecraft", ModMinecraft._MapperTag + "versions\\" + CS$<>8__locals1.$VB$Local_VersionName);
					}
					else
					{
						ModBase.Log("[ModPack] 整合包中未找到 minecraft override 目录，已跳过", ModBase.LogLevel.Normal, "出现错误");
					}
					Task.Progress = 0.9;
					ModBase.WriteIni(ModMinecraft._MapperTag + "versions\\" + CS$<>8__locals1.$VB$Local_VersionName + "\\PCL\\Setup.ini", "VersionArgumentIndie", Conversions.ToString(1));
				}, null, ThreadPriority.Normal)
				{
					ProgressWeight = (double)new FileInfo(CS$<>8__locals1.$VB$Local_FileAddress).Length / 1024.0 / 1024.0 / 6.0,
					Block = false
				});
				if (jobject["gameVersion"] == null)
				{
					throw new Exception("整合包未提供游戏版本信息");
				}
				ModDownloadLib.McInstallRequest request = new ModDownloadLib.McInstallRequest
				{
					_ConnectionState = CS$<>8__locals1.$VB$Local_VersionName,
					customerState = jobject["gameVersion"].ToString()
				};
				double num = 0.0;
				try
				{
					foreach (ModLoader.LoaderBase loaderBase in list)
					{
						num += loaderBase.ProgressWeight;
					}
				}
				finally
				{
					List<ModLoader.LoaderBase>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				List<ModLoader.LoaderBase> list2 = ModDownloadLib.McInstallLoader(request, true);
				if (list2 != null)
				{
					double num2 = 0.0;
					try
					{
						foreach (ModLoader.LoaderBase loaderBase2 in list2)
						{
							num2 += loaderBase2.ProgressWeight;
						}
					}
					finally
					{
						List<ModLoader.LoaderBase>.Enumerator enumerator2;
						((IDisposable)enumerator2).Dispose();
					}
					List<ModLoader.LoaderBase> list3 = new List<ModLoader.LoaderBase>();
					list3.Add(new ModLoader.LoaderTask<string, string>("重命名版本 Json（副加载器）", delegate(ModLoader.LoaderTask<string, string> a0)
					{
						base._Lambda$__1();
					}, null, ThreadPriority.Normal)
					{
						ProgressWeight = 0.1,
						Show = false
					});
					list3.Add(new ModLoader.LoaderTask<string, List<ModNet.NetFile>>("分析游戏支持库文件（副加载器）", delegate(ModLoader.LoaderTask<string, List<ModNet.NetFile>> Task)
					{
						Task.Output = ModMinecraft.McLibFix(new ModMinecraft.McVersion(CS$<>8__locals1.$VB$Local_VersionName), false);
					}, null, ThreadPriority.Normal)
					{
						ProgressWeight = 1.0,
						Show = false
					});
					list3.Add(new ModNet.LoaderDownload("下载游戏支持库文件（副加载器）", new List<ModNet.NetFile>())
					{
						ProgressWeight = 7.0,
						Show = false
					});
					List<ModLoader.LoaderBase> loaders = new List<ModLoader.LoaderBase>
					{
						new ModLoader.LoaderCombo<string>("游戏安装", list2)
						{
							Show = false,
							Block = false,
							ProgressWeight = num2
						},
						new ModLoader.LoaderCombo<string>("整合包安装", list)
						{
							Show = false,
							ProgressWeight = num
						},
						new ModLoader.LoaderCombo<string>("下载游戏支持库文件", list3)
						{
							ProgressWeight = 8.0
						}
					};
					string text2 = "HMCL 整合包安装：" + CS$<>8__locals1.$VB$Local_VersionName + " ";
					object loaderTaskbarLock = ModLoader.LoaderTaskbarLock;
					ObjectFlowControl.CheckForSyncLockOnValueType(loaderTaskbarLock);
					checked
					{
						lock (loaderTaskbarLock)
						{
							int num3 = ModLoader.LoaderTaskbar.Count - 1;
							for (int i = 0; i <= num3; i++)
							{
								if (Operators.CompareString(ModLoader.LoaderTaskbar[i].Name, text2, true) == 0)
								{
									ModMain.Hint("该整合包正在安装中！", ModMain.HintType.Critical, true);
									return;
								}
							}
						}
						ModLoader.LoaderCombo<string> loaderCombo = new ModLoader.LoaderCombo<string>(text2, loaders);
						loaderCombo.OnStateChanged = new Action<ModLoader.LoaderBase>(ModDownloadLib.McInstallState);
						loaderCombo.Start(ModMinecraft._MapperTag + "versions\\" + CS$<>8__locals1.$VB$Local_VersionName + "\\", false);
						ModLoader.LoaderTaskbarAdd(loaderCombo);
						ModMain.m_CollectionAccount.BtnExtraDownload.ShowRefresh();
						ModMain.m_CollectionAccount.BtnExtraDownload.Ribble();
					}
				}
			}
		}

		// Token: 0x06000154 RID: 340 RVA: 0x00012B0C File Offset: 0x00010D0C
		private static void InstallPackMMC(string FileAddress, ZipArchive Archive, string ArchiveBaseFolder)
		{
			ModModpack._Closure$__9-0 CS$<>8__locals1 = new ModModpack._Closure$__9-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Local_FileAddress = FileAddress;
			CS$<>8__locals1.$VB$Local_ArchiveBaseFolder = ArchiveBaseFolder;
			JObject jobject;
			string str;
			try
			{
				jobject = (JObject)ModBase.GetJson(ModBase.ReadFile(Archive.GetEntry(CS$<>8__locals1.$VB$Local_ArchiveBaseFolder + "mmc-pack.json").Open(), Encoding.UTF8));
				str = ModBase.ReadFile(Archive.GetEntry(CS$<>8__locals1.$VB$Local_ArchiveBaseFolder + "instance.cfg").Open(), Encoding.UTF8);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "整合包安装信息存在问题", ModBase.LogLevel.Hint, "出现错误");
				return;
			}
			string text = ModBase.RegexSeek(str, "(?<=\\nname\\=)[^\\n]+", RegexOptions.None) ?? "";
			ValidateFolderName validateFolderName = new ValidateFolderName(ModMinecraft._MapperTag + "versions", true, true);
			if (Operators.CompareString(validateFolderName.Validate(text), "", true) != 0)
			{
				text = "";
			}
			CS$<>8__locals1.$VB$Local_VersionName = ModMain.MyMsgBoxInput(text, new Collection<Validate>
			{
				validateFolderName
			}, "", "输入版本名", "确定", "取消", false);
			if (CS$<>8__locals1.$VB$Local_VersionName != null)
			{
				CS$<>8__locals1.$VB$Local_InstallTemp = ModBase.attributeState + "PackInstall\\" + Conversions.ToString(ModBase.RandomInteger(0, 100000)) + "\\";
				List<ModLoader.LoaderBase> list = new List<ModLoader.LoaderBase>();
				list.Add(new ModLoader.LoaderTask<string, int>("解压整合包文件", delegate(ModLoader.LoaderTask<string, int> Task)
				{
					ModModpack.UnpackFiles(CS$<>8__locals1.$VB$Local_InstallTemp, CS$<>8__locals1.$VB$Local_FileAddress);
					Task.Progress = 0.5;
					if (Directory.Exists(CS$<>8__locals1.$VB$Local_InstallTemp + CS$<>8__locals1.$VB$Local_ArchiveBaseFolder + ".minecraft"))
					{
						MyWpfExtension.FindModel().FileSystem.CopyDirectory(CS$<>8__locals1.$VB$Local_InstallTemp + CS$<>8__locals1.$VB$Local_ArchiveBaseFolder + ".minecraft", ModMinecraft._MapperTag + "versions\\" + CS$<>8__locals1.$VB$Local_VersionName);
					}
					else
					{
						ModBase.Log("[ModPack] 整合包中未找到 override .minecraft 目录，已跳过", ModBase.LogLevel.Normal, "出现错误");
					}
					Task.Progress = 0.9;
					ModBase.WriteIni(ModMinecraft._MapperTag + "versions\\" + CS$<>8__locals1.$VB$Local_VersionName + "\\PCL\\Setup.ini", "VersionArgumentIndie", Conversions.ToString(1));
				}, null, ThreadPriority.Normal)
				{
					ProgressWeight = (double)new FileInfo(CS$<>8__locals1.$VB$Local_FileAddress).Length / 1024.0 / 1024.0 / 6.0,
					Block = false
				});
				if (jobject["components"] == null)
				{
					throw new Exception("整合包未提供游戏版本信息");
				}
				ModDownloadLib.McInstallRequest mcInstallRequest = new ModDownloadLib.McInstallRequest
				{
					_ConnectionState = CS$<>8__locals1.$VB$Local_VersionName
				};
				try
				{
					foreach (JToken jtoken in jobject["components"])
					{
						string left = (jtoken["uid"] ?? "").ToString();
						if (Operators.CompareString(left, "org.lwjgl", true) == 0)
						{
							ModBase.Log("[ModPack] 已跳过 LWJGL 项", ModBase.LogLevel.Normal, "出现错误");
						}
						else if (Operators.CompareString(left, "net.minecraft", true) == 0)
						{
							mcInstallRequest.customerState = (string)jtoken["version"];
						}
						else if (Operators.CompareString(left, "net.minecraftforge", true) == 0)
						{
							mcInstallRequest._AdvisorState = (string)jtoken["version"];
						}
					}
				}
				finally
				{
					IEnumerator<JToken> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				double num = 0.0;
				try
				{
					foreach (ModLoader.LoaderBase loaderBase in list)
					{
						num += loaderBase.ProgressWeight;
					}
				}
				finally
				{
					List<ModLoader.LoaderBase>.Enumerator enumerator2;
					((IDisposable)enumerator2).Dispose();
				}
				List<ModLoader.LoaderBase> list2 = ModDownloadLib.McInstallLoader(mcInstallRequest, true);
				if (list2 != null)
				{
					double num2 = 0.0;
					try
					{
						foreach (ModLoader.LoaderBase loaderBase2 in list2)
						{
							num2 += loaderBase2.ProgressWeight;
						}
					}
					finally
					{
						List<ModLoader.LoaderBase>.Enumerator enumerator3;
						((IDisposable)enumerator3).Dispose();
					}
					List<ModLoader.LoaderBase> list3 = new List<ModLoader.LoaderBase>();
					list3.Add(new ModLoader.LoaderTask<string, List<ModNet.NetFile>>("分析游戏支持库文件（副加载器）", delegate(ModLoader.LoaderTask<string, List<ModNet.NetFile>> Task)
					{
						Task.Output = ModMinecraft.McLibFix(new ModMinecraft.McVersion(CS$<>8__locals1.$VB$Local_VersionName), false);
					}, null, ThreadPriority.Normal)
					{
						ProgressWeight = 1.0,
						Show = false
					});
					list3.Add(new ModNet.LoaderDownload("下载游戏支持库文件（副加载器）", new List<ModNet.NetFile>())
					{
						ProgressWeight = 7.0,
						Show = false
					});
					List<ModLoader.LoaderBase> list4 = new List<ModLoader.LoaderBase>();
					list4.Add(new ModLoader.LoaderCombo<string>("游戏安装", list2)
					{
						Show = false,
						Block = false,
						ProgressWeight = num2
					});
					list4.Add(new ModLoader.LoaderCombo<string>("整合包安装", list)
					{
						Show = false,
						ProgressWeight = num
					});
					list4.Add(new ModLoader.LoaderCombo<string>("下载游戏支持库文件", list3)
					{
						ProgressWeight = 8.0
					});
					string text2 = "MMC 整合包安装：" + CS$<>8__locals1.$VB$Local_VersionName + " ";
					object loaderTaskbarLock = ModLoader.LoaderTaskbarLock;
					ObjectFlowControl.CheckForSyncLockOnValueType(loaderTaskbarLock);
					checked
					{
						lock (loaderTaskbarLock)
						{
							int num3 = ModLoader.LoaderTaskbar.Count - 1;
							for (int i = 0; i <= num3; i++)
							{
								if (Operators.CompareString(ModLoader.LoaderTaskbar[i].Name, text2, true) == 0)
								{
									ModMain.Hint("该整合包正在安装中！", ModMain.HintType.Critical, true);
									return;
								}
							}
						}
						ModLoader.LoaderCombo<string> loaderCombo = new ModLoader.LoaderCombo<string>(text2, list4);
						loaderCombo.OnStateChanged = new Action<ModLoader.LoaderBase>(ModDownloadLib.McInstallState);
						loaderCombo.Start(ModMinecraft._MapperTag + "versions\\" + CS$<>8__locals1.$VB$Local_VersionName + "\\", false);
						ModLoader.LoaderTaskbarAdd(loaderCombo);
						ModMain.m_CollectionAccount.BtnExtraDownload.ShowRefresh();
						ModMain.m_CollectionAccount.BtnExtraDownload.Ribble();
					}
				}
			}
		}

		// Token: 0x06000155 RID: 341 RVA: 0x0001304C File Offset: 0x0001124C
		private static void InstallPackMCBBS(string FileAddress, ZipArchive Archive, string ArchiveBaseFolder)
		{
			ModModpack._Closure$__10-0 CS$<>8__locals1 = new ModModpack._Closure$__10-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Local_FileAddress = FileAddress;
			CS$<>8__locals1.$VB$Local_ArchiveBaseFolder = ArchiveBaseFolder;
			JObject jobject;
			try
			{
				jobject = (JObject)ModBase.GetJson(ModBase.ReadFile((Archive.GetEntry(CS$<>8__locals1.$VB$Local_ArchiveBaseFolder + "mcbbs.packmeta") ?? Archive.GetEntry(CS$<>8__locals1.$VB$Local_ArchiveBaseFolder + "manifest.json")).Open(), Encoding.UTF8));
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "整合包安装信息存在问题", ModBase.LogLevel.Hint, "出现错误");
				return;
			}
			string text = (string)(jobject["name"] ?? "");
			ValidateFolderName validateFolderName = new ValidateFolderName(ModMinecraft._MapperTag + "versions", true, true);
			if (Operators.CompareString(validateFolderName.Validate(text), "", true) != 0)
			{
				text = "";
			}
			CS$<>8__locals1.$VB$Local_VersionName = ModMain.MyMsgBoxInput(text, new Collection<Validate>
			{
				validateFolderName
			}, "", "输入版本名", "确定", "取消", false);
			if (CS$<>8__locals1.$VB$Local_VersionName != null)
			{
				CS$<>8__locals1.$VB$Local_InstallTemp = ModBase.attributeState + "PackInstall\\" + Conversions.ToString(ModBase.RandomInteger(0, 100000)) + "\\";
				List<ModLoader.LoaderBase> list = new List<ModLoader.LoaderBase>();
				list.Add(new ModLoader.LoaderTask<string, int>("解压整合包文件", delegate(ModLoader.LoaderTask<string, int> Task)
				{
					ModModpack.UnpackFiles(CS$<>8__locals1.$VB$Local_InstallTemp, CS$<>8__locals1.$VB$Local_FileAddress);
					Task.Progress = 0.5;
					if (Directory.Exists(CS$<>8__locals1.$VB$Local_InstallTemp + CS$<>8__locals1.$VB$Local_ArchiveBaseFolder + "overrides"))
					{
						MyWpfExtension.FindModel().FileSystem.CopyDirectory(CS$<>8__locals1.$VB$Local_InstallTemp + CS$<>8__locals1.$VB$Local_ArchiveBaseFolder + "overrides", ModMinecraft._MapperTag + "versions\\" + CS$<>8__locals1.$VB$Local_VersionName);
					}
					else
					{
						ModBase.Log("[ModPack] 整合包中未找到 overrides 目录，已跳过", ModBase.LogLevel.Normal, "出现错误");
					}
					Task.Progress = 0.9;
					ModBase.WriteIni(ModMinecraft._MapperTag + "versions\\" + CS$<>8__locals1.$VB$Local_VersionName + "\\PCL\\Setup.ini", "VersionArgumentIndie", Conversions.ToString(1));
				}, null, ThreadPriority.Normal)
				{
					ProgressWeight = (double)new FileInfo(CS$<>8__locals1.$VB$Local_FileAddress).Length / 1024.0 / 1024.0 / 6.0,
					Block = false
				});
				if (jobject["addons"] == null)
				{
					throw new Exception("整合包未提供游戏版本信息");
				}
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				try
				{
					foreach (JToken jtoken in jobject["addons"])
					{
						dictionary.Add((string)jtoken["id"], (string)jtoken["version"]);
					}
				}
				finally
				{
					IEnumerator<JToken> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				if (!dictionary.ContainsKey("game"))
				{
					throw new Exception("整合包未提供游戏版本信息");
				}
				ModDownloadLib.McInstallRequest request = new ModDownloadLib.McInstallRequest
				{
					_ConnectionState = CS$<>8__locals1.$VB$Local_VersionName,
					customerState = dictionary["game"],
					_DatabaseState = (dictionary.ContainsKey("optifine") ? dictionary["optifine"] : null),
					_AdvisorState = (dictionary.ContainsKey("forge") ? dictionary["forge"] : null),
					_SingletonState = (dictionary.ContainsKey("fabric") ? dictionary["fabric"] : null)
				};
				double num = 0.0;
				try
				{
					foreach (ModLoader.LoaderBase loaderBase in list)
					{
						num += loaderBase.ProgressWeight;
					}
				}
				finally
				{
					List<ModLoader.LoaderBase>.Enumerator enumerator2;
					((IDisposable)enumerator2).Dispose();
				}
				List<ModLoader.LoaderBase> list2 = ModDownloadLib.McInstallLoader(request, true);
				if (list2 != null)
				{
					double num2 = 0.0;
					try
					{
						foreach (ModLoader.LoaderBase loaderBase2 in list2)
						{
							num2 += loaderBase2.ProgressWeight;
						}
					}
					finally
					{
						List<ModLoader.LoaderBase>.Enumerator enumerator3;
						((IDisposable)enumerator3).Dispose();
					}
					List<ModLoader.LoaderBase> list3 = new List<ModLoader.LoaderBase>();
					list3.Add(new ModLoader.LoaderTask<string, List<ModNet.NetFile>>("分析游戏支持库文件（副加载器）", delegate(ModLoader.LoaderTask<string, List<ModNet.NetFile>> Task)
					{
						Task.Output = ModMinecraft.McLibFix(new ModMinecraft.McVersion(CS$<>8__locals1.$VB$Local_VersionName), false);
					}, null, ThreadPriority.Normal)
					{
						ProgressWeight = 1.0,
						Show = false
					});
					list3.Add(new ModNet.LoaderDownload("下载游戏支持库文件（副加载器）", new List<ModNet.NetFile>())
					{
						ProgressWeight = 7.0,
						Show = false
					});
					List<ModLoader.LoaderBase> list4 = new List<ModLoader.LoaderBase>();
					list4.Add(new ModLoader.LoaderCombo<string>("游戏安装", list2)
					{
						Show = false,
						Block = false,
						ProgressWeight = num2
					});
					list4.Add(new ModLoader.LoaderCombo<string>("整合包安装", list)
					{
						Show = false,
						ProgressWeight = num
					});
					list4.Add(new ModLoader.LoaderCombo<string>("下载游戏支持库文件", list3)
					{
						ProgressWeight = 8.0
					});
					string text2 = "MCBBS 整合包安装：" + CS$<>8__locals1.$VB$Local_VersionName + " ";
					object loaderTaskbarLock = ModLoader.LoaderTaskbarLock;
					ObjectFlowControl.CheckForSyncLockOnValueType(loaderTaskbarLock);
					checked
					{
						lock (loaderTaskbarLock)
						{
							int num3 = ModLoader.LoaderTaskbar.Count - 1;
							for (int i = 0; i <= num3; i++)
							{
								if (Operators.CompareString(ModLoader.LoaderTaskbar[i].Name, text2, true) == 0)
								{
									ModMain.Hint("该整合包正在安装中！", ModMain.HintType.Critical, true);
									return;
								}
							}
						}
						ModLoader.LoaderCombo<string> loaderCombo = new ModLoader.LoaderCombo<string>(text2, list4);
						loaderCombo.OnStateChanged = new Action<ModLoader.LoaderBase>(ModDownloadLib.McInstallState);
						loaderCombo.Start(ModMinecraft._MapperTag + "versions\\" + CS$<>8__locals1.$VB$Local_VersionName + "\\", false);
						ModLoader.LoaderTaskbarAdd(loaderCombo);
						ModMain.m_CollectionAccount.BtnExtraDownload.ShowRefresh();
						ModMain.m_CollectionAccount.BtnExtraDownload.Ribble();
					}
				}
			}
		}

		// Token: 0x06000156 RID: 342 RVA: 0x000135B0 File Offset: 0x000117B0
		private static void InstallPackCompress(string FileAddress, string ArchiveBaseFolder)
		{
			ModMain.MyMsgBox("请在接下来打开的窗口中选择想要安装的目标文件夹。", "安装提示", "继续", "", "", false, true, true);
			string text = ModBase.SelectFolder("选择安装目标文件夹");
			if (!string.IsNullOrEmpty(text))
			{
				if (text.Contains("!") || text.Contains(";"))
				{
					ModMain.Hint("Minecraft 文件夹路径中不能含有感叹号或分号！", ModMain.HintType.Critical, true);
					return;
				}
				string text2 = ModMain.MyMsgBoxInput(ModBase.GetFolderNameFromPath(text), new Collection<Validate>
				{
					new ValidateNullOrWhiteSpace(),
					new ValidateLength(1, 30),
					new ValidateExcept(new string[]
					{
						">",
						"|"
					}, "输入内容不能包含 %！")
				}, "", "输入它在列表中的显示名称", "确定", "取消", false);
				if (!string.IsNullOrWhiteSpace(text2))
				{
					ModMain.Hint("正在解压压缩包……", ModMain.HintType.Info, true);
					ModModpack.UnpackFiles(text, FileAddress);
					PageSelectLeft.AddFolder(text, text2, false);
					ModMain.Hint("已加入游戏文件夹列表：" + text2, ModMain.HintType.Finish, true);
				}
			}
		}

		// Token: 0x040000A8 RID: 168
		private static bool m_Creator = false;

		// Token: 0x040000A9 RID: 169
		private static bool _Object = false;
	}
}
