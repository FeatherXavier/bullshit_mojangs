﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x020000BE RID: 190
	[DesignerGenerated]
	public class PageVersionModDisabled : MyPageRight, IComponentConnector
	{
		// Token: 0x0600075B RID: 1883 RVA: 0x00005E15 File Offset: 0x00004015
		public PageVersionModDisabled()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600075C RID: 1884 RVA: 0x00005E24 File Offset: 0x00004024
		private void BtnDownload_Click(object sender, EventArgs e)
		{
			ModMain.m_CollectionAccount.PageChange(FormMain.PageType.Download, FormMain.PageSubType.DownloadInstall);
		}

		// Token: 0x0600075D RID: 1885 RVA: 0x00005E37 File Offset: 0x00004037
		private void BtnVersion_Click(object sender, EventArgs e)
		{
			ModMain.m_CollectionAccount.PageChange(FormMain.PageType.Launch, FormMain.PageSubType.Default);
			ModMain.m_CollectionAccount.PageChange(FormMain.PageType.VersionSelect, FormMain.PageSubType.Default);
		}

		// Token: 0x0600075E RID: 1886 RVA: 0x0003368C File Offset: 0x0003188C
		public void BtnDownload_Loaded()
		{
			Visibility visibility = Conversions.ToBoolean((Conversions.ToBoolean(ModBase._ParamsState.Get("UiHiddenPageDownload", null)) && !PageSetupUI.AwakeResolver()) || (ModMain._PageAccount != null && ModMain._PageAccount._EventComparator)) ? Visibility.Collapsed : Visibility.Visible;
			if (this.BtnDownload.Visibility != visibility)
			{
				this.BtnDownload.Visibility = visibility;
				this.PanMain.TriggerForceResize();
			}
		}

		// Token: 0x17000110 RID: 272
		// (get) Token: 0x0600075F RID: 1887 RVA: 0x00005E5B File Offset: 0x0000405B
		// (set) Token: 0x06000760 RID: 1888 RVA: 0x00005E63 File Offset: 0x00004063
		internal virtual MyCard PanMain { get; set; }

		// Token: 0x17000111 RID: 273
		// (get) Token: 0x06000761 RID: 1889 RVA: 0x00005E6C File Offset: 0x0000406C
		// (set) Token: 0x06000762 RID: 1890 RVA: 0x00033704 File Offset: 0x00031904
		internal virtual MyButton BtnDownload
		{
			[CompilerGenerated]
			get
			{
				return this.m_CreatorResolver;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnDownload_Click);
				RoutedEventHandler value2 = delegate(object sender, RoutedEventArgs e)
				{
					this.BtnDownload_Loaded();
				};
				MyButton creatorResolver = this.m_CreatorResolver;
				if (creatorResolver != null)
				{
					creatorResolver.RevertResolver(obj);
					creatorResolver.Loaded -= value2;
				}
				this.m_CreatorResolver = value;
				creatorResolver = this.m_CreatorResolver;
				if (creatorResolver != null)
				{
					creatorResolver.PostResolver(obj);
					creatorResolver.Loaded += value2;
				}
			}
		}

		// Token: 0x17000112 RID: 274
		// (get) Token: 0x06000763 RID: 1891 RVA: 0x00005E74 File Offset: 0x00004074
		// (set) Token: 0x06000764 RID: 1892 RVA: 0x00033764 File Offset: 0x00031964
		internal virtual MyButton BtnVersion
		{
			[CompilerGenerated]
			get
			{
				return this._ObjectResolver;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnVersion_Click);
				MyButton objectResolver = this._ObjectResolver;
				if (objectResolver != null)
				{
					objectResolver.RevertResolver(obj);
				}
				this._ObjectResolver = value;
				objectResolver = this._ObjectResolver;
				if (objectResolver != null)
				{
					objectResolver.PostResolver(obj);
				}
			}
		}

		// Token: 0x06000765 RID: 1893 RVA: 0x000337A8 File Offset: 0x000319A8
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.regResolver)
			{
				this.regResolver = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pageversion/pageversionmoddisabled.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000766 RID: 1894 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000767 RID: 1895 RVA: 0x00005E7C File Offset: 0x0000407C
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanMain = (MyCard)target;
				return;
			}
			if (connectionId == 2)
			{
				this.BtnDownload = (MyButton)target;
				return;
			}
			if (connectionId == 3)
			{
				this.BtnVersion = (MyButton)target;
				return;
			}
			this.regResolver = true;
		}

		// Token: 0x0400034D RID: 845
		[AccessedThroughProperty("PanMain")]
		[CompilerGenerated]
		private MyCard _InstanceResolver;

		// Token: 0x0400034E RID: 846
		[CompilerGenerated]
		[AccessedThroughProperty("BtnDownload")]
		private MyButton m_CreatorResolver;

		// Token: 0x0400034F RID: 847
		[CompilerGenerated]
		[AccessedThroughProperty("BtnVersion")]
		private MyButton _ObjectResolver;

		// Token: 0x04000350 RID: 848
		private bool regResolver;
	}
}
