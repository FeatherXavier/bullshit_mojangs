﻿using System;

namespace PCL
{
	// Token: 0x02000051 RID: 81
	public interface ILoadingTrigger
	{
		// Token: 0x17000033 RID: 51
		// (get) Token: 0x06000222 RID: 546
		bool IsLoader { get; }

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x06000223 RID: 547
		// (set) Token: 0x06000224 RID: 548
		MyLoading.MyLoadingState LoadingState { get; set; }

		// Token: 0x14000003 RID: 3
		// (add) Token: 0x06000225 RID: 549
		// (remove) Token: 0x06000226 RID: 550
		event ILoadingTrigger.LoadingStateChangedEventHandler LoadingStateChanged;

		// Token: 0x02000052 RID: 82
		// (Invoke) Token: 0x0600022A RID: 554
		public delegate void LoadingStateChangedEventHandler(MyLoading.MyLoadingState NewState, MyLoading.MyLoadingState OldState);
	}
}
