﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Newtonsoft.Json.Linq;
using PCL.My;

namespace PCL
{
	// Token: 0x02000101 RID: 257
	[StandardModule]
	public sealed class ModLaunch
	{
		// Token: 0x06000992 RID: 2450 RVA: 0x00045234 File Offset: 0x00043434
		public static void McLaunchLog(string Text)
		{
			ModBase.RunInUi(delegate()
			{
				TextBlock labLog;
				(labLog = ModMain._ReaderAccount.LabLog).Text = string.Concat(new string[]
				{
					labLog.Text,
					"\r\n[",
					ModBase.GetTimeNow(),
					"] ",
					Text
				});
			}, false);
			ModBase.Log("[Launch] " + Text, ModBase.LogLevel.Normal, "出现错误");
		}

		// Token: 0x06000993 RID: 2451 RVA: 0x0004527C File Offset: 0x0004347C
		private static void McLaunchState(ModLoader.LoaderTask<string, object> Loader)
		{
			switch (ModLaunch._AttrTag.State)
			{
			case ModBase.LoadState.Waiting:
			case ModBase.LoadState.Finished:
			case ModBase.LoadState.Failed:
			case ModBase.LoadState.Aborted:
				ModMain._FilterAccount.PageChangeToLogin();
				return;
			case ModBase.LoadState.Loading:
				ModMain._ReaderAccount.LabLog.Text = "";
				return;
			default:
				return;
			}
		}

		// Token: 0x06000994 RID: 2452 RVA: 0x000452D0 File Offset: 0x000434D0
		private static void McLaunchStart(ModLoader.LoaderTask<string, object> Loader)
		{
			ModLaunch._Closure$__7-0 CS$<>8__locals1 = new ModLaunch._Closure$__7-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Local_Loader = Loader;
			ModBase.RunInUiWait(new Action(ModMain._FilterAccount.PageChangeToLaunching));
			try
			{
				ModLaunch.McLaunchPrecheck();
				ModLaunch.McLaunchLog("预检测已通过");
			}
			catch (Exception ex)
			{
				ModMain.Hint(ex.Message, ModMain.HintType.Critical, true);
				throw;
			}
			try
			{
				ModLoader.LoaderCombo<object> loaderCombo = new ModLoader.LoaderCombo<object>("Minecraft 启动", new ModLoader.LoaderBase[]
				{
					new ModLoader.LoaderCombo<int>("Java 处理", new ModLoader.LoaderBase[]
					{
						new ModLoader.LoaderTask<int, List<ModNet.NetFile>>("Java 验证", (ModLaunch._Closure$__.$IR7-2 == null) ? (ModLaunch._Closure$__.$IR7-2 = delegate(ModLoader.LoaderTask<int, List<ModNet.NetFile>> a0)
						{
							ModLaunch.McLaunchJavaValidate();
						}) : ModLaunch._Closure$__.$IR7-2, null, ThreadPriority.Normal)
						{
							ProgressWeight = 2.0
						}
					})
					{
						ProgressWeight = 2.0,
						Show = false,
						Block = false
					},
					ModLaunch.m_IndexerTag,
					new ModLoader.LoaderCombo<string>("补全文件", ModDownload.DlClientFix(ModMinecraft.SetupResolver(), false, ModDownload.AssetsIndexExistsBehaviour.DownloadInBackground, true))
					{
						ProgressWeight = 15.0,
						Show = false,
						Block = true
					},
					new ModLoader.LoaderTask<int, string>("提供参数中的服务器 IP", delegate(ModLoader.LoaderTask<int, string> InnerLoader)
					{
						InnerLoader.Output = CS$<>8__locals1.$VB$Local_Loader.Input;
					}, null, ThreadPriority.Normal)
					{
						ProgressWeight = 0.01,
						Show = false
					},
					new ModLoader.LoaderTask<string, List<ModMinecraft.McLibToken>>("获取启动参数", new Action<ModLoader.LoaderTask<string, List<ModMinecraft.McLibToken>>>(ModLaunch.McLaunchArgumentMain), null, ThreadPriority.Normal)
					{
						ProgressWeight = 2.0
					},
					new ModLoader.LoaderTask<List<ModMinecraft.McLibToken>, int>("解压文件", new Action<ModLoader.LoaderTask<List<ModMinecraft.McLibToken>, int>>(ModLaunch.McLaunchNatives), null, ThreadPriority.Normal)
					{
						ProgressWeight = 2.0
					},
					new ModLoader.LoaderTask<int, int>("预启动处理", (ModLaunch._Closure$__.$IR7-3 == null) ? (ModLaunch._Closure$__.$IR7-3 = delegate(ModLoader.LoaderTask<int, int> a0)
					{
						ModLaunch.McLaunchPrerun();
					}) : ModLaunch._Closure$__.$IR7-3, null, ThreadPriority.Normal)
					{
						ProgressWeight = 1.0
					},
					new ModLoader.LoaderTask<int, Process>("启动进程", new Action<ModLoader.LoaderTask<int, Process>>(ModLaunch.McLaunchRun), null, ThreadPriority.Normal)
					{
						ProgressWeight = 2.0
					},
					new ModLoader.LoaderTask<Process, int>("等待游戏窗口出现", new Action<ModLoader.LoaderTask<Process, int>>(ModLaunch.McLaunchWait), null, ThreadPriority.Normal)
					{
						ProgressWeight = 1.0
					},
					new ModLoader.LoaderTask<int, int>("结束处理", (ModLaunch._Closure$__.$IR7-4 == null) ? (ModLaunch._Closure$__.$IR7-4 = delegate(ModLoader.LoaderTask<int, int> a0)
					{
						ModLaunch.McLaunchEnd();
					}) : ModLaunch._Closure$__.$IR7-4, null, ThreadPriority.Normal)
					{
						ProgressWeight = 1.0
					}
				})
				{
					Show = false
				};
				ModLaunch.facadeTag = loaderCombo;
				loaderCombo.Start(null, false);
				ModLoader.LoaderTaskbarAdd(loaderCombo);
				while (loaderCombo.State == ModBase.LoadState.Loading)
				{
					ModMain._FilterAccount.Dispatcher.Invoke(new Action(ModMain._FilterAccount.LaunchingRefresh));
					Thread.Sleep(200);
				}
				ModMain._FilterAccount.Dispatcher.Invoke(new Action(ModMain._FilterAccount.LaunchingRefresh));
				switch (loaderCombo.State)
				{
				case ModBase.LoadState.Finished:
					ModMain.Hint(ModMinecraft.SetupResolver().Name + " 启动成功！", ModMain.HintType.Finish, true);
					break;
				case ModBase.LoadState.Failed:
					throw loaderCombo.Error;
				case ModBase.LoadState.Aborted:
					ModMain.Hint("已取消启动！", ModMain.HintType.Info, true);
					break;
				default:
					throw new Exception("错误的状态改变：" + ModBase.GetStringFromEnum(loaderCombo.State));
				}
			}
			catch (Exception ex2)
			{
				Exception ex3 = ex2;
				while (!ex3.Message.StartsWith("$"))
				{
					if (ex3.InnerException == null)
					{
						ModLaunch.McLaunchLog("错误：" + ModBase.GetString(ex2, false, false));
						ModBase.Log(ex2, "Minecraft 启动失败", ModBase.LogLevel.Msgbox, "启动失败");
						throw;
					}
					ex3 = ex3.InnerException;
				}
				if (Operators.CompareString(ex3.Message, "$$", true) != 0)
				{
					ModMain.MyMsgBox(ex3.Message.TrimStart(new char[]
					{
						'$'
					}), "启动失败", "确定", "", "", false, true, false);
				}
				throw;
			}
		}

		// Token: 0x06000995 RID: 2453 RVA: 0x00045704 File Offset: 0x00043904
		private static void McLaunchPrecheck()
		{
			if (ModMinecraft.SetupResolver().CreateComparator().Contains("!") || ModMinecraft.SetupResolver().CreateComparator().Contains(";"))
			{
				throw new Exception("游戏路径中不可包含 ! 或 ;（" + ModMinecraft.SetupResolver().CreateComparator() + "）");
			}
			if (ModMinecraft.SetupResolver().Path.Contains("!") || ModMinecraft.SetupResolver().Path.Contains(";"))
			{
				throw new Exception("游戏路径中不可包含 ! 或 ;（" + ModMinecraft.SetupResolver().Path + "）");
			}
			string CheckResult = null;
			ModBase.RunInUiWait(delegate
			{
				CheckResult = ModLaunch.McLoginAble(ModLaunch.McLoginInput());
			});
			if (Operators.CompareString(CheckResult, "", true) != 0)
			{
				throw new ArgumentException(CheckResult);
			}
			if (ModMinecraft.SetupResolver() == null)
			{
				throw new Exception("未选择 Minecraft 版本！");
			}
			ModMinecraft.SetupResolver().Load();
			if (ModMinecraft.SetupResolver()._ClassProccesor == ModMinecraft.McVersionState.Error)
			{
				throw new Exception("Minecraft 存在问题：" + ModMinecraft.SetupResolver().proxyProccesor);
			}
			if (!ModMain.CreateTag(null))
			{
				ModBase.RunInNewThread((ModLaunch._Closure$__.$I8-1 == null) ? (ModLaunch._Closure$__.$I8-1 = delegate()
				{
					object left = ModBase._ParamsState.Get("SystemLaunchCount", null);
					if (Conversions.ToBoolean(Conversions.ToBoolean(Operators.CompareObjectEqual(left, 20, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 50, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 100, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 150, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 200, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 250, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 300, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 350, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 400, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 450, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 500, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 600, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 700, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 800, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 900, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 1000, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 1100, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 1200, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 1300, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 1400, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 1500, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 1600, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 1700, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 1800, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 1900, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 2000, true))) && ModMain.MyMsgBox(Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("PCL2 已经为你启动了 ", ModBase._ParamsState.Get("SystemLaunchCount", null)), " 次游戏啦！"), "\r\n"), "如果觉得 PCL2 还算好用的话，也可以考虑小小地赞助一下作者呢 qwq……"), "\r\n"), "毕竟一个人开发也不容易（小声）……")), "求赞助啦……", "这就赞助！", "但是我拒绝", "", false, true, false) == 1)
					{
						ModBase.OpenWebsite("https://afdian.net/@LTCat/plan");
					}
				}) : ModLaunch._Closure$__.$I8-1, "Donate", ThreadPriority.Normal);
			}
		}

		// Token: 0x06000996 RID: 2454 RVA: 0x00045870 File Offset: 0x00043A70
		public static string McLoginName()
		{
			object left = ModBase._ParamsState.Get("LoginType", null);
			if (Operators.ConditionalCompareObjectEqual(left, ModLaunch.McLoginType.Mojang, true))
			{
				if (Operators.ConditionalCompareObjectNotEqual(ModBase._ParamsState.Get("CacheMojangName", null), "", true))
				{
					return Conversions.ToString(ModBase._ParamsState.Get("CacheMojangName", null));
				}
			}
			else if (Operators.ConditionalCompareObjectEqual(left, ModLaunch.McLoginType.Ms, true))
			{
				if (Operators.ConditionalCompareObjectNotEqual(ModBase._ParamsState.Get("CacheMsName", null), "", true))
				{
					return Conversions.ToString(ModBase._ParamsState.Get("CacheMsName", null));
				}
			}
			else if (Operators.ConditionalCompareObjectEqual(left, ModLaunch.McLoginType.Legacy, true))
			{
				if (Operators.ConditionalCompareObjectNotEqual(ModBase._ParamsState.Get("LoginLegacyName", null), "", true))
				{
					return ModBase._ParamsState.Get("LoginLegacyName", null).ToString().Split(new char[]
					{
						'¨'
					})[0];
				}
			}
			else if (Operators.ConditionalCompareObjectEqual(left, ModLaunch.McLoginType.Nide, true))
			{
				if (Operators.ConditionalCompareObjectNotEqual(ModBase._ParamsState.Get("CacheNideName", null), "", true))
				{
					return Conversions.ToString(ModBase._ParamsState.Get("CacheNideName", null));
				}
			}
			else if (Operators.ConditionalCompareObjectEqual(left, ModLaunch.McLoginType.Auth, true) && Operators.ConditionalCompareObjectNotEqual(ModBase._ParamsState.Get("CacheAuthName", null), "", true))
			{
				return Conversions.ToString(ModBase._ParamsState.Get("CacheAuthName", null));
			}
			string result;
			if (Operators.ConditionalCompareObjectNotEqual(ModBase._ParamsState.Get("CacheMsName", null), "", true))
			{
				result = Conversions.ToString(ModBase._ParamsState.Get("CacheMsName", null));
			}
			else if (Operators.ConditionalCompareObjectNotEqual(ModBase._ParamsState.Get("CacheMojangName", null), "", true))
			{
				result = Conversions.ToString(ModBase._ParamsState.Get("CacheMojangName", null));
			}
			else if (Operators.ConditionalCompareObjectNotEqual(ModBase._ParamsState.Get("CacheNideName", null), "", true))
			{
				result = Conversions.ToString(ModBase._ParamsState.Get("CacheNideName", null));
			}
			else if (Operators.ConditionalCompareObjectNotEqual(ModBase._ParamsState.Get("CacheAuthName", null), "", true))
			{
				result = Conversions.ToString(ModBase._ParamsState.Get("CacheAuthName", null));
			}
			else if (Operators.ConditionalCompareObjectNotEqual(ModBase._ParamsState.Get("LoginLegacyName", null), "", true))
			{
				result = ModBase._ParamsState.Get("LoginLegacyName", null).ToString().Split(new char[]
				{
					'¨'
				})[0];
			}
			else
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000997 RID: 2455 RVA: 0x00045B3C File Offset: 0x00043D3C
		public static string McLoginAble()
		{
			object left = ModBase._ParamsState.Get("LoginType", null);
			string result;
			if (Operators.ConditionalCompareObjectEqual(left, ModLaunch.McLoginType.Mojang, true))
			{
				if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("CacheMojangAccess", null), "", true))
				{
					result = ModMain._ServerAccount.IsVaild();
				}
				else
				{
					result = "";
				}
			}
			else if (Operators.ConditionalCompareObjectEqual(left, ModLaunch.McLoginType.Ms, true))
			{
				if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("CacheMsOAuthRefresh", null), "", true))
				{
					result = ModMain.candidateAccount.IsVaild();
				}
				else
				{
					result = "";
				}
			}
			else if (Operators.ConditionalCompareObjectEqual(left, ModLaunch.McLoginType.Legacy, true))
			{
				result = ModMain._ImporterAccount.IsVaild();
			}
			else if (Operators.ConditionalCompareObjectEqual(left, ModLaunch.McLoginType.Nide, true))
			{
				if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("CacheNideAccess", null), "", true))
				{
					result = ModMain._ProxyAccount.IsVaild();
				}
				else
				{
					result = "";
				}
			}
			else if (Operators.ConditionalCompareObjectEqual(left, ModLaunch.McLoginType.Auth, true))
			{
				if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("CacheAuthAccess", null), "", true))
				{
					result = ModMain.m_RegistryAccount.IsVaild();
				}
				else
				{
					result = "";
				}
			}
			else
			{
				result = "未知的登录方式";
			}
			return result;
		}

		// Token: 0x06000998 RID: 2456 RVA: 0x00045C90 File Offset: 0x00043E90
		public static string McLoginAble(ModLaunch.McLoginData LoginData)
		{
			switch (LoginData.Type)
			{
			case ModLaunch.McLoginType.Legacy:
				return PageLoginLegacy.IsVaild((ModLaunch.McLoginLegacy)LoginData);
			case ModLaunch.McLoginType.Mojang:
				return PageLoginMojang.IsVaild((ModLaunch.McLoginServer)LoginData);
			case ModLaunch.McLoginType.Nide:
				return PageLoginNide.IsVaild((ModLaunch.McLoginServer)LoginData);
			case ModLaunch.McLoginType.Auth:
				return PageLoginAuth.IsVaild((ModLaunch.McLoginServer)LoginData);
			case ModLaunch.McLoginType.Ms:
				return PageLoginMs.IsVaild((ModLaunch.McLoginMs)LoginData);
			}
			return "未知的登录方式";
		}

		// Token: 0x06000999 RID: 2457 RVA: 0x00045D14 File Offset: 0x00043F14
		public static ModLaunch.McLoginData McLoginInput()
		{
			ModLaunch.McLoginData result = null;
			ModLaunch.McLoginType mcLoginType = (ModLaunch.McLoginType)Conversions.ToInteger(ModBase._ParamsState.Get("LoginType", null));
			try
			{
				switch (mcLoginType)
				{
				case ModLaunch.McLoginType.Legacy:
					result = PageLoginLegacy.GetLoginData();
					break;
				case ModLaunch.McLoginType.Mojang:
					if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("CacheMojangAccess", null), "", true))
					{
						result = PageLoginMojang.GetLoginData();
					}
					else
					{
						result = PageLoginMojangSkin.GetLoginData();
					}
					break;
				case ModLaunch.McLoginType.Nide:
					if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("CacheNideAccess", null), "", true))
					{
						result = PageLoginNide.GetLoginData();
					}
					else
					{
						result = PageLoginNideSkin.GetLoginData();
					}
					break;
				case ModLaunch.McLoginType.Auth:
					if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("CacheAuthAccess", null), "", true))
					{
						result = PageLoginAuth.GetLoginData();
					}
					else
					{
						result = PageLoginAuthSkin.GetLoginData();
					}
					break;
				case ModLaunch.McLoginType.Ms:
					if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("CacheMsOAuthRefresh", null), "", true))
					{
						result = PageLoginMs.GetLoginData();
					}
					else
					{
						result = PageLoginMsSkin.GetLoginData();
					}
					break;
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "获取登录输入信息失败（" + ModBase.GetStringFromEnum(mcLoginType) + "）", ModBase.LogLevel.Feedback, "出现错误");
			}
			return result;
		}

		// Token: 0x0600099A RID: 2458 RVA: 0x00045E68 File Offset: 0x00044068
		private static void McLoginStart(ModLoader.LoaderTask<ModLaunch.McLoginData, ModLaunch.McLoginResult> Data)
		{
			ModLaunch.McLaunchLog("登录线程已启动");
			string text = ModLaunch.McLoginAble(Data.Input);
			if (Operators.CompareString(text, "", true) != 0)
			{
				throw new ArgumentException(text);
			}
			ModLoader.LoaderBase loaderBase = null;
			switch (Data.Input.Type)
			{
			case ModLaunch.McLoginType.Legacy:
				loaderBase = ModLaunch._GetterTag;
				break;
			case ModLaunch.McLoginType.Mojang:
				loaderBase = ModLaunch.templateTag;
				break;
			case ModLaunch.McLoginType.Nide:
				loaderBase = ModLaunch.listenerTag;
				break;
			case ModLaunch.McLoginType.Auth:
				loaderBase = ModLaunch._IdentifierTag;
				break;
			case ModLaunch.McLoginType.Ms:
				loaderBase = ModLaunch._ExpressionTag;
				break;
			}
			loaderBase.WaitForExit(Data.Input, ModLaunch.m_IndexerTag, Data.IsForceRestarting);
			object obj = NewLateBinding.LateGet(loaderBase, null, "Output", new object[0], null, null, null);
			Data.Output = ((obj != null) ? ((ModLaunch.McLoginResult)obj) : default(ModLaunch.McLoginResult));
			ModBase.RunInUi((ModLaunch._Closure$__.$I20-0 == null) ? (ModLaunch._Closure$__.$I20-0 = delegate()
			{
				ModMain._FilterAccount.RefreshPage(true, false);
			}) : ModLaunch._Closure$__.$I20-0, false);
		}

		// Token: 0x0600099B RID: 2459 RVA: 0x00045F68 File Offset: 0x00044168
		private static void McLoginMsStart(ModLoader.LoaderTask<ModLaunch.McLoginMs, ModLaunch.McLoginResult> Data)
		{
			ModLaunch.McLoginMs input = Data.Input;
			string dicProccesor = input._DicProccesor;
			ModLaunch.McLaunchLog("登录方式：微软正版（" + ((Operators.CompareString(dicProccesor, "", true) == 0) ? "尚未登录" : dicProccesor) + "）");
			Data.Progress = 0.05;
			if (Operators.CompareString(input.m_RulesProccesor, "", true) != 0 && !Data.IsForceRestarting)
			{
				Data.Output = new ModLaunch.McLoginResult
				{
					m_MerchantProccesor = input.m_RulesProccesor,
					Name = input._DicProccesor,
					ruleProccesor = input._WorkerProccesor,
					Type = "Microsoft",
					m_ExporterProccesor = input._WorkerProccesor
				};
			}
			else
			{
				string[] array;
				if (!Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("CacheMsOAuthRefresh", null), "", true))
				{
					array = ModLaunch.MsLoginStep2(Conversions.ToString(ModBase._ParamsState.Get("CacheMsOAuthRefresh", null)), true);
					goto IL_119;
				}
				IL_F2:
				string code = ModLaunch.MsLoginStep1(Data);
				if (Data.IsAborted)
				{
					throw new ThreadInterruptedException();
				}
				Data.Progress = 0.2;
				array = ModLaunch.MsLoginStep2(code, false);
				IL_119:
				if (Operators.CompareString(array[0], "Relogin", true) == 0)
				{
					goto IL_F2;
				}
				Data.Progress = 0.35;
				if (Data.IsAborted)
				{
					throw new ThreadInterruptedException();
				}
				string accessToken = array[0];
				string value = array[1];
				string xbltoken = ModLaunch.MsLoginStep3(accessToken);
				Data.Progress = 0.5;
				if (Data.IsAborted)
				{
					throw new ThreadInterruptedException();
				}
				string[] tokens = ModLaunch.MsLoginStep4(xbltoken);
				Data.Progress = 0.65;
				if (Data.IsAborted)
				{
					throw new ThreadInterruptedException();
				}
				string text = ModLaunch.MsLoginStep5(tokens);
				Data.Progress = 0.8;
				if (Data.IsAborted)
				{
					throw new ThreadInterruptedException();
				}
				string[] array2 = ModLaunch.MsLoginStep6(text);
				ModBase._ParamsState.Set("CacheMsOAuthRefresh", value, false, null);
				ModBase._ParamsState.Set("CacheMsAccess", text, false, null);
				ModBase._ParamsState.Set("CacheMsUuid", array2[0], false, null);
				ModBase._ParamsState.Set("CacheMsName", array2[1], false, null);
				Data.Output = new ModLaunch.McLoginResult
				{
					m_MerchantProccesor = text,
					Name = array2[1],
					ruleProccesor = array2[0],
					Type = "Microsoft",
					m_ExporterProccesor = array2[0],
					_GlobalProccesor = array2[2]
				};
			}
			ModLaunch.McLaunchLog("微软登录完成");
			Data.Progress = 0.95;
			if (ModMain.ThemeUnlock(10, false, null))
			{
				ModMain.MyMsgBox("感谢你对正版游戏的支持！\r\n隐藏主题 跳票红 已解锁！", "提示", "确定", "", "", false, true, false);
			}
		}

		// Token: 0x0600099C RID: 2460 RVA: 0x00046224 File Offset: 0x00044424
		private static void McLoginServerStart(ModLoader.LoaderTask<ModLaunch.McLoginServer, ModLaunch.McLoginResult> Data)
		{
			ModLaunch._Closure$__27-0 CS$<>8__locals1 = new ModLaunch._Closure$__27-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Local_Data = Data;
			ModLaunch.McLoginServer input = CS$<>8__locals1.$VB$Local_Data.Input;
			bool flag = false;
			string text = input.m_InterpreterProccesor;
			if (Conversions.ToBoolean(text.Contains("@") && Conversions.ToBoolean(ModBase._ParamsState.Get("UiLauncherEmail", null))))
			{
				text = ModMinecraft.AccountFilter(text);
			}
			ModLaunch.McLaunchLog(string.Concat(new string[]
			{
				"登录方式：",
				input._ExceptionProccesor,
				"（",
				text,
				"）"
			}));
			CS$<>8__locals1.$VB$Local_Data.Progress = 0.05;
			if (!Conversions.ToBoolean(!CS$<>8__locals1.$VB$Local_Data.Input._TestsProccesor && Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("Cache" + input.m_ErrorProccesor + "Username", null), CS$<>8__locals1.$VB$Local_Data.Input.m_InterpreterProccesor, true) && Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("Cache" + input.m_ErrorProccesor + "Pass", null), CS$<>8__locals1.$VB$Local_Data.Input._ParserProccesor, true) && Conversions.ToBoolean(Operators.NotObject(Operators.CompareObjectEqual(ModBase._ParamsState.Get("Cache" + input.m_ErrorProccesor + "Access", null), "", true))) && Conversions.ToBoolean(Operators.NotObject(Operators.CompareObjectEqual(ModBase._ParamsState.Get("Cache" + input.m_ErrorProccesor + "Client", null), "", true))) && Conversions.ToBoolean(Operators.NotObject(Operators.CompareObjectEqual(ModBase._ParamsState.Get("Cache" + input.m_ErrorProccesor + "Uuid", null), "", true))) && Conversions.ToBoolean(Operators.NotObject(Operators.CompareObjectEqual(ModBase._ParamsState.Get("Cache" + input.m_ErrorProccesor + "Name", null), "", true)))))
			{
				goto IL_389;
			}
			try
			{
				if (CS$<>8__locals1.$VB$Local_Data.IsAborted)
				{
					throw new ThreadInterruptedException();
				}
				ModLaunch.McLoginRequestValidate(ref CS$<>8__locals1.$VB$Local_Data);
				goto IL_38F;
			}
			catch (Exception ex)
			{
				string @string = ModBase.GetString(ex, true, false);
				ModLaunch.McLaunchLog("验证登录失败：" + @string);
				if ((@string.Contains("超时") || @string.Contains("imeout")) && !@string.Contains("403"))
				{
					ModLaunch.McLaunchLog("已触发超时登录失败");
					throw new Exception("$登录失败：连接登录服务器超时。\r\n请检查你的网络状况是否良好，或尝试使用 VPN！");
				}
			}
			CS$<>8__locals1.$VB$Local_Data.Progress = 0.25;
			IL_31E:
			try
			{
				if (CS$<>8__locals1.$VB$Local_Data.IsAborted)
				{
					throw new ThreadInterruptedException();
				}
				ModLaunch.McLoginRequestRefresh(ref CS$<>8__locals1.$VB$Local_Data, flag);
				goto IL_38F;
			}
			catch (Exception ex2)
			{
				ModLaunch.McLaunchLog("刷新登录失败：" + ModBase.GetString(ex2, true, false));
			}
			CS$<>8__locals1.$VB$Local_Data.Progress = (flag ? 0.85 : 0.45);
			IL_389:
			try
			{
				if (CS$<>8__locals1.$VB$Local_Data.IsAborted)
				{
					throw new ThreadInterruptedException();
				}
				flag = ModLaunch.McLoginRequestLogin(ref CS$<>8__locals1.$VB$Local_Data);
			}
			catch (Exception ex3)
			{
				ModLaunch.McLaunchLog("登录失败：" + ModBase.GetString(ex3, true, false));
				throw;
			}
			if (flag)
			{
				CS$<>8__locals1.$VB$Local_Data.Progress = 0.65;
				goto IL_31E;
			}
			IL_38F:
			CS$<>8__locals1.$VB$Local_Data.Progress = 0.95;
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			List<string> list = new List<string>();
			List<string> list2 = new List<string>();
			checked
			{
				try
				{
					if (Conversions.ToBoolean(Operators.NotObject(Operators.CompareObjectEqual(ModBase._ParamsState.Get("Login" + input.m_ErrorProccesor + "Email", null), "", true))))
					{
						list.AddRange(ModBase._ParamsState.Get("Login" + input.m_ErrorProccesor + "Email", null).ToString().Split(new char[]
						{
							'¨'
						}));
					}
					if (Conversions.ToBoolean(Operators.NotObject(Operators.CompareObjectEqual(ModBase._ParamsState.Get("Login" + input.m_ErrorProccesor + "Pass", null), "", true))))
					{
						list2.AddRange(ModBase._ParamsState.Get("Login" + input.m_ErrorProccesor + "Pass", null).ToString().Split(new char[]
						{
							'¨'
						}));
					}
					int num = list.Count - 1;
					for (int i = 0; i <= num; i++)
					{
						dictionary.Add(list[i], list2[i]);
					}
					dictionary.Remove(input.m_InterpreterProccesor);
					list = new List<string>(dictionary.Keys);
					list.Insert(0, input.m_InterpreterProccesor);
					list2 = new List<string>(dictionary.Values);
					list2.Insert(0, input._ParserProccesor);
					ModBase._ParamsState.Set("Login" + input.m_ErrorProccesor + "Email", ModBase.Join(list, "¨"), false, null);
					ModBase._ParamsState.Set("Login" + input.m_ErrorProccesor + "Pass", ModBase.Join(list2, "¨"), false, null);
				}
				catch (Exception ex4)
				{
					ModBase.Log(ex4, "保存启动记录失败", ModBase.LogLevel.Hint, "出现错误");
					ModBase._ParamsState.Set("Login" + input.m_ErrorProccesor + "Email", "", false, null);
					ModBase._ParamsState.Set("Login" + input.m_ErrorProccesor + "Pass", "", false, null);
				}
				if (Operators.CompareString(input.m_ErrorProccesor, "Mojang", true) == 0 && ModMain.ThemeUnlock(10, false, null))
				{
					ModMain.MyMsgBox("感谢你对正版游戏的支持！\r\n隐藏主题 跳票红 已解锁！", "提示", "确定", "", "", false, true, false);
				}
				if (Operators.CompareString(input.m_ErrorProccesor, "Mojang", true) == 0)
				{
					ModBase.RunInThread(delegate
					{
						try
						{
							ModLaunch.McLaunchLog("Mojang 账号已登录，正在检查账号迁移");
							JObject jobject = (JObject)ModBase.GetJson(ModNet.NetRequestRetry("https://api.minecraftservices.com/rollout/v1/msamigration", "GET", "", "", true, new Dictionary<string, string>
							{
								{
									"Authorization",
									"Bearer " + CS$<>8__locals1.$VB$Local_Data.Output.m_MerchantProccesor
								}
							}));
							if (jobject["rollout"] != null)
							{
								bool flag2 = jobject["rollout"].ToObject<bool>();
								ModLaunch.McLaunchLog("账号迁移检查结果：" + Conversions.ToString(flag2));
								if (flag2)
								{
									ModBase.RunInUi((ModLaunch._Closure$__.$I27-1 == null) ? (ModLaunch._Closure$__.$I27-1 = delegate()
									{
										ModMain._ReaderAccount.PanMs.Visibility = Visibility.Visible;
									}) : ModLaunch._Closure$__.$I27-1, false);
								}
							}
						}
						catch (Exception ex5)
						{
							ModBase.Log(ex5, "账号迁移检查失败", ModBase.LogLevel.Debug, "出现错误");
						}
					});
				}
			}
		}

		// Token: 0x0600099D RID: 2461 RVA: 0x000468E4 File Offset: 0x00044AE4
		private static void McLoginLegacyStart(ModLoader.LoaderTask<ModLaunch.McLoginLegacy, ModLaunch.McLoginResult> Data)
		{
			ModLaunch.McLoginLegacy input = Data.Input;
			ModLaunch.McLaunchLog("登录方式：离线（" + input._ConfigurationProccesor + "）");
			Data.Progress = 0.1;
			Data.Output.Name = input._ConfigurationProccesor;
			Data.Output.ruleProccesor = Conversions.ToString(ModLaunch.McLoginLegacyUuid(input._ConfigurationProccesor));
			Data.Output.Type = "Legacy";
			checked
			{
				switch (input.m_ConfigProccesor)
				{
				case 0:
					goto IL_37C;
				case 1:
					while (Operators.CompareString(ModMinecraft.McSkinSex(Data.Output.ruleProccesor), "Steve", true) != 0)
					{
						if (Data.Output.ruleProccesor.EndsWith("FFFFF"))
						{
							Data.Output.ruleProccesor = Strings.Mid(Data.Output.ruleProccesor, 1, 27) + "00000";
						}
						Data.Output.ruleProccesor = Strings.Mid(Data.Output.ruleProccesor, 1, 27) + (long.Parse(Strings.Right(Data.Output.ruleProccesor, 5), NumberStyles.AllowHexSpecifier) + 1L).ToString("X");
					}
					goto IL_37C;
				case 2:
					while (Operators.CompareString(ModMinecraft.McSkinSex(Data.Output.ruleProccesor), "Alex", true) != 0)
					{
						if (Data.Output.ruleProccesor.EndsWith("FFFFF"))
						{
							Data.Output.ruleProccesor = Strings.Mid(Data.Output.ruleProccesor, 1, 27) + "00000";
						}
						Data.Output.ruleProccesor = Strings.Mid(Data.Output.ruleProccesor, 1, 27) + (long.Parse(Strings.Right(Data.Output.ruleProccesor, 5), NumberStyles.AllowHexSpecifier) + 1L).ToString("X");
					}
					goto IL_37C;
				case 3:
					try
					{
						if (Operators.CompareString(input.managerProccesor, "", true) != 0)
						{
							ModBase.Log("[Skin] 由于离线皮肤设置，使用正版 UUID：" + input.managerProccesor, ModBase.LogLevel.Normal, "出现错误");
							Data.Output.ruleProccesor = Conversions.ToString(ModLaunch.McLoginMojangUuid(input.managerProccesor, false));
						}
						goto IL_37C;
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "离线启动时使用的正版皮肤获取失败", ModBase.LogLevel.Debug, "出现错误");
						ModMain.MyMsgBox("由于设置的离线启动时使用的正版皮肤获取失败，游戏将以无皮肤的方式启动。\r\n请检查你的网络是否通畅，或尝试使用 VPN！\r\n\r\n详细的错误信息：" + ex.Message, "皮肤获取失败", "确定", "", "", false, true, false);
						goto IL_37C;
					}
					break;
				case 4:
					break;
				default:
					goto IL_37C;
				}
				while (Operators.CompareString(ModMinecraft.McSkinSex(Data.Output.ruleProccesor), (!Conversions.ToBoolean(ModBase._ParamsState.Get("LaunchSkinSlim", null))) ? "Steve" : "Alex", true) != 0)
				{
					if (Data.Output.ruleProccesor.EndsWith("FFFFF"))
					{
						Data.Output.ruleProccesor = Strings.Mid(Data.Output.ruleProccesor, 1, 27) + "00000";
					}
					Data.Output.ruleProccesor = Strings.Mid(Data.Output.ruleProccesor, 1, 27) + (long.Parse(Strings.Right(Data.Output.ruleProccesor, 5), NumberStyles.AllowHexSpecifier) + 1L).ToString("X");
				}
				IL_37C:
				Data.Output.m_MerchantProccesor = Data.Output.ruleProccesor;
				Data.Output.m_ExporterProccesor = Data.Output.ruleProccesor;
				List<string> list = new List<string>();
				if (Conversions.ToBoolean(Operators.NotObject(Operators.CompareObjectEqual(ModBase._ParamsState.Get("LoginLegacyName", null), "", true))))
				{
					list.AddRange(ModBase._ParamsState.Get("LoginLegacyName", null).ToString().Split(new char[]
					{
						'¨'
					}));
				}
				list.Remove(input._ConfigurationProccesor);
				list.Insert(0, input._ConfigurationProccesor);
				ModBase._ParamsState.Set("LoginLegacyName", ModBase.Join(list.ToArray(), "¨"), false, null);
			}
		}

		// Token: 0x0600099E RID: 2462 RVA: 0x00046D40 File Offset: 0x00044F40
		private static void McLoginRequestValidate(ref ModLoader.LoaderTask<ModLaunch.McLoginServer, ModLaunch.McLoginResult> Data)
		{
			ModLaunch.McLaunchLog("验证登录开始（Validate, " + Data.Input.m_ErrorProccesor + "）");
			string text = Conversions.ToString(ModBase._ParamsState.Get("Cache" + Data.Input.m_ErrorProccesor + "Access", null));
			string text2 = Conversions.ToString(ModBase._ParamsState.Get("Cache" + Data.Input.m_ErrorProccesor + "Client", null));
			string ruleProccesor = Conversions.ToString(ModBase._ParamsState.Get("Cache" + Data.Input.m_ErrorProccesor + "Uuid", null));
			string name = Conversions.ToString(ModBase._ParamsState.Get("Cache" + Data.Input.m_ErrorProccesor + "Name", null));
			ModNet.NetRequestRetry(Data.Input._StubProccesor + "/validate", "POST", string.Concat(new string[]
			{
				"{\"accessToken\":\"",
				text,
				"\",\"clientToken\":\"",
				text2,
				"\",\"requestUser\":true}"
			}), "application/json; charset=utf-8", true, null);
			Data.Output.m_MerchantProccesor = text;
			Data.Output.m_ExporterProccesor = text2;
			Data.Output.ruleProccesor = ruleProccesor;
			Data.Output.Name = name;
			Data.Output.Type = Data.Input.m_ErrorProccesor;
			Data.Output._QueueProccesor = Data.Input.m_InterpreterProccesor;
			ModLaunch.McLaunchLog("验证登录成功（Validate, " + Data.Input.m_ErrorProccesor + "）");
		}

		// Token: 0x0600099F RID: 2463 RVA: 0x00046EF4 File Offset: 0x000450F4
		private static void McLoginRequestRefresh(ref ModLoader.LoaderTask<ModLaunch.McLoginServer, ModLaunch.McLoginResult> Data, bool RequestUser)
		{
			ModLaunch.McLaunchLog("刷新登录开始（Refresh, " + Data.Input.m_ErrorProccesor + "）");
			JObject jobject = (JObject)ModBase.GetJson(ModNet.NetRequestRetry(Data.Input._StubProccesor + "/refresh", "POST", Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("{", RequestUser ? Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("\r\n               \"requestUser\": true,\r\n               \"selectedProfile\": {\r\n                   \"id\":\"", ModBase._ParamsState.Get("Cache" + Data.Input.m_ErrorProccesor + "Uuid", null)), "\",\r\n                   \"name\":\""), ModBase._ParamsState.Get("Cache" + Data.Input.m_ErrorProccesor + "Name", null)), "\"},") : ""), "\r\n               \"accessToken\":\""), ModBase._ParamsState.Get("Cache" + Data.Input.m_ErrorProccesor + "Access", null)), "\",\r\n               \"clientToken\":\""), ModBase._ParamsState.Get("Cache" + Data.Input.m_ErrorProccesor + "Client", null)), "\"}"), "application/json; charset=utf-8", true, null));
			if (jobject["selectedProfile"] == null)
			{
				throw new Exception(Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("选择的角色 ", ModBase._ParamsState.Get("Cache" + Data.Input.m_ErrorProccesor + "Name", null)), " 无效！")));
			}
			Data.Output.m_MerchantProccesor = jobject["accessToken"].ToString();
			Data.Output.m_ExporterProccesor = jobject["clientToken"].ToString();
			Data.Output.ruleProccesor = jobject["selectedProfile"]["id"].ToString();
			Data.Output.Name = jobject["selectedProfile"]["name"].ToString();
			Data.Output.Type = Data.Input.m_ErrorProccesor;
			Data.Output._QueueProccesor = Data.Input.m_InterpreterProccesor;
			ModBase._ParamsState.Set("Cache" + Data.Input.m_ErrorProccesor + "Access", Data.Output.m_MerchantProccesor, false, null);
			ModBase._ParamsState.Set("Cache" + Data.Input.m_ErrorProccesor + "Client", Data.Output.m_ExporterProccesor, false, null);
			ModBase._ParamsState.Set("Cache" + Data.Input.m_ErrorProccesor + "Uuid", Data.Output.ruleProccesor, false, null);
			ModBase._ParamsState.Set("Cache" + Data.Input.m_ErrorProccesor + "Name", Data.Output.Name, false, null);
			ModBase._ParamsState.Set("Cache" + Data.Input.m_ErrorProccesor + "Username", Data.Input.m_InterpreterProccesor, false, null);
			ModBase._ParamsState.Set("Cache" + Data.Input.m_ErrorProccesor + "Pass", Data.Input._ParserProccesor, false, null);
			ModLaunch.McLaunchLog("刷新登录成功（Refresh, " + Data.Input.m_ErrorProccesor + "）");
		}

		// Token: 0x060009A0 RID: 2464 RVA: 0x000472A4 File Offset: 0x000454A4
		private static bool McLoginRequestLogin(ref ModLoader.LoaderTask<ModLaunch.McLoginServer, ModLaunch.McLoginResult> Data)
		{
			bool result;
			try
			{
				ModLaunch._Closure$__31-0 CS$<>8__locals1 = new ModLaunch._Closure$__31-0(CS$<>8__locals1);
				bool flag = false;
				ModLaunch.McLaunchLog("登录开始（Login, " + Data.Input.m_ErrorProccesor + "）");
				CS$<>8__locals1.$VB$Local_LoginJson = (JObject)ModBase.GetJson(ModNet.NetRequestRetry(Data.Input._StubProccesor + "/authenticate", "POST", string.Concat(new string[]
				{
					"{\"agent\": {\"name\": \"Minecraft\",\"version\": 1},\"username\":\"",
					Data.Input.m_InterpreterProccesor,
					"\",\"password\":\"",
					Data.Input._ParserProccesor,
					"\",\"requestUser\":true}"
				}), "application/json; charset=utf-8", true, null));
				if (CS$<>8__locals1.$VB$Local_LoginJson["availableProfiles"].Count<JToken>() == 0)
				{
					if (Data.Input.Type == ModLaunch.McLoginType.Auth)
					{
						if (Data.Input._TestsProccesor)
						{
							ModMain.Hint("你还没有创建角色，无法更换！", ModMain.HintType.Critical, true);
						}
						throw new Exception("$你还没有创建角色，请在创建角色后再试！");
					}
					throw new Exception("$你还没有购买 Minecraft 正版，请在购买后再试！");
				}
				else
				{
					if (Data.Input._TestsProccesor && CS$<>8__locals1.$VB$Local_LoginJson["availableProfiles"].Count<JToken>() == 1)
					{
						ModMain.Hint("你的账户中只有一个角色，无法更换！", ModMain.HintType.Critical, true);
					}
					CS$<>8__locals1.$VB$Local_SelectedName = null;
					CS$<>8__locals1.$VB$Local_SelectedId = null;
					if ((CS$<>8__locals1.$VB$Local_LoginJson["selectedProfile"] == null || Data.Input._TestsProccesor) && CS$<>8__locals1.$VB$Local_LoginJson["availableProfiles"].Count<JToken>() > 1)
					{
						flag = true;
						string right = Conversions.ToString(ModBase._ParamsState.Get("Cache" + Data.Input.m_ErrorProccesor + "Uuid", null));
						try
						{
							foreach (JToken jtoken in CS$<>8__locals1.$VB$Local_LoginJson["availableProfiles"])
							{
								if (Operators.CompareString(jtoken["id"].ToString(), right, true) == 0)
								{
									CS$<>8__locals1.$VB$Local_SelectedName = jtoken["name"].ToString();
									CS$<>8__locals1.$VB$Local_SelectedId = jtoken["id"].ToString();
									ModLaunch.McLaunchLog("根据缓存选择的角色：" + CS$<>8__locals1.$VB$Local_SelectedName);
								}
							}
						}
						finally
						{
							IEnumerator<JToken> enumerator;
							if (enumerator != null)
							{
								enumerator.Dispose();
							}
						}
						if (CS$<>8__locals1.$VB$Local_SelectedName == null)
						{
							ModLaunch.McLaunchLog("要求玩家选择角色");
							ModBase.RunInUiWait(delegate
							{
								List<IMyRadio> list = new List<IMyRadio>();
								List<JToken> list2 = new List<JToken>();
								try
								{
									foreach (JToken jtoken2 in CS$<>8__locals1.$VB$Local_LoginJson["availableProfiles"])
									{
										list.Add(new MyRadioBox
										{
											Text = jtoken2["name"].ToString()
										});
										list2.Add(jtoken2);
									}
								}
								finally
								{
									IEnumerator<JToken> enumerator2;
									if (enumerator2 != null)
									{
										enumerator2.Dispose();
									}
								}
								int value = ModMain.MyMsgBoxSelect(list, "选择使用的角色", "确定", "", false).Value;
								CS$<>8__locals1.$VB$Local_SelectedName = list2[value]["name"].ToString();
								CS$<>8__locals1.$VB$Local_SelectedId = list2[value]["id"].ToString();
							});
							ModLaunch.McLaunchLog("玩家选择的角色：" + CS$<>8__locals1.$VB$Local_SelectedName);
						}
					}
					else
					{
						CS$<>8__locals1.$VB$Local_SelectedName = CS$<>8__locals1.$VB$Local_LoginJson["selectedProfile"]["name"].ToString();
						CS$<>8__locals1.$VB$Local_SelectedId = CS$<>8__locals1.$VB$Local_LoginJson["selectedProfile"]["id"].ToString();
					}
					Data.Output.m_MerchantProccesor = CS$<>8__locals1.$VB$Local_LoginJson["accessToken"].ToString();
					Data.Output.m_ExporterProccesor = CS$<>8__locals1.$VB$Local_LoginJson["clientToken"].ToString();
					Data.Output.Name = CS$<>8__locals1.$VB$Local_SelectedName;
					Data.Output.ruleProccesor = CS$<>8__locals1.$VB$Local_SelectedId;
					Data.Output.Type = Data.Input.m_ErrorProccesor;
					Data.Output._QueueProccesor = Data.Input.m_InterpreterProccesor;
					ModBase._ParamsState.Set("Cache" + Data.Input.m_ErrorProccesor + "Access", Data.Output.m_MerchantProccesor, false, null);
					ModBase._ParamsState.Set("Cache" + Data.Input.m_ErrorProccesor + "Client", Data.Output.m_ExporterProccesor, false, null);
					ModBase._ParamsState.Set("Cache" + Data.Input.m_ErrorProccesor + "Uuid", Data.Output.ruleProccesor, false, null);
					ModBase._ParamsState.Set("Cache" + Data.Input.m_ErrorProccesor + "Name", Data.Output.Name, false, null);
					ModBase._ParamsState.Set("Cache" + Data.Input.m_ErrorProccesor + "Username", Data.Input.m_InterpreterProccesor, false, null);
					ModBase._ParamsState.Set("Cache" + Data.Input.m_ErrorProccesor + "Pass", Data.Input._ParserProccesor, false, null);
					ModLaunch.McLaunchLog("登录成功（Login, " + Data.Input.m_ErrorProccesor + "）");
					result = flag;
				}
			}
			catch (Exception ex)
			{
				string @string = ModBase.GetString(ex, true, false);
				ModBase.Log(ex, "登录失败原始错误信息", ModBase.LogLevel.Normal, "出现错误");
				if (@string.Contains("410") && @string.Contains("Migrated"))
				{
					throw new Exception("$登录失败：该 Mojang 账号已迁移至微软账号，请在上方的登录方式中选择 微软 并再次尝试登录！");
				}
				if (@string.Contains("403"))
				{
					switch (Data.Input.Type)
					{
					case ModLaunch.McLoginType.Legacy:
						throw;
					case ModLaunch.McLoginType.Mojang:
						if (@string.Contains("Invalid username or password"))
						{
							throw new Exception("$登录失败：输入的账号或密码有误。");
						}
						throw new Exception("$登录尝试过于频繁，导致被 Mojang 暂时屏蔽。请不要操作，等待 10 分钟后再试。");
					case ModLaunch.McLoginType.Nide:
						throw new Exception("$登录失败，以下为可能的原因：\r\n - 输入的账号或密码错误。\r\n - 密码错误次数过多，导致被暂时屏蔽。请不要操作，等待 10 分钟后再试。\r\n" + (Data.Input.m_InterpreterProccesor.Contains("@") ? "" : " - 登录账号应为邮箱或统一通行证账号，而非游戏角色 ID。\r\n") + " - 只注册了账号，但没有加入对应服务器。");
					case ModLaunch.McLoginType.Auth:
						throw new Exception("$登录失败，以下为可能的原因：\r\n - 输入的账号或密码错误。\r\n - 登录尝试过于频繁，导致被暂时屏蔽。请不要操作，等待 10 分钟后再试。\r\n - 只注册了账号，但没有在皮肤站新建角色。");
					case ModLaunch.McLoginType.Ms:
						throw new Exception("$登录失败，以下为可能的原因：\r\n - 登录尝试过于频繁，导致被暂时屏蔽。请不要操作，等待 10 分钟后再试。\r\n - 账号类别错误。如果你在使用 Mojang 账号，请将登录方式切换为 Mojang。");
					}
					result = false;
				}
				else
				{
					if (@string.Contains("超时") || @string.Contains("imeout"))
					{
						throw new Exception("$登录失败：连接登录服务器超时。\r\n请检查你的网络状况是否良好，或尝试使用 VPN！");
					}
					if (@string.Contains("网络请求失败"))
					{
						throw new Exception("$登录失败：连接登录服务器失败。\r\n请检查你的网络状况是否良好，或尝试使用 VPN！");
					}
					if (ex.Message.StartsWith("$"))
					{
						throw;
					}
					throw new Exception("登录失败：" + ex.Message, ex);
				}
			}
			return result;
		}

		// Token: 0x060009A1 RID: 2465 RVA: 0x00047910 File Offset: 0x00045B10
		private static string MsLoginStep1(ModLoader.LoaderTask<ModLaunch.McLoginMs, ModLaunch.McLoginResult> Data)
		{
			ModLaunch.McLaunchLog("开始微软登录步骤 1");
			string result;
			if (ModBase.broadcasterState <= new Version(10, 0, 17763, 0))
			{
				ModMain.MyMsgBox("PCL2 即将打开登录网页。登录后会转到一个空白页面（这代表登录成功了），请将该空白页面的网址复制到 PCL2。\r\n如果网络环境不佳，登录网页可能一直加载不出来，此时请尝试使用 VPN 或代理服务器，然后再试。", "登录说明", "开始", "", "", false, true, true);
				ModBase.OpenWebsite(FormLoginOAuth.m_ContextRepository);
				string text = ModMain.MyMsgBoxInput("", new Collection<Validate>
				{
					new ValidateRegex("(?<=code\\=)[^&]+", "返回网址应以 https://login.live.com/oauth20_desktop.srf?code= 开头")
				}, "https://login.live.com/oauth20_desktop.srf?code=XXXXXX", "输入登录返回码", "确定", "取消", false);
				if (text == null)
				{
					ModLaunch.McLaunchLog("微软登录已在步骤 1 被取消");
					throw new ThreadInterruptedException("$$");
				}
				result = ModBase.RegexSeek(text, "(?<=code\\=)[^&]+", RegexOptions.None);
			}
			else
			{
				ModLaunch._Closure$__32-0 CS$<>8__locals1 = new ModLaunch._Closure$__32-0(CS$<>8__locals1);
				CS$<>8__locals1.$VB$Local_ReturnCode = null;
				CS$<>8__locals1.$VB$Local_ReturnEx = null;
				CS$<>8__locals1.$VB$Local_IsFinished = ModBase.LoadState.Loading;
				CS$<>8__locals1.$VB$Local_LoginForm = null;
				ModBase.RunInUi(delegate()
				{
					try
					{
						CS$<>8__locals1.$VB$Local_LoginForm = new FormLoginOAuth();
						CS$<>8__locals1.$VB$Local_LoginForm.Show();
						CS$<>8__locals1.$VB$Local_LoginForm.LoginRepository((CS$<>8__locals1.$I1 == null) ? (CS$<>8__locals1.$I1 = delegate(string Code)
						{
							CS$<>8__locals1.$VB$Local_ReturnCode = Code;
							CS$<>8__locals1.$VB$Local_IsFinished = ModBase.LoadState.Finished;
						}) : CS$<>8__locals1.$I1);
						CS$<>8__locals1.$VB$Local_LoginForm.MoveRepository((CS$<>8__locals1.$IR5 == null) ? (CS$<>8__locals1.$IR5 = delegate(bool a0)
						{
							((CS$<>8__locals1.$I2 == null) ? (CS$<>8__locals1.$I2 = delegate()
							{
								CS$<>8__locals1.$VB$Local_IsFinished = ModBase.LoadState.Aborted;
							}) : CS$<>8__locals1.$I2)();
						}) : CS$<>8__locals1.$IR5);
					}
					catch (Exception $VB$Local_ReturnEx)
					{
						CS$<>8__locals1.$VB$Local_ReturnEx = $VB$Local_ReturnEx;
						CS$<>8__locals1.$VB$Local_IsFinished = ModBase.LoadState.Failed;
					}
				}, false);
				while (CS$<>8__locals1.$VB$Local_IsFinished == ModBase.LoadState.Loading && !Data.IsAborted)
				{
					Thread.Sleep(20);
				}
				ModBase.RunInUi(delegate()
				{
					if (CS$<>8__locals1.$VB$Local_LoginForm != null)
					{
						CS$<>8__locals1.$VB$Local_LoginForm.Close();
					}
				}, false);
				if (CS$<>8__locals1.$VB$Local_IsFinished == ModBase.LoadState.Finished)
				{
					result = CS$<>8__locals1.$VB$Local_ReturnCode;
				}
				else
				{
					if (CS$<>8__locals1.$VB$Local_IsFinished == ModBase.LoadState.Failed)
					{
						throw CS$<>8__locals1.$VB$Local_ReturnEx;
					}
					ModLaunch.McLaunchLog("微软登录已在步骤 1 被取消");
					throw new ThreadInterruptedException("$$");
				}
			}
			return result;
		}

		// Token: 0x060009A2 RID: 2466 RVA: 0x00047A70 File Offset: 0x00045C70
		private static string[] MsLoginStep2(string Code, bool IsRefresh)
		{
			ModLaunch.McLaunchLog("开始微软登录步骤 2（" + (IsRefresh ? "" : "非") + "刷新登录）");
			string data;
			if (IsRefresh)
			{
				data = string.Concat(new string[]
				{
					"client_id=00000000402b5328&refresh_token=",
					Uri.EscapeDataString(Code),
					"&grant_type=refresh_token&redirect_uri=",
					Uri.EscapeDataString("https://login.live.com/oauth20_desktop.srf"),
					"&scope=",
					Uri.EscapeDataString("service::user.auth.xboxlive.com::MBI_SSL")
				});
			}
			else
			{
				data = string.Concat(new string[]
				{
					"client_id=00000000402b5328&code=",
					Uri.EscapeDataString(Code),
					"&grant_type=authorization_code&redirect_uri=",
					Uri.EscapeDataString("https://login.live.com/oauth20_desktop.srf"),
					"&scope=",
					Uri.EscapeDataString("service::user.auth.xboxlive.com::MBI_SSL")
				});
			}
			string data2;
			try
			{
				data2 = Conversions.ToString(ModNet.NetRequestMuity("https://login.live.com/oauth20_token.srf", "POST", data, "application/x-www-form-urlencoded", 1, null));
			}
			catch (Exception ex)
			{
				if (!ex.Message.Contains("must sign in again"))
				{
					throw;
				}
				return new string[]
				{
					"Relogin",
					""
				};
			}
			JObject jobject = (JObject)ModBase.GetJson(data2);
			string text = jobject["access_token"].ToString();
			string text2 = jobject["refresh_token"].ToString();
			return new string[]
			{
				text,
				text2
			};
		}

		// Token: 0x060009A3 RID: 2467 RVA: 0x00047BDC File Offset: 0x00045DDC
		private static string MsLoginStep3(string AccessToken)
		{
			ModLaunch.McLaunchLog("开始微软登录步骤 3");
			string data = "{\r\n                                    \"Properties\": {\r\n                                        \"AuthMethod\": \"RPS\",\r\n                                        \"SiteName\": \"user.auth.xboxlive.com\",\r\n                                        \"RpsTicket\": \"" + AccessToken + "\"\r\n                                    },\r\n                                    \"RelyingParty\": \"http://auth.xboxlive.com\",\r\n                                    \"TokenType\": \"JWT\"\r\n                                 }";
			return ((JObject)ModBase.GetJson(Conversions.ToString(ModNet.NetRequestMuity("https://user.auth.xboxlive.com/user/authenticate", "POST", data, "application/json", 3, null))))["Token"].ToString();
		}

		// Token: 0x060009A4 RID: 2468 RVA: 0x00047C3C File Offset: 0x00045E3C
		private static string[] MsLoginStep4(string XBLToken)
		{
			ModLaunch.McLaunchLog("开始微软登录步骤 4");
			string data = "{\r\n                                    \"Properties\": {\r\n                                        \"SandboxId\": \"RETAIL\",\r\n                                        \"UserTokens\": [\r\n                                            \"" + XBLToken + "\"\r\n                                        ]\r\n                                    },\r\n                                    \"RelyingParty\": \"rp://api.minecraftservices.com/\",\r\n                                    \"TokenType\": \"JWT\"\r\n                                 }";
			string data2;
			try
			{
				data2 = Conversions.ToString(ModNet.NetRequestMuity("https://xsts.auth.xboxlive.com/xsts/authorize", "POST", data, "application/json", 3, null));
			}
			catch (WebException ex)
			{
				if (ex.Message.Contains("2148916233"))
				{
					throw new Exception("$该微软账号尚未购买 Minecraft 或注册 XBox 账户！");
				}
				if (ex.Message.Contains("2148916238"))
				{
					if (ModMain.MyMsgBox("该账号年龄不足，你需要先修改出生日期，然后才能登录。\r\n该账号目前填写的年龄是否在 13 岁以上？", "登录提示", "13 岁以上", "12 岁以下", "我不知道", false, true, false) == 1)
					{
						ModBase.OpenWebsite("https://account.live.com/editprof.aspx");
						ModMain.MyMsgBox("请在打开的网页中修改账号的出生日期（建议改为 18 岁以上）。\r\n在修改成功后等待一分钟，然后再回到 PCL2，就可以正常登录了！", "登录提示", "确定", "", "", false, true, false);
					}
					else
					{
						ModBase.OpenWebsite("https://support.microsoft.com/zh-cn/account-billing/如何更改-microsoft-帐户上的出生日期-837badbc-999e-54d2-2617-d19206b9540a");
						ModMain.MyMsgBox("请根据打开的网页的说明，修改账号的出生日期（建议改为 18 岁以上）。\r\n在修改成功后等待一分钟，然后再回到 PCL2，就可以正常登录了！", "登录提示", "确定", "", "", false, true, false);
					}
					throw new Exception("$$");
				}
				throw;
			}
			JObject jobject = (JObject)ModBase.GetJson(data2);
			string text = jobject["Token"].ToString();
			string text2 = jobject["DisplayClaims"]["xui"][0]["uhs"].ToString();
			return new string[]
			{
				text,
				text2
			};
		}

		// Token: 0x060009A5 RID: 2469 RVA: 0x00047DB8 File Offset: 0x00045FB8
		private static string MsLoginStep5(string[] Tokens)
		{
			ModLaunch.McLaunchLog("开始微软登录步骤 5");
			string data = string.Concat(new string[]
			{
				"{\"identityToken\": \"XBL3.0 x=",
				Tokens[1],
				";",
				Tokens[0],
				"\"}"
			});
			string data2;
			try
			{
				data2 = Conversions.ToString(ModNet.NetRequestMuity("https://api.minecraftservices.com/authentication/login_with_xbox", "POST", data, "application/json", 2, null));
			}
			catch (WebException ex)
			{
				if (ModBase.GetString(ex, true, false).Contains("(429)"))
				{
					ModBase.Log(ex, "微软登录第 5 步汇报 429", ModBase.LogLevel.Debug, "出现错误");
					throw new Exception("$登录尝试太过频繁，请等待几分钟后再试！");
				}
				throw;
			}
			return ((JObject)ModBase.GetJson(data2))["access_token"].ToString();
		}

		// Token: 0x060009A6 RID: 2470 RVA: 0x00047E84 File Offset: 0x00046084
		private static string[] MsLoginStep6(string AccessToken)
		{
			ModLaunch.McLaunchLog("开始微软登录步骤 6");
			string text;
			try
			{
				text = Conversions.ToString(ModNet.NetRequestMuity("https://api.minecraftservices.com/minecraft/profile", "GET", "", "application/json", 2, new Dictionary<string, string>
				{
					{
						"Authorization",
						"Bearer " + AccessToken
					}
				}));
			}
			catch (WebException ex)
			{
				string @string = ModBase.GetString(ex, true, false);
				if (@string.Contains("(429)"))
				{
					ModBase.Log(ex, "微软登录第 6 步汇报 429", ModBase.LogLevel.Debug, "出现错误");
					throw new Exception("$登录尝试太过频繁，请等待几分钟后再试！");
				}
				if (@string.Contains("(404)"))
				{
					ModBase.Log(ex, "微软登录第 6 步汇报 404", ModBase.LogLevel.Debug, "出现错误");
					throw new Exception("$该微软账号尚未购买 Minecraft，或尚未创建游戏角色！");
				}
				throw;
			}
			JObject jobject = (JObject)ModBase.GetJson(text);
			string text2 = jobject["id"].ToString();
			string text3 = jobject["name"].ToString();
			return new string[]
			{
				text2,
				text3,
				text
			};
		}

		// Token: 0x060009A7 RID: 2471 RVA: 0x00047F90 File Offset: 0x00046190
		public static object McLoginMojangUuid(string Name, bool ThrowOnNotFound)
		{
			object result;
			if (Name.Trim().Length == 0)
			{
				result = ModBase.StrFill("", "0", 32);
			}
			else
			{
				string text = ModBase.ReadIni(ModBase.attributeState + "Cache\\Uuid\\Mojang.ini", Name, "");
				if (Strings.Len(text) == 32)
				{
					result = text;
				}
				else
				{
					try
					{
						JObject jobject = (JObject)ModNet.NetGetCodeByRequestRetry("https://api.mojang.com/users/profiles/minecraft/" + Name, null, "", true);
						if (jobject == null)
						{
							throw new FileNotFoundException("正版玩家档案不存在（" + Name + "）");
						}
						text = (string)(jobject["id"] ?? "");
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "从官网获取正版 Uuid 失败（" + Name + "）", ModBase.LogLevel.Debug, "出现错误");
						if (ThrowOnNotFound || Operators.CompareString(ex.GetType().Name, "FileNotFoundException", true) != 0)
						{
							throw new Exception("从官网获取正版 Uuid 失败", ex);
						}
						text = Conversions.ToString(ModLaunch.McLoginLegacyUuid(Name));
					}
					if (Strings.Len(text) != 32)
					{
						throw new Exception("获取的正版 Uuid 长度不足（" + text + "）");
					}
					ModBase.WriteIni(ModBase.attributeState + "Cache\\Uuid\\Mojang.ini", Name, text);
					result = text;
				}
			}
			return result;
		}

		// Token: 0x060009A8 RID: 2472 RVA: 0x000480EC File Offset: 0x000462EC
		public static object McLoginLegacyUuid(string Name)
		{
			string text = ModBase.StrFill(Name.Length.ToString("X"), "0", 16) + ModBase.StrFill(ModBase.GetHash(Name).ToString("X"), "0", 16);
			return string.Concat(new string[]
			{
				text.Substring(0, 12),
				"3",
				text.Substring(13, 3),
				"9",
				text.Substring(17, 15)
			});
		}

		// Token: 0x060009A9 RID: 2473 RVA: 0x00048180 File Offset: 0x00046380
		private static void McLaunchJavaValidate()
		{
			Version version = new Version(0, 0, 0, 0);
			Version version2 = new Version(999, 999, 999, 999);
			if ((DateTime.Compare(ModMinecraft.SetupResolver().m_MappingProccesor, new DateTime(2021, 11, 16)) >= 0 && ModMinecraft.SetupResolver().Version.tagParameter == 99) || (ModMinecraft.SetupResolver().Version.tagParameter >= 18 && ModMinecraft.SetupResolver().Version.tagParameter != 99))
			{
				version = new Version(1, 17, 0, 0);
			}
			else if ((DateTime.Compare(ModMinecraft.SetupResolver().m_MappingProccesor, new DateTime(2021, 5, 11)) >= 0 && ModMinecraft.SetupResolver().Version.tagParameter == 99) || (ModMinecraft.SetupResolver().Version.tagParameter >= 17 && ModMinecraft.SetupResolver().Version.tagParameter != 99))
			{
				version = new Version(1, 16, 0, 0);
			}
			else if (ModMinecraft.SetupResolver().m_MappingProccesor.Year >= 2017)
			{
				version = new Version(1, 8, 0, 0);
			}
			else if (ModMinecraft.SetupResolver().m_MappingProccesor.Year >= 2001)
			{
				version2 = new Version(1, 12, 999, 999);
			}
			if (ModMinecraft.SetupResolver().Version.requestParameter)
			{
				if (Operators.CompareString(ModMinecraft.SetupResolver().Version._ResolverParameter, "1.7.2", true) == 0)
				{
					version = new Version(1, 7, 0, 0);
					version2 = new Version(1, 7, 999, 999);
				}
				else if (ModMinecraft.SetupResolver().Version.tagParameter <= 12 && ModMinecraft.SetupResolver().Version.tagParameter != -1 && ModMinecraft.VersionSortBoolean("14.23.5.2855", ModMinecraft.SetupResolver().Version.m_AccountParameter))
				{
					version2 = new Version(1, 8, 999, 999);
				}
				else if (ModMinecraft.SetupResolver().Version.tagParameter <= 14 && ModMinecraft.SetupResolver().Version.tagParameter != -1 && ModMinecraft.VersionSortBoolean("28.2.23", ModMinecraft.SetupResolver().Version.m_AccountParameter))
				{
					version = new Version(1, 8, 0, 0);
					version2 = new Version(1, 10, 999, 999);
				}
				else if (ModMinecraft.SetupResolver().Version.tagParameter <= 16 && ModMinecraft.SetupResolver().Version.tagParameter != -1)
				{
					version = new Version(1, 8, 0, 0);
					version2 = new Version(1, 15, 999, 999);
				}
			}
			if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LoginType", null), ModLaunch.McLoginType.Nide, true))
			{
				version = ((new Version(1, 8, 0, 101) > version) ? new Version(1, 8, 0, 101) : version);
			}
			ModLaunch.McLaunchLog("Java 版本需求：最低 " + version.ToString() + "，最高 " + version2.ToString());
			ModLaunch._InstanceTag = ModMinecraft.JavaSelect(version, version2, ModMinecraft.SetupResolver());
			if (ModLaunch._InstanceTag == null)
			{
				ModLaunch.McLaunchLog("无合适的 Java，取消启动");
				if (version >= new Version(1, 17, 0, 0))
				{
					ModMinecraft.JavaMissing(17);
				}
				else if (version >= new Version(1, 16, 0, 0))
				{
					ModMinecraft.JavaMissing(16);
				}
				else if (version2 < new Version(1, 8, 0, 0))
				{
					ModMinecraft.JavaMissing(7);
				}
				else
				{
					ModMinecraft.JavaMissing(8);
				}
				throw new Exception("$$");
			}
			ModLaunch.McLaunchLog("选择的 Java：" + ModLaunch._InstanceTag.ToString());
		}

		// Token: 0x060009AA RID: 2474 RVA: 0x0004850C File Offset: 0x0004670C
		private static void McLaunchArgumentMain(ModLoader.LoaderTask<string, List<ModMinecraft.McLibToken>> Loader)
		{
			ModLaunch.McLaunchLog("开始获取 Minecraft 启动参数");
			string text;
			if (ModMinecraft.SetupResolver().DestroyPrototype()["arguments"] != null && ModMinecraft.SetupResolver().DestroyPrototype()["arguments"]["jvm"] != null)
			{
				ModLaunch.McLaunchLog("获取新版 JVM 参数");
				text = ModLaunch.McLaunchArgumentsJvmNew(ModMinecraft.SetupResolver());
				ModLaunch.McLaunchLog("新版 JVM 参数获取成功：");
				ModLaunch.McLaunchLog(text);
			}
			else
			{
				ModLaunch.McLaunchLog("获取旧版 JVM 参数");
				text = ModLaunch.McLaunchArgumentsJvmOld(ModMinecraft.SetupResolver());
				ModLaunch.McLaunchLog("旧版 JVM 参数获取成功：");
				ModLaunch.McLaunchLog(text);
			}
			if (ModMinecraft.SetupResolver().DestroyPrototype()["minecraftArguments"] != null)
			{
				ModLaunch.McLaunchLog("获取旧版 Game 参数");
				text = text + " " + ModLaunch.McLaunchArgumentsGameOld(ModMinecraft.SetupResolver());
				ModLaunch.McLaunchLog("旧版 Game 参数获取成功");
			}
			if (ModMinecraft.SetupResolver().DestroyPrototype()["arguments"] != null && ModMinecraft.SetupResolver().DestroyPrototype()["arguments"]["game"] != null)
			{
				ModLaunch.McLaunchLog("获取新版 Game 参数");
				text = text + " " + ModLaunch.McLaunchArgumentsGameNew(ModMinecraft.SetupResolver());
				ModLaunch.McLaunchLog("新版 Game 参数获取成功");
			}
			Dictionary<string, string> dictionary = ModLaunch.McLaunchArgumentsReplace(ModMinecraft.SetupResolver(), ref Loader);
			if (string.IsNullOrWhiteSpace(dictionary["${version_type}"]))
			{
				text = text.Replace(" --versionType ${version_type}", "");
				dictionary["${version_type}"] = "\"\"";
			}
			try
			{
				foreach (KeyValuePair<string, string> keyValuePair in dictionary)
				{
					text = text.Replace(keyValuePair.Key, (keyValuePair.Value.Contains(" ") || keyValuePair.Value.Contains(":\\")) ? ("\"" + keyValuePair.Value + "\"") : keyValuePair.Value);
				}
			}
			finally
			{
				Dictionary<string, string>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			text = text.Replace(" -Dos.name=Windows 10 ", " -Dos.name=\"Windows 10\" ");
			if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LaunchArgumentWindowType", null), 0, true))
			{
				text += " --fullscreen";
			}
			string text2 = Conversions.ToString(string.IsNullOrEmpty(Loader.Input) ? ModBase._ParamsState.Get("VersionServerEnter", ModMinecraft.SetupResolver()) : Loader.Input);
			if (text2.Length > 0)
			{
				if (text2.Contains(":"))
				{
					text = string.Concat(new string[]
					{
						text,
						" --server ",
						text2.Split(new char[]
						{
							':'
						})[0],
						" --port ",
						text2.Split(new char[]
						{
							':'
						})[1]
					});
				}
				else
				{
					text = text + " --server " + text2 + " --port 25565";
				}
				if (ModMinecraft.SetupResolver().Version.m_PrototypeParameter)
				{
					ModMain.Hint("OptiFine 与自动进入服务器可能不兼容，有概率导致材质丢失甚至游戏崩溃！", ModMain.HintType.Critical, true);
				}
			}
			string text3 = Conversions.ToString(ModBase._ParamsState.Get("VersionAdvanceGame", ModMinecraft.SetupResolver()));
			text = Conversions.ToString(Operators.AddObject(text, Operators.ConcatenateObject(" ", (Operators.CompareString(text3, "", true) == 0) ? ModBase._ParamsState.Get("LaunchAdvanceGame", null) : text3)));
			ModLaunch.McLaunchLog("Minecraft 启动参数：");
			ModLaunch.McLaunchLog(text.Replace(ModLaunch.m_IndexerTag.Output.m_MerchantProccesor, ModLaunch.m_IndexerTag.Output.m_MerchantProccesor.Substring(0, 22) + "********" + ModLaunch.m_IndexerTag.Output.m_MerchantProccesor.Substring(30)));
			ModLaunch.m_CreatorTag = text;
		}

		// Token: 0x060009AB RID: 2475 RVA: 0x000488C8 File Offset: 0x00046AC8
		private static string McLaunchArgumentsJvmOld(ModMinecraft.McVersion Version)
		{
			List<string> list = new List<string>();
			list.Add("-XX:HeapDumpPath=MojangTricksIntelDriversForPerformance_javaw.exe_minecraft.exe.heapdump");
			string text = Conversions.ToString(ModBase._ParamsState.Get("VersionAdvanceJvm", ModMinecraft.SetupResolver()));
			if (Operators.CompareString(text, "", true) == 0)
			{
				text = Conversions.ToString(ModBase._ParamsState.Get("LaunchAdvanceJvm", null));
			}
			if (!text.Contains("-Dlog4j2.formatMsgNoLookups=true"))
			{
				text += " -Dlog4j2.formatMsgNoLookups=true";
			}
			list.Insert(0, text);
			list.Add("-Xmn256m");
			list.Add("-Xmx" + Conversions.ToString(Math.Floor(PageVersionSetup.GetRam(ModMinecraft.SetupResolver()) * 1024.0)) + "m");
			list.Add("\"-Djava.library.path=" + Version.Path + Version.Name + "-natives\"");
			list.Add("-cp ${classpath}");
			if (Operators.CompareString(ModLaunch.m_IndexerTag.Output.Type, "Nide", true) == 0)
			{
				list.Insert(0, Conversions.ToString(Operators.ConcatenateObject("-Dnide8auth.client=true -javaagent:nide8auth.jar=", ModBase._ParamsState.Get("VersionServerNide", ModMinecraft.SetupResolver()))));
			}
			if (Operators.CompareString(ModLaunch.m_IndexerTag.Output.Type, "Auth", true) == 0)
			{
				string text2 = Conversions.ToString(ModBase._ParamsState.Get("VersionServerAuthServer", ModMinecraft.SetupResolver()));
				string s = Conversions.ToString(ModNet.NetGetCodeByRequestRetry(text2, Encoding.UTF8, "", false));
				list.Insert(0, "-javaagent:authlib-injector.jar=" + text2 + " -Dauthlibinjector.side=client -Dauthlibinjector.yggdrasil.prefetched=" + Convert.ToBase64String(Encoding.UTF8.GetBytes(s)));
			}
			if (Version.DestroyPrototype()["mainClass"] == null)
			{
				throw new Exception("版本 Json 中没有 mainClass 项！");
			}
			list.Add((string)Version.DestroyPrototype()["mainClass"]);
			return ModBase.Join(list, " ");
		}

		// Token: 0x060009AC RID: 2476 RVA: 0x00048AAC File Offset: 0x00046CAC
		private static string McLaunchArgumentsJvmNew(ModMinecraft.McVersion Version)
		{
			List<string> list = new List<string>();
			ModMinecraft.McVersion mcVersion = Version;
			for (;;)
			{
				if (mcVersion.DestroyPrototype()["arguments"] != null && mcVersion.DestroyPrototype()["arguments"]["jvm"] != null)
				{
					try
					{
						foreach (JToken jtoken in mcVersion.DestroyPrototype()["arguments"]["jvm"])
						{
							if (jtoken.Type == 8)
							{
								list.Add(jtoken.ToString());
							}
							else if (ModMinecraft.McJsonRuleCheck(jtoken["rules"]))
							{
								if (jtoken["value"].Type == 8)
								{
									list.Add(jtoken["value"].ToString());
								}
								else
								{
									try
									{
										foreach (JToken jtoken2 in jtoken["value"])
										{
											list.Add(jtoken2.ToString());
										}
									}
									finally
									{
										IEnumerator<JToken> enumerator2;
										if (enumerator2 != null)
										{
											enumerator2.Dispose();
										}
									}
								}
							}
						}
						goto IL_0D;
					}
					finally
					{
						IEnumerator<JToken> enumerator;
						if (enumerator != null)
						{
							enumerator.Dispose();
						}
					}
					continue;
				}
				IL_0D:
				if (Operators.CompareString(mcVersion.PrintPrototype(), "", true) == 0)
				{
					break;
				}
				mcVersion = new ModMinecraft.McVersion(mcVersion.PrintPrototype());
			}
			string text = Conversions.ToString(ModBase._ParamsState.Get("VersionAdvanceJvm", ModMinecraft.SetupResolver()));
			list.Insert(0, Conversions.ToString((Operators.CompareString(text, "", true) == 0) ? ModBase._ParamsState.Get("LaunchAdvanceJvm", null) : text));
			ModLaunch.McLaunchLog("当前剩余内存：" + Conversions.ToString(Math.Round(MyWpfExtension.FindModel().Info.AvailablePhysicalMemory / 1024.0 / 1024.0 / 1024.0 * 10.0) / 10.0) + "G");
			list.Add("-Xmn256m");
			list.Add("-Xmx" + Conversions.ToString(Math.Floor(PageVersionSetup.GetRam(ModMinecraft.SetupResolver()) * 1024.0)) + "m");
			if (Operators.CompareString(ModLaunch.m_IndexerTag.Output.Type, "Nide", true) == 0)
			{
				list.Insert(0, Conversions.ToString(Operators.ConcatenateObject("-javaagent:nide8auth.jar=", ModBase._ParamsState.Get("VersionServerNide", ModMinecraft.SetupResolver()))));
			}
			if (Operators.CompareString(ModLaunch.m_IndexerTag.Output.Type, "Auth", true) == 0)
			{
				string text2 = Conversions.ToString(ModBase._ParamsState.Get("VersionServerAuthServer", ModMinecraft.SetupResolver()));
				try
				{
					string s = Conversions.ToString(ModNet.NetGetCodeByRequestRetry(text2, Encoding.UTF8, "", false));
					list.Insert(0, "-javaagent:authlib-injector.jar=" + text2 + " -Dauthlibinjector.side=client -Dauthlibinjector.yggdrasil.prefetched=" + Convert.ToBase64String(Encoding.UTF8.GetBytes(s)));
				}
				catch (Exception ex)
				{
					throw new Exception("无法连接到第三方登录服务器（" + text2 + "）");
				}
			}
			List<string> list2 = new List<string>();
			checked
			{
				int num = list.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					string text3 = list[i];
					if (list[i].StartsWith("-"))
					{
						while (i < list.Count - 1 && !list[i + 1].StartsWith("-"))
						{
							i++;
							text3 = text3 + " " + list[i];
						}
					}
					list2.Add(text3.Trim().Replace("McEmu= ", "McEmu="));
				}
				string str = ModBase.Join(ModBase.ArrayNoDouble<string>(list2, null), " ");
				if (Version.DestroyPrototype()["mainClass"] == null)
				{
					throw new Exception("版本 Json 中没有 mainClass 项！");
				}
				return str + " " + Version.DestroyPrototype()["mainClass"].ToString();
			}
		}

		// Token: 0x060009AD RID: 2477 RVA: 0x00048EF4 File Offset: 0x000470F4
		private static string McLaunchArgumentsGameOld(ModMinecraft.McVersion Version)
		{
			List<string> list = new List<string>();
			string text = Version.DestroyPrototype()["minecraftArguments"].ToString();
			if (!text.Contains("--height"))
			{
				text += " --height ${resolution_height} --width ${resolution_width}";
			}
			list.Add(text);
			string text2 = ModBase.Join(list, " ");
			if ((Version.Version.requestParameter || Version.Version._ParameterParameter) && Version.Version.m_PrototypeParameter)
			{
				if (text2.Contains("--tweakClass optifine.OptiFineForgeTweaker"))
				{
					ModBase.Log("[Launch] 发现正确的 OptiFineForge TweakClass，目前参数：" + text2, ModBase.LogLevel.Normal, "出现错误");
					text2 = text2.Replace(" --tweakClass optifine.OptiFineForgeTweaker", "").Replace("--tweakClass optifine.OptiFineForgeTweaker ", "") + " --tweakClass optifine.OptiFineForgeTweaker";
				}
				if (text2.Contains("--tweakClass optifine.OptiFineTweaker"))
				{
					ModBase.Log("[Launch] 发现错误的 OptiFineForge TweakClass，目前参数：" + text2, ModBase.LogLevel.Normal, "出现错误");
					text2 = text2.Replace(" --tweakClass optifine.OptiFineTweaker", "").Replace("--tweakClass optifine.OptiFineTweaker ", "") + " --tweakClass optifine.OptiFineForgeTweaker";
					try
					{
						ModBase.WriteFile(Version.Path + Version.Name + ".json", ModBase.ReadFile(Version.Path + Version.Name + ".json").Replace("optifine.OptiFineTweaker", "optifine.OptiFineForgeTweaker"), false, null);
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "替换 OptiFineForge TweakClass 失败", ModBase.LogLevel.Debug, "出现错误");
					}
				}
			}
			return text2;
		}

		// Token: 0x060009AE RID: 2478 RVA: 0x0004908C File Offset: 0x0004728C
		private static string McLaunchArgumentsGameNew(ModMinecraft.McVersion Version)
		{
			List<string> list = new List<string>();
			ModMinecraft.McVersion mcVersion = Version;
			for (;;)
			{
				if (mcVersion.DestroyPrototype()["arguments"] != null && mcVersion.DestroyPrototype()["arguments"]["game"] != null)
				{
					try
					{
						foreach (JToken jtoken in mcVersion.DestroyPrototype()["arguments"]["game"])
						{
							if (jtoken.Type == 8)
							{
								list.Add(jtoken.ToString());
							}
							else if (ModMinecraft.McJsonRuleCheck(jtoken["rules"]))
							{
								if (jtoken["value"].Type == 8)
								{
									list.Add(jtoken["value"].ToString());
								}
								else
								{
									try
									{
										foreach (JToken jtoken2 in jtoken["value"])
										{
											list.Add(jtoken2.ToString());
										}
									}
									finally
									{
										IEnumerator<JToken> enumerator2;
										if (enumerator2 != null)
										{
											enumerator2.Dispose();
										}
									}
								}
							}
						}
						goto IL_0D;
					}
					finally
					{
						IEnumerator<JToken> enumerator;
						if (enumerator != null)
						{
							enumerator.Dispose();
						}
					}
					continue;
				}
				IL_0D:
				if (Operators.CompareString(mcVersion.PrintPrototype(), "", true) == 0)
				{
					break;
				}
				mcVersion = new ModMinecraft.McVersion(mcVersion.PrintPrototype());
			}
			List<string> list2 = new List<string>();
			checked
			{
				int num = list.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					string text = list[i];
					if (list[i].StartsWith("-"))
					{
						while (i < list.Count - 1 && !list[i + 1].StartsWith("-"))
						{
							i++;
							text = text + " " + list[i];
						}
					}
					list2.Add(text);
				}
				string text2 = ModBase.Join(ModBase.ArrayNoDouble<string>(list2, null), " ");
				if ((Version.Version.requestParameter || Version.Version._ParameterParameter) && Version.Version.m_PrototypeParameter)
				{
					if (text2.Contains("--tweakClass optifine.OptiFineForgeTweaker"))
					{
						ModBase.Log("[Launch] 发现正确的 OptiFineForge TweakClass，目前参数：" + text2, ModBase.LogLevel.Normal, "出现错误");
						text2 = text2.Replace(" --tweakClass optifine.OptiFineForgeTweaker", "").Replace("--tweakClass optifine.OptiFineForgeTweaker ", "") + " --tweakClass optifine.OptiFineForgeTweaker";
					}
					if (text2.Contains("--tweakClass optifine.OptiFineTweaker"))
					{
						ModBase.Log("[Launch] 发现错误的 OptiFineForge TweakClass，目前参数：" + text2, ModBase.LogLevel.Normal, "出现错误");
						text2 = text2.Replace(" --tweakClass optifine.OptiFineTweaker", "").Replace("--tweakClass optifine.OptiFineTweaker ", "") + " --tweakClass optifine.OptiFineForgeTweaker";
						try
						{
							ModBase.WriteFile(Version.Path + Version.Name + ".json", ModBase.ReadFile(Version.Path + Version.Name + ".json").Replace("optifine.OptiFineTweaker", "optifine.OptiFineForgeTweaker"), false, null);
						}
						catch (Exception ex)
						{
							ModBase.Log(ex, "替换 OptiFineForge TweakClass 失败", ModBase.LogLevel.Debug, "出现错误");
						}
					}
				}
				return text2;
			}
		}

		// Token: 0x060009AF RID: 2479 RVA: 0x000493E8 File Offset: 0x000475E8
		private static Dictionary<string, string> McLaunchArgumentsReplace(ModMinecraft.McVersion Version, ref ModLoader.LoaderTask<string, List<ModMinecraft.McLibToken>> Loader)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary.Add("${classpath_separator}", ";");
			dictionary.Add("${natives_directory}", Version.Path + Version.Name + "-natives");
			dictionary.Add("${library_directory}", ModMinecraft._MapperTag + "libraries");
			dictionary.Add("${libraries_directory}", ModMinecraft._MapperTag + "libraries");
			dictionary.Add("${launcher_name}", "PCL2");
			dictionary.Add("${launcher_version}", Conversions.ToString(246));
			dictionary.Add("${version_name}", Version.Name);
			string text = Conversions.ToString(ModBase._ParamsState.Get("VersionArgumentInfo", ModMinecraft.SetupResolver()));
			dictionary.Add("${version_type}", Conversions.ToString((Operators.CompareString(text, "", true) == 0) ? ModBase._ParamsState.Get("LaunchArgumentInfo", null) : text));
			checked
			{
				dictionary.Add("${game_directory}", Strings.Left(ModMinecraft.SetupResolver().CreateComparator(), ModMinecraft.SetupResolver().CreateComparator().Count<char>() - 1));
				dictionary.Add("${assets_root}", ModMinecraft._MapperTag + "assets");
				dictionary.Add("${user_properties}", "{}");
				dictionary.Add("${auth_player_name}", ModLaunch.m_IndexerTag.Output.Name);
				dictionary.Add("${auth_uuid}", ModLaunch.m_IndexerTag.Output.ruleProccesor);
				dictionary.Add("${auth_access_token}", ModLaunch.m_IndexerTag.Output.m_MerchantProccesor);
				dictionary.Add("${access_token}", ModLaunch.m_IndexerTag.Output.m_MerchantProccesor);
				dictionary.Add("${auth_session}", ModLaunch.m_IndexerTag.Output.m_MerchantProccesor);
				dictionary.Add("${user_type}", (Operators.CompareString(ModLaunch.m_IndexerTag.Output.Type, "Legacy", true) == 0) ? "Legacy" : "Mojang");
				System.Windows.Size launchArgumentWindowSize = ModBase._ParamsState.GetLaunchArgumentWindowSize();
				dictionary.Add("${resolution_width}", Conversions.ToString(launchArgumentWindowSize.Width));
				dictionary.Add("${resolution_height}", Conversions.ToString(launchArgumentWindowSize.Height));
				dictionary.Add("${game_assets}", ModMinecraft._MapperTag + "assets\\virtual\\legacy");
				dictionary.Add("${assets_index_name}", ModMinecraft.McAssetsGetIndexName(Version));
				List<ModMinecraft.McLibToken> list = ModMinecraft.McLibListGet(Version, !Version.Version.requestParameter || Version.Version.tagParameter < 17);
				Loader.Output = list;
				List<string> list2 = new List<string>();
				string text2 = null;
				try
				{
					foreach (ModMinecraft.McLibToken mcLibToken in list)
					{
						if (!mcLibToken.m_ParamsParameter)
						{
							if (mcLibToken.Name != null && Operators.CompareString(mcLibToken.Name, "optifine:OptiFine", true) == 0)
							{
								text2 = mcLibToken.tokenizerParameter;
							}
							else
							{
								list2.Add(mcLibToken.tokenizerParameter);
							}
						}
					}
				}
				finally
				{
					List<ModMinecraft.McLibToken>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				if (text2 != null)
				{
					list2.Insert(list2.Count - 2, text2);
				}
				dictionary.Add("${classpath}", ModBase.Join(list2, ";"));
				return dictionary;
			}
		}

		// Token: 0x060009B0 RID: 2480 RVA: 0x00049730 File Offset: 0x00047930
		private static void McLaunchNatives(ModLoader.LoaderTask<List<ModMinecraft.McLibToken>, int> Loader)
		{
			Directory.CreateDirectory(ModMinecraft.SetupResolver().Path + ModMinecraft.SetupResolver().Name + "-natives");
			ModLaunch.McLaunchLog("正在解压 Natives 文件");
			List<string> list = new List<string>();
			try
			{
				foreach (ModMinecraft.McLibToken mcLibToken in Loader.Input)
				{
					if (mcLibToken.m_ParamsParameter)
					{
						ZipArchive zipArchive = new ZipArchive(new FileStream(mcLibToken.tokenizerParameter, FileMode.Open));
						try
						{
							foreach (ZipArchiveEntry zipArchiveEntry in zipArchive.Entries)
							{
								string fullName = zipArchiveEntry.FullName;
								if (fullName.EndsWith(".dll"))
								{
									string text = ModMinecraft.SetupResolver().Path + ModMinecraft.SetupResolver().Name + "-natives\\" + fullName;
									list.Add(text);
									FileInfo fileInfo = new FileInfo(text);
									if (fileInfo.Exists)
									{
										if (fileInfo.Length == zipArchiveEntry.Length)
										{
											if (ModBase._EventState)
											{
												ModLaunch.McLaunchLog("无需解压：" + text);
												continue;
											}
											continue;
										}
										else
										{
											try
											{
												File.Delete(text);
											}
											catch (UnauthorizedAccessException ex)
											{
												ModLaunch.McLaunchLog("删除原 dll 访问被拒绝，这通常代表有一个 MC 正在运行，跳过解压：" + text);
												ModLaunch.McLaunchLog("实际的错误信息：" + ModBase.GetString(ex, true, false));
												break;
											}
										}
									}
									ModBase.WriteFile(text, zipArchiveEntry.Open());
									ModLaunch.McLaunchLog("已解压：" + text);
								}
							}
							goto IL_190;
						}
						finally
						{
							IEnumerator<ZipArchiveEntry> enumerator2;
							if (enumerator2 != null)
							{
								enumerator2.Dispose();
							}
						}
						IL_185:
						zipArchive.Dispose();
						continue;
						IL_190:
						if (zipArchive != null)
						{
							goto IL_185;
						}
					}
				}
			}
			finally
			{
				List<ModMinecraft.McLibToken>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			foreach (string text2 in Directory.GetFiles(ModMinecraft.SetupResolver().Path + ModMinecraft.SetupResolver().Name + "-natives"))
			{
				if (!list.Contains(text2))
				{
					try
					{
						ModLaunch.McLaunchLog("删除：" + text2);
						File.Delete(text2);
					}
					catch (UnauthorizedAccessException ex2)
					{
						ModLaunch.McLaunchLog("删除多余文件访问被拒绝，跳过删除步骤");
						ModLaunch.McLaunchLog("实际的错误信息：" + ModBase.GetString(ex2, true, false));
						break;
					}
				}
			}
		}

		// Token: 0x060009B1 RID: 2481 RVA: 0x000499E0 File Offset: 0x00047BE0
		private static void McLaunchPrerun()
		{
			try
			{
				if (Operators.CompareString(ModLaunch.m_IndexerTag.Output.Type, "Mojang", true) == 0 || Operators.CompareString(ModLaunch.m_IndexerTag.Output.Type, "Microsoft", true) == 0)
				{
					ModMinecraft.McFolderLauncherProfilesJsonCreate(ModMinecraft._MapperTag);
					JObject jobject = (JObject)ModBase.GetJson(string.Concat(new string[]
					{
						"\r\n            {\r\n              \"authenticationDatabase\": {\r\n                \"00000111112222233333444445555566\": {\r\n                  \"accessToken\": \"",
						ModLaunch.m_IndexerTag.Output.m_MerchantProccesor,
						"\",\r\n                  \"username\": \"",
						(ModLaunch.m_IndexerTag.Output._QueueProccesor ?? ModLaunch.m_IndexerTag.Output.Name).Replace("\"", "-"),
						"\",\r\n                  \"profiles\": {\r\n                    \"66666555554444433333222221111100\": {\r\n                        \"displayName\": \"",
						ModLaunch.m_IndexerTag.Output.Name,
						"\"\r\n                    }\r\n                  }\r\n                }\r\n              },\r\n              \"clientToken\": \"",
						ModLaunch.m_IndexerTag.Output.m_ExporterProccesor,
						"\",\r\n              \"selectedUser\": {\r\n                \"account\": \"00000111112222233333444445555566\", \r\n                \"profile\": \"66666555554444433333222221111100\"\r\n              }\r\n            }"
					}));
					JObject jobject2 = (JObject)ModBase.GetJson(ModBase.ReadFile(ModMinecraft._MapperTag + "launcher_profiles.json"));
					jobject2.Merge(jobject);
					ModBase.WriteFile(ModMinecraft._MapperTag + "launcher_profiles.json", jobject2.ToString(), false, Encoding.Default);
					ModLaunch.McLaunchLog("已更新 launcher_profiles.json");
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "更新 launcher_profiles.json 失败，将在删除文件后重试", ModBase.LogLevel.Debug, "出现错误");
				try
				{
					File.Delete(ModMinecraft._MapperTag + "launcher_profiles.json");
					ModMinecraft.McFolderLauncherProfilesJsonCreate(ModMinecraft._MapperTag);
					JObject jobject3 = (JObject)ModBase.GetJson(string.Concat(new string[]
					{
						"\r\n                    {\r\n                      \"authenticationDatabase\": {\r\n                        \"00000111112222233333444445555566\": {\r\n                          \"accessToken\": \"",
						ModLaunch.m_IndexerTag.Output.m_MerchantProccesor,
						"\",\r\n                          \"username\": \"",
						(ModLaunch.m_IndexerTag.Output._QueueProccesor ?? ModLaunch.m_IndexerTag.Output.Name).Replace("\"", "-"),
						"\",\r\n                          \"profiles\": {\r\n                            \"66666555554444433333222221111100\": {\r\n                                \"displayName\": \"",
						ModLaunch.m_IndexerTag.Output.Name,
						"\"\r\n                            }\r\n                          }\r\n                        }\r\n                      },\r\n                      \"clientToken\": \"",
						ModLaunch.m_IndexerTag.Output.m_ExporterProccesor,
						"\",\r\n                      \"selectedUser\": {\r\n                        \"account\": \"00000111112222233333444445555566\", \r\n                        \"profile\": \"66666555554444433333222221111100\"\r\n                      }\r\n                    }"
					}));
					JObject jobject4 = (JObject)ModBase.GetJson(ModBase.ReadFile(ModMinecraft._MapperTag + "launcher_profiles.json"));
					jobject4.Merge(jobject3);
					ModBase.WriteFile(ModMinecraft._MapperTag + "launcher_profiles.json", jobject4.ToString(), false, Encoding.Default);
					ModLaunch.McLaunchLog("已在删除后更新 launcher_profiles.json");
				}
				catch (Exception ex2)
				{
					ModBase.Log(ex2, "更新 launcher_profiles.json 失败", ModBase.LogLevel.Feedback, "出现错误");
				}
			}
			string text = ModMinecraft.SetupResolver().CreateComparator() + "options.txt";
			try
			{
				if (Conversions.ToBoolean(ModBase._ParamsState.Get("ToolHelpChinese", null)))
				{
					if (File.Exists(text) && Directory.Exists(ModMinecraft.SetupResolver().CreateComparator() + "saves"))
					{
						ModLaunch.McLaunchLog("并非首次启动，不修改语言");
					}
					else
					{
						ModLaunch.McLaunchLog("已根据设置自动修改语言为中文");
						ModBase.WriteIni(text, "lang", "-");
						if (ModMinecraft.SetupResolver().Version.tagParameter >= 12)
						{
							ModBase.WriteIni(text, "lang", "zh_cn");
						}
						else
						{
							ModBase.WriteIni(text, "lang", "zh_CN");
						}
						ModBase.WriteIni(text, "forceUnicodeFont", "true");
					}
				}
				ModBase.WriteIni(text, "fullscreen", Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LaunchArgumentWindowType", null), 0, true) ? "true" : "false");
			}
			catch (Exception ex3)
			{
				ModBase.Log(ex3, "更新 options.txt 失败", ModBase.LogLevel.Hint, "出现错误");
			}
			try
			{
				if (Conversions.ToBoolean(ModMinecraft.SetupResolver().Version.tagParameter <= 7 && ModMinecraft.SetupResolver().Version.tagParameter >= 2 && ModLaunch.m_IndexerTag.Input.Type == ModLaunch.McLoginType.Legacy && (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LaunchSkinType", null), 2, true) || (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LaunchSkinType", null), 4, true) && Conversions.ToBoolean(ModBase._ParamsState.Get("LaunchSkinSlim", null))))))
				{
					ModMain.Hint("此 Minecraft 版本尚不支持 Alex 皮肤，你的皮肤可能会显示为 Steve！", ModMain.HintType.Critical, true);
				}
			}
			catch (Exception ex4)
			{
				ModBase.Log(ex4, "检查离线皮肤失效失败", ModBase.LogLevel.Debug, "出现错误");
			}
			try
			{
				Directory.CreateDirectory(ModMinecraft.SetupResolver().CreateComparator() + "resourcepacks\\");
				string path = ModMinecraft.SetupResolver().CreateComparator() + "resourcepacks\\PCL2 Skin.zip";
				bool flag = ModMinecraft.SetupResolver().Version.tagParameter >= 13 || ModMinecraft.SetupResolver().Version.tagParameter < 6;
				if (ModLaunch.m_IndexerTag.Input.Type == ModLaunch.McLoginType.Legacy && Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LaunchSkinType", null), 4, true) && File.Exists(ModBase.attributeState + "CustomSkin.png"))
				{
					Directory.CreateDirectory(ModBase.attributeState);
					string text2 = ModBase.attributeState + "pack.mcmeta";
					string text3 = ModBase.attributeState + "pack.png";
					int value;
					switch (ModMinecraft.SetupResolver().Version.tagParameter)
					{
					case 0:
					case 1:
					case 2:
					case 3:
					case 4:
					case 5:
						ModLaunch.McLaunchLog("Minecraft 版本过老，尚不支持自定义离线皮肤");
						goto IL_A25;
					case 6:
					case 7:
					case 8:
						value = 1;
						break;
					case 9:
					case 10:
						value = 2;
						break;
					case 11:
					case 12:
						value = 3;
						break;
					case 13:
					case 14:
						value = 4;
						break;
					case 15:
						value = 5;
						break;
					case 16:
						value = 6;
						break;
					default:
						value = 7;
						break;
					}
					ModLaunch.McLaunchLog("正在构建自定义皮肤资源包，格式为：" + Conversions.ToString(value));
					new MyBitmap(ModBase._TokenizerState + "Heads/Logo.png").Save(text3);
					ModBase.WriteFile(text2, "{\"pack\":{\"pack_format\":" + Conversions.ToString(value) + ",\"description\":\"PCL2 自定义离线皮肤资源包\"}}", false, null);
					MyBitmap myBitmap = new MyBitmap(ModBase.attributeState + "CustomSkin.png");
					if ((ModMinecraft.SetupResolver().Version.tagParameter == 6 || ModMinecraft.SetupResolver().Version.tagParameter == 7) && myBitmap.templateAccount.Height == 64)
					{
						ModLaunch.McLaunchLog("该 Minecraft 版本不支持双层皮肤，已进行裁剪");
						myBitmap = myBitmap.Clip(new Rectangle(0, 0, 64, 32));
					}
					myBitmap.Save(ModBase.Path + "PCL\\CustomSkin_Cliped.png");
					using (FileStream fileStream = new FileStream(path, FileMode.Create))
					{
						using (ZipArchive zipArchive = new ZipArchive(fileStream, ZipArchiveMode.Create))
						{
							zipArchive.CreateEntryFromFile(text2, "pack.mcmeta");
							zipArchive.CreateEntryFromFile(text3, "pack.png");
							zipArchive.CreateEntryFromFile(ModBase.Path + "PCL\\CustomSkin_Cliped.png", "assets/minecraft/textures/entity/" + (Conversions.ToBoolean(ModBase._ParamsState.Get("LaunchSkinSlim", null)) ? "alex.png" : "steve.png"));
						}
					}
					File.Delete(ModBase.Path + "PCL\\CustomSkin_Cliped.png");
					ModBase.IniClearCache(text);
					string text4 = ModBase.ReadIni(text, "resourcePacks", "[]").TrimStart(new char[]
					{
						'['
					}).TrimEnd(new char[]
					{
						']'
					});
					if (flag)
					{
						if (Operators.CompareString(text4, "", true) == 0)
						{
							text4 = "\"vanilla\"";
						}
						List<string> list = new List<string>(text4.Split(new char[]
						{
							','
						}));
						List<string> list2 = new List<string>();
						try
						{
							foreach (string text5 in list)
							{
								if (Operators.CompareString(text5, "\"file/PCL2 Skin.zip\"", true) != 0 && Operators.CompareString(text5, "", true) != 0)
								{
									list2.Add(text5);
								}
							}
						}
						finally
						{
							List<string>.Enumerator enumerator;
							((IDisposable)enumerator).Dispose();
						}
						list2.Add("\"file/PCL2 Skin.zip\"");
						string value2 = "[" + ModBase.Join(list2, ",") + "]";
						ModBase.WriteIni(text, "resourcePacks", value2);
					}
					else
					{
						List<string> list3 = new List<string>(text4.Split(new char[]
						{
							','
						}));
						List<string> list4 = new List<string>();
						try
						{
							foreach (string text6 in list3)
							{
								if (Operators.CompareString(text6, "\"PCL2 Skin.zip\"", true) != 0 && Operators.CompareString(text6, "", true) != 0)
								{
									list4.Add(text6);
								}
							}
						}
						finally
						{
							List<string>.Enumerator enumerator2;
							((IDisposable)enumerator2).Dispose();
						}
						list4.Add("\"PCL2 Skin.zip\"");
						string value3 = "[" + ModBase.Join(list4, ",") + "]";
						ModBase.WriteIni(text, "resourcePacks", value3);
					}
				}
				else if (File.Exists(path))
				{
					ModLaunch.McLaunchLog("正在清空自定义皮肤资源包");
					File.Delete(path);
					ModBase.IniClearCache(text);
					string text7 = ModBase.ReadIni(text, "resourcePacks", "[]").TrimStart(new char[]
					{
						'['
					}).TrimEnd(new char[]
					{
						']'
					});
					if (flag)
					{
						if (Operators.CompareString(text7, "", true) == 0)
						{
							text7 = "\"vanilla\"";
						}
						List<string> list5 = new List<string>(text7.Split(new char[]
						{
							','
						}));
						list5.Remove("\"file/PCL2 Skin.zip\"");
						string value4 = "[" + ModBase.Join(list5, ",") + "]";
						ModBase.WriteIni(text, "resourcePacks", value4);
					}
					else
					{
						List<string> list6 = new List<string>(text7.Split(new char[]
						{
							','
						}));
						list6.Remove("\"PCL2 Skin.zip\"");
						string value5 = "[" + ModBase.Join(list6, ",") + "]";
						ModBase.WriteIni(text, "resourcePacks", value5);
					}
				}
				IL_A25:;
			}
			catch (Exception ex5)
			{
				ModBase.Log(ex5, "离线皮肤资源包设置失败", ModBase.LogLevel.Hint, "出现错误");
			}
		}

		// Token: 0x060009B2 RID: 2482 RVA: 0x0004A514 File Offset: 0x00048714
		private static void McLaunchRun(ModLoader.LoaderTask<int, Process> Loader)
		{
			Process process = new Process();
			ProcessStartInfo processStartInfo = new ProcessStartInfo(ModLaunch._InstanceTag.RegisterComparator());
			if (processStartInfo.EnvironmentVariables.ContainsKey("appdata"))
			{
				processStartInfo.EnvironmentVariables["appdata"] = ModMinecraft._MapperTag;
			}
			else
			{
				processStartInfo.EnvironmentVariables.Add("appdata", ModMinecraft._MapperTag);
			}
			List<string> list = new List<string>(processStartInfo.EnvironmentVariables["Path"].Split(new char[]
			{
				';'
			}));
			list.Add(ModLaunch._InstanceTag.m_ListProccesor);
			processStartInfo.EnvironmentVariables["Path"] = ModBase.Join(ModBase.ArrayNoDouble<string>(list, null), ";");
			processStartInfo.WorkingDirectory = ModMinecraft.SetupResolver().CreateComparator();
			processStartInfo.UseShellExecute = false;
			processStartInfo.RedirectStandardOutput = true;
			processStartInfo.RedirectStandardError = true;
			processStartInfo.CreateNoWindow = false;
			processStartInfo.Arguments = ModLaunch.m_CreatorTag;
			process.StartInfo = processStartInfo;
			process.Start();
			ModLaunch.McLaunchLog("已启动游戏进程");
			Loader.Output = process;
			ModLaunch.m_BridgeTag = process;
			try
			{
				string text = string.Concat(new string[]
				{
					"@echo off\r\ntitle 启动 - ",
					ModMinecraft.SetupResolver().Name,
					"\r\necho 游戏正在启动，请稍候。\r\nset APPDATA=\"",
					ModMinecraft._MapperTag,
					"\"\r\ncd /D \"",
					ModMinecraft._MapperTag,
					"\"\r\n\"",
					ModLaunch._InstanceTag.StartComparator(),
					"\" ",
					ModLaunch.m_CreatorTag,
					"\r\necho 游戏已退出。\r\npause"
				});
				ModBase.WriteFile(ModBase.Path + "PCL\\LatestLaunch.bat", text, false, Encoding.Default);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "输出启动脚本失败", ModBase.LogLevel.Debug, "出现错误");
			}
			try
			{
				if (!process.HasExited)
				{
					process.PriorityBoostEnabled = true;
					object left = ModBase._ParamsState.Get("LaunchArgumentPriority", null);
					if (Operators.ConditionalCompareObjectEqual(left, 0, true))
					{
						process.PriorityClass = ProcessPriorityClass.AboveNormal;
					}
					else if (Operators.ConditionalCompareObjectEqual(left, 2, true))
					{
						process.PriorityClass = ProcessPriorityClass.BelowNormal;
					}
				}
			}
			catch (Exception ex2)
			{
				ModBase.Log(ex2, "设置进程优先级失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x060009B3 RID: 2483 RVA: 0x0004A774 File Offset: 0x00048974
		private static void McLaunchWait(ModLoader.LoaderTask<Process, int> Loader)
		{
			ModLaunch.McLaunchLog("");
			ModLaunch.McLaunchLog("~ 基础参数 ~");
			ModLaunch.McLaunchLog("PCL2 版本：Release 2.2.9 (" + Conversions.ToString(246) + ")");
			ModLaunch.McLaunchLog(string.Concat(new string[]
			{
				"游戏版本：",
				ModMinecraft.SetupResolver().Version.ToString(),
				"（",
				Conversions.ToString(ModMinecraft.SetupResolver().Version.tagParameter),
				"）"
			}));
			ModLaunch.McLaunchLog("资源版本：" + ModMinecraft.McAssetsGetIndexName(ModMinecraft.SetupResolver()));
			ModLaunch.McLaunchLog("版本继承：" + ((Operators.CompareString(ModMinecraft.SetupResolver().PrintPrototype(), "", true) == 0) ? "无" : ModMinecraft.SetupResolver().PrintPrototype()));
			ModLaunch.McLaunchLog(string.Concat(new string[]
			{
				"分配的内存：",
				Conversions.ToString(PageVersionSetup.GetRam(ModMinecraft.SetupResolver())),
				" GB（",
				Conversions.ToString(Math.Round(PageVersionSetup.GetRam(ModMinecraft.SetupResolver()) * 1024.0)),
				" MB）"
			}));
			ModLaunch.McLaunchLog("MC 文件夹：" + ModMinecraft._MapperTag);
			ModLaunch.McLaunchLog("版本文件夹：" + ModMinecraft.SetupResolver().Path);
			ModLaunch.McLaunchLog("版本隔离：" + Conversions.ToString(Operators.CompareString(ModMinecraft.SetupResolver().CreateComparator(), ModMinecraft.SetupResolver().Path, true) == 0));
			ModLaunch.McLaunchLog("HMCL 格式：" + Conversions.ToString(ModMinecraft.SetupResolver().VerifyPrototype()));
			ModLaunch.McLaunchLog("Java 信息：" + ((ModLaunch._InstanceTag != null) ? ModLaunch._InstanceTag.ToString() : "无可用 Java"));
			ModLaunch.McLaunchLog("环境变量：" + ((ModLaunch._InstanceTag != null) ? (ModLaunch._InstanceTag.InitComparator() ? "已设置" : "未设置") : "未设置"));
			ModLaunch.McLaunchLog("");
			ModLaunch.McLaunchLog("~ 登录参数 ~");
			ModLaunch.McLaunchLog("玩家用户名：" + ModLaunch.m_IndexerTag.Output.Name);
			ModLaunch.McLaunchLog("AccessToken：" + ModLaunch.m_IndexerTag.Output.m_MerchantProccesor.Substring(0, 22) + "********" + ModLaunch.m_IndexerTag.Output.m_MerchantProccesor.Substring(30));
			ModLaunch.McLaunchLog("ClientToken：" + ModLaunch.m_IndexerTag.Output.m_ExporterProccesor);
			ModLaunch.McLaunchLog("UUID：" + ModLaunch.m_IndexerTag.Output.ruleProccesor);
			ModLaunch.McLaunchLog("登录方式：" + ModLaunch.m_IndexerTag.Output.Type);
			ModLaunch.McLaunchLog("");
			string text = Conversions.ToString(ModBase._ParamsState.Get("VersionArgumentTitle", ModMinecraft.SetupResolver()));
			if (Operators.CompareString(text, "", true) == 0)
			{
				text = Conversions.ToString(ModBase._ParamsState.Get("LaunchArgumentTitle", null));
			}
			text = ModMinecraft.ArgumentReplace(text);
			ModWatcher.Watcher watcher = new ModWatcher.Watcher(Loader, ModMinecraft.SetupResolver(), text);
			ModLaunch.m_StructTag = watcher;
			while (watcher.State == ModWatcher.Watcher.MinecraftState.Loading)
			{
				Thread.Sleep(100);
			}
			if (watcher.State == ModWatcher.Watcher.MinecraftState.Crashed)
			{
				throw new Exception("$$");
			}
		}

		// Token: 0x060009B4 RID: 2484 RVA: 0x0004AADC File Offset: 0x00048CDC
		private static void McLaunchEnd()
		{
			ModLaunch.McLaunchLog("开始启动结束处理");
			if (Conversions.ToBoolean(ModBase._ParamsState.Get("UiMusicStop", null)))
			{
				ModBase.RunInUi((ModLaunch._Closure$__.$I53-0 == null) ? (ModLaunch._Closure$__.$I53-0 = delegate()
				{
					if (ModMusic.MusicPause())
					{
						ModBase.Log("[Music] 已根据设置，在启动后暂停音乐播放", ModBase.LogLevel.Normal, "出现错误");
					}
				}) : ModLaunch._Closure$__.$I53-0, false);
			}
			else if (Conversions.ToBoolean(ModBase._ParamsState.Get("UiMusicStart", null)))
			{
				ModBase.RunInUi((ModLaunch._Closure$__.$I53-1 == null) ? (ModLaunch._Closure$__.$I53-1 = delegate()
				{
					if (ModMusic.MusicResume())
					{
						ModBase.Log("[Music] 已根据设置，在启动后开始音乐播放", ModBase.LogLevel.Normal, "出现错误");
					}
				}) : ModLaunch._Closure$__.$I53-1, false);
			}
			ModLaunch.McLaunchLog(Conversions.ToString(Operators.ConcatenateObject("启动器可见性：", ModBase._ParamsState.Get("LaunchArgumentVisible", null))));
			object left = ModBase._ParamsState.Get("LaunchArgumentVisible", null);
			if (Operators.ConditionalCompareObjectEqual(left, 0, true))
			{
				ModLaunch.McLaunchLog("已根据设置，在启动后关闭启动器");
				ModBase.RunInUi((ModLaunch._Closure$__.$I53-2 == null) ? (ModLaunch._Closure$__.$I53-2 = delegate()
				{
					ModMain.m_CollectionAccount.EndProgram(false);
				}) : ModLaunch._Closure$__.$I53-2, false);
			}
			else if (Conversions.ToBoolean(Conversions.ToBoolean(Operators.CompareObjectEqual(left, 2, true)) || Conversions.ToBoolean(Operators.CompareObjectEqual(left, 3, true))))
			{
				ModLaunch.McLaunchLog("已根据设置，在启动后隐藏启动器");
				ModBase.RunInUi((ModLaunch._Closure$__.$I53-3 == null) ? (ModLaunch._Closure$__.$I53-3 = delegate()
				{
					ModMain.m_CollectionAccount.Hidden = true;
				}) : ModLaunch._Closure$__.$I53-3, false);
			}
			else if (Operators.ConditionalCompareObjectEqual(left, 4, true))
			{
				ModLaunch.McLaunchLog("已根据设置，在启动后最小化启动器");
				ModBase.RunInUi((ModLaunch._Closure$__.$I53-4 == null) ? (ModLaunch._Closure$__.$I53-4 = delegate()
				{
					ModMain.m_CollectionAccount.WindowState = WindowState.Minimized;
				}) : ModLaunch._Closure$__.$I53-4, false);
			}
			else
			{
				Operators.ConditionalCompareObjectEqual(left, 5, true);
			}
			ModBase._ParamsState.Set("SystemLaunchCount", Operators.AddObject(ModBase._ParamsState.Get("SystemLaunchCount", null), 1), false, null);
		}

		// Token: 0x040004DA RID: 1242
		public static ModLoader.LoaderTask<string, object> _AttrTag = new ModLoader.LoaderTask<string, object>("Loader Launch", new Action<ModLoader.LoaderTask<string, object>>(ModLaunch.McLaunchStart), null, ThreadPriority.Normal)
		{
			OnStateChanged = delegate(ModLoader.LoaderBase a0)
			{
				ModLaunch.McLaunchState((ModLoader.LoaderTask<string, object>)a0);
			},
			ReloadTimeout = 1
		};

		// Token: 0x040004DB RID: 1243
		public static ModLoader.LoaderCombo<object> facadeTag;

		// Token: 0x040004DC RID: 1244
		public static Process m_BridgeTag;

		// Token: 0x040004DD RID: 1245
		public static ModWatcher.Watcher m_StructTag;

		// Token: 0x040004DE RID: 1246
		public static ModLoader.LoaderTask<ModLaunch.McLoginData, ModLaunch.McLoginResult> m_IndexerTag = new ModLoader.LoaderTask<ModLaunch.McLoginData, ModLaunch.McLoginResult>("登录", new Action<ModLoader.LoaderTask<ModLaunch.McLoginData, ModLaunch.McLoginResult>>(ModLaunch.McLoginStart), new Func<ModLaunch.McLoginData>(ModLaunch.McLoginInput), ThreadPriority.BelowNormal)
		{
			ReloadTimeout = 60000,
			ProgressWeight = 15.0,
			Block = false
		};

		// Token: 0x040004DF RID: 1247
		public static ModLoader.LoaderTask<ModLaunch.McLoginServer, ModLaunch.McLoginResult> templateTag = new ModLoader.LoaderTask<ModLaunch.McLoginServer, ModLaunch.McLoginResult>("Loader Login Mojang", new Action<ModLoader.LoaderTask<ModLaunch.McLoginServer, ModLaunch.McLoginResult>>(ModLaunch.McLoginServerStart), null, ThreadPriority.Normal)
		{
			ReloadTimeout = 60000
		};

		// Token: 0x040004E0 RID: 1248
		public static ModLoader.LoaderTask<ModLaunch.McLoginMs, ModLaunch.McLoginResult> _ExpressionTag = new ModLoader.LoaderTask<ModLaunch.McLoginMs, ModLaunch.McLoginResult>("Loader Login Ms", new Action<ModLoader.LoaderTask<ModLaunch.McLoginMs, ModLaunch.McLoginResult>>(ModLaunch.McLoginMsStart), null, ThreadPriority.Normal)
		{
			ReloadTimeout = 300000
		};

		// Token: 0x040004E1 RID: 1249
		public static ModLoader.LoaderTask<ModLaunch.McLoginLegacy, ModLaunch.McLoginResult> _GetterTag = new ModLoader.LoaderTask<ModLaunch.McLoginLegacy, ModLaunch.McLoginResult>("Loader Login Legacy", new Action<ModLoader.LoaderTask<ModLaunch.McLoginLegacy, ModLaunch.McLoginResult>>(ModLaunch.McLoginLegacyStart), null, ThreadPriority.Normal);

		// Token: 0x040004E2 RID: 1250
		public static ModLoader.LoaderTask<ModLaunch.McLoginServer, ModLaunch.McLoginResult> listenerTag = new ModLoader.LoaderTask<ModLaunch.McLoginServer, ModLaunch.McLoginResult>("Loader Login Nide", new Action<ModLoader.LoaderTask<ModLaunch.McLoginServer, ModLaunch.McLoginResult>>(ModLaunch.McLoginServerStart), null, ThreadPriority.Normal)
		{
			ReloadTimeout = 60000
		};

		// Token: 0x040004E3 RID: 1251
		public static ModLoader.LoaderTask<ModLaunch.McLoginServer, ModLaunch.McLoginResult> _IdentifierTag = new ModLoader.LoaderTask<ModLaunch.McLoginServer, ModLaunch.McLoginResult>("Loader Login Auth", new Action<ModLoader.LoaderTask<ModLaunch.McLoginServer, ModLaunch.McLoginResult>>(ModLaunch.McLoginServerStart), null, ThreadPriority.Normal)
		{
			ReloadTimeout = 60000
		};

		// Token: 0x040004E4 RID: 1252
		private static ModMinecraft.JavaEntry _InstanceTag = null;

		// Token: 0x040004E5 RID: 1253
		private static string m_CreatorTag;

		// Token: 0x02000102 RID: 258
		public enum McLoginType
		{
			// Token: 0x040004E7 RID: 1255
			Legacy,
			// Token: 0x040004E8 RID: 1256
			Mojang,
			// Token: 0x040004E9 RID: 1257
			Nide,
			// Token: 0x040004EA RID: 1258
			Auth,
			// Token: 0x040004EB RID: 1259
			Ms = 5
		}

		// Token: 0x02000103 RID: 259
		public abstract class McLoginData
		{
			// Token: 0x060009B6 RID: 2486 RVA: 0x00006AF4 File Offset: 0x00004CF4
			public override bool Equals(object obj)
			{
				return obj != null && obj.GetHashCode() == this.GetHashCode();
			}

			// Token: 0x040004EC RID: 1260
			public ModLaunch.McLoginType Type;
		}

		// Token: 0x02000104 RID: 260
		public class McLoginServer : ModLaunch.McLoginData
		{
			// Token: 0x060009B8 RID: 2488 RVA: 0x00006B09 File Offset: 0x00004D09
			public McLoginServer(ModLaunch.McLoginType Type)
			{
				this._TestsProccesor = false;
				this.Type = Type;
			}

			// Token: 0x060009B9 RID: 2489 RVA: 0x0004ACE0 File Offset: 0x00048EE0
			public override int GetHashCode()
			{
				return Convert.ToInt32(decimal.Remainder(new decimal(ModBase.GetHash(string.Concat(new string[]
				{
					this.m_InterpreterProccesor,
					this._ParserProccesor,
					this._StubProccesor,
					this.m_ErrorProccesor,
					Conversions.ToString((int)this.Type)
				}))), 2147483647m));
			}

			// Token: 0x040004ED RID: 1261
			public string m_InterpreterProccesor;

			// Token: 0x040004EE RID: 1262
			public string _ParserProccesor;

			// Token: 0x040004EF RID: 1263
			public string _StubProccesor;

			// Token: 0x040004F0 RID: 1264
			public string m_ErrorProccesor;

			// Token: 0x040004F1 RID: 1265
			public string _ExceptionProccesor;

			// Token: 0x040004F2 RID: 1266
			public bool _TestsProccesor;
		}

		// Token: 0x02000105 RID: 261
		public class McLoginMs : ModLaunch.McLoginData
		{
			// Token: 0x060009BB RID: 2491 RVA: 0x00006B20 File Offset: 0x00004D20
			public McLoginMs()
			{
				this.strategyProccesor = "";
				this.m_RulesProccesor = "";
				this._WorkerProccesor = "";
				this._DicProccesor = "";
				this.Type = ModLaunch.McLoginType.Ms;
			}

			// Token: 0x060009BC RID: 2492 RVA: 0x0004AD4C File Offset: 0x00048F4C
			public override int GetHashCode()
			{
				return Convert.ToInt32(decimal.Remainder(new decimal(ModBase.GetHash(this.strategyProccesor + this.m_RulesProccesor + this._WorkerProccesor + this._DicProccesor)), 2147483647m));
			}

			// Token: 0x040004F3 RID: 1267
			public string strategyProccesor;

			// Token: 0x040004F4 RID: 1268
			public string m_RulesProccesor;

			// Token: 0x040004F5 RID: 1269
			public string _WorkerProccesor;

			// Token: 0x040004F6 RID: 1270
			public string _DicProccesor;
		}

		// Token: 0x02000106 RID: 262
		public class McLoginLegacy : ModLaunch.McLoginData
		{
			// Token: 0x060009BE RID: 2494 RVA: 0x00006B5C File Offset: 0x00004D5C
			public McLoginLegacy()
			{
				this.Type = ModLaunch.McLoginType.Legacy;
			}

			// Token: 0x060009BF RID: 2495 RVA: 0x0004AD98 File Offset: 0x00048F98
			public override int GetHashCode()
			{
				return Convert.ToInt32(decimal.Remainder(new decimal(ModBase.GetHash(this._ConfigurationProccesor + Conversions.ToString(this.m_ConfigProccesor) + this.managerProccesor + Conversions.ToString((int)this.Type))), 2147483647m));
			}

			// Token: 0x040004F7 RID: 1271
			public string _ConfigurationProccesor;

			// Token: 0x040004F8 RID: 1272
			public int m_ConfigProccesor;

			// Token: 0x040004F9 RID: 1273
			public string managerProccesor;
		}

		// Token: 0x02000107 RID: 263
		public struct McLoginResult
		{
			// Token: 0x040004FA RID: 1274
			public string Name;

			// Token: 0x040004FB RID: 1275
			public string ruleProccesor;

			// Token: 0x040004FC RID: 1276
			public string m_MerchantProccesor;

			// Token: 0x040004FD RID: 1277
			public string Type;

			// Token: 0x040004FE RID: 1278
			public string m_ExporterProccesor;

			// Token: 0x040004FF RID: 1279
			public string _QueueProccesor;

			// Token: 0x04000500 RID: 1280
			public string _GlobalProccesor;
		}
	}
}
