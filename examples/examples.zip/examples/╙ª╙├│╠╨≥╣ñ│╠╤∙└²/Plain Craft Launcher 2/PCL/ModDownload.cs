﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Newtonsoft.Json.Linq;

namespace PCL
{
	// Token: 0x020000ED RID: 237
	[StandardModule]
	public sealed class ModDownload
	{
		// Token: 0x06000933 RID: 2355 RVA: 0x00040514 File Offset: 0x0003E714
		public static ModNet.NetFile DlClientJarGet(ModMinecraft.McVersion Version, bool ReturnNothingOnFileUseable)
		{
			while (!string.IsNullOrEmpty(Version.PrintPrototype()))
			{
				Version = new ModMinecraft.McVersion(Version.PrintPrototype());
			}
			if (Version.DestroyPrototype()["downloads"] != null && Version.DestroyPrototype()["downloads"]["client"] != null && Version.DestroyPrototype()["downloads"]["client"]["url"] != null)
			{
				ModBase.FileChecker fileChecker = new ModBase.FileChecker(1024L, (long)(Version.DestroyPrototype()["downloads"]["client"]["size"] ?? -1), (string)Version.DestroyPrototype()["downloads"]["client"]["sha1"], true, false);
				if (ReturnNothingOnFileUseable)
				{
					bool flag = Conversions.ToBoolean(ModBase._ParamsState.Get("LaunchAdvanceAssets", null));
					object left = ModBase._ParamsState.Get("VersionAdvanceAssets", Version);
					if (!Operators.ConditionalCompareObjectEqual(left, 0, true))
					{
						if (Operators.ConditionalCompareObjectEqual(left, 1, true))
						{
							flag = false;
						}
						else if (Operators.ConditionalCompareObjectEqual(left, 2, true))
						{
							flag = true;
						}
					}
					if (flag && File.Exists(Version.Path + Version.Name + ".jar"))
					{
						return null;
					}
					if (fileChecker.Check(Version.Path + Version.Name + ".jar") == null)
					{
						return null;
					}
				}
				string mojangBase = (string)Version.DestroyPrototype()["downloads"]["client"]["url"];
				return new ModNet.NetFile(ModDownload.DlSourceLauncherOrMetaGet(mojangBase, true), Version.Path + Version.Name + ".jar", fileChecker);
			}
			throw new Exception("底层版本 " + Version.Name + " 中无 Jar 文件下载信息");
		}

		// Token: 0x06000934 RID: 2356 RVA: 0x00040724 File Offset: 0x0003E924
		public static ModNet.NetFile DlClientAssetIndexGet(ModMinecraft.McVersion Version)
		{
			while (!string.IsNullOrEmpty(Version.PrintPrototype()))
			{
				Version = new ModMinecraft.McVersion(Version.PrintPrototype());
			}
			JToken jtoken = ModMinecraft.McAssetsGetIndex(Version, true, true);
			string localPath = ModMinecraft._MapperTag + "assets\\indexes\\" + jtoken["id"].ToString() + ".json";
			ModBase.Log("[Download] 版本 " + Version.Name + " 对应的资源文件索引为 " + jtoken["id"].ToString(), ModBase.LogLevel.Normal, "出现错误");
			string text = (string)(jtoken["url"] ?? "");
			ModNet.NetFile result;
			if (Operators.CompareString(text, "", true) == 0)
			{
				result = null;
			}
			else
			{
				result = new ModNet.NetFile(ModDownload.DlSourceLauncherOrMetaGet(text, false), localPath, new ModBase.FileChecker(-1L, -1L, null, false, true));
			}
			return result;
		}

		// Token: 0x06000935 RID: 2357 RVA: 0x00040808 File Offset: 0x0003EA08
		public static List<ModLoader.LoaderBase> DlClientFix(ModMinecraft.McVersion Version, bool CheckAssetsHash, ModDownload.AssetsIndexExistsBehaviour AssetsIndexBehaviour, bool SkipAssetsDownloadWhileSetupRequired)
		{
			List<ModLoader.LoaderBase> list = new List<ModLoader.LoaderBase>();
			List<ModLoader.LoaderBase> loaders = new List<ModLoader.LoaderBase>
			{
				new ModLoader.LoaderTask<string, List<ModNet.NetFile>>("分析缺失支持库文件", delegate(ModLoader.LoaderTask<string, List<ModNet.NetFile>> Task)
				{
					Task.Output = ModMinecraft.McLibFix(Version, false);
				}, null, ThreadPriority.Normal)
				{
					ProgressWeight = 1.0
				},
				new ModNet.LoaderDownload("下载支持库文件", new List<ModNet.NetFile>())
				{
					ProgressWeight = 15.0
				}
			};
			list.Add(new ModLoader.LoaderCombo<string>("下载支持库文件（主加载器）", loaders)
			{
				Block = false,
				Show = false,
				ProgressWeight = 16.0
			});
			bool flag = Conversions.ToBoolean(ModBase._ParamsState.Get("LaunchAdvanceAssets", null));
			object left = ModBase._ParamsState.Get("VersionAdvanceAssets", Version);
			if (!Operators.ConditionalCompareObjectEqual(left, 0, true))
			{
				if (Operators.ConditionalCompareObjectEqual(left, 1, true))
				{
					flag = false;
				}
				else if (Operators.ConditionalCompareObjectEqual(left, 2, true))
				{
					flag = true;
				}
			}
			if (flag)
			{
				ModBase.Log("[Download] 已跳过 Assets 下载", ModBase.LogLevel.Normal, "出现错误");
			}
			if (!SkipAssetsDownloadWhileSetupRequired || !flag)
			{
				List<ModLoader.LoaderBase> list2 = new List<ModLoader.LoaderBase>();
				list2.Add(new ModLoader.LoaderTask<string, List<ModNet.NetFile>>("分析资源文件索引地址", delegate(ModLoader.LoaderTask<string, List<ModNet.NetFile>> Task)
				{
					try
					{
						ModNet.NetFile netFile = ModDownload.DlClientAssetIndexGet(Version);
						new FileInfo(netFile.m_ModelProccesor);
						if (AssetsIndexBehaviour != ModDownload.AssetsIndexExistsBehaviour.AlwaysDownload && netFile.stateProccesor.Check(netFile.m_ModelProccesor) == null)
						{
							Task.Output = new List<ModNet.NetFile>();
						}
						else
						{
							Task.Output = new List<ModNet.NetFile>
							{
								netFile
							};
						}
					}
					catch (Exception innerException)
					{
						throw new Exception("分析资源文件索引地址失败", innerException);
					}
				}, null, ThreadPriority.Normal)
				{
					ProgressWeight = 0.5,
					Show = false
				});
				list2.Add(new ModNet.LoaderDownload("下载资源文件索引", new List<ModNet.NetFile>())
				{
					ProgressWeight = 2.0
				});
				if (AssetsIndexBehaviour == ModDownload.AssetsIndexExistsBehaviour.DownloadInBackground)
				{
					List<ModLoader.LoaderBase> list3 = new List<ModLoader.LoaderBase>();
					string TempAddress = null;
					string RealAddress = null;
					list3.Add(new ModLoader.LoaderTask<string, List<ModNet.NetFile>>("后台分析资源文件索引地址", delegate(ModLoader.LoaderTask<string, List<ModNet.NetFile>> Task)
					{
						ModNet.NetFile netFile = ModDownload.DlClientAssetIndexGet(Version);
						RealAddress = netFile.m_ModelProccesor;
						TempAddress = ModBase.attributeState + "Cache\\" + netFile.m_WrapperProccesor;
						netFile.m_ModelProccesor = TempAddress;
						Task.Output = new List<ModNet.NetFile>
						{
							netFile
						};
					}, null, ThreadPriority.Normal));
					list3.Add(new ModNet.LoaderDownload("后台下载资源文件索引", new List<ModNet.NetFile>()));
					list3.Add(new ModLoader.LoaderTask<List<ModNet.NetFile>, string>("后台复制资源文件索引", delegate(ModLoader.LoaderTask<List<ModNet.NetFile>, string> Task)
					{
						try
						{
							File.Copy(TempAddress, RealAddress, true);
							ModLaunch.McLaunchLog("后台更新资源文件索引成功：" + TempAddress);
						}
						catch (Exception ex)
						{
							ModBase.Log(ex, "后台更新资源文件索引失败", ModBase.LogLevel.Debug, "出现错误");
							ModLaunch.McLaunchLog("后台更新资源文件索引失败：" + TempAddress);
						}
					}, null, ThreadPriority.Normal));
					ModLoader.LoaderCombo<string> loaderCombo = new ModLoader.LoaderCombo<string>("后台更新资源文件索引", list3);
					ModBase.Log("[Download] 开始后台更新资源文件索引", ModBase.LogLevel.Normal, "出现错误");
					loaderCombo.Start(null, false);
				}
				list2.Add(new ModLoader.LoaderTask<string, List<ModNet.NetFile>>("分析缺失资源文件", delegate(ModLoader.LoaderTask<string, List<ModNet.NetFile>> Task)
				{
					ModLoader.LoaderTask<string, List<ModNet.NetFile>> loaderTask = Task;
					string indexAddress = ModMinecraft.McAssetsGetIndexName(Version);
					bool $VB$Local_CheckAssetsHash = CheckAssetsHash;
					ModLoader.LoaderBase loaderBase = Task;
					List<ModNet.NetFile> output = ModMinecraft.McAssetsFixList(indexAddress, $VB$Local_CheckAssetsHash, ref loaderBase);
					Task = (ModLoader.LoaderTask<string, List<ModNet.NetFile>>)loaderBase;
					loaderTask.Output = output;
				}, null, ThreadPriority.Normal)
				{
					ProgressWeight = 3.0
				});
				list2.Add(new ModNet.LoaderDownload("下载资源文件", new List<ModNet.NetFile>())
				{
					ProgressWeight = 25.0
				});
				list.Add(new ModLoader.LoaderCombo<string>("下载资源文件（主加载器）", list2)
				{
					Block = false,
					Show = false,
					ProgressWeight = 30.5
				});
			}
			return list;
		}

		// Token: 0x06000936 RID: 2358 RVA: 0x00040ACC File Offset: 0x0003ECCC
		private static void DlClientListMain(ModLoader.LoaderTask<int, ModDownload.DlClientListResult> Loader)
		{
			object left = ModBase._ParamsState.Get("ToolDownloadVersion", null);
			if (Operators.ConditionalCompareObjectEqual(left, 0, true))
			{
				ModDownload.DlSourceLoader<int, ModDownload.DlClientListResult>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlClientListResult>, int>>
				{
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlClientListResult>, int>(ModDownload.eventTag, 30),
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlClientListResult>, int>(ModDownload.m_DescriptorTag, 60)
				}, Loader.IsForceRestarting);
				return;
			}
			if (Operators.ConditionalCompareObjectEqual(left, 1, true))
			{
				ModDownload.DlSourceLoader<int, ModDownload.DlClientListResult>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlClientListResult>, int>>
				{
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlClientListResult>, int>(ModDownload.m_DescriptorTag, 5),
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlClientListResult>, int>(ModDownload.eventTag, 35)
				}, Loader.IsForceRestarting);
				return;
			}
			ModDownload.DlSourceLoader<int, ModDownload.DlClientListResult>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlClientListResult>, int>>
			{
				new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlClientListResult>, int>(ModDownload.m_DescriptorTag, 60),
				new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlClientListResult>, int>(ModDownload.eventTag, 60)
			}, Loader.IsForceRestarting);
		}

		// Token: 0x06000937 RID: 2359 RVA: 0x00040BA8 File Offset: 0x0003EDA8
		private static void DlClientListMojangMain(ModLoader.LoaderTask<int, ModDownload.DlClientListResult> Loader)
		{
			JObject jobject = (JObject)ModNet.NetGetCodeByRequestRetry("https://launchermeta.mojang.com/mc/game/version_manifest.json", null, "", true);
			try
			{
				JArray jarray = (JArray)jobject["versions"];
				if (jarray.Count < 200)
				{
					throw new Exception("获取到的版本列表长度不足（" + jobject.ToString() + "）");
				}
				if (File.Exists(ModBase.attributeState + "Cache\\download.json"))
				{
					jarray.Merge(RuntimeHelpers.GetObjectValue(ModBase.GetJson(ModBase.ReadFile(ModBase.attributeState + "Cache\\download.json"))));
				}
				Loader.Output = new ModDownload.DlClientListResult
				{
					m_TestProccesor = true,
					_WatcherProccesor = "Mojang 官方源",
					Value = jobject
				};
				string text = (string)jobject["latest"]["release"];
				if (Conversions.ToBoolean(Conversions.ToBoolean(ModBase._ParamsState.Get("ToolUpdateRelease", null)) && Conversions.ToBoolean(Operators.NotObject(Operators.CompareObjectEqual(ModBase._ParamsState.Get("ToolUpdateReleaseLast", null), "", true))) && text != null && Conversions.ToBoolean(Operators.NotObject(Operators.CompareObjectEqual(ModBase._ParamsState.Get("ToolUpdateReleaseLast", null), text, true)))))
				{
					ModMinecraft.McDownloadClientUpdateHint(text, jobject);
					ModDownload.m_MapTag = true;
				}
				ModBase._ParamsState.Set("ToolUpdateReleaseLast", text, false, null);
				text = (string)jobject["latest"]["snapshot"];
				if (Conversions.ToBoolean(Conversions.ToBoolean(ModBase._ParamsState.Get("ToolUpdateSnapshot", null)) && Conversions.ToBoolean(Operators.NotObject(Operators.CompareObjectEqual(ModBase._ParamsState.Get("ToolUpdateSnapshotLast", null), "", true))) && text != null && Conversions.ToBoolean(Operators.NotObject(Operators.CompareObjectEqual(ModBase._ParamsState.Get("ToolUpdateSnapshotLast", null), text, true))) && !ModDownload.m_MapTag))
				{
					ModMinecraft.McDownloadClientUpdateHint(text, jobject);
				}
				ModBase._ParamsState.Set("ToolUpdateSnapshotLast", text ?? "Nothing", false, null);
			}
			catch (Exception innerException)
			{
				throw new Exception("版本列表解析失败", innerException);
			}
		}

		// Token: 0x06000938 RID: 2360 RVA: 0x00040E00 File Offset: 0x0003F000
		private static void DlClientListBmclapiMain(ModLoader.LoaderTask<int, ModDownload.DlClientListResult> Loader)
		{
			JObject jobject = (JObject)ModNet.NetGetCodeByRequestRetry("https://bmclapi2.bangbang93.com/mc/game/version_manifest.json", null, "", true);
			try
			{
				JArray jarray = (JArray)jobject["versions"];
				if (jarray.Count < 200)
				{
					throw new Exception("获取到的版本列表长度不足（" + jobject.ToString() + "）");
				}
				if (File.Exists(ModBase.attributeState + "Cache\\download.json"))
				{
					jarray.Merge(RuntimeHelpers.GetObjectValue(ModBase.GetJson(ModBase.ReadFile(ModBase.attributeState + "Cache\\download.json"))));
				}
				Loader.Output = new ModDownload.DlClientListResult
				{
					m_TestProccesor = false,
					_WatcherProccesor = "BMCLAPI",
					Value = jobject
				};
			}
			catch (Exception innerException)
			{
				throw new Exception("版本列表解析失败（" + jobject.ToString() + "）", innerException);
			}
		}

		// Token: 0x06000939 RID: 2361 RVA: 0x00040EF8 File Offset: 0x0003F0F8
		public static object DlClientListGet(string Id)
		{
			object result;
			try
			{
				switch (ModDownload.propertyTag.State)
				{
				case ModBase.LoadState.Waiting:
				case ModBase.LoadState.Failed:
				case ModBase.LoadState.Aborted:
					ModDownload.propertyTag.WaitForExit(null, null, true);
					break;
				case ModBase.LoadState.Loading:
					ModDownload.propertyTag.WaitForExit(null, null, false);
					break;
				}
				Id = Id.Replace("_", "-");
				if (Operators.CompareString(Id, "1.0", true) != 0 && Id.EndsWith(".0"))
				{
					Id = Strings.Left(Id, checked(Id.Length - 2));
				}
				try
				{
					foreach (JToken jtoken in ModDownload.propertyTag.Output.Value["versions"])
					{
						JObject jobject = (JObject)jtoken;
						if ((string)jobject["id"] == Id)
						{
							return jobject["url"].ToString();
						}
					}
				}
				finally
				{
					IEnumerator<JToken> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				ModBase.Log("未发现版本 " + Id + " 的 Json 下载地址，版本列表返回为：\r\n" + ModDownload.propertyTag.Output.Value.ToString(), ModBase.LogLevel.Debug, "出现错误");
				result = null;
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "获取版本 " + Id + " 的 Json 下载地址失败", ModBase.LogLevel.Debug, "出现错误");
				result = null;
			}
			return result;
		}

		// Token: 0x0600093A RID: 2362 RVA: 0x0004108C File Offset: 0x0003F28C
		private static void DlOptiFineListMain(ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult> Loader)
		{
			object left = ModBase._ParamsState.Get("ToolDownloadVersion", null);
			if (Operators.ConditionalCompareObjectEqual(left, 0, true))
			{
				ModDownload.DlSourceLoader<int, ModDownload.DlOptiFineListResult>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult>, int>>
				{
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult>, int>(ModDownload._PublisherTag, 30),
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult>, int>(ModDownload.m_PoolTag, 60)
				}, Loader.IsForceRestarting);
				return;
			}
			if (Operators.ConditionalCompareObjectEqual(left, 1, true))
			{
				ModDownload.DlSourceLoader<int, ModDownload.DlOptiFineListResult>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult>, int>>
				{
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult>, int>(ModDownload.m_PoolTag, 5),
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult>, int>(ModDownload._PublisherTag, 35)
				}, Loader.IsForceRestarting);
				return;
			}
			ModDownload.DlSourceLoader<int, ModDownload.DlOptiFineListResult>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult>, int>>
			{
				new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult>, int>(ModDownload.m_PoolTag, 60),
				new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult>, int>(ModDownload._PublisherTag, 60)
			}, Loader.IsForceRestarting);
		}

		// Token: 0x0600093B RID: 2363 RVA: 0x00041168 File Offset: 0x0003F368
		private static void DlOptiFineListOfficialMain(ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult> Loader)
		{
			string text = ModNet.NetGetCodeByClient("https://optifine.net/downloads", Encoding.Default, "application/json, text/javascript, */*; q=0.01");
			if (text.Length < 200)
			{
				throw new Exception("获取到的版本列表长度不足（" + text + "）");
			}
			List<string> list = ModBase.RegexSearch(text, "(?<=Date'>)[^<]+", RegexOptions.None);
			List<string> list2 = ModBase.RegexSearch(text, "(?<=OptiFine_)[0-9A-Za-z_.]+(?=.jar\")", RegexOptions.None);
			if (list.Count != list2.Count)
			{
				throw new Exception("版本与发布时间数据无法对应");
			}
			if (list.Count < 10)
			{
				throw new Exception("获取到的版本数量不足（" + text + "）");
			}
			List<ModDownload.DlOptiFineListEntry> list3 = new List<ModDownload.DlOptiFineListEntry>();
			checked
			{
				int num = list.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					list2[i] = list2[i].Replace("_", " ");
					ModDownload.DlOptiFineListEntry dlOptiFineListEntry = new ModDownload.DlOptiFineListEntry();
					dlOptiFineListEntry.m_SerializerProccesor = list2[i].ToString().Replace("HD U ", "").Replace(".0 ", " ");
					dlOptiFineListEntry._HelperProccesor = ModBase.Join(new string[]
					{
						list[i].Split(new char[]
						{
							'.'
						})[2],
						list[i].Split(new char[]
						{
							'.'
						})[1],
						list[i].Split(new char[]
						{
							'.'
						})[0]
					}, "/");
					dlOptiFineListEntry.m_RecordProccesor = list2[i].ToString().ToLower().Contains("pre");
					dlOptiFineListEntry.PublishComparator(list2[i].ToString().Split(new char[]
					{
						' '
					})[0]);
					dlOptiFineListEntry.m_RoleProccesor = (list2[i].ToString().ToLower().Contains("pre") ? "preview_" : "") + "OptiFine_" + list2[i].ToString().Replace(" ", "_") + ".jar";
					ModDownload.DlOptiFineListEntry dlOptiFineListEntry2 = dlOptiFineListEntry;
					if (Operators.CompareString(dlOptiFineListEntry2.m_SerializerProccesor, "1.17.1 G9", true) != 0)
					{
						dlOptiFineListEntry2._ValueProccesor = dlOptiFineListEntry2.CustomizeComparator() + "-OptiFine_" + list2[i].ToString().Replace(" ", "_").Replace(dlOptiFineListEntry2.CustomizeComparator() + "_", "");
						list3.Add(dlOptiFineListEntry2);
					}
				}
				Loader.Output = new ModDownload.DlOptiFineListResult
				{
					_IteratorProccesor = true,
					taskProccesor = "OptiFine 官方源",
					Value = list3
				};
			}
		}

		// Token: 0x0600093C RID: 2364 RVA: 0x00041430 File Offset: 0x0003F630
		private static void DlOptiFineListBmclapiMain(ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult> Loader)
		{
			JArray jarray = (JArray)ModNet.NetGetCodeByRequestRetry("https://bmclapi2.bangbang93.com/optifine/versionList", null, "", true);
			try
			{
				List<ModDownload.DlOptiFineListEntry> list = new List<ModDownload.DlOptiFineListEntry>();
				try
				{
					foreach (JToken jtoken in jarray)
					{
						JObject jobject = (JObject)jtoken;
						ModDownload.DlOptiFineListEntry dlOptiFineListEntry = new ModDownload.DlOptiFineListEntry();
						dlOptiFineListEntry.m_SerializerProccesor = (jobject["mcversion"].ToString() + jobject["type"].ToString().Replace("HD_U", "").Replace("_", " ") + " " + jobject["patch"].ToString()).Replace(".0 ", " ");
						dlOptiFineListEntry._HelperProccesor = "";
						dlOptiFineListEntry.m_RecordProccesor = jobject["patch"].ToString().ToLower().Contains("pre");
						dlOptiFineListEntry.PublishComparator(jobject["mcversion"].ToString());
						dlOptiFineListEntry.m_RoleProccesor = jobject["filename"].ToString();
						ModDownload.DlOptiFineListEntry dlOptiFineListEntry2 = dlOptiFineListEntry;
						if (Operators.CompareString(dlOptiFineListEntry2.m_SerializerProccesor, "1.17.1 G9", true) != 0)
						{
							dlOptiFineListEntry2._ValueProccesor = dlOptiFineListEntry2.CustomizeComparator() + "-OptiFine_" + (jobject["type"].ToString() + " " + jobject["patch"].ToString()).Replace(".0 ", " ").Replace(" ", "_").Replace(dlOptiFineListEntry2.CustomizeComparator() + "_", "");
							list.Add(dlOptiFineListEntry2);
						}
					}
				}
				finally
				{
					IEnumerator<JToken> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				Loader.Output = new ModDownload.DlOptiFineListResult
				{
					_IteratorProccesor = false,
					taskProccesor = "BMCLAPI",
					Value = list
				};
			}
			catch (Exception innerException)
			{
				throw new Exception("版本列表解析失败（" + jarray.ToString() + "）", innerException);
			}
		}

		// Token: 0x0600093D RID: 2365 RVA: 0x0004167C File Offset: 0x0003F87C
		private static void DlForgeListMain(ModLoader.LoaderTask<int, ModDownload.DlForgeListResult> Loader)
		{
			object left = ModBase._ParamsState.Get("ToolDownloadVersion", null);
			if (Operators.ConditionalCompareObjectEqual(left, 0, true))
			{
				ModDownload.DlSourceLoader<int, ModDownload.DlForgeListResult>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlForgeListResult>, int>>
				{
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlForgeListResult>, int>(ModDownload._TaskTag, 30),
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlForgeListResult>, int>(ModDownload.m_TestTag, 60)
				}, Loader.IsForceRestarting);
				return;
			}
			if (Operators.ConditionalCompareObjectEqual(left, 1, true))
			{
				ModDownload.DlSourceLoader<int, ModDownload.DlForgeListResult>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlForgeListResult>, int>>
				{
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlForgeListResult>, int>(ModDownload.m_TestTag, 5),
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlForgeListResult>, int>(ModDownload._TaskTag, 35)
				}, Loader.IsForceRestarting);
				return;
			}
			ModDownload.DlSourceLoader<int, ModDownload.DlForgeListResult>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlForgeListResult>, int>>
			{
				new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlForgeListResult>, int>(ModDownload.m_TestTag, 60),
				new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlForgeListResult>, int>(ModDownload._TaskTag, 60)
			}, Loader.IsForceRestarting);
		}

		// Token: 0x0600093E RID: 2366 RVA: 0x00041758 File Offset: 0x0003F958
		private static void DlForgeListOfficialMain(ModLoader.LoaderTask<int, ModDownload.DlForgeListResult> Loader)
		{
			string text = Conversions.ToString(ModNet.NetGetCodeByRequestRetry("http://files.minecraftforge.net/maven/net/minecraftforge/forge/index_1.2.4.html", Encoding.Default, "text/html", false));
			if (text.Length < 200)
			{
				throw new Exception("获取到的版本列表长度不足（" + text + "）");
			}
			List<string> list = ModBase.RegexSearch(text, "(?<=a href=\"index_)[0-9.]+(_pre[0-9]?)?(?=.html)", RegexOptions.None);
			list.Add("1.2.4");
			if (list.Count < 10)
			{
				throw new Exception("获取到的版本数量不足（" + text + "）");
			}
			Loader.Output = new ModDownload.DlForgeListResult
			{
				_BaseProccesor = true,
				m_ParamProccesor = "Forge 官方源",
				Value = list
			};
		}

		// Token: 0x0600093F RID: 2367 RVA: 0x00041808 File Offset: 0x0003FA08
		private static void DlForgeListBmclapiMain(ModLoader.LoaderTask<int, ModDownload.DlForgeListResult> Loader)
		{
			string text = Conversions.ToString(ModNet.NetGetCodeByRequestRetry("https://bmclapi2.bangbang93.com/forge/minecraft", Encoding.Default, "", false));
			if (text.Length < 200)
			{
				throw new Exception("获取到的版本列表长度不足（" + text + "）");
			}
			List<string> list = ModBase.RegexSearch(text, "[0-9.]+(_pre[0-9]?)?", RegexOptions.None);
			if (list.Count < 10)
			{
				throw new Exception("获取到的版本数量不足（" + text + "）");
			}
			Loader.Output = new ModDownload.DlForgeListResult
			{
				_BaseProccesor = false,
				m_ParamProccesor = "BMCLAPI",
				Value = list
			};
		}

		// Token: 0x06000940 RID: 2368 RVA: 0x000418AC File Offset: 0x0003FAAC
		public static void DlForgeVersionMain(ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>> Loader)
		{
			ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>> key = new ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>("DlForgeVersion Official", new Action<ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>>(ModDownload.DlForgeVersionOfficialMain), null, ThreadPriority.Normal);
			ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>> key2 = new ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>("DlForgeVersion Bmclapi", new Action<ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>>(ModDownload.DlForgeVersionBmclapiMain), null, ThreadPriority.Normal);
			object left = ModBase._ParamsState.Get("ToolDownloadVersion", null);
			if (Operators.ConditionalCompareObjectEqual(left, 0, true))
			{
				ModDownload.DlSourceLoader<string, List<ModDownload.DlForgeVersionEntry>>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>, int>>
				{
					new KeyValuePair<ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>, int>(key2, 30),
					new KeyValuePair<ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>, int>(key, 60)
				}, Loader.IsForceRestarting);
				return;
			}
			if (Operators.ConditionalCompareObjectEqual(left, 1, true))
			{
				ModDownload.DlSourceLoader<string, List<ModDownload.DlForgeVersionEntry>>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>, int>>
				{
					new KeyValuePair<ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>, int>(key, 5),
					new KeyValuePair<ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>, int>(key2, 35)
				}, Loader.IsForceRestarting);
				return;
			}
			ModDownload.DlSourceLoader<string, List<ModDownload.DlForgeVersionEntry>>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>, int>>
			{
				new KeyValuePair<ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>, int>(key, 60),
				new KeyValuePair<ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>>, int>(key2, 60)
			}, Loader.IsForceRestarting);
		}

		// Token: 0x06000941 RID: 2369 RVA: 0x000419A4 File Offset: 0x0003FBA4
		public static void DlForgeVersionOfficialMain(ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>> Loader)
		{
			string text;
			try
			{
				text = ModNet.NetGetCodeByDownload("http://files.minecraftforge.net/maven/net/minecraftforge/forge/index_" + Loader.Input + ".html", 45000, false);
			}
			catch (Exception ex)
			{
				if (ModBase.GetString(ex, true, false).Contains("(404)"))
				{
					throw new Exception("没有可用版本");
				}
				throw;
			}
			if (text.Length < 1000)
			{
				throw new Exception("获取到的版本列表长度不足（" + text + "）");
			}
			List<ModDownload.DlForgeVersionEntry> list = new List<ModDownload.DlForgeVersionEntry>();
			checked
			{
				try
				{
					string[] array = Strings.Mid(text, 1, text.LastIndexOf("</table>")).Replace("<td class=\"download-version", "¨").Split(new char[]
					{
						'¨'
					});
					int num = array.Count<string>() - 1;
					for (int i = 1; i <= num; i++)
					{
						string text2 = array[i];
						try
						{
							string text3 = ModBase.RegexSeek(text2, "(?<=[^(0-9)]+)[0-9\\.]+", RegexOptions.None);
							bool structProccesor = text2.Contains("fa promo-recommended");
							string input = Loader.Input;
							string text4 = ModBase.RegexSeek(text2, "(?<=Branch:</strong>[\\s]*)[^<]+", RegexOptions.None);
							text4 = ModBase.RegexSeek(text4 ?? "", "[^\\s]+", RegexOptions.None);
							if (string.IsNullOrWhiteSpace(text4))
							{
								text4 = null;
							}
							if (Operators.CompareString(text3, "11.15.1.2318", true) == 0 || Operators.CompareString(text3, "11.15.1.1902", true) == 0 || Operators.CompareString(text3, "11.15.1.1890", true) == 0)
							{
								text4 = "1.8.9";
							}
							if (text4 == null && Operators.CompareString(input, "1.7.10", true) == 0 && Conversions.ToDouble(text3.Split(new char[]
							{
								'.'
							})[3]) >= 1300.0)
							{
								text4 = "1.7.10";
							}
							string[] array2 = ModBase.RegexSeek(text2, "(?<=\"download-time\" title=\")[^\"]+", RegexOptions.None).Split(" -:".ToCharArray());
							string facadeProccesor = new DateTime(Conversions.ToInteger(array2[0]), Conversions.ToInteger(array2[1]), Conversions.ToInteger(array2[2]), Conversions.ToInteger(array2[3]), Conversions.ToInteger(array2[4]), Conversions.ToInteger(array2[5]), 0, DateTimeKind.Utc).ToLocalTime().ToString("yyyy/MM/dd HH:mm");
							string text5;
							string indexerProccesor;
							if (text2.Contains("classifier-installer\""))
							{
								text2 = text2.Substring(text2.IndexOf("installer.jar"));
								text5 = ModBase.RegexSeek(text2, "(?<=MD5:</strong> )[^<]+", RegexOptions.None);
								indexerProccesor = "installer";
							}
							else if (text2.Contains("classifier-universal\""))
							{
								text2 = text2.Substring(text2.IndexOf("universal.zip"));
								text5 = ModBase.RegexSeek(text2, "(?<=MD5:</strong> )[^<]+", RegexOptions.None);
								indexerProccesor = "universal";
							}
							else
							{
								text2 = text2.Substring(text2.IndexOf("client.zip"));
								text5 = ModBase.RegexSeek(text2, "(?<=MD5:</strong> )[^<]+", RegexOptions.None);
								indexerProccesor = "client";
							}
							list.Add(new ModDownload.DlForgeVersionEntry
							{
								_IndexerProccesor = indexerProccesor,
								productProccesor = text3,
								m_StructProccesor = structProccesor,
								m_BridgeProccesor = text5.Trim(new char[]
								{
									'\r',
									'\n'
								}),
								m_AttrProccesor = input,
								facadeProccesor = facadeProccesor,
								templateProccesor = text4
							});
						}
						catch (Exception innerException)
						{
							throw new Exception("版本信息提取失败（" + text2 + "）", innerException);
						}
					}
				}
				catch (Exception innerException2)
				{
					throw new Exception("版本列表解析失败（" + text + "）", innerException2);
				}
				if (list.Count == 0)
				{
					throw new Exception("没有可用版本");
				}
				Loader.Output = list;
			}
		}

		// Token: 0x06000942 RID: 2370 RVA: 0x00041D70 File Offset: 0x0003FF70
		public static void DlForgeVersionBmclapiMain(ModLoader.LoaderTask<string, List<ModDownload.DlForgeVersionEntry>> Loader)
		{
			JArray jarray = (JArray)ModNet.NetGetCodeByRequestRetry("https://bmclapi2.bangbang93.com/forge/minecraft/" + Loader.Input, null, "", true);
			List<ModDownload.DlForgeVersionEntry> list = new List<ModDownload.DlForgeVersionEntry>();
			try
			{
				string left = ModDownloadLib.McDownloadForgeRecommendedGet(Loader.Input);
				try
				{
					foreach (JToken jtoken in jarray)
					{
						JObject jobject = (JObject)jtoken;
						string bridgeProccesor = null;
						string indexerProccesor = "unknown";
						int num = -1;
						try
						{
							foreach (JToken jtoken2 in jobject["files"])
							{
								JObject jobject2 = (JObject)jtoken2;
								string left2 = jobject2["category"].ToString();
								if (Operators.CompareString(left2, "installer", true) == 0)
								{
									if (Operators.CompareString(jobject2["format"].ToString(), "jar", true) == 0)
									{
										bridgeProccesor = (string)jobject2["hash"];
										indexerProccesor = "installer";
										num = 2;
									}
								}
								else if (Operators.CompareString(left2, "universal", true) == 0)
								{
									if (num <= 1 && Operators.CompareString(jobject2["format"].ToString(), "zip", true) == 0)
									{
										bridgeProccesor = (string)jobject2["hash"];
										indexerProccesor = "universal";
										num = 1;
									}
								}
								else if (Operators.CompareString(left2, "client", true) == 0 && num <= 0 && Operators.CompareString(jobject2["format"].ToString(), "zip", true) == 0)
								{
									bridgeProccesor = (string)jobject2["hash"];
									indexerProccesor = "client";
									num = 0;
								}
							}
						}
						finally
						{
							IEnumerator<JToken> enumerator2;
							if (enumerator2 != null)
							{
								enumerator2.Dispose();
							}
						}
						string input = Loader.Input;
						string text = (string)jobject["branch"];
						string text2 = (string)jobject["version"];
						if (Operators.CompareString(text2, "11.15.1.2318", true) == 0 || Operators.CompareString(text2, "11.15.1.1902", true) == 0 || Operators.CompareString(text2, "11.15.1.1890", true) == 0)
						{
							text = "1.8.9";
						}
						if (text == null && Operators.CompareString(input, "1.7.10", true) == 0 && Conversions.ToDouble(text2.Split(new char[]
						{
							'.'
						})[3]) >= 1300.0)
						{
							text = "1.7.10";
						}
						ModDownload.DlForgeVersionEntry dlForgeVersionEntry = new ModDownload.DlForgeVersionEntry
						{
							m_BridgeProccesor = bridgeProccesor,
							_IndexerProccesor = indexerProccesor,
							productProccesor = text2,
							templateProccesor = text,
							m_AttrProccesor = input,
							m_StructProccesor = (Operators.CompareString(left, text2, true) == 0)
						};
						jobject["modified"].ToString().Split(new char[]
						{
							'-',
							'T',
							':',
							'.',
							' ',
							'/'
						});
						dlForgeVersionEntry.facadeProccesor = jobject["modified"].ToObject<DateTime>().ToLocalTime().ToString("yyyy/MM/dd HH:mm");
						list.Add(dlForgeVersionEntry);
					}
				}
				finally
				{
					IEnumerator<JToken> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
			}
			catch (Exception innerException)
			{
				throw new Exception("版本列表解析失败（" + jarray.ToString() + "）", innerException);
			}
			if (list.Count == 0)
			{
				throw new Exception("没有可用版本");
			}
			Loader.Output = list;
		}

		// Token: 0x06000943 RID: 2371 RVA: 0x00042104 File Offset: 0x00040304
		private static void DlLiteLoaderListMain(ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult> Loader)
		{
			object left = ModBase._ParamsState.Get("ToolDownloadVersion", null);
			if (Operators.ConditionalCompareObjectEqual(left, 0, true))
			{
				ModDownload.DlSourceLoader<int, ModDownload.DlLiteLoaderListResult>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult>, int>>
				{
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult>, int>(ModDownload._RoleTag, 30),
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult>, int>(ModDownload._SerializerTag, 60)
				}, Loader.IsForceRestarting);
				return;
			}
			if (Operators.ConditionalCompareObjectEqual(left, 1, true))
			{
				ModDownload.DlSourceLoader<int, ModDownload.DlLiteLoaderListResult>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult>, int>>
				{
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult>, int>(ModDownload._SerializerTag, 5),
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult>, int>(ModDownload._RoleTag, 35)
				}, Loader.IsForceRestarting);
				return;
			}
			ModDownload.DlSourceLoader<int, ModDownload.DlLiteLoaderListResult>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult>, int>>
			{
				new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult>, int>(ModDownload._SerializerTag, 60),
				new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult>, int>(ModDownload._RoleTag, 60)
			}, Loader.IsForceRestarting);
		}

		// Token: 0x06000944 RID: 2372 RVA: 0x000421E0 File Offset: 0x000403E0
		private static void DlLiteLoaderListOfficialMain(ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult> Loader)
		{
			JObject jobject = (JObject)ModNet.NetGetCodeByRequestRetry("http://dl.liteloader.com/versions/versions.json", null, "", true);
			try
			{
				JObject jobject2 = (JObject)jobject["versions"];
				List<ModDownload.DlLiteLoaderListEntry> list = new List<ModDownload.DlLiteLoaderListEntry>();
				try
				{
					foreach (KeyValuePair<string, JToken> keyValuePair in jobject2)
					{
						if (!keyValuePair.Key.StartsWith("1.6") && !keyValuePair.Key.StartsWith("1.5"))
						{
							JToken jtoken = (keyValuePair.Value["artefacts"] ?? keyValuePair.Value["snapshots"])["com.mumfrey:liteloader"]["latest"];
							list.Add(new ModDownload.DlLiteLoaderListEntry
							{
								Inherit = keyValuePair.Key,
								IsLegacy = (Conversions.ToDouble(keyValuePair.Key.Split(new char[]
								{
									'.'
								})[1]) < 8.0),
								IsPreview = (Operators.CompareString(jtoken["stream"].ToString().ToLower(), "snapshot", true) == 0),
								FileName = "liteloader-installer-" + keyValuePair.Key + ((Operators.CompareString(keyValuePair.Key, "1.8", true) == 0 || Operators.CompareString(keyValuePair.Key, "1.9", true) == 0) ? ".0" : "") + "-00-SNAPSHOT.jar",
								MD5 = (string)jtoken["md5"],
								ReleaseTime = ModBase.GetLocalTime(ModBase.GetDate((int)jtoken["timestamp"])).ToString("yyyy/MM/dd HH:mm:ss"),
								JsonToken = jtoken
							});
						}
					}
				}
				finally
				{
					IEnumerator<KeyValuePair<string, JToken>> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				Loader.Output = new ModDownload.DlLiteLoaderListResult
				{
					IsOfficial = true,
					SourceName = "LiteLoader 官方源",
					Value = list
				};
			}
			catch (Exception innerException)
			{
				throw new Exception("版本列表解析失败（" + jobject.ToString() + "）", innerException);
			}
		}

		// Token: 0x06000945 RID: 2373 RVA: 0x00042450 File Offset: 0x00040650
		private static void DlLiteLoaderListBmclapiMain(ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult> Loader)
		{
			JObject jobject = (JObject)ModNet.NetGetCodeByRequestRetry("https://bmclapi2.bangbang93.com/maven/com/mumfrey/liteloader/versions.json", null, "", true);
			try
			{
				JObject jobject2 = (JObject)jobject["versions"];
				List<ModDownload.DlLiteLoaderListEntry> list = new List<ModDownload.DlLiteLoaderListEntry>();
				try
				{
					foreach (KeyValuePair<string, JToken> keyValuePair in jobject2)
					{
						if (!keyValuePair.Key.StartsWith("1.6") && !keyValuePair.Key.StartsWith("1.5"))
						{
							JToken jtoken = (keyValuePair.Value["artefacts"] ?? keyValuePair.Value["snapshots"])["com.mumfrey:liteloader"]["latest"];
							list.Add(new ModDownload.DlLiteLoaderListEntry
							{
								Inherit = keyValuePair.Key,
								IsLegacy = (Conversions.ToDouble(keyValuePair.Key.Split(new char[]
								{
									'.'
								})[1]) < 8.0),
								IsPreview = (Operators.CompareString(jtoken["stream"].ToString().ToLower(), "snapshot", true) == 0),
								FileName = "liteloader-installer-" + keyValuePair.Key + ((Operators.CompareString(keyValuePair.Key, "1.8", true) == 0 || Operators.CompareString(keyValuePair.Key, "1.9", true) == 0) ? ".0" : "") + "-00-SNAPSHOT.jar",
								MD5 = (string)jtoken["md5"],
								ReleaseTime = ModBase.GetLocalTime(ModBase.GetDate((int)jtoken["timestamp"])).ToString("yyyy/MM/dd HH:mm:ss"),
								JsonToken = jtoken
							});
						}
					}
				}
				finally
				{
					IEnumerator<KeyValuePair<string, JToken>> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				Loader.Output = new ModDownload.DlLiteLoaderListResult
				{
					IsOfficial = false,
					SourceName = "BMCLAPI",
					Value = list
				};
			}
			catch (Exception innerException)
			{
				throw new Exception("版本列表解析失败（" + jobject.ToString() + "）", innerException);
			}
		}

		// Token: 0x06000946 RID: 2374 RVA: 0x000426C0 File Offset: 0x000408C0
		private static void DlFabricListMain(ModLoader.LoaderTask<int, ModDownload.DlFabricListResult> Loader)
		{
			object left = ModBase._ParamsState.Get("ToolDownloadVersion", null);
			if (Operators.ConditionalCompareObjectEqual(left, 0, true))
			{
				ModDownload.DlSourceLoader<int, ModDownload.DlFabricListResult>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlFabricListResult>, int>>
				{
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlFabricListResult>, int>(ModDownload.m_VisitorTag, 30),
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlFabricListResult>, int>(ModDownload.recordTag, 60)
				}, Loader.IsForceRestarting);
				return;
			}
			if (Operators.ConditionalCompareObjectEqual(left, 1, true))
			{
				ModDownload.DlSourceLoader<int, ModDownload.DlFabricListResult>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlFabricListResult>, int>>
				{
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlFabricListResult>, int>(ModDownload.recordTag, 5),
					new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlFabricListResult>, int>(ModDownload.m_VisitorTag, 35)
				}, Loader.IsForceRestarting);
				return;
			}
			ModDownload.DlSourceLoader<int, ModDownload.DlFabricListResult>(Loader, new List<KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlFabricListResult>, int>>
			{
				new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlFabricListResult>, int>(ModDownload.recordTag, 60),
				new KeyValuePair<ModLoader.LoaderTask<int, ModDownload.DlFabricListResult>, int>(ModDownload.m_VisitorTag, 60)
			}, Loader.IsForceRestarting);
		}

		// Token: 0x06000947 RID: 2375 RVA: 0x0004279C File Offset: 0x0004099C
		private static void DlFabricListOfficialMain(ModLoader.LoaderTask<int, ModDownload.DlFabricListResult> Loader)
		{
			JObject jobject = (JObject)ModNet.NetGetCodeByRequestRetry("https://meta.fabricmc.net/v2/versions", null, "", true);
			try
			{
				ModDownload.DlFabricListResult dlFabricListResult = new ModDownload.DlFabricListResult
				{
					_GetterProccesor = true,
					expressionProccesor = "Fabric 官方源",
					Value = jobject
				};
				if (dlFabricListResult.Value["game"] == null || dlFabricListResult.Value["loader"] == null || dlFabricListResult.Value["installer"] == null)
				{
					throw new Exception("获取到的列表缺乏必要项");
				}
				Loader.Output = dlFabricListResult;
			}
			catch (Exception innerException)
			{
				throw new Exception("列表解析失败（" + jobject.ToString() + "）", innerException);
			}
		}

		// Token: 0x06000948 RID: 2376 RVA: 0x00042864 File Offset: 0x00040A64
		private static void DlFabricListBmclapiMain(ModLoader.LoaderTask<int, ModDownload.DlFabricListResult> Loader)
		{
			JObject jobject = (JObject)ModNet.NetGetCodeByRequestRetry("https://bmclapi2.bangbang93.com/fabric-meta/v2/versions", null, "", true);
			try
			{
				ModDownload.DlFabricListResult dlFabricListResult = new ModDownload.DlFabricListResult
				{
					_GetterProccesor = false,
					expressionProccesor = "BMCLAPI",
					Value = jobject
				};
				if (dlFabricListResult.Value["game"] == null || dlFabricListResult.Value["loader"] == null || dlFabricListResult.Value["installer"] == null)
				{
					throw new Exception("获取到的列表缺乏必要项");
				}
				Loader.Output = dlFabricListResult;
			}
			catch (Exception innerException)
			{
				throw new Exception("列表解析失败（" + jobject.ToString() + "）", innerException);
			}
		}

		// Token: 0x06000949 RID: 2377 RVA: 0x0004292C File Offset: 0x00040B2C
		public static void DlCfProjectSub(ModLoader.LoaderTask<ModDownload.DlCfProjectRequest, ModDownload.DlCfProjectResult> Task)
		{
			string text = Task.Input.m_ObjectProccesor ?? "";
			Task.Input.m_ObjectProccesor = text;
			ModBase.Log("[Download] CurseForge 工程列表搜索原始文本：" + text, ModBase.LogLevel.Normal, "出现错误");
			checked
			{
				bool flag;
				if ((flag = ModBase.RegexCheck(text, "[\\u4e00-\\u9fbb]", RegexOptions.None)) && !string.IsNullOrEmpty(text))
				{
					if (Task.Input.identifierProccesor)
					{
						throw new Exception("整合包搜索仅支持英文");
					}
					if (ModDownload.m_ParamTag == null)
					{
						ModDownload.m_ParamTag = (JObject)ModBase.GetJson(ModBase.DecodeBytes(ModBase.GetResources("ModData")));
					}
					List<ModBase.SearchEntry<string>> list = new List<ModBase.SearchEntry<string>>();
					try
					{
						foreach (KeyValuePair<string, JToken> keyValuePair in ModDownload.m_ParamTag)
						{
							if (!keyValuePair.Value.ToString().Contains("动态的树"))
							{
								list.Add(new ModBase.SearchEntry<string>
								{
									interceptorParameter = keyValuePair.Value.ToString().Split(new char[]
									{
										'|'
									})[1],
									m_RefParameter = new List<KeyValuePair<string, double>>
									{
										new KeyValuePair<string, double>(keyValuePair.Value.ToString().Replace(" (", "|").Split(new char[]
										{
											'|'
										})[1], 1.0)
									}
								});
							}
						}
					}
					finally
					{
						IEnumerator<KeyValuePair<string, JToken>> enumerator;
						if (enumerator != null)
						{
							enumerator.Dispose();
						}
					}
					List<ModBase.SearchEntry<string>> list2 = ModBase.Search<string>(list, Task.Input.m_ObjectProccesor, 3, 0.1);
					if (list2.Count == 0)
					{
						throw new Exception("无搜索结果，请尝试搜索英文名称");
					}
					string text2 = "";
					int num = Math.Min(2, list2.Count - 1);
					for (int i = 0; i <= num; i++)
					{
						text2 = text2 + list2[i].interceptorParameter.Replace(" (", "|").Split(new char[]
						{
							'|'
						}).Last<string>().TrimEnd(new char[]
						{
							')'
						}) + " ";
					}
					ModBase.Log("[Download] CurseForge 工程列表中文搜索原始关键词：" + text2, ModBase.LogLevel.Developer, "出现错误");
					string text3 = "";
					foreach (string text4 in text2.Split(new char[]
					{
						' '
					}))
					{
						if (!new string[]
						{
							"the",
							"of",
							"a"
						}.Contains(text4.ToLower()))
						{
							text3 = text3 + text4 + " ";
						}
					}
					Task.Input.m_ObjectProccesor = text3;
					ModBase.Log("[Download] CurseForge 工程列表中文搜索最终关键词：" + text3, ModBase.LogLevel.Developer, "出现错误");
				}
				string str = ModBase.RegexReplace(Task.Input.m_ObjectProccesor, "$& ", "([A-Z]+|[a-z]+?)(?=[A-Z]+[a-z]+[a-z ]*)", RegexOptions.None);
				string str2 = Task.Input.m_ObjectProccesor.Replace(" ", "");
				string text5 = str + " " + (flag ? Task.Input.m_ObjectProccesor : (str2 + " " + text));
				List<string> list3 = new List<string>();
				foreach (string text6 in text5.Split(new char[]
				{
					' '
				}))
				{
					if (Operators.CompareString(text6.Trim(), "", true) != 0)
					{
						list3.Add(text6);
					}
				}
				Task.Input.m_ObjectProccesor = ModBase.Join(ModBase.ArrayNoDouble<string>(list3, null), " ").ToLower();
				ModBase.Log("[Download] CurseForge 工程列表搜索最终文本：" + Task.Input.m_ObjectProccesor, ModBase.LogLevel.Developer, "出现错误");
				string address = Task.Input.GetAddress();
				ModBase.Log("[Download] 开始获取 CurseForge 工程列表：" + address, ModBase.LogLevel.Normal, "出现错误");
				JObject jobject = (JObject)ModNet.NetGetCodeByRequestRetry(address, Encoding.UTF8, "", true);
				List<ModDownload.DlCfProject> list4 = ModDownload.GetCfProjectListFromJson((JArray)jobject["data"], Task.Input.identifierProccesor);
				if (list4.Count == 0)
				{
					throw new Exception("无搜索结果");
				}
				if (!string.IsNullOrEmpty(Task.Input.m_ObjectProccesor))
				{
					Dictionary<ModDownload.DlCfProject, double> dictionary = new Dictionary<ModDownload.DlCfProject, double>();
					List<ModBase.SearchEntry<ModDownload.DlCfProject>> list5 = new List<ModBase.SearchEntry<ModDownload.DlCfProject>>();
					int count = list4.Count;
					for (int l = 1; l <= count; l++)
					{
						ModDownload.DlCfProject dlCfProject = list4[l - 1];
						dictionary.Add(dlCfProject, unchecked(1.0 - (double)l / (double)list4.Count));
						list5.Add(new ModBase.SearchEntry<ModDownload.DlCfProject>
						{
							interceptorParameter = dlCfProject,
							m_RefParameter = new List<KeyValuePair<string, double>>
							{
								new KeyValuePair<string, double>(flag ? dlCfProject.FlushComparator() : dlCfProject.Name, 1.0),
								new KeyValuePair<string, double>(dlCfProject._MapperProccesor, 0.05)
							}
						});
					}
					List<ModBase.SearchEntry<ModDownload.DlCfProject>> list6 = ModBase.Search<ModDownload.DlCfProject>(list5, text, 101, -1.0);
					try
					{
						foreach (ModBase.SearchEntry<ModDownload.DlCfProject> searchEntry in list6)
						{
							Dictionary<ModDownload.DlCfProject, double> dictionary2;
							ModDownload.DlCfProject interceptorParameter;
							(dictionary2 = dictionary)[interceptorParameter = searchEntry.interceptorParameter] = unchecked(dictionary2[interceptorParameter] + searchEntry.serverParameter / list6[0].serverParameter);
						}
					}
					finally
					{
						List<ModBase.SearchEntry<ModDownload.DlCfProject>>.Enumerator enumerator2;
						((IDisposable)enumerator2).Dispose();
					}
					List<KeyValuePair<ModDownload.DlCfProject, double>> list7 = ModBase.Sort<KeyValuePair<ModDownload.DlCfProject, double>>(dictionary.ToList<KeyValuePair<ModDownload.DlCfProject, double>>(), (ModDownload._Closure$__.$IR54-1 == null) ? (ModDownload._Closure$__.$IR54-1 = ((object a0, object a1) => ((ModDownload._Closure$__.$I54-0 == null) ? (ModDownload._Closure$__.$I54-0 = ((KeyValuePair<ModDownload.DlCfProject, double> Left, KeyValuePair<ModDownload.DlCfProject, double> Right) => Left.Value > Right.Value)) : ModDownload._Closure$__.$I54-0)((a0 != null) ? ((KeyValuePair<ModDownload.DlCfProject, double>)a0) : default(KeyValuePair<ModDownload.DlCfProject, double>), (a1 != null) ? ((KeyValuePair<ModDownload.DlCfProject, double>)a1) : default(KeyValuePair<ModDownload.DlCfProject, double>)))) : ModDownload._Closure$__.$IR54-1);
					list4 = new List<ModDownload.DlCfProject>();
					try
					{
						foreach (KeyValuePair<ModDownload.DlCfProject, double> keyValuePair2 in list7)
						{
							list4.Add(keyValuePair2.Key);
						}
					}
					finally
					{
						List<KeyValuePair<ModDownload.DlCfProject, double>>.Enumerator enumerator3;
						((IDisposable)enumerator3).Dispose();
					}
				}
				Task.Output = new ModDownload.DlCfProjectResult
				{
					m_CallbackProccesor = list4,
					m_AdvisorProccesor = (int)jobject["pagination"]["index"],
					_ObserverProccesor = (long)jobject["pagination"]["totalCount"]
				};
			}
		}

		// Token: 0x0600094A RID: 2378 RVA: 0x00042F94 File Offset: 0x00041194
		private static List<ModDownload.DlCfProject> GetCfProjectListFromJson(JArray Json, bool IsModPack)
		{
			List<ModDownload.DlCfProject> list = new List<ModDownload.DlCfProject>();
			try
			{
				foreach (JToken jtoken in Json)
				{
					ModDownload.DlCfProject cfProjectFromJson = ModDownload.GetCfProjectFromJson((JObject)jtoken, IsModPack);
					if (cfProjectFromJson != null)
					{
						list.Add(cfProjectFromJson);
					}
				}
			}
			finally
			{
				IEnumerator<JToken> enumerator;
				if (enumerator != null)
				{
					enumerator.Dispose();
				}
			}
			return list;
		}

		// Token: 0x0600094B RID: 2379 RVA: 0x00042FF4 File Offset: 0x000411F4
		private static ModDownload.DlCfProject GetCfProjectFromJson(JObject Json, bool IsModPack)
		{
			ModDownload.DlCfProject result;
			if (Json["links"]["websiteUrl"] == null)
			{
				ModBase.Log("[Download] 发现关键项为 Nothing 的工程：" + (Json ?? "").ToString(), ModBase.LogLevel.Debug, "出现错误");
				result = null;
			}
			else if (IsModPack == Json["links"]["websiteUrl"].ToString().Contains("curseforge.com/minecraft/mc-mods"))
			{
				ModBase.Log("[Download] 返回的工程与要求的类别不一致：" + Json["links"]["websiteUrl"].ToString(), ModBase.LogLevel.Debug, "出现错误");
				result = null;
			}
			else
			{
				result = new ModDownload.DlCfProject(Json);
			}
			return result;
		}

		// Token: 0x0600094C RID: 2380 RVA: 0x000430A4 File Offset: 0x000412A4
		public static List<ModDownload.DlCfFile> DlCfGetFiles(int ProjectId, bool IsModPack)
		{
			ModDownload.DlCfProject dlCfProject;
			if (ModDownload.baseTag.ContainsKey(ProjectId))
			{
				dlCfProject = ModDownload.baseTag[ProjectId];
			}
			else
			{
				dlCfProject = ModDownload.GetCfProjectFromJson((JObject)NewLateBinding.LateIndexGet(ModNet.NetGetCodeByRequestRetry("https://api.curseforge.com/v1/mods/" + Conversions.ToString(ProjectId), Encoding.UTF8, "", true), new object[]
				{
					"data"
				}, null), IsModPack);
			}
			if (dlCfProject.m_CustomerProccesor == null)
			{
				ModBase.Log("[Download] 开始获取 CurseForge 工程 ID 为 " + Conversions.ToString(ProjectId) + " 的文件列表", ModBase.LogLevel.Normal, "出现错误");
				JArray jarray;
				if (dlCfProject.threadProccesor)
				{
					jarray = (JArray)NewLateBinding.LateIndexGet(ModNet.NetGetCodeByRequestRetry("https://api.curseforge.com/v1/mods/" + Conversions.ToString(ProjectId) + "/files?pageSize=999", null, "application/json", true), new object[]
					{
						"data"
					}, null);
				}
				else
				{
					jarray = (JArray)NewLateBinding.LateIndexGet(ModBase.GetJson(ModNet.NetRequestRetry("https://api.curseforge.com/v1/mods/files", "POST", "{\"fileIds\": [" + ModBase.Join(dlCfProject._ConnectionProccesor, ",") + "]}", "application/json", true, null)), new object[]
					{
						"data"
					}, null);
				}
				dlCfProject.m_CustomerProccesor = new List<ModDownload.DlCfFile>();
				try
				{
					foreach (JToken jtoken in jarray)
					{
						JObject data = (JObject)jtoken;
						ModDownload.DlCfFile dlCfFile = new ModDownload.DlCfFile(data, IsModPack);
						if (dlCfFile.PushComparator())
						{
							dlCfProject.m_CustomerProccesor.Add(dlCfFile);
						}
					}
				}
				finally
				{
					IEnumerator<JToken> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
			}
			if (!IsModPack)
			{
				List<int> list = new List<int>();
				try
				{
					foreach (ModDownload.DlCfFile dlCfFile2 in dlCfProject.m_CustomerProccesor)
					{
						try
						{
							foreach (int num in dlCfFile2._PrinterProccesor)
							{
								if (!list.Contains(num) && !ModDownload.baseTag.ContainsKey(num))
								{
									list.Add(num);
								}
							}
						}
						finally
						{
							List<int>.Enumerator enumerator3;
							((IDisposable)enumerator3).Dispose();
						}
					}
				}
				finally
				{
					List<ModDownload.DlCfFile>.Enumerator enumerator2;
					((IDisposable)enumerator2).Dispose();
				}
				if (list.Count > 0)
				{
					ModBase.Log("[Download] 文件列表中需要获取的前置 Mod：" + ModBase.Join(list, "，"), ModBase.LogLevel.Normal, "出现错误");
					ModDownload.GetCfProjectListFromJson((JArray)NewLateBinding.LateIndexGet(ModBase.GetJson(ModNet.NetRequestRetry("https://api.curseforge.com/v1/mods", "POST", "{\"modIds\": [" + ModBase.Join(list, ",") + "]}", "application/json", true, null)), new object[]
					{
						"data"
					}, null), false);
				}
			}
			return dlCfProject.m_CustomerProccesor;
		}

		// Token: 0x0600094D RID: 2381 RVA: 0x00043360 File Offset: 0x00041560
		public static void DlCfFilesPreload(StackPanel Stack, List<ModDownload.DlCfFile> Entrys, MyListItem.ClickEventHandler OnClick)
		{
			List<int> list = new List<int>();
			try
			{
				foreach (ModDownload.DlCfFile dlCfFile in Entrys)
				{
					try
					{
						foreach (int num in (dlCfFile._PrinterProccesor ?? new List<int>()))
						{
							if (!list.Contains(num))
							{
								if (!ModDownload.baseTag.ContainsKey(num))
								{
									ModBase.Log("[Download] 未找到 ID 为 " + Conversions.ToString(num) + " 的前置 Mod 信息", ModBase.LogLevel.Developer, "出现错误");
								}
								else
								{
									list.Add(num);
								}
							}
						}
					}
					finally
					{
						List<int>.Enumerator enumerator2;
						((IDisposable)enumerator2).Dispose();
					}
				}
			}
			finally
			{
				List<ModDownload.DlCfFile>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			list.Remove(306612);
			if (list.Count != 0)
			{
				list.Sort();
				Stack.Children.Add(new TextBlock
				{
					Text = "前置 Mod",
					FontSize = 14.0,
					HorizontalAlignment = HorizontalAlignment.Left,
					Margin = new Thickness(6.0, 2.0, 0.0, 5.0)
				});
				try
				{
					foreach (int key in list)
					{
						ModDownload.DlCfProject dlCfProject = ModDownload.baseTag[key];
						ModDownload._Closure$__R60-1 CS$<>8__locals1 = new ModDownload._Closure$__R60-1(CS$<>8__locals1);
						CS$<>8__locals1.$VB$NonLocal_2 = ModMain.m_ConfigAccount;
						MyCfItem element = dlCfProject.ToCfItem(delegate(object sender, MouseButtonEventArgs e)
						{
							CS$<>8__locals1.$VB$NonLocal_2.ProjectClick((MyCfItem)sender, e);
						});
						Stack.Children.Add(element);
					}
				}
				finally
				{
					List<int>.Enumerator enumerator3;
					((IDisposable)enumerator3).Dispose();
				}
				Stack.Children.Add(new TextBlock
				{
					Text = "可选版本",
					FontSize = 14.0,
					HorizontalAlignment = HorizontalAlignment.Left,
					Margin = new Thickness(6.0, 12.0, 0.0, 5.0)
				});
			}
		}

		// Token: 0x0600094E RID: 2382 RVA: 0x00043598 File Offset: 0x00041798
		public static string[] DlSourceResourceGet(string MojangBase)
		{
			return new string[]
			{
				MojangBase.Replace("http://resources.download.minecraft.net", "https://download.mcbbs.net/assets"),
				MojangBase,
				MojangBase.Replace("http://resources.download.minecraft.net", "https://mcres.mirrors.tmysam.top"),
				MojangBase.Replace("http://resources.download.minecraft.net", "https://bmclapi2.bangbang93.com/assets")
			};
		}

		// Token: 0x0600094F RID: 2383 RVA: 0x000435E8 File Offset: 0x000417E8
		public static string[] DlSourceLibraryGet(string MojangBase)
		{
			return new string[]
			{
				MojangBase.Replace("https://libraries.minecraft.net", "https://download.mcbbs.net/maven"),
				MojangBase.Replace("https://libraries.minecraft.net", "https://download.mcbbs.net/libraries"),
				MojangBase,
				MojangBase.Replace("https://libraries.minecraft.net", "https://mclib.mirrors.tmysam.top"),
				MojangBase.Replace("https://libraries.minecraft.net", "https://bmclapi2.bangbang93.com/maven"),
				MojangBase.Replace("https://libraries.minecraft.net", "https://bmclapi2.bangbang93.com/libraries")
			};
		}

		// Token: 0x06000950 RID: 2384 RVA: 0x00043660 File Offset: 0x00041860
		public static string[] DlSourceLauncherOrMetaGet(string MojangBase, bool IsStatic = true)
		{
			if (MojangBase == null)
			{
				throw new Exception("无对应的 Json 下载地址");
			}
			string[] result;
			if (IsStatic)
			{
				result = new string[]
				{
					MojangBase.Replace("https://launcher.mojang.com", "https://download.mcbbs.net").Replace("https://launchermeta.mojang.com", "https://download.mcbbs.net"),
					MojangBase,
					MojangBase.Replace("https://launcher.mojang.com", "https://mc.mirrors.tmysam.top").Replace("https://launchermeta.mojang.com", "https://mc.mirrors.tmysam.top"),
					MojangBase.Replace("https://launcher.mojang.com", "https://bmclapi2.bangbang93.com").Replace("https://launchermeta.mojang.com", "https://bmclapi2.bangbang93.com")
				};
			}
			else
			{
				result = new string[]
				{
					MojangBase.Replace("https://launcher.mojang.com", "https://download.mcbbs.net").Replace("https://launchermeta.mojang.com", "https://download.mcbbs.net"),
					MojangBase,
					MojangBase.Replace("https://launcher.mojang.com", "https://bmclapi2.bangbang93.com").Replace("https://launchermeta.mojang.com", "https://bmclapi2.bangbang93.com")
				};
			}
			return result;
		}

		// Token: 0x06000951 RID: 2385 RVA: 0x00043744 File Offset: 0x00041944
		private static void DlSourceLoader<InputType, OutputType>(ModLoader.LoaderTask<InputType, OutputType> MainLoader, List<KeyValuePair<ModLoader.LoaderTask<InputType, OutputType>, int>> LoaderList, bool IsForceRestart = false)
		{
			int num = 0;
			checked
			{
				for (;;)
				{
					IL_02:
					bool flag = true;
					try
					{
						foreach (KeyValuePair<ModLoader.LoaderTask<InputType, OutputType>, int> keyValuePair in LoaderList)
						{
							if (num == 0)
							{
								if (IsForceRestart)
								{
									break;
								}
								if ((keyValuePair.Key.Input == null ^ MainLoader.Input == null) || (keyValuePair.Key.Input != null && !keyValuePair.Key.Input.Equals(MainLoader.Input)))
								{
									continue;
								}
							}
							if (keyValuePair.Key.State != ModBase.LoadState.Failed)
							{
								flag = false;
							}
							if (keyValuePair.Key.State == ModBase.LoadState.Finished)
							{
								MainLoader.Output = keyValuePair.Key.Output;
								ModDownload.DlSourceLoaderAbort<InputType, OutputType>(LoaderList);
								return;
							}
							if (flag && num < keyValuePair.Value * 100)
							{
								num = keyValuePair.Value * 100;
							}
							if (keyValuePair.Key.Error != null && keyValuePair.Key.Error.Message.Contains("没有可用版本"))
							{
								try
								{
									foreach (KeyValuePair<ModLoader.LoaderTask<InputType, OutputType>, int> keyValuePair2 in LoaderList)
									{
										if (num < keyValuePair2.Value * 100)
										{
											num = keyValuePair2.Value * 100;
										}
									}
								}
								finally
								{
									List<KeyValuePair<ModLoader.LoaderTask<InputType, OutputType>, int>>.Enumerator enumerator2;
									((IDisposable)enumerator2).Dispose();
								}
							}
						}
						goto IL_215;
					}
					finally
					{
						List<KeyValuePair<ModLoader.LoaderTask<InputType, OutputType>, int>>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
					goto IL_174;
					IL_195:
					int num2 = LoaderList.Count - 1;
					int i = 0;
					while (i <= num2)
					{
						if (num == LoaderList[i].Value * 100)
						{
							if (i >= LoaderList.Count - 1)
							{
								goto IL_228;
							}
							LoaderList[i + 1].Key.Start(MainLoader.Input, IsForceRestart);
							IL_1FD:
							if (!MainLoader.IsAborted)
							{
								Thread.Sleep(10);
								num++;
								goto IL_02;
							}
							goto IL_221;
						}
						else
						{
							i++;
						}
					}
					goto IL_1FD;
					IL_174:
					LoaderList[0].Key.Start(MainLoader.Input, IsForceRestart);
					goto IL_195;
					IL_215:
					if (num == 0)
					{
						goto IL_174;
					}
					goto IL_195;
				}
				IL_221:
				ModDownload.DlSourceLoaderAbort<InputType, OutputType>(LoaderList);
				return;
				IL_228:
				Exception ex = null;
				int num3 = LoaderList.Count - 1;
				for (int j = 0; j <= num3; j++)
				{
					LoaderList[j].Key.Input = default(InputType);
					if (LoaderList[j].Key.Error != null && (ex == null || LoaderList[j].Key.Error.Message.Contains("没有可用版本")))
					{
						ex = LoaderList[j].Key.Error;
					}
				}
				if (ex == null)
				{
					ex = new TimeoutException("下载源连接超时");
				}
				ModDownload.DlSourceLoaderAbort<InputType, OutputType>(LoaderList);
				throw ex;
			}
		}

		// Token: 0x06000952 RID: 2386 RVA: 0x00043A60 File Offset: 0x00041C60
		private static void DlSourceLoaderAbort<InputType, OutputType>(List<KeyValuePair<ModLoader.LoaderTask<InputType, OutputType>, int>> LoaderList)
		{
			try
			{
				foreach (KeyValuePair<ModLoader.LoaderTask<InputType, OutputType>, int> keyValuePair in LoaderList)
				{
					if (keyValuePair.Key.State == ModBase.LoadState.Loading)
					{
						keyValuePair.Key.Abort();
					}
				}
			}
			finally
			{
				List<KeyValuePair<ModLoader.LoaderTask<InputType, OutputType>, int>>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
		}

		// Token: 0x0400046C RID: 1132
		public static ModLoader.LoaderTask<int, ModDownload.DlClientListResult> propertyTag = new ModLoader.LoaderTask<int, ModDownload.DlClientListResult>("DlClientList Main", new Action<ModLoader.LoaderTask<int, ModDownload.DlClientListResult>>(ModDownload.DlClientListMain), null, ThreadPriority.Normal);

		// Token: 0x0400046D RID: 1133
		public static ModLoader.LoaderTask<int, ModDownload.DlClientListResult> m_DescriptorTag = new ModLoader.LoaderTask<int, ModDownload.DlClientListResult>("DlClientList Mojang", new Action<ModLoader.LoaderTask<int, ModDownload.DlClientListResult>>(ModDownload.DlClientListMojangMain), null, ThreadPriority.Normal);

		// Token: 0x0400046E RID: 1134
		private static bool m_MapTag = false;

		// Token: 0x0400046F RID: 1135
		public static ModLoader.LoaderTask<int, ModDownload.DlClientListResult> eventTag = new ModLoader.LoaderTask<int, ModDownload.DlClientListResult>("DlClientList Bmclapi", new Action<ModLoader.LoaderTask<int, ModDownload.DlClientListResult>>(ModDownload.DlClientListBmclapiMain), null, ThreadPriority.Normal);

		// Token: 0x04000470 RID: 1136
		public static ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult> m_AlgoTag = new ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult>("DlOptiFineList Main", new Action<ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult>>(ModDownload.DlOptiFineListMain), null, ThreadPriority.Normal);

		// Token: 0x04000471 RID: 1137
		public static ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult> m_PoolTag = new ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult>("DlOptiFineList Official", new Action<ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult>>(ModDownload.DlOptiFineListOfficialMain), null, ThreadPriority.Normal);

		// Token: 0x04000472 RID: 1138
		public static ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult> _PublisherTag = new ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult>("DlOptiFineList Bmclapi", new Action<ModLoader.LoaderTask<int, ModDownload.DlOptiFineListResult>>(ModDownload.DlOptiFineListBmclapiMain), null, ThreadPriority.Normal);

		// Token: 0x04000473 RID: 1139
		public static ModLoader.LoaderTask<int, ModDownload.DlForgeListResult> m_WatcherTag = new ModLoader.LoaderTask<int, ModDownload.DlForgeListResult>("DlForgeList Main", new Action<ModLoader.LoaderTask<int, ModDownload.DlForgeListResult>>(ModDownload.DlForgeListMain), null, ThreadPriority.Normal);

		// Token: 0x04000474 RID: 1140
		public static ModLoader.LoaderTask<int, ModDownload.DlForgeListResult> m_TestTag = new ModLoader.LoaderTask<int, ModDownload.DlForgeListResult>("DlForgeList Official", new Action<ModLoader.LoaderTask<int, ModDownload.DlForgeListResult>>(ModDownload.DlForgeListOfficialMain), null, ThreadPriority.Normal);

		// Token: 0x04000475 RID: 1141
		public static ModLoader.LoaderTask<int, ModDownload.DlForgeListResult> _TaskTag = new ModLoader.LoaderTask<int, ModDownload.DlForgeListResult>("DlForgeList Bmclapi", new Action<ModLoader.LoaderTask<int, ModDownload.DlForgeListResult>>(ModDownload.DlForgeListBmclapiMain), null, ThreadPriority.Normal);

		// Token: 0x04000476 RID: 1142
		public static ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult> iteratorTag = new ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult>("DlLiteLoaderList Main", new Action<ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult>>(ModDownload.DlLiteLoaderListMain), null, ThreadPriority.Normal);

		// Token: 0x04000477 RID: 1143
		public static ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult> _SerializerTag = new ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult>("DlLiteLoaderList Official", new Action<ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult>>(ModDownload.DlLiteLoaderListOfficialMain), null, ThreadPriority.Normal);

		// Token: 0x04000478 RID: 1144
		public static ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult> _RoleTag = new ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult>("DlLiteLoaderList Bmclapi", new Action<ModLoader.LoaderTask<int, ModDownload.DlLiteLoaderListResult>>(ModDownload.DlLiteLoaderListBmclapiMain), null, ThreadPriority.Normal);

		// Token: 0x04000479 RID: 1145
		public static ModLoader.LoaderTask<int, ModDownload.DlFabricListResult> m_ValueTag = new ModLoader.LoaderTask<int, ModDownload.DlFabricListResult>("DlFabricList Main", new Action<ModLoader.LoaderTask<int, ModDownload.DlFabricListResult>>(ModDownload.DlFabricListMain), null, ThreadPriority.Normal);

		// Token: 0x0400047A RID: 1146
		public static ModLoader.LoaderTask<int, ModDownload.DlFabricListResult> recordTag = new ModLoader.LoaderTask<int, ModDownload.DlFabricListResult>("DlFabricList Official", new Action<ModLoader.LoaderTask<int, ModDownload.DlFabricListResult>>(ModDownload.DlFabricListOfficialMain), null, ThreadPriority.Normal);

		// Token: 0x0400047B RID: 1147
		public static ModLoader.LoaderTask<int, ModDownload.DlFabricListResult> m_VisitorTag = new ModLoader.LoaderTask<int, ModDownload.DlFabricListResult>("DlFabricList Bmclapi", new Action<ModLoader.LoaderTask<int, ModDownload.DlFabricListResult>>(ModDownload.DlFabricListBmclapiMain), null, ThreadPriority.Normal);

		// Token: 0x0400047C RID: 1148
		public static ModLoader.LoaderTask<int, List<ModDownload.DlCfFile>> _HelperTag = new ModLoader.LoaderTask<int, List<ModDownload.DlCfFile>>("Fabric API List Loader", delegate(ModLoader.LoaderTask<int, List<ModDownload.DlCfFile>> Task)
		{
			Task.Output = ModDownload.DlCfGetFiles(306612, false);
		}, null, ThreadPriority.Normal);

		// Token: 0x0400047D RID: 1149
		private static JObject m_ParamTag = null;

		// Token: 0x0400047E RID: 1150
		private static Dictionary<int, ModDownload.DlCfProject> baseTag = new Dictionary<int, ModDownload.DlCfProject>();

		// Token: 0x0400047F RID: 1151
		public static ModLoader.LoaderTask<KeyValuePair<int, bool>, List<ModDownload.DlCfFile>> m_ProductTag = new ModLoader.LoaderTask<KeyValuePair<int, bool>, List<ModDownload.DlCfFile>>("DlCfFile Main", delegate(ModLoader.LoaderTask<KeyValuePair<int, bool>, List<ModDownload.DlCfFile>> Task)
		{
			Task.Output = ModDownload.DlCfGetFiles(Task.Input.Key, Task.Input.Value);
		}, null, ThreadPriority.Normal);

		// Token: 0x020000EE RID: 238
		public enum AssetsIndexExistsBehaviour
		{
			// Token: 0x04000481 RID: 1153
			DontDownload,
			// Token: 0x04000482 RID: 1154
			DownloadInBackground,
			// Token: 0x04000483 RID: 1155
			AlwaysDownload
		}

		// Token: 0x020000EF RID: 239
		public struct DlClientListResult
		{
			// Token: 0x04000484 RID: 1156
			public string _WatcherProccesor;

			// Token: 0x04000485 RID: 1157
			public bool m_TestProccesor;

			// Token: 0x04000486 RID: 1158
			public JObject Value;
		}

		// Token: 0x020000F0 RID: 240
		public struct DlOptiFineListResult
		{
			// Token: 0x04000487 RID: 1159
			public string taskProccesor;

			// Token: 0x04000488 RID: 1160
			public bool _IteratorProccesor;

			// Token: 0x04000489 RID: 1161
			public List<ModDownload.DlOptiFineListEntry> Value;
		}

		// Token: 0x020000F1 RID: 241
		public class DlOptiFineListEntry
		{
			// Token: 0x06000954 RID: 2388 RVA: 0x000068EE File Offset: 0x00004AEE
			public string CustomizeComparator()
			{
				return this._VisitorProccesor;
			}

			// Token: 0x06000955 RID: 2389 RVA: 0x000068F6 File Offset: 0x00004AF6
			public void PublishComparator(string value)
			{
				if (value.EndsWith(".0"))
				{
					value = Strings.Left(value, checked(value.Length - 2));
				}
				this._VisitorProccesor = value;
			}

			// Token: 0x0400048A RID: 1162
			public string m_SerializerProccesor;

			// Token: 0x0400048B RID: 1163
			public string m_RoleProccesor;

			// Token: 0x0400048C RID: 1164
			public string _ValueProccesor;

			// Token: 0x0400048D RID: 1165
			public bool m_RecordProccesor;

			// Token: 0x0400048E RID: 1166
			private string _VisitorProccesor;

			// Token: 0x0400048F RID: 1167
			public string _HelperProccesor;
		}

		// Token: 0x020000F2 RID: 242
		public struct DlForgeListResult
		{
			// Token: 0x04000490 RID: 1168
			public string m_ParamProccesor;

			// Token: 0x04000491 RID: 1169
			public bool _BaseProccesor;

			// Token: 0x04000492 RID: 1170
			public List<string> Value;
		}

		// Token: 0x020000F3 RID: 243
		public class DlForgeVersionEntry
		{
			// Token: 0x06000957 RID: 2391 RVA: 0x0000691C File Offset: 0x00004B1C
			public DlForgeVersionEntry()
			{
				this.m_BridgeProccesor = null;
				this.templateProccesor = null;
			}

			// Token: 0x06000958 RID: 2392 RVA: 0x00006933 File Offset: 0x00004B33
			public bool ViewComparator()
			{
				return Conversions.ToDouble(this.productProccesor.Split(new char[]
				{
					'.'
				})[0]) >= 20.0;
			}

			// Token: 0x06000959 RID: 2393 RVA: 0x00043AC4 File Offset: 0x00041CC4
			public int InstantiateComparator()
			{
				string[] array = this.productProccesor.Split(new char[]
				{
					'.'
				});
				checked
				{
					int result;
					if (Conversions.ToDouble(array[0]) < 15.0)
					{
						result = Conversions.ToInteger(array[array.Count<string>() - 1]);
					}
					else
					{
						result = (int)Math.Round(unchecked(Conversions.ToDouble(array[checked(array.Count<string>() - 1)]) + 10000.0));
					}
					return result;
				}
			}

			// Token: 0x0600095A RID: 2394 RVA: 0x00006960 File Offset: 0x00004B60
			public string LogoutComparator()
			{
				return this.productProccesor + ((this.templateProccesor == null) ? "" : ("-" + this.templateProccesor));
			}

			// Token: 0x0600095B RID: 2395 RVA: 0x00043B30 File Offset: 0x00041D30
			public string ReflectComparator()
			{
				return string.Concat(new string[]
				{
					"forge-",
					this.m_AttrProccesor,
					"-",
					this.LogoutComparator(),
					"-",
					this._IndexerProccesor,
					".",
					this.PrepareComparator()
				});
			}

			// Token: 0x0600095C RID: 2396 RVA: 0x00043B8C File Offset: 0x00041D8C
			public string PrepareComparator()
			{
				string result;
				if (Operators.CompareString(this._IndexerProccesor, "installer", true) == 0)
				{
					result = "jar";
				}
				else
				{
					result = "zip";
				}
				return result;
			}

			// Token: 0x04000493 RID: 1171
			public string productProccesor;

			// Token: 0x04000494 RID: 1172
			public string m_AttrProccesor;

			// Token: 0x04000495 RID: 1173
			public string facadeProccesor;

			// Token: 0x04000496 RID: 1174
			public string m_BridgeProccesor;

			// Token: 0x04000497 RID: 1175
			public bool m_StructProccesor;

			// Token: 0x04000498 RID: 1176
			public string _IndexerProccesor;

			// Token: 0x04000499 RID: 1177
			public string templateProccesor;
		}

		// Token: 0x020000F4 RID: 244
		public struct DlLiteLoaderListResult
		{
			// Token: 0x0400049A RID: 1178
			public string SourceName;

			// Token: 0x0400049B RID: 1179
			public bool IsOfficial;

			// Token: 0x0400049C RID: 1180
			public List<ModDownload.DlLiteLoaderListEntry> Value;

			// Token: 0x0400049D RID: 1181
			public Exception OfficialError;
		}

		// Token: 0x020000F5 RID: 245
		public class DlLiteLoaderListEntry
		{
			// Token: 0x0400049E RID: 1182
			public string FileName;

			// Token: 0x0400049F RID: 1183
			public bool IsPreview;

			// Token: 0x040004A0 RID: 1184
			public string Inherit;

			// Token: 0x040004A1 RID: 1185
			public bool IsLegacy;

			// Token: 0x040004A2 RID: 1186
			public string ReleaseTime;

			// Token: 0x040004A3 RID: 1187
			public string MD5;

			// Token: 0x040004A4 RID: 1188
			public JToken JsonToken;
		}

		// Token: 0x020000F6 RID: 246
		public struct DlFabricListResult
		{
			// Token: 0x040004A5 RID: 1189
			public string expressionProccesor;

			// Token: 0x040004A6 RID: 1190
			public bool _GetterProccesor;

			// Token: 0x040004A7 RID: 1191
			public JObject Value;
		}

		// Token: 0x020000F7 RID: 247
		public class DlCfProjectRequest
		{
			// Token: 0x06000960 RID: 2400 RVA: 0x00043BBC File Offset: 0x00041DBC
			public DlCfProjectRequest()
			{
				this._ListenerProccesor = 0;
				this.identifierProccesor = false;
				this._InstanceProccesor = null;
				this.creatorProccesor = Conversions.ToString(50);
				this.m_ObjectProccesor = null;
				this.m_RegProccesor = null;
				this._InvocationProccesor = null;
			}

			// Token: 0x06000961 RID: 2401 RVA: 0x00043C14 File Offset: 0x00041E14
			public string GetAddress()
			{
				string[] array = new string[9];
				array[0] = "https://api.curseforge.com/v1/mods/search?gameId=432&sortField=Featured&sortOrder=desc&pageSize=";
				array[1] = this.creatorProccesor;
				array[2] = "&categoryId=";
				array[3] = Conversions.ToString(this._ListenerProccesor);
				array[4] = (this.identifierProccesor ? "&classId=4471" : "&classId=6");
				array[5] = (string.IsNullOrEmpty(this._InstanceProccesor) ? "" : ("&gameVersion=" + this._InstanceProccesor));
				array[6] = (string.IsNullOrEmpty(this.m_ObjectProccesor) ? "" : ("&searchFilter=" + WebUtility.UrlEncode(this.m_ObjectProccesor)));
				int num = 7;
				string text;
				if (this.m_RegProccesor == null)
				{
					text = "";
				}
				else
				{
					string str = "&index=";
					int? num3;
					int? num2 = num3 = this.m_RegProccesor;
					text = str + ((num3 != null) ? Conversions.ToString(num2.GetValueOrDefault()) : null);
				}
				array[num] = text;
				int num4 = 8;
				string text2;
				if (this._InvocationProccesor != null)
				{
					int? num2 = this._InvocationProccesor;
					if (((num2 != null) ? new bool?(num2.GetValueOrDefault() > 0) : null).GetValueOrDefault())
					{
						string str2 = "&modLoaderType=";
						int? num3;
						num2 = (num3 = this._InvocationProccesor);
						text2 = str2 + ((num3 != null) ? Conversions.ToString(num2.GetValueOrDefault()) : null);
						goto IL_14F;
					}
				}
				text2 = "";
				IL_14F:
				array[num4] = text2;
				return string.Concat(array);
			}

			// Token: 0x06000962 RID: 2402 RVA: 0x00043D78 File Offset: 0x00041F78
			public override bool Equals(object obj)
			{
				ModDownload.DlCfProjectRequest dlCfProjectRequest = obj as ModDownload.DlCfProjectRequest;
				return dlCfProjectRequest != null && Operators.CompareString(dlCfProjectRequest.GetAddress(), this.GetAddress(), true) == 0;
			}

			// Token: 0x06000963 RID: 2403 RVA: 0x0000698C File Offset: 0x00004B8C
			public static bool operator ==(ModDownload.DlCfProjectRequest left, ModDownload.DlCfProjectRequest right)
			{
				return EqualityComparer<ModDownload.DlCfProjectRequest>.Default.Equals(left, right);
			}

			// Token: 0x06000964 RID: 2404 RVA: 0x0000699A File Offset: 0x00004B9A
			public static bool operator !=(ModDownload.DlCfProjectRequest left, ModDownload.DlCfProjectRequest right)
			{
				return !(left == right);
			}

			// Token: 0x040004A8 RID: 1192
			public int _ListenerProccesor;

			// Token: 0x040004A9 RID: 1193
			public bool identifierProccesor;

			// Token: 0x040004AA RID: 1194
			public string _InstanceProccesor;

			// Token: 0x040004AB RID: 1195
			public string creatorProccesor;

			// Token: 0x040004AC RID: 1196
			public string m_ObjectProccesor;

			// Token: 0x040004AD RID: 1197
			public int? m_RegProccesor;

			// Token: 0x040004AE RID: 1198
			public int? _InvocationProccesor;
		}

		// Token: 0x020000F8 RID: 248
		public class DlCfProject
		{
			// Token: 0x06000966 RID: 2406 RVA: 0x00043DA8 File Offset: 0x00041FA8
			public string CheckComparator()
			{
				if (ModDownload.m_ParamTag == null)
				{
					ModDownload.m_ParamTag = (JObject)ModBase.GetJson(ModBase.DecodeBytes(ModBase.GetResources("ModData")));
				}
				if (this.m_SchemaProccesor == null && this.m_FactoryProccesor != null)
				{
					string text = this.m_FactoryProccesor.TrimEnd(new char[]
					{
						'/'
					}).Split(new char[]
					{
						'/'
					}).Last<string>();
					if (ModDownload.m_ParamTag.ContainsKey(text))
					{
						string[] array = ModDownload.m_ParamTag[text].ToString().Split(new char[]
						{
							'|'
						});
						if (array.Length == 3)
						{
							this.m_SchemaProccesor = array.Last<string>();
						}
					}
				}
				return this.m_SchemaProccesor;
			}

			// Token: 0x06000967 RID: 2407 RVA: 0x000069A6 File Offset: 0x00004BA6
			public void WriteComparator(string value)
			{
				this.m_SchemaProccesor = value;
			}

			// Token: 0x06000968 RID: 2408 RVA: 0x00043E5C File Offset: 0x0004205C
			public string FlushComparator()
			{
				if (ModDownload.m_ParamTag == null)
				{
					ModDownload.m_ParamTag = (JObject)ModBase.GetJson(ModBase.DecodeBytes(ModBase.GetResources("ModData")));
				}
				if (this.databaseProccesor == null)
				{
					this.databaseProccesor = this.Name;
					if (this.m_FactoryProccesor != null)
					{
						string text = this.m_FactoryProccesor.TrimEnd(new char[]
						{
							'/'
						}).Split(new char[]
						{
							'/'
						}).Last<string>();
						if (ModDownload.m_ParamTag.ContainsKey(text))
						{
							string text2 = (string)ModDownload.m_ParamTag[text];
							this.itemProccesor = Conversions.ToInteger(text2.Split(new char[]
							{
								'|'
							})[0]);
							if (Operators.CompareString(text2.Split(new char[]
							{
								'|'
							})[1], "~", true) != 0)
							{
								this.databaseProccesor = text2.Split(new char[]
								{
									'|'
								})[1] + " (" + this.Name + ")";
							}
						}
					}
				}
				return this.databaseProccesor;
			}

			// Token: 0x06000969 RID: 2409 RVA: 0x000069AF File Offset: 0x00004BAF
			public void ChangeComparator(string value)
			{
				this.databaseProccesor = value;
			}

			// Token: 0x0600096A RID: 2410 RVA: 0x00043F6C File Offset: 0x0004216C
			public DlCfProject(JObject Data)
			{
				this.itemProccesor = 0;
				this._UtilsProccesor = new List<string>();
				this._ConnectionProccesor = new List<int>();
				this.composerProccesor = (int)Data["id"];
				this.Name = (string)Data["name"];
				this._MapperProccesor = (string)Data["summary"];
				this.m_FactoryProccesor = (string)Data["links"]["websiteUrl"];
				this.processProccesor = (DateTime)Data["dateModified"];
				this.valProccesor = (int)Data["downloadCount"];
				this.threadProccesor = !this.m_FactoryProccesor.Contains("/mc-mods/");
				try
				{
					foreach (JToken jtoken in (Data["latestFiles"] ?? new byte[0]))
					{
						new ModDownload.DlCfFile((JObject)jtoken, this.threadProccesor).PushComparator();
					}
				}
				finally
				{
					IEnumerator<JToken> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				List<int> list = new List<int>();
				this._UtilsProccesor = new List<string>();
				try
				{
					foreach (JToken jtoken2 in (Data["latestFilesIndexes"] ?? new byte[0]))
					{
						string text = (string)jtoken2["gameVersion"];
						if (text.Contains("1."))
						{
							list.Add(Conversions.ToInteger(text.Split(new char[]
							{
								'.'
							})[1].Split(new char[]
							{
								'-'
							}).First<string>()));
							string left = (jtoken2["modLoader"] ?? "0").ToString();
							if (Operators.CompareString(left, Conversions.ToString(1), true) == 0)
							{
								this._UtilsProccesor.Add("Forge");
							}
							else if (Operators.CompareString(left, Conversions.ToString(2), true) == 0)
							{
								this._UtilsProccesor.Add("Cauldron");
							}
							else if (Operators.CompareString(left, Conversions.ToString(3), true) == 0)
							{
								this._UtilsProccesor.Add("LiteLoader");
							}
							else if (Operators.CompareString(left, Conversions.ToString(4), true) == 0)
							{
								this._UtilsProccesor.Add("Fabric");
							}
							this._ConnectionProccesor.Add((int)jtoken2["fileId"]);
						}
					}
				}
				finally
				{
					IEnumerator<JToken> enumerator2;
					if (enumerator2 != null)
					{
						enumerator2.Dispose();
					}
				}
				list = ModBase.Sort<int>(list.Distinct<int>().ToList<int>(), (ModDownload.DlCfProject._Closure$__.$IR22-1 == null) ? (ModDownload.DlCfProject._Closure$__.$IR22-1 = ((object a0, object a1) => ModMinecraft.VersionSortBoolean(Conversions.ToString(a0), Conversions.ToString(a1)))) : ModDownload.DlCfProject._Closure$__.$IR22-1);
				this._UtilsProccesor = this._UtilsProccesor.Distinct<string>().ToList<string>();
				this._UtilsProccesor.Sort();
				checked
				{
					if (list.Count == 0)
					{
						this.orderProccesor = "";
					}
					else
					{
						List<string> list2 = new List<string>();
						int num = list.Count - 1;
						for (int i = 0; i <= num; i++)
						{
							int num2 = list[i];
							int num3 = list[i];
							int num4 = i + 1;
							int num5 = list.Count - 1;
							int num6 = num4;
							while (num6 <= num5 && list[num6] == num3 - 1)
							{
								num3 = list[num6];
								i = num6;
								num6++;
							}
							if (num2 == num3)
							{
								list2.Add("1." + Conversions.ToString(num2));
							}
							else
							{
								list2.Add("1." + Conversions.ToString(num2) + "-1." + Conversions.ToString(num3));
							}
						}
						this.orderProccesor = "[" + ModBase.Join(list2, ", ") + "] ";
					}
					JToken jtoken3 = Data["categories"];
					List<int> list3 = new List<int>();
					try
					{
						foreach (JToken jtoken4 in jtoken3)
						{
							list3.Add((int)jtoken4["id"]);
						}
					}
					finally
					{
						IEnumerator<JToken> enumerator3;
						if (enumerator3 != null)
						{
							enumerator3.Dispose();
						}
					}
					list3 = ModBase.ArrayNoDouble<int>(list3, null);
					list3.Sort();
					this.policyProccesor = new List<string>();
					try
					{
						foreach (int num7 in list3)
						{
							string item;
							if (num7 <= 4487)
							{
								switch (num7)
								{
								case 406:
									item = "世界生成";
									break;
								case 407:
									item = "生物群系";
									break;
								case 408:
								case 413:
								case 418:
								case 426:
								case 427:
								case 428:
								case 429:
								case 430:
								case 431:
								case 432:
								case 433:
									continue;
								case 409:
									item = "天然结构";
									break;
								case 410:
									item = "维度";
									break;
								case 411:
									item = "生物";
									break;
								case 412:
									item = "科技";
									break;
								case 414:
									item = "交通与移动";
									break;
								case 415:
									item = "管道与物流";
									break;
								case 416:
									item = "农业";
									break;
								case 417:
									item = "能源";
									break;
								case 419:
									item = "魔法";
									break;
								case 420:
									item = "仓储";
									break;
								case 421:
									item = "支持库";
									break;
								case 422:
									item = "冒险与探索";
									break;
								case 423:
									item = "信息显示";
									break;
								case 424:
									item = "建筑与装饰";
									break;
								case 425:
									item = "杂项";
									break;
								case 434:
									item = "装备与工具";
									break;
								case 435:
									item = "服务器";
									break;
								case 436:
									item = "食物";
									break;
								default:
									switch (num7)
									{
									case 4471:
										item = "科幻";
										break;
									case 4472:
										item = "科技";
										break;
									case 4473:
										item = "魔法";
										break;
									case 4474:
									case 4485:
									case 4486:
										continue;
									case 4475:
										item = "冒险";
										break;
									case 4476:
										item = "探索";
										break;
									case 4477:
										item = "小游戏";
										break;
									case 4478:
										item = "任务";
										break;
									case 4479:
										item = "硬核";
										break;
									case 4480:
										item = "基于地图";
										break;
									case 4481:
										item = "小型整合";
										break;
									case 4482:
										item = "大型整合";
										break;
									case 4483:
										item = "战斗";
										break;
									case 4484:
										item = "多人";
										break;
									case 4487:
										item = "FTB";
										break;
									default:
										continue;
									}
									break;
								}
							}
							else if (num7 != 4558)
							{
								if (num7 != 4736)
								{
									continue;
								}
								item = "空岛";
							}
							else
							{
								item = "红石";
							}
							this.policyProccesor.Add(item);
						}
					}
					finally
					{
						List<int>.Enumerator enumerator4;
						((IDisposable)enumerator4).Dispose();
					}
					if (this.policyProccesor.Count == 0)
					{
						this.policyProccesor.Add("杂类");
					}
					if (Data["logo"].Count<JToken>() > 0)
					{
						if (ModBase.GetPixelSize(1.0) > 1.25)
						{
							this.Thumb = Data["logo"]["thumbnailUrl"].ToString();
						}
						else
						{
							this.Thumb = Data["logo"]["thumbnailUrl"].ToString().Replace("/256/256/", "/64/64/");
						}
					}
					ModBase.DictionaryAdd<int, ModDownload.DlCfProject>(ref ModDownload.baseTag, this.composerProccesor, this);
				}
			}

			// Token: 0x0600096B RID: 2411 RVA: 0x0004479C File Offset: 0x0004299C
			public MyCfItem ToCfItem(MyCfItem.ClickEventHandler OnClick = null)
			{
				bool flag;
				bool flag2;
				if (ModMain.m_CollectionAccount.comparatorAccount.m_CreatorParameter == FormMain.PageType.Download)
				{
					if (ModMain.m_CollectionAccount.QueryTag() == FormMain.PageSubType.DownloadMod)
					{
						flag = (Operators.CompareString(ModMain.m_ConfigAccount.TextSearchVersion.Text, "", true) == 0);
						flag2 = (ModMain.m_ConfigAccount.ComboSearchLoader.SelectedIndex == 0);
					}
					else
					{
						flag = (Operators.CompareString(ModMain.managerAccount.TextSearchVersion.Text, "", true) == 0);
						flag2 = false;
					}
				}
				else
				{
					flag = true;
					flag2 = true;
				}
				MyCfItem myCfItem = new MyCfItem
				{
					Tag = this
				};
				myCfItem.LabTitle.Text = this.FlushComparator();
				myCfItem.LabInfo.Text = this._MapperProccesor.Replace("\r", "").Replace("\n", "");
				myCfItem.LabLeft.Text = string.Concat(new string[]
				{
					(this._UtilsProccesor.Count <= 0 || !flag2) ? "" : ("[" + ModBase.Join(this._UtilsProccesor, " & ") + "] "),
					flag ? this.orderProccesor : "",
					ModBase.Join(this.policyProccesor, "，"),
					" (",
					ModBase.GetTimeSpanString(this.processProccesor - DateTime.Now),
					"更新，",
					(this.valProccesor > 100000) ? (Conversions.ToString(Math.Round((double)this.valProccesor / 10000.0)) + " 万次下载）") : (Conversions.ToString(this.valProccesor) + " 次下载）")
				});
				if (this.Thumb == null)
				{
					myCfItem.Logo = "pack://application:,,,/images/Icons/NoIcon.png";
				}
				else
				{
					myCfItem.Logo = this.Thumb;
				}
				if (OnClick != null)
				{
					myCfItem.CalculateRepository(OnClick);
				}
				myCfItem.advisorWrapper = (OnClick != null);
				return myCfItem;
			}

			// Token: 0x0600096C RID: 2412 RVA: 0x00044990 File Offset: 0x00042B90
			public override bool Equals(object obj)
			{
				ModDownload.DlCfProject dlCfProject = obj as ModDownload.DlCfProject;
				return dlCfProject != null && this.composerProccesor == dlCfProject.composerProccesor;
			}

			// Token: 0x0600096D RID: 2413 RVA: 0x000069B8 File Offset: 0x00004BB8
			public static bool operator ==(ModDownload.DlCfProject left, ModDownload.DlCfProject right)
			{
				return EqualityComparer<ModDownload.DlCfProject>.Default.Equals(left, right);
			}

			// Token: 0x0600096E RID: 2414 RVA: 0x000069C6 File Offset: 0x00004BC6
			public static bool operator !=(ModDownload.DlCfProject left, ModDownload.DlCfProject right)
			{
				return !(left == right);
			}

			// Token: 0x040004AF RID: 1199
			public int composerProccesor;

			// Token: 0x040004B0 RID: 1200
			public string Name;

			// Token: 0x040004B1 RID: 1201
			public int itemProccesor;

			// Token: 0x040004B2 RID: 1202
			public string _MapperProccesor;

			// Token: 0x040004B3 RID: 1203
			public string m_FactoryProccesor;

			// Token: 0x040004B4 RID: 1204
			public DateTime processProccesor;

			// Token: 0x040004B5 RID: 1205
			public int valProccesor;

			// Token: 0x040004B6 RID: 1206
			public List<string> _UtilsProccesor;

			// Token: 0x040004B7 RID: 1207
			public string orderProccesor;

			// Token: 0x040004B8 RID: 1208
			private List<string> policyProccesor;

			// Token: 0x040004B9 RID: 1209
			private string Thumb;

			// Token: 0x040004BA RID: 1210
			public bool threadProccesor;

			// Token: 0x040004BB RID: 1211
			public List<int> _ConnectionProccesor;

			// Token: 0x040004BC RID: 1212
			public List<ModDownload.DlCfFile> m_CustomerProccesor;

			// Token: 0x040004BD RID: 1213
			private string m_SchemaProccesor;

			// Token: 0x040004BE RID: 1214
			private string databaseProccesor;
		}

		// Token: 0x020000FA RID: 250
		public class DlCfProjectResult
		{
			// Token: 0x040004C1 RID: 1217
			public List<ModDownload.DlCfProject> m_CallbackProccesor;

			// Token: 0x040004C2 RID: 1218
			public int m_AdvisorProccesor;

			// Token: 0x040004C3 RID: 1219
			public long _ObserverProccesor;
		}

		// Token: 0x020000FB RID: 251
		public class DlCfFile
		{
			// Token: 0x06000975 RID: 2421 RVA: 0x000449B8 File Offset: 0x00042BB8
			public string AddComparator()
			{
				int readerProccesor = this._ReaderProccesor;
				string result;
				if (readerProccesor != 1)
				{
					if (readerProccesor != 2)
					{
						result = (ModBase._EventState ? "Alpha 测试版" : "测试版");
					}
					else
					{
						result = (ModBase._EventState ? "Beta 测试版" : "测试版");
					}
				}
				else
				{
					result = "正式版";
				}
				return result;
			}

			// Token: 0x06000976 RID: 2422 RVA: 0x000069F4 File Offset: 0x00004BF4
			public bool PushComparator()
			{
				return this.m_CollectionProccesor != null && this._FilterProccesor != null && this.m_FieldProccesor != null && this.m_TokenProccesor[0].StartsWith("http");
			}

			// Token: 0x06000977 RID: 2423 RVA: 0x00044A08 File Offset: 0x00042C08
			public DlCfFile(JObject Data, bool IsModPack)
			{
				this._PrinterProccesor = new List<int>();
				this._ContextProccesor = (int)Data["id"];
				this.m_CollectionProccesor = Data["displayName"].ToString().Replace("\t", "").Trim(new char[]
				{
					' '
				});
				this.m_ConsumerProccesor = (DateTime)Data["fileDate"];
				this._ReaderProccesor = (int)Data["releaseType"];
				this.m_PageProccesor = (int)Data["downloadCount"];
				this.m_FieldProccesor = (string)Data["fileName"];
				this._SingletonProccesor = IsModPack;
				string text = Data["downloadUrl"].ToString();
				text = text.Replace(this.m_FieldProccesor, WebUtility.UrlEncode(this.m_FieldProccesor));
				this.m_TokenProccesor = ModBase.ArrayNoDouble<string>(new string[]
				{
					text.Replace("-service.overwolf.wtf", ".forgecdn.net").Replace("://edge", "://media"),
					text.Replace("-service.overwolf.wtf", ".forgecdn.net"),
					text.Replace("://edge", "://media"),
					text
				}, null);
				if (!IsModPack)
				{
					try
					{
						foreach (JToken jtoken in Data["dependencies"])
						{
							if (jtoken["relationType"].ToObject<int>() == 3 && jtoken["modId"].ToObject<int>() != 306612)
							{
								this._PrinterProccesor.Add((int)jtoken["modId"]);
							}
						}
					}
					finally
					{
						IEnumerator<JToken> enumerator;
						if (enumerator != null)
						{
							enumerator.Dispose();
						}
					}
				}
				List<string> list = new List<string>();
				try
				{
					foreach (JToken jtoken2 in Data["gameVersions"])
					{
						if (jtoken2.ToString().StartsWith("1.") || jtoken2.ToString().Contains("w"))
						{
							list.Add(jtoken2.ToString().Trim().ToLower());
						}
					}
				}
				finally
				{
					IEnumerator<JToken> enumerator2;
					if (enumerator2 != null)
					{
						enumerator2.Dispose();
					}
				}
				if (list.Count > 1)
				{
					this._FilterProccesor = ModBase.Sort<string>(list, (ModDownload.DlCfFile._Closure$__.$IR14-1 == null) ? (ModDownload.DlCfFile._Closure$__.$IR14-1 = ((object a0, object a1) => ModMinecraft.VersionSortBoolean(Conversions.ToString(a0), Conversions.ToString(a1)))) : ModDownload.DlCfFile._Closure$__.$IR14-1).ToArray();
					if (IsModPack)
					{
						this._FilterProccesor = new string[]
						{
							this._FilterProccesor[0]
						};
						return;
					}
				}
				else
				{
					if (list.Count == 1)
					{
						this._FilterProccesor = list.ToArray();
						return;
					}
					this._FilterProccesor = new string[]
					{
						"未知版本"
					};
				}
			}

			// Token: 0x06000978 RID: 2424 RVA: 0x00006A22 File Offset: 0x00004C22
			public ModNet.NetFile GetDownloadFile(string LocalAddress, bool IsFullPath)
			{
				return new ModNet.NetFile(this.m_TokenProccesor, LocalAddress + (IsFullPath ? "" : this.m_FieldProccesor), null);
			}

			// Token: 0x06000979 RID: 2425 RVA: 0x00044CE4 File Offset: 0x00042EE4
			public MyListItem ToListItem(MyListItem.ClickEventHandler OnClick, MyIconButton.ClickEventHandler OnSaveClick = null)
			{
				string text = "";
				if (!this._SingletonProccesor)
				{
					text = text + "适用于 " + ModBase.Join(this._FilterProccesor, "、").Replace("-snapshot", " 快照") + ((!ModBase._EventState || this._PrinterProccesor.Count <= 0) ? "，" : ("，" + Conversions.ToString(this._PrinterProccesor.Count) + " 个前置，"));
				}
				text += ((this.m_PageProccesor > 100000) ? (Conversions.ToString(Math.Round((double)this.m_PageProccesor / 10000.0)) + " 万次下载，") : (Conversions.ToString(this.m_PageProccesor) + " 次下载，"));
				text = text + ModBase.GetTimeSpanString(this.m_ConsumerProccesor - DateTime.Now) + "更新";
				text += ((this._ReaderProccesor != 1) ? ("，" + this.AddComparator()) : "");
				MyListItem myListItem = new MyListItem
				{
					Title = this.m_CollectionProccesor,
					SnapsToDevicePixels = true,
					Height = 42.0,
					Type = MyListItem.CheckType.Clickable,
					Tag = this,
					Info = text
				};
				int readerProccesor = this._ReaderProccesor;
				if (readerProccesor != 1)
				{
					if (readerProccesor != 2)
					{
						myListItem.Logo = "pack://application:,,,/images/Icons/A.png";
					}
					else
					{
						myListItem.Logo = "pack://application:,,,/images/Icons/B.png";
					}
				}
				else
				{
					myListItem.Logo = "pack://application:,,,/images/Icons/R.png";
				}
				myListItem.WriteResolver(OnClick);
				if (OnSaveClick != null)
				{
					MyIconButton myIconButton = new MyIconButton
					{
						Logo = "M819.392 0L1024 202.752v652.16a168.96 168.96 0 0 1-168.832 168.768h-104.192a47.296 47.296 0 0 1-10.752 0H283.776a47.232 47.232 0 0 1-10.752 0H168.832A168.96 168.96 0 0 1 0 854.912V168.768A168.96 168.96 0 0 1 168.832 0h650.56z m110.208 854.912V242.112l-149.12-147.776H168.896c-41.088 0-74.432 33.408-74.432 74.432v686.144c0 41.024 33.344 74.432 74.432 74.432h62.4v-190.528c0-33.408 27.136-60.544 60.544-60.544h440.448c33.408 0 60.544 27.136 60.544 60.544v190.528h62.4c41.088 0 74.432-33.408 74.432-74.432z m-604.032 74.432h372.864v-156.736H325.568v156.736z m403.52-596.48a47.168 47.168 0 1 1 0 94.336H287.872a47.168 47.168 0 1 1 0-94.336h441.216z m0-153.728a47.168 47.168 0 1 1 0 94.4H287.872a47.168 47.168 0 1 1 0-94.4h441.216z",
						ToolTip = "另存为"
					};
					ToolTipService.SetPlacement(myIconButton, PlacementMode.Center);
					ToolTipService.SetVerticalOffset(myIconButton, 30.0);
					ToolTipService.SetHorizontalOffset(myIconButton, 2.0);
					myIconButton.Click += OnSaveClick;
					myListItem.Buttons = new MyIconButton[]
					{
						myIconButton
					};
					myListItem.PaddingRight = 35;
				}
				return myListItem;
			}

			// Token: 0x0600097A RID: 2426 RVA: 0x00006A46 File Offset: 0x00004C46
			public override string ToString()
			{
				return this.m_CollectionProccesor;
			}

			// Token: 0x040004C4 RID: 1220
			public bool _SingletonProccesor;

			// Token: 0x040004C5 RID: 1221
			public int _ContextProccesor;

			// Token: 0x040004C6 RID: 1222
			public string m_CollectionProccesor;

			// Token: 0x040004C7 RID: 1223
			public DateTime m_ConsumerProccesor;

			// Token: 0x040004C8 RID: 1224
			public string[] _FilterProccesor;

			// Token: 0x040004C9 RID: 1225
			public int _ReaderProccesor;

			// Token: 0x040004CA RID: 1226
			public string m_FieldProccesor;

			// Token: 0x040004CB RID: 1227
			public int m_PageProccesor;

			// Token: 0x040004CC RID: 1228
			public List<int> _PrinterProccesor;

			// Token: 0x040004CD RID: 1229
			private string[] m_TokenProccesor;
		}
	}
}
