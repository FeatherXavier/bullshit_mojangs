﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000125 RID: 293
	[DesignerGenerated]
	public class PageOtherFeedback : MyPageRight, IComponentConnector
	{
		// Token: 0x06000AD5 RID: 2773 RVA: 0x00007556 File Offset: 0x00005756
		public PageOtherFeedback()
		{
			base.Loaded += this.PageOther_Loaded;
			base.Initialized += this.PageOther_Inited;
			this.errorTag = false;
			this.InitializeComponent();
		}

		// Token: 0x06000AD6 RID: 2774 RVA: 0x00007590 File Offset: 0x00005790
		private void PageOther_Loaded(object sender, RoutedEventArgs e)
		{
			this.PanBack.ScrollToHome();
		}

		// Token: 0x06000AD7 RID: 2775 RVA: 0x00056844 File Offset: 0x00054A44
		private void PageOther_Inited(object sender, EventArgs e)
		{
			base.PageLoaderInit(this.Load, this.PanLoad, this.PanBack, null, ModMain.wrapperState, delegate(ModLoader.LoaderBase a0)
			{
				this.FeedbackListLoad((ModLoader.LoaderTask<int, Dictionary<string, List<ModMain.FeedbackEntry>>>)a0);
			}, null, true);
		}

		// Token: 0x06000AD8 RID: 2776 RVA: 0x00056880 File Offset: 0x00054A80
		private void FeedbackListLoad(ModLoader.LoaderTask<int, Dictionary<string, List<ModMain.FeedbackEntry>>> Loader)
		{
			try
			{
				this.PanList.Children.Clear();
				this.PanBack.ScrollToHome();
				Dictionary<string, List<ModMain.FeedbackEntry>> output = Loader.Output;
				try
				{
					foreach (KeyValuePair<string, List<ModMain.FeedbackEntry>> keyValuePair in output)
					{
						string text = keyValuePair.Key;
						string left = text;
						if (Operators.CompareString(left, "我的反馈", true) == 0 || Operators.CompareString(left, "处理中", true) == 0 || Operators.CompareString(left, "未处理", true) == 0)
						{
							text = text + " (" + Conversions.ToString(keyValuePair.Value.Count) + ")";
						}
						MyCard myCard = new MyCard();
						myCard.Title = text;
						myCard.Margin = new Thickness(0.0, 0.0, 0.0, 15.0);
						myCard.CustomizeModel(1);
						MyCard myCard2 = myCard;
						StackPanel stackPanel = new StackPanel
						{
							Margin = new Thickness(20.0, 40.0, 18.0, 0.0),
							VerticalAlignment = VerticalAlignment.Top,
							RenderTransform = new TranslateTransform(0.0, 0.0),
							Tag = keyValuePair.Value
						};
						if (Operators.CompareString(keyValuePair.Key, "我的反馈", true) == 0)
						{
							stackPanel.Children.Add(new MyHint
							{
								collection = "HintFeedbackDelete",
								CanClose = true,
								IsWarn = false,
								Margin = new Thickness(0.0, 0.0, 0.0, 8.0),
								Text = "为保证反馈页面的加载速度，已处理或已忽略的反馈可能会在保留数天后被删除。"
							});
						}
						myCard2.Children.Add(stackPanel);
						myCard2.m_Decorator = stackPanel;
						if (Operators.CompareString(keyValuePair.Key, "我的反馈", true) != 0 && Operators.CompareString(keyValuePair.Key, "处理中", true) != 0 && Operators.CompareString(keyValuePair.Key, "未处理", true) != 0)
						{
							myCard2.IsSwaped = true;
						}
						else
						{
							MyCard.StackInstall(ref stackPanel, 1, keyValuePair.Key);
						}
						this.PanList.Children.Add(myCard2);
					}
				}
				finally
				{
					Dictionary<string, List<ModMain.FeedbackEntry>>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "加载反馈列表 UI 失败", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000AD9 RID: 2777 RVA: 0x00056B34 File Offset: 0x00054D34
		public static MyListItem FeedbackListItem(ModMain.FeedbackEntry Entry, string CardTitle)
		{
			string type = Entry.Type;
			string logo;
			if (Operators.CompareString(type, "优化建议", true) == 0)
			{
				logo = "pack://application:,,,/images/Blocks/Grass.png";
			}
			else if (Operators.CompareString(type, "新功能提议", true) == 0)
			{
				logo = "pack://application:,,,/images/Blocks/Anvil.png";
			}
			else
			{
				logo = "pack://application:,,,/images/Blocks/RedstoneBlock.png";
			}
			MyListItem myListItem = new MyListItem
			{
				Logo = logo,
				SnapsToDevicePixels = true,
				Title = Entry.Title,
				Info = ((Operators.CompareString(CardTitle, "已处理", true) == 0 || Operators.CompareString(CardTitle, "处理中", true) == 0 || Operators.CompareString(CardTitle, "我的反馈", true) == 0) ? (Entry.databaseParameter + "：") : string.Empty) + Entry.m_CallbackParameter.TrimEnd(new char[]
				{
					'。'
				}),
				Height = 42.0,
				Type = MyListItem.CheckType.Clickable,
				Tag = Entry,
				PaddingRight = 4
			};
			myListItem.WriteResolver(delegate(object sender, MouseButtonEventArgs e)
			{
				base._Lambda$__0();
			});
			return myListItem;
		}

		// Token: 0x06000ADA RID: 2778 RVA: 0x00056C64 File Offset: 0x00054E64
		public static string FeedbackDesc(ModMain.FeedbackEntry Entry)
		{
			string text = "";
			if (!string.IsNullOrWhiteSpace(Entry._CollectionParameter))
			{
				text = string.Concat(new string[]
				{
					text,
					"提交者：",
					Entry._CollectionParameter,
					"（",
					ModBase.GetTimeSpanString(DateTime.Parse(Entry.m_ConsumerParameter) - DateTime.Now),
					"）"
				});
			}
			else
			{
				text = text + "提交于：" + ModBase.GetTimeSpanString(DateTime.Parse(Entry.m_ConsumerParameter) - DateTime.Now);
			}
			text = text + "\r\n状态：" + Entry.databaseParameter;
			if (!string.IsNullOrWhiteSpace(Entry.observerParameter))
			{
				text = text + "\r\n\r\n" + Entry.observerParameter;
			}
			if (!Entry.m_CallbackParameter.Contains("未查看该反馈"))
			{
				text = text + "\r\n\r\n开发者回复：\r\n" + Entry.m_CallbackParameter;
			}
			return text;
		}

		// Token: 0x06000ADB RID: 2779 RVA: 0x00056D50 File Offset: 0x00054F50
		private void BtnConnectWeb_Click(object sender, EventArgs e)
		{
			if (false.Equals(PageSetupSystem.IsLauncherNewest()))
			{
				ModMain.MyMsgBox("你的 PCL2 不是最新版，因此无法提交反馈。\r\n请先在 设置 → 启动器 中更新启动器，确认该问题在最新版中依然存在，然后再提交反馈。", "无法提交反馈", "确定", "", "", false, true, false);
				return;
			}
			if (!this.errorTag)
			{
				ModMain.MyMsgBox("你想要提交的反馈可能已经被其他人提交过了。\r\n请在提交反馈前，先搜索已有的反馈，在确认你的反馈没有与其他人重复之后再继续。", "无法提交反馈", "返回并进行搜索", "", "", false, true, false);
				return;
			}
			ModBase.Feedback("user2", true, false);
		}

		// Token: 0x06000ADC RID: 2780 RVA: 0x0000759D File Offset: 0x0000579D
		private void BtnConnectCode_Click(object sender, EventArgs e)
		{
			ModBase.ClipboardSet(ModBase.initializerState, true);
		}

		// Token: 0x06000ADD RID: 2781 RVA: 0x000075AA File Offset: 0x000057AA
		private void BtnConnectEdit_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://jinshuju.net/forms/rP4b6E/my_entries");
		}

		// Token: 0x06000ADE RID: 2782 RVA: 0x00056DCC File Offset: 0x00054FCC
		public void SearchRun()
		{
			if (string.IsNullOrWhiteSpace(this.SearchBox.Text))
			{
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaOpacity(this.PanSearch, -this.PanSearch.Opacity, 100, 0, null, false),
					ModAnimation.AaCode(delegate
					{
						this.PanSearch.Height = 0.0;
						this.PanSearch.Visibility = Visibility.Collapsed;
						this.PanSend.Visibility = Visibility.Visible;
						this.PanList.Visibility = Visibility.Visible;
					}, 0, true),
					ModAnimation.AaOpacity(this.PanSend, 1.0 - this.PanSend.Opacity, 150, 30, null, false),
					ModAnimation.AaOpacity(this.PanList, 1.0 - this.PanList.Opacity, 150, 30, null, false)
				}, "FrmOtherFeedback Search Switch", false);
				return;
			}
			this.errorTag = true;
			List<ModBase.SearchEntry<ModMain.FeedbackEntry>> list = new List<ModBase.SearchEntry<ModMain.FeedbackEntry>>();
			try
			{
				foreach (KeyValuePair<string, List<ModMain.FeedbackEntry>> keyValuePair in ModMain.wrapperState.Output)
				{
					if (!keyValuePair.Key.StartsWith("我的反馈"))
					{
						try
						{
							foreach (ModMain.FeedbackEntry feedbackEntry in keyValuePair.Value)
							{
								list.Add(new ModBase.SearchEntry<ModMain.FeedbackEntry>
								{
									interceptorParameter = feedbackEntry,
									m_RefParameter = new List<KeyValuePair<string, double>>
									{
										new KeyValuePair<string, double>("PCL-" + Conversions.ToString(feedbackEntry._SchemaParameter) + "#", 0.0001),
										new KeyValuePair<string, double>(feedbackEntry.Title, 1.0),
										new KeyValuePair<string, double>(feedbackEntry.observerParameter, 0.5),
										new KeyValuePair<string, double>(feedbackEntry._CollectionParameter, 0.0001),
										new KeyValuePair<string, double>(feedbackEntry.m_SingletonParameter, 1.5),
										new KeyValuePair<string, double>(feedbackEntry.m_CallbackParameter, 0.5)
									}
								});
							}
						}
						finally
						{
							List<ModMain.FeedbackEntry>.Enumerator enumerator2;
							((IDisposable)enumerator2).Dispose();
						}
					}
				}
			}
			finally
			{
				Dictionary<string, List<ModMain.FeedbackEntry>>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			List<ModBase.SearchEntry<ModMain.FeedbackEntry>> list2 = ModBase.Search<ModMain.FeedbackEntry>(list, this.SearchBox.Text, 5, 0.08);
			this.PanSearchList.Children.Clear();
			if (list2.Count == 0)
			{
				this.PanSearch.Title = "无搜索结果";
				this.PanSearchList.Visibility = Visibility.Collapsed;
			}
			else
			{
				this.PanSearch.Title = "搜索结果";
				try
				{
					foreach (ModBase.SearchEntry<ModMain.FeedbackEntry> searchEntry in list2)
					{
						MyListItem myListItem = PageOtherFeedback.FeedbackListItem(searchEntry.interceptorParameter, "搜索结果");
						if (ModBase._EventState)
						{
							myListItem.Info = string.Concat(new string[]
							{
								searchEntry.serviceParameter ? "完全匹配，" : "",
								"相似度：",
								Conversions.ToString(Math.Round(searchEntry.serverParameter, 3)),
								"，",
								myListItem.Info
							});
						}
						this.PanSearchList.Children.Add(myListItem);
					}
				}
				finally
				{
					List<ModBase.SearchEntry<ModMain.FeedbackEntry>>.Enumerator enumerator3;
					((IDisposable)enumerator3).Dispose();
				}
				this.PanSearchList.Visibility = Visibility.Visible;
			}
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaOpacity(this.PanList, -this.PanList.Opacity, 100, 0, null, false),
				ModAnimation.AaOpacity(this.PanSend, -this.PanSend.Opacity, 100, 0, null, false),
				ModAnimation.AaCode(delegate
				{
					this.PanList.Visibility = Visibility.Collapsed;
					this.PanSend.Visibility = Visibility.Collapsed;
					this.PanSearch.Visibility = Visibility.Visible;
					this.PanSearch.TriggerForceResize();
				}, 0, true),
				ModAnimation.AaOpacity(this.PanSearch, 1.0 - this.PanSearch.Opacity, 150, 30, null, false)
			}, "FrmOtherFeedback Search Switch", false);
		}

		// Token: 0x17000184 RID: 388
		// (get) Token: 0x06000ADF RID: 2783 RVA: 0x000075B6 File Offset: 0x000057B6
		// (set) Token: 0x06000AE0 RID: 2784 RVA: 0x000075BE File Offset: 0x000057BE
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x17000185 RID: 389
		// (get) Token: 0x06000AE1 RID: 2785 RVA: 0x000075C7 File Offset: 0x000057C7
		// (set) Token: 0x06000AE2 RID: 2786 RVA: 0x000075CF File Offset: 0x000057CF
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x17000186 RID: 390
		// (get) Token: 0x06000AE3 RID: 2787 RVA: 0x000075D8 File Offset: 0x000057D8
		// (set) Token: 0x06000AE4 RID: 2788 RVA: 0x0005721C File Offset: 0x0005541C
		internal virtual MySearchBox SearchBox
		{
			[CompilerGenerated]
			get
			{
				return this.strategyTag;
			}
			[CompilerGenerated]
			set
			{
				MySearchBox.TextChangedEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.SearchRun();
				};
				MySearchBox mySearchBox = this.strategyTag;
				if (mySearchBox != null)
				{
					mySearchBox.PushWrapper(obj);
				}
				this.strategyTag = value;
				mySearchBox = this.strategyTag;
				if (mySearchBox != null)
				{
					mySearchBox.RunWrapper(obj);
				}
			}
		}

		// Token: 0x17000187 RID: 391
		// (get) Token: 0x06000AE5 RID: 2789 RVA: 0x000075E0 File Offset: 0x000057E0
		// (set) Token: 0x06000AE6 RID: 2790 RVA: 0x000075E8 File Offset: 0x000057E8
		internal virtual MyCard PanSend { get; set; }

		// Token: 0x17000188 RID: 392
		// (get) Token: 0x06000AE7 RID: 2791 RVA: 0x000075F1 File Offset: 0x000057F1
		// (set) Token: 0x06000AE8 RID: 2792 RVA: 0x000075F9 File Offset: 0x000057F9
		internal virtual TextBlock LabConnect { get; set; }

		// Token: 0x17000189 RID: 393
		// (get) Token: 0x06000AE9 RID: 2793 RVA: 0x00007602 File Offset: 0x00005802
		// (set) Token: 0x06000AEA RID: 2794 RVA: 0x00057260 File Offset: 0x00055460
		internal virtual MyButton BtnConnectWeb
		{
			[CompilerGenerated]
			get
			{
				return this.m_DicTag;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnConnectWeb_Click);
				MyButton dicTag = this.m_DicTag;
				if (dicTag != null)
				{
					dicTag.RevertResolver(obj);
				}
				this.m_DicTag = value;
				dicTag = this.m_DicTag;
				if (dicTag != null)
				{
					dicTag.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700018A RID: 394
		// (get) Token: 0x06000AEB RID: 2795 RVA: 0x0000760A File Offset: 0x0000580A
		// (set) Token: 0x06000AEC RID: 2796 RVA: 0x000572A4 File Offset: 0x000554A4
		internal virtual MyButton BtnConnectEdit
		{
			[CompilerGenerated]
			get
			{
				return this.m_ConfigurationTag;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnConnectEdit_Click);
				MyButton configurationTag = this.m_ConfigurationTag;
				if (configurationTag != null)
				{
					configurationTag.RevertResolver(obj);
				}
				this.m_ConfigurationTag = value;
				configurationTag = this.m_ConfigurationTag;
				if (configurationTag != null)
				{
					configurationTag.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700018B RID: 395
		// (get) Token: 0x06000AED RID: 2797 RVA: 0x00007612 File Offset: 0x00005812
		// (set) Token: 0x06000AEE RID: 2798 RVA: 0x000572E8 File Offset: 0x000554E8
		internal virtual MyButton BtnConnectCode
		{
			[CompilerGenerated]
			get
			{
				return this.configTag;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnConnectCode_Click);
				MyButton myButton = this.configTag;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.configTag = value;
				myButton = this.configTag;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700018C RID: 396
		// (get) Token: 0x06000AEF RID: 2799 RVA: 0x0000761A File Offset: 0x0000581A
		// (set) Token: 0x06000AF0 RID: 2800 RVA: 0x00007622 File Offset: 0x00005822
		internal virtual MyCard PanSearch { get; set; }

		// Token: 0x1700018D RID: 397
		// (get) Token: 0x06000AF1 RID: 2801 RVA: 0x0000762B File Offset: 0x0000582B
		// (set) Token: 0x06000AF2 RID: 2802 RVA: 0x00007633 File Offset: 0x00005833
		internal virtual StackPanel PanSearchList { get; set; }

		// Token: 0x1700018E RID: 398
		// (get) Token: 0x06000AF3 RID: 2803 RVA: 0x0000763C File Offset: 0x0000583C
		// (set) Token: 0x06000AF4 RID: 2804 RVA: 0x00007644 File Offset: 0x00005844
		internal virtual StackPanel PanList { get; set; }

		// Token: 0x1700018F RID: 399
		// (get) Token: 0x06000AF5 RID: 2805 RVA: 0x0000764D File Offset: 0x0000584D
		// (set) Token: 0x06000AF6 RID: 2806 RVA: 0x00007655 File Offset: 0x00005855
		internal virtual MyCard PanLoad { get; set; }

		// Token: 0x17000190 RID: 400
		// (get) Token: 0x06000AF7 RID: 2807 RVA: 0x0000765E File Offset: 0x0000585E
		// (set) Token: 0x06000AF8 RID: 2808 RVA: 0x00007666 File Offset: 0x00005866
		internal virtual MyLoading Load { get; set; }

		// Token: 0x06000AF9 RID: 2809 RVA: 0x0005732C File Offset: 0x0005552C
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this._GlobalTag)
			{
				this._GlobalTag = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pageother/pageotherfeedback.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000AFA RID: 2810 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000AFB RID: 2811 RVA: 0x0005735C File Offset: 0x0005555C
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			if (connectionId == 3)
			{
				this.SearchBox = (MySearchBox)target;
				return;
			}
			if (connectionId == 4)
			{
				this.PanSend = (MyCard)target;
				return;
			}
			if (connectionId == 5)
			{
				this.LabConnect = (TextBlock)target;
				return;
			}
			if (connectionId == 6)
			{
				this.BtnConnectWeb = (MyButton)target;
				return;
			}
			if (connectionId == 7)
			{
				this.BtnConnectEdit = (MyButton)target;
				return;
			}
			if (connectionId == 8)
			{
				this.BtnConnectCode = (MyButton)target;
				return;
			}
			if (connectionId == 9)
			{
				this.PanSearch = (MyCard)target;
				return;
			}
			if (connectionId == 10)
			{
				this.PanSearchList = (StackPanel)target;
				return;
			}
			if (connectionId == 11)
			{
				this.PanList = (StackPanel)target;
				return;
			}
			if (connectionId == 12)
			{
				this.PanLoad = (MyCard)target;
				return;
			}
			if (connectionId == 13)
			{
				this.Load = (MyLoading)target;
				return;
			}
			this._GlobalTag = true;
		}

		// Token: 0x040005BE RID: 1470
		private bool errorTag;

		// Token: 0x040005BF RID: 1471
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyScrollViewer exceptionTag;

		// Token: 0x040005C0 RID: 1472
		[AccessedThroughProperty("PanMain")]
		[CompilerGenerated]
		private StackPanel testsTag;

		// Token: 0x040005C1 RID: 1473
		[AccessedThroughProperty("SearchBox")]
		[CompilerGenerated]
		private MySearchBox strategyTag;

		// Token: 0x040005C2 RID: 1474
		[AccessedThroughProperty("PanSend")]
		[CompilerGenerated]
		private MyCard _RulesTag;

		// Token: 0x040005C3 RID: 1475
		[CompilerGenerated]
		[AccessedThroughProperty("LabConnect")]
		private TextBlock workerTag;

		// Token: 0x040005C4 RID: 1476
		[CompilerGenerated]
		[AccessedThroughProperty("BtnConnectWeb")]
		private MyButton m_DicTag;

		// Token: 0x040005C5 RID: 1477
		[AccessedThroughProperty("BtnConnectEdit")]
		[CompilerGenerated]
		private MyButton m_ConfigurationTag;

		// Token: 0x040005C6 RID: 1478
		[AccessedThroughProperty("BtnConnectCode")]
		[CompilerGenerated]
		private MyButton configTag;

		// Token: 0x040005C7 RID: 1479
		[AccessedThroughProperty("PanSearch")]
		[CompilerGenerated]
		private MyCard _ManagerTag;

		// Token: 0x040005C8 RID: 1480
		[AccessedThroughProperty("PanSearchList")]
		[CompilerGenerated]
		private StackPanel ruleTag;

		// Token: 0x040005C9 RID: 1481
		[CompilerGenerated]
		[AccessedThroughProperty("PanList")]
		private StackPanel _MerchantTag;

		// Token: 0x040005CA RID: 1482
		[AccessedThroughProperty("PanLoad")]
		[CompilerGenerated]
		private MyCard _ExporterTag;

		// Token: 0x040005CB RID: 1483
		[AccessedThroughProperty("Load")]
		[CompilerGenerated]
		private MyLoading _QueueTag;

		// Token: 0x040005CC RID: 1484
		private bool _GlobalTag;
	}
}
