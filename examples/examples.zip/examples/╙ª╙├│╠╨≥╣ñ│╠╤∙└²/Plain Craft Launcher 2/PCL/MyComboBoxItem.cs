﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000012 RID: 18
	public class MyComboBoxItem : ComboBoxItem
	{
		// Token: 0x0600006A RID: 106 RVA: 0x0000C854 File Offset: 0x0000AA54
		public MyComboBoxItem()
		{
			base.Unselected += delegate(object sender, RoutedEventArgs e)
			{
				this.RefreshColor();
			};
			base.MouseMove += delegate(object sender, MouseEventArgs e)
			{
				this.RefreshColor();
			};
			base.MouseLeave += delegate(object sender, MouseEventArgs e)
			{
				this.RefreshColor();
			};
			base.Selected += delegate(object sender, RoutedEventArgs e)
			{
				this.RefreshColor();
			};
			base.IsEnabledChanged += delegate(object sender, DependencyPropertyChangedEventArgs e)
			{
				this.RefreshColor();
			};
			base.MouseLeftButtonUp += this.MyComboBoxItem_MouseLeftButtonUp;
			this.m_Container = ModBase.GetUuid();
			base.Style = (Style)base.FindResource("MyComboBoxItem");
		}

		// Token: 0x0600006B RID: 107 RVA: 0x0000C8F8 File Offset: 0x0000AAF8
		private void RefreshColor()
		{
			string right;
			double num;
			int time;
			if (base.IsSelected)
			{
				right = "ColorBrush6";
				num = 1.0;
				time = 100;
			}
			else if (base.IsMouseOver)
			{
				right = "ColorBrush8";
				num = 1.0;
				time = 100;
			}
			else if (base.IsEnabled)
			{
				right = "ColorBrushTransparent";
				num = 1.0;
				time = 300;
			}
			else
			{
				right = "ColorBrushTransparent";
				num = 0.4;
				time = 300;
			}
			if (Operators.CompareString(this.code, right, true) != 0 || this.tokenizer != num)
			{
				this.code = right;
				this.tokenizer = num;
				if (base.IsLoaded && ModAnimation.DefineModel() == 0)
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaColor(this, Control.BackgroundProperty, this.code, time, 0, null, false),
						ModAnimation.AaOpacity(this, this.tokenizer - base.Opacity, time, 0, null, false)
					}, "ComboBoxItem Color " + Conversions.ToString(this.m_Container), false);
					return;
				}
				ModAnimation.AniStop("ComboBoxItem Color " + Conversions.ToString(this.m_Container));
				base.SetResourceReference(Control.BackgroundProperty, this.code);
				base.Opacity = this.tokenizer;
			}
		}

		// Token: 0x0600006C RID: 108 RVA: 0x000026BB File Offset: 0x000008BB
		public override string ToString()
		{
			return base.Content.ToString();
		}

		// Token: 0x0600006D RID: 109 RVA: 0x000026C8 File Offset: 0x000008C8
		public static implicit operator string(MyComboBoxItem Value)
		{
			return Value.Content.ToString();
		}

		// Token: 0x0600006E RID: 110 RVA: 0x000026D5 File Offset: 0x000008D5
		private void MyComboBoxItem_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			ModBase.Log("[Control] 选择下拉列表项：" + this.ToString(), ModBase.LogLevel.Normal, "出现错误");
		}

		// Token: 0x04000013 RID: 19
		public int m_Container;

		// Token: 0x04000014 RID: 20
		private string code;

		// Token: 0x04000015 RID: 21
		private double tokenizer;
	}
}
