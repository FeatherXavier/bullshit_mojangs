﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200009E RID: 158
	[DesignerGenerated]
	public class PageLoginMs : StackPanel, IComponentConnector
	{
		// Token: 0x060005E1 RID: 1505 RVA: 0x000050E8 File Offset: 0x000032E8
		public PageLoginMs()
		{
			this.InitializeComponent();
		}

		// Token: 0x060005E2 RID: 1506 RVA: 0x000050F7 File Offset: 0x000032F7
		public void Reload(bool KeepInput)
		{
		}

		// Token: 0x060005E3 RID: 1507 RVA: 0x000050F9 File Offset: 0x000032F9
		public static ModLaunch.McLoginMs GetLoginData()
		{
			return new ModLaunch.McLoginMs
			{
				strategyProccesor = Conversions.ToString(ModBase._ParamsState.Get("CacheMsOAuthRefresh", null)),
				_DicProccesor = Conversions.ToString(ModBase._ParamsState.Get("CacheMsName", null))
			};
		}

		// Token: 0x060005E4 RID: 1508 RVA: 0x0002C4F0 File Offset: 0x0002A6F0
		public static string IsVaild(ModLaunch.McLoginMs LoginData)
		{
			string result;
			if (Operators.CompareString(LoginData.strategyProccesor, "", true) == 0)
			{
				result = "请在登录账号后再继续！";
			}
			else
			{
				result = "";
			}
			return result;
		}

		// Token: 0x060005E5 RID: 1509 RVA: 0x00005136 File Offset: 0x00003336
		public string IsVaild()
		{
			return PageLoginMs.IsVaild(PageLoginMs.GetLoginData());
		}

		// Token: 0x060005E6 RID: 1510 RVA: 0x00005142 File Offset: 0x00003342
		private void BtnLogin_Click(object sender, EventArgs e)
		{
			this.BtnLogin.IsEnabled = false;
			this.BtnLogin.Text = "登录中 0%";
			ModBase.RunInNewThread(delegate
			{
				try
				{
					ModLaunch._ExpressionTag.Start(PageLoginMs.GetLoginData(), false);
					while (ModLaunch._ExpressionTag.State == ModBase.LoadState.Loading)
					{
						ModBase.RunInUi(delegate()
						{
							this.BtnLogin.Text = "登录中 " + Conversions.ToString(Math.Round(ModLaunch._ExpressionTag.Progress * 100.0)) + "%";
						}, false);
						Thread.Sleep(50);
					}
					if (ModLaunch._ExpressionTag.State == ModBase.LoadState.Finished)
					{
						ModBase.RunInUi((PageLoginMs._Closure$__.$I5-2 == null) ? (PageLoginMs._Closure$__.$I5-2 = delegate()
						{
							ModMain._FilterAccount.RefreshPage(false, true);
						}) : PageLoginMs._Closure$__.$I5-2, false);
					}
					else
					{
						if (ModLaunch._ExpressionTag.State == ModBase.LoadState.Aborted)
						{
							throw new ThreadInterruptedException();
						}
						if (ModLaunch._ExpressionTag.Error == null)
						{
							throw new Exception("未知错误！");
						}
						throw new Exception(ModLaunch._ExpressionTag.Error.Message, ModLaunch._ExpressionTag.Error);
					}
				}
				catch (ThreadInterruptedException ex)
				{
					ModMain.Hint("登录已取消！", ModMain.HintType.Info, true);
				}
				catch (Exception ex2)
				{
					if (Operators.CompareString(ex2.Message, "$$", true) != 0)
					{
						if (ex2.Message.StartsWith("$"))
						{
							ModMain.Hint(ex2.Message.TrimStart(new char[]
							{
								'$'
							}), ModMain.HintType.Critical, true);
						}
						else
						{
							ModBase.Log(ex2, "微软登录尝试失败", ModBase.LogLevel.Msgbox, "出现错误");
						}
					}
				}
				finally
				{
					ModBase.RunInUi(delegate()
					{
						this.BtnLogin.IsEnabled = true;
						this.BtnLogin.Text = "添加账号";
					}, false);
				}
			}, "Ms Login", ThreadPriority.Normal);
		}

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x060005E7 RID: 1511 RVA: 0x00005178 File Offset: 0x00003378
		// (set) Token: 0x060005E8 RID: 1512 RVA: 0x00005180 File Offset: 0x00003380
		internal virtual StackPanel PanEmpty { get; set; }

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x060005E9 RID: 1513 RVA: 0x00005189 File Offset: 0x00003389
		// (set) Token: 0x060005EA RID: 1514 RVA: 0x0002C520 File Offset: 0x0002A720
		internal virtual MyButton BtnLogin
		{
			[CompilerGenerated]
			get
			{
				return this.m_RuleRepository;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnLogin_Click);
				MyButton ruleRepository = this.m_RuleRepository;
				if (ruleRepository != null)
				{
					ruleRepository.RevertResolver(obj);
				}
				this.m_RuleRepository = value;
				ruleRepository = this.m_RuleRepository;
				if (ruleRepository != null)
				{
					ruleRepository.PostResolver(obj);
				}
			}
		}

		// Token: 0x060005EB RID: 1515 RVA: 0x0002C564 File Offset: 0x0002A764
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_MerchantRepository)
			{
				this.m_MerchantRepository = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagelaunch/pageloginms.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x060005EC RID: 1516 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060005ED RID: 1517 RVA: 0x00005191 File Offset: 0x00003391
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanEmpty = (StackPanel)target;
				return;
			}
			if (connectionId == 2)
			{
				this.BtnLogin = (MyButton)target;
				return;
			}
			this.m_MerchantRepository = true;
		}

		// Token: 0x040002AD RID: 685
		[AccessedThroughProperty("PanEmpty")]
		[CompilerGenerated]
		private StackPanel _ManagerRepository;

		// Token: 0x040002AE RID: 686
		[CompilerGenerated]
		[AccessedThroughProperty("BtnLogin")]
		private MyButton m_RuleRepository;

		// Token: 0x040002AF RID: 687
		private bool m_MerchantRepository;
	}
}
