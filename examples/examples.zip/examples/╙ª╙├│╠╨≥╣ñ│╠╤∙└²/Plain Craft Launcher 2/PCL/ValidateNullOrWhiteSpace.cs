﻿using System;
using Microsoft.VisualBasic;

namespace PCL
{
	// Token: 0x020000E3 RID: 227
	public class ValidateNullOrWhiteSpace : Validate
	{
		// Token: 0x060008F0 RID: 2288 RVA: 0x0003F704 File Offset: 0x0003D904
		public override string Validate(string Str)
		{
			string result;
			if (!Information.IsNothing(Str) && !string.IsNullOrWhiteSpace(Str))
			{
				result = "";
			}
			else
			{
				result = "输入内容不能为空！";
			}
			return result;
		}
	}
}
