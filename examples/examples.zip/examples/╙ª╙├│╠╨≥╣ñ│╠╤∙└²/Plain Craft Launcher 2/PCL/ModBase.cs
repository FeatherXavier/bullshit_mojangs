﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Management;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using System.Xml.Linq;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.Win32;
using Newtonsoft.Json;
using Ookii.Dialogs.Wpf;
using PCL.My;
using PCL.My.Resources;

namespace PCL
{
	// Token: 0x020001A4 RID: 420
	[StandardModule]
	public sealed class ModBase
	{
		// Token: 0x0600135A RID: 4954 RVA: 0x0008357C File Offset: 0x0008177C
		public static double MathBezier(double x, double x1, double y1, double x2, double y2, double acc = 0.01)
		{
			double result;
			if (x > 0.0 && !double.IsNaN(x))
			{
				if (x >= 1.0)
				{
					result = 1.0;
				}
				else
				{
					object obj = x;
					object obj2;
					do
					{
						obj2 = Operators.MultiplyObject(Operators.MultiplyObject(3, obj), Operators.AddObject(Operators.AddObject(Operators.MultiplyObject(Operators.MultiplyObject(0.33333333 + x1 - x2, obj), obj), Operators.MultiplyObject(x2 - 2.0 * x1, obj)), x1));
						obj = Operators.AddObject(obj, Operators.MultiplyObject(Operators.SubtractObject(x, obj2), 0.5));
					}
					while (!Operators.ConditionalCompareObjectLess(NewLateBinding.LateGet(null, typeof(Math), "Abs", new object[]
					{
						Operators.SubtractObject(obj2, x)
					}, null, null, null), acc, true));
					result = Conversions.ToDouble(Operators.MultiplyObject(Operators.MultiplyObject(3, obj), Operators.AddObject(Operators.AddObject(Operators.MultiplyObject(Operators.MultiplyObject(0.33333333 + y1 - y2, obj), obj), Operators.MultiplyObject(y2 - 2.0 * y1, obj)), y1)));
				}
			}
			else
			{
				result = 0.0;
			}
			return result;
		}

		// Token: 0x0600135B RID: 4955 RVA: 0x0000B404 File Offset: 0x00009604
		public static byte MathByte(double d)
		{
			if (d < 0.0)
			{
				d = 0.0;
			}
			if (d > 255.0)
			{
				d = 255.0;
			}
			return checked((byte)Math.Round(d));
		}

		// Token: 0x0600135C RID: 4956 RVA: 0x000836F0 File Offset: 0x000818F0
		public static ModBase.MyColor MathRound(ModBase.MyColor col, int w = 0)
		{
			return new ModBase.MyColor
			{
				m_StrategyParameter = Math.Round(col.m_StrategyParameter, w),
				m_RulesParameter = Math.Round(col.m_RulesParameter, w),
				m_WorkerParameter = Math.Round(col.m_WorkerParameter, w),
				_DicParameter = Math.Round(col._DicParameter, w)
			};
		}

		// Token: 0x0600135D RID: 4957 RVA: 0x0000B43B File Offset: 0x0000963B
		public static double MathPercent(double ValueA, double ValueB, double Percent)
		{
			return Math.Round(ValueA * (1.0 - Percent) + ValueB * Percent, 6);
		}

		// Token: 0x0600135E RID: 4958 RVA: 0x0000B454 File Offset: 0x00009654
		public static ModBase.MyColor MathPercent(ModBase.MyColor ValueA, ModBase.MyColor ValueB, double Percent)
		{
			return ModBase.MathRound(ValueA * (1.0 - Percent) + ValueB * Percent, 6);
		}

		// Token: 0x0600135F RID: 4959 RVA: 0x0000B479 File Offset: 0x00009679
		public static double MathRange(double value, double min, double max)
		{
			return Math.Max(min, Math.Min(max, value));
		}

		// Token: 0x06001360 RID: 4960 RVA: 0x0008374C File Offset: 0x0008194C
		public static int MathSgn(double Value)
		{
			int result;
			if (Value == 0.0)
			{
				result = 0;
			}
			else if (Value > 0.0)
			{
				result = 1;
			}
			else
			{
				result = -1;
			}
			return result;
		}

		// Token: 0x06001361 RID: 4961 RVA: 0x0008377C File Offset: 0x0008197C
		public static void RegRename(RegistryKey parentKey, string subKeyName, string newSubKeyName)
		{
			if (parentKey.GetSubKeyNames().Contains(newSubKeyName))
			{
				parentKey.DeleteSubKeyTree(newSubKeyName, false);
			}
			RegistryKey registryKey = parentKey.OpenSubKey(subKeyName);
			if (!Information.IsNothing(registryKey))
			{
				RegistryKey registryKey2 = parentKey.CreateSubKey(newSubKeyName);
				if (registryKey.GetSubKeyNames().Length > 0)
				{
					throw new NotSupportedException("不支持对包含子键的子键进行重命名：" + registryKey.GetSubKeyNames()[0] + "。");
				}
				foreach (string name in registryKey.GetValueNames())
				{
					object objectValue = RuntimeHelpers.GetObjectValue(registryKey.GetValue(name));
					RegistryValueKind valueKind = registryKey.GetValueKind(name);
					registryKey2.SetValue(name, RuntimeHelpers.GetObjectValue(objectValue), valueKind);
				}
				parentKey.DeleteSubKeyTree(subKeyName, false);
			}
		}

		// Token: 0x06001362 RID: 4962 RVA: 0x0008382C File Offset: 0x00081A2C
		public static string ReadReg(string Key, string DefaultValue = "")
		{
			string result;
			try
			{
				RegistryKey registryKey = MyWpfExtension.FindModel().Registry.CurrentUser.OpenSubKey("Software\\PCL", true);
				if (registryKey == null)
				{
					result = DefaultValue;
				}
				else
				{
					StringBuilder stringBuilder = new StringBuilder();
					stringBuilder.AppendLine(Conversions.ToString(registryKey.GetValue(Key)));
					string text = stringBuilder.ToString().Replace("\r\n", "");
					result = ((Operators.CompareString(text, "", true) == 0) ? DefaultValue : text);
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "读取注册表出错：" + Key, ModBase.LogLevel.Hint, "出现错误");
				result = DefaultValue;
			}
			return result;
		}

		// Token: 0x06001363 RID: 4963 RVA: 0x000838D8 File Offset: 0x00081AD8
		public static void WriteReg(string Key, string Value, bool ShowException = false)
		{
			try
			{
				RegistryKey currentUser = MyWpfExtension.FindModel().Registry.CurrentUser;
				RegistryKey registryKey = currentUser.OpenSubKey("Software\\PCL", true);
				if (registryKey == null)
				{
					registryKey = currentUser.CreateSubKey("Software\\PCL");
				}
				registryKey.SetValue(Key, Value);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "写入注册表出错：" + Key, ShowException ? ModBase.LogLevel.Hint : ModBase.LogLevel.Developer, "出现错误");
				if (ShowException)
				{
					throw;
				}
			}
		}

		// Token: 0x06001364 RID: 4964 RVA: 0x0000B488 File Offset: 0x00009688
		public static void IniClearCache(string FileName)
		{
			if (!FileName.Contains(":\\"))
			{
				FileName = ModBase.Path + "PCL\\" + FileName + ".ini";
			}
			if (ModBase._SpecificationState.ContainsKey(FileName))
			{
				ModBase._SpecificationState.Remove(FileName);
			}
		}

		// Token: 0x06001365 RID: 4965 RVA: 0x0008395C File Offset: 0x00081B5C
		private static ModBase.IniCache IniGetContent(string FileName)
		{
			ModBase.IniCache result;
			try
			{
				if (!FileName.Contains(":\\"))
				{
					FileName = ModBase.Path + "PCL\\" + FileName + ".ini";
				}
				if (ModBase._SpecificationState.ContainsKey(FileName))
				{
					ModBase.IniCache iniCache = new ModBase.IniCache();
					ModBase._SpecificationState.TryGetValue(FileName, out iniCache);
					result = iniCache;
				}
				else
				{
					ModBase.IniCache iniCache2;
					if (File.Exists(FileName))
					{
						string merchantParameter = ("\r\n" + ModBase.ReadFile(FileName) + "\r\n").Replace("\r\n", "\r").Replace("\n", "\r").Replace("\r", "\r\n").Replace("\r\n\r\n", "\r\n").Replace("\0", "");
						iniCache2 = new ModBase.IniCache
						{
							_MerchantParameter = merchantParameter
						};
					}
					else
					{
						iniCache2 = new ModBase.IniCache
						{
							_MerchantParameter = ""
						};
					}
					if (!ModBase._SpecificationState.ContainsKey(FileName))
					{
						ModBase._SpecificationState.Add(FileName, iniCache2);
					}
					result = iniCache2;
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "读取文件失败：" + FileName, ModBase.LogLevel.Hint, "出现错误");
				result = new ModBase.IniCache
				{
					_MerchantParameter = ""
				};
			}
			return result;
		}

		// Token: 0x06001366 RID: 4966 RVA: 0x00083AA4 File Offset: 0x00081CA4
		public static string ReadIni(string FileName, string Key, string DefaultValue = "")
		{
			string result;
			try
			{
				ModBase.IniCache iniCache = ModBase.IniGetContent(FileName);
				if (Information.IsNothing(iniCache))
				{
					result = DefaultValue;
				}
				else if (iniCache.exporterParameter.ContainsKey(Key))
				{
					result = (iniCache.exporterParameter[Key] ?? DefaultValue);
				}
				else if (iniCache._MerchantParameter.Contains("\r\n" + Key + ":"))
				{
					string text = Strings.Mid(iniCache._MerchantParameter, checked(iniCache._MerchantParameter.IndexOf("\r\n" + Key + ":") + 3));
					text = (text.Contains("\r\n") ? Strings.Mid(text, 1, text.IndexOf("\r\n")) : text).Replace(Key + ":", "");
					iniCache.exporterParameter.Add(Key, (Operators.CompareString(text, "\n", true) == 0) ? "" : text);
					result = ((Operators.CompareString(text, "\n", true) == 0) ? "" : text);
				}
				else
				{
					result = DefaultValue;
				}
			}
			catch (Exception ex)
			{
				result = DefaultValue;
			}
			return result;
		}

		// Token: 0x06001367 RID: 4967 RVA: 0x00083BD0 File Offset: 0x00081DD0
		public static void WriteIni(string FileName, string Key, string Value)
		{
			try
			{
				if (!FileName.Contains(":\\"))
				{
					FileName = ModBase.Path + "PCL\\" + FileName + ".ini";
				}
				if (Information.IsNothing(Value))
				{
					Value = "";
				}
				Value = Value.Replace("\r\n", "");
				if (!Directory.Exists(ModBase.GetPathFromFullPath(FileName)))
				{
					Directory.CreateDirectory(ModBase.GetPathFromFullPath(FileName));
				}
				string text = ModBase.IniGetContent(FileName)._MerchantParameter;
				if (!text.EndsWith("\r\n"))
				{
					text += "\r\n";
				}
				if (!text.Contains(string.Concat(new string[]
				{
					"\r\n",
					Key,
					":",
					Value,
					"\r\n"
				})))
				{
					string text2 = ModBase.ReadIni(FileName, Key, "");
					if (Operators.CompareString(text2, "", true) == 0 && !text.Contains("\r\n" + Key + ":"))
					{
						text = string.Concat(new string[]
						{
							text,
							"\r\n",
							Key,
							":",
							Value,
							"\r\n"
						});
					}
					else
					{
						text = text.Replace(string.Concat(new string[]
						{
							"\r\n",
							Key,
							":",
							text2,
							"\r\n"
						}), string.Concat(new string[]
						{
							"\r\n",
							Key,
							":",
							Value,
							"\r\n"
						}));
					}
					ModBase.WriteFile(FileName, text, false, null);
					ModBase._SpecificationState[FileName]._MerchantParameter = text;
					ModBase._SpecificationState[FileName].exporterParameter.Remove(Key);
					ModBase._SpecificationState[FileName].exporterParameter.Add(Key, Value);
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, string.Concat(new string[]
				{
					"写入文件失败：",
					FileName,
					"/",
					Key,
					": ",
					Value
				}), ModBase.LogLevel.Debug, "出现错误");
			}
		}

		// Token: 0x06001368 RID: 4968 RVA: 0x00083E0C File Offset: 0x0008200C
		public static string GetPathFromFullPath(string FilePath)
		{
			if (!FilePath.Contains("\\") && !FilePath.Contains("/"))
			{
				throw new Exception("不包含路径：" + FilePath);
			}
			checked
			{
				string text;
				if (!FilePath.EndsWith("\\") && !FilePath.EndsWith("/"))
				{
					text = Strings.Left(FilePath, FilePath.LastIndexOfAny(new char[]
					{
						'\\',
						'/'
					}) + 1);
					if (Operators.CompareString(text, "", true) == 0)
					{
						throw new Exception("不包含路径：" + FilePath);
					}
				}
				else
				{
					bool flag = FilePath.EndsWith("\\");
					FilePath = Strings.Left(FilePath, Strings.Len(FilePath) - 1);
					text = Strings.Left(FilePath, FilePath.LastIndexOfAny(new char[]
					{
						'\\',
						'/'
					})) + (flag ? "\\" : "/");
					if (Operators.CompareString(text, "", true) == 0)
					{
						throw new Exception("不包含路径：" + FilePath);
					}
				}
				return text;
			}
		}

		// Token: 0x06001369 RID: 4969 RVA: 0x00083F0C File Offset: 0x0008210C
		public static string GetFileNameFromPath(string FilePath)
		{
			if (!FilePath.EndsWith("\\") && !FilePath.EndsWith("/"))
			{
				string text;
				if (!FilePath.Contains("\\") && !FilePath.Contains("/"))
				{
					text = FilePath;
				}
				else
				{
					if (FilePath.Contains("?"))
					{
						FilePath = Strings.Left(FilePath, FilePath.LastIndexOf("?"));
					}
					text = Strings.Mid(FilePath, checked(FilePath.LastIndexOfAny(new char[]
					{
						'\\',
						'/'
					}) + 2));
					if (Operators.CompareString(text, "", true) == 0)
					{
						throw new Exception("不包含文件名：" + FilePath);
					}
				}
				return text;
			}
			throw new Exception("不包含文件名：" + FilePath);
		}

		// Token: 0x0600136A RID: 4970 RVA: 0x00083FC4 File Offset: 0x000821C4
		public static string GetFileNameWithoutExtentionFromPath(string FilePath)
		{
			string fileNameFromPath = ModBase.GetFileNameFromPath(FilePath);
			string result;
			if (fileNameFromPath.Contains("."))
			{
				result = fileNameFromPath.Substring(0, fileNameFromPath.LastIndexOf("."));
			}
			else
			{
				result = fileNameFromPath;
			}
			return result;
		}

		// Token: 0x0600136B RID: 4971 RVA: 0x00084000 File Offset: 0x00082200
		public static string GetFolderNameFromPath(string FolderPath)
		{
			string result;
			if (!FolderPath.EndsWith(":\\") && !FolderPath.EndsWith(":\\\\"))
			{
				if (FolderPath.EndsWith("\\") || FolderPath.EndsWith("/"))
				{
					FolderPath = Strings.Left(FolderPath, checked(FolderPath.Length - 1));
				}
				result = ModBase.GetFileNameFromPath(FolderPath);
			}
			else
			{
				result = FolderPath.Substring(0, 1);
			}
			return result;
		}

		// Token: 0x0600136C RID: 4972 RVA: 0x00084064 File Offset: 0x00082264
		public static string ReadFile(string FilePath)
		{
			string result;
			try
			{
				if (!FilePath.Contains(":\\"))
				{
					FilePath = ModBase.Path + FilePath;
				}
				if (File.Exists(FilePath))
				{
					result = ModBase.DecodeBytes(File.ReadAllBytes(FilePath));
				}
				else
				{
					result = "";
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "读取文件出错：" + FilePath, ModBase.LogLevel.Debug, "出现错误");
				result = "";
			}
			return result;
		}

		// Token: 0x0600136D RID: 4973 RVA: 0x000840E8 File Offset: 0x000822E8
		public static string ReadFile(Stream Stream, Encoding Encoding = null)
		{
			string result;
			try
			{
				byte[] array = new byte[16385];
				int i = Stream.Read(array, 0, 16384);
				List<byte> list = new List<byte>();
				while (i > 0)
				{
					if (i > 0)
					{
						list.AddRange(array.ToList<byte>().GetRange(0, i));
					}
					i = Stream.Read(array, 0, 16384);
				}
				byte[] bytes = list.ToArray();
				result = (Encoding ?? ModBase.GetEncoding(bytes)).GetString(bytes);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "读取流出错", ModBase.LogLevel.Debug, "出现错误");
				result = "";
			}
			return result;
		}

		// Token: 0x0600136E RID: 4974 RVA: 0x00084198 File Offset: 0x00082398
		public static bool WriteFile(string FilePath, string Text, bool Append = false, Encoding Encoding = null)
		{
			bool result;
			try
			{
				if (!FilePath.Contains(":\\"))
				{
					FilePath = ModBase.Path + FilePath;
				}
				Directory.CreateDirectory(ModBase.GetPathFromFullPath(FilePath));
				if (File.Exists(FilePath))
				{
					using (StreamWriter streamWriter = new StreamWriter(FilePath, Append, Encoding ?? ModBase.GetEncoding(FilePath)))
					{
						streamWriter.Write(Text);
						streamWriter.Flush();
						streamWriter.Close();
						goto IL_72;
					}
				}
				File.WriteAllText(FilePath, Text, Encoding ?? new UTF8Encoding(false));
				IL_72:
				result = true;
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "写入文件时出错：" + FilePath, ModBase.LogLevel.Debug, "出现错误");
				result = false;
			}
			return result;
		}

		// Token: 0x0600136F RID: 4975 RVA: 0x00084260 File Offset: 0x00082460
		public static bool WriteFile(string FilePath, byte[] Content, bool Append = false)
		{
			bool result;
			try
			{
				if (!FilePath.Contains(":\\"))
				{
					FilePath = ModBase.Path + FilePath;
				}
				Directory.CreateDirectory(ModBase.GetPathFromFullPath(FilePath));
				File.WriteAllBytes(FilePath, Content);
				result = true;
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "写入文件时出错：" + FilePath, ModBase.LogLevel.Debug, "出现错误");
				result = false;
			}
			return result;
		}

		// Token: 0x06001370 RID: 4976 RVA: 0x000842D8 File Offset: 0x000824D8
		public static bool WriteFile(string FilePath, Stream Stream)
		{
			bool result;
			try
			{
				if (!FilePath.Contains(":\\"))
				{
					FilePath = ModBase.Path + FilePath;
				}
				Directory.CreateDirectory(ModBase.GetPathFromFullPath(FilePath));
				using (FileStream fileStream = new FileStream(FilePath, FileMode.Create, FileAccess.Write))
				{
					byte[] array = new byte[16385];
					for (int i = Stream.Read(array, 0, 16384); i > 0; i = Stream.Read(array, 0, 16384))
					{
						if (i > 0)
						{
							fileStream.Write(array, 0, i);
						}
					}
					fileStream.Close();
				}
				result = true;
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "保存流出错", ModBase.LogLevel.Debug, "出现错误");
				result = false;
			}
			return result;
		}

		// Token: 0x06001371 RID: 4977 RVA: 0x000843A4 File Offset: 0x000825A4
		public static Encoding GetEncoding(string FilePath)
		{
			if (!FilePath.Contains(":\\"))
			{
				FilePath = ModBase.Path + FilePath;
			}
			return ModBase.GetEncoding(File.ReadAllBytes(FilePath));
		}

		// Token: 0x06001372 RID: 4978 RVA: 0x000843D8 File Offset: 0x000825D8
		public static Encoding GetEncoding(byte[] Bytes)
		{
			Encoding result;
			if (Bytes.Count<byte>() <= 2)
			{
				result = new UTF8Encoding(false);
			}
			else if (Bytes[0] >= 239)
			{
				if (Bytes[0] == 239 && Bytes[1] == 187)
				{
					result = new UTF8Encoding(true);
				}
				else if (Bytes[0] == 254 && Bytes[1] == 255)
				{
					result = Encoding.BigEndianUnicode;
				}
				else if (Bytes[0] == 255 && Bytes[1] == 254)
				{
					result = Encoding.Unicode;
				}
				else
				{
					result = Encoding.GetEncoding("GB18030");
				}
			}
			else
			{
				string @string = Encoding.UTF8.GetString(Bytes);
				char value = Encoding.UTF8.GetString(new byte[]
				{
					239,
					191,
					189
				}).ToCharArray()[0];
				if (@string.Contains(Conversions.ToString(value)))
				{
					result = Encoding.GetEncoding("GB18030");
				}
				else
				{
					result = new UTF8Encoding(false);
				}
			}
			return result;
		}

		// Token: 0x06001373 RID: 4979 RVA: 0x000844BC File Offset: 0x000826BC
		public static string DecodeBytes(byte[] Bytes)
		{
			int num = Bytes.Length;
			checked
			{
				string result;
				if (num < 3)
				{
					result = Encoding.UTF8.GetString(Bytes);
				}
				else if (Bytes[0] >= 239)
				{
					if (Bytes[0] == 239 && Bytes[1] == 187)
					{
						result = Encoding.UTF8.GetString(Bytes, 3, num - 3);
					}
					else if (Bytes[0] == 254 && Bytes[1] == 255)
					{
						result = Encoding.BigEndianUnicode.GetString(Bytes, 3, num - 3);
					}
					else if (Bytes[0] == 255 && Bytes[1] == 254)
					{
						result = Encoding.Unicode.GetString(Bytes, 3, num - 3);
					}
					else
					{
						result = Encoding.GetEncoding("GB18030").GetString(Bytes, 3, num - 3);
					}
				}
				else
				{
					string @string = Encoding.UTF8.GetString(Bytes);
					char value = Encoding.UTF8.GetString(new byte[]
					{
						239,
						191,
						189
					}).ToCharArray()[0];
					if (@string.Contains(Conversions.ToString(value)))
					{
						result = Encoding.GetEncoding("GB18030").GetString(Bytes);
					}
					else
					{
						result = @string;
					}
				}
				return result;
			}
		}

		// Token: 0x06001374 RID: 4980 RVA: 0x000845D4 File Offset: 0x000827D4
		public static string SelectAs(string Title, string FileName, string FileFilter = null, string DefaultDir = null)
		{
			string fileName;
			using (System.Windows.Forms.SaveFileDialog saveFileDialog = new System.Windows.Forms.SaveFileDialog())
			{
				saveFileDialog.AddExtension = true;
				saveFileDialog.AutoUpgradeEnabled = true;
				saveFileDialog.Title = Title;
				saveFileDialog.FileName = FileName;
				if (FileFilter != null)
				{
					saveFileDialog.Filter = FileFilter;
				}
				if (DefaultDir != null)
				{
					saveFileDialog.InitialDirectory = DefaultDir;
				}
				saveFileDialog.ShowDialog();
				fileName = saveFileDialog.FileName;
				ModBase.Log("[UI] 选择文件返回：" + fileName, ModBase.LogLevel.Normal, "出现错误");
			}
			return fileName;
		}

		// Token: 0x06001375 RID: 4981 RVA: 0x00084658 File Offset: 0x00082858
		public static string SelectFile(string FileFilter, string Title)
		{
			string fileName;
			using (System.Windows.Forms.OpenFileDialog openFileDialog = new System.Windows.Forms.OpenFileDialog())
			{
				openFileDialog.AddExtension = true;
				openFileDialog.AutoUpgradeEnabled = true;
				openFileDialog.CheckFileExists = true;
				openFileDialog.Filter = FileFilter;
				openFileDialog.Multiselect = false;
				openFileDialog.Title = Title;
				openFileDialog.ValidateNames = true;
				openFileDialog.ShowDialog();
				fileName = openFileDialog.FileName;
				ModBase.Log("[UI] 选择文件返回：" + fileName, ModBase.LogLevel.Normal, "出现错误");
			}
			return fileName;
		}

		// Token: 0x06001376 RID: 4982 RVA: 0x000846E0 File Offset: 0x000828E0
		public static string SelectFolder(string Title = "选择文件夹")
		{
			VistaFolderBrowserDialog vistaFolderBrowserDialog = new VistaFolderBrowserDialog
			{
				ShowNewFolderButton = true,
				RootFolder = Environment.SpecialFolder.Desktop,
				Description = Title,
				UseDescriptionForTitle = true
			};
			vistaFolderBrowserDialog.ShowDialog();
			string text = string.IsNullOrEmpty(vistaFolderBrowserDialog.SelectedPath) ? "" : (vistaFolderBrowserDialog.SelectedPath + (vistaFolderBrowserDialog.SelectedPath.EndsWith("\\") ? "" : "\\"));
			ModBase.Log("[UI] 选择文件夹返回：" + text, ModBase.LogLevel.Normal, "出现错误");
			return text;
		}

		// Token: 0x06001377 RID: 4983 RVA: 0x0008476C File Offset: 0x0008296C
		public static bool CheckPermission(string Path)
		{
			bool result;
			try
			{
				if (Operators.CompareString(Path, "", true) == 0)
				{
					result = false;
				}
				else
				{
					if (!Path.EndsWith("\\"))
					{
						Path += "\\";
					}
					if (!Path.EndsWith(":\\System Volume Information\\") && !Path.EndsWith(":\\$RECYCLE.BIN\\"))
					{
						if (!Directory.Exists(Path))
						{
							result = false;
						}
						else
						{
							string str = "CheckPermission" + Conversions.ToString(ModBase.GetUuid());
							if (File.Exists(Path + str))
							{
								File.Delete(Path + str);
							}
							File.Create(Path + str).Dispose();
							File.Delete(Path + str);
							result = true;
						}
					}
					else
					{
						result = false;
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "没有对文件夹 " + Path + " 的权限，请尝试以管理员权限运行 PCL", ModBase.LogLevel.Debug, "出现错误");
				result = false;
			}
			return result;
		}

		// Token: 0x06001378 RID: 4984 RVA: 0x00084864 File Offset: 0x00082A64
		public static void CheckPermissionWithException(string Path)
		{
			if (string.IsNullOrWhiteSpace(Path))
			{
				throw new ArgumentNullException("文件夹名不能为空！");
			}
			if (!Path.EndsWith("\\"))
			{
				Path += "\\";
			}
			if (!Directory.Exists(Path))
			{
				throw new DirectoryNotFoundException("文件夹不存在！");
			}
			if (File.Exists(Path + "CheckPermission"))
			{
				File.Delete(Path + "CheckPermission");
			}
			File.Create(Path + "CheckPermission").Dispose();
			File.Delete(Path + "CheckPermission");
		}

		// Token: 0x06001379 RID: 4985 RVA: 0x000848F8 File Offset: 0x00082AF8
		public static string smethod_0(string FilePath)
		{
			bool flag = false;
			checked
			{
				string result;
				for (;;)
				{
					try
					{
						StringBuilder stringBuilder = new StringBuilder();
						FileStream fileStream = new FileStream(FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
						byte[] array = new MD5CryptoServiceProvider().ComputeHash(fileStream);
						fileStream.Close();
						int num = array.Length - 1;
						for (int i = 0; i <= num; i++)
						{
							stringBuilder.Append(array[i].ToString("x2"));
						}
						result = stringBuilder.ToString();
						break;
					}
					catch (Exception ex)
					{
						if (flag)
						{
							ModBase.Log(ex, "获取文件 MD5 失败：" + FilePath, ModBase.LogLevel.Debug, "出现错误");
							result = "";
							break;
						}
						flag = true;
						ModBase.Log(ex, "获取文件 MD5 可重试失败：" + FilePath, ModBase.LogLevel.Normal, "出现错误");
						Thread.Sleep(ModBase.RandomInteger(200, 500));
					}
				}
				return result;
			}
		}

		// Token: 0x0600137A RID: 4986 RVA: 0x000849E8 File Offset: 0x00082BE8
		public static string smethod_1(string FilePath)
		{
			bool flag = false;
			checked
			{
				string result;
				for (;;)
				{
					try
					{
						FileStream fileStream = new FileStream(FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
						byte[] array = new SHA1CryptoServiceProvider().ComputeHash(fileStream);
						fileStream.Close();
						StringBuilder stringBuilder = new StringBuilder();
						int num = array.Length - 1;
						for (int i = 0; i <= num; i++)
						{
							stringBuilder.Append(array[i].ToString("x2"));
						}
						result = stringBuilder.ToString();
						break;
					}
					catch (Exception ex)
					{
						if (flag)
						{
							ModBase.Log(ex, "获取文件 SHA1 失败：" + FilePath, ModBase.LogLevel.Debug, "出现错误");
							result = "";
							break;
						}
						flag = true;
						ModBase.Log(ex, "获取文件 SHA1 可重试失败：" + FilePath, ModBase.LogLevel.Normal, "出现错误");
						Thread.Sleep(ModBase.RandomInteger(200, 500));
					}
				}
				return result;
			}
		}

		// Token: 0x0600137B RID: 4987 RVA: 0x00084AD8 File Offset: 0x00082CD8
		public static string smethod_2(Stream Stream)
		{
			checked
			{
				string result;
				try
				{
					byte[] array = new SHA1CryptoServiceProvider().ComputeHash(Stream);
					StringBuilder stringBuilder = new StringBuilder();
					int num = array.Length - 1;
					for (int i = 0; i <= num; i++)
					{
						stringBuilder.Append(array[i].ToString("x2"));
					}
					result = stringBuilder.ToString();
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "获取流 SHA1 失败", ModBase.LogLevel.Debug, "出现错误");
					result = "";
				}
				return result;
			}
		}

		// Token: 0x0600137C RID: 4988 RVA: 0x00084B68 File Offset: 0x00082D68
		public static bool ExtractFile(string CompressFilePath, string DestDirectory, Encoding Encode = null)
		{
			bool result;
			try
			{
				Directory.CreateDirectory(DestDirectory);
				if (!CompressFilePath.EndsWith(".zip") && !CompressFilePath.EndsWith(".jar"))
				{
					if (CompressFilePath.EndsWith(".gz"))
					{
						GZipStream gzipStream = new GZipStream(new FileStream(CompressFilePath, FileMode.Open, FileAccess.ReadWrite), CompressionMode.Decompress);
						FileStream fileStream = new FileStream(DestDirectory + ModBase.GetFileNameFromPath(CompressFilePath).ToLower().Replace(".tar", "").Replace(".gz", ""), FileMode.OpenOrCreate, FileAccess.Write);
						for (int num = gzipStream.ReadByte(); num != -1; num = gzipStream.ReadByte())
						{
							fileStream.WriteByte(checked((byte)num));
						}
						fileStream.Close();
						gzipStream.Close();
						result = true;
					}
					else
					{
						result = false;
					}
				}
				else
				{
					ZipFile.ExtractToDirectory(CompressFilePath, DestDirectory, Encode ?? Encoding.Default);
					result = true;
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "尝试解压文件失败", ModBase.LogLevel.Debug, "出现错误");
				result = false;
			}
			return result;
		}

		// Token: 0x0600137D RID: 4989 RVA: 0x00084C68 File Offset: 0x00082E68
		public static void DeleteDirectory(string Path, bool IgnoreIssue = false)
		{
			checked
			{
				if (Directory.Exists(Path))
				{
					foreach (string path in Directory.GetFiles(Path))
					{
						try
						{
							File.Delete(path);
						}
						catch (Exception ex)
						{
							if (!IgnoreIssue)
							{
								throw;
							}
							ModBase.Log(ex, "删除单个文件可忽略地失败", ModBase.LogLevel.Debug, "出现错误");
						}
					}
					string[] directories = Directory.GetDirectories(Path);
					for (int j = 0; j < directories.Length; j++)
					{
						ModBase.DeleteDirectory(directories[j], false);
					}
					try
					{
						Directory.Delete(Path, true);
					}
					catch (Exception ex2)
					{
						if (!IgnoreIssue)
						{
							throw;
						}
						ModBase.Log(ex2, "删除单个文件夹可忽略地失败", ModBase.LogLevel.Debug, "出现错误");
					}
				}
			}
		}

		// Token: 0x0600137E RID: 4990 RVA: 0x00084D38 File Offset: 0x00082F38
		public static List<FileInfo> EnumerateFiles(string Directory)
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(Directory);
			List<FileInfo> list = new List<FileInfo>();
			list.AddRange(directoryInfo.EnumerateFiles());
			try
			{
				foreach (DirectoryInfo directoryInfo2 in directoryInfo.EnumerateDirectories())
				{
					list.AddRange(ModBase.EnumerateFiles(directoryInfo2.FullName));
				}
			}
			finally
			{
				IEnumerator<DirectoryInfo> enumerator;
				if (enumerator != null)
				{
					enumerator.Dispose();
				}
			}
			return list;
		}

		// Token: 0x0600137F RID: 4991 RVA: 0x00084DAC File Offset: 0x00082FAC
		public static string GetString(Exception Ex, bool IsLine = true, bool ShowAllTrace = false)
		{
			string result;
			if (Ex == null)
			{
				result = "无可用错误信息！";
			}
			else
			{
				List<string> list = new List<string>();
				string fullName = Ex.GetType().FullName;
				if (!(Ex is TypeLoadException) && !(Ex is NotImplementedException) && !(Ex is TypeInitializationException))
				{
					if (Ex is UnauthorizedAccessException)
					{
						list.Add("PCL2 权限不足，请尝试右键 PCL2，选择以管理员身份运行");
					}
					else if (Ex is OutOfMemoryException)
					{
						list.Add("电脑运行内存不足，PCL2 无法继续运行");
					}
				}
				else
				{
					list.Add("系统环境存在问题，请尝试重装 .Net Framework 4.5 后再试");
				}
				if (IsLine)
				{
					if (Ex.InnerException == null)
					{
						if (list.Count == 0)
						{
							result = Ex.Message.Replace("\r\n", "\r").Replace("\n", "\r").Replace("\r\r", "\r").Replace("\r", " ");
						}
						else
						{
							result = list.First<string>();
						}
					}
					else
					{
						while (Ex != null)
						{
							list.Add(Ex.Message.Replace("\r\n", "\r").Replace("\n", "\r").Replace("\r\r", "\r").Replace("\r", " "));
							Ex = Ex.InnerException;
						}
						list.Reverse();
						result = ModBase.Join(list, " → ");
					}
				}
				else
				{
					List<string> list2 = new List<string>();
					while (Ex != null)
					{
						list.Add(Ex.Message.Replace("\r\n", "\r").Replace("\n", "\r").Replace("\r\r", "\r").Replace("\r", "\r\n"));
						if (Ex.StackTrace != null)
						{
							foreach (string text in Ex.StackTrace.Split(new char[]
							{
								'\r'
							}))
							{
								if (ShowAllTrace || text.ToLower().Contains("pcl"))
								{
									list2.Add(text.Replace("\r", string.Empty).Replace("\n", string.Empty));
								}
							}
						}
						Ex = Ex.InnerException;
					}
					result = ModBase.Join(list, "\r\nCaused By: ") + ((list2.Count > 0) ? ("\r\n" + ModBase.Join(list2, "\r\n")) : "") + ((Operators.CompareString(fullName, "System.Exception", true) == 0) ? "" : ("\r\n错误类型：" + fullName));
				}
			}
			return result;
		}

		// Token: 0x06001380 RID: 4992 RVA: 0x0000B4C7 File Offset: 0x000096C7
		public static string GetStringFromEnum(Enum EnumData)
		{
			return Enum.GetName(EnumData.GetType(), EnumData);
		}

		// Token: 0x06001381 RID: 4993 RVA: 0x0008502C File Offset: 0x0008322C
		public static string GetString(long FileSize)
		{
			checked
			{
				string result;
				if (FileSize < 1000L)
				{
					result = Conversions.ToString(FileSize) + " B";
				}
				else if (FileSize < 1024000L)
				{
					string text = Conversions.ToString(Math.Round((double)FileSize / 1024.0));
					result = Conversions.ToString(Math.Round((double)FileSize / 1024.0, (int)Math.Round(ModBase.MathRange((double)(3 - text.Length), 0.0, 2.0)))) + " K";
				}
				else if (FileSize < 1048576000L)
				{
					string text2 = Conversions.ToString(Math.Round((double)FileSize / 1024.0 / 1024.0));
					result = Conversions.ToString(Math.Round((double)FileSize / 1024.0 / 1024.0, (int)Math.Round(ModBase.MathRange((double)(3 - text2.Length), 0.0, 2.0)))) + " M";
				}
				else
				{
					string text3 = Conversions.ToString(Math.Round((double)FileSize / 1024.0 / 1024.0 / 1024.0));
					result = Conversions.ToString(Math.Round((double)FileSize / 1024.0 / 1024.0 / 1024.0, (int)Math.Round(ModBase.MathRange((double)(3 - text3.Length), 0.0, 2.0)))) + " G";
				}
				return result;
			}
		}

		// Token: 0x06001382 RID: 4994 RVA: 0x0000B4D5 File Offset: 0x000096D5
		public static object GetJson(string Data)
		{
			return JsonConvert.DeserializeObject(Data, new JsonSerializerSettings
			{
				DateTimeZoneHandling = 0
			});
		}

		// Token: 0x06001383 RID: 4995 RVA: 0x000851D4 File Offset: 0x000833D4
		public static string StrFill(string Str, string Code, byte Length)
		{
			string result;
			if (Str.Length > (int)Length)
			{
				result = Strings.Mid(Str, 1, (int)Length);
			}
			else
			{
				result = Strings.Mid(Str.PadRight((int)Length, Conversions.ToChar(Code)), checked(Str.Length + 1)) + Str;
			}
			return result;
		}

		// Token: 0x06001384 RID: 4996 RVA: 0x00085218 File Offset: 0x00083418
		public static string StrFillNum(double Num, int Length)
		{
			Num = Math.Round(Num, Length, MidpointRounding.AwayFromZero);
			string text = Conversions.ToString(Num);
			checked
			{
				if (!text.Contains("."))
				{
					text = (text + ".").PadRight(text.Length + 1 + Length, '0');
				}
				else
				{
					text = text.PadRight(text.Split(new char[]
					{
						'.'
					})[0].Length + 1 + Length, '0');
				}
				return text;
			}
		}

		// Token: 0x06001385 RID: 4997 RVA: 0x00085288 File Offset: 0x00083488
		public static object StrTrim(string Str, bool RemoveQuote = true)
		{
			if (RemoveQuote)
			{
				Str = Str.Split(new char[]
				{
					'（'
				})[0].Split(new char[]
				{
					'：'
				})[0].Split(new char[]
				{
					'('
				})[0].Split(new char[]
				{
					':'
				})[0];
			}
			return Str.Trim(new char[]
			{
				'.',
				'。',
				'！',
				' ',
				'!',
				'?',
				'？',
				'\r',
				'\n'
			});
		}

		// Token: 0x06001386 RID: 4998 RVA: 0x00085304 File Offset: 0x00083504
		public static string Join(ICollection List, string Split)
		{
			StringBuilder stringBuilder = new StringBuilder();
			checked
			{
				int num = List.Count - 1;
				int num2 = num;
				for (int i = 0; i <= num2; i++)
				{
					if (List.Cast<object>().ElementAtOrDefault(i) != null)
					{
						stringBuilder.Append(RuntimeHelpers.GetObjectValue(List.Cast<object>().ElementAtOrDefault(i)));
					}
					if (i != num)
					{
						stringBuilder.Append(Split);
					}
				}
				return stringBuilder.ToString();
			}
		}

		// Token: 0x06001387 RID: 4999 RVA: 0x00085368 File Offset: 0x00083568
		public static ulong GetHash(string Str)
		{
			ulong num = 5381UL;
			checked
			{
				int num2 = Str.Length - 1;
				for (int i = 0; i <= num2; i++)
				{
					num = (num << 5 ^ num ^ (ulong)Str[i]);
				}
				return num ^ 12218072394304324399UL;
			}
		}

		// Token: 0x06001388 RID: 5000 RVA: 0x000853B0 File Offset: 0x000835B0
		public static string GetStringMD5(string Str)
		{
			byte[] array = new MD5CryptoServiceProvider().ComputeHash(Encoding.GetEncoding("gb2312").GetBytes(Str));
			StringBuilder stringBuilder = new StringBuilder();
			foreach (byte b in array)
			{
				stringBuilder.Append(b.ToString("x2"));
			}
			return stringBuilder.ToString();
		}

		// Token: 0x06001389 RID: 5001 RVA: 0x0000B4E9 File Offset: 0x000096E9
		public static double Val(object Str)
		{
			if (Str is string && Operators.ConditionalCompareObjectEqual(Str, "&", true))
			{
				return 0.0;
			}
			return Conversion.Val(RuntimeHelpers.GetObjectValue(Str));
		}

		// Token: 0x0600138A RID: 5002 RVA: 0x0008540C File Offset: 0x0008360C
		public static string smethod_3(string Str)
		{
			return Str.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("'", "&apos;").Replace("\"", "&quot;");
		}

		// Token: 0x0600138B RID: 5003 RVA: 0x00085468 File Offset: 0x00083668
		public static List<string> RegexSearch(string str, string regex, RegexOptions options = RegexOptions.None)
		{
			List<string> list;
			try
			{
				list = new List<string>();
				MatchCollection matchCollection = new Regex(regex, options).Matches(str);
				if (matchCollection == null)
				{
					list = list;
				}
				else
				{
					try
					{
						foreach (object obj in matchCollection)
						{
							Match match = (Match)obj;
							list.Add(match.Value);
						}
					}
					finally
					{
						IEnumerator enumerator;
						if (enumerator is IDisposable)
						{
							(enumerator as IDisposable).Dispose();
						}
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "正则匹配全部项出错", ModBase.LogLevel.Debug, "出现错误");
				list = new List<string>();
			}
			return list;
		}

		// Token: 0x0600138C RID: 5004 RVA: 0x00085518 File Offset: 0x00083718
		public static string RegexSeek(string str, string regex, RegexOptions options = RegexOptions.None)
		{
			string result;
			try
			{
				string value = Regex.Match(str, regex, options).Value;
				result = ((Operators.CompareString(value, "", true) == 0) ? null : value);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "正则匹配第一项出错", ModBase.LogLevel.Debug, "出现错误");
				result = null;
			}
			return result;
		}

		// Token: 0x0600138D RID: 5005 RVA: 0x0008557C File Offset: 0x0008377C
		public static bool RegexCheck(string str, string regex, RegexOptions options = RegexOptions.None)
		{
			bool result;
			try
			{
				result = Regex.IsMatch(str, regex, options);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "正则检查出错", ModBase.LogLevel.Debug, "出现错误");
				result = false;
			}
			return result;
		}

		// Token: 0x0600138E RID: 5006 RVA: 0x0000B516 File Offset: 0x00009716
		public static string RegexReplace(string Input, string Replacement, string Regex, RegexOptions options = RegexOptions.None)
		{
			return Regex.Replace(Input, Regex, Replacement, options);
		}

		// Token: 0x0600138F RID: 5007 RVA: 0x000855C8 File Offset: 0x000837C8
		private static string CancelTag(string info)
		{
			string result;
			if (string.IsNullOrEmpty(info))
			{
				result = "@;$ Abv2";
			}
			else
			{
				result = Strings.Mid(ModBase.StrFill(Conversions.ToString(ModBase.GetHash(info)), "X", 8), 1, 8);
			}
			return result;
		}

		// Token: 0x06001390 RID: 5008 RVA: 0x00085604 File Offset: 0x00083804
		public static string PostTag(string first, string caller = "")
		{
			caller = ModBase.CancelTag(caller);
			byte[] bytes = Encoding.UTF8.GetBytes(caller);
			byte[] bytes2 = Encoding.UTF8.GetBytes("95168702");
			DESCryptoServiceProvider descryptoServiceProvider = new DESCryptoServiceProvider();
			string result;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				byte[] bytes3 = Encoding.UTF8.GetBytes(first);
				using (CryptoStream cryptoStream = new CryptoStream(memoryStream, descryptoServiceProvider.CreateEncryptor(bytes, bytes2), CryptoStreamMode.Write))
				{
					cryptoStream.Write(bytes3, 0, bytes3.Length);
					cryptoStream.FlushFinalBlock();
					result = Convert.ToBase64String(memoryStream.ToArray());
				}
			}
			return result;
		}

		// Token: 0x06001391 RID: 5009 RVA: 0x000856BC File Offset: 0x000838BC
		public static string RevertTag(string init, string pol = "")
		{
			pol = ModBase.CancelTag(pol);
			byte[] bytes = Encoding.UTF8.GetBytes(pol);
			byte[] bytes2 = Encoding.UTF8.GetBytes("95168702");
			DESCryptoServiceProvider descryptoServiceProvider = new DESCryptoServiceProvider();
			string @string;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				byte[] array = Convert.FromBase64String(init);
				using (CryptoStream cryptoStream = new CryptoStream(memoryStream, descryptoServiceProvider.CreateDecryptor(bytes, bytes2), CryptoStreamMode.Write))
				{
					cryptoStream.Write(array, 0, array.Length);
					cryptoStream.FlushFinalBlock();
					@string = Encoding.UTF8.GetString(memoryStream.ToArray());
				}
			}
			return @string;
		}

		// Token: 0x06001392 RID: 5010 RVA: 0x00085774 File Offset: 0x00083974
		public static bool FillComparator(string config, string cont)
		{
			bool result;
			try
			{
				RSACryptoServiceProvider rsacryptoServiceProvider = new RSACryptoServiceProvider(512);
				rsacryptoServiceProvider.FromXmlString(ModBase._InfoState.Replace("!", "").Replace("$", "+") + "/R1Frckd3/Sn+Zsx9aD6U2f" + Conversions.ToString(Math.Round(84m)) + "SdWMDlrRY9DfhQ==</Modulus><Exponent>AQAB<\\Exponent><\\RSAKeyValue>".Replace("\\", "/"));
				result = rsacryptoServiceProvider.VerifyData(Encoding.Default.GetBytes(config), typeof(SHA256), Convert.FromBase64String(cont));
			}
			catch (Exception ex)
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06001393 RID: 5011 RVA: 0x00085830 File Offset: 0x00083A30
		private static double SearchSimilarity(string Source, string Query)
		{
			int i = 0;
			double num = 0.0;
			Source = Source.ToLower().Replace(" ", "");
			Query = Query.ToLower().Replace(" ", "");
			int length = Source.Length;
			int length2 = Query.Length;
			checked
			{
				while (i < Query.Length)
				{
					int j = 0;
					int num2 = 0;
					int num3 = 0;
					while (j < Source.Length)
					{
						int num4 = 0;
						while (i + num4 < Query.Length && j + num4 < Source.Length)
						{
							if (Source[j + num4] != Query[i + num4])
							{
								break;
							}
							num4++;
						}
						if (num4 > num2)
						{
							num2 = num4;
							num3 = j;
						}
						j += Math.Max(1, num4);
					}
					if (num2 > 0)
					{
						Source = Source.Substring(0, num3) + ((Source.Count<char>() > num3 + num2) ? Source.Substring(num3 + num2) : string.Empty);
						unchecked
						{
							double num5 = Math.Pow(1.4, (double)(checked(3 + num2))) - 3.6;
							num5 *= 1.0 + 0.3 * (double)Math.Max(0, checked(3 - Math.Abs(i - num3)));
							num += num5;
						}
					}
					i += Math.Max(1, num2);
				}
			}
			return num / (double)length2 * (3.0 / Math.Pow((double)(checked(length + 15)), 0.5)) * (double)((length2 <= 2) ? checked(3 - length2) : 1);
		}

		// Token: 0x06001394 RID: 5012 RVA: 0x000859C0 File Offset: 0x00083BC0
		private static double SearchSimilarityWeighted(List<KeyValuePair<string, double>> Source, string Query)
		{
			double num = 0.0;
			double num2 = 0.0;
			try
			{
				foreach (KeyValuePair<string, double> keyValuePair in Source)
				{
					num2 += ModBase.SearchSimilarity(keyValuePair.Key, Query) * keyValuePair.Value;
					num += keyValuePair.Value;
				}
			}
			finally
			{
				List<KeyValuePair<string, double>>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			return num2 / num;
		}

		// Token: 0x06001395 RID: 5013 RVA: 0x00085A40 File Offset: 0x00083C40
		public static List<ModBase.SearchEntry<T>> Search<T>(List<ModBase.SearchEntry<T>> Entries, string Query, int MaxBlurCount = 5, double MinBlurSimilarity = 0.1)
		{
			List<ModBase.SearchEntry<T>> list = new List<ModBase.SearchEntry<T>>();
			checked
			{
				List<ModBase.SearchEntry<T>> result;
				if (Entries.Count == 0)
				{
					result = list;
				}
				else
				{
					try
					{
						foreach (ModBase.SearchEntry<T> searchEntry in Entries)
						{
							searchEntry.serverParameter = ModBase.SearchSimilarityWeighted(searchEntry.m_RefParameter, Query);
							searchEntry.serviceParameter = false;
							try
							{
								foreach (KeyValuePair<string, double> keyValuePair in searchEntry.m_RefParameter)
								{
									if (keyValuePair.Key.ToLower().Replace(" ", "").Contains(Query.ToLower().Replace(" ", "")))
									{
										searchEntry.serviceParameter = true;
									}
								}
							}
							finally
							{
								List<KeyValuePair<string, double>>.Enumerator enumerator2;
								((IDisposable)enumerator2).Dispose();
							}
						}
					}
					finally
					{
						List<ModBase.SearchEntry<T>>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
					Entries = ModBase.Sort<ModBase.SearchEntry<T>>(Entries, (ModBase._Closure$__93<T>.$IR93-1 == null) ? (ModBase._Closure$__93<T>.$IR93-1 = ((object a0, object a1) => ((ModBase._Closure$__93<$CLS0>.$I93-0 == null) ? (ModBase._Closure$__93<$CLS0>.$I93-0 = delegate(ModBase.SearchEntry<$CLS0> Left, ModBase.SearchEntry<$CLS0> Right)
					{
						bool result2;
						if (Left.serviceParameter ^ Right.serviceParameter)
						{
							result2 = Left.serviceParameter;
						}
						else
						{
							result2 = (Left.serverParameter > Right.serverParameter);
						}
						return result2;
					}) : ModBase._Closure$__93<$CLS0>.$I93-0)((ModBase.SearchEntry<$CLS0>)a0, (ModBase.SearchEntry<$CLS0>)a1))) : ModBase._Closure$__93<T>.$IR93-1);
					int num = 0;
					try
					{
						foreach (ModBase.SearchEntry<T> searchEntry2 in Entries)
						{
							if (searchEntry2.serviceParameter)
							{
								list.Add(searchEntry2);
							}
							else
							{
								if (searchEntry2.serverParameter < MinBlurSimilarity)
								{
									break;
								}
								if (num == MaxBlurCount)
								{
									break;
								}
								list.Add(searchEntry2);
								num++;
							}
						}
					}
					finally
					{
						List<ModBase.SearchEntry<T>>.Enumerator enumerator3;
						((IDisposable)enumerator3).Dispose();
					}
					result = list;
				}
				return result;
			}
		}

		// Token: 0x06001396 RID: 5014 RVA: 0x00085BDC File Offset: 0x00083DDC
		public static bool IsAdmin()
		{
			WindowsIdentity current = WindowsIdentity.GetCurrent();
			return new WindowsPrincipal(current).IsInRole(WindowsBuiltInRole.Administrator);
		}

		// Token: 0x06001397 RID: 5015 RVA: 0x00085C00 File Offset: 0x00083E00
		public static bool RerunAsAdmin(string Argument)
		{
			bool result;
			try
			{
				Process.Start(new ProcessStartInfo(ModBase.m_CodeState)
				{
					Verb = "runas",
					Arguments = Argument
				});
				result = true;
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "以管理员权限运行程序失败", ModBase.LogLevel.Debug, "出现错误");
				result = false;
			}
			return result;
		}

		// Token: 0x06001398 RID: 5016 RVA: 0x00085C68 File Offset: 0x00083E68
		public static int GetUuid()
		{
			if (ModBase.propertyState == null)
			{
				ModBase.propertyState = RuntimeHelpers.GetObjectValue(new object());
			}
			object obj = ModBase.propertyState;
			ObjectFlowControl.CheckForSyncLockOnValueType(obj);
			checked
			{
				int decoratorState;
				lock (obj)
				{
					ModBase._DecoratorState++;
					decoratorState = ModBase._DecoratorState;
				}
				return decoratorState;
			}
		}

		// Token: 0x06001399 RID: 5017 RVA: 0x00085CD0 File Offset: 0x00083ED0
		public static List<T> GetFullList<T>(IList data)
		{
			List<T> list = new List<T>();
			checked
			{
				int num = data.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (data[i] is ICollection)
					{
						list.AddRange((IEnumerable<T>)data[i]);
					}
					else
					{
						list.Add(Conversions.ToGenericParameter<T>(data[i]));
					}
				}
				return list;
			}
		}

		// Token: 0x0600139A RID: 5018 RVA: 0x00085D30 File Offset: 0x00083F30
		public static T[] ArrayNoDouble<T>(T[] Arr, ModBase.CompareThreadStart IsEqual = null)
		{
			List<T> list = new List<T>();
			int num = Information.UBound(Arr, 1);
			int i = 0;
			IL_87:
			checked
			{
				while (i <= num)
				{
					int num2 = i + 1;
					int num3 = Information.UBound(Arr, 1);
					int j = num2;
					while (j <= num3)
					{
						if (IsEqual == null)
						{
							if (Arr[i].Equals(Arr[j]))
							{
								goto IL_83;
							}
						}
						else if (IsEqual(Arr[i], Arr[j]))
						{
							goto IL_83;
						}
						j++;
						continue;
						IL_83:
						i++;
						goto IL_87;
					}
					list.Add(Arr[i]);
					goto IL_83;
				}
				return list.ToArray();
			}
		}

		// Token: 0x0600139B RID: 5019 RVA: 0x00085DD0 File Offset: 0x00083FD0
		public static List<T> ArrayNoDouble<T>(List<T> Arr, ModBase.CompareThreadStart IsEqual = null)
		{
			List<T> list = new List<T>();
			checked
			{
				int num = Arr.Count - 1;
				int i = 0;
				IL_8B:
				while (i <= num)
				{
					int num2 = i + 1;
					int num3 = Arr.Count - 1;
					int j = num2;
					while (j <= num3)
					{
						if (IsEqual == null)
						{
							T t = Arr[i];
							if (t.Equals(Arr[j]))
							{
								goto IL_87;
							}
						}
						else if (IsEqual(Arr[i], Arr[j]))
						{
							goto IL_87;
						}
						j++;
						continue;
						IL_87:
						i++;
						goto IL_8B;
					}
					list.Add(Arr[i]);
					goto IL_87;
				}
				return list;
			}
		}

		// Token: 0x0600139C RID: 5020 RVA: 0x0000B521 File Offset: 0x00009721
		public static void DictionaryAdd<TKey, TValue>(ref Dictionary<TKey, TValue> Dict, TKey Key, TValue Value)
		{
			if (Dict.ContainsKey(Key))
			{
				Dict[Key] = Value;
				return;
			}
			Dict.Add(Key, Value);
		}

		// Token: 0x0600139D RID: 5021 RVA: 0x00085E70 File Offset: 0x00084070
		public static string GetTimeNow()
		{
			return DateTime.Now.ToString("HH:mm:ss.fff");
		}

		// Token: 0x0600139E RID: 5022 RVA: 0x0000B540 File Offset: 0x00009740
		public static long GetTimeTick()
		{
			return checked(unchecked((long)MyWpfExtension.FindModel().Clock.TickCount) + 2147483651L);
		}

		// Token: 0x0600139F RID: 5023 RVA: 0x00085E90 File Offset: 0x00084090
		public static string GetTimeSpanString(TimeSpan Span)
		{
			string str = (Span.TotalMilliseconds > 0.0) ? "后" : "前";
			if (Span.TotalMilliseconds < 0.0)
			{
				Span = -Span;
			}
			double num = Math.Floor((double)Span.Days / 30.0);
			string str2;
			if (num >= 61.0)
			{
				str2 = Conversions.ToString(Math.Floor(num / 12.0)) + " 年";
			}
			else if (num >= 12.0)
			{
				str2 = Conversions.ToString(Math.Floor(num / 12.0)) + " 年" + ((num % 12.0 > 0.0) ? (" " + Conversions.ToString(num % 12.0) + " 个月") : "");
			}
			else if (num >= 4.0)
			{
				str2 = Conversions.ToString(num) + " 月";
			}
			else if (num >= 1.0)
			{
				str2 = Conversions.ToString(num) + " 月" + ((Span.Days % 30 > 0) ? (" " + Conversions.ToString(Span.Days % 30) + " 天") : "");
			}
			else if (Span.TotalDays >= 4.0)
			{
				str2 = Conversions.ToString(Span.Days) + " 天";
			}
			else if (Span.TotalDays >= 1.0)
			{
				str2 = Conversions.ToString(Span.Days) + " 天" + ((Span.Hours > 0) ? (" " + Conversions.ToString(Span.Hours) + " 小时") : "");
			}
			else if (Span.TotalHours >= 10.0)
			{
				str2 = Conversions.ToString(Span.Hours) + " 小时";
			}
			else if (Span.TotalHours >= 1.0)
			{
				str2 = Conversions.ToString(Span.Hours) + " 小时" + ((Span.Minutes > 0) ? (" " + Conversions.ToString(Span.Minutes) + " 分钟") : "");
			}
			else if (Span.TotalMinutes >= 10.0)
			{
				str2 = Conversions.ToString(Span.Minutes) + " 分钟";
			}
			else if (Span.TotalMinutes >= 1.0)
			{
				str2 = Conversions.ToString(Span.Minutes) + " 分" + ((Span.Seconds > 0) ? (" " + Conversions.ToString(Span.Seconds) + " 秒") : "");
			}
			else if (Span.TotalSeconds >= 1.0)
			{
				str2 = Conversions.ToString(Span.Seconds) + " 秒";
			}
			else
			{
				str2 = "1 秒";
			}
			return str2 + str;
		}

		// Token: 0x060013A0 RID: 5024 RVA: 0x000861D4 File Offset: 0x000843D4
		public static long GetUnixTimestamp()
		{
			return checked((long)Math.Round((double)(DateAndTime.Now.ToUniversalTime().Ticks - 621355968000000000L) / 10000000.0));
		}

		// Token: 0x060013A1 RID: 5025 RVA: 0x00086214 File Offset: 0x00084414
		public static object GetCdnTypeA(string UrlWithMark)
		{
			object result;
			if (!UrlWithMark.EndsWith("{CDN}"))
			{
				result = UrlWithMark;
			}
			else
			{
				string text = UrlWithMark.Replace("{CDN}", "").Replace(" ", "%20");
				string text2 = ModBase.StrFill(ModBase.RandomInteger(0, 2147483645).ToString("x"), "0", 8);
				string text3 = ModBase.RevertTag("VwHB1je1uabAr0gKijpFaQ==", "CDN");
				string text4 = Conversions.ToString(ModBase.GetUnixTimestamp());
				string text5 = text.Substring(checked(text.IndexOf("://") + 3));
				text5 = text5.Substring(text5.IndexOf("/"));
				string stringMD = ModBase.GetStringMD5(ModBase.Join(new string[]
				{
					text5,
					text4,
					text2,
					"0",
					text3
				}, "-"));
				result = text + "?sign=" + ModBase.Join(new string[]
				{
					text4,
					text2,
					"0",
					stringMD
				}, "-");
			}
			return result;
		}

		// Token: 0x060013A2 RID: 5026 RVA: 0x00086324 File Offset: 0x00084524
		public static ModBase.Result ShellAndGetExitCode(string FileName, string Arguments = "", bool WaitForExit = false, int Timeout = 1000000)
		{
			ModBase.Result result;
			try
			{
				using (Process process = new Process())
				{
					process.StartInfo.Arguments = Arguments;
					process.StartInfo.FileName = FileName;
					ModBase.Log("[System] 执行外部命令并等待返回码：" + FileName + " " + Arguments, ModBase.LogLevel.Normal, "出现错误");
					process.Start();
					if (WaitForExit)
					{
						if (process.WaitForExit(Timeout))
						{
							result = (ModBase.Result)process.ExitCode;
						}
						else
						{
							result = ModBase.Result.Timeout;
						}
					}
					else
					{
						result = ModBase.Result.Success;
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "执行命令失败：" + FileName, ModBase.LogLevel.Msgbox, "出现错误");
				result = ModBase.Result.Fail;
			}
			return result;
		}

		// Token: 0x060013A3 RID: 5027 RVA: 0x000863E0 File Offset: 0x000845E0
		public static string ShellAndGetOutput(string FileName, string Arguments = "", int Timeout = 1000000, string WorkingDirectory = null)
		{
			ProcessStartInfo processStartInfo = new ProcessStartInfo
			{
				Arguments = Arguments,
				FileName = FileName,
				UseShellExecute = false,
				CreateNoWindow = true,
				RedirectStandardError = true,
				RedirectStandardOutput = true,
				WorkingDirectory = (WorkingDirectory ?? ModBase.Path.TrimEnd(new char[]
				{
					'\\'
				}))
			};
			if (WorkingDirectory != null)
			{
				if (processStartInfo.EnvironmentVariables.ContainsKey("appdata"))
				{
					processStartInfo.EnvironmentVariables["appdata"] = WorkingDirectory;
				}
				else
				{
					processStartInfo.EnvironmentVariables.Add("appdata", WorkingDirectory);
				}
			}
			ModBase.Log("[System] 执行外部命令并等待返回结果：" + FileName + " " + Arguments, ModBase.LogLevel.Normal, "出现错误");
			string result;
			using (Process process = new Process
			{
				StartInfo = processStartInfo
			})
			{
				process.Start();
				process.WaitForExit(Timeout);
				result = process.StandardOutput.ReadToEnd() + process.StandardError.ReadToEnd();
			}
			return result;
		}

		// Token: 0x060013A4 RID: 5028 RVA: 0x000864EC File Offset: 0x000846EC
		public static Thread RunInNewThread(Action Action, string Name, ThreadPriority Priority = ThreadPriority.Normal)
		{
			Thread thread = new Thread(delegate()
			{
				try
				{
					Action();
				}
				catch (ThreadInterruptedException ex)
				{
					ModBase.Log(Name + "：线程已中止", ModBase.LogLevel.Normal, "出现错误");
				}
				catch (Exception ex2)
				{
					ModBase.Log(ex2, Name + "：线程执行失败", ModBase.LogLevel.Feedback, "出现错误");
				}
			});
			thread.Name = Name;
			thread.Priority = Priority;
			thread.Start();
			return thread;
		}

		// Token: 0x060013A5 RID: 5029 RVA: 0x0000B55C File Offset: 0x0000975C
		public static void RunInUiWait(Action Action)
		{
			if (ModBase.RunInUi())
			{
				Action();
				return;
			}
			System.Windows.Application.Current.Dispatcher.Invoke(Action);
		}

		// Token: 0x060013A6 RID: 5030 RVA: 0x0000B57C File Offset: 0x0000977C
		public static void RunInUi(Action Action, bool ForceWaitUntilLoaded = false)
		{
			if (ForceWaitUntilLoaded)
			{
				System.Windows.Application.Current.Dispatcher.InvokeAsync(Action, DispatcherPriority.Loaded);
				return;
			}
			if (ModBase.RunInUi())
			{
				Action();
				return;
			}
			System.Windows.Application.Current.Dispatcher.InvokeAsync(Action);
		}

		// Token: 0x060013A7 RID: 5031 RVA: 0x0000B5B3 File Offset: 0x000097B3
		public static void RunInThread(Action Action)
		{
			if (ModBase.RunInUi())
			{
				ModBase.RunInNewThread(Action, "Runtime Invoke " + Conversions.ToString(ModBase.GetUuid()) + "#", ThreadPriority.Normal);
				return;
			}
			Action();
		}

		// Token: 0x060013A8 RID: 5032 RVA: 0x00086538 File Offset: 0x00084738
		public static string GetUniqueAddress()
		{
			string result;
			try
			{
				string str;
				try
				{
					using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(new SelectQuery(ModBase.RevertTag("pzch4Ldn3GgLX7tf2sKI72+QG9RuUJ7iXQzuJT4UBjeFf0TBzZ/YmY6syXOWGqMw", ""))))
					{
						str = NewLateBinding.LateIndexGet(managementObjectSearcher.Get().Cast<object>().ElementAtOrDefault(0), new object[]
						{
							"Uuid"
						}, null).ToString();
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "获取主板标识码失败", ModBase.LogLevel.Debug, "出现错误");
					str = "Unknown";
				}
				string text;
				try
				{
					text = Conversions.ToString(ModBase._ParamsState.Get("Identify", null));
				}
				catch (Exception ex2)
				{
					text = "";
				}
				if (text.Length < 3)
				{
					text = Conversions.ToString(ModBase.GetTimeTick()) + Conversions.ToString(MyWpfExtension.FindModel().Info.AvailablePhysicalMemory);
					ModBase._ParamsState.Set("Identify", text, false, null);
				}
				string text2 = ModBase.StrFill(ModBase.GetHash(str + text).ToString("X"), "7", 16);
				text2 = string.Concat(new string[]
				{
					Strings.Mid(text2, 5, 4),
					"-",
					Strings.Mid(text2, 13, 4),
					"-",
					Strings.Mid(text2, 1, 4),
					"-",
					Strings.Mid(text2, 9, 4)
				});
				result = text2;
			}
			catch (Exception ex3)
			{
				ModBase.Log(ex3, "PCL 无法获取设备标识码，这可能会导致部分设置无法正常存储。\r\n\r\n详细的错误信息", ModBase.LogLevel.Feedback, "获取标识码失败");
				result = "0000-0000-0000-0000";
			}
			return result;
		}

		// Token: 0x060013A9 RID: 5033 RVA: 0x00086738 File Offset: 0x00084938
		public static List<T> Sort<T>(IList<T> List, ModBase.CompareThreadStart SortRule)
		{
			List<T> list = new List<T>();
			checked
			{
				while (List.Count > 0)
				{
					T t = List[0];
					int num = List.Count - 1;
					for (int i = 1; i <= num; i++)
					{
						if (SortRule(List[i], t))
						{
							t = List[i];
						}
					}
					List.Remove(t);
					list.Add(t);
				}
				return list;
			}
		}

		// Token: 0x060013AA RID: 5034 RVA: 0x000867A8 File Offset: 0x000849A8
		public static object GetProgramArgument(string Name, object DefaultValue = "")
		{
			string[] array = Interaction.Command().Split(new char[]
			{
				' '
			});
			checked
			{
				int num = array.Length - 1;
				for (int i = 0; i <= num; i++)
				{
					if (Operators.CompareString(array[i], "-" + Name, true) == 0)
					{
						object result;
						if (array.Length != i + 1 && !array[i + 1].StartsWith("-"))
						{
							result = array[i + 1];
						}
						else
						{
							result = true;
						}
						return result;
					}
				}
				return DefaultValue;
			}
		}

		// Token: 0x060013AB RID: 5035 RVA: 0x00086820 File Offset: 0x00084A20
		public static DateTime GetDate(int timeStamp)
		{
			DateTime dateTime = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc));
			long ticks = checked(unchecked((long)timeStamp) * 10000000L);
			return dateTime.Add(new TimeSpan(ticks));
		}

		// Token: 0x060013AC RID: 5036 RVA: 0x00086864 File Offset: 0x00084A64
		public static DateTime GetLocalTime(DateTime UtcDate)
		{
			return DateTime.SpecifyKind(UtcDate, DateTimeKind.Utc).ToLocalTime();
		}

		// Token: 0x060013AD RID: 5037 RVA: 0x00086880 File Offset: 0x00084A80
		public static void OpenWebsite(string Url)
		{
			try
			{
				ModBase.Log("[System] 正在打开网页：" + Url, ModBase.LogLevel.Normal, "出现错误");
				Process.Start(Url);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "无法打开网页（" + Url + "）", ModBase.LogLevel.Debug, "出现错误");
				ModBase.ClipboardSet(Url, false);
				ModMain.MyMsgBox("可能由于浏览器未正确配置，PCL2 无法为你打开网页。\r\n网址已经复制到剪贴板，若有需要可以手动粘贴访问。", "无法打开网页", "确定", "", "", false, true, false);
			}
		}

		// Token: 0x060013AE RID: 5038 RVA: 0x00086910 File Offset: 0x00084B10
		public static void OpenExplorer(string Argument)
		{
			try
			{
				Process.Start("explorer.exe", Argument);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "打开资源管理器失败，请尝试关闭安全软件（如 360 安全卫士）", ModBase.LogLevel.Msgbox, "出现错误");
			}
		}

		// Token: 0x060013AF RID: 5039 RVA: 0x0008695C File Offset: 0x00084B5C
		public static void ClipboardSet(string Text, bool ShowSuccessHint = true)
		{
			ModBase._Closure$__123-0 CS$<>8__locals1 = new ModBase._Closure$__123-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Local_Text = Text;
			CS$<>8__locals1.$VB$Local_ShowSuccessHint = ShowSuccessHint;
			ModBase.RunInThread(checked(delegate
			{
				int num = 0;
				for (;;)
				{
					try
					{
						ModBase.RunInUi((CS$<>8__locals1.$I1 == null) ? (CS$<>8__locals1.$I1 = delegate()
						{
							MyWpfExtension.FindModel().Clipboard.Clear();
							MyWpfExtension.FindModel().Clipboard.SetText(CS$<>8__locals1.$VB$Local_Text);
						}) : CS$<>8__locals1.$I1, false);
						break;
					}
					catch (Exception ex)
					{
						num++;
						if (num > 5)
						{
							ModBase.Log(ex, "可能由于剪贴板被其他程序占用，文本复制失败", ModBase.LogLevel.Hint, "出现错误");
							break;
						}
						Thread.Sleep(20);
					}
				}
				if (CS$<>8__locals1.$VB$Local_ShowSuccessHint)
				{
					ModMain.Hint("已成功复制！", ModMain.HintType.Finish, true);
				}
			}));
		}

		// Token: 0x060013B0 RID: 5040 RVA: 0x0000B5E4 File Offset: 0x000097E4
		public static byte[] GetResources(string ResourceName)
		{
			ModBase.Log("[System] 获取资源：" + ResourceName, ModBase.LogLevel.Normal, "出现错误");
			return (byte[])Resources.TestModel.GetObject(ResourceName);
		}

		// Token: 0x060013B1 RID: 5041 RVA: 0x00086990 File Offset: 0x00084B90
		public static void DeltaLeft(FrameworkElement control, double newValue)
		{
			ModBase.DebugAssert(!double.IsNaN(newValue));
			ModBase.DebugAssert(!double.IsInfinity(newValue));
			if (control is Window)
			{
				Window window;
				(window = (Window)control).Left = window.Left + newValue;
				return;
			}
			switch (control.HorizontalAlignment)
			{
			case System.Windows.HorizontalAlignment.Left:
			case System.Windows.HorizontalAlignment.Stretch:
				control.Margin = new Thickness(control.Margin.Left + newValue, control.Margin.Top, control.Margin.Right, control.Margin.Bottom);
				return;
			default:
				ModBase.DebugAssert(false);
				return;
			case System.Windows.HorizontalAlignment.Right:
				control.Margin = new Thickness(control.Margin.Left, control.Margin.Top, control.Margin.Right - newValue, control.Margin.Bottom);
				return;
			}
		}

		// Token: 0x060013B2 RID: 5042 RVA: 0x00086A88 File Offset: 0x00084C88
		public static void SetLeft(FrameworkElement control, double newValue)
		{
			ModBase.DebugAssert(control.HorizontalAlignment == System.Windows.HorizontalAlignment.Left);
			control.Margin = new Thickness(newValue, control.Margin.Top, control.Margin.Right, control.Margin.Bottom);
		}

		// Token: 0x060013B3 RID: 5043 RVA: 0x00086ADC File Offset: 0x00084CDC
		public static void DeltaTop(FrameworkElement control, double newValue)
		{
			ModBase.DebugAssert(!double.IsNaN(newValue));
			ModBase.DebugAssert(!double.IsInfinity(newValue));
			if (control is Window)
			{
				Window window;
				(window = (Window)control).Top = window.Top + newValue;
				return;
			}
			VerticalAlignment verticalAlignment = control.VerticalAlignment;
			if (verticalAlignment == VerticalAlignment.Top)
			{
				control.Margin = new Thickness(control.Margin.Left, control.Margin.Top + newValue, control.Margin.Right, control.Margin.Bottom);
				return;
			}
			if (verticalAlignment != VerticalAlignment.Bottom)
			{
				ModBase.DebugAssert(false);
				return;
			}
			control.Margin = new Thickness(control.Margin.Left, control.Margin.Top, control.Margin.Right, control.Margin.Bottom - newValue);
		}

		// Token: 0x060013B4 RID: 5044 RVA: 0x00086BC4 File Offset: 0x00084DC4
		public static void SetTop(FrameworkElement control, double newValue)
		{
			ModBase.DebugAssert(control.VerticalAlignment == VerticalAlignment.Top);
			control.Margin = new Thickness(control.Margin.Left, newValue, control.Margin.Right, control.Margin.Bottom);
		}

		// Token: 0x060013B5 RID: 5045 RVA: 0x0000B60C File Offset: 0x0000980C
		public static double GetPixelSize(double WPFSize)
		{
			return WPFSize / 96.0 * (double)ModBase.m_DescriptorState;
		}

		// Token: 0x060013B6 RID: 5046 RVA: 0x0000B620 File Offset: 0x00009820
		public static double smethod_4(double PixelSize)
		{
			return PixelSize * 96.0 / (double)ModBase.m_DescriptorState;
		}

		// Token: 0x060013B7 RID: 5047 RVA: 0x00086C18 File Offset: 0x00084E18
		public static ImageBrush ControlBrush(FrameworkElement UI)
		{
			double actualWidth = UI.ActualWidth;
			double actualHeight = UI.ActualHeight;
			ImageBrush result;
			if (actualWidth >= 1.0 && actualHeight >= 1.0)
			{
				RenderTargetBitmap renderTargetBitmap = checked(new RenderTargetBitmap((int)Math.Round(ModBase.GetPixelSize(actualWidth)), (int)Math.Round(ModBase.GetPixelSize(actualHeight)), (double)ModBase.m_DescriptorState, (double)ModBase.m_DescriptorState, PixelFormats.Pbgra32));
				renderTargetBitmap.Render(UI);
				result = new ImageBrush(renderTargetBitmap);
			}
			else
			{
				result = new ImageBrush();
			}
			return result;
		}

		// Token: 0x060013B8 RID: 5048 RVA: 0x00086C94 File Offset: 0x00084E94
		public static ImageBrush ControlBrush(FrameworkElement UI, double Width, double Height, double Left = 0.0, double Top = 0.0)
		{
			UI.Measure(new System.Windows.Size(Width, Height));
			UI.Arrange(new Rect(0.0, 0.0, Width, Height));
			RenderTargetBitmap renderTargetBitmap = checked(new RenderTargetBitmap((int)Math.Round(ModBase.GetPixelSize(Width)), (int)Math.Round(ModBase.GetPixelSize(Height)), (double)ModBase.m_DescriptorState, (double)ModBase.m_DescriptorState, PixelFormats.Default));
			renderTargetBitmap.Render(UI);
			if (Left != 0.0 || Top != 0.0)
			{
				UI.Arrange(new Rect(Left, Top, Width, Height));
			}
			return new ImageBrush(renderTargetBitmap);
		}

		// Token: 0x060013B9 RID: 5049 RVA: 0x0000B634 File Offset: 0x00009834
		public static void ControlFreeze(System.Windows.Controls.Panel UI)
		{
			UI.Background = ModBase.ControlBrush(UI);
			UI.Children.Clear();
		}

		// Token: 0x060013BA RID: 5050 RVA: 0x0000B64D File Offset: 0x0000984D
		public static void ControlFreeze(Border UI)
		{
			UI.Background = ModBase.ControlBrush(UI);
			UI.Child = null;
		}

		// Token: 0x060013BB RID: 5051 RVA: 0x00086D34 File Offset: 0x00084F34
		public static object GetObjectFromXML(XElement Str)
		{
			object result;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				using (StreamWriter streamWriter = new StreamWriter(memoryStream))
				{
					streamWriter.Write(Str.ToString());
					streamWriter.Flush();
					memoryStream.Position = 0L;
					result = XamlReader.Load(memoryStream);
				}
			}
			return result;
		}

		// Token: 0x060013BC RID: 5052 RVA: 0x00086DAC File Offset: 0x00084FAC
		public static object GetObjectFromXML(string Str)
		{
			object result;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				using (StreamWriter streamWriter = new StreamWriter(memoryStream))
				{
					streamWriter.Write(Str);
					streamWriter.Flush();
					memoryStream.Position = 0L;
					result = XamlReader.Load(memoryStream);
				}
			}
			return result;
		}

		// Token: 0x060013BD RID: 5053 RVA: 0x0000B662 File Offset: 0x00009862
		public static bool RunInUi()
		{
			return Thread.CurrentThread.ManagedThreadId == ModBase._MapState;
		}

		// Token: 0x060013BE RID: 5054 RVA: 0x0000B675 File Offset: 0x00009875
		public static void LogStart()
		{
			ModBase.RunInNewThread((ModBase._Closure$__.$I145-0 == null) ? (ModBase._Closure$__.$I145-0 = delegate()
			{
				bool flag = true;
				try
				{
					if (File.Exists(ModBase.Path + "PCL\\Log4.txt"))
					{
						if (File.Exists(ModBase.Path + "PCL\\Log5.txt"))
						{
							File.Delete(ModBase.Path + "PCL\\Log5.txt");
						}
						File.Copy(ModBase.Path + "PCL\\Log4.txt", ModBase.Path + "PCL\\Log5.txt");
					}
					if (File.Exists(ModBase.Path + "PCL\\Log3.txt"))
					{
						if (File.Exists(ModBase.Path + "PCL\\Log4.txt"))
						{
							File.Delete(ModBase.Path + "PCL\\Log4.txt");
						}
						File.Copy(ModBase.Path + "PCL\\Log3.txt", ModBase.Path + "PCL\\Log4.txt");
					}
					if (File.Exists(ModBase.Path + "PCL\\Log2.txt"))
					{
						if (File.Exists(ModBase.Path + "PCL\\Log3.txt"))
						{
							File.Delete(ModBase.Path + "PCL\\Log3.txt");
						}
						File.Copy(ModBase.Path + "PCL\\Log2.txt", ModBase.Path + "PCL\\Log3.txt");
					}
					if (File.Exists(ModBase.Path + "PCL\\Log1.txt"))
					{
						if (File.Exists(ModBase.Path + "PCL\\Log2.txt"))
						{
							File.Delete(ModBase.Path + "PCL\\Log2.txt");
						}
						File.Copy(ModBase.Path + "PCL\\Log1.txt", ModBase.Path + "PCL\\Log2.txt");
					}
					File.Create(ModBase.Path + "PCL\\Log1.txt").Dispose();
				}
				catch (Exception ex)
				{
					flag = false;
					ModMain.Hint("可能同时开启了多个 PCL2，程序可能会出现未知问题！", ModMain.HintType.Critical, true);
					ModBase.Log(ex, "日志初始化失败", ModBase.LogLevel.Debug, "出现错误");
				}
				try
				{
					ModBase.publisherState = new StreamWriter(ModBase.Path + "PCL\\Log1.txt", true)
					{
						AutoFlush = true
					};
					goto IL_239;
				}
				catch (Exception ex2)
				{
					ModBase.publisherState = null;
					ModBase.Log(ex2, "日志写入失败", ModBase.LogLevel.Hint, "出现错误");
					goto IL_239;
				}
				IL_21F:
				ModBase.poolState = new StringBuilder();
				IL_229:
				Thread.Sleep(50);
				IL_239:
				if (flag)
				{
					ModBase.LogFlush();
					goto IL_229;
				}
				goto IL_21F;
			}) : ModBase._Closure$__.$I145-0, "Log Writer", ThreadPriority.Lowest);
		}

		// Token: 0x060013BF RID: 5055 RVA: 0x00086E1C File Offset: 0x0008501C
		public static void LogFlush()
		{
			int num;
			int num4;
			object obj;
			try
			{
				IL_00:
				ProjectData.ClearProjectError();
				num = 1;
				IL_07:
				int num2 = 2;
				if (ModBase.publisherState == null)
				{
					goto IL_72;
				}
				IL_10:
				num2 = 4;
				string text = null;
				IL_14:
				num2 = 5;
				object watcherState = ModBase.m_WatcherState;
				ObjectFlowControl.CheckForSyncLockOnValueType(watcherState);
				lock (watcherState)
				{
					if (ModBase.poolState.Length > 0)
					{
						StringBuilder stringBuilder = ModBase.poolState;
						ModBase.poolState = new StringBuilder();
						text = stringBuilder.ToString();
					}
				}
				IL_60:
				num2 = 6;
				if (text == null)
				{
					goto IL_72;
				}
				IL_65:
				num2 = 7;
				ModBase.publisherState.Write(text);
				IL_72:
				goto IL_E1;
				IL_74:
				int num3 = num4 + 1;
				num4 = 0;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
				IL_A2:
				goto IL_D6;
				IL_A4:
				num4 = num2;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
				IL_B4:;
			}
			catch when (endfilter(obj is Exception & num != 0 & num4 == 0))
			{
				Exception ex = (Exception)obj2;
				goto IL_A4;
			}
			IL_D6:
			throw ProjectData.CreateProjectError(-2146828237);
			IL_E1:
			if (num4 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		// Token: 0x060013C0 RID: 5056 RVA: 0x00086F30 File Offset: 0x00085130
		public static void Log(string Text, ModBase.LogLevel Level = ModBase.LogLevel.Normal, string Title = "出现错误")
		{
			int num;
			int num4;
			object obj2;
			try
			{
				IL_00:
				ProjectData.ClearProjectError();
				num = 1;
				IL_07:
				int num2 = 2;
				string value = string.Concat(new string[]
				{
					"[",
					ModBase.GetTimeNow(),
					"] ",
					Text,
					"\r\n"
				});
				IL_39:
				num2 = 3;
				if (!ModBase._EventState)
				{
					goto IL_78;
				}
				IL_42:
				num2 = 4;
				object obj = ModBase.testState;
				ObjectFlowControl.CheckForSyncLockOnValueType(obj);
				lock (obj)
				{
					ModBase.poolState.Append(value);
					goto IL_86;
				}
				IL_78:
				num2 = 6;
				ModBase.poolState.Append(value);
				IL_86:
				num2 = 7;
				if (ModBase.m_SystemState || Level == ModBase.LogLevel.Normal)
				{
					goto IL_20A;
				}
				IL_98:
				num2 = 9;
				Text = ModBase.RegexReplace(Text, "", "\\[[^\\]]+?\\] ", RegexOptions.None);
				IL_AE:
				num2 = 10;
				switch (Level)
				{
				case ModBase.LogLevel.Debug:
					IL_DB:
					num2 = 13;
					if (!ModBase._EventState)
					{
						break;
					}
					IL_E8:
					num2 = 14;
					ModMain.Hint("[调试模式] " + Text, ModMain.HintType.Info, false);
					break;
				case ModBase.LogLevel.Hint:
					IL_102:
					num2 = 16;
					ModBase.m_AlgoState = true;
					IL_10B:
					num2 = 17;
					ModMain.Hint(Text, ModMain.HintType.Critical, false);
					break;
				case ModBase.LogLevel.Msgbox:
					IL_11B:
					num2 = 19;
					ModBase.m_AlgoState = true;
					IL_124:
					num2 = 20;
					ModMain.MyMsgBox(Text, Title, "确定", "", "", false, true, false);
					break;
				case ModBase.LogLevel.Feedback:
					IL_146:
					num2 = 22;
					ModBase.m_AlgoState = true;
					IL_14F:
					num2 = 23;
					if (ModMain.MyMsgBox(Text + "\r\n\r\n是否反馈此问题？如果不反馈，这个问题可能永远无法得到解决！", Title, "反馈", "取消", "", false, true, false) != 1)
					{
						break;
					}
					IL_17B:
					num2 = 24;
					ModBase.Feedback("exlog", false, true);
					break;
				case ModBase.LogLevel.Assert:
				{
					IL_18C:
					num2 = 26;
					ModBase.m_AlgoState = true;
					IL_195:
					num2 = 27;
					long timeTick = ModBase.GetTimeTick();
					IL_19F:
					num2 = 28;
					if (Interaction.MsgBox(Text + "\r\n\r\n是否反馈此问题？如果不反馈，这个问题可能永远无法得到解决！", MsgBoxStyle.YesNo | MsgBoxStyle.Critical, Title) != MsgBoxResult.Yes)
					{
						goto IL_1C7;
					}
					IL_1B8:
					num2 = 29;
					ModBase.Feedback("exlog", false, true);
					IL_1C7:
					num2 = 30;
					if (checked(ModBase.GetTimeTick() - timeTick) >= 1500L)
					{
						goto IL_201;
					}
					IL_1DD:
					num2 = 31;
					ModBase.Log("[System] PCL 已崩溃：\r\n" + Text, ModBase.LogLevel.Normal, "出现错误");
					IL_1F6:
					num2 = 32;
					FormMain.EndProgramForce(ModBase.Result.Exception);
					break;
					IL_201:
					num2 = 34;
					FormMain.EndProgramForce(ModBase.Result.Fail);
					break;
				}
				}
				IL_20A:
				goto IL_2EC;
				IL_20F:
				int num3 = num4 + 1;
				num4 = 0;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
				IL_2AD:
				goto IL_2E1;
				IL_2AF:
				num4 = num2;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
				IL_2BF:;
			}
			catch when (endfilter(obj2 is Exception & num != 0 & num4 == 0))
			{
				Exception ex = (Exception)obj3;
				goto IL_2AF;
			}
			IL_2E1:
			throw ProjectData.CreateProjectError(-2146828237);
			IL_2EC:
			if (num4 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		// Token: 0x060013C1 RID: 5057 RVA: 0x00087268 File Offset: 0x00085468
		public static void Log(Exception Ex, string Desc, ModBase.LogLevel Level = ModBase.LogLevel.Debug, string Title = "出现错误")
		{
			int num;
			int num4;
			object obj2;
			try
			{
				IL_00:
				ProjectData.ClearProjectError();
				num = 1;
				IL_07:
				int num2 = 2;
				if (Ex is ThreadInterruptedException)
				{
					goto IL_241;
				}
				IL_14:
				num2 = 4;
				ModBase.m_AlgoState = true;
				IL_1C:
				num2 = 5;
				string text = Desc + "：" + ModBase.GetString(Ex, false, false);
				IL_32:
				num2 = 6;
				string value = string.Concat(new string[]
				{
					"[",
					ModBase.GetTimeNow(),
					"] ",
					Desc,
					"：",
					ModBase.GetString(Ex, false, true),
					"\r\n"
				});
				IL_78:
				num2 = 7;
				if (!ModBase._EventState)
				{
					goto IL_B8;
				}
				IL_81:
				num2 = 8;
				object obj = ModBase.testState;
				ObjectFlowControl.CheckForSyncLockOnValueType(obj);
				lock (obj)
				{
					ModBase.poolState.Append(value);
					goto IL_C8;
				}
				IL_B8:
				num2 = 10;
				ModBase.poolState.Append(value);
				IL_C8:
				num2 = 11;
				if (ModBase.m_SystemState)
				{
					goto IL_241;
				}
				IL_D5:
				num2 = 13;
				switch (Level)
				{
				case ModBase.LogLevel.Debug:
				{
					IL_104:
					num2 = 17;
					string str = Desc + "：" + ModBase.GetString(Ex, true, false);
					IL_11C:
					num2 = 18;
					if (!ModBase._EventState)
					{
						break;
					}
					IL_129:
					num2 = 19;
					ModMain.Hint("[调试模式] " + str, ModMain.HintType.Info, false);
					break;
				}
				case ModBase.LogLevel.Hint:
				{
					IL_144:
					num2 = 21;
					string text2 = Desc + "：" + ModBase.GetString(Ex, true, false);
					IL_15C:
					num2 = 22;
					ModMain.Hint(text2, ModMain.HintType.Critical, false);
					break;
				}
				case ModBase.LogLevel.Msgbox:
					IL_16D:
					num2 = 24;
					ModMain.MyMsgBox(text, Title, "确定", "", "", false, true, false);
					break;
				case ModBase.LogLevel.Feedback:
					IL_18F:
					num2 = 26;
					if (ModMain.MyMsgBox(text + "\r\n\r\n是否反馈此问题？如果不反馈，这个问题可能永远无法得到解决！", Title, "反馈", "取消", "", false, true, false) != 1)
					{
						break;
					}
					IL_1BB:
					num2 = 27;
					ModBase.Feedback("exlog", false, true);
					break;
				case ModBase.LogLevel.Assert:
				{
					IL_1CC:
					num2 = 29;
					long timeTick = ModBase.GetTimeTick();
					IL_1D6:
					num2 = 30;
					if (Interaction.MsgBox(text + "\r\n\r\n是否反馈此问题？如果不反馈，这个问题可能永远无法得到解决！", MsgBoxStyle.YesNo | MsgBoxStyle.Critical, Title) != MsgBoxResult.Yes)
					{
						goto IL_1FE;
					}
					IL_1EF:
					num2 = 31;
					ModBase.Feedback("exlog", false, true);
					IL_1FE:
					num2 = 32;
					if (checked(ModBase.GetTimeTick() - timeTick) >= 1500L)
					{
						goto IL_238;
					}
					IL_214:
					num2 = 33;
					ModBase.Log("[System] PCL 已崩溃：\r\n" + text, ModBase.LogLevel.Normal, "出现错误");
					IL_22D:
					num2 = 34;
					FormMain.EndProgramForce(ModBase.Result.Exception);
					break;
					IL_238:
					num2 = 36;
					FormMain.EndProgramForce(ModBase.Result.Fail);
					break;
				}
				}
				IL_241:
				goto IL_32B;
				IL_246:
				int num3 = num4 + 1;
				num4 = 0;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
				IL_2EC:
				goto IL_320;
				IL_2EE:
				num4 = num2;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
				IL_2FE:;
			}
			catch when (endfilter(obj2 is Exception & num != 0 & num4 == 0))
			{
				Exception ex = (Exception)obj3;
				goto IL_2EE;
			}
			IL_320:
			throw ProjectData.CreateProjectError(-2146828237);
			IL_32B:
			if (num4 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		// Token: 0x060013C2 RID: 5058 RVA: 0x000875DC File Offset: 0x000857DC
		public static void Feedback(string Source, bool ShowMsgbox = true, bool ForceOpenLog = false)
		{
			int num;
			int num4;
			object obj;
			try
			{
				IL_00:
				ProjectData.ClearProjectError();
				num = 1;
				IL_07:
				int num2 = 2;
				ModBase.FeedbackInfo();
				IL_0E:
				num2 = 3;
				if (!ForceOpenLog && (!ShowMsgbox || ModMain.MyMsgBox("若你在汇报一个 Bug，请点击 打开文件夹 按钮，并上传 Log(1~5).txt 中包含错误信息的文件。\r\n游戏崩溃一般与启动器无关，请不要因为游戏崩溃而提交反馈。", "反馈提交提醒", "打开文件夹", "不需要", "", false, true, false) != 1))
				{
					goto IL_55;
				}
				IL_3A:
				num2 = 4;
				ModBase.OpenExplorer("\"" + ModBase.Path + "PCL\\\"");
				IL_55:
				num2 = 5;
				ModBase.OpenWebsite("https://jinshuju.net/f/rP4b6E?x_field_1=" + Source);
				IL_67:
				num2 = 6;
				if (!Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("HintFeedback", null), "", true))
				{
					goto IL_9E;
				}
				IL_86:
				num2 = 7;
				ModBase._ParamsState.Set("HintFeedback", "/", false, null);
				IL_9E:
				goto IL_10D;
				IL_A0:
				int num3 = num4 + 1;
				num4 = 0;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
				IL_CE:
				goto IL_102;
				IL_D0:
				num4 = num2;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
				IL_E0:;
			}
			catch when (endfilter(obj is Exception & num != 0 & num4 == 0))
			{
				Exception ex = (Exception)obj2;
				goto IL_D0;
			}
			IL_102:
			throw ProjectData.CreateProjectError(-2146828237);
			IL_10D:
			if (num4 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		// Token: 0x060013C3 RID: 5059 RVA: 0x00087710 File Offset: 0x00085910
		public static void FeedbackInfo()
		{
			int num;
			int num4;
			object obj;
			try
			{
				IL_00:
				ProjectData.ClearProjectError();
				num = 1;
				IL_07:
				int num2 = 2;
				ModBase.Log(string.Concat(new string[]
				{
					"[System] 诊断信息：\r\n操作系统：",
					MyWpfExtension.FindModel().Info.OSFullName,
					"\r\n剩余内存：",
					Conversions.ToString(Conversion.Int(MyWpfExtension.FindModel().Info.AvailablePhysicalMemory / 1024.0 / 1024.0)),
					" M / ",
					Conversions.ToString(Conversion.Int(MyWpfExtension.FindModel().Info.TotalPhysicalMemory / 1024.0 / 1024.0)),
					" M\r\nDPI：",
					Conversions.ToString(ModBase.m_DescriptorState),
					"（",
					Conversions.ToString(Math.Round((double)ModBase.m_DescriptorState / 96.0, 2) * 100.0),
					"%）\r\n文件位置：",
					ModBase.Path
				}), ModBase.LogLevel.Normal, "出现错误");
				IL_106:
				goto IL_161;
				IL_108:
				int num3 = num4 + 1;
				num4 = 0;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
				IL_122:
				goto IL_156;
				IL_124:
				num4 = num2;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
				IL_134:;
			}
			catch when (endfilter(obj is Exception & num != 0 & num4 == 0))
			{
				Exception ex = (Exception)obj2;
				goto IL_124;
			}
			IL_156:
			throw ProjectData.CreateProjectError(-2146828237);
			IL_161:
			if (num4 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		// Token: 0x060013C4 RID: 5060 RVA: 0x0000B6A7 File Offset: 0x000098A7
		public static void DebugAssert(bool Exp)
		{
			if (!Exp)
			{
				throw new Exception("断言命中");
			}
		}

		// Token: 0x060013C5 RID: 5061 RVA: 0x0000B6B7 File Offset: 0x000098B7
		public static object RandomOne(Array objects)
		{
			return objects.GetValue(ModBase.RandomInteger(0, checked(objects.Length - 1)));
		}

		// Token: 0x060013C6 RID: 5062 RVA: 0x0000B6CD File Offset: 0x000098CD
		public static object RandomOne(IList objects)
		{
			return objects[ModBase.RandomInteger(0, checked(objects.Count - 1))];
		}

		// Token: 0x060013C7 RID: 5063 RVA: 0x0000B6E3 File Offset: 0x000098E3
		public static int RandomInteger(int min, int max)
		{
			return checked((int)Math.Round(unchecked(Math.Floor((double)(checked(max - min + 1)) * ModBase.m_TaskState.NextDouble()) + (double)min)));
		}

		// Token: 0x060013C8 RID: 5064 RVA: 0x000878A4 File Offset: 0x00085AA4
		public static IList<T> RandomChaos<T>(IList<T> array)
		{
			IList<T> list = new List<T>();
			while (array.Count > 0)
			{
				int index = ModBase.RandomInteger(0, checked(array.Count - 1));
				list.Add(array[index]);
				array.RemoveAt(index);
			}
			return list;
		}

		// Token: 0x040009F2 RID: 2546
		public static IntPtr containerState;

		// Token: 0x040009F3 RID: 2547
		public static string Path = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;

		// Token: 0x040009F4 RID: 2548
		public static string m_CodeState = ModBase.Path + AppDomain.CurrentDomain.SetupInformation.ApplicationName;

		// Token: 0x040009F5 RID: 2549
		public static string _TokenizerState = "pack://application:,,,/images/";

		// Token: 0x040009F6 RID: 2550
		public static string m_DefinitionState = "zh_CN";

		// Token: 0x040009F7 RID: 2551
		public static ModSetup _ParamsState = new ModSetup();

		// Token: 0x040009F8 RID: 2552
		public static long _MockState;

		// Token: 0x040009F9 RID: 2553
		public static DateTime adapterState = DateTime.Now;

		// Token: 0x040009FA RID: 2554
		public static string initializerState = ModBase.GetUniqueAddress();

		// Token: 0x040009FB RID: 2555
		public static bool m_SystemState = false;

		// Token: 0x040009FC RID: 2556
		public static bool m_WriterState = !Environment.Is64BitOperatingSystem;

		// Token: 0x040009FD RID: 2557
		public static Version broadcasterState = Environment.OSVersion.Version;

		// Token: 0x040009FE RID: 2558
		public static string attributeState = (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("SystemSystemCache", null), "", true) ? (System.IO.Path.GetTempPath() + "PCL\\") : ModBase._ParamsState.Get("SystemSystemCache", null)).ToString().Replace("/", "\\").TrimEnd(new char[]
		{
			'\\'
		}) + "\\";

		// Token: 0x040009FF RID: 2559
		private static readonly Dictionary<string, ModBase.IniCache> _SpecificationState = new Dictionary<string, ModBase.IniCache>();

		// Token: 0x04000A00 RID: 2560
		public static char m_PredicateState = Convert.ToChar(8220);

		// Token: 0x04000A01 RID: 2561
		public static char _ClientState = Convert.ToChar(8221);

		// Token: 0x04000A02 RID: 2562
		public static string _InfoState = "<RS!AKeyValu!e><Mo!dul!us>0L/cZoJUyBRAIE8OKiG8$qYOytXD$azFCBsmOuQra";

		// Token: 0x04000A03 RID: 2563
		private static int _DecoratorState = 1;

		// Token: 0x04000A04 RID: 2564
		private static object propertyState;

		// Token: 0x04000A05 RID: 2565
		public static readonly int m_DescriptorState = checked((int)Math.Round((double)Graphics.FromHwnd(IntPtr.Zero).DpiX));

		// Token: 0x04000A06 RID: 2566
		private static readonly int _MapState = Thread.CurrentThread.ManagedThreadId;

		// Token: 0x04000A07 RID: 2567
		public static bool _EventState = false;

		// Token: 0x04000A08 RID: 2568
		public static bool m_AlgoState = false;

		// Token: 0x04000A09 RID: 2569
		private static StringBuilder poolState = new StringBuilder();

		// Token: 0x04000A0A RID: 2570
		private static StreamWriter publisherState;

		// Token: 0x04000A0B RID: 2571
		private static readonly object m_WatcherState = RuntimeHelpers.GetObjectValue(new object());

		// Token: 0x04000A0C RID: 2572
		private static readonly object testState = RuntimeHelpers.GetObjectValue(new object());

		// Token: 0x04000A0D RID: 2573
		private static readonly Random m_TaskState = new Random();

		// Token: 0x020001A5 RID: 421
		public class Logo
		{
		}

		// Token: 0x020001A6 RID: 422
		public class MyColor
		{
			// Token: 0x060013CB RID: 5067 RVA: 0x0000B704 File Offset: 0x00009904
			public static implicit operator ModBase.MyColor(string str)
			{
				return new ModBase.MyColor(str);
			}

			// Token: 0x060013CC RID: 5068 RVA: 0x0000B70C File Offset: 0x0000990C
			public static implicit operator ModBase.MyColor(System.Windows.Media.Color col)
			{
				return new ModBase.MyColor(col);
			}

			// Token: 0x060013CD RID: 5069 RVA: 0x0000B714 File Offset: 0x00009914
			public static implicit operator System.Windows.Media.Color(ModBase.MyColor conv)
			{
				return System.Windows.Media.Color.FromArgb(ModBase.MathByte(conv.m_StrategyParameter), ModBase.MathByte(conv.m_RulesParameter), ModBase.MathByte(conv.m_WorkerParameter), ModBase.MathByte(conv._DicParameter));
			}

			// Token: 0x060013CE RID: 5070 RVA: 0x0000B747 File Offset: 0x00009947
			public static implicit operator System.Drawing.Color(ModBase.MyColor conv)
			{
				return System.Drawing.Color.FromArgb((int)ModBase.MathByte(conv.m_StrategyParameter), (int)ModBase.MathByte(conv.m_RulesParameter), (int)ModBase.MathByte(conv.m_WorkerParameter), (int)ModBase.MathByte(conv._DicParameter));
			}

			// Token: 0x060013CF RID: 5071 RVA: 0x0000B77A File Offset: 0x0000997A
			public static implicit operator ModBase.MyColor(SolidColorBrush bru)
			{
				return new ModBase.MyColor(bru.Color);
			}

			// Token: 0x060013D0 RID: 5072 RVA: 0x0000B787 File Offset: 0x00009987
			public static implicit operator SolidColorBrush(ModBase.MyColor conv)
			{
				return new SolidColorBrush(System.Windows.Media.Color.FromArgb(ModBase.MathByte(conv.m_StrategyParameter), ModBase.MathByte(conv.m_RulesParameter), ModBase.MathByte(conv.m_WorkerParameter), ModBase.MathByte(conv._DicParameter)));
			}

			// Token: 0x060013D1 RID: 5073 RVA: 0x0000B7BF File Offset: 0x000099BF
			public static implicit operator ModBase.MyColor(System.Windows.Media.Brush bru)
			{
				return new ModBase.MyColor(bru);
			}

			// Token: 0x060013D2 RID: 5074 RVA: 0x0000B787 File Offset: 0x00009987
			public static implicit operator System.Windows.Media.Brush(ModBase.MyColor conv)
			{
				return new SolidColorBrush(System.Windows.Media.Color.FromArgb(ModBase.MathByte(conv.m_StrategyParameter), ModBase.MathByte(conv.m_RulesParameter), ModBase.MathByte(conv.m_WorkerParameter), ModBase.MathByte(conv._DicParameter)));
			}

			// Token: 0x060013D3 RID: 5075 RVA: 0x000878E8 File Offset: 0x00085AE8
			public static ModBase.MyColor operator +(ModBase.MyColor a, ModBase.MyColor b)
			{
				return new ModBase.MyColor
				{
					m_StrategyParameter = a.m_StrategyParameter + b.m_StrategyParameter,
					_DicParameter = a._DicParameter + b._DicParameter,
					m_WorkerParameter = a.m_WorkerParameter + b.m_WorkerParameter,
					m_RulesParameter = a.m_RulesParameter + b.m_RulesParameter
				};
			}

			// Token: 0x060013D4 RID: 5076 RVA: 0x00087948 File Offset: 0x00085B48
			public static ModBase.MyColor operator -(ModBase.MyColor a, ModBase.MyColor b)
			{
				return new ModBase.MyColor
				{
					m_StrategyParameter = a.m_StrategyParameter - b.m_StrategyParameter,
					_DicParameter = a._DicParameter - b._DicParameter,
					m_WorkerParameter = a.m_WorkerParameter - b.m_WorkerParameter,
					m_RulesParameter = a.m_RulesParameter - b.m_RulesParameter
				};
			}

			// Token: 0x060013D5 RID: 5077 RVA: 0x0000B7C7 File Offset: 0x000099C7
			public static ModBase.MyColor operator *(ModBase.MyColor a, double b)
			{
				return new ModBase.MyColor
				{
					m_StrategyParameter = a.m_StrategyParameter * b,
					_DicParameter = a._DicParameter * b,
					m_WorkerParameter = a.m_WorkerParameter * b,
					m_RulesParameter = a.m_RulesParameter * b
				};
			}

			// Token: 0x060013D6 RID: 5078 RVA: 0x0000B806 File Offset: 0x00009A06
			public static ModBase.MyColor operator /(ModBase.MyColor a, double b)
			{
				return new ModBase.MyColor
				{
					m_StrategyParameter = a.m_StrategyParameter / b,
					_DicParameter = a._DicParameter / b,
					m_WorkerParameter = a.m_WorkerParameter / b,
					m_RulesParameter = a.m_RulesParameter / b
				};
			}

			// Token: 0x060013D7 RID: 5079 RVA: 0x000879A8 File Offset: 0x00085BA8
			public static bool operator ==(ModBase.MyColor a, ModBase.MyColor b)
			{
				return (Information.IsNothing(a) && Information.IsNothing(b)) || (!Information.IsNothing(a) && !Information.IsNothing(b) && (a.m_StrategyParameter == b.m_StrategyParameter && a.m_RulesParameter == b.m_RulesParameter && a.m_WorkerParameter == b.m_WorkerParameter) && a._DicParameter == b._DicParameter);
			}

			// Token: 0x060013D8 RID: 5080 RVA: 0x00087A1C File Offset: 0x00085C1C
			public static bool operator !=(ModBase.MyColor a, ModBase.MyColor b)
			{
				return (!Information.IsNothing(a) || !Information.IsNothing(b)) && (Information.IsNothing(a) || Information.IsNothing(b) || a.m_StrategyParameter != b.m_StrategyParameter || a.m_RulesParameter != b.m_RulesParameter || a.m_WorkerParameter != b.m_WorkerParameter || a._DicParameter != b._DicParameter);
			}

			// Token: 0x060013D9 RID: 5081 RVA: 0x00087A94 File Offset: 0x00085C94
			public MyColor()
			{
				this.m_StrategyParameter = 255.0;
				this.m_RulesParameter = 0.0;
				this.m_WorkerParameter = 0.0;
				this._DicParameter = 0.0;
			}

			// Token: 0x060013DA RID: 5082 RVA: 0x00087AE4 File Offset: 0x00085CE4
			public MyColor(System.Windows.Media.Color col)
			{
				this.m_StrategyParameter = 255.0;
				this.m_RulesParameter = 0.0;
				this.m_WorkerParameter = 0.0;
				this._DicParameter = 0.0;
				this.m_StrategyParameter = (double)col.A;
				this.m_RulesParameter = (double)col.R;
				this.m_WorkerParameter = (double)col.G;
				this._DicParameter = (double)col.B;
			}

			// Token: 0x060013DB RID: 5083 RVA: 0x00087B6C File Offset: 0x00085D6C
			public MyColor(string HexString)
			{
				this.m_StrategyParameter = 255.0;
				this.m_RulesParameter = 0.0;
				this.m_WorkerParameter = 0.0;
				this._DicParameter = 0.0;
				object obj = System.Windows.Media.ColorConverter.ConvertFromString(HexString);
				System.Windows.Media.Color color = (obj != null) ? ((System.Windows.Media.Color)obj) : default(System.Windows.Media.Color);
				this.m_StrategyParameter = (double)color.A;
				this.m_RulesParameter = (double)color.R;
				this.m_WorkerParameter = (double)color.G;
				this._DicParameter = (double)color.B;
			}

			// Token: 0x060013DC RID: 5084 RVA: 0x00087C10 File Offset: 0x00085E10
			public MyColor(double newA, ModBase.MyColor col)
			{
				this.m_StrategyParameter = 255.0;
				this.m_RulesParameter = 0.0;
				this.m_WorkerParameter = 0.0;
				this._DicParameter = 0.0;
				this.m_StrategyParameter = newA;
				this.m_RulesParameter = col.m_RulesParameter;
				this.m_WorkerParameter = col.m_WorkerParameter;
				this._DicParameter = col._DicParameter;
			}

			// Token: 0x060013DD RID: 5085 RVA: 0x00087C8C File Offset: 0x00085E8C
			public MyColor(double newR, double newG, double newB)
			{
				this.m_StrategyParameter = 255.0;
				this.m_RulesParameter = 0.0;
				this.m_WorkerParameter = 0.0;
				this._DicParameter = 0.0;
				this.m_StrategyParameter = 255.0;
				this.m_RulesParameter = newR;
				this.m_WorkerParameter = newG;
				this._DicParameter = newB;
			}

			// Token: 0x060013DE RID: 5086 RVA: 0x00087D00 File Offset: 0x00085F00
			public MyColor(double newA, double newR, double newG, double newB)
			{
				this.m_StrategyParameter = 255.0;
				this.m_RulesParameter = 0.0;
				this.m_WorkerParameter = 0.0;
				this._DicParameter = 0.0;
				this.m_StrategyParameter = newA;
				this.m_RulesParameter = newR;
				this.m_WorkerParameter = newG;
				this._DicParameter = newB;
			}

			// Token: 0x060013DF RID: 5087 RVA: 0x00087D70 File Offset: 0x00085F70
			public MyColor(System.Windows.Media.Brush brush)
			{
				this.m_StrategyParameter = 255.0;
				this.m_RulesParameter = 0.0;
				this.m_WorkerParameter = 0.0;
				this._DicParameter = 0.0;
				System.Windows.Media.Color color = ((SolidColorBrush)brush).Color;
				this.m_StrategyParameter = (double)color.A;
				this.m_RulesParameter = (double)color.R;
				this.m_WorkerParameter = (double)color.G;
				this._DicParameter = (double)color.B;
			}

			// Token: 0x060013E0 RID: 5088 RVA: 0x00087E04 File Offset: 0x00086004
			public MyColor(SolidColorBrush brush)
			{
				this.m_StrategyParameter = 255.0;
				this.m_RulesParameter = 0.0;
				this.m_WorkerParameter = 0.0;
				this._DicParameter = 0.0;
				System.Windows.Media.Color color = brush.Color;
				this.m_StrategyParameter = (double)color.A;
				this.m_RulesParameter = (double)color.R;
				this.m_WorkerParameter = (double)color.G;
				this._DicParameter = (double)color.B;
			}

			// Token: 0x060013E1 RID: 5089 RVA: 0x00087E94 File Offset: 0x00086094
			public MyColor(object obj)
			{
				this.m_StrategyParameter = 255.0;
				this.m_RulesParameter = 0.0;
				this.m_WorkerParameter = 0.0;
				this._DicParameter = 0.0;
				if (obj == null)
				{
					this.m_StrategyParameter = 255.0;
					this.m_RulesParameter = 255.0;
					this.m_WorkerParameter = 255.0;
					this._DicParameter = 255.0;
					return;
				}
				if (obj is SolidColorBrush)
				{
					System.Windows.Media.Color color = ((SolidColorBrush)obj).Color;
					this.m_StrategyParameter = (double)color.A;
					this.m_RulesParameter = (double)color.R;
					this.m_WorkerParameter = (double)color.G;
					this._DicParameter = (double)color.B;
					return;
				}
				this.m_StrategyParameter = Conversions.ToDouble(NewLateBinding.LateGet(obj, null, "A", new object[0], null, null, null));
				this.m_RulesParameter = Conversions.ToDouble(NewLateBinding.LateGet(obj, null, "R", new object[0], null, null, null));
				this.m_WorkerParameter = Conversions.ToDouble(NewLateBinding.LateGet(obj, null, "G", new object[0], null, null, null));
				this._DicParameter = Conversions.ToDouble(NewLateBinding.LateGet(obj, null, "B", new object[0], null, null, null));
			}

			// Token: 0x060013E2 RID: 5090 RVA: 0x00087FF4 File Offset: 0x000861F4
			public double Hue(double v1, double v2, double vH)
			{
				if (vH < 0.0)
				{
					vH += 1.0;
				}
				if (vH > 1.0)
				{
					vH -= 1.0;
				}
				double result;
				if (vH < 0.16667)
				{
					result = v1 + (v2 - v1) * 6.0 * vH;
				}
				else if (vH < 0.5)
				{
					result = v2;
				}
				else if (vH < 0.66667)
				{
					result = v1 + (v2 - v1) * (4.0 - vH * 6.0);
				}
				else
				{
					result = v1;
				}
				return result;
			}

			// Token: 0x060013E3 RID: 5091 RVA: 0x00088090 File Offset: 0x00086290
			public ModBase.MyColor FromHSL(double sH, double sS, double sL)
			{
				if (sS == 0.0)
				{
					this.m_RulesParameter = sL * 2.55;
					this.m_WorkerParameter = this.m_RulesParameter;
					this._DicParameter = this.m_RulesParameter;
				}
				else
				{
					double num = sH / 360.0;
					double num2 = sS / 100.0;
					double num3 = sL / 100.0;
					num2 = ((num3 < 0.5) ? (num2 * num3 + num3) : (num2 * (1.0 - num3) + num3));
					num3 = 2.0 * num3 - num2;
					this.m_RulesParameter = 255.0 * this.Hue(num3, num2, num + 0.3333333333333333);
					this.m_WorkerParameter = 255.0 * this.Hue(num3, num2, num);
					this._DicParameter = 255.0 * this.Hue(num3, num2, num - 0.3333333333333333);
				}
				this.m_StrategyParameter = 255.0;
				return this;
			}

			// Token: 0x060013E4 RID: 5092 RVA: 0x0008819C File Offset: 0x0008639C
			public ModBase.MyColor FromHSL2(double sH, double sS, double sL)
			{
				if (sS == 0.0)
				{
					this.m_RulesParameter = sL * 2.55;
					this.m_WorkerParameter = this.m_RulesParameter;
					this._DicParameter = this.m_RulesParameter;
				}
				else
				{
					sH = (sH + 3600000.0) % 360.0;
					double[] array = new double[]
					{
						0.1,
						-0.06,
						-0.3,
						-0.19,
						-0.15,
						-0.24,
						-0.32,
						-0.09,
						0.18,
						0.05,
						-0.12,
						-0.02,
						0.1,
						-0.06
					};
					double num = sH / 30.0;
					int num2 = checked((int)Math.Floor(num));
					num = 50.0 - ((1.0 - num + (double)num2) * array[num2] + (num - (double)num2) * array[checked(num2 + 1)]) * sS;
					sL = ((sL < num) ? (sL / num) : (1.0 + (sL - num) / (100.0 - num))) * 50.0;
					this.FromHSL(sH, sS, sL);
				}
				this.m_StrategyParameter = 255.0;
				return this;
			}

			// Token: 0x060013E5 RID: 5093 RVA: 0x00088294 File Offset: 0x00086494
			public override string ToString()
			{
				return string.Concat(new string[]
				{
					"(",
					Conversions.ToString(this.m_StrategyParameter),
					",",
					Conversions.ToString(this.m_RulesParameter),
					",",
					Conversions.ToString(this.m_WorkerParameter),
					",",
					Conversions.ToString(this._DicParameter),
					")"
				});
			}

			// Token: 0x060013E6 RID: 5094 RVA: 0x0000B845 File Offset: 0x00009A45
			public override bool Equals(object obj)
			{
				return this == (ModBase.MyColor)obj;
			}

			// Token: 0x04000A0E RID: 2574
			public double m_StrategyParameter;

			// Token: 0x04000A0F RID: 2575
			public double m_RulesParameter;

			// Token: 0x04000A10 RID: 2576
			public double m_WorkerParameter;

			// Token: 0x04000A11 RID: 2577
			public double _DicParameter;
		}

		// Token: 0x020001A7 RID: 423
		public class MyRect
		{
			// Token: 0x17000351 RID: 849
			// (get) Token: 0x060013E8 RID: 5096 RVA: 0x0000B853 File Offset: 0x00009A53
			// (set) Token: 0x060013E9 RID: 5097 RVA: 0x0000B85B File Offset: 0x00009A5B
			public double Width { get; set; }

			// Token: 0x17000352 RID: 850
			// (get) Token: 0x060013EA RID: 5098 RVA: 0x0000B864 File Offset: 0x00009A64
			// (set) Token: 0x060013EB RID: 5099 RVA: 0x0000B86C File Offset: 0x00009A6C
			public double Height { get; set; }

			// Token: 0x17000353 RID: 851
			// (get) Token: 0x060013EC RID: 5100 RVA: 0x0000B875 File Offset: 0x00009A75
			// (set) Token: 0x060013ED RID: 5101 RVA: 0x0000B87D File Offset: 0x00009A7D
			public double Left { get; set; }

			// Token: 0x17000354 RID: 852
			// (get) Token: 0x060013EE RID: 5102 RVA: 0x0000B886 File Offset: 0x00009A86
			// (set) Token: 0x060013EF RID: 5103 RVA: 0x0000B88E File Offset: 0x00009A8E
			public double Top { get; set; }

			// Token: 0x060013F0 RID: 5104 RVA: 0x00088310 File Offset: 0x00086510
			public MyRect()
			{
				this.Width = 0.0;
				this.Height = 0.0;
				this.Left = 0.0;
				this.Top = 0.0;
			}

			// Token: 0x060013F1 RID: 5105 RVA: 0x00088360 File Offset: 0x00086560
			public MyRect(double left, double top, double width, double height)
			{
				this.Width = 0.0;
				this.Height = 0.0;
				this.Left = 0.0;
				this.Top = 0.0;
				this.Left = left;
				this.Top = top;
				this.Width = width;
				this.Height = height;
			}

			// Token: 0x04000A12 RID: 2578
			[CompilerGenerated]
			private double _ConfigurationParameter;

			// Token: 0x04000A13 RID: 2579
			[CompilerGenerated]
			private double _ConfigParameter;

			// Token: 0x04000A14 RID: 2580
			[CompilerGenerated]
			private double _ManagerParameter;

			// Token: 0x04000A15 RID: 2581
			[CompilerGenerated]
			private double _RuleParameter;
		}

		// Token: 0x020001A8 RID: 424
		public enum LoadState
		{
			// Token: 0x04000A17 RID: 2583
			Waiting,
			// Token: 0x04000A18 RID: 2584
			Loading,
			// Token: 0x04000A19 RID: 2585
			Finished,
			// Token: 0x04000A1A RID: 2586
			Failed,
			// Token: 0x04000A1B RID: 2587
			Aborted
		}

		// Token: 0x020001A9 RID: 425
		public enum Result
		{
			// Token: 0x04000A1D RID: 2589
			Aborted = -1,
			// Token: 0x04000A1E RID: 2590
			Success,
			// Token: 0x04000A1F RID: 2591
			Fail,
			// Token: 0x04000A20 RID: 2592
			Exception,
			// Token: 0x04000A21 RID: 2593
			Timeout,
			// Token: 0x04000A22 RID: 2594
			Cancel
		}

		// Token: 0x020001AA RID: 426
		public class EqualableList<T> : List<T>
		{
			// Token: 0x060013F4 RID: 5108 RVA: 0x000883D0 File Offset: 0x000865D0
			public override bool Equals(object obj)
			{
				checked
				{
					bool result;
					if (!(obj is List<T>))
					{
						result = false;
					}
					else
					{
						List<T> list = (List<T>)obj;
						if (list.Count != base.Count)
						{
							result = false;
						}
						else
						{
							int num = list.Count - 1;
							for (int i = 0; i <= num; i++)
							{
								T t = list[i];
								if (!t.Equals(base[i]))
								{
									return false;
								}
							}
							result = true;
						}
					}
					return result;
				}
			}

			// Token: 0x060013F5 RID: 5109 RVA: 0x0000B8A0 File Offset: 0x00009AA0
			public static bool operator ==(ModBase.EqualableList<T> left, ModBase.EqualableList<T> right)
			{
				return EqualityComparer<ModBase.EqualableList<T>>.Default.Equals(left, right);
			}

			// Token: 0x060013F6 RID: 5110 RVA: 0x0000B8AE File Offset: 0x00009AAE
			public static bool operator !=(ModBase.EqualableList<T> left, ModBase.EqualableList<T> right)
			{
				return !(left == right);
			}
		}

		// Token: 0x020001AB RID: 427
		private class IniCache
		{
			// Token: 0x060013F8 RID: 5112 RVA: 0x0000B8BA File Offset: 0x00009ABA
			public IniCache()
			{
				this._MerchantParameter = "";
				this.exporterParameter = new Dictionary<string, string>();
			}

			// Token: 0x04000A23 RID: 2595
			public string _MerchantParameter;

			// Token: 0x04000A24 RID: 2596
			public Dictionary<string, string> exporterParameter;
		}

		// Token: 0x020001AC RID: 428
		public class FileChecker
		{
			// Token: 0x060013FA RID: 5114 RVA: 0x00088444 File Offset: 0x00086644
			public FileChecker(long MinSize = -1L, long ActualSize = -1L, string Hash = null, bool CanUseExistsFile = true, bool IsJson = false)
			{
				this.queueParameter = -1L;
				this._GlobalParameter = -1L;
				this._ListParameter = null;
				this.methodParameter = true;
				this._AnnotationParameter = false;
				this.queueParameter = ActualSize;
				this._GlobalParameter = MinSize;
				this._ListParameter = Hash;
				this.methodParameter = CanUseExistsFile;
				this._AnnotationParameter = IsJson;
			}

			// Token: 0x060013FB RID: 5115 RVA: 0x000884B0 File Offset: 0x000866B0
			public string Check(string LocalPath)
			{
				string result;
				try
				{
					FileInfo fileInfo = new FileInfo(LocalPath);
					if (!fileInfo.Exists)
					{
						result = "文件不存在：" + LocalPath;
					}
					else
					{
						long length = fileInfo.Length;
						if (this.queueParameter >= 0L && this.queueParameter != length)
						{
							result = string.Concat(new string[]
							{
								"文件大小应为 ",
								Conversions.ToString(this.queueParameter),
								" B，实际为 ",
								Conversions.ToString(length),
								" B"
							});
						}
						else if (this._GlobalParameter >= 0L && this._GlobalParameter > length)
						{
							result = string.Concat(new string[]
							{
								"文件大小应大于 ",
								Conversions.ToString(this._GlobalParameter),
								" B，实际为 ",
								Conversions.ToString(length),
								" B"
							});
						}
						else
						{
							if (!string.IsNullOrEmpty(this._ListParameter))
							{
								if (this._ListParameter.Length < 35)
								{
									if (Operators.CompareString(this._ListParameter, ModBase.smethod_0(LocalPath), true) != 0)
									{
										return "文件 MD5 应为 " + this._ListParameter + "，实际为 " + ModBase.smethod_0(LocalPath);
									}
								}
								else if (Operators.CompareString(this._ListParameter, ModBase.smethod_1(LocalPath), true) != 0)
								{
									return "文件 SHA1 应为 " + this._ListParameter + "，实际为 " + ModBase.smethod_1(LocalPath);
								}
							}
							if (this._AnnotationParameter)
							{
								string text = ModBase.ReadFile(LocalPath);
								if (Operators.CompareString(text, "", true) == 0)
								{
									throw new Exception("读取到的文件为空");
								}
								try
								{
									ModBase.GetJson(text);
								}
								catch (Exception innerException)
								{
									throw new Exception("不是有效的 Json 文件", innerException);
								}
							}
							result = null;
						}
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "检查文件出错", ModBase.LogLevel.Debug, "出现错误");
					result = ModBase.GetString(ex, true, false);
				}
				return result;
			}

			// Token: 0x04000A25 RID: 2597
			public long queueParameter;

			// Token: 0x04000A26 RID: 2598
			public long _GlobalParameter;

			// Token: 0x04000A27 RID: 2599
			public string _ListParameter;

			// Token: 0x04000A28 RID: 2600
			public bool methodParameter;

			// Token: 0x04000A29 RID: 2601
			public bool _AnnotationParameter;
		}

		// Token: 0x020001AD RID: 429
		public class SearchEntry<T>
		{
			// Token: 0x04000A2A RID: 2602
			public T interceptorParameter;

			// Token: 0x04000A2B RID: 2603
			public List<KeyValuePair<string, double>> m_RefParameter;

			// Token: 0x04000A2C RID: 2604
			public double serverParameter;

			// Token: 0x04000A2D RID: 2605
			public bool serviceParameter;
		}

		// Token: 0x020001AE RID: 430
		public sealed class RouteEventArgs : EventArgs
		{
			// Token: 0x060013FF RID: 5119 RVA: 0x0000B8D9 File Offset: 0x00009AD9
			public RouteEventArgs(bool RaiseByMouse = false)
			{
				this.proxyParameter = false;
				this.m_ImporterParameter = RaiseByMouse;
			}

			// Token: 0x04000A2E RID: 2606
			public bool m_ImporterParameter;

			// Token: 0x04000A2F RID: 2607
			public bool proxyParameter;
		}

		// Token: 0x020001AF RID: 431
		// (Invoke) Token: 0x06001404 RID: 5124
		public delegate bool CompareThreadStart(object Left, object Right);

		// Token: 0x020001B0 RID: 432
		public enum LogLevel
		{
			// Token: 0x04000A31 RID: 2609
			Normal,
			// Token: 0x04000A32 RID: 2610
			Developer,
			// Token: 0x04000A33 RID: 2611
			Debug,
			// Token: 0x04000A34 RID: 2612
			Hint,
			// Token: 0x04000A35 RID: 2613
			Msgbox,
			// Token: 0x04000A36 RID: 2614
			Feedback,
			// Token: 0x04000A37 RID: 2615
			Assert
		}
	}
}
