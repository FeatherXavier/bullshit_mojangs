﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000035 RID: 53
	public class MyPageRight : AdornerDecorator
	{
		// Token: 0x06000119 RID: 281 RVA: 0x00002CC6 File Offset: 0x00000EC6
		public MyPageRight()
		{
			this.attr = ModBase.GetUuid();
			this._Facade = MyPageRight.PageStates.Empty;
		}

		// Token: 0x0600011A RID: 282 RVA: 0x00002CE1 File Offset: 0x00000EE1
		public MyPageRight.PageStates SelectModel()
		{
			return this._Facade;
		}

		// Token: 0x0600011B RID: 283 RVA: 0x00002CE9 File Offset: 0x00000EE9
		public void FlushModel(MyPageRight.PageStates value)
		{
			if (this._Facade != value)
			{
				this._Facade = value;
				if (ModBase._EventState)
				{
					ModBase.Log("[UI] 页面状态切换为 " + ModBase.GetStringFromEnum(value), ModBase.LogLevel.Normal, "出现错误");
				}
			}
		}

		// Token: 0x0600011C RID: 284 RVA: 0x0001047C File Offset: 0x0000E67C
		public void PageLoaderInit(MyLoading LoaderUi, FrameworkElement PanLoader, FrameworkElement PanContent, FrameworkElement PanAlways, ModLoader.LoaderBase RealLoader, Action<ModLoader.LoaderBase> FinishedInvoke, Func<object> InputInvoke = null, bool AutoRun = true)
		{
			MyPageRight._Closure$__14-0 CS$<>8__locals1 = new MyPageRight._Closure$__14-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Me = this;
			CS$<>8__locals1.$VB$Local_RealLoader = RealLoader;
			CS$<>8__locals1.$VB$Local_FinishedInvoke = FinishedInvoke;
			this._Template = PanLoader;
			this.m_Expression = PanContent;
			this.PanAlways = PanAlways;
			this.m_Bridge = CS$<>8__locals1.$VB$Local_RealLoader;
			this._Indexer = LoaderUi;
			this._Struct = InputInvoke;
			this.getter = AutoRun;
			CS$<>8__locals1.$VB$Local_RealLoader.PreviewFinish += delegate(ModLoader.LoaderBase a0)
			{
				base._Lambda$__0();
			};
			CS$<>8__locals1.$VB$Local_RealLoader.OnStateChangedUi += delegate(ModLoader.LoaderBase Loader, ModBase.LoadState NewState, ModBase.LoadState OldState)
			{
				MyPageRight._Closure$__14-1 CS$<>8__locals2 = new MyPageRight._Closure$__14-1(CS$<>8__locals2);
				CS$<>8__locals2.$VB$Me = this;
				CS$<>8__locals2.$VB$Local_Loader = Loader;
				CS$<>8__locals2.$VB$Local_NewState = NewState;
				CS$<>8__locals2.$VB$Local_OldState = OldState;
				ModBase.RunInUi(delegate()
				{
					CS$<>8__locals2.$VB$Me.PageLoaderState(CS$<>8__locals2.$VB$Local_Loader, CS$<>8__locals2.$VB$Local_NewState, CS$<>8__locals2.$VB$Local_OldState);
				}, false);
			};
			PanLoader.Visibility = Visibility.Collapsed;
			PanContent.Visibility = Visibility.Collapsed;
			if (PanAlways != null)
			{
				PanAlways.Visibility = Visibility.Collapsed;
			}
			if (this.getter)
			{
				if (this.m_Bridge.GetType().Name.StartsWith("LoaderTask"))
				{
					ModLoader.LoaderBase bridge = this.m_Bridge;
					object bridge2 = this.m_Bridge;
					Type type = null;
					string memberName = "StartGetInput";
					object[] array = new object[2];
					int num = 1;
					ref object ptr = ref this._Struct;
					array[num] = this._Struct;
					object[] array2 = array;
					bool[] array3;
					object obj = NewLateBinding.LateGet(bridge2, type, memberName, array, null, null, array3 = new bool[]
					{
						default(bool),
						true
					});
					if (array3[1])
					{
						ptr = RuntimeHelpers.GetObjectValue(array2[1]);
					}
					bridge.Start(RuntimeHelpers.GetObjectValue(obj), false);
				}
				else
				{
					object obj2 = null;
					if (this._Struct != null)
					{
						obj2 = RuntimeHelpers.GetObjectValue(NewLateBinding.LateIndexGet(this._Struct, new object[0], null));
					}
					this.m_Bridge.Start(RuntimeHelpers.GetObjectValue(obj2), false);
				}
			}
			if (this.m_Bridge.State == ModBase.LoadState.Finished)
			{
				ModBase.RunInUiWait(delegate
				{
					CS$<>8__locals1.$VB$Local_FinishedInvoke(CS$<>8__locals1.$VB$Local_RealLoader);
				});
			}
			this._Indexer.State = CS$<>8__locals1.$VB$Local_RealLoader;
			this._Indexer.PatchWrapper(delegate(object sender, MouseButtonEventArgs e)
			{
				base._Lambda$__5();
			});
		}

		// Token: 0x0600011D RID: 285 RVA: 0x00010624 File Offset: 0x0000E824
		public void PageLoaderRestart(object Input = null, bool IsForceRestart = true)
		{
			if (this.getter)
			{
				if (this.m_Bridge.GetType().Name.StartsWith("LoaderTask"))
				{
					ModLoader.LoaderBase bridge = this.m_Bridge;
					object bridge2 = this.m_Bridge;
					Type type = null;
					string memberName = "StartGetInput";
					object[] array = new object[2];
					array[0] = Input;
					int num = 1;
					ref object ptr = ref this._Struct;
					array[num] = this._Struct;
					object[] array2 = array;
					bool[] array3;
					object obj = NewLateBinding.LateGet(bridge2, type, memberName, array, null, null, array3 = new bool[]
					{
						true,
						true
					});
					if (array3[0])
					{
						Input = RuntimeHelpers.GetObjectValue(array2[0]);
					}
					if (array3[1])
					{
						ptr = RuntimeHelpers.GetObjectValue(array2[1]);
					}
					bridge.Start(RuntimeHelpers.GetObjectValue(obj), IsForceRestart);
					return;
				}
				if (Input == null && this._Struct != null)
				{
					Input = RuntimeHelpers.GetObjectValue(NewLateBinding.LateIndexGet(this._Struct, new object[0], null));
				}
				this.m_Bridge.Start(RuntimeHelpers.GetObjectValue(Input), IsForceRestart);
			}
		}

		// Token: 0x0600011E RID: 286 RVA: 0x000106FC File Offset: 0x0000E8FC
		public void PageOnEnter()
		{
			if (ModBase._EventState)
			{
				ModBase.Log("[UI] 已触发 PageOnEnter", ModBase.LogLevel.Normal, "出现错误");
			}
			MyPageRight.OnPageEnterEventHandler listener = this._Listener;
			if (listener != null)
			{
				listener();
			}
			if (this.SelectModel() == MyPageRight.PageStates.Empty)
			{
				if (this.m_Bridge != null)
				{
					if (this.m_Bridge.State != ModBase.LoadState.Finished)
					{
						if (this.m_Bridge.State == ModBase.LoadState.Loading)
						{
							this.FlushModel(MyPageRight.PageStates.LoaderWait);
							ModAnimation.AniStart(ModAnimation.AaCode(new ThreadStart(this.PageOnLoaderWaitFinished), 200, false), "PageRight PageChange " + Conversions.ToString(this.attr), false);
							return;
						}
						if (this.m_Bridge.State == ModBase.LoadState.Failed)
						{
							this.FlushModel(MyPageRight.PageStates.LoaderEnter);
							this.TriggerEnterAnimation(new FrameworkElement[]
							{
								this.PanAlways,
								this._Template
							});
							return;
						}
						throw new Exception(string.Concat(new string[]
						{
							"页面加载器 ",
							this.m_Bridge.Name,
							" 不应在 PageOnEnter 事件出现 ",
							ModBase.GetStringFromEnum(this.m_Bridge.State),
							"状态。"
						}));
					}
				}
				this.FlushModel(MyPageRight.PageStates.ContentEnter);
				this.TriggerEnterAnimation(new FrameworkElement[]
				{
					this.PanAlways,
					(FrameworkElement)(this.m_Expression ?? this.Child)
				});
				return;
			}
			throw new Exception("在状态为 " + ModBase.GetStringFromEnum(this.SelectModel()) + " 时触发了 PageOnEnter 事件。");
		}

		// Token: 0x0600011F RID: 287 RVA: 0x00010884 File Offset: 0x0000EA84
		[CompilerGenerated]
		public void CountModel(MyPageRight.OnPageEnterEventHandler obj)
		{
			MyPageRight.OnPageEnterEventHandler onPageEnterEventHandler = this._Listener;
			MyPageRight.OnPageEnterEventHandler onPageEnterEventHandler2;
			do
			{
				onPageEnterEventHandler2 = onPageEnterEventHandler;
				MyPageRight.OnPageEnterEventHandler value = (MyPageRight.OnPageEnterEventHandler)Delegate.Combine(onPageEnterEventHandler2, obj);
				onPageEnterEventHandler = Interlocked.CompareExchange<MyPageRight.OnPageEnterEventHandler>(ref this._Listener, value, onPageEnterEventHandler2);
			}
			while (onPageEnterEventHandler != onPageEnterEventHandler2);
		}

		// Token: 0x06000120 RID: 288 RVA: 0x000108BC File Offset: 0x0000EABC
		[CompilerGenerated]
		public void AddModel(MyPageRight.OnPageEnterEventHandler obj)
		{
			MyPageRight.OnPageEnterEventHandler onPageEnterEventHandler = this._Listener;
			MyPageRight.OnPageEnterEventHandler onPageEnterEventHandler2;
			do
			{
				onPageEnterEventHandler2 = onPageEnterEventHandler;
				MyPageRight.OnPageEnterEventHandler value = (MyPageRight.OnPageEnterEventHandler)Delegate.Remove(onPageEnterEventHandler2, obj);
				onPageEnterEventHandler = Interlocked.CompareExchange<MyPageRight.OnPageEnterEventHandler>(ref this._Listener, value, onPageEnterEventHandler2);
			}
			while (onPageEnterEventHandler != onPageEnterEventHandler2);
		}

		// Token: 0x06000121 RID: 289 RVA: 0x000108F4 File Offset: 0x0000EAF4
		public void PageOnExit()
		{
			if (ModBase._EventState)
			{
				ModBase.Log("[UI] 已触发 PageOnExit", ModBase.LogLevel.Normal, "出现错误");
			}
			switch (this.SelectModel())
			{
			case MyPageRight.PageStates.Empty:
			case MyPageRight.PageStates.PageExit:
				break;
			case MyPageRight.PageStates.LoaderWait:
				this.FlushModel(MyPageRight.PageStates.PageExit);
				this.TriggerExitAnimation(new FrameworkElement[]
				{
					this.PanAlways
				});
				return;
			case MyPageRight.PageStates.LoaderEnter:
			case MyPageRight.PageStates.LoaderStayForce:
			case MyPageRight.PageStates.LoaderStay:
				this.FlushModel(MyPageRight.PageStates.PageExit);
				this.TriggerExitAnimation(new FrameworkElement[]
				{
					this.PanAlways,
					this._Template
				});
				return;
			case MyPageRight.PageStates.LoaderExit:
			case MyPageRight.PageStates.ReloadExit:
				this.FlushModel(MyPageRight.PageStates.PageExit);
				if (this.PanAlways != null)
				{
					this.TriggerExitAnimation(new FrameworkElement[]
					{
						this.PanAlways,
						(FrameworkElement)(this.m_Expression ?? this.Child)
					});
				}
				break;
			case MyPageRight.PageStates.ContentEnter:
			case MyPageRight.PageStates.ContentStay:
				this.FlushModel(MyPageRight.PageStates.PageExit);
				this.TriggerExitAnimation(new FrameworkElement[]
				{
					this.PanAlways,
					(FrameworkElement)(this.m_Expression ?? this.Child)
				});
				return;
			default:
				return;
			}
		}

		// Token: 0x06000122 RID: 290 RVA: 0x00010A08 File Offset: 0x0000EC08
		public void PageOnForceExit()
		{
			if (this.SelectModel() != MyPageRight.PageStates.Empty)
			{
				if (ModBase._EventState)
				{
					ModBase.Log("[UI] 已触发 PageOnForceExit", ModBase.LogLevel.Normal, "出现错误");
				}
				this.FlushModel(MyPageRight.PageStates.Empty);
				ModAnimation.AniStop("PageRight PageChange " + Conversions.ToString(this.attr));
				if (this.m_Bridge == null)
				{
					this.Child.Visibility = Visibility.Collapsed;
					return;
				}
				this.m_Expression.Visibility = Visibility.Collapsed;
				this._Template.Visibility = Visibility.Collapsed;
				if (this.PanAlways != null)
				{
					this.PanAlways.Visibility = Visibility.Collapsed;
				}
			}
		}

		// Token: 0x06000123 RID: 291 RVA: 0x00010A98 File Offset: 0x0000EC98
		private void PageOnEnterAnimationFinished()
		{
			if (ModBase._EventState)
			{
				ModBase.Log("[UI] 已触发 PageOnEnterAnimationFinished", ModBase.LogLevel.Normal, "出现错误");
			}
			MyPageRight.PageStates pageStates = this.SelectModel();
			if (pageStates == MyPageRight.PageStates.LoaderEnter)
			{
				this.FlushModel(MyPageRight.PageStates.LoaderStayForce);
				ModAnimation.AniStart(ModAnimation.AaCode(new ThreadStart(this.PageOnLoaderStayFinished), 400, false), "PageRight PageChange " + Conversions.ToString(this.attr), false);
				return;
			}
			if (pageStates == MyPageRight.PageStates.ContentEnter)
			{
				this.FlushModel(MyPageRight.PageStates.ContentStay);
				return;
			}
			throw new Exception("在状态为 " + ModBase.GetStringFromEnum(this.SelectModel()) + " 时触发了 PageOnEnterAnimationFinished 事件。");
		}

		// Token: 0x06000124 RID: 292 RVA: 0x00010B34 File Offset: 0x0000ED34
		private void PageOnExitAnimationFinished()
		{
			if (ModBase._EventState)
			{
				ModBase.Log("[UI] 已触发 PageOnExitAnimationFinished", ModBase.LogLevel.Normal, "出现错误");
			}
			switch (this.SelectModel())
			{
			case MyPageRight.PageStates.LoaderExit:
				this.FlushModel(MyPageRight.PageStates.ContentEnter);
				this.TriggerEnterAnimation(new FrameworkElement[]
				{
					this.m_Expression
				});
				return;
			case MyPageRight.PageStates.ReloadExit:
				this.FlushModel(MyPageRight.PageStates.Empty);
				this.PageOnEnter();
				return;
			case MyPageRight.PageStates.PageExit:
				this.FlushModel(MyPageRight.PageStates.Empty);
				return;
			}
			throw new Exception("在状态为 " + ModBase.GetStringFromEnum(this.SelectModel()) + " 时触发了 PageOnExitAnimationFinished 事件。");
		}

		// Token: 0x06000125 RID: 293 RVA: 0x00010BD8 File Offset: 0x0000EDD8
		private void PageOnLoaderWaitFinished()
		{
			if (ModBase._EventState)
			{
				ModBase.Log("[UI] 已触发 PageOnLoaderWaitFinished", ModBase.LogLevel.Normal, "出现错误");
			}
			MyPageRight.PageStates pageStates = this.SelectModel();
			if (pageStates != MyPageRight.PageStates.LoaderWait)
			{
				throw new Exception("在状态为 " + ModBase.GetStringFromEnum(this.SelectModel()) + " 时触发了 PageOnLoaderWaitFinished 事件。");
			}
			this.FlushModel(MyPageRight.PageStates.LoaderEnter);
			if (this.PanAlways != null && this.PanAlways.Visibility == Visibility.Collapsed)
			{
				this.TriggerEnterAnimation(new FrameworkElement[]
				{
					this.PanAlways,
					this._Template
				});
				return;
			}
			this.TriggerEnterAnimation(new FrameworkElement[]
			{
				this._Template
			});
		}

		// Token: 0x06000126 RID: 294 RVA: 0x00010C80 File Offset: 0x0000EE80
		private void PageOnLoaderStayFinished()
		{
			if (ModBase._EventState)
			{
				ModBase.Log("[UI] 已触发 PageOnLoaderStayFinished", ModBase.LogLevel.Normal, "出现错误");
			}
			MyPageRight.PageStates pageStates = this.SelectModel();
			if (pageStates != MyPageRight.PageStates.LoaderStayForce)
			{
				throw new Exception("在状态为 " + ModBase.GetStringFromEnum(this.SelectModel()) + " 时触发了 PageOnLoaderWaitFinished 事件。");
			}
			if (this.m_Bridge.State == ModBase.LoadState.Finished)
			{
				this.FlushModel(MyPageRight.PageStates.LoaderExit);
				this.TriggerExitAnimation(new FrameworkElement[]
				{
					this._Template
				});
				return;
			}
			this.FlushModel(MyPageRight.PageStates.LoaderStay);
		}

		// Token: 0x06000127 RID: 295 RVA: 0x00010D08 File Offset: 0x0000EF08
		private void PageLoaderState(object sender, ModBase.LoadState NewState, ModBase.LoadState OldState)
		{
			switch (NewState)
			{
			case ModBase.LoadState.Loading:
			case ModBase.LoadState.Failed:
				if (OldState == ModBase.LoadState.Finished)
				{
					if (ModBase._EventState)
					{
						ModBase.Log("[UI] 已触发 PageLoaderState (Refresh)", ModBase.LogLevel.Normal, "出现错误");
					}
					switch (this.SelectModel())
					{
					case MyPageRight.PageStates.LoaderExit:
					case MyPageRight.PageStates.ReloadExit:
						this.FlushModel(MyPageRight.PageStates.ReloadExit);
						return;
					case MyPageRight.PageStates.ContentEnter:
					case MyPageRight.PageStates.ContentStay:
						this.FlushModel(MyPageRight.PageStates.ReloadExit);
						this.TriggerExitAnimation(new FrameworkElement[]
						{
							this.m_Expression
						});
						return;
					default:
						return;
					}
				}
				break;
			case ModBase.LoadState.Finished:
				if (OldState == ModBase.LoadState.Loading)
				{
					if (ModBase._EventState)
					{
						ModBase.Log("[UI] 已触发 PageLoaderState (Stop)", ModBase.LogLevel.Normal, "出现错误");
					}
					MyPageRight.PageStates pageStates = this.SelectModel();
					if (pageStates != MyPageRight.PageStates.LoaderWait)
					{
						if (pageStates != MyPageRight.PageStates.LoaderStay)
						{
							return;
						}
						this.FlushModel(MyPageRight.PageStates.LoaderExit);
						this.TriggerExitAnimation(new FrameworkElement[]
						{
							this._Template
						});
					}
					else
					{
						this.FlushModel(MyPageRight.PageStates.ContentEnter);
						if (this.PanAlways != null && this.PanAlways.Visibility == Visibility.Collapsed)
						{
							this.TriggerEnterAnimation(new FrameworkElement[]
							{
								this.PanAlways,
								this.m_Expression
							});
							return;
						}
						this.TriggerEnterAnimation(new FrameworkElement[]
						{
							this.m_Expression
						});
						return;
					}
				}
				break;
			default:
				return;
			}
		}

		// Token: 0x06000128 RID: 296 RVA: 0x00010E30 File Offset: 0x0000F030
		public void TriggerEnterAnimation(params FrameworkElement[] Elements)
		{
			List<FrameworkElement> list = new List<FrameworkElement>();
			foreach (FrameworkElement frameworkElement in Elements)
			{
				if (frameworkElement != null)
				{
					list.Add(frameworkElement);
				}
			}
			try
			{
				foreach (FrameworkElement frameworkElement2 in list)
				{
					frameworkElement2.Visibility = Visibility.Visible;
				}
			}
			finally
			{
				List<FrameworkElement>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			List<ModAnimation.AniData> list2 = new List<ModAnimation.AniData>();
			int num = 0;
			checked
			{
				try
				{
					foreach (FrameworkElement element in list)
					{
						try
						{
							foreach (FrameworkElement frameworkElement3 in this.GetAllAnimControls(element))
							{
								frameworkElement3.Opacity = 0.0;
								frameworkElement3.IsHitTestVisible = true;
								frameworkElement3.RenderTransform = new TranslateTransform(0.0, -16.0);
								list2.Add(ModAnimation.AaOpacity(frameworkElement3, 1.0, 150, num, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Weak), false));
								list2.Add(ModAnimation.AaTranslateY(frameworkElement3, 5.0, 250, num, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false));
								list2.Add(ModAnimation.AaTranslateY(frameworkElement3, 11.0, 350, num, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Middle), false));
								num += 40;
							}
						}
						finally
						{
							List<FrameworkElement>.Enumerator enumerator3;
							((IDisposable)enumerator3).Dispose();
						}
					}
				}
				finally
				{
					List<FrameworkElement>.Enumerator enumerator2;
					((IDisposable)enumerator2).Dispose();
				}
				list2.Add(ModAnimation.AaCode(delegate
				{
					this.PageOnEnterAnimationFinished();
				}, 0, true));
				ModAnimation.AniStart(list2, "PageRight PageChange " + Conversions.ToString(this.attr), false);
			}
		}

		// Token: 0x06000129 RID: 297 RVA: 0x00011034 File Offset: 0x0000F234
		public void TriggerExitAnimation(params FrameworkElement[] Elements)
		{
			MyPageRight._Closure$__30-0 CS$<>8__locals1 = new MyPageRight._Closure$__30-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Me = this;
			CS$<>8__locals1.$VB$Local_RealElements = new List<FrameworkElement>();
			foreach (FrameworkElement frameworkElement in Elements)
			{
				if (frameworkElement != null)
				{
					CS$<>8__locals1.$VB$Local_RealElements.Add(frameworkElement);
				}
			}
			List<ModAnimation.AniData> list = new List<ModAnimation.AniData>();
			int num = 0;
			checked
			{
				try
				{
					foreach (FrameworkElement element in CS$<>8__locals1.$VB$Local_RealElements)
					{
						try
						{
							foreach (FrameworkElement frameworkElement2 in this.GetAllAnimControls(element))
							{
								frameworkElement2.IsHitTestVisible = false;
								list.Add(ModAnimation.AaOpacity(frameworkElement2, -1.0, 90, num, null, false));
								list.Add(ModAnimation.AaTranslateY(frameworkElement2, -6.0, 90, num, null, false));
								num += 20;
							}
						}
						finally
						{
							List<FrameworkElement>.Enumerator enumerator2;
							((IDisposable)enumerator2).Dispose();
						}
					}
				}
				finally
				{
					List<FrameworkElement>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				list.Add(ModAnimation.AaCode(delegate
				{
					try
					{
						foreach (FrameworkElement frameworkElement3 in CS$<>8__locals1.$VB$Local_RealElements)
						{
							frameworkElement3.Visibility = Visibility.Collapsed;
						}
					}
					finally
					{
						List<FrameworkElement>.Enumerator enumerator3;
						((IDisposable)enumerator3).Dispose();
					}
					CS$<>8__locals1.$VB$Me.PageOnExitAnimationFinished();
				}, 0, true));
				ModAnimation.AniStart(list, "PageRight PageChange " + Conversions.ToString(this.attr), false);
			}
		}

		// Token: 0x0600012A RID: 298 RVA: 0x00011188 File Offset: 0x0000F388
		internal List<FrameworkElement> GetAllAnimControls(FrameworkElement Element)
		{
			List<FrameworkElement> result = new List<FrameworkElement>();
			this.GetAllAnimControls(Element, ref result);
			return result;
		}

		// Token: 0x0600012B RID: 299 RVA: 0x000111A8 File Offset: 0x0000F3A8
		private void GetAllAnimControls(FrameworkElement Element, ref List<FrameworkElement> AllControls)
		{
			if (Element.Visibility != Visibility.Collapsed)
			{
				if (!(Element is MyCard) && !(Element is MyHint))
				{
					if (Element is ContentControl)
					{
						this.GetAllAnimControls((FrameworkElement)((ContentControl)Element).Content, ref AllControls);
						return;
					}
					if (!(Element is Panel))
					{
						return;
					}
					try
					{
						foreach (object obj in ((Panel)Element).Children)
						{
							FrameworkElement element = (FrameworkElement)obj;
							this.GetAllAnimControls(element, ref AllControls);
						}
						return;
					}
					finally
					{
						IEnumerator enumerator;
						if (enumerator is IDisposable)
						{
							(enumerator as IDisposable).Dispose();
						}
					}
				}
				AllControls.Add(Element);
				return;
			}
		}

		// Token: 0x04000085 RID: 133
		public int attr;

		// Token: 0x04000086 RID: 134
		private MyPageRight.PageStates _Facade;

		// Token: 0x04000087 RID: 135
		private ModLoader.LoaderBase m_Bridge;

		// Token: 0x04000088 RID: 136
		private object _Struct;

		// Token: 0x04000089 RID: 137
		private MyLoading _Indexer;

		// Token: 0x0400008A RID: 138
		private FrameworkElement _Template;

		// Token: 0x0400008B RID: 139
		private FrameworkElement m_Expression;

		// Token: 0x0400008C RID: 140
		private FrameworkElement PanAlways;

		// Token: 0x0400008D RID: 141
		private bool getter;

		// Token: 0x0400008E RID: 142
		[CompilerGenerated]
		private MyPageRight.OnPageEnterEventHandler _Listener;

		// Token: 0x02000036 RID: 54
		public enum PageStates
		{
			// Token: 0x04000090 RID: 144
			Empty,
			// Token: 0x04000091 RID: 145
			LoaderWait,
			// Token: 0x04000092 RID: 146
			LoaderEnter,
			// Token: 0x04000093 RID: 147
			LoaderStayForce,
			// Token: 0x04000094 RID: 148
			LoaderStay,
			// Token: 0x04000095 RID: 149
			LoaderExit,
			// Token: 0x04000096 RID: 150
			ContentEnter,
			// Token: 0x04000097 RID: 151
			ContentStay,
			// Token: 0x04000098 RID: 152
			ReloadExit,
			// Token: 0x04000099 RID: 153
			PageExit
		}

		// Token: 0x02000037 RID: 55
		// (Invoke) Token: 0x06000132 RID: 306
		public delegate void OnPageEnterEventHandler();
	}
}
