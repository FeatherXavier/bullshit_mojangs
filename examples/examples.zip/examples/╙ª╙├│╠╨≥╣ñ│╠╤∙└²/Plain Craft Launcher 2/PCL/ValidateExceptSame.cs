﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x020000E9 RID: 233
	public class ValidateExceptSame : Validate
	{
		// Token: 0x06000916 RID: 2326 RVA: 0x000067F7 File Offset: 0x000049F7
		[CompilerGenerated]
		public Collection<string> FlushRepository()
		{
			return this._SystemTag;
		}

		// Token: 0x06000917 RID: 2327 RVA: 0x000067FF File Offset: 0x000049FF
		[CompilerGenerated]
		public void ChangeRepository(Collection<string> AutoPropertyValue)
		{
			this._SystemTag = AutoPropertyValue;
		}

		// Token: 0x06000918 RID: 2328 RVA: 0x00006808 File Offset: 0x00004A08
		[CompilerGenerated]
		public string AddRepository()
		{
			return this.m_WriterTag;
		}

		// Token: 0x06000919 RID: 2329 RVA: 0x00006810 File Offset: 0x00004A10
		[CompilerGenerated]
		public void RunRepository(string AutoPropertyValue)
		{
			this.m_WriterTag = AutoPropertyValue;
		}

		// Token: 0x0600091A RID: 2330 RVA: 0x00006819 File Offset: 0x00004A19
		[CompilerGenerated]
		public bool ExcludeRepository()
		{
			return this.m_BroadcasterTag;
		}

		// Token: 0x0600091B RID: 2331 RVA: 0x00006821 File Offset: 0x00004A21
		[CompilerGenerated]
		public void StartRepository(bool AutoPropertyValue)
		{
			this.m_BroadcasterTag = AutoPropertyValue;
		}

		// Token: 0x0600091C RID: 2332 RVA: 0x0000682A File Offset: 0x00004A2A
		public ValidateExceptSame(Collection<string> Excepts, string ErrorMessage = "输入内容不能为 %！", bool IgnoreCase = false)
		{
			this.ChangeRepository(new Collection<string>());
			this.StartRepository(false);
			this.ChangeRepository(Excepts);
			this.RunRepository(ErrorMessage);
			this.StartRepository(IgnoreCase);
		}

		// Token: 0x0600091D RID: 2333 RVA: 0x0003F9F4 File Offset: 0x0003DBF4
		public ValidateExceptSame(IEnumerable Excepts, string ErrorMessage = "输入内容不能为 %！", bool IgnoreCase = false)
		{
			this.ChangeRepository(new Collection<string>());
			this.StartRepository(false);
			this.ChangeRepository(new Collection<string>());
			try
			{
				foreach (object value in Excepts)
				{
					string item = Conversions.ToString(value);
					this.FlushRepository().Add(item);
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			this.RunRepository(ErrorMessage);
			this.StartRepository(IgnoreCase);
		}

		// Token: 0x0600091E RID: 2334 RVA: 0x0003FA84 File Offset: 0x0003DC84
		public override string Validate(string Str)
		{
			string result;
			if (Str == null)
			{
				result = this.AddRepository().Replace("%", "null");
			}
			else
			{
				try
				{
					foreach (string text in this.FlushRepository())
					{
						if (this.ExcludeRepository())
						{
							if (Operators.CompareString(Str.ToLower(), text.ToLower(), true) == 0)
							{
								return this.AddRepository().Replace("%", text);
							}
						}
						else if (Str.Equals(text))
						{
							return this.AddRepository().Replace("%", text);
						}
					}
				}
				finally
				{
					IEnumerator<string> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				result = "";
			}
			return result;
		}

		// Token: 0x04000463 RID: 1123
		[CompilerGenerated]
		private Collection<string> _SystemTag;

		// Token: 0x04000464 RID: 1124
		[CompilerGenerated]
		private string m_WriterTag;

		// Token: 0x04000465 RID: 1125
		[CompilerGenerated]
		private bool m_BroadcasterTag;
	}
}
