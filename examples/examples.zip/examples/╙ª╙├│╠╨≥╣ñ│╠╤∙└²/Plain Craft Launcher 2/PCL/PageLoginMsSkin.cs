﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x020000A0 RID: 160
	[DesignerGenerated]
	public class PageLoginMsSkin : Grid, IComponentConnector
	{
		// Token: 0x060005F5 RID: 1525 RVA: 0x00005231 File Offset: 0x00003431
		public PageLoginMsSkin()
		{
			base.Loaded += this.PageLoginLegacy_Loaded;
			this.m_ExporterRepository = false;
			this.InitializeComponent();
			this.Skin.m_RepositoryComparator = PageLaunchLeft.m_BridgeComparator;
		}

		// Token: 0x060005F6 RID: 1526 RVA: 0x00005269 File Offset: 0x00003469
		private void PageLoginLegacy_Loaded(object sender, RoutedEventArgs e)
		{
			this.Skin.m_RepositoryComparator.Start(null, false);
		}

		// Token: 0x060005F7 RID: 1527 RVA: 0x0000527D File Offset: 0x0000347D
		public void Reload(bool KeepInput)
		{
			this.TextName.Text = Conversions.ToString(ModBase._ParamsState.Get("CacheMsName", null));
		}

		// Token: 0x060005F8 RID: 1528 RVA: 0x0002C73C File Offset: 0x0002A93C
		public static ModLaunch.McLoginMs GetLoginData()
		{
			ModLaunch.McLoginMs result;
			if (ModLaunch._ExpressionTag.State == ModBase.LoadState.Finished)
			{
				result = new ModLaunch.McLoginMs
				{
					strategyProccesor = Conversions.ToString(ModBase._ParamsState.Get("CacheMsOAuthRefresh", null)),
					_DicProccesor = Conversions.ToString(ModBase._ParamsState.Get("CacheMsName", null)),
					m_RulesProccesor = Conversions.ToString(ModBase._ParamsState.Get("CacheMsAccess", null)),
					_WorkerProccesor = Conversions.ToString(ModBase._ParamsState.Get("CacheMsUuid", null))
				};
			}
			else
			{
				result = new ModLaunch.McLoginMs
				{
					strategyProccesor = Conversions.ToString(ModBase._ParamsState.Get("CacheMsOAuthRefresh", null)),
					_DicProccesor = Conversions.ToString(ModBase._ParamsState.Get("CacheMsName", null))
				};
			}
			return result;
		}

		// Token: 0x060005F9 RID: 1529 RVA: 0x0002C808 File Offset: 0x0002AA08
		private void PageLoginMsSkin_MouseEnter(object sender, MouseEventArgs e)
		{
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaOpacity(this.BtnEdit, 1.0 - this.BtnEdit.Opacity, 80, 0, null, false),
				ModAnimation.AaHeight(this.BtnEdit, 25.5 - this.BtnEdit.Height, 140, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaHeight(this.BtnEdit, -1.5, 50, 140, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaOpacity(this.BtnExit, 1.0 - this.BtnExit.Opacity, 80, 0, null, false),
				ModAnimation.AaHeight(this.BtnExit, 25.5 - this.BtnExit.Height, 140, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaHeight(this.BtnExit, -1.5, 50, 140, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false)
			}, "PageLoginMsSkin Button", false);
		}

		// Token: 0x060005FA RID: 1530 RVA: 0x0002C938 File Offset: 0x0002AB38
		private void PageLoginMsSkin_MouseLeave(object sender, MouseEventArgs e)
		{
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaOpacity(this.BtnEdit, -this.BtnEdit.Opacity, 120, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaHeight(this.BtnEdit, 14.0 - this.BtnEdit.Height, 120, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaOpacity(this.BtnExit, -this.BtnExit.Opacity, 120, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaHeight(this.BtnExit, 14.0 - this.BtnExit.Height, 120, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false)
			}, "PageLoginMsSkin Button", false);
		}

		// Token: 0x060005FB RID: 1531 RVA: 0x0000529F File Offset: 0x0000349F
		private void BtnEdit_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://account.microsoft.com/security");
		}

		// Token: 0x060005FC RID: 1532 RVA: 0x0002CA08 File Offset: 0x0002AC08
		private void BtnExit_Click()
		{
			ModBase._ParamsState.Set("CacheMsOAuthRefresh", "", false, null);
			ModBase._ParamsState.Set("CacheMsAccess", "", false, null);
			ModBase._ParamsState.Set("CacheMsUuid", "", false, null);
			ModBase._ParamsState.Set("CacheMsName", "", false, null);
			ModLaunch._ExpressionTag.Abort();
			ModMain._FilterAccount.RefreshPage(false, true);
		}

		// Token: 0x060005FD RID: 1533 RVA: 0x0002CA84 File Offset: 0x0002AC84
		private void Skin_Click(object sender, MouseButtonEventArgs e)
		{
			PageLoginMsSkin._Closure$__9-0 CS$<>8__locals1 = new PageLoginMsSkin._Closure$__9-0(CS$<>8__locals1);
			CS$<>8__locals1.$VB$Me = this;
			if (this.m_ExporterRepository)
			{
				ModMain.Hint("正在更改皮肤中，请稍候！", ModMain.HintType.Info, true);
				return;
			}
			if (ModLaunch.m_IndexerTag.State == ModBase.LoadState.Failed)
			{
				ModMain.Hint("登录失败，无法更改皮肤！", ModMain.HintType.Critical, true);
				return;
			}
			CS$<>8__locals1.$VB$Local_SkinInfo = ModMinecraft.McSkinSelect(false);
			if (CS$<>8__locals1.$VB$Local_SkinInfo._CodeParameter)
			{
				ModMain.Hint("正在更改皮肤……", ModMain.HintType.Info, true);
				this.m_ExporterRepository = true;
				ModBase.RunInNewThread(delegate
				{
					PageLoginMsSkin._Closure$__9-0.VB$StateMachine___Lambda$__0 vb$StateMachine___Lambda$__ = default(PageLoginMsSkin._Closure$__9-0.VB$StateMachine___Lambda$__0);
					vb$StateMachine___Lambda$__.$VB$NonLocal__Closure$__9-0 = CS$<>8__locals1;
					vb$StateMachine___Lambda$__.$State = -1;
					vb$StateMachine___Lambda$__.$Builder = AsyncVoidMethodBuilder.Create();
					vb$StateMachine___Lambda$__.$Builder.Start<PageLoginMsSkin._Closure$__9-0.VB$StateMachine___Lambda$__0>(ref vb$StateMachine___Lambda$__);
				}, "Ms Skin Upload", ThreadPriority.Normal);
			}
		}

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x060005FE RID: 1534 RVA: 0x000052AB File Offset: 0x000034AB
		// (set) Token: 0x060005FF RID: 1535 RVA: 0x0002CB14 File Offset: 0x0002AD14
		internal virtual Grid PanData
		{
			[CompilerGenerated]
			get
			{
				return this.m_QueueRepository;
			}
			[CompilerGenerated]
			set
			{
				MouseEventHandler value2 = new MouseEventHandler(this.PageLoginMsSkin_MouseEnter);
				MouseEventHandler value3 = new MouseEventHandler(this.PageLoginMsSkin_MouseLeave);
				Grid queueRepository = this.m_QueueRepository;
				if (queueRepository != null)
				{
					queueRepository.MouseEnter -= value2;
					queueRepository.MouseLeave -= value3;
				}
				this.m_QueueRepository = value;
				queueRepository = this.m_QueueRepository;
				if (queueRepository != null)
				{
					queueRepository.MouseEnter += value2;
					queueRepository.MouseLeave += value3;
				}
			}
		}

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x06000600 RID: 1536 RVA: 0x000052B3 File Offset: 0x000034B3
		// (set) Token: 0x06000601 RID: 1537 RVA: 0x000052BB File Offset: 0x000034BB
		internal virtual TextBlock TextName { get; set; }

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x06000602 RID: 1538 RVA: 0x000052C4 File Offset: 0x000034C4
		// (set) Token: 0x06000603 RID: 1539 RVA: 0x0002CB74 File Offset: 0x0002AD74
		internal virtual MyIconButton BtnEdit
		{
			[CompilerGenerated]
			get
			{
				return this._ListRepository;
			}
			[CompilerGenerated]
			set
			{
				MyIconButton.ClickEventHandler value2 = new MyIconButton.ClickEventHandler(this.BtnEdit_Click);
				MyIconButton listRepository = this._ListRepository;
				if (listRepository != null)
				{
					listRepository.Click -= value2;
				}
				this._ListRepository = value;
				listRepository = this._ListRepository;
				if (listRepository != null)
				{
					listRepository.Click += value2;
				}
			}
		}

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x06000604 RID: 1540 RVA: 0x000052CC File Offset: 0x000034CC
		// (set) Token: 0x06000605 RID: 1541 RVA: 0x0002CBB8 File Offset: 0x0002ADB8
		internal virtual MyIconButton BtnExit
		{
			[CompilerGenerated]
			get
			{
				return this.methodRepository;
			}
			[CompilerGenerated]
			set
			{
				MyIconButton.ClickEventHandler value2 = delegate(object sender, EventArgs e)
				{
					this.BtnExit_Click();
				};
				MyIconButton myIconButton = this.methodRepository;
				if (myIconButton != null)
				{
					myIconButton.Click -= value2;
				}
				this.methodRepository = value;
				myIconButton = this.methodRepository;
				if (myIconButton != null)
				{
					myIconButton.Click += value2;
				}
			}
		}

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x06000606 RID: 1542 RVA: 0x000052D4 File Offset: 0x000034D4
		// (set) Token: 0x06000607 RID: 1543 RVA: 0x0002CBFC File Offset: 0x0002ADFC
		internal virtual MySkin Skin
		{
			[CompilerGenerated]
			get
			{
				return this.m_AnnotationRepository;
			}
			[CompilerGenerated]
			set
			{
				MySkin.ClickEventHandler obj = new MySkin.ClickEventHandler(this.Skin_Click);
				MySkin annotationRepository = this.m_AnnotationRepository;
				if (annotationRepository != null)
				{
					annotationRepository.ResolveResolver(obj);
				}
				this.m_AnnotationRepository = value;
				annotationRepository = this.m_AnnotationRepository;
				if (annotationRepository != null)
				{
					annotationRepository.VerifyResolver(obj);
				}
			}
		}

		// Token: 0x06000608 RID: 1544 RVA: 0x0002CC40 File Offset: 0x0002AE40
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this._InterceptorRepository)
			{
				this._InterceptorRepository = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagelaunch/pageloginmsskin.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000609 RID: 1545 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600060A RID: 1546 RVA: 0x0002CC70 File Offset: 0x0002AE70
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanData = (Grid)target;
				return;
			}
			if (connectionId == 2)
			{
				this.TextName = (TextBlock)target;
				return;
			}
			if (connectionId == 3)
			{
				this.BtnEdit = (MyIconButton)target;
				return;
			}
			if (connectionId == 4)
			{
				this.BtnExit = (MyIconButton)target;
				return;
			}
			if (connectionId == 5)
			{
				this.Skin = (MySkin)target;
				return;
			}
			this._InterceptorRepository = true;
		}

		// Token: 0x040002B2 RID: 690
		private bool m_ExporterRepository;

		// Token: 0x040002B3 RID: 691
		[CompilerGenerated]
		[AccessedThroughProperty("PanData")]
		private Grid m_QueueRepository;

		// Token: 0x040002B4 RID: 692
		[CompilerGenerated]
		[AccessedThroughProperty("TextName")]
		private TextBlock globalRepository;

		// Token: 0x040002B5 RID: 693
		[AccessedThroughProperty("BtnEdit")]
		[CompilerGenerated]
		private MyIconButton _ListRepository;

		// Token: 0x040002B6 RID: 694
		[CompilerGenerated]
		[AccessedThroughProperty("BtnExit")]
		private MyIconButton methodRepository;

		// Token: 0x040002B7 RID: 695
		[CompilerGenerated]
		[AccessedThroughProperty("Skin")]
		private MySkin m_AnnotationRepository;

		// Token: 0x040002B8 RID: 696
		private bool _InterceptorRepository;
	}
}
