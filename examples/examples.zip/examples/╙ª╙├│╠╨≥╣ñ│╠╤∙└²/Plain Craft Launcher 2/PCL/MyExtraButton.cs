﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000045 RID: 69
	[DesignerGenerated]
	public class MyExtraButton : Grid, IComponentConnector
	{
		// Token: 0x06000175 RID: 373 RVA: 0x0001444C File Offset: 0x0001264C
		public MyExtraButton()
		{
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.RefreshColor();
			};
			this.m_Item = ModBase.GetUuid();
			this.m_Mapper = "";
			this.factory = 1.0;
			this.process = false;
			this.m_Val = null;
			this._Utils = false;
			this._Order = false;
			this.policy = false;
			this.InitializeComponent();
		}

		// Token: 0x06000176 RID: 374 RVA: 0x000144C0 File Offset: 0x000126C0
		[CompilerGenerated]
		public void AssetModel(MyExtraButton.ClickEventHandler obj)
		{
			MyExtraButton.ClickEventHandler clickEventHandler = this.reg;
			MyExtraButton.ClickEventHandler clickEventHandler2;
			do
			{
				clickEventHandler2 = clickEventHandler;
				MyExtraButton.ClickEventHandler value = (MyExtraButton.ClickEventHandler)Delegate.Combine(clickEventHandler2, obj);
				clickEventHandler = Interlocked.CompareExchange<MyExtraButton.ClickEventHandler>(ref this.reg, value, clickEventHandler2);
			}
			while (clickEventHandler != clickEventHandler2);
		}

		// Token: 0x06000177 RID: 375 RVA: 0x000144F8 File Offset: 0x000126F8
		[CompilerGenerated]
		public void CreateModel(MyExtraButton.ClickEventHandler obj)
		{
			MyExtraButton.ClickEventHandler clickEventHandler = this.reg;
			MyExtraButton.ClickEventHandler clickEventHandler2;
			do
			{
				clickEventHandler2 = clickEventHandler;
				MyExtraButton.ClickEventHandler value = (MyExtraButton.ClickEventHandler)Delegate.Remove(clickEventHandler2, obj);
				clickEventHandler = Interlocked.CompareExchange<MyExtraButton.ClickEventHandler>(ref this.reg, value, clickEventHandler2);
			}
			while (clickEventHandler != clickEventHandler2);
		}

		// Token: 0x06000178 RID: 376 RVA: 0x00014530 File Offset: 0x00012730
		[CompilerGenerated]
		public void PostModel(MyExtraButton.RightClickEventHandler obj)
		{
			MyExtraButton.RightClickEventHandler rightClickEventHandler = this.invocation;
			MyExtraButton.RightClickEventHandler rightClickEventHandler2;
			do
			{
				rightClickEventHandler2 = rightClickEventHandler;
				MyExtraButton.RightClickEventHandler value = (MyExtraButton.RightClickEventHandler)Delegate.Combine(rightClickEventHandler2, obj);
				rightClickEventHandler = Interlocked.CompareExchange<MyExtraButton.RightClickEventHandler>(ref this.invocation, value, rightClickEventHandler2);
			}
			while (rightClickEventHandler != rightClickEventHandler2);
		}

		// Token: 0x06000179 RID: 377 RVA: 0x00014568 File Offset: 0x00012768
		[CompilerGenerated]
		public void RevertModel(MyExtraButton.RightClickEventHandler obj)
		{
			MyExtraButton.RightClickEventHandler rightClickEventHandler = this.invocation;
			MyExtraButton.RightClickEventHandler rightClickEventHandler2;
			do
			{
				rightClickEventHandler2 = rightClickEventHandler;
				MyExtraButton.RightClickEventHandler value = (MyExtraButton.RightClickEventHandler)Delegate.Remove(rightClickEventHandler2, obj);
				rightClickEventHandler = Interlocked.CompareExchange<MyExtraButton.RightClickEventHandler>(ref this.invocation, value, rightClickEventHandler2);
			}
			while (rightClickEventHandler != rightClickEventHandler2);
		}

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x0600017A RID: 378 RVA: 0x00002FE0 File Offset: 0x000011E0
		// (set) Token: 0x0600017B RID: 379 RVA: 0x00002FE8 File Offset: 0x000011E8
		public string Logo
		{
			get
			{
				return this.m_Mapper;
			}
			set
			{
				if (Operators.CompareString(value, this.m_Mapper, true) != 0)
				{
					this.m_Mapper = value;
					this.Path.Data = (Geometry)new GeometryConverter().ConvertFromString(value);
				}
			}
		}

		// Token: 0x0600017C RID: 380 RVA: 0x0000301B File Offset: 0x0000121B
		public double CalcModel()
		{
			return this.factory;
		}

		// Token: 0x0600017D RID: 381 RVA: 0x00003023 File Offset: 0x00001223
		public void RegisterModel(double value)
		{
			this.factory = value;
			if (!Information.IsNothing(this.Path))
			{
				this.Path.RenderTransform = new ScaleTransform
				{
					ScaleX = this.CalcModel(),
					ScaleY = this.CalcModel()
				};
			}
		}

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x0600017E RID: 382 RVA: 0x00003061 File Offset: 0x00001261
		// (set) Token: 0x0600017F RID: 383 RVA: 0x000145A0 File Offset: 0x000127A0
		public bool Show
		{
			get
			{
				return this.process;
			}
			set
			{
				if (this.process != value)
				{
					this.process = value;
					ModBase.RunInUi(delegate()
					{
						if (value)
						{
							this.Visibility = Visibility.Visible;
							ModAnimation.AniStart(new ModAnimation.AniData[]
							{
								ModAnimation.AaScaleTransform(this, 0.3 - ((ScaleTransform)this.RenderTransform).ScaleX, 500, 60, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Weak), false),
								ModAnimation.AaScaleTransform(this, 0.7, 500, 60, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Weak), false),
								ModAnimation.AaHeight(this, 50.0 - this.Height, 200, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Weak), false)
							}, "MyExtraButton MainScale " + Conversions.ToString(this.m_Item), false);
						}
						else
						{
							ModAnimation.AniStart(new ModAnimation.AniData[]
							{
								ModAnimation.AaScaleTransform(this, -((ScaleTransform)this.RenderTransform).ScaleX, 100, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Weak), false),
								ModAnimation.AaHeight(this, -this.Height, 400, 100, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
								ModAnimation.AaCode(delegate
								{
									base.Visibility = Visibility.Collapsed;
								}, 0, true)
							}, "MyExtraButton MainScale " + Conversions.ToString(this.m_Item), false);
						}
						this.IsHitTestVisible = value;
					}, false);
				}
			}
		}

		// Token: 0x06000180 RID: 384 RVA: 0x00003069 File Offset: 0x00001269
		public void ShowRefresh()
		{
			if (this.m_Val != null)
			{
				this.Show = this.m_Val();
			}
		}

		// Token: 0x06000181 RID: 385 RVA: 0x000145F0 File Offset: 0x000127F0
		private void Button_LeftMouseUp(object sender, MouseButtonEventArgs e)
		{
			if (this._Order)
			{
				ModBase.Log("[Control] 按下附加按钮" + (Operators.ConditionalCompareObjectEqual(base.ToolTip, "", true) ? "" : ("：" + base.ToolTip.ToString())), ModBase.LogLevel.Normal, "出现错误");
				MyExtraButton.ClickEventHandler clickEventHandler = this.reg;
				if (clickEventHandler != null)
				{
					clickEventHandler(RuntimeHelpers.GetObjectValue(sender), e);
				}
				e.Handled = true;
				this.Button_LeftMouseUp();
			}
		}

		// Token: 0x06000182 RID: 386 RVA: 0x00014670 File Offset: 0x00012870
		private void Button_RightMouseUp(object sender, MouseButtonEventArgs e)
		{
			if (this.policy)
			{
				ModBase.Log("[Control] 右键按下附加按钮" + (Operators.ConditionalCompareObjectEqual(base.ToolTip, "", true) ? "" : ("：" + base.ToolTip.ToString())), ModBase.LogLevel.Normal, "出现错误");
				MyExtraButton.RightClickEventHandler rightClickEventHandler = this.invocation;
				if (rightClickEventHandler != null)
				{
					rightClickEventHandler(RuntimeHelpers.GetObjectValue(sender), e);
				}
				e.Handled = true;
				this.Button_RightMouseUp();
			}
		}

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x06000183 RID: 387 RVA: 0x00003084 File Offset: 0x00001284
		// (set) Token: 0x06000184 RID: 388 RVA: 0x0000308C File Offset: 0x0000128C
		public bool CanRightClick
		{
			get
			{
				return this._Utils;
			}
			set
			{
				this._Utils = value;
			}
		}

		// Token: 0x06000185 RID: 389 RVA: 0x000146F0 File Offset: 0x000128F0
		private void Button_LeftMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!this._Order && !this.policy)
			{
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaScaleTransform(this.PanScale, 0.85 - ((ScaleTransform)this.PanScale.RenderTransform).ScaleX, 800, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false),
					ModAnimation.AaScaleTransform(this.PanScale, -0.05, 60, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false)
				}, "MyExtraButton Scale " + Conversions.ToString(this.m_Item), false);
			}
			this._Order = true;
			base.Focus();
		}

		// Token: 0x06000186 RID: 390 RVA: 0x000147A8 File Offset: 0x000129A8
		private void Button_RightMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.CanRightClick)
			{
				if (!this._Order && !this.policy)
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaScaleTransform(this.PanScale, 0.85 - ((ScaleTransform)this.PanScale.RenderTransform).ScaleX, 800, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Strong), false),
						ModAnimation.AaScaleTransform(this.PanScale, -0.05, 60, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false)
					}, "MyExtraButton Scale " + Conversions.ToString(this.m_Item), false);
				}
				this.policy = true;
				base.Focus();
			}
		}

		// Token: 0x06000187 RID: 391 RVA: 0x00014868 File Offset: 0x00012A68
		private void Button_LeftMouseUp()
		{
			if (!this.policy)
			{
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaScaleTransform(this.PanScale, 1.0 - ((ScaleTransform)this.PanScale.RenderTransform).ScaleX, 300, 0, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Middle), false)
				}, "MyExtraButton Scale " + Conversions.ToString(this.m_Item), false);
			}
			this._Order = false;
			this.RefreshColor();
		}

		// Token: 0x06000188 RID: 392 RVA: 0x000148EC File Offset: 0x00012AEC
		private void Button_RightMouseUp()
		{
			if (this.CanRightClick)
			{
				if (!this._Order)
				{
					ModAnimation.AniStart(new ModAnimation.AniData[]
					{
						ModAnimation.AaScaleTransform(this.PanScale, 1.0 - ((ScaleTransform)this.PanScale.RenderTransform).ScaleX, 300, 0, new ModAnimation.AniEaseOutBack(ModAnimation.AniEasePower.Middle), false)
					}, "MyExtraButton Scale " + Conversions.ToString(this.m_Item), false);
				}
				this.policy = false;
				this.RefreshColor();
			}
		}

		// Token: 0x06000189 RID: 393 RVA: 0x00014978 File Offset: 0x00012B78
		private void Button_MouseLeave()
		{
			this._Order = false;
			this.policy = false;
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaScaleTransform(this.PanScale, 1.0 - ((ScaleTransform)this.PanScale.RenderTransform).ScaleX, 500, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false)
			}, "MyExtraButton Scale " + Conversions.ToString(this.m_Item), false);
			this.RefreshColor();
		}

		// Token: 0x0600018A RID: 394 RVA: 0x000149F8 File Offset: 0x00012BF8
		public void RefreshColor()
		{
			try
			{
				if (base.IsLoaded && ModAnimation.DefineModel() == 0)
				{
					if (base.IsMouseOver)
					{
						ModAnimation.AniStart(ModAnimation.AaColor(this.PanColor, Panel.BackgroundProperty, "ColorBrush4", 120, 0, null, false), "MyExtraButton Color " + Conversions.ToString(this.m_Item), false);
					}
					else
					{
						ModAnimation.AniStart(ModAnimation.AaColor(this.PanColor, Panel.BackgroundProperty, "ColorBrush3", 150, 0, null, false), "MyExtraButton Color " + Conversions.ToString(this.m_Item), false);
					}
				}
				else
				{
					ModAnimation.AniStop("MyExtraButton Color " + Conversions.ToString(this.m_Item));
					if (base.IsMouseOver)
					{
						this.PanColor.SetResourceReference(Panel.BackgroundProperty, "ColorBrush2");
					}
					else
					{
						this.PanColor.SetResourceReference(Panel.BackgroundProperty, "ColorBrush3");
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "刷新图标按钮颜色出错", ModBase.LogLevel.Debug, "出现错误");
			}
		}

		// Token: 0x0600018B RID: 395 RVA: 0x00003095 File Offset: 0x00001295
		public void Ribble()
		{
			ModBase.RunInUi(delegate()
			{
				Border Shape = new Border
				{
					CornerRadius = new CornerRadius(1000.0),
					BorderThickness = new Thickness(0.001),
					Opacity = 0.5,
					RenderTransformOrigin = new Point(0.5, 0.5),
					RenderTransform = new ScaleTransform()
				};
				Shape.SetResourceReference(Border.BackgroundProperty, "ColorBrush5");
				this.PanScale.Children.Insert(0, Shape);
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaScaleTransform(Shape, 13.0, 1000, 0, new ModAnimation.AniEaseInoutFluent(ModAnimation.AniEasePower.Strong, 0.3), false),
					ModAnimation.AaOpacity(Shape, -Shape.Opacity, 1000, 0, null, false),
					ModAnimation.AaCode(delegate
					{
						this.PanScale.Children.Remove(Shape);
					}, 0, true)
				}, "ExtraButton Ribble " + Conversions.ToString(ModBase.GetUuid()), false);
			}, false);
		}

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x0600018C RID: 396 RVA: 0x000030A9 File Offset: 0x000012A9
		// (set) Token: 0x0600018D RID: 397 RVA: 0x000030B1 File Offset: 0x000012B1
		internal virtual MyExtraButton PanBack { get; set; }

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x0600018E RID: 398 RVA: 0x000030BA File Offset: 0x000012BA
		// (set) Token: 0x0600018F RID: 399 RVA: 0x00014B14 File Offset: 0x00012D14
		internal virtual Border PanClick
		{
			[CompilerGenerated]
			get
			{
				return this._Customer;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = new MouseButtonEventHandler(this.Button_LeftMouseUp);
				MouseButtonEventHandler value3 = new MouseButtonEventHandler(this.Button_RightMouseUp);
				MouseButtonEventHandler value4 = new MouseButtonEventHandler(this.Button_LeftMouseDown);
				MouseButtonEventHandler value5 = new MouseButtonEventHandler(this.Button_RightMouseDown);
				MouseButtonEventHandler value6 = delegate(object sender, MouseButtonEventArgs e)
				{
					this.Button_LeftMouseUp();
				};
				MouseButtonEventHandler value7 = delegate(object sender, MouseButtonEventArgs e)
				{
					this.Button_RightMouseUp();
				};
				MouseEventHandler value8 = delegate(object sender, MouseEventArgs e)
				{
					this.Button_MouseLeave();
				};
				MouseEventHandler value9 = delegate(object sender, MouseEventArgs e)
				{
					this.RefreshColor();
				};
				MouseEventHandler value10 = delegate(object sender, MouseEventArgs e)
				{
					this.RefreshColor();
				};
				Border customer = this._Customer;
				if (customer != null)
				{
					customer.MouseLeftButtonUp -= value2;
					customer.MouseRightButtonUp -= value3;
					customer.MouseLeftButtonDown -= value4;
					customer.MouseRightButtonDown -= value5;
					customer.MouseLeftButtonUp -= value6;
					customer.MouseRightButtonUp -= value7;
					customer.MouseLeave -= value8;
					customer.MouseEnter -= value9;
					customer.MouseLeave -= value10;
				}
				this._Customer = value;
				customer = this._Customer;
				if (customer != null)
				{
					customer.MouseLeftButtonUp += value2;
					customer.MouseRightButtonUp += value3;
					customer.MouseLeftButtonDown += value4;
					customer.MouseRightButtonDown += value5;
					customer.MouseLeftButtonUp += value6;
					customer.MouseRightButtonUp += value7;
					customer.MouseLeave += value8;
					customer.MouseEnter += value9;
					customer.MouseLeave += value10;
				}
			}
		}

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x06000190 RID: 400 RVA: 0x000030C2 File Offset: 0x000012C2
		// (set) Token: 0x06000191 RID: 401 RVA: 0x000030CA File Offset: 0x000012CA
		internal virtual Grid PanScale { get; set; }

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x06000192 RID: 402 RVA: 0x000030D3 File Offset: 0x000012D3
		// (set) Token: 0x06000193 RID: 403 RVA: 0x000030DB File Offset: 0x000012DB
		internal virtual Border PanColor { get; set; }

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x06000194 RID: 404 RVA: 0x000030E4 File Offset: 0x000012E4
		// (set) Token: 0x06000195 RID: 405 RVA: 0x000030EC File Offset: 0x000012EC
		internal virtual Path Path { get; set; }

		// Token: 0x06000196 RID: 406 RVA: 0x00014C54 File Offset: 0x00012E54
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.advisor)
			{
				this.advisor = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/controls/myextrabutton.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000197 RID: 407 RVA: 0x00014C84 File Offset: 0x00012E84
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyExtraButton)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanClick = (Border)target;
				return;
			}
			if (connectionId == 3)
			{
				this.PanScale = (Grid)target;
				return;
			}
			if (connectionId == 4)
			{
				this.PanColor = (Border)target;
				return;
			}
			if (connectionId == 5)
			{
				this.Path = (Path)target;
				return;
			}
			this.advisor = true;
		}

		// Token: 0x040000BF RID: 191
		[CompilerGenerated]
		private MyExtraButton.ClickEventHandler reg;

		// Token: 0x040000C0 RID: 192
		[CompilerGenerated]
		private MyExtraButton.RightClickEventHandler invocation;

		// Token: 0x040000C1 RID: 193
		public int m_Item;

		// Token: 0x040000C2 RID: 194
		private string m_Mapper;

		// Token: 0x040000C3 RID: 195
		private double factory;

		// Token: 0x040000C4 RID: 196
		private bool process;

		// Token: 0x040000C5 RID: 197
		public MyExtraButton.ShowCheckDelegate m_Val;

		// Token: 0x040000C6 RID: 198
		private bool _Utils;

		// Token: 0x040000C7 RID: 199
		private bool _Order;

		// Token: 0x040000C8 RID: 200
		private bool policy;

		// Token: 0x040000C9 RID: 201
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyExtraButton thread;

		// Token: 0x040000CA RID: 202
		[CompilerGenerated]
		[AccessedThroughProperty("PanClick")]
		private Border _Customer;

		// Token: 0x040000CB RID: 203
		[CompilerGenerated]
		[AccessedThroughProperty("PanScale")]
		private Grid schema;

		// Token: 0x040000CC RID: 204
		[AccessedThroughProperty("PanColor")]
		[CompilerGenerated]
		private Border _Database;

		// Token: 0x040000CD RID: 205
		[CompilerGenerated]
		[AccessedThroughProperty("Path")]
		private Path _Callback;

		// Token: 0x040000CE RID: 206
		private bool advisor;

		// Token: 0x02000046 RID: 70
		// (Invoke) Token: 0x060001A4 RID: 420
		public delegate void ClickEventHandler(object sender, MouseButtonEventArgs e);

		// Token: 0x02000047 RID: 71
		// (Invoke) Token: 0x060001A9 RID: 425
		public delegate void RightClickEventHandler(object sender, MouseButtonEventArgs e);

		// Token: 0x02000048 RID: 72
		// (Invoke) Token: 0x060001AE RID: 430
		public delegate bool ShowCheckDelegate();
	}
}
