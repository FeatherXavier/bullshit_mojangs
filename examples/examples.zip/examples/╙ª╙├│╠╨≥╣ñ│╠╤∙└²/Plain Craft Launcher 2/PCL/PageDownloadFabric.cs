﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;
using Newtonsoft.Json.Linq;

namespace PCL
{
	// Token: 0x02000090 RID: 144
	[DesignerGenerated]
	public class PageDownloadFabric : MyPageRight, IComponentConnector
	{
		// Token: 0x0600043E RID: 1086 RVA: 0x000042B3 File Offset: 0x000024B3
		public PageDownloadFabric()
		{
			base.Initialized += delegate(object sender, EventArgs e)
			{
				this.LoaderInit();
			};
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.Init();
			};
			this.InitializeComponent();
		}

		// Token: 0x0600043F RID: 1087 RVA: 0x000266F4 File Offset: 0x000248F4
		private void LoaderInit()
		{
			base.PageLoaderInit(this.Load, this.PanLoad, this.CardVersions, this.CardTip, ModDownload.m_ValueTag, delegate(ModLoader.LoaderBase a0)
			{
				this.Load_OnFinish();
			}, null, true);
		}

		// Token: 0x06000440 RID: 1088 RVA: 0x000042E6 File Offset: 0x000024E6
		private void Init()
		{
			this.PanBack.ScrollToHome();
		}

		// Token: 0x06000441 RID: 1089 RVA: 0x00026734 File Offset: 0x00024934
		private void Load_OnFinish()
		{
			try
			{
				JArray jarray = (JArray)ModDownload.m_ValueTag.Output.Value["installer"];
				this.PanVersions.Children.Clear();
				try
				{
					foreach (JToken jtoken in jarray)
					{
						this.PanVersions.Children.Add(ModDownloadLib.FabricDownloadListItem((JObject)jtoken, delegate(object sender, MouseButtonEventArgs e)
						{
							this.Fabric_Selected((MyListItem)sender, e);
						}));
					}
				}
				finally
				{
					IEnumerator<JToken> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				this.CardVersions.Title = "版本列表 (" + Conversions.ToString(jarray.Count) + ")";
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "可视化 Fabric 版本列表出错", ModBase.LogLevel.Feedback, "出现错误");
			}
		}

		// Token: 0x06000442 RID: 1090 RVA: 0x000042F3 File Offset: 0x000024F3
		private void Fabric_Selected(MyListItem sender, EventArgs e)
		{
			ModDownloadLib.McDownloadFabricLoaderSave((JObject)sender.Tag);
		}

		// Token: 0x06000443 RID: 1091 RVA: 0x00004305 File Offset: 0x00002505
		private void BtnWeb_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://www.fabricmc.net");
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x06000444 RID: 1092 RVA: 0x00004311 File Offset: 0x00002511
		// (set) Token: 0x06000445 RID: 1093 RVA: 0x00004319 File Offset: 0x00002519
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x06000446 RID: 1094 RVA: 0x00004322 File Offset: 0x00002522
		// (set) Token: 0x06000447 RID: 1095 RVA: 0x0000432A File Offset: 0x0000252A
		internal virtual MyCard CardTip { get; set; }

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x06000448 RID: 1096 RVA: 0x00004333 File Offset: 0x00002533
		// (set) Token: 0x06000449 RID: 1097 RVA: 0x00026820 File Offset: 0x00024A20
		internal virtual MyButton BtnWeb
		{
			[CompilerGenerated]
			get
			{
				return this.m_ManagerWrapper;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnWeb_Click);
				MyButton managerWrapper = this.m_ManagerWrapper;
				if (managerWrapper != null)
				{
					managerWrapper.RevertResolver(obj);
				}
				this.m_ManagerWrapper = value;
				managerWrapper = this.m_ManagerWrapper;
				if (managerWrapper != null)
				{
					managerWrapper.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x0600044A RID: 1098 RVA: 0x0000433B File Offset: 0x0000253B
		// (set) Token: 0x0600044B RID: 1099 RVA: 0x00004343 File Offset: 0x00002543
		internal virtual MyCard CardVersions { get; set; }

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x0600044C RID: 1100 RVA: 0x0000434C File Offset: 0x0000254C
		// (set) Token: 0x0600044D RID: 1101 RVA: 0x00004354 File Offset: 0x00002554
		internal virtual StackPanel PanVersions { get; set; }

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x0600044E RID: 1102 RVA: 0x0000435D File Offset: 0x0000255D
		// (set) Token: 0x0600044F RID: 1103 RVA: 0x00004365 File Offset: 0x00002565
		internal virtual MyCard PanLoad { get; set; }

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x06000450 RID: 1104 RVA: 0x0000436E File Offset: 0x0000256E
		// (set) Token: 0x06000451 RID: 1105 RVA: 0x00004376 File Offset: 0x00002576
		internal virtual MyLoading Load { get; set; }

		// Token: 0x06000452 RID: 1106 RVA: 0x00026864 File Offset: 0x00024A64
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.globalWrapper)
			{
				this.globalWrapper = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagedownload/pagedownloadfabric.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000453 RID: 1107 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x00026894 File Offset: 0x00024A94
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.CardTip = (MyCard)target;
				return;
			}
			if (connectionId == 3)
			{
				this.BtnWeb = (MyButton)target;
				return;
			}
			if (connectionId == 4)
			{
				this.CardVersions = (MyCard)target;
				return;
			}
			if (connectionId == 5)
			{
				this.PanVersions = (StackPanel)target;
				return;
			}
			if (connectionId == 6)
			{
				this.PanLoad = (MyCard)target;
				return;
			}
			if (connectionId == 7)
			{
				this.Load = (MyLoading)target;
				return;
			}
			this.globalWrapper = true;
		}

		// Token: 0x04000218 RID: 536
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyScrollViewer configurationWrapper;

		// Token: 0x04000219 RID: 537
		[AccessedThroughProperty("CardTip")]
		[CompilerGenerated]
		private MyCard m_ConfigWrapper;

		// Token: 0x0400021A RID: 538
		[CompilerGenerated]
		[AccessedThroughProperty("BtnWeb")]
		private MyButton m_ManagerWrapper;

		// Token: 0x0400021B RID: 539
		[AccessedThroughProperty("CardVersions")]
		[CompilerGenerated]
		private MyCard _RuleWrapper;

		// Token: 0x0400021C RID: 540
		[CompilerGenerated]
		[AccessedThroughProperty("PanVersions")]
		private StackPanel m_MerchantWrapper;

		// Token: 0x0400021D RID: 541
		[AccessedThroughProperty("PanLoad")]
		[CompilerGenerated]
		private MyCard exporterWrapper;

		// Token: 0x0400021E RID: 542
		[CompilerGenerated]
		[AccessedThroughProperty("Load")]
		private MyLoading queueWrapper;

		// Token: 0x0400021F RID: 543
		private bool globalWrapper;
	}
}
