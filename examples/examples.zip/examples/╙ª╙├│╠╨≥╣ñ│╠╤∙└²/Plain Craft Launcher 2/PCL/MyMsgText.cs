﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000179 RID: 377
	[DesignerGenerated]
	public class MyMsgText : Grid, IComponentConnector
	{
		// Token: 0x06001167 RID: 4455 RVA: 0x00076050 File Offset: 0x00074250
		public MyMsgText(ModMain.MyMsgBoxConverter Converter)
		{
			base.Loaded += new RoutedEventHandler(this.Load);
			this.m_IdentifierRequest = ModBase.GetUuid();
			try
			{
				this.InitializeComponent();
				this.Btn1.Name = this.Btn1.Name + Conversions.ToString(ModBase.GetUuid());
				this.Btn2.Name = this.Btn2.Name + Conversions.ToString(ModBase.GetUuid());
				this.Btn3.Name = this.Btn3.Name + Conversions.ToString(ModBase.GetUuid());
				this.m_ListenerRequest = Converter;
				this.LabTitle.Text = Converter.Title;
				this.LabCaption.Text = Conversions.ToString(Converter.m_ComposerParameter);
				this.Btn1.Text = Converter._ProcessParameter;
				if (Converter.m_OrderParameter)
				{
					this.Btn1.ColorType = MyButton.ColorState.Red;
					this.LabTitle.SetResourceReference(TextBlock.ForegroundProperty, "ColorBrushRedLight");
					this.ShapeLine.SetResourceReference(Shape.FillProperty, "ColorBrushRedLight");
				}
				this.Btn2.Text = Converter._ValParameter;
				this.Btn3.Text = Converter.utilsParameter;
				this.Btn2.Visibility = ((Operators.CompareString(Converter._ValParameter, "", true) == 0) ? Visibility.Collapsed : Visibility.Visible);
				this.Btn3.Visibility = ((Operators.CompareString(Converter.utilsParameter, "", true) == 0) ? Visibility.Collapsed : Visibility.Visible);
				this.ShapeLine.StrokeThickness = ModBase.smethod_4(1.0);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "普通弹窗初始化失败", ModBase.LogLevel.Hint, "出现错误");
			}
		}

		// Token: 0x06001168 RID: 4456 RVA: 0x00076230 File Offset: 0x00074430
		private void Load(object sender, EventArgs e)
		{
			try
			{
				if (this.Btn2.IsVisible && this.Btn1.ColorType != MyButton.ColorState.Red)
				{
					this.Btn1.ColorType = MyButton.ColorState.Highlight;
				}
				base.Measure(new Size(ModMain.m_CollectionAccount.Width - 20.0, ModMain.m_CollectionAccount.Height - 20.0));
				base.Arrange(new Rect(0.0, 0.0, ModMain.m_CollectionAccount.Width - 20.0, ModMain.m_CollectionAccount.Height - 20.0));
				this.Btn1.Focus();
				ModAnimation.AniStart(new ModAnimation.AniData[]
				{
					ModAnimation.AaColor(ModMain.m_CollectionAccount.PanMsg, Panel.BackgroundProperty, new ModBase.MyColor(60.0, 0.0, 0.0, 0.0), 250, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaColor(this.PanBorder, Border.BackgroundProperty, new ModBase.MyColor(255.0, 0.0, 0.0, 0.0), 150, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaOpacity(this.EffectShadow, 0.75, 400, 50, null, false),
					ModAnimation.AaWidth(this.ShapeLine, this.ShapeLine.ActualWidth, 250, 100, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaOpacity(this.ShapeLine, 1.0, 200, 100, null, false),
					ModAnimation.AaWidth(this.LabTitle, this.LabTitle.ActualWidth, 200, 150, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
					ModAnimation.AaOpacity(this.LabTitle, 1.0, 150, 150, null, false),
					ModAnimation.AaOpacity(this.PanCaption, 1.0, 150, 150, null, false),
					ModAnimation.AaOpacity(this.Btn1, 1.0, 150, 100, null, false),
					ModAnimation.AaOpacity(this.Btn2, 1.0, 150, 150, null, false),
					ModAnimation.AaOpacity(this.Btn3, 1.0, 150, 200, null, false),
					ModAnimation.AaCode(delegate
					{
						this.ShapeLine.MinWidth = this.ShapeLine.ActualWidth;
						this.ShapeLine.HorizontalAlignment = HorizontalAlignment.Stretch;
						this.ShapeLine.Width = double.NaN;
						this.LabTitle.Width = double.NaN;
						this.LabTitle.TextTrimming = TextTrimming.CharacterEllipsis;
					}, 350, false)
				}, "MyMsgBox Start " + Conversions.ToString(this.m_IdentifierRequest), false);
				this.ShapeLine.Width = 0.0;
				this.ShapeLine.HorizontalAlignment = HorizontalAlignment.Center;
				this.LabTitle.Width = 0.0;
				this.LabTitle.Opacity = 0.0;
				this.LabTitle.TextWrapping = TextWrapping.NoWrap;
				this.PanCaption.Opacity = 0.0;
				ModBase.Log("[Control] 普通弹窗：" + this.LabTitle.Text + "\r\n" + this.LabCaption.Text, ModBase.LogLevel.Normal, "出现错误");
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "普通弹窗加载失败", ModBase.LogLevel.Hint, "出现错误");
			}
		}

		// Token: 0x06001169 RID: 4457 RVA: 0x00076600 File Offset: 0x00074800
		private void Close()
		{
			if (this.m_ListenerRequest._PolicyParameter || Operators.CompareString(this.m_ListenerRequest._ValParameter, "", true) != 0)
			{
				this.m_ListenerRequest.m_ThreadParameter.Continue = false;
			}
			ComponentDispatcher.PopModal();
			this.LabTitle.TextTrimming = TextTrimming.None;
			this.LabTitle.TextWrapping = TextWrapping.NoWrap;
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaColor(ModMain.m_CollectionAccount.PanMsg, Panel.BackgroundProperty, new ModBase.MyColor(-60.0, 0.0, 0.0, 0.0), 350, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaColor(this.PanBorder, Border.BackgroundProperty, new ModBase.MyColor(-255.0, 0.0, 0.0, 0.0), 300, 100, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaOpacity(this.EffectShadow, -0.75, 150, 0, null, false),
				ModAnimation.AaWidth(this.ShapeLine, -this.ShapeLine.ActualWidth, 250, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Weak), false),
				ModAnimation.AaOpacity(this.ShapeLine, -1.0, 200, 0, null, false),
				ModAnimation.AaWidth(this.LabTitle, -this.LabTitle.ActualWidth, 250, 0, null, false),
				ModAnimation.AaOpacity(this.LabTitle, -1.0, 200, 0, null, false),
				ModAnimation.AaOpacity(this.PanCaption, -1.0, 200, 0, null, false),
				ModAnimation.AaOpacity(this.Btn1, -1.0, 150, 0, null, false),
				ModAnimation.AaOpacity(this.Btn2, -1.0, 150, 50, null, false),
				ModAnimation.AaOpacity(this.Btn3, -1.0, 150, 100, null, false),
				ModAnimation.AaCode(delegate
				{
					((Grid)base.Parent).Children.Remove(this);
				}, 0, true)
			}, "MyMsgBox Close " + Conversions.ToString(this.m_IdentifierRequest), false);
			this.ShapeLine.MinWidth = 0.0;
		}

		// Token: 0x0600116A RID: 4458 RVA: 0x0000A41D File Offset: 0x0000861D
		public void Btn1_Click()
		{
			if (!this.m_ListenerRequest.connectionParameter)
			{
				this.m_ListenerRequest.connectionParameter = true;
				this.m_ListenerRequest._CustomerParameter = 1;
				this.Close();
			}
		}

		// Token: 0x0600116B RID: 4459 RVA: 0x0000A44F File Offset: 0x0000864F
		private void Btn2_Click()
		{
			if (!this.m_ListenerRequest.connectionParameter)
			{
				this.m_ListenerRequest.connectionParameter = true;
				this.m_ListenerRequest._CustomerParameter = 2;
				this.Close();
			}
		}

		// Token: 0x0600116C RID: 4460 RVA: 0x0000A481 File Offset: 0x00008681
		private void Btn3_Click()
		{
			if (!this.m_ListenerRequest.connectionParameter)
			{
				this.m_ListenerRequest.connectionParameter = true;
				this.m_ListenerRequest._CustomerParameter = 3;
				this.Close();
			}
		}

		// Token: 0x0600116D RID: 4461 RVA: 0x0007689C File Offset: 0x00074A9C
		private void Drag(object sender, MouseButtonEventArgs e)
		{
			int num;
			int num4;
			object obj;
			try
			{
				IL_00:
				ProjectData.ClearProjectError();
				num = 1;
				IL_07:
				int num2 = 2;
				if (e.GetPosition(this.ShapeLine).Y > 2.0)
				{
					goto IL_34;
				}
				IL_28:
				num2 = 3;
				ModMain.m_CollectionAccount.DragMove();
				IL_34:
				goto IL_93;
				IL_36:
				int num3 = num4 + 1;
				num4 = 0;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
				IL_54:
				goto IL_88;
				IL_56:
				num4 = num2;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
				IL_66:;
			}
			catch when (endfilter(obj is Exception & num != 0 & num4 == 0))
			{
				Exception ex = (Exception)obj2;
				goto IL_56;
			}
			IL_88:
			throw ProjectData.CreateProjectError(-2146828237);
			IL_93:
			if (num4 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		// Token: 0x170002FF RID: 767
		// (get) Token: 0x0600116E RID: 4462 RVA: 0x0000A4B3 File Offset: 0x000086B3
		// (set) Token: 0x0600116F RID: 4463 RVA: 0x0000A4BB File Offset: 0x000086BB
		internal virtual MyMsgText PanBack { get; set; }

		// Token: 0x17000300 RID: 768
		// (get) Token: 0x06001170 RID: 4464 RVA: 0x0000A4C4 File Offset: 0x000086C4
		// (set) Token: 0x06001171 RID: 4465 RVA: 0x00076954 File Offset: 0x00074B54
		internal virtual Border PanBorder
		{
			[CompilerGenerated]
			get
			{
				return this._CreatorRequest;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = new MouseButtonEventHandler(this.Drag);
				Border creatorRequest = this._CreatorRequest;
				if (creatorRequest != null)
				{
					creatorRequest.MouseLeftButtonDown -= value2;
				}
				this._CreatorRequest = value;
				creatorRequest = this._CreatorRequest;
				if (creatorRequest != null)
				{
					creatorRequest.MouseLeftButtonDown += value2;
				}
			}
		}

		// Token: 0x17000301 RID: 769
		// (get) Token: 0x06001172 RID: 4466 RVA: 0x0000A4CC File Offset: 0x000086CC
		// (set) Token: 0x06001173 RID: 4467 RVA: 0x0000A4D4 File Offset: 0x000086D4
		internal virtual DropShadowEffect EffectShadow { get; set; }

		// Token: 0x17000302 RID: 770
		// (get) Token: 0x06001174 RID: 4468 RVA: 0x0000A4DD File Offset: 0x000086DD
		// (set) Token: 0x06001175 RID: 4469 RVA: 0x00076998 File Offset: 0x00074B98
		internal virtual TextBlock LabTitle
		{
			[CompilerGenerated]
			get
			{
				return this.regRequest;
			}
			[CompilerGenerated]
			set
			{
				MouseButtonEventHandler value2 = new MouseButtonEventHandler(this.Drag);
				TextBlock textBlock = this.regRequest;
				if (textBlock != null)
				{
					textBlock.MouseLeftButtonDown -= value2;
				}
				this.regRequest = value;
				textBlock = this.regRequest;
				if (textBlock != null)
				{
					textBlock.MouseLeftButtonDown += value2;
				}
			}
		}

		// Token: 0x17000303 RID: 771
		// (get) Token: 0x06001176 RID: 4470 RVA: 0x0000A4E5 File Offset: 0x000086E5
		// (set) Token: 0x06001177 RID: 4471 RVA: 0x0000A4ED File Offset: 0x000086ED
		internal virtual Rectangle ShapeLine { get; set; }

		// Token: 0x17000304 RID: 772
		// (get) Token: 0x06001178 RID: 4472 RVA: 0x0000A4F6 File Offset: 0x000086F6
		// (set) Token: 0x06001179 RID: 4473 RVA: 0x0000A4FE File Offset: 0x000086FE
		internal virtual MyScrollViewer PanCaption { get; set; }

		// Token: 0x17000305 RID: 773
		// (get) Token: 0x0600117A RID: 4474 RVA: 0x0000A507 File Offset: 0x00008707
		// (set) Token: 0x0600117B RID: 4475 RVA: 0x0000A50F File Offset: 0x0000870F
		internal virtual TextBlock LabCaption { get; set; }

		// Token: 0x17000306 RID: 774
		// (get) Token: 0x0600117C RID: 4476 RVA: 0x0000A518 File Offset: 0x00008718
		// (set) Token: 0x0600117D RID: 4477 RVA: 0x0000A520 File Offset: 0x00008720
		internal virtual StackPanel PanBtn { get; set; }

		// Token: 0x17000307 RID: 775
		// (get) Token: 0x0600117E RID: 4478 RVA: 0x0000A529 File Offset: 0x00008729
		// (set) Token: 0x0600117F RID: 4479 RVA: 0x000769DC File Offset: 0x00074BDC
		internal virtual MyButton Btn1
		{
			[CompilerGenerated]
			get
			{
				return this._FactoryRequest;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.Btn1_Click();
				};
				MyButton factoryRequest = this._FactoryRequest;
				if (factoryRequest != null)
				{
					factoryRequest.RevertResolver(obj);
				}
				this._FactoryRequest = value;
				factoryRequest = this._FactoryRequest;
				if (factoryRequest != null)
				{
					factoryRequest.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000308 RID: 776
		// (get) Token: 0x06001180 RID: 4480 RVA: 0x0000A531 File Offset: 0x00008731
		// (set) Token: 0x06001181 RID: 4481 RVA: 0x00076A20 File Offset: 0x00074C20
		internal virtual MyButton Btn2
		{
			[CompilerGenerated]
			get
			{
				return this.m_ProcessRequest;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.Btn2_Click();
				};
				MyButton processRequest = this.m_ProcessRequest;
				if (processRequest != null)
				{
					processRequest.RevertResolver(obj);
				}
				this.m_ProcessRequest = value;
				processRequest = this.m_ProcessRequest;
				if (processRequest != null)
				{
					processRequest.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000309 RID: 777
		// (get) Token: 0x06001182 RID: 4482 RVA: 0x0000A539 File Offset: 0x00008739
		// (set) Token: 0x06001183 RID: 4483 RVA: 0x00076A64 File Offset: 0x00074C64
		internal virtual MyButton Btn3
		{
			[CompilerGenerated]
			get
			{
				return this.valRequest;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.Btn3_Click();
				};
				MyButton myButton = this.valRequest;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.valRequest = value;
				myButton = this.valRequest;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x06001184 RID: 4484 RVA: 0x00076AA8 File Offset: 0x00074CA8
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.utilsRequest)
			{
				this.utilsRequest = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/controls/mymsg/mymsgtext.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06001185 RID: 4485 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06001186 RID: 4486 RVA: 0x00076AD8 File Offset: 0x00074CD8
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyMsgText)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanBorder = (Border)target;
				return;
			}
			if (connectionId == 3)
			{
				this.EffectShadow = (DropShadowEffect)target;
				return;
			}
			if (connectionId == 4)
			{
				this.LabTitle = (TextBlock)target;
				return;
			}
			if (connectionId == 5)
			{
				this.ShapeLine = (Rectangle)target;
				return;
			}
			if (connectionId == 6)
			{
				this.PanCaption = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 7)
			{
				this.LabCaption = (TextBlock)target;
				return;
			}
			if (connectionId == 8)
			{
				this.PanBtn = (StackPanel)target;
				return;
			}
			if (connectionId == 9)
			{
				this.Btn1 = (MyButton)target;
				return;
			}
			if (connectionId == 10)
			{
				this.Btn2 = (MyButton)target;
				return;
			}
			if (connectionId == 11)
			{
				this.Btn3 = (MyButton)target;
				return;
			}
			this.utilsRequest = true;
		}

		// Token: 0x0400088C RID: 2188
		private readonly ModMain.MyMsgBoxConverter m_ListenerRequest;

		// Token: 0x0400088D RID: 2189
		private readonly int m_IdentifierRequest;

		// Token: 0x0400088E RID: 2190
		[CompilerGenerated]
		[AccessedThroughProperty("PanBack")]
		private MyMsgText _InstanceRequest;

		// Token: 0x0400088F RID: 2191
		[AccessedThroughProperty("PanBorder")]
		[CompilerGenerated]
		private Border _CreatorRequest;

		// Token: 0x04000890 RID: 2192
		[CompilerGenerated]
		[AccessedThroughProperty("EffectShadow")]
		private DropShadowEffect objectRequest;

		// Token: 0x04000891 RID: 2193
		[AccessedThroughProperty("LabTitle")]
		[CompilerGenerated]
		private TextBlock regRequest;

		// Token: 0x04000892 RID: 2194
		[AccessedThroughProperty("ShapeLine")]
		[CompilerGenerated]
		private Rectangle invocationRequest;

		// Token: 0x04000893 RID: 2195
		[AccessedThroughProperty("PanCaption")]
		[CompilerGenerated]
		private MyScrollViewer m_ComposerRequest;

		// Token: 0x04000894 RID: 2196
		[CompilerGenerated]
		[AccessedThroughProperty("LabCaption")]
		private TextBlock m_ItemRequest;

		// Token: 0x04000895 RID: 2197
		[AccessedThroughProperty("PanBtn")]
		[CompilerGenerated]
		private StackPanel m_MapperRequest;

		// Token: 0x04000896 RID: 2198
		[AccessedThroughProperty("Btn1")]
		[CompilerGenerated]
		private MyButton _FactoryRequest;

		// Token: 0x04000897 RID: 2199
		[AccessedThroughProperty("Btn2")]
		[CompilerGenerated]
		private MyButton m_ProcessRequest;

		// Token: 0x04000898 RID: 2200
		[AccessedThroughProperty("Btn3")]
		[CompilerGenerated]
		private MyButton valRequest;

		// Token: 0x04000899 RID: 2201
		private bool utilsRequest;
	}
}
