﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using PCL.My;

namespace PCL
{
	// Token: 0x02000195 RID: 405
	public class MyBitmap
	{
		// Token: 0x06001303 RID: 4867 RVA: 0x0000B1E9 File Offset: 0x000093E9
		public static implicit operator MyBitmap(Image Image)
		{
			return new MyBitmap(Image);
		}

		// Token: 0x06001304 RID: 4868 RVA: 0x0000B1F1 File Offset: 0x000093F1
		public static implicit operator Image(MyBitmap Image)
		{
			return Image.templateAccount;
		}

		// Token: 0x06001305 RID: 4869 RVA: 0x0000B1F9 File Offset: 0x000093F9
		public static implicit operator MyBitmap(ImageSource Image)
		{
			return new MyBitmap(Image);
		}

		// Token: 0x06001306 RID: 4870 RVA: 0x0007D674 File Offset: 0x0007B874
		public static implicit operator ImageSource(MyBitmap Image)
		{
			Bitmap bitmap = Image.templateAccount;
			Rectangle rect = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
			BitmapData bitmapData = bitmap.LockBits(rect, ImageLockMode.ReadWrite, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
			ImageSource result;
			try
			{
				int bufferSize = checked(rect.Width * rect.Height * 4);
				result = BitmapSource.Create(bitmap.Width, bitmap.Height, (double)ModBase.m_DescriptorState, (double)ModBase.m_DescriptorState, PixelFormats.Bgra32, null, bitmapData.Scan0, bufferSize, bitmapData.Stride);
			}
			finally
			{
				bitmap.UnlockBits(bitmapData);
			}
			return result;
		}

		// Token: 0x06001307 RID: 4871 RVA: 0x0000B201 File Offset: 0x00009401
		public static implicit operator MyBitmap(Bitmap Image)
		{
			return new MyBitmap(Image);
		}

		// Token: 0x06001308 RID: 4872 RVA: 0x0000B1F1 File Offset: 0x000093F1
		public static implicit operator Bitmap(MyBitmap Image)
		{
			return Image.templateAccount;
		}

		// Token: 0x06001309 RID: 4873 RVA: 0x0000B209 File Offset: 0x00009409
		public static implicit operator MyBitmap(ImageBrush Image)
		{
			return new MyBitmap(Image);
		}

		// Token: 0x0600130A RID: 4874 RVA: 0x0000B211 File Offset: 0x00009411
		public static implicit operator ImageBrush(MyBitmap Image)
		{
			return new ImageBrush(new MyBitmap(Image.templateAccount));
		}

		// Token: 0x0600130B RID: 4875 RVA: 0x000023C1 File Offset: 0x000005C1
		public MyBitmap()
		{
		}

		// Token: 0x0600130C RID: 4876 RVA: 0x0007D70C File Offset: 0x0007B90C
		public MyBitmap(string FilePathOrResourceName)
		{
			try
			{
				if (FilePathOrResourceName.StartsWith(ModBase._TokenizerState))
				{
					if (MyBitmap.m_IndexerAccount.ContainsKey(FilePathOrResourceName))
					{
						this.templateAccount = MyBitmap.m_IndexerAccount[FilePathOrResourceName].templateAccount;
					}
					else
					{
						this.templateAccount = new MyBitmap((ImageSource)new ImageSourceConverter().ConvertFromString(FilePathOrResourceName)).templateAccount;
						MyBitmap.m_IndexerAccount.Add(FilePathOrResourceName, new MyBitmap(this.templateAccount));
					}
				}
				else
				{
					using (FileStream fileStream = new FileStream(FilePathOrResourceName, FileMode.Open))
					{
						this.templateAccount = new Bitmap(fileStream);
						fileStream.Dispose();
					}
				}
			}
			catch (Exception ex)
			{
				this.templateAccount = (Bitmap)MyWpfExtension.FillModel().TryFindResource(FilePathOrResourceName);
				if (this.templateAccount == null)
				{
					this.templateAccount = new Bitmap(1, 1);
					ModBase.Log(ex, "加载位图失败（" + FilePathOrResourceName + "）", ModBase.LogLevel.Debug, "出现错误");
					throw;
				}
				ModBase.Log(ex, "指定类型有误的位图加载（" + FilePathOrResourceName + "）", ModBase.LogLevel.Developer, "出现错误");
			}
		}

		// Token: 0x0600130D RID: 4877 RVA: 0x0007D844 File Offset: 0x0007BA44
		public MyBitmap(ImageSource Image)
		{
			using (MemoryStream memoryStream = new MemoryStream())
			{
				new PngBitmapEncoder
				{
					Frames = 
					{
						BitmapFrame.Create((BitmapSource)Image)
					}
				}.Save(memoryStream);
				this.templateAccount = new Bitmap(memoryStream);
			}
		}

		// Token: 0x0600130E RID: 4878 RVA: 0x0000B228 File Offset: 0x00009428
		public MyBitmap(Image Image)
		{
			this.templateAccount = (Bitmap)Image;
		}

		// Token: 0x0600130F RID: 4879 RVA: 0x0000B23D File Offset: 0x0000943D
		public MyBitmap(Bitmap Image)
		{
			this.templateAccount = Image;
		}

		// Token: 0x06001310 RID: 4880 RVA: 0x0007D8A8 File Offset: 0x0007BAA8
		public MyBitmap(ImageBrush Image)
		{
			using (MemoryStream memoryStream = new MemoryStream())
			{
				new BmpBitmapEncoder
				{
					Frames = 
					{
						BitmapFrame.Create((BitmapSource)Image.ImageSource)
					}
				}.Save(memoryStream);
				this.templateAccount = new Bitmap(memoryStream);
			}
		}

		// Token: 0x06001311 RID: 4881 RVA: 0x0007D910 File Offset: 0x0007BB10
		public Bitmap Rotation(double angle)
		{
			Image image = this.templateAccount;
			float num = (float)image.Width;
			Bitmap bitmap = checked(new Bitmap((int)Math.Round((double)num), (int)Math.Round((double)num)));
			using (Graphics graphics = Graphics.FromImage(bitmap))
			{
				graphics.TranslateTransform(num / 2f, num / 2f);
				graphics.RotateTransform((float)angle);
				graphics.TranslateTransform(-num / 2f, -num / 2f);
				graphics.DrawImage(image, new Rectangle(0, 0, image.Width, image.Width));
			}
			return bitmap;
		}

		// Token: 0x06001312 RID: 4882 RVA: 0x0007D9B4 File Offset: 0x0007BBB4
		public Bitmap Clip(Rectangle rect)
		{
			Image image = this.templateAccount;
			Bitmap bitmap = new Bitmap(rect.Width, rect.Height);
			using (Graphics graphics = Graphics.FromImage(bitmap))
			{
				graphics.DrawImageUnscaled(image, rect);
			}
			return bitmap;
		}

		// Token: 0x06001313 RID: 4883 RVA: 0x0000B24D File Offset: 0x0000944D
		public Bitmap LeftRightFilp()
		{
			Bitmap bitmap = new Bitmap(this.templateAccount);
			bitmap.RotateFlip(RotateFlipType.RotateNoneFlipX);
			return bitmap;
		}

		// Token: 0x06001314 RID: 4884 RVA: 0x0007DA08 File Offset: 0x0007BC08
		public void Save(string FilePath)
		{
			BitmapEncoder bitmapEncoder = new PngBitmapEncoder();
			bitmapEncoder.Frames.Add(BitmapFrame.Create((BitmapSource)this));
			using (FileStream fileStream = new FileStream(FilePath, FileMode.Create))
			{
				bitmapEncoder.Save(fileStream);
			}
		}

		// Token: 0x04000955 RID: 2389
		public static Dictionary<string, MyBitmap> m_IndexerAccount = new Dictionary<string, MyBitmap>();

		// Token: 0x04000956 RID: 2390
		public Bitmap templateAccount;
	}
}
