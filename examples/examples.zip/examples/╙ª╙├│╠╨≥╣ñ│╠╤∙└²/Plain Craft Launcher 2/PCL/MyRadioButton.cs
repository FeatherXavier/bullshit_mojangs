﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000188 RID: 392
	[DesignerGenerated]
	public class MyRadioButton : Border, IComponentConnector
	{
		// Token: 0x06001215 RID: 4629 RVA: 0x00078F98 File Offset: 0x00077198
		public MyRadioButton()
		{
			base.MouseLeftButtonUp += delegate(object sender, MouseButtonEventArgs e)
			{
				this.Radiobox_MouseUp();
			};
			base.MouseLeftButtonDown += delegate(object sender, MouseButtonEventArgs e)
			{
				this.Radiobox_MouseDown();
			};
			base.MouseLeave += delegate(object sender, MouseEventArgs e)
			{
				this.Radiobox_MouseLeave();
			};
			base.MouseEnter += new MouseEventHandler(this.RefreshColor);
			base.MouseLeave += new MouseEventHandler(this.RefreshColor);
			base.Loaded += new RoutedEventHandler(this.RefreshColor);
			this.m_ServiceRequest = ModBase.GetUuid();
			this._ClassRequest = 1.0;
			this.registryRequest = false;
			this._CandidateRequest = MyRadioButton.ColorState.White;
			this._SetterRequest = false;
			this.InitializeComponent();
		}

		// Token: 0x06001216 RID: 4630 RVA: 0x00079050 File Offset: 0x00077250
		[CompilerGenerated]
		public void CountTag(MyRadioButton.CheckEventHandler obj)
		{
			MyRadioButton.CheckEventHandler checkEventHandler = this._ImporterRequest;
			MyRadioButton.CheckEventHandler checkEventHandler2;
			do
			{
				checkEventHandler2 = checkEventHandler;
				MyRadioButton.CheckEventHandler value = (MyRadioButton.CheckEventHandler)Delegate.Combine(checkEventHandler2, obj);
				checkEventHandler = Interlocked.CompareExchange<MyRadioButton.CheckEventHandler>(ref this._ImporterRequest, value, checkEventHandler2);
			}
			while (checkEventHandler != checkEventHandler2);
		}

		// Token: 0x06001217 RID: 4631 RVA: 0x00079088 File Offset: 0x00077288
		[CompilerGenerated]
		public void AddTag(MyRadioButton.CheckEventHandler obj)
		{
			MyRadioButton.CheckEventHandler checkEventHandler = this._ImporterRequest;
			MyRadioButton.CheckEventHandler checkEventHandler2;
			do
			{
				checkEventHandler2 = checkEventHandler;
				MyRadioButton.CheckEventHandler value = (MyRadioButton.CheckEventHandler)Delegate.Remove(checkEventHandler2, obj);
				checkEventHandler = Interlocked.CompareExchange<MyRadioButton.CheckEventHandler>(ref this._ImporterRequest, value, checkEventHandler2);
			}
			while (checkEventHandler != checkEventHandler2);
		}

		// Token: 0x06001218 RID: 4632 RVA: 0x000790C0 File Offset: 0x000772C0
		[CompilerGenerated]
		public void PushTag(MyRadioButton.ChangeEventHandler obj)
		{
			MyRadioButton.ChangeEventHandler changeEventHandler = this._ProxyRequest;
			MyRadioButton.ChangeEventHandler changeEventHandler2;
			do
			{
				changeEventHandler2 = changeEventHandler;
				MyRadioButton.ChangeEventHandler value = (MyRadioButton.ChangeEventHandler)Delegate.Combine(changeEventHandler2, obj);
				changeEventHandler = Interlocked.CompareExchange<MyRadioButton.ChangeEventHandler>(ref this._ProxyRequest, value, changeEventHandler2);
			}
			while (changeEventHandler != changeEventHandler2);
		}

		// Token: 0x06001219 RID: 4633 RVA: 0x000790F8 File Offset: 0x000772F8
		[CompilerGenerated]
		public void ExcludeTag(MyRadioButton.ChangeEventHandler obj)
		{
			MyRadioButton.ChangeEventHandler changeEventHandler = this._ProxyRequest;
			MyRadioButton.ChangeEventHandler changeEventHandler2;
			do
			{
				changeEventHandler2 = changeEventHandler;
				MyRadioButton.ChangeEventHandler value = (MyRadioButton.ChangeEventHandler)Delegate.Remove(changeEventHandler2, obj);
				changeEventHandler = Interlocked.CompareExchange<MyRadioButton.ChangeEventHandler>(ref this._ProxyRequest, value, changeEventHandler2);
			}
			while (changeEventHandler != changeEventHandler2);
		}

		// Token: 0x0600121A RID: 4634 RVA: 0x00079130 File Offset: 0x00077330
		public void RaiseChange()
		{
			MyRadioButton.ChangeEventHandler proxyRequest = this._ProxyRequest;
			if (proxyRequest != null)
			{
				proxyRequest(this, false);
			}
		}

		// Token: 0x1700031C RID: 796
		// (get) Token: 0x0600121B RID: 4635 RVA: 0x0000A9E9 File Offset: 0x00008BE9
		// (set) Token: 0x0600121C RID: 4636 RVA: 0x0000A9FB File Offset: 0x00008BFB
		public string Logo
		{
			get
			{
				return this.ShapeLogo.Data.ToString();
			}
			set
			{
				this.ShapeLogo.Data = (Geometry)new GeometryConverter().ConvertFromString(value);
			}
		}

		// Token: 0x1700031D RID: 797
		// (get) Token: 0x0600121D RID: 4637 RVA: 0x0000AA18 File Offset: 0x00008C18
		// (set) Token: 0x0600121E RID: 4638 RVA: 0x0000AA20 File Offset: 0x00008C20
		public double LogoScale
		{
			get
			{
				return this._ClassRequest;
			}
			set
			{
				this._ClassRequest = value;
				if (!Information.IsNothing(this.ShapeLogo))
				{
					this.ShapeLogo.RenderTransform = new ScaleTransform
					{
						ScaleX = this.LogoScale,
						ScaleY = this.LogoScale
					};
				}
			}
		}

		// Token: 0x1700031E RID: 798
		// (get) Token: 0x0600121F RID: 4639 RVA: 0x0000AA5E File Offset: 0x00008C5E
		// (set) Token: 0x06001220 RID: 4640 RVA: 0x0000AA66 File Offset: 0x00008C66
		public bool Checked
		{
			get
			{
				return this.registryRequest;
			}
			set
			{
				this.SetChecked(value, false, true);
			}
		}

		// Token: 0x06001221 RID: 4641 RVA: 0x00079150 File Offset: 0x00077350
		public void SetChecked(bool value, bool user, bool anime)
		{
			checked
			{
				try
				{
					bool flag = false;
					if (base.IsLoaded && value != this.registryRequest)
					{
						MyRadioButton.ChangeEventHandler proxyRequest = this._ProxyRequest;
						if (proxyRequest != null)
						{
							proxyRequest(this, user);
						}
					}
					if (value != this.registryRequest)
					{
						this.registryRequest = value;
						flag = true;
					}
					if (!Information.IsNothing(base.Parent))
					{
						List<MyRadioButton> list = new List<MyRadioButton>();
						int num = 0;
						try
						{
							foreach (object obj in ((IEnumerable)NewLateBinding.LateGet(base.Parent, null, "Children", new object[0], null, null, null)))
							{
								object objectValue = RuntimeHelpers.GetObjectValue(obj);
								if (objectValue is MyRadioButton)
								{
									list.Add((MyRadioButton)objectValue);
									if (Conversions.ToBoolean(NewLateBinding.LateGet(objectValue, null, "Checked", new object[0], null, null, null)))
									{
										num++;
									}
								}
							}
						}
						finally
						{
							IEnumerator enumerator;
							if (enumerator is IDisposable)
							{
								(enumerator as IDisposable).Dispose();
							}
						}
						int num2 = num;
						if (num2 == 0)
						{
							list[0].Checked = true;
						}
						else if (num2 > 1)
						{
							if (this.Checked)
							{
								try
								{
									foreach (MyRadioButton myRadioButton in list)
									{
										if (myRadioButton.Checked && !myRadioButton.Equals(this))
										{
											myRadioButton.Checked = false;
										}
									}
									goto IL_198;
								}
								finally
								{
									List<MyRadioButton>.Enumerator enumerator2;
									((IDisposable)enumerator2).Dispose();
								}
							}
							bool flag2 = false;
							try
							{
								foreach (MyRadioButton myRadioButton2 in list)
								{
									if (myRadioButton2.Checked)
									{
										if (flag2)
										{
											myRadioButton2.Checked = false;
										}
										else
										{
											flag2 = true;
										}
									}
								}
							}
							finally
							{
								List<MyRadioButton>.Enumerator enumerator3;
								((IDisposable)enumerator3).Dispose();
							}
						}
						IL_198:
						if (flag)
						{
							this.RefreshColor(null, anime);
							if (this.Checked)
							{
								MyRadioButton.CheckEventHandler importerRequest = this._ImporterRequest;
								if (importerRequest != null)
								{
									importerRequest(this, user);
								}
							}
						}
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "单选按钮勾选改变错误", ModBase.LogLevel.Hint, "出现错误");
				}
			}
		}

		// Token: 0x1700031F RID: 799
		// (get) Token: 0x06001222 RID: 4642 RVA: 0x0000AA71 File Offset: 0x00008C71
		// (set) Token: 0x06001223 RID: 4643 RVA: 0x0000AA83 File Offset: 0x00008C83
		public string Text
		{
			get
			{
				return Conversions.ToString(base.GetValue(MyRadioButton.producerRequest));
			}
			set
			{
				base.SetValue(MyRadioButton.producerRequest, value);
			}
		}

		// Token: 0x17000320 RID: 800
		// (get) Token: 0x06001224 RID: 4644 RVA: 0x0000AA91 File Offset: 0x00008C91
		// (set) Token: 0x06001225 RID: 4645 RVA: 0x0000AA99 File Offset: 0x00008C99
		public MyRadioButton.ColorState ColorType
		{
			get
			{
				return this._CandidateRequest;
			}
			set
			{
				this._CandidateRequest = value;
				this.RefreshColor(null, null);
			}
		}

		// Token: 0x06001226 RID: 4646 RVA: 0x0000AAAA File Offset: 0x00008CAA
		private void Radiobox_MouseUp()
		{
			if (!this.Checked && this._SetterRequest)
			{
				ModBase.Log("[Control] 按下单选按钮：" + this.Text, ModBase.LogLevel.Normal, "出现错误");
				this._SetterRequest = false;
				this.SetChecked(true, true, true);
			}
		}

		// Token: 0x06001227 RID: 4647 RVA: 0x0000AAE7 File Offset: 0x00008CE7
		private void Radiobox_MouseDown()
		{
			if (!this.Checked)
			{
				this._SetterRequest = true;
				this.RefreshColor(null, null);
			}
		}

		// Token: 0x06001228 RID: 4648 RVA: 0x0000AB00 File Offset: 0x00008D00
		private void Radiobox_MouseLeave()
		{
			this._SetterRequest = false;
		}

		// Token: 0x06001229 RID: 4649 RVA: 0x000793AC File Offset: 0x000775AC
		private void RefreshColor(object obj = null, object e = null)
		{
			try
			{
				if (base.IsLoaded && ModAnimation.DefineModel() == 0 && !false.Equals(RuntimeHelpers.GetObjectValue(e)))
				{
					MyRadioButton.ColorState colorType = this.ColorType;
					if (colorType != MyRadioButton.ColorState.White)
					{
						if (colorType == MyRadioButton.ColorState.Highlight)
						{
							if (this.Checked)
							{
								ModAnimation.AniStart(new ModAnimation.AniData[]
								{
									ModAnimation.AaColor(this.ShapeLogo, Shape.FillProperty, new ModBase.MyColor(255.0, 255.0, 255.0) - this.ShapeLogo.Fill, 120, 0, null, false),
									ModAnimation.AaColor(this.LabText, TextBlock.ForegroundProperty, new ModBase.MyColor(255.0, 255.0, 255.0) - this.LabText.Foreground, 120, 0, null, false)
								}, "MyRadioButton Checked " + Conversions.ToString(this.m_ServiceRequest), false);
								ModAnimation.AniStart(ModAnimation.AaColor(this, Border.BackgroundProperty, "ColorBrush3", 120, 0, null, false), "MyRadioButton Color " + Conversions.ToString(this.m_ServiceRequest), false);
							}
							else if (this._SetterRequest)
							{
								ModAnimation.AniStart(ModAnimation.AaColor(this, Border.BackgroundProperty, "ColorBrush6", 90, 0, null, false), "MyRadioButton Color " + Conversions.ToString(this.m_ServiceRequest), false);
							}
							else if (base.IsMouseOver)
							{
								ModAnimation.AniStart(new ModAnimation.AniData[]
								{
									ModAnimation.AaColor(this.ShapeLogo, Shape.FillProperty, "ColorBrush3", 90, 0, null, false),
									ModAnimation.AaColor(this.LabText, TextBlock.ForegroundProperty, "ColorBrush3", 90, 0, null, false)
								}, "MyRadioButton Checked " + Conversions.ToString(this.m_ServiceRequest), false);
								ModAnimation.AniStart(ModAnimation.AaColor(this, Border.BackgroundProperty, "ColorBrush7", 90, 0, null, false), "MyRadioButton Color " + Conversions.ToString(this.m_ServiceRequest), false);
							}
							else
							{
								ModAnimation.AniStart(new ModAnimation.AniData[]
								{
									ModAnimation.AaColor(this.ShapeLogo, Shape.FillProperty, "ColorBrush3", 150, 0, null, false),
									ModAnimation.AaColor(this.LabText, TextBlock.ForegroundProperty, "ColorBrush3", 150, 0, null, false)
								}, "MyRadioButton Checked " + Conversions.ToString(this.m_ServiceRequest), false);
								ModAnimation.AniStart(ModAnimation.AaColor(this, Border.BackgroundProperty, ModMain.m_ConnectionAccount - base.Background, 150, 0, null, false), "MyRadioButton Color " + Conversions.ToString(this.m_ServiceRequest), false);
							}
						}
					}
					else if (this.Checked)
					{
						ModAnimation.AniStart(new ModAnimation.AniData[]
						{
							ModAnimation.AaColor(this.ShapeLogo, Shape.FillProperty, "ColorBrush3", 120, 0, null, false),
							ModAnimation.AaColor(this.LabText, TextBlock.ForegroundProperty, "ColorBrush3", 120, 0, null, false)
						}, "MyRadioButton Checked " + Conversions.ToString(this.m_ServiceRequest), false);
						ModAnimation.AniStart(ModAnimation.AaColor(this, Border.BackgroundProperty, new ModBase.MyColor(255.0, 255.0, 255.0) - base.Background, 120, 0, null, false), "MyRadioButton Color " + Conversions.ToString(this.m_ServiceRequest), false);
					}
					else if (this._SetterRequest)
					{
						ModAnimation.AniStart(ModAnimation.AaColor(this, Border.BackgroundProperty, new ModBase.MyColor(120.0, ModMain.m_ComposerAccount) - base.Background, 60, 0, null, false), "MyRadioButton Color " + Conversions.ToString(this.m_ServiceRequest), false);
					}
					else if (base.IsMouseOver)
					{
						ModAnimation.AniStart(new ModAnimation.AniData[]
						{
							ModAnimation.AaColor(this.ShapeLogo, Shape.FillProperty, new ModBase.MyColor(255.0, 255.0, 255.0) - this.ShapeLogo.Fill, 90, 0, null, false),
							ModAnimation.AaColor(this.LabText, TextBlock.ForegroundProperty, new ModBase.MyColor(255.0, 255.0, 255.0) - this.LabText.Foreground, 90, 0, null, false)
						}, "MyRadioButton Checked " + Conversions.ToString(this.m_ServiceRequest), false);
						ModAnimation.AniStart(ModAnimation.AaColor(this, Border.BackgroundProperty, new ModBase.MyColor(50.0, ModMain.m_ComposerAccount) - base.Background, 90, 0, null, false), "MyRadioButton Color " + Conversions.ToString(this.m_ServiceRequest), false);
					}
					else
					{
						ModAnimation.AniStart(new ModAnimation.AniData[]
						{
							ModAnimation.AaColor(this.ShapeLogo, Shape.FillProperty, new ModBase.MyColor(255.0, 255.0, 255.0) - this.ShapeLogo.Fill, 150, 0, null, false),
							ModAnimation.AaColor(this.LabText, TextBlock.ForegroundProperty, new ModBase.MyColor(255.0, 255.0, 255.0) - this.LabText.Foreground, 150, 0, null, false)
						}, "MyRadioButton Checked " + Conversions.ToString(this.m_ServiceRequest), false);
						ModAnimation.AniStart(ModAnimation.AaColor(this, Border.BackgroundProperty, ModMain.m_ConnectionAccount - base.Background, 150, 0, null, false), "MyRadioButton Color " + Conversions.ToString(this.m_ServiceRequest), false);
					}
				}
				else
				{
					ModAnimation.AniStop("MyRadioButton Checked " + Conversions.ToString(this.m_ServiceRequest));
					ModAnimation.AniStop("MyRadioButton Color " + Conversions.ToString(this.m_ServiceRequest));
					MyRadioButton.ColorState colorType2 = this.ColorType;
					if (colorType2 != MyRadioButton.ColorState.White)
					{
						if (colorType2 == MyRadioButton.ColorState.Highlight)
						{
							if (this.Checked)
							{
								base.SetResourceReference(Border.BackgroundProperty, "ColorBrush3");
								this.ShapeLogo.Fill = new ModBase.MyColor(255.0, 255.0, 255.0);
								this.LabText.Foreground = new ModBase.MyColor(255.0, 255.0, 255.0);
							}
							else
							{
								base.Background = ModMain.m_ConnectionAccount;
								this.ShapeLogo.SetResourceReference(Shape.FillProperty, "ColorBrush3");
								this.LabText.SetResourceReference(TextBlock.ForegroundProperty, "ColorBrush3");
							}
						}
					}
					else if (this.Checked)
					{
						base.Background = new ModBase.MyColor(255.0, 255.0, 255.0);
						this.ShapeLogo.SetResourceReference(Shape.FillProperty, "ColorBrush3");
						this.LabText.SetResourceReference(TextBlock.ForegroundProperty, "ColorBrush3");
					}
					else
					{
						base.Background = ModMain.m_ConnectionAccount;
						this.ShapeLogo.Fill = new ModBase.MyColor(255.0, 255.0, 255.0);
						this.LabText.Foreground = new ModBase.MyColor(255.0, 255.0, 255.0);
					}
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "刷新按钮颜色出错", ModBase.LogLevel.Debug, "出现错误");
			}
		}

		// Token: 0x17000321 RID: 801
		// (get) Token: 0x0600122A RID: 4650 RVA: 0x0000AB09 File Offset: 0x00008D09
		// (set) Token: 0x0600122B RID: 4651 RVA: 0x0000AB11 File Offset: 0x00008D11
		internal virtual MyRadioButton PanBack { get; set; }

		// Token: 0x17000322 RID: 802
		// (get) Token: 0x0600122C RID: 4652 RVA: 0x0000AB1A File Offset: 0x00008D1A
		// (set) Token: 0x0600122D RID: 4653 RVA: 0x0000AB22 File Offset: 0x00008D22
		internal virtual Path ShapeLogo { get; set; }

		// Token: 0x17000323 RID: 803
		// (get) Token: 0x0600122E RID: 4654 RVA: 0x0000AB2B File Offset: 0x00008D2B
		// (set) Token: 0x0600122F RID: 4655 RVA: 0x0000AB33 File Offset: 0x00008D33
		internal virtual TextBlock LabText { get; set; }

		// Token: 0x06001230 RID: 4656 RVA: 0x00079BFC File Offset: 0x00077DFC
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this._StatusRequest)
			{
				this._StatusRequest = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/controls/myradiobutton.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06001231 RID: 4657 RVA: 0x0000AB3C File Offset: 0x00008D3C
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyRadioButton)target;
				return;
			}
			if (connectionId == 2)
			{
				this.ShapeLogo = (Path)target;
				return;
			}
			if (connectionId == 3)
			{
				this.LabText = (TextBlock)target;
				return;
			}
			this._StatusRequest = true;
		}

		// Token: 0x040008D9 RID: 2265
		public int m_ServiceRequest;

		// Token: 0x040008DA RID: 2266
		[CompilerGenerated]
		private MyRadioButton.CheckEventHandler _ImporterRequest;

		// Token: 0x040008DB RID: 2267
		[CompilerGenerated]
		private MyRadioButton.ChangeEventHandler _ProxyRequest;

		// Token: 0x040008DC RID: 2268
		private double _ClassRequest;

		// Token: 0x040008DD RID: 2269
		private bool registryRequest;

		// Token: 0x040008DE RID: 2270
		public static readonly DependencyProperty producerRequest = DependencyProperty.Register("Text", typeof(string), typeof(MyRadioButton), new PropertyMetadata(delegate(DependencyObject sender, DependencyPropertyChangedEventArgs e)
		{
			if (!Information.IsNothing(sender))
			{
				((MyRadioButton)sender).LabText.Text = Conversions.ToString(e.NewValue);
			}
		}));

		// Token: 0x040008DF RID: 2271
		private MyRadioButton.ColorState _CandidateRequest;

		// Token: 0x040008E0 RID: 2272
		private bool _SetterRequest;

		// Token: 0x040008E1 RID: 2273
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyRadioButton _MappingRequest;

		// Token: 0x040008E2 RID: 2274
		[AccessedThroughProperty("ShapeLogo")]
		[CompilerGenerated]
		private Path m_DispatcherRequest;

		// Token: 0x040008E3 RID: 2275
		[CompilerGenerated]
		[AccessedThroughProperty("LabText")]
		private TextBlock messageRequest;

		// Token: 0x040008E4 RID: 2276
		private bool _StatusRequest;

		// Token: 0x02000189 RID: 393
		// (Invoke) Token: 0x06001238 RID: 4664
		public delegate void CheckEventHandler(object sender, bool raiseByMouse);

		// Token: 0x0200018A RID: 394
		// (Invoke) Token: 0x0600123D RID: 4669
		public delegate void ChangeEventHandler(object sender, bool raiseByMouse);

		// Token: 0x0200018B RID: 395
		public enum ColorState
		{
			// Token: 0x040008E6 RID: 2278
			White,
			// Token: 0x040008E7 RID: 2279
			Highlight
		}
	}
}
