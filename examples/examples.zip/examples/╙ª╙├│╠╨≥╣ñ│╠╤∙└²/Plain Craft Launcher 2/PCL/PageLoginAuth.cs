﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200009C RID: 156
	[DesignerGenerated]
	public class PageLoginAuth : Grid, IComponentConnector
	{
		// Token: 0x060005A8 RID: 1448 RVA: 0x00004EE9 File Offset: 0x000030E9
		public PageLoginAuth()
		{
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.ReloadRegisterButton();
			};
			this._TokenRepository = true;
			this.InitializeComponent();
		}

		// Token: 0x060005A9 RID: 1449 RVA: 0x0002B868 File Offset: 0x00029A68
		public void Reload(bool KeepInput)
		{
			this.CheckRemember.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("LoginRemember", null));
			if (KeepInput && !this._TokenRepository)
			{
				string text = this.ComboName.Text;
				this.ComboName.ItemsSource = (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LoginAuthEmail", null), "", true) ? null : ModBase._ParamsState.Get("LoginAuthEmail", null).ToString().Split(new char[]
				{
					'¨'
				}));
				this.ComboName.Text = text;
			}
			else if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LoginAuthEmail", null), "", true))
			{
				this.ComboName.ItemsSource = null;
			}
			else
			{
				this.ComboName.ItemsSource = ModBase._ParamsState.Get("LoginAuthEmail", null).ToString().Split(new char[]
				{
					'¨'
				});
				this.ComboName.Text = ModBase._ParamsState.Get("LoginAuthEmail", null).ToString().Split(new char[]
				{
					'¨'
				})[0];
				if (Conversions.ToBoolean(ModBase._ParamsState.Get("LoginRemember", null)))
				{
					this.TextPass.Password = ModBase._ParamsState.Get("LoginAuthPass", null).ToString().Split(new char[]
					{
						'¨'
					})[0].Trim();
				}
			}
			this._TokenRepository = false;
		}

		// Token: 0x060005AA RID: 1450 RVA: 0x0002BA00 File Offset: 0x00029C00
		public static ModLaunch.McLoginServer GetLoginData()
		{
			string stubProccesor = Conversions.ToString(Operators.ConcatenateObject(Information.IsNothing(ModMinecraft.SetupResolver()) ? ModBase._ParamsState.Get("CacheAuthServerServer", null) : ModBase._ParamsState.Get("VersionServerAuthServer", ModMinecraft.SetupResolver()), "/authserver"));
			ModLaunch.McLoginServer result;
			if (ModMain.m_RegistryAccount == null)
			{
				result = new ModLaunch.McLoginServer(ModLaunch.McLoginType.Auth)
				{
					m_ErrorProccesor = "Auth",
					_StubProccesor = stubProccesor,
					m_InterpreterProccesor = "",
					_ParserProccesor = "",
					_ExceptionProccesor = "Authlib-Injector",
					Type = ModLaunch.McLoginType.Auth
				};
			}
			else
			{
				result = new ModLaunch.McLoginServer(ModLaunch.McLoginType.Auth)
				{
					m_ErrorProccesor = "Auth",
					_StubProccesor = stubProccesor,
					m_InterpreterProccesor = ModMain.m_RegistryAccount.ComboName.Text.Replace("¨", "").Trim(),
					_ParserProccesor = ModMain.m_RegistryAccount.TextPass.Password.Replace("¨", "").Trim(),
					_ExceptionProccesor = "Authlib-Injector",
					Type = ModLaunch.McLoginType.Auth
				};
			}
			return result;
		}

		// Token: 0x060005AB RID: 1451 RVA: 0x0002BB18 File Offset: 0x00029D18
		public static string IsVaild(ModLaunch.McLoginServer LoginData)
		{
			string result;
			if (Operators.CompareString(LoginData.m_InterpreterProccesor, "", true) == 0)
			{
				result = "账号不能为空！";
			}
			else if (Operators.CompareString(LoginData._ParserProccesor, "", true) == 0)
			{
				result = "密码不能为空！";
			}
			else
			{
				result = "";
			}
			return result;
		}

		// Token: 0x060005AC RID: 1452 RVA: 0x00004F11 File Offset: 0x00003111
		public string IsVaild()
		{
			return PageLoginAuth.IsVaild(PageLoginAuth.GetLoginData());
		}

		// Token: 0x060005AD RID: 1453 RVA: 0x0002BB64 File Offset: 0x00029D64
		private void ComboName_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (Operators.ConditionalCompareObjectEqual(NewLateBinding.LateGet(sender, null, "Text", new object[0], null, null, null), "", true))
			{
				this.TextPass.Password = "";
			}
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set("CacheAuthAccess", "", false, null);
			}
		}

		// Token: 0x060005AE RID: 1454 RVA: 0x00004F1D File Offset: 0x0000311D
		private void TextPass_PasswordChanged(object sender, RoutedEventArgs e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set("CacheAuthAccess", "", false, null);
			}
		}

		// Token: 0x060005AF RID: 1455 RVA: 0x0002BBC0 File Offset: 0x00029DC0
		private void ComboName_SelectionChanged(MyComboBox sender, SelectionChangedEventArgs e)
		{
			if (Conversions.ToBoolean(sender.SelectedIndex == -1 || Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("LoginRemember", null)))))
			{
				this.TextPass.Password = "";
				return;
			}
			this.TextPass.Password = ModBase._ParamsState.Get("LoginAuthPass", null).ToString().Split(new char[]
			{
				'¨'
			})[sender.SelectedIndex].Trim();
		}

		// Token: 0x060005B0 RID: 1456 RVA: 0x00004F3C File Offset: 0x0000313C
		private void CheckBoxChange(MyCheckBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.Checked, false, null);
			}
		}

		// Token: 0x060005B1 RID: 1457 RVA: 0x00004F67 File Offset: 0x00003167
		private void ComboName_TextChanged()
		{
			this.BtnLink.Content = ((Operators.CompareString(this.ComboName.Text, "", true) == 0) ? "注册账号" : "找回密码");
		}

		// Token: 0x060005B2 RID: 1458 RVA: 0x00004F98 File Offset: 0x00003198
		private void Btn_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite(Conversions.ToString((ModMinecraft.SetupResolver() == null) ? ModBase._ParamsState.Get("VersionServerAuthRegister", ModMinecraft.SetupResolver()) : ModBase._ParamsState.Get("CacheAuthServerRegister", null)));
		}

		// Token: 0x060005B3 RID: 1459 RVA: 0x0002BC50 File Offset: 0x00029E50
		private void ReloadRegisterButton()
		{
			string str = Conversions.ToString((ModMinecraft.SetupResolver() != null) ? ModBase._ParamsState.Get("VersionServerAuthRegister", ModMinecraft.SetupResolver()) : ModBase._ParamsState.Get("CacheAuthServerRegister", null));
			this.BtnLink.Visibility = (string.IsNullOrEmpty(new ValidateHttp().Validate(str)) ? Visibility.Visible : Visibility.Collapsed);
		}

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x060005B4 RID: 1460 RVA: 0x00004FD1 File Offset: 0x000031D1
		// (set) Token: 0x060005B5 RID: 1461 RVA: 0x0002BCB4 File Offset: 0x00029EB4
		internal virtual MyComboBox ComboName
		{
			[CompilerGenerated]
			get
			{
				return this._InterpreterRepository;
			}
			[CompilerGenerated]
			set
			{
				MyComboBox.TextChangedEventHandler obj = new MyComboBox.TextChangedEventHandler(this.ComboName_TextChanged);
				SelectionChangedEventHandler value2 = delegate(object sender, SelectionChangedEventArgs e)
				{
					this.ComboName_SelectionChanged((MyComboBox)sender, e);
				};
				MyComboBox.TextChangedEventHandler obj2 = delegate(object sender, TextChangedEventArgs e)
				{
					this.ComboName_TextChanged();
				};
				MyComboBox interpreterRepository = this._InterpreterRepository;
				if (interpreterRepository != null)
				{
					interpreterRepository.VisitModel(obj);
					interpreterRepository.SelectionChanged -= value2;
					interpreterRepository.VisitModel(obj2);
				}
				this._InterpreterRepository = value;
				interpreterRepository = this._InterpreterRepository;
				if (interpreterRepository != null)
				{
					interpreterRepository.GetModel(obj);
					interpreterRepository.SelectionChanged += value2;
					interpreterRepository.GetModel(obj2);
				}
			}
		}

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x060005B6 RID: 1462 RVA: 0x00004FD9 File Offset: 0x000031D9
		// (set) Token: 0x060005B7 RID: 1463 RVA: 0x0002BD30 File Offset: 0x00029F30
		internal virtual PasswordBox TextPass
		{
			[CompilerGenerated]
			get
			{
				return this.parserRepository;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = new RoutedEventHandler(this.TextPass_PasswordChanged);
				PasswordBox passwordBox = this.parserRepository;
				if (passwordBox != null)
				{
					passwordBox.PasswordChanged -= value2;
				}
				this.parserRepository = value;
				passwordBox = this.parserRepository;
				if (passwordBox != null)
				{
					passwordBox.PasswordChanged += value2;
				}
			}
		}

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x060005B8 RID: 1464 RVA: 0x00004FE1 File Offset: 0x000031E1
		// (set) Token: 0x060005B9 RID: 1465 RVA: 0x0002BD74 File Offset: 0x00029F74
		internal virtual MyCheckBox CheckRemember
		{
			[CompilerGenerated]
			get
			{
				return this.stubRepository;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = delegate(object a0, bool a1)
				{
					this.CheckBoxChange((MyCheckBox)a0, a1);
				};
				MyCheckBox myCheckBox = this.stubRepository;
				if (myCheckBox != null)
				{
					myCheckBox.StopTag(obj);
				}
				this.stubRepository = value;
				myCheckBox = this.stubRepository;
				if (myCheckBox != null)
				{
					myCheckBox.CloneTag(obj);
				}
			}
		}

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x060005BA RID: 1466 RVA: 0x00004FE9 File Offset: 0x000031E9
		// (set) Token: 0x060005BB RID: 1467 RVA: 0x0002BDB8 File Offset: 0x00029FB8
		internal virtual MyTextButton BtnLink
		{
			[CompilerGenerated]
			get
			{
				return this.errorRepository;
			}
			[CompilerGenerated]
			set
			{
				MyTextButton.ClickEventHandler obj = new MyTextButton.ClickEventHandler(this.Btn_Click);
				MyTextButton myTextButton = this.errorRepository;
				if (myTextButton != null)
				{
					myTextButton.TestRepository(obj);
				}
				this.errorRepository = value;
				myTextButton = this.errorRepository;
				if (myTextButton != null)
				{
					myTextButton.ResolveRepository(obj);
				}
			}
		}

		// Token: 0x060005BC RID: 1468 RVA: 0x0002BDFC File Offset: 0x00029FFC
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_ExceptionRepository)
			{
				this.m_ExceptionRepository = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagelaunch/pageloginauth.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x060005BD RID: 1469 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060005BE RID: 1470 RVA: 0x0002BE2C File Offset: 0x0002A02C
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.ComboName = (MyComboBox)target;
				return;
			}
			if (connectionId == 2)
			{
				this.TextPass = (PasswordBox)target;
				return;
			}
			if (connectionId == 3)
			{
				this.CheckRemember = (MyCheckBox)target;
				return;
			}
			if (connectionId == 4)
			{
				this.BtnLink = (MyTextButton)target;
				return;
			}
			this.m_ExceptionRepository = true;
		}

		// Token: 0x040002A0 RID: 672
		private bool _TokenRepository;

		// Token: 0x040002A1 RID: 673
		[AccessedThroughProperty("ComboName")]
		[CompilerGenerated]
		private MyComboBox _InterpreterRepository;

		// Token: 0x040002A2 RID: 674
		[AccessedThroughProperty("TextPass")]
		[CompilerGenerated]
		private PasswordBox parserRepository;

		// Token: 0x040002A3 RID: 675
		[AccessedThroughProperty("CheckRemember")]
		[CompilerGenerated]
		private MyCheckBox stubRepository;

		// Token: 0x040002A4 RID: 676
		[CompilerGenerated]
		[AccessedThroughProperty("BtnLink")]
		private MyTextButton errorRepository;

		// Token: 0x040002A5 RID: 677
		private bool m_ExceptionRepository;
	}
}
