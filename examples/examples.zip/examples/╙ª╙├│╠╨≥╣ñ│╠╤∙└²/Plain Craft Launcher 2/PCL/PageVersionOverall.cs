﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Newtonsoft.Json.Linq;
using PCL.My;

namespace PCL
{
	// Token: 0x020000BF RID: 191
	[DesignerGenerated]
	public class PageVersionOverall : MyPageRight, IComponentConnector
	{
		// Token: 0x0600076A RID: 1898 RVA: 0x00005EC0 File Offset: 0x000040C0
		public PageVersionOverall()
		{
			base.Loaded += this.PageSetupLaunch_Loaded;
			this.invocationResolver = false;
			this.InitializeComponent();
		}

		// Token: 0x0600076B RID: 1899 RVA: 0x00005EE8 File Offset: 0x000040E8
		private void PageSetupLaunch_Loaded(object sender, RoutedEventArgs e)
		{
			this.PanBack.ScrollToHome();
			this.ItemDisplayLogoCustom.Tag = "PCL\\Logo.png";
			this.Reload();
			if (!this.invocationResolver)
			{
				this.invocationResolver = true;
				this.PanDisplay.TriggerForceResize();
			}
		}

		// Token: 0x0600076C RID: 1900 RVA: 0x000337D8 File Offset: 0x000319D8
		private void Reload()
		{
			checked
			{
				ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
				this.ComboDisplayType.SelectedIndex = Conversions.ToInteger(ModBase.ReadIni(PageVersionLeft.m_AlgoResolver.Path + "PCL\\Setup.ini", "DisplayType", Conversions.ToString(0)));
				this.BtnDisplayStar.Text = (PageVersionLeft.m_AlgoResolver._ProducerProccesor ? "从收藏夹中移除" : "加入收藏夹");
				this.PanDisplayItem.Children.Clear();
				this.m_ComposerResolver = PageSelectRight.McVersionListItem(PageVersionLeft.m_AlgoResolver);
				this.m_ComposerResolver.IsHitTestVisible = false;
				this.PanDisplayItem.Children.Add(this.m_ComposerResolver);
				ModMain.m_CollectionAccount.PageNameRefresh();
				this.ComboDisplayLogo.SelectedIndex = 0;
				string text = ModBase.ReadIni(PageVersionLeft.m_AlgoResolver.Path + "PCL\\Setup.ini", "Logo", "");
				if (Conversions.ToBoolean(ModBase.ReadIni(PageVersionLeft.m_AlgoResolver.Path + "PCL\\Setup.ini", "LogoCustom", "False")))
				{
					try
					{
						foreach (object obj in ((IEnumerable)this.ComboDisplayLogo.Items))
						{
							MyComboBoxItem myComboBoxItem = (MyComboBoxItem)obj;
							if (Operators.ConditionalCompareObjectEqual(myComboBoxItem.Tag, text, true) || (Operators.ConditionalCompareObjectEqual(myComboBoxItem.Tag, "PCL\\Logo.png", true) && text.EndsWith("PCL\\Logo.png")))
							{
								this.ComboDisplayLogo.SelectedItem = myComboBoxItem;
								break;
							}
						}
					}
					finally
					{
						IEnumerator enumerator;
						if (enumerator is IDisposable)
						{
							(enumerator as IDisposable).Dispose();
						}
					}
				}
				ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
			}
		}

		// Token: 0x0600076D RID: 1901 RVA: 0x00033988 File Offset: 0x00031B88
		private void ComboDisplayType_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (this.invocationResolver && ModAnimation.DefineModel() == 0)
			{
				if (this.ComboDisplayType.SelectedIndex != 1)
				{
					try
					{
						ModBase.WriteIni(PageVersionLeft.m_AlgoResolver.Path + "PCL\\Setup.ini", "DisplayType", Conversions.ToString(this.ComboDisplayType.SelectedIndex));
						ModBase.WriteIni(ModMinecraft._MapperTag + "PCL.ini", "VersionCache", "");
						ModLoader.LoaderFolderRun(ModMinecraft.threadTag, ModMinecraft._MapperTag, ModLoader.LoaderFolderRunType.ForceRun, 1, "versions\\", false);
						return;
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "修改版本分类失败（" + PageVersionLeft.m_AlgoResolver.Name + "）", ModBase.LogLevel.Feedback, "出现错误");
						return;
					}
				}
				try
				{
					if (Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("HintHide", null))))
					{
						if (ModMain.MyMsgBox("确认要从版本列表中隐藏该版本吗？隐藏该版本后，它将不再出现于 PCL 显示的版本列表中。\r\n此后，在版本列表页面按下 F11 才可以查看被隐藏的版本。", "隐藏版本提示", "确定", "取消", "", false, true, false) != 1)
						{
							this.ComboDisplayType.SelectedIndex = 0;
							return;
						}
						ModBase._ParamsState.Set("HintHide", true, false, null);
					}
					ModBase.WriteIni(PageVersionLeft.m_AlgoResolver.Path + "PCL\\Setup.ini", "DisplayType", Conversions.ToString(1));
					ModBase.WriteIni(ModMinecraft._MapperTag + "PCL.ini", "VersionCache", "");
					ModLoader.LoaderFolderRun(ModMinecraft.threadTag, ModMinecraft._MapperTag, ModLoader.LoaderFolderRunType.ForceRun, 1, "versions\\", false);
				}
				catch (Exception ex2)
				{
					ModBase.Log(ex2, "隐藏版本 " + PageVersionLeft.m_AlgoResolver.Name + " 失败", ModBase.LogLevel.Feedback, "出现错误");
				}
			}
		}

		// Token: 0x0600076E RID: 1902 RVA: 0x00033B70 File Offset: 0x00031D70
		private void BtnDisplayDesc_Click(object sender, EventArgs e)
		{
			try
			{
				string text = ModBase.ReadIni(PageVersionLeft.m_AlgoResolver.Path + "PCL\\Setup.ini", "CustomInfo", "");
				string text2 = ModMain.MyMsgBoxInput(text, new Collection<Validate>(), "留空即为使用默认描述", "更改描述", "确定", "取消", false);
				if (text2 != null && Operators.CompareString(text, text2, true) != 0)
				{
					ModBase.WriteIni(PageVersionLeft.m_AlgoResolver.Path + "PCL\\Setup.ini", "CustomInfo", text2);
				}
				PageVersionLeft.m_AlgoResolver = new ModMinecraft.McVersion(PageVersionLeft.m_AlgoResolver.Name).Load();
				this.Reload();
				ModLoader.LoaderFolderRun(ModMinecraft.threadTag, ModMinecraft._MapperTag, ModLoader.LoaderFolderRunType.ForceRun, 1, "versions\\", false);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "版本 " + PageVersionLeft.m_AlgoResolver.Name + " 描述更改失败", ModBase.LogLevel.Msgbox, "出现错误");
			}
		}

		// Token: 0x0600076F RID: 1903 RVA: 0x00033C6C File Offset: 0x00031E6C
		private void BtnDisplayRename_Click(object sender, EventArgs e)
		{
			try
			{
				string name = PageVersionLeft.m_AlgoResolver.Name;
				string path = PageVersionLeft.m_AlgoResolver.Path;
				string text = ModMain.MyMsgBoxInput(name, new Collection<Validate>
				{
					new ValidateFolderName(ModMinecraft._MapperTag + "versions", true, false)
				}, "", "重命名版本", "确定", "取消", false);
				if (!string.IsNullOrWhiteSpace(text))
				{
					string text2 = ModMinecraft._MapperTag + "versions\\" + text + "\\";
					string text3 = text + "_temp";
					string directory = ModMinecraft._MapperTag + "versions\\" + text3 + "\\";
					bool flag = Operators.CompareString(text.ToLower(), name.ToLower(), true) == 0;
					JObject jobject;
					try
					{
						jobject = (JObject)ModBase.GetJson(ModBase.ReadFile(PageVersionLeft.m_AlgoResolver.Path + PageVersionLeft.m_AlgoResolver.Name + ".json"));
					}
					catch (Exception ex)
					{
						ModBase.Log(ex, "重命名读取 Json 时失败", ModBase.LogLevel.Debug, "出现错误");
						jobject = PageVersionLeft.m_AlgoResolver.DestroyPrototype();
					}
					MyWpfExtension.FindModel().FileSystem.RenameDirectory(path, text3);
					MyWpfExtension.FindModel().FileSystem.RenameDirectory(directory, text);
					try
					{
						foreach (DirectoryInfo directoryInfo in new DirectoryInfo(text2).EnumerateDirectories())
						{
							if (directoryInfo.Name.Contains(name))
							{
								if (flag)
								{
									MyWpfExtension.FindModel().FileSystem.RenameDirectory(directoryInfo.FullName, directoryInfo.Name + "_temp");
									MyWpfExtension.FindModel().FileSystem.RenameDirectory(directoryInfo.FullName + "_temp", directoryInfo.Name.Replace(name, text));
								}
								else
								{
									ModBase.DeleteDirectory(text2 + directoryInfo.Name.Replace(name, text), false);
									MyWpfExtension.FindModel().FileSystem.RenameDirectory(directoryInfo.FullName, directoryInfo.Name.Replace(name, text));
								}
							}
						}
					}
					finally
					{
						IEnumerator<DirectoryInfo> enumerator;
						if (enumerator != null)
						{
							enumerator.Dispose();
						}
					}
					try
					{
						foreach (FileInfo fileInfo in new DirectoryInfo(text2).EnumerateFiles())
						{
							if (fileInfo.Name.Contains(name))
							{
								if (flag)
								{
									MyWpfExtension.FindModel().FileSystem.RenameFile(fileInfo.FullName, fileInfo.Name + "_temp");
									MyWpfExtension.FindModel().FileSystem.RenameFile(fileInfo.FullName + "_temp", fileInfo.Name.Replace(name, text));
								}
								else
								{
									if (File.Exists(text2 + fileInfo.Name.Replace(name, text)))
									{
										File.Delete(text2 + fileInfo.Name.Replace(name, text));
									}
									MyWpfExtension.FindModel().FileSystem.RenameFile(fileInfo.FullName, fileInfo.Name.Replace(name, text));
								}
							}
						}
					}
					finally
					{
						IEnumerator<FileInfo> enumerator2;
						if (enumerator2 != null)
						{
							enumerator2.Dispose();
						}
					}
					if (File.Exists(text2 + "PCL\\Setup.ini"))
					{
						ModBase.WriteFile(text2 + "PCL\\Setup.ini", ModBase.ReadFile(text2 + "PCL\\Setup.ini").Replace(path, text2), false, null);
					}
					if (Operators.CompareString(ModBase.ReadIni(ModMinecraft._MapperTag + "PCL.ini", "Version", ""), name, true) == 0)
					{
						ModBase.WriteIni(ModMinecraft._MapperTag + "PCL.ini", "Version", text);
					}
					if (File.Exists(text2 + text + ".json"))
					{
						try
						{
							jobject["id"] = text;
							ModBase.WriteFile(text2 + text + ".json", jobject.ToString(), false, null);
						}
						catch (Exception ex2)
						{
							ModBase.Log(ex2, "重命名 Json 时失败", ModBase.LogLevel.Debug, "出现错误");
						}
					}
					ModMain.Hint("重命名成功！", ModMain.HintType.Finish, true);
					PageVersionLeft.m_AlgoResolver = new ModMinecraft.McVersion(text).Load();
					if (!Information.IsNothing(ModMinecraft.SetupResolver()) && ModMinecraft.SetupResolver().Equals(PageVersionLeft.m_AlgoResolver))
					{
						ModBase.WriteIni(ModMinecraft._MapperTag + "PCL.ini", "Version", text);
					}
					this.Reload();
					ModLoader.LoaderFolderRun(ModMinecraft.threadTag, ModMinecraft._MapperTag, ModLoader.LoaderFolderRunType.ForceRun, 1, "versions\\", false);
				}
			}
			catch (Exception ex3)
			{
				ModBase.Log(ex3, "重命名版本失败", ModBase.LogLevel.Msgbox, "出现错误");
			}
		}

		// Token: 0x06000770 RID: 1904 RVA: 0x00034184 File Offset: 0x00032384
		private void BtnDisplayStar_Click(object sender, EventArgs e)
		{
			try
			{
				ModBase.WriteIni(PageVersionLeft.m_AlgoResolver.Path + "PCL\\Setup.ini", "IsStar", Conversions.ToString(!PageVersionLeft.m_AlgoResolver._ProducerProccesor));
				PageVersionLeft.m_AlgoResolver = new ModMinecraft.McVersion(PageVersionLeft.m_AlgoResolver.Name).Load();
				this.Reload();
				ModMinecraft._PolicyTag = true;
				ModLoader.LoaderFolderRun(ModMinecraft.threadTag, ModMinecraft._MapperTag, ModLoader.LoaderFolderRunType.ForceRun, 1, "versions\\", false);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "版本 " + PageVersionLeft.m_AlgoResolver.Name + " 收藏状态更改失败", ModBase.LogLevel.Msgbox, "出现错误");
			}
		}

		// Token: 0x06000771 RID: 1905 RVA: 0x00034244 File Offset: 0x00032444
		private void BtnManageCheck_Click(object sender, EventArgs e)
		{
			checked
			{
				try
				{
					PageVersionOverall._Closure$__9-0 CS$<>8__locals1 = new PageVersionOverall._Closure$__9-0(CS$<>8__locals1);
					object loaderTaskbarLock = ModLoader.LoaderTaskbarLock;
					ObjectFlowControl.CheckForSyncLockOnValueType(loaderTaskbarLock);
					lock (loaderTaskbarLock)
					{
						int num = ModLoader.LoaderTaskbar.Count - 1;
						for (int i = 0; i <= num; i++)
						{
							if (Operators.CompareString(ModLoader.LoaderTaskbar[i].Name, PageVersionLeft.m_AlgoResolver.Name + " 文件补全", true) == 0)
							{
								ModMain.Hint("正在处理中，请稍候！", ModMain.HintType.Critical, true);
								return;
							}
						}
					}
					CS$<>8__locals1.$VB$Local_Loader = new ModLoader.LoaderCombo<string>(PageVersionLeft.m_AlgoResolver.Name + " 文件补全", ModDownload.DlClientFix(PageVersionLeft.m_AlgoResolver, true, ModDownload.AssetsIndexExistsBehaviour.AlwaysDownload, false));
					CS$<>8__locals1.$VB$Local_Loader.OnStateChanged = delegate(ModLoader.LoaderBase a0)
					{
						base._Lambda$__0();
					};
					CS$<>8__locals1.$VB$Local_Loader.Start(PageVersionLeft.m_AlgoResolver.Name, false);
					ModLoader.LoaderTaskbarAdd(CS$<>8__locals1.$VB$Local_Loader);
					ModMain.m_CollectionAccount.BtnExtraDownload.ShowRefresh();
					ModMain.m_CollectionAccount.BtnExtraDownload.Ribble();
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "尝试补全文件失败（" + PageVersionLeft.m_AlgoResolver.Name + "）", ModBase.LogLevel.Msgbox, "出现错误");
				}
			}
		}

		// Token: 0x06000772 RID: 1906 RVA: 0x000343C4 File Offset: 0x000325C4
		private void BtnManageDelete_Click(object sender, EventArgs e)
		{
			try
			{
				if (ModMain.MyMsgBox("你确定要删除版本 " + PageVersionLeft.m_AlgoResolver.Name + " 吗？该操作不可撤销！" + ((Operators.CompareString(PageVersionLeft.m_AlgoResolver.CreateComparator(), ModMinecraft._MapperTag, true) != 0) ? "\r\n由于该版本开启了版本隔离，删除版本时该版本对应的存档、资源包、Mod 等文件也将被一并删除！" : ""), "删除版本", "确定", "取消", "", true, true, false) == 1)
				{
					ModBase.DeleteDirectory(PageVersionLeft.m_AlgoResolver.Path, false);
					ModMain.Hint("版本 " + PageVersionLeft.m_AlgoResolver.Name + " 已删除！", ModMain.HintType.Finish, true);
					ModLoader.LoaderFolderRun(ModMinecraft.threadTag, ModMinecraft._MapperTag, ModLoader.LoaderFolderRunType.ForceRun, 1, "versions\\", false);
					ModMain.m_CollectionAccount.PageBack();
				}
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "删除版本 " + PageVersionLeft.m_AlgoResolver.Name + " 失败", ModBase.LogLevel.Msgbox, "出现错误");
			}
		}

		// Token: 0x06000773 RID: 1907 RVA: 0x00005F25 File Offset: 0x00004125
		private void BtnManageFolder_Click()
		{
			PageVersionOverall.OpenVersionFolder(PageVersionLeft.m_AlgoResolver);
		}

		// Token: 0x06000774 RID: 1908 RVA: 0x00005F31 File Offset: 0x00004131
		public static void OpenVersionFolder(ModMinecraft.McVersion Version)
		{
			ModBase.OpenExplorer("\"" + Version.Path + "\"");
		}

		// Token: 0x06000775 RID: 1909 RVA: 0x000344C4 File Offset: 0x000326C4
		private void ComboDisplayLogo_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (this.invocationResolver && ModAnimation.DefineModel() == 0)
			{
				try
				{
					if (this.ComboDisplayLogo.SelectedItem == this.ItemDisplayLogoCustom)
					{
						string text = ModBase.SelectFile("常用图片文件(*.png;*.jpg;*.gif)|*.png;*.jpg;*.gif", "选择图片");
						if (Operators.CompareString(text, "", true) == 0)
						{
							this.Reload();
							return;
						}
						File.Delete(PageVersionLeft.m_AlgoResolver.Path + "PCL\\Logo.png");
						File.Copy(text, PageVersionLeft.m_AlgoResolver.Path + "PCL\\Logo.png");
					}
					else
					{
						File.Delete(PageVersionLeft.m_AlgoResolver.Path + "PCL\\Logo.png");
					}
				}
				catch (Exception ex)
				{
					ModBase.Log(ex, "更改自定义版本图标失败（" + PageVersionLeft.m_AlgoResolver.Name + "）", ModBase.LogLevel.Feedback, "出现错误");
				}
				try
				{
					string text2 = Conversions.ToString(NewLateBinding.LateGet(this.ComboDisplayLogo.SelectedItem, null, "Tag", new object[0], null, null, null));
					ModBase.WriteIni(PageVersionLeft.m_AlgoResolver.Path + "PCL\\Setup.ini", "Logo", text2);
					ModBase.WriteIni(PageVersionLeft.m_AlgoResolver.Path + "PCL\\Setup.ini", "LogoCustom", Conversions.ToString(Operators.CompareString(text2, "", true) != 0));
					ModBase.WriteIni(ModMinecraft._MapperTag + "PCL.ini", "VersionCache", "");
					PageVersionLeft.m_AlgoResolver = new ModMinecraft.McVersion(PageVersionLeft.m_AlgoResolver.Name).Load();
					this.Reload();
					ModLoader.LoaderFolderRun(ModMinecraft.threadTag, ModMinecraft._MapperTag, ModLoader.LoaderFolderRunType.ForceRun, 1, "versions\\", false);
				}
				catch (Exception ex2)
				{
					ModBase.Log(ex2, "更改版本图标失败（" + PageVersionLeft.m_AlgoResolver.Name + "）", ModBase.LogLevel.Feedback, "出现错误");
				}
			}
		}

		// Token: 0x17000113 RID: 275
		// (get) Token: 0x06000776 RID: 1910 RVA: 0x00005F4D File Offset: 0x0000414D
		// (set) Token: 0x06000777 RID: 1911 RVA: 0x00005F55 File Offset: 0x00004155
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x17000114 RID: 276
		// (get) Token: 0x06000778 RID: 1912 RVA: 0x00005F5E File Offset: 0x0000415E
		// (set) Token: 0x06000779 RID: 1913 RVA: 0x00005F66 File Offset: 0x00004166
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x17000115 RID: 277
		// (get) Token: 0x0600077A RID: 1914 RVA: 0x00005F6F File Offset: 0x0000416F
		// (set) Token: 0x0600077B RID: 1915 RVA: 0x00005F77 File Offset: 0x00004177
		internal virtual MyCard PanDisplay { get; set; }

		// Token: 0x17000116 RID: 278
		// (get) Token: 0x0600077C RID: 1916 RVA: 0x00005F80 File Offset: 0x00004180
		// (set) Token: 0x0600077D RID: 1917 RVA: 0x00005F88 File Offset: 0x00004188
		internal virtual Grid PanDisplayItem { get; set; }

		// Token: 0x17000117 RID: 279
		// (get) Token: 0x0600077E RID: 1918 RVA: 0x00005F91 File Offset: 0x00004191
		// (set) Token: 0x0600077F RID: 1919 RVA: 0x00005F99 File Offset: 0x00004199
		internal virtual Grid PanDisplayIcon { get; set; }

		// Token: 0x17000118 RID: 280
		// (get) Token: 0x06000780 RID: 1920 RVA: 0x00005FA2 File Offset: 0x000041A2
		// (set) Token: 0x06000781 RID: 1921 RVA: 0x000346C4 File Offset: 0x000328C4
		internal virtual MyComboBox ComboDisplayLogo
		{
			[CompilerGenerated]
			get
			{
				return this.m_UtilsResolver;
			}
			[CompilerGenerated]
			set
			{
				SelectionChangedEventHandler value2 = new SelectionChangedEventHandler(this.ComboDisplayLogo_SelectionChanged);
				MyComboBox utilsResolver = this.m_UtilsResolver;
				if (utilsResolver != null)
				{
					utilsResolver.SelectionChanged -= value2;
				}
				this.m_UtilsResolver = value;
				utilsResolver = this.m_UtilsResolver;
				if (utilsResolver != null)
				{
					utilsResolver.SelectionChanged += value2;
				}
			}
		}

		// Token: 0x17000119 RID: 281
		// (get) Token: 0x06000782 RID: 1922 RVA: 0x00005FAA File Offset: 0x000041AA
		// (set) Token: 0x06000783 RID: 1923 RVA: 0x00005FB2 File Offset: 0x000041B2
		internal virtual MyComboBoxItem ItemDisplayLogoCustom { get; set; }

		// Token: 0x1700011A RID: 282
		// (get) Token: 0x06000784 RID: 1924 RVA: 0x00005FBB File Offset: 0x000041BB
		// (set) Token: 0x06000785 RID: 1925 RVA: 0x00034708 File Offset: 0x00032908
		internal virtual MyComboBox ComboDisplayType
		{
			[CompilerGenerated]
			get
			{
				return this.policyResolver;
			}
			[CompilerGenerated]
			set
			{
				SelectionChangedEventHandler value2 = new SelectionChangedEventHandler(this.ComboDisplayType_SelectionChanged);
				MyComboBox myComboBox = this.policyResolver;
				if (myComboBox != null)
				{
					myComboBox.SelectionChanged -= value2;
				}
				this.policyResolver = value;
				myComboBox = this.policyResolver;
				if (myComboBox != null)
				{
					myComboBox.SelectionChanged += value2;
				}
			}
		}

		// Token: 0x1700011B RID: 283
		// (get) Token: 0x06000786 RID: 1926 RVA: 0x00005FC3 File Offset: 0x000041C3
		// (set) Token: 0x06000787 RID: 1927 RVA: 0x0003474C File Offset: 0x0003294C
		internal virtual MyButton BtnDisplayRename
		{
			[CompilerGenerated]
			get
			{
				return this.m_ThreadResolver;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnDisplayRename_Click);
				MyButton threadResolver = this.m_ThreadResolver;
				if (threadResolver != null)
				{
					threadResolver.RevertResolver(obj);
				}
				this.m_ThreadResolver = value;
				threadResolver = this.m_ThreadResolver;
				if (threadResolver != null)
				{
					threadResolver.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700011C RID: 284
		// (get) Token: 0x06000788 RID: 1928 RVA: 0x00005FCB File Offset: 0x000041CB
		// (set) Token: 0x06000789 RID: 1929 RVA: 0x00034790 File Offset: 0x00032990
		internal virtual MyButton BtnDisplayDesc
		{
			[CompilerGenerated]
			get
			{
				return this.connectionResolver;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnDisplayDesc_Click);
				MyButton myButton = this.connectionResolver;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.connectionResolver = value;
				myButton = this.connectionResolver;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700011D RID: 285
		// (get) Token: 0x0600078A RID: 1930 RVA: 0x00005FD3 File Offset: 0x000041D3
		// (set) Token: 0x0600078B RID: 1931 RVA: 0x000347D4 File Offset: 0x000329D4
		internal virtual MyButton BtnDisplayStar
		{
			[CompilerGenerated]
			get
			{
				return this.customerResolver;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnDisplayStar_Click);
				MyButton myButton = this.customerResolver;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.customerResolver = value;
				myButton = this.customerResolver;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x1700011E RID: 286
		// (get) Token: 0x0600078C RID: 1932 RVA: 0x00005FDB File Offset: 0x000041DB
		// (set) Token: 0x0600078D RID: 1933 RVA: 0x00005FE3 File Offset: 0x000041E3
		internal virtual MyCard PanManage { get; set; }

		// Token: 0x1700011F RID: 287
		// (get) Token: 0x0600078E RID: 1934 RVA: 0x00005FEC File Offset: 0x000041EC
		// (set) Token: 0x0600078F RID: 1935 RVA: 0x00034818 File Offset: 0x00032A18
		internal virtual MyButton BtnManageFolder
		{
			[CompilerGenerated]
			get
			{
				return this.m_DatabaseResolver;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = delegate(object sender, EventArgs e)
				{
					this.BtnManageFolder_Click();
				};
				MyButton databaseResolver = this.m_DatabaseResolver;
				if (databaseResolver != null)
				{
					databaseResolver.RevertResolver(obj);
				}
				this.m_DatabaseResolver = value;
				databaseResolver = this.m_DatabaseResolver;
				if (databaseResolver != null)
				{
					databaseResolver.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000120 RID: 288
		// (get) Token: 0x06000790 RID: 1936 RVA: 0x00005FF4 File Offset: 0x000041F4
		// (set) Token: 0x06000791 RID: 1937 RVA: 0x0003485C File Offset: 0x00032A5C
		internal virtual MyButton BtnManageCheck
		{
			[CompilerGenerated]
			get
			{
				return this._CallbackResolver;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnManageCheck_Click);
				MyButton callbackResolver = this._CallbackResolver;
				if (callbackResolver != null)
				{
					callbackResolver.RevertResolver(obj);
				}
				this._CallbackResolver = value;
				callbackResolver = this._CallbackResolver;
				if (callbackResolver != null)
				{
					callbackResolver.PostResolver(obj);
				}
			}
		}

		// Token: 0x17000121 RID: 289
		// (get) Token: 0x06000792 RID: 1938 RVA: 0x00005FFC File Offset: 0x000041FC
		// (set) Token: 0x06000793 RID: 1939 RVA: 0x000348A0 File Offset: 0x00032AA0
		internal virtual MyButton BtnManageDelete
		{
			[CompilerGenerated]
			get
			{
				return this.advisorResolver;
			}
			[CompilerGenerated]
			set
			{
				MyButton.ClickEventHandler obj = new MyButton.ClickEventHandler(this.BtnManageDelete_Click);
				MyButton myButton = this.advisorResolver;
				if (myButton != null)
				{
					myButton.RevertResolver(obj);
				}
				this.advisorResolver = value;
				myButton = this.advisorResolver;
				if (myButton != null)
				{
					myButton.PostResolver(obj);
				}
			}
		}

		// Token: 0x06000794 RID: 1940 RVA: 0x000348E4 File Offset: 0x00032AE4
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.observerResolver)
			{
				this.observerResolver = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pageversion/pageversionoverall.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000795 RID: 1941 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000796 RID: 1942 RVA: 0x00034914 File Offset: 0x00032B14
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			if (connectionId == 3)
			{
				this.PanDisplay = (MyCard)target;
				return;
			}
			if (connectionId == 4)
			{
				this.PanDisplayItem = (Grid)target;
				return;
			}
			if (connectionId == 5)
			{
				this.PanDisplayIcon = (Grid)target;
				return;
			}
			if (connectionId == 6)
			{
				this.ComboDisplayLogo = (MyComboBox)target;
				return;
			}
			if (connectionId == 7)
			{
				this.ItemDisplayLogoCustom = (MyComboBoxItem)target;
				return;
			}
			if (connectionId == 8)
			{
				this.ComboDisplayType = (MyComboBox)target;
				return;
			}
			if (connectionId == 9)
			{
				this.BtnDisplayRename = (MyButton)target;
				return;
			}
			if (connectionId == 10)
			{
				this.BtnDisplayDesc = (MyButton)target;
				return;
			}
			if (connectionId == 11)
			{
				this.BtnDisplayStar = (MyButton)target;
				return;
			}
			if (connectionId == 12)
			{
				this.PanManage = (MyCard)target;
				return;
			}
			if (connectionId == 13)
			{
				this.BtnManageFolder = (MyButton)target;
				return;
			}
			if (connectionId == 14)
			{
				this.BtnManageCheck = (MyButton)target;
				return;
			}
			if (connectionId == 15)
			{
				this.BtnManageDelete = (MyButton)target;
				return;
			}
			this.observerResolver = true;
		}

		// Token: 0x04000351 RID: 849
		private bool invocationResolver;

		// Token: 0x04000352 RID: 850
		public MyListItem m_ComposerResolver;

		// Token: 0x04000353 RID: 851
		[CompilerGenerated]
		[AccessedThroughProperty("PanBack")]
		private MyScrollViewer _ItemResolver;

		// Token: 0x04000354 RID: 852
		[CompilerGenerated]
		[AccessedThroughProperty("PanMain")]
		private StackPanel mapperResolver;

		// Token: 0x04000355 RID: 853
		[AccessedThroughProperty("PanDisplay")]
		[CompilerGenerated]
		private MyCard _FactoryResolver;

		// Token: 0x04000356 RID: 854
		[AccessedThroughProperty("PanDisplayItem")]
		[CompilerGenerated]
		private Grid _ProcessResolver;

		// Token: 0x04000357 RID: 855
		[AccessedThroughProperty("PanDisplayIcon")]
		[CompilerGenerated]
		private Grid valResolver;

		// Token: 0x04000358 RID: 856
		[CompilerGenerated]
		[AccessedThroughProperty("ComboDisplayLogo")]
		private MyComboBox m_UtilsResolver;

		// Token: 0x04000359 RID: 857
		[AccessedThroughProperty("ItemDisplayLogoCustom")]
		[CompilerGenerated]
		private MyComboBoxItem m_OrderResolver;

		// Token: 0x0400035A RID: 858
		[CompilerGenerated]
		[AccessedThroughProperty("ComboDisplayType")]
		private MyComboBox policyResolver;

		// Token: 0x0400035B RID: 859
		[AccessedThroughProperty("BtnDisplayRename")]
		[CompilerGenerated]
		private MyButton m_ThreadResolver;

		// Token: 0x0400035C RID: 860
		[CompilerGenerated]
		[AccessedThroughProperty("BtnDisplayDesc")]
		private MyButton connectionResolver;

		// Token: 0x0400035D RID: 861
		[CompilerGenerated]
		[AccessedThroughProperty("BtnDisplayStar")]
		private MyButton customerResolver;

		// Token: 0x0400035E RID: 862
		[CompilerGenerated]
		[AccessedThroughProperty("PanManage")]
		private MyCard m_SchemaResolver;

		// Token: 0x0400035F RID: 863
		[AccessedThroughProperty("BtnManageFolder")]
		[CompilerGenerated]
		private MyButton m_DatabaseResolver;

		// Token: 0x04000360 RID: 864
		[CompilerGenerated]
		[AccessedThroughProperty("BtnManageCheck")]
		private MyButton _CallbackResolver;

		// Token: 0x04000361 RID: 865
		[AccessedThroughProperty("BtnManageDelete")]
		[CompilerGenerated]
		private MyButton advisorResolver;

		// Token: 0x04000362 RID: 866
		private bool observerResolver;
	}
}
