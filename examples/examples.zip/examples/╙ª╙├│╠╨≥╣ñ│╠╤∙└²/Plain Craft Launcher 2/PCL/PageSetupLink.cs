﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x0200015E RID: 350
	[DesignerGenerated]
	public class PageSetupLink : MyPageRight, IComponentConnector
	{
		// Token: 0x06000F0C RID: 3852 RVA: 0x000094C6 File Offset: 0x000076C6
		public PageSetupLink()
		{
			base.Loaded += this.PageSetupLink_Loaded;
			this.m_RepositoryIssuer = false;
			this.InitializeComponent();
		}

		// Token: 0x06000F0D RID: 3853 RVA: 0x000094EE File Offset: 0x000076EE
		private void PageSetupLink_Loaded(object sender, RoutedEventArgs e)
		{
			this.PanBack.ScrollToHome();
			checked
			{
				if (!this.m_RepositoryIssuer)
				{
					this.m_RepositoryIssuer = true;
					ModAnimation.CheckModel(ModAnimation.DefineModel() + 1);
					this.Reload();
					ModAnimation.CheckModel(ModAnimation.DefineModel() - 1);
				}
			}
		}

		// Token: 0x06000F0E RID: 3854 RVA: 0x0006C45C File Offset: 0x0006A65C
		public void Reload()
		{
			this.CheckLinkAuto.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("LinkAuto", null));
			this.TextLinkName.Text = Conversions.ToString(ModBase._ParamsState.Get("LinkName", null));
		}

		// Token: 0x06000F0F RID: 3855 RVA: 0x0006C4AC File Offset: 0x0006A6AC
		public void Reset()
		{
			try
			{
				ModBase._ParamsState.Reset("LinkAuto", false, null);
				ModBase._ParamsState.Reset("LinkName", false, null);
				ModBase.Log("[Setup] 已初始化联机页设置", ModBase.LogLevel.Normal, "出现错误");
				ModMain.Hint("已初始化联机页设置！", ModMain.HintType.Finish, false);
			}
			catch (Exception ex)
			{
				ModBase.Log(ex, "初始化联机页设置失败", ModBase.LogLevel.Msgbox, "出现错误");
			}
			this.Reload();
		}

		// Token: 0x06000F10 RID: 3856 RVA: 0x00008FBA File Offset: 0x000071BA
		private static void CheckBoxChange(MyCheckBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.Checked, false, null);
			}
		}

		// Token: 0x06000F11 RID: 3857 RVA: 0x00008F3E File Offset: 0x0000713E
		private static void TextBoxChange(MyTextBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.Text, false, null);
			}
		}

		// Token: 0x1700026B RID: 619
		// (get) Token: 0x06000F12 RID: 3858 RVA: 0x00009528 File Offset: 0x00007728
		// (set) Token: 0x06000F13 RID: 3859 RVA: 0x00009530 File Offset: 0x00007730
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x1700026C RID: 620
		// (get) Token: 0x06000F14 RID: 3860 RVA: 0x00009539 File Offset: 0x00007739
		// (set) Token: 0x06000F15 RID: 3861 RVA: 0x00009541 File Offset: 0x00007741
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x1700026D RID: 621
		// (get) Token: 0x06000F16 RID: 3862 RVA: 0x0000954A File Offset: 0x0000774A
		// (set) Token: 0x06000F17 RID: 3863 RVA: 0x0006C530 File Offset: 0x0006A730
		internal virtual MyTextBox TextLinkName
		{
			[CompilerGenerated]
			get
			{
				return this._ComparatorIssuer;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = (PageSetupLink._Closure$__.$IR17-1 == null) ? (PageSetupLink._Closure$__.$IR17-1 = delegate(object sender, RoutedEventArgs e)
				{
					PageSetupLink.TextBoxChange((MyTextBox)sender, e);
				}) : PageSetupLink._Closure$__.$IR17-1;
				MyTextBox comparatorIssuer = this._ComparatorIssuer;
				if (comparatorIssuer != null)
				{
					comparatorIssuer.FindRepository(value2);
				}
				this._ComparatorIssuer = value;
				comparatorIssuer = this._ComparatorIssuer;
				if (comparatorIssuer != null)
				{
					comparatorIssuer.SetupRepository(value2);
				}
			}
		}

		// Token: 0x1700026E RID: 622
		// (get) Token: 0x06000F18 RID: 3864 RVA: 0x00009552 File Offset: 0x00007752
		// (set) Token: 0x06000F19 RID: 3865 RVA: 0x0006C58C File Offset: 0x0006A78C
		internal virtual MyCheckBox CheckLinkAuto
		{
			[CompilerGenerated]
			get
			{
				return this.prototypeIssuer;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = (PageSetupLink._Closure$__.$IR21-2 == null) ? (PageSetupLink._Closure$__.$IR21-2 = delegate(object a0, bool a1)
				{
					PageSetupLink.CheckBoxChange((MyCheckBox)a0, a1);
				}) : PageSetupLink._Closure$__.$IR21-2;
				MyCheckBox myCheckBox = this.prototypeIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.StopTag(obj);
				}
				this.prototypeIssuer = value;
				myCheckBox = this.prototypeIssuer;
				if (myCheckBox != null)
				{
					myCheckBox.CloneTag(obj);
				}
			}
		}

		// Token: 0x06000F1A RID: 3866 RVA: 0x0006C5E8 File Offset: 0x0006A7E8
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_IssuerIssuer)
			{
				this.m_IssuerIssuer = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagesetup/pagesetuplink.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000F1B RID: 3867 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000F1C RID: 3868 RVA: 0x0006C618 File Offset: 0x0006A818
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			if (connectionId == 3)
			{
				this.TextLinkName = (MyTextBox)target;
				return;
			}
			if (connectionId == 4)
			{
				this.CheckLinkAuto = (MyCheckBox)target;
				return;
			}
			this.m_IssuerIssuer = true;
		}

		// Token: 0x0400076C RID: 1900
		private bool m_RepositoryIssuer;

		// Token: 0x0400076D RID: 1901
		[CompilerGenerated]
		[AccessedThroughProperty("PanBack")]
		private MyScrollViewer m_ResolverIssuer;

		// Token: 0x0400076E RID: 1902
		[AccessedThroughProperty("PanMain")]
		[CompilerGenerated]
		private StackPanel tagIssuer;

		// Token: 0x0400076F RID: 1903
		[CompilerGenerated]
		[AccessedThroughProperty("TextLinkName")]
		private MyTextBox _ComparatorIssuer;

		// Token: 0x04000770 RID: 1904
		[CompilerGenerated]
		[AccessedThroughProperty("CheckLinkAuto")]
		private MyCheckBox prototypeIssuer;

		// Token: 0x04000771 RID: 1905
		private bool m_IssuerIssuer;
	}
}
