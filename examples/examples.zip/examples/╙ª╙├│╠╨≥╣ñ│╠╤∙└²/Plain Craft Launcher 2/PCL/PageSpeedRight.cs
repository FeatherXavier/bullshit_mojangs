﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000167 RID: 359
	[DesignerGenerated]
	public class PageSpeedRight : MyPageRight, IComponentConnector
	{
		// Token: 0x0600107F RID: 4223 RVA: 0x00009CD4 File Offset: 0x00007ED4
		public PageSpeedRight()
		{
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				this.Init();
			};
			this.InitializeComponent();
		}

		// Token: 0x06001080 RID: 4224 RVA: 0x00009CF5 File Offset: 0x00007EF5
		private void Init()
		{
			this.PanBack.ScrollToHome();
		}

		// Token: 0x170002D0 RID: 720
		// (get) Token: 0x06001081 RID: 4225 RVA: 0x00009D02 File Offset: 0x00007F02
		// (set) Token: 0x06001082 RID: 4226 RVA: 0x00009D0A File Offset: 0x00007F0A
		internal virtual MyScrollViewer PanBack { get; set; }

		// Token: 0x170002D1 RID: 721
		// (get) Token: 0x06001083 RID: 4227 RVA: 0x00009D13 File Offset: 0x00007F13
		// (set) Token: 0x06001084 RID: 4228 RVA: 0x00009D1B File Offset: 0x00007F1B
		internal virtual StackPanel PanMain { get; set; }

		// Token: 0x06001085 RID: 4229 RVA: 0x00071568 File Offset: 0x0006F768
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.methodIssuer)
			{
				this.methodIssuer = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagespeedright.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06001086 RID: 4230 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06001087 RID: 4231 RVA: 0x00009D24 File Offset: 0x00007F24
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanBack = (MyScrollViewer)target;
				return;
			}
			if (connectionId == 2)
			{
				this.PanMain = (StackPanel)target;
				return;
			}
			this.methodIssuer = true;
		}

		// Token: 0x04000826 RID: 2086
		[AccessedThroughProperty("PanBack")]
		[CompilerGenerated]
		private MyScrollViewer _GlobalIssuer;

		// Token: 0x04000827 RID: 2087
		[CompilerGenerated]
		[AccessedThroughProperty("PanMain")]
		private StackPanel listIssuer;

		// Token: 0x04000828 RID: 2088
		private bool methodIssuer;
	}
}
