﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x020000A3 RID: 163
	[DesignerGenerated]
	public class PageLoginNideSkin : Grid, IComponentConnector
	{
		// Token: 0x06000613 RID: 1555 RVA: 0x0000530A File Offset: 0x0000350A
		public PageLoginNideSkin()
		{
			base.Loaded += this.PageLoginLegacy_Loaded;
			this.InitializeComponent();
			this.Skin.m_RepositoryComparator = PageLaunchLeft.m_IndexerComparator;
		}

		// Token: 0x06000614 RID: 1556 RVA: 0x0000533B File Offset: 0x0000353B
		private void PageLoginLegacy_Loaded(object sender, RoutedEventArgs e)
		{
			this.Skin.m_RepositoryComparator.Start(null, false);
		}

		// Token: 0x06000615 RID: 1557 RVA: 0x0002D198 File Offset: 0x0002B398
		public void Reload(bool KeepInput)
		{
			this.TextName.Text = Conversions.ToString(ModBase._ParamsState.Get("CacheNideName", null));
			this.TextEmail.Text = Conversions.ToString(ModBase._ParamsState.Get("CacheNideUsername", null));
			this.TextEmail.Visibility = (Conversions.ToBoolean(ModBase._ParamsState.Get("UiLauncherEmail", null)) ? Visibility.Collapsed : Visibility.Visible);
		}

		// Token: 0x06000616 RID: 1558 RVA: 0x0002D20C File Offset: 0x0002B40C
		public static ModLaunch.McLoginServer GetLoginData()
		{
			string str = Conversions.ToString(Information.IsNothing(ModMinecraft.SetupResolver()) ? ModBase._ParamsState.Get("CacheNideServer", null) : ModBase._ParamsState.Get("VersionServerNide", ModMinecraft.SetupResolver()));
			return new ModLaunch.McLoginServer(ModLaunch.McLoginType.Nide)
			{
				m_ErrorProccesor = "Nide",
				m_InterpreterProccesor = Conversions.ToString(ModBase._ParamsState.Get("CacheNideUsername", null)),
				_ParserProccesor = Conversions.ToString(ModBase._ParamsState.Get("CacheNidePass", null)),
				_ExceptionProccesor = "统一通行证",
				Type = ModLaunch.McLoginType.Nide,
				_StubProccesor = "https://auth2.nide8.com:233/" + str + "/authserver"
			};
		}

		// Token: 0x06000617 RID: 1559 RVA: 0x0002D2C0 File Offset: 0x0002B4C0
		private void PageLoginNideSkin_MouseEnter(object sender, MouseEventArgs e)
		{
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaOpacity(this.BtnEdit, 1.0 - this.BtnEdit.Opacity, 80, 0, null, false),
				ModAnimation.AaHeight(this.BtnEdit, 25.5 - this.BtnEdit.Height, 140, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaHeight(this.BtnEdit, -1.5, 50, 140, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaOpacity(this.BtnExit, 1.0 - this.BtnExit.Opacity, 80, 0, null, false),
				ModAnimation.AaHeight(this.BtnExit, 25.5 - this.BtnExit.Height, 140, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaHeight(this.BtnExit, -1.5, 50, 140, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false)
			}, "PageLoginNideSkin Button", false);
		}

		// Token: 0x06000618 RID: 1560 RVA: 0x0002D3F0 File Offset: 0x0002B5F0
		private void PageLoginNideSkin_MouseLeave(object sender, MouseEventArgs e)
		{
			ModAnimation.AniStart(new ModAnimation.AniData[]
			{
				ModAnimation.AaOpacity(this.BtnEdit, -this.BtnEdit.Opacity, 120, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaHeight(this.BtnEdit, 14.0 - this.BtnEdit.Height, 120, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaOpacity(this.BtnExit, -this.BtnExit.Opacity, 120, 0, new ModAnimation.AniEaseOutFluent(ModAnimation.AniEasePower.Middle), false),
				ModAnimation.AaHeight(this.BtnExit, 14.0 - this.BtnExit.Height, 120, 0, new ModAnimation.AniEaseInFluent(ModAnimation.AniEasePower.Middle), false)
			}, "PageLoginNideSkin Button", false);
		}

		// Token: 0x06000619 RID: 1561 RVA: 0x0000534F File Offset: 0x0000354F
		private void BtnEdit_Click(object sender, EventArgs e)
		{
			ModBase.OpenWebsite("https://login2.nide8.com:233/account/changepw");
		}

		// Token: 0x0600061A RID: 1562 RVA: 0x0000535B File Offset: 0x0000355B
		private void BtnExit_Click()
		{
			ModBase._ParamsState.Set("CacheNideAccess", "", false, null);
			ModMain._FilterAccount.RefreshPage(false, true);
		}

		// Token: 0x0600061B RID: 1563 RVA: 0x0002D4C0 File Offset: 0x0002B6C0
		private void Skin_Click(object sender, MouseButtonEventArgs e)
		{
			ModBase.OpenWebsite(Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("https://login2.nide8.com:233/", Information.IsNothing(ModMinecraft.SetupResolver()) ? ModBase._ParamsState.Get("CacheNideServer", null) : ModBase._ParamsState.Get("VersionServerNide", ModMinecraft.SetupResolver())), "/skin")));
		}

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x0600061C RID: 1564 RVA: 0x0000537F File Offset: 0x0000357F
		// (set) Token: 0x0600061D RID: 1565 RVA: 0x0002D520 File Offset: 0x0002B720
		internal virtual Grid PanData
		{
			[CompilerGenerated]
			get
			{
				return this.m_RefRepository;
			}
			[CompilerGenerated]
			set
			{
				MouseEventHandler value2 = new MouseEventHandler(this.PageLoginNideSkin_MouseEnter);
				MouseEventHandler value3 = new MouseEventHandler(this.PageLoginNideSkin_MouseLeave);
				Grid refRepository = this.m_RefRepository;
				if (refRepository != null)
				{
					refRepository.MouseEnter -= value2;
					refRepository.MouseLeave -= value3;
				}
				this.m_RefRepository = value;
				refRepository = this.m_RefRepository;
				if (refRepository != null)
				{
					refRepository.MouseEnter += value2;
					refRepository.MouseLeave += value3;
				}
			}
		}

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x0600061E RID: 1566 RVA: 0x00005387 File Offset: 0x00003587
		// (set) Token: 0x0600061F RID: 1567 RVA: 0x0000538F File Offset: 0x0000358F
		internal virtual TextBlock TextName { get; set; }

		// Token: 0x170000DC RID: 220
		// (get) Token: 0x06000620 RID: 1568 RVA: 0x00005398 File Offset: 0x00003598
		// (set) Token: 0x06000621 RID: 1569 RVA: 0x000053A0 File Offset: 0x000035A0
		internal virtual TextBlock TextEmail { get; set; }

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x06000622 RID: 1570 RVA: 0x000053A9 File Offset: 0x000035A9
		// (set) Token: 0x06000623 RID: 1571 RVA: 0x0002D580 File Offset: 0x0002B780
		internal virtual MyIconButton BtnEdit
		{
			[CompilerGenerated]
			get
			{
				return this._ImporterRepository;
			}
			[CompilerGenerated]
			set
			{
				MyIconButton.ClickEventHandler value2 = new MyIconButton.ClickEventHandler(this.BtnEdit_Click);
				MyIconButton importerRepository = this._ImporterRepository;
				if (importerRepository != null)
				{
					importerRepository.Click -= value2;
				}
				this._ImporterRepository = value;
				importerRepository = this._ImporterRepository;
				if (importerRepository != null)
				{
					importerRepository.Click += value2;
				}
			}
		}

		// Token: 0x170000DE RID: 222
		// (get) Token: 0x06000624 RID: 1572 RVA: 0x000053B1 File Offset: 0x000035B1
		// (set) Token: 0x06000625 RID: 1573 RVA: 0x0002D5C4 File Offset: 0x0002B7C4
		internal virtual MyIconButton BtnExit
		{
			[CompilerGenerated]
			get
			{
				return this.m_ProxyRepository;
			}
			[CompilerGenerated]
			set
			{
				MyIconButton.ClickEventHandler value2 = delegate(object sender, EventArgs e)
				{
					this.BtnExit_Click();
				};
				MyIconButton proxyRepository = this.m_ProxyRepository;
				if (proxyRepository != null)
				{
					proxyRepository.Click -= value2;
				}
				this.m_ProxyRepository = value;
				proxyRepository = this.m_ProxyRepository;
				if (proxyRepository != null)
				{
					proxyRepository.Click += value2;
				}
			}
		}

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x06000626 RID: 1574 RVA: 0x000053B9 File Offset: 0x000035B9
		// (set) Token: 0x06000627 RID: 1575 RVA: 0x0002D608 File Offset: 0x0002B808
		internal virtual MySkin Skin
		{
			[CompilerGenerated]
			get
			{
				return this.classRepository;
			}
			[CompilerGenerated]
			set
			{
				MySkin.ClickEventHandler obj = new MySkin.ClickEventHandler(this.Skin_Click);
				MySkin mySkin = this.classRepository;
				if (mySkin != null)
				{
					mySkin.ResolveResolver(obj);
				}
				this.classRepository = value;
				mySkin = this.classRepository;
				if (mySkin != null)
				{
					mySkin.VerifyResolver(obj);
				}
			}
		}

		// Token: 0x06000628 RID: 1576 RVA: 0x0002D64C File Offset: 0x0002B84C
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this._RegistryRepository)
			{
				this._RegistryRepository = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagelaunch/pageloginnideskin.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000629 RID: 1577 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600062A RID: 1578 RVA: 0x0002D67C File Offset: 0x0002B87C
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.PanData = (Grid)target;
				return;
			}
			if (connectionId == 2)
			{
				this.TextName = (TextBlock)target;
				return;
			}
			if (connectionId == 3)
			{
				this.TextEmail = (TextBlock)target;
				return;
			}
			if (connectionId == 4)
			{
				this.BtnEdit = (MyIconButton)target;
				return;
			}
			if (connectionId == 5)
			{
				this.BtnExit = (MyIconButton)target;
				return;
			}
			if (connectionId == 6)
			{
				this.Skin = (MySkin)target;
				return;
			}
			this._RegistryRepository = true;
		}

		// Token: 0x040002C1 RID: 705
		[AccessedThroughProperty("PanData")]
		[CompilerGenerated]
		private Grid m_RefRepository;

		// Token: 0x040002C2 RID: 706
		[AccessedThroughProperty("TextName")]
		[CompilerGenerated]
		private TextBlock _ServerRepository;

		// Token: 0x040002C3 RID: 707
		[CompilerGenerated]
		[AccessedThroughProperty("TextEmail")]
		private TextBlock _ServiceRepository;

		// Token: 0x040002C4 RID: 708
		[AccessedThroughProperty("BtnEdit")]
		[CompilerGenerated]
		private MyIconButton _ImporterRepository;

		// Token: 0x040002C5 RID: 709
		[AccessedThroughProperty("BtnExit")]
		[CompilerGenerated]
		private MyIconButton m_ProxyRepository;

		// Token: 0x040002C6 RID: 710
		[AccessedThroughProperty("Skin")]
		[CompilerGenerated]
		private MySkin classRepository;

		// Token: 0x040002C7 RID: 711
		private bool _RegistryRepository;
	}
}
