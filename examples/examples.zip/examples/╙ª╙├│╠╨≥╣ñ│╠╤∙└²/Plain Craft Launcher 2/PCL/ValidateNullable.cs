﻿using System;
using Microsoft.VisualBasic;

namespace PCL
{
	// Token: 0x020000E1 RID: 225
	public class ValidateNullable : Validate
	{
		// Token: 0x060008EA RID: 2282 RVA: 0x0003F6B0 File Offset: 0x0003D8B0
		public override string Validate(string Str)
		{
			string result;
			if (!Information.IsNothing(Str) && !string.IsNullOrEmpty(Str))
			{
				result = "";
			}
			else
			{
				result = null;
			}
			return result;
		}
	}
}
