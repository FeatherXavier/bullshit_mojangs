﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.VisualBasic.CompilerServices;

namespace PCL
{
	// Token: 0x02000130 RID: 304
	[DesignerGenerated]
	public class PageLoginMojang : Grid, IComponentConnector
	{
		// Token: 0x06000BA6 RID: 2982 RVA: 0x00007C6D File Offset: 0x00005E6D
		public PageLoginMojang()
		{
			this._InitializerComparator = true;
			this.InitializeComponent();
		}

		// Token: 0x06000BA7 RID: 2983 RVA: 0x0005BB60 File Offset: 0x00059D60
		public void Reload(bool KeepInput)
		{
			this.CheckRemember.Checked = Conversions.ToBoolean(ModBase._ParamsState.Get("LoginRemember", null));
			if (KeepInput && !this._InitializerComparator)
			{
				string text = this.ComboName.Text;
				this.ComboName.ItemsSource = (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LoginMojangEmail", null), "", true) ? null : ModBase._ParamsState.Get("LoginMojangEmail", null).ToString().Split(new char[]
				{
					'¨'
				}));
				this.ComboName.Text = text;
			}
			else if (Operators.ConditionalCompareObjectEqual(ModBase._ParamsState.Get("LoginMojangEmail", null), "", true))
			{
				this.ComboName.ItemsSource = null;
			}
			else
			{
				this.ComboName.ItemsSource = ModBase._ParamsState.Get("LoginMojangEmail", null).ToString().Split(new char[]
				{
					'¨'
				});
				this.ComboName.Text = ModBase._ParamsState.Get("LoginMojangEmail", null).ToString().Split(new char[]
				{
					'¨'
				})[0];
				if (Conversions.ToBoolean(ModBase._ParamsState.Get("LoginRemember", null)))
				{
					this.TextPass.Password = ModBase._ParamsState.Get("LoginMojangPass", null).ToString().Split(new char[]
					{
						'¨'
					})[0].Trim();
				}
			}
			this._InitializerComparator = false;
		}

		// Token: 0x06000BA8 RID: 2984 RVA: 0x0005BCF8 File Offset: 0x00059EF8
		public static ModLaunch.McLoginServer GetLoginData()
		{
			ModLaunch.McLoginServer result;
			if (ModMain._ServerAccount == null)
			{
				result = new ModLaunch.McLoginServer(ModLaunch.McLoginType.Mojang)
				{
					_StubProccesor = "https://authserver.mojang.com",
					m_ErrorProccesor = "Mojang",
					m_InterpreterProccesor = "",
					_ParserProccesor = "",
					Type = ModLaunch.McLoginType.Mojang,
					_ExceptionProccesor = "Mojang 正版"
				};
			}
			else
			{
				result = new ModLaunch.McLoginServer(ModLaunch.McLoginType.Mojang)
				{
					_StubProccesor = "https://authserver.mojang.com",
					m_ErrorProccesor = "Mojang",
					m_InterpreterProccesor = (ModMain._ServerAccount.ComboName.Text ?? "").Replace("¨", "").Trim(),
					_ParserProccesor = (ModMain._ServerAccount.TextPass.Password ?? "").Replace("¨", "").Trim(),
					Type = ModLaunch.McLoginType.Mojang,
					_ExceptionProccesor = "Mojang 正版"
				};
			}
			return result;
		}

		// Token: 0x06000BA9 RID: 2985 RVA: 0x0005BDEC File Offset: 0x00059FEC
		public static string IsVaild(ModLaunch.McLoginServer LoginData)
		{
			string result;
			if (Operators.CompareString(LoginData.m_InterpreterProccesor, "", true) == 0)
			{
				result = "邮箱不能为空！";
			}
			else if (!LoginData.m_InterpreterProccesor.Contains("@"))
			{
				result = "邮箱格式错误！";
			}
			else if (Operators.CompareString(LoginData._ParserProccesor, "", true) == 0)
			{
				result = "密码不能为空！";
			}
			else
			{
				result = "";
			}
			return result;
		}

		// Token: 0x06000BAA RID: 2986 RVA: 0x00007C83 File Offset: 0x00005E83
		public string IsVaild()
		{
			return PageLoginMojang.IsVaild(PageLoginMojang.GetLoginData());
		}

		// Token: 0x06000BAB RID: 2987 RVA: 0x0005BE50 File Offset: 0x0005A050
		private void ComboMojangName_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (Operators.ConditionalCompareObjectEqual(NewLateBinding.LateGet(sender, null, "Text", new object[0], null, null, null), "", true))
			{
				this.TextPass.Password = "";
			}
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set("CacheMojangAccess", "", false, null);
			}
		}

		// Token: 0x06000BAC RID: 2988 RVA: 0x00007C8F File Offset: 0x00005E8F
		private void TextMojangPass_PasswordChanged(object sender, RoutedEventArgs e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set("CacheMojangAccess", "", false, null);
			}
		}

		// Token: 0x06000BAD RID: 2989 RVA: 0x0005BEAC File Offset: 0x0005A0AC
		private void ComboMojangName_SelectionChanged(MyComboBox sender, SelectionChangedEventArgs e)
		{
			if (Conversions.ToBoolean(sender.SelectedIndex == -1 || Conversions.ToBoolean(Operators.NotObject(ModBase._ParamsState.Get("LoginRemember", null)))))
			{
				this.TextPass.Password = "";
				return;
			}
			this.TextPass.Password = ModBase._ParamsState.Get("LoginMojangPass", null).ToString().Split(new char[]
			{
				'¨'
			})[sender.SelectedIndex].Trim();
		}

		// Token: 0x06000BAE RID: 2990 RVA: 0x00004F3C File Offset: 0x0000313C
		private void CheckRememberChange(MyCheckBox sender, object e)
		{
			if (ModAnimation.DefineModel() == 0)
			{
				ModBase._ParamsState.Set(Conversions.ToString(sender.Tag), sender.Checked, false, null);
			}
		}

		// Token: 0x06000BAF RID: 2991 RVA: 0x0005BF3C File Offset: 0x0005A13C
		private void InputChanged()
		{
			this.BtnLink.Content = ((Operators.CompareString(this.ComboName.Text, "", true) != 0 || Operators.CompareString(this.TextPass.Password, "", true) != 0) ? "找回密码" : "购买正版");
		}

		// Token: 0x06000BB0 RID: 2992 RVA: 0x00007CAE File Offset: 0x00005EAE
		private void BtnMojang_Click(object sender, EventArgs e)
		{
			if (Operators.ConditionalCompareObjectEqual(this.BtnLink.Content, "购买正版", true))
			{
				ModBase.OpenWebsite("https://www.minecraft.net/store/minecraft-java-edition/buy");
				return;
			}
			ModBase.OpenWebsite("https://account.mojang.com/password");
		}

		// Token: 0x170001AE RID: 430
		// (get) Token: 0x06000BB1 RID: 2993 RVA: 0x00007CDD File Offset: 0x00005EDD
		// (set) Token: 0x06000BB2 RID: 2994 RVA: 0x0005BF90 File Offset: 0x0005A190
		internal virtual MyComboBox ComboName
		{
			[CompilerGenerated]
			get
			{
				return this._SystemComparator;
			}
			[CompilerGenerated]
			set
			{
				MyComboBox.TextChangedEventHandler obj = new MyComboBox.TextChangedEventHandler(this.ComboMojangName_TextChanged);
				SelectionChangedEventHandler value2 = delegate(object sender, SelectionChangedEventArgs e)
				{
					this.ComboMojangName_SelectionChanged((MyComboBox)sender, e);
				};
				MyComboBox.TextChangedEventHandler obj2 = delegate(object sender, TextChangedEventArgs e)
				{
					this.InputChanged();
				};
				MyComboBox systemComparator = this._SystemComparator;
				if (systemComparator != null)
				{
					systemComparator.VisitModel(obj);
					systemComparator.SelectionChanged -= value2;
					systemComparator.VisitModel(obj2);
				}
				this._SystemComparator = value;
				systemComparator = this._SystemComparator;
				if (systemComparator != null)
				{
					systemComparator.GetModel(obj);
					systemComparator.SelectionChanged += value2;
					systemComparator.GetModel(obj2);
				}
			}
		}

		// Token: 0x170001AF RID: 431
		// (get) Token: 0x06000BB3 RID: 2995 RVA: 0x00007CE5 File Offset: 0x00005EE5
		// (set) Token: 0x06000BB4 RID: 2996 RVA: 0x0005C00C File Offset: 0x0005A20C
		internal virtual PasswordBox TextPass
		{
			[CompilerGenerated]
			get
			{
				return this.m_WriterComparator;
			}
			[CompilerGenerated]
			set
			{
				RoutedEventHandler value2 = new RoutedEventHandler(this.TextMojangPass_PasswordChanged);
				RoutedEventHandler value3 = delegate(object sender, RoutedEventArgs e)
				{
					this.InputChanged();
				};
				PasswordBox writerComparator = this.m_WriterComparator;
				if (writerComparator != null)
				{
					writerComparator.PasswordChanged -= value2;
					writerComparator.PasswordChanged -= value3;
				}
				this.m_WriterComparator = value;
				writerComparator = this.m_WriterComparator;
				if (writerComparator != null)
				{
					writerComparator.PasswordChanged += value2;
					writerComparator.PasswordChanged += value3;
				}
			}
		}

		// Token: 0x170001B0 RID: 432
		// (get) Token: 0x06000BB5 RID: 2997 RVA: 0x00007CED File Offset: 0x00005EED
		// (set) Token: 0x06000BB6 RID: 2998 RVA: 0x0005C06C File Offset: 0x0005A26C
		internal virtual MyCheckBox CheckRemember
		{
			[CompilerGenerated]
			get
			{
				return this._BroadcasterComparator;
			}
			[CompilerGenerated]
			set
			{
				MyCheckBox.ChangeEventHandler obj = delegate(object a0, bool a1)
				{
					this.CheckRememberChange((MyCheckBox)a0, a1);
				};
				MyCheckBox broadcasterComparator = this._BroadcasterComparator;
				if (broadcasterComparator != null)
				{
					broadcasterComparator.StopTag(obj);
				}
				this._BroadcasterComparator = value;
				broadcasterComparator = this._BroadcasterComparator;
				if (broadcasterComparator != null)
				{
					broadcasterComparator.CloneTag(obj);
				}
			}
		}

		// Token: 0x170001B1 RID: 433
		// (get) Token: 0x06000BB7 RID: 2999 RVA: 0x00007CF5 File Offset: 0x00005EF5
		// (set) Token: 0x06000BB8 RID: 3000 RVA: 0x0005C0B0 File Offset: 0x0005A2B0
		internal virtual MyTextButton BtnLink
		{
			[CompilerGenerated]
			get
			{
				return this.m_AttributeComparator;
			}
			[CompilerGenerated]
			set
			{
				MyTextButton.ClickEventHandler obj = new MyTextButton.ClickEventHandler(this.BtnMojang_Click);
				MyTextButton attributeComparator = this.m_AttributeComparator;
				if (attributeComparator != null)
				{
					attributeComparator.TestRepository(obj);
				}
				this.m_AttributeComparator = value;
				attributeComparator = this.m_AttributeComparator;
				if (attributeComparator != null)
				{
					attributeComparator.ResolveRepository(obj);
				}
			}
		}

		// Token: 0x06000BB9 RID: 3001 RVA: 0x0005C0F4 File Offset: 0x0005A2F4
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!this.m_SpecificationComparator)
			{
				this.m_SpecificationComparator = true;
				Uri resourceLocator = new Uri("/Plain Craft Launcher 2;component/pages/pagelaunch/pageloginmojang.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		// Token: 0x06000BBA RID: 3002 RVA: 0x00003275 File Offset: 0x00001475
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000BBB RID: 3003 RVA: 0x0005C124 File Offset: 0x0005A324
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void System_Windows_Markup_IComponentConnector_Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.ComboName = (MyComboBox)target;
				return;
			}
			if (connectionId == 2)
			{
				this.TextPass = (PasswordBox)target;
				return;
			}
			if (connectionId == 3)
			{
				this.CheckRemember = (MyCheckBox)target;
				return;
			}
			if (connectionId == 4)
			{
				this.BtnLink = (MyTextButton)target;
				return;
			}
			this.m_SpecificationComparator = true;
		}

		// Token: 0x04000600 RID: 1536
		private bool _InitializerComparator;

		// Token: 0x04000601 RID: 1537
		[CompilerGenerated]
		[AccessedThroughProperty("ComboName")]
		private MyComboBox _SystemComparator;

		// Token: 0x04000602 RID: 1538
		[CompilerGenerated]
		[AccessedThroughProperty("TextPass")]
		private PasswordBox m_WriterComparator;

		// Token: 0x04000603 RID: 1539
		[CompilerGenerated]
		[AccessedThroughProperty("CheckRemember")]
		private MyCheckBox _BroadcasterComparator;

		// Token: 0x04000604 RID: 1540
		[CompilerGenerated]
		[AccessedThroughProperty("BtnLink")]
		private MyTextButton m_AttributeComparator;

		// Token: 0x04000605 RID: 1541
		private bool m_SpecificationComparator;
	}
}
