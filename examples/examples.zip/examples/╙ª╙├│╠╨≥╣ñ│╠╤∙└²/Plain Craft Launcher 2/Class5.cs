﻿using System;

// Token: 0x020001DD RID: 477
internal class Class5
{
	// Token: 0x06001536 RID: 5430 RVA: 0x000050F7 File Offset: 0x000032F7
	internal static void LogoutComposer()
	{
	}

	// Token: 0x04000A88 RID: 2696
	private static bool decoratorAuthentication;
}
