﻿using System;

namespace dummy_ptr
{
	// Token: 0x020001EA RID: 490
	internal abstract class {77e10e4b-2798-45ee-91f1-0221f8c911d8}
	{
		// Token: 0x06000001 RID: 1
		public abstract void m000001();

		// Token: 0x06000006 RID: 6
		public abstract void m000006();

		// Token: 0x0600000B RID: 11
		public abstract void m00000B();

		// Token: 0x06000010 RID: 16
		public abstract void m000010();

		// Token: 0x06000015 RID: 21
		public abstract void m000015();

		// Token: 0x0600001A RID: 26
		public abstract void m00001A();

		// Token: 0x0600001B RID: 27
		public abstract void m00001B();

		// Token: 0x0600001E RID: 30
		public abstract void m00001E();

		// Token: 0x06000030 RID: 48
		public abstract void m000030();

		// Token: 0x0600003D RID: 61
		public abstract void m00003D();

		// Token: 0x0600003F RID: 63
		public abstract void m00003F();

		// Token: 0x06000048 RID: 72
		public abstract void m000048();

		// Token: 0x0600004D RID: 77
		public abstract void m00004D();

		// Token: 0x06000064 RID: 100
		public abstract void m000064();

		// Token: 0x06000069 RID: 105
		public abstract void m000069();

		// Token: 0x06000074 RID: 116
		public abstract void m000074();

		// Token: 0x06000098 RID: 152
		public abstract void m000098();

		// Token: 0x0600009D RID: 157
		public abstract void m00009D();

		// Token: 0x060000AA RID: 170
		public abstract void m0000AA();

		// Token: 0x060000AD RID: 173
		public abstract void m0000AD();

		// Token: 0x060000B0 RID: 176
		public abstract void m0000B0();

		// Token: 0x060000B3 RID: 179
		public abstract void m0000B3();

		// Token: 0x060000B6 RID: 182
		public abstract void m0000B6();

		// Token: 0x060000B9 RID: 185
		public abstract void m0000B9();

		// Token: 0x060000BC RID: 188
		public abstract void m0000BC();

		// Token: 0x060000E1 RID: 225
		public abstract void m0000E1();

		// Token: 0x060000E3 RID: 227
		public abstract void m0000E3();

		// Token: 0x060000E7 RID: 231
		public abstract void m0000E7();

		// Token: 0x060000EA RID: 234
		public abstract void m0000EA();

		// Token: 0x060000EE RID: 238
		public abstract void m0000EE();

		// Token: 0x060000F1 RID: 241
		public abstract void m0000F1();

		// Token: 0x060000F4 RID: 244
		public abstract void m0000F4();

		// Token: 0x060000F7 RID: 247
		public abstract void m0000F7();

		// Token: 0x060000FA RID: 250
		public abstract void m0000FA();

		// Token: 0x060000FD RID: 253
		public abstract void m0000FD();

		// Token: 0x06000100 RID: 256
		public abstract void m000100();

		// Token: 0x06000103 RID: 259
		public abstract void m000103();

		// Token: 0x06000106 RID: 262
		public abstract void m000106();

		// Token: 0x06000109 RID: 265
		public abstract void m000109();

		// Token: 0x0600010F RID: 271
		public abstract void m00010F();

		// Token: 0x06000112 RID: 274
		public abstract void m000112();

		// Token: 0x06000115 RID: 277
		public abstract void m000115();

		// Token: 0x06000118 RID: 280
		public abstract void m000118();

		// Token: 0x0600012E RID: 302
		public abstract void m00012E();

		// Token: 0x06000133 RID: 307
		public abstract void m000133();

		// Token: 0x0600013B RID: 315
		public abstract void m00013B();

		// Token: 0x0600013E RID: 318
		public abstract void m00013E();

		// Token: 0x06000141 RID: 321
		public abstract void m000141();

		// Token: 0x0600014C RID: 332
		public abstract void m00014C();

		// Token: 0x06000159 RID: 345
		public abstract void m000159();

		// Token: 0x0600015D RID: 349
		public abstract void m00015D();

		// Token: 0x06000163 RID: 355
		public abstract void m000163();

		// Token: 0x06000169 RID: 361
		public abstract void m000169();

		// Token: 0x0600016D RID: 365
		public abstract void m00016D();

		// Token: 0x06000171 RID: 369
		public abstract void m000171();

		// Token: 0x06000174 RID: 372
		public abstract void m000174();

		// Token: 0x060001A0 RID: 416
		public abstract void m0001A0();

		// Token: 0x060001A5 RID: 421
		public abstract void m0001A5();

		// Token: 0x060001AA RID: 426
		public abstract void m0001AA();

		// Token: 0x060001AF RID: 431
		public abstract void m0001AF();

		// Token: 0x060001B2 RID: 434
		public abstract void m0001B2();

		// Token: 0x060001B5 RID: 437
		public abstract void m0001B5();

		// Token: 0x060001CE RID: 462
		public abstract void m0001CE();

		// Token: 0x06000217 RID: 535
		public abstract void m000217();

		// Token: 0x0600021C RID: 540
		public abstract void m00021C();

		// Token: 0x06000221 RID: 545
		public abstract void m000221();

		// Token: 0x0600022B RID: 555
		public abstract void m00022B();

		// Token: 0x06000234 RID: 564
		public abstract void m000234();

		// Token: 0x0600023B RID: 571
		public abstract void m00023B();

		// Token: 0x06000262 RID: 610
		public abstract void m000262();

		// Token: 0x0600028A RID: 650
		public abstract void m00028A();

		// Token: 0x06000293 RID: 659
		public abstract void m000293();

		// Token: 0x0600029D RID: 669
		public abstract void m00029D();

		// Token: 0x060002AF RID: 687
		public abstract void m0002AF();

		// Token: 0x060002B4 RID: 692
		public abstract void m0002B4();

		// Token: 0x060002DC RID: 732
		public abstract void m0002DC();

		// Token: 0x060002E0 RID: 736
		public abstract void m0002E0();

		// Token: 0x060002E3 RID: 739
		public abstract void m0002E3();

		// Token: 0x060002FC RID: 764
		public abstract void m0002FC();

		// Token: 0x06000303 RID: 771
		public abstract void m000303();

		// Token: 0x06000316 RID: 790
		public abstract void m000316();

		// Token: 0x0600032A RID: 810
		public abstract void m00032A();

		// Token: 0x0600032B RID: 811
		public abstract void m00032B();

		// Token: 0x06000342 RID: 834
		public abstract void m000342();

		// Token: 0x06000347 RID: 839
		public abstract void m000347();

		// Token: 0x0600034A RID: 842
		public abstract void m00034A();

		// Token: 0x0600034D RID: 845
		public abstract void m00034D();

		// Token: 0x0600035C RID: 860
		public abstract void m00035C();

		// Token: 0x06000391 RID: 913
		public abstract void m000391();

		// Token: 0x060003A5 RID: 933
		public abstract void m0003A5();

		// Token: 0x060003A7 RID: 935
		public abstract void m0003A7();

		// Token: 0x060003A9 RID: 937
		public abstract void m0003A9();

		// Token: 0x060003AD RID: 941
		public abstract void m0003AD();

		// Token: 0x060003B4 RID: 948
		public abstract void m0003B4();

		// Token: 0x060003B7 RID: 951
		public abstract void m0003B7();

		// Token: 0x060003BA RID: 954
		public abstract void m0003BA();

		// Token: 0x060003C0 RID: 960
		public abstract void m0003C0();

		// Token: 0x060003C6 RID: 966
		public abstract void m0003C6();

		// Token: 0x060003C8 RID: 968
		public abstract void m0003C8();

		// Token: 0x060003CB RID: 971
		public abstract void m0003CB();

		// Token: 0x060003CF RID: 975
		public abstract void m0003CF();

		// Token: 0x060003D1 RID: 977
		public abstract void m0003D1();

		// Token: 0x060003D3 RID: 979
		public abstract void m0003D3();

		// Token: 0x060003D7 RID: 983
		public abstract void m0003D7();

		// Token: 0x060003DE RID: 990
		public abstract void m0003DE();

		// Token: 0x060003E2 RID: 994
		public abstract void m0003E2();

		// Token: 0x060003E5 RID: 997
		public abstract void m0003E5();

		// Token: 0x060003E9 RID: 1001
		public abstract void m0003E9();

		// Token: 0x060003ED RID: 1005
		public abstract void m0003ED();

		// Token: 0x06000409 RID: 1033
		public abstract void m000409();

		// Token: 0x0600040E RID: 1038
		public abstract void m00040E();

		// Token: 0x06000411 RID: 1041
		public abstract void m000411();

		// Token: 0x06000414 RID: 1044
		public abstract void m000414();

		// Token: 0x06000459 RID: 1113
		public abstract void m000459();

		// Token: 0x06000517 RID: 1303
		public abstract void m000517();

		// Token: 0x0600054B RID: 1355
		public abstract void m00054B();

		// Token: 0x0600059E RID: 1438
		public abstract void m00059E();

		// Token: 0x060005A3 RID: 1443
		public abstract void m0005A3();

		// Token: 0x060005A7 RID: 1447
		public abstract void m0005A7();

		// Token: 0x060005C3 RID: 1475
		public abstract void m0005C3();

		// Token: 0x060005E0 RID: 1504
		public abstract void m0005E0();

		// Token: 0x060005F1 RID: 1521
		public abstract void m0005F1();

		// Token: 0x0600060C RID: 1548
		public abstract void m00060C();

		// Token: 0x0600060F RID: 1551
		public abstract void m00060F();

		// Token: 0x06000612 RID: 1554
		public abstract void m000612();

		// Token: 0x0600062C RID: 1580
		public abstract void m00062C();

		// Token: 0x06000633 RID: 1587
		public abstract void m000633();

		// Token: 0x0600063E RID: 1598
		public abstract void m00063E();

		// Token: 0x06000681 RID: 1665
		public abstract void m000681();

		// Token: 0x0600068E RID: 1678
		public abstract void m00068E();

		// Token: 0x060006A0 RID: 1696
		public abstract void m0006A0();

		// Token: 0x060006A4 RID: 1700
		public abstract void m0006A4();

		// Token: 0x060006A7 RID: 1703
		public abstract void m0006A7();

		// Token: 0x060006AA RID: 1706
		public abstract void m0006AA();

		// Token: 0x060006AD RID: 1709
		public abstract void m0006AD();

		// Token: 0x060006B0 RID: 1712
		public abstract void m0006B0();

		// Token: 0x060006B3 RID: 1715
		public abstract void m0006B3();

		// Token: 0x060006B6 RID: 1718
		public abstract void m0006B6();

		// Token: 0x060006B9 RID: 1721
		public abstract void m0006B9();

		// Token: 0x060006BB RID: 1723
		public abstract void m0006BB();

		// Token: 0x060006BE RID: 1726
		public abstract void m0006BE();

		// Token: 0x060006F6 RID: 1782
		public abstract void m0006F6();

		// Token: 0x060006FD RID: 1789
		public abstract void m0006FD();

		// Token: 0x06000717 RID: 1815
		public abstract void m000717();

		// Token: 0x0600075A RID: 1882
		public abstract void m00075A();

		// Token: 0x06000769 RID: 1897
		public abstract void m000769();

		// Token: 0x06000798 RID: 1944
		public abstract void m000798();

		// Token: 0x0600079C RID: 1948
		public abstract void m00079C();

		// Token: 0x06000816 RID: 2070
		public abstract void m000816();

		// Token: 0x06000857 RID: 2135
		public abstract void m000857();

		// Token: 0x0600085C RID: 2140
		public abstract void m00085C();

		// Token: 0x06000861 RID: 2145
		public abstract void m000861();

		// Token: 0x06000866 RID: 2150
		public abstract void m000866();

		// Token: 0x06000869 RID: 2153
		public abstract void m000869();

		// Token: 0x0600086D RID: 2157
		public abstract void m00086D();

		// Token: 0x06000876 RID: 2166
		public abstract void m000876();

		// Token: 0x06000879 RID: 2169
		public abstract void m000879();

		// Token: 0x0600087C RID: 2172
		public abstract void m00087C();

		// Token: 0x06000889 RID: 2185
		public abstract void m000889();

		// Token: 0x0600088B RID: 2187
		public abstract void m00088B();

		// Token: 0x0600089B RID: 2203
		public abstract void m00089B();

		// Token: 0x060008A5 RID: 2213
		public abstract void m0008A5();

		// Token: 0x060008AE RID: 2222
		public abstract void m0008AE();

		// Token: 0x060008BE RID: 2238
		public abstract void m0008BE();

		// Token: 0x060008CD RID: 2253
		public abstract void m0008CD();

		// Token: 0x060008D0 RID: 2256
		public abstract void m0008D0();

		// Token: 0x060008D2 RID: 2258
		public abstract void m0008D2();

		// Token: 0x060008D5 RID: 2261
		public abstract void m0008D5();

		// Token: 0x060008DF RID: 2271
		public abstract void m0008DF();

		// Token: 0x060008E2 RID: 2274
		public abstract void m0008E2();

		// Token: 0x060008E5 RID: 2277
		public abstract void m0008E5();

		// Token: 0x060008E8 RID: 2280
		public abstract void m0008E8();

		// Token: 0x060008EB RID: 2283
		public abstract void m0008EB();

		// Token: 0x060008EE RID: 2286
		public abstract void m0008EE();

		// Token: 0x060008F1 RID: 2289
		public abstract void m0008F1();

		// Token: 0x060008F9 RID: 2297
		public abstract void m0008F9();

		// Token: 0x060008FC RID: 2300
		public abstract void m0008FC();

		// Token: 0x06000904 RID: 2308
		public abstract void m000904();

		// Token: 0x0600090C RID: 2316
		public abstract void m00090C();

		// Token: 0x06000915 RID: 2325
		public abstract void m000915();

		// Token: 0x0600091F RID: 2335
		public abstract void m00091F();

		// Token: 0x06000928 RID: 2344
		public abstract void m000928();

		// Token: 0x0600092E RID: 2350
		public abstract void m00092E();

		// Token: 0x06000956 RID: 2390
		public abstract void m000956();

		// Token: 0x0600095D RID: 2397
		public abstract void m00095D();

		// Token: 0x0600095F RID: 2399
		public abstract void m00095F();

		// Token: 0x06000965 RID: 2405
		public abstract void m000965();

		// Token: 0x0600096F RID: 2415
		public abstract void m00096F();

		// Token: 0x06000974 RID: 2420
		public abstract void m000974();

		// Token: 0x0600097B RID: 2427
		public abstract void m00097B();

		// Token: 0x06000989 RID: 2441
		public abstract void m000989();

		// Token: 0x0600098D RID: 2445
		public abstract void m00098D();

		// Token: 0x06000990 RID: 2448
		public abstract void m000990();

		// Token: 0x060009B7 RID: 2487
		public abstract void m0009B7();

		// Token: 0x060009BA RID: 2490
		public abstract void m0009BA();

		// Token: 0x060009BD RID: 2493
		public abstract void m0009BD();

		// Token: 0x060009C0 RID: 2496
		public abstract void m0009C0();

		// Token: 0x060009D1 RID: 2513
		public abstract void m0009D1();

		// Token: 0x060009D4 RID: 2516
		public abstract void m0009D4();

		// Token: 0x060009D7 RID: 2519
		public abstract void m0009D7();

		// Token: 0x060009DE RID: 2526
		public abstract void m0009DE();

		// Token: 0x060009E1 RID: 2529
		public abstract void m0009E1();

		// Token: 0x060009E4 RID: 2532
		public abstract void m0009E4();

		// Token: 0x06000A17 RID: 2583
		public abstract void m000A17();

		// Token: 0x06000A1B RID: 2587
		public abstract void m000A1B();

		// Token: 0x06000A30 RID: 2608
		public abstract void m000A30();

		// Token: 0x06000A3A RID: 2618
		public abstract void m000A3A();

		// Token: 0x06000A41 RID: 2625
		public abstract void m000A41();

		// Token: 0x06000A43 RID: 2627
		public abstract void m000A43();

		// Token: 0x06000A5D RID: 2653
		public abstract void m000A5D();

		// Token: 0x06000A60 RID: 2656
		public abstract void m000A60();

		// Token: 0x06000A78 RID: 2680
		public abstract void m000A78();

		// Token: 0x06000A7A RID: 2682
		public abstract void m000A7A();

		// Token: 0x06000A97 RID: 2711
		public abstract void m000A97();

		// Token: 0x06000AB6 RID: 2742
		public abstract void m000AB6();

		// Token: 0x06000AD4 RID: 2772
		public abstract void m000AD4();

		// Token: 0x06000B00 RID: 2816
		public abstract void m000B00();

		// Token: 0x06000B04 RID: 2820
		public abstract void m000B04();

		// Token: 0x06000B40 RID: 2880
		public abstract void m000B40();

		// Token: 0x06000B6C RID: 2924
		public abstract void m000B6C();

		// Token: 0x06000B71 RID: 2929
		public abstract void m000B71();

		// Token: 0x06000B74 RID: 2932
		public abstract void m000B74();

		// Token: 0x06000B77 RID: 2935
		public abstract void m000B77();

		// Token: 0x06000B7A RID: 2938
		public abstract void m000B7A();

		// Token: 0x06000B94 RID: 2964
		public abstract void m000B94();

		// Token: 0x06000BA5 RID: 2981
		public abstract void m000BA5();

		// Token: 0x06000BC0 RID: 3008
		public abstract void m000BC0();

		// Token: 0x06000BDB RID: 3035
		public abstract void m000BDB();

		// Token: 0x06000BDE RID: 3038
		public abstract void m000BDE();

		// Token: 0x06000BE1 RID: 3041
		public abstract void m000BE1();

		// Token: 0x06000C05 RID: 3077
		public abstract void m000C05();

		// Token: 0x06000C16 RID: 3094
		public abstract void m000C16();

		// Token: 0x06000C2B RID: 3115
		public abstract void m000C2B();

		// Token: 0x06000C31 RID: 3121
		public abstract void m000C31();

		// Token: 0x06000C34 RID: 3124
		public abstract void m000C34();

		// Token: 0x06000C37 RID: 3127
		public abstract void m000C37();

		// Token: 0x06000C3A RID: 3130
		public abstract void m000C3A();

		// Token: 0x06000C3D RID: 3133
		public abstract void m000C3D();

		// Token: 0x06000C40 RID: 3136
		public abstract void m000C40();

		// Token: 0x06000CB7 RID: 3255
		public abstract void m000CB7();

		// Token: 0x06000CBA RID: 3258
		public abstract void m000CBA();

		// Token: 0x06000CBD RID: 3261
		public abstract void m000CBD();

		// Token: 0x06000CE1 RID: 3297
		public abstract void m000CE1();

		// Token: 0x06000CE4 RID: 3300
		public abstract void m000CE4();

		// Token: 0x06000D2D RID: 3373
		public abstract void m000D2D();

		// Token: 0x06000D53 RID: 3411
		public abstract void m000D53();

		// Token: 0x06000D56 RID: 3414
		public abstract void m000D56();

		// Token: 0x06000D59 RID: 3417
		public abstract void m000D59();

		// Token: 0x06000D5D RID: 3421
		public abstract void m000D5D();

		// Token: 0x06000D8E RID: 3470
		public abstract void m000D8E();

		// Token: 0x06000DA6 RID: 3494
		public abstract void m000DA6();

		// Token: 0x06000DC5 RID: 3525
		public abstract void m000DC5();

		// Token: 0x06000DE3 RID: 3555
		public abstract void m000DE3();

		// Token: 0x06000E14 RID: 3604
		public abstract void m000E14();

		// Token: 0x06000E16 RID: 3606
		public abstract void m000E16();

		// Token: 0x06000E19 RID: 3609
		public abstract void m000E19();

		// Token: 0x06000E1C RID: 3612
		public abstract void m000E1C();

		// Token: 0x06000EA3 RID: 3747
		public abstract void m000EA3();

		// Token: 0x06000EF9 RID: 3833
		public abstract void m000EF9();

		// Token: 0x06000F1D RID: 3869
		public abstract void m000F1D();

		// Token: 0x0600106E RID: 4206
		public abstract void m00106E();

		// Token: 0x06001078 RID: 4216
		public abstract void m001078();

		// Token: 0x0600107B RID: 4219
		public abstract void m00107B();

		// Token: 0x0600107E RID: 4222
		public abstract void m00107E();

		// Token: 0x06001089 RID: 4233
		public abstract void m001089();

		// Token: 0x060010E1 RID: 4321
		public abstract void m0010E1();

		// Token: 0x060010E6 RID: 4326
		public abstract void m0010E6();

		// Token: 0x0600110F RID: 4367
		public abstract void m00110F();

		// Token: 0x0600113D RID: 4413
		public abstract void m00113D();

		// Token: 0x06001142 RID: 4418
		public abstract void m001142();

		// Token: 0x06001161 RID: 4449
		public abstract void m001161();

		// Token: 0x06001166 RID: 4454
		public abstract void m001166();

		// Token: 0x0600118C RID: 4492
		public abstract void m00118C();

		// Token: 0x060011B6 RID: 4534
		public abstract void m0011B6();

		// Token: 0x060011BB RID: 4539
		public abstract void m0011BB();

		// Token: 0x060011D8 RID: 4568
		public abstract void m0011D8();

		// Token: 0x060011DA RID: 4570
		public abstract void m0011DA();

		// Token: 0x060011E1 RID: 4577
		public abstract void m0011E1();

		// Token: 0x06001209 RID: 4617
		public abstract void m001209();

		// Token: 0x0600120E RID: 4622
		public abstract void m00120E();

		// Token: 0x06001213 RID: 4627
		public abstract void m001213();

		// Token: 0x06001239 RID: 4665
		public abstract void m001239();

		// Token: 0x0600123E RID: 4670
		public abstract void m00123E();

		// Token: 0x060012F0 RID: 4848
		public abstract void m0012F0();

		// Token: 0x060012FB RID: 4859
		public abstract void m0012FB();

		// Token: 0x060012FE RID: 4862
		public abstract void m0012FE();

		// Token: 0x06001301 RID: 4865
		public abstract void m001301();

		// Token: 0x06001334 RID: 4916
		public abstract void m001334();

		// Token: 0x06001336 RID: 4918
		public abstract void m001336();

		// Token: 0x0600133A RID: 4922
		public abstract void m00133A();

		// Token: 0x06001349 RID: 4937
		public abstract void m001349();

		// Token: 0x0600134D RID: 4941
		public abstract void m00134D();

		// Token: 0x06001350 RID: 4944
		public abstract void m001350();

		// Token: 0x06001354 RID: 4948
		public abstract void m001354();

		// Token: 0x06001358 RID: 4952
		public abstract void m001358();

		// Token: 0x060013CA RID: 5066
		public abstract void m0013CA();

		// Token: 0x060013E7 RID: 5095
		public abstract void m0013E7();

		// Token: 0x060013F2 RID: 5106
		public abstract void m0013F2();

		// Token: 0x060013F7 RID: 5111
		public abstract void m0013F7();

		// Token: 0x060013F9 RID: 5113
		public abstract void m0013F9();

		// Token: 0x060013FC RID: 5116
		public abstract void m0013FC();

		// Token: 0x060013FE RID: 5118
		public abstract void m0013FE();

		// Token: 0x06001400 RID: 5120
		public abstract void m001400();

		// Token: 0x06001405 RID: 5125
		public abstract void m001405();

		// Token: 0x0600140B RID: 5131
		public abstract void m00140B();

		// Token: 0x0600140F RID: 5135
		public abstract void m00140F();

		// Token: 0x0600141D RID: 5149
		public abstract void m00141D();

		// Token: 0x0600141E RID: 5150
		public abstract void m00141E();

		// Token: 0x06001439 RID: 5177
		public abstract void m001439();

		// Token: 0x06001441 RID: 5185
		public abstract void m001441();

		// Token: 0x06001467 RID: 5223
		public abstract void m001467();

		// Token: 0x060014FF RID: 5375
		public abstract void m0014FF();

		// Token: 0x06001501 RID: 5377
		public abstract void m001501();

		// Token: 0x06001503 RID: 5379
		public abstract void m001503();

		// Token: 0x06001506 RID: 5382
		public abstract void m001506();

		// Token: 0x0600150B RID: 5387
		public abstract void m00150B();

		// Token: 0x06001510 RID: 5392
		public abstract void m001510();

		// Token: 0x06001517 RID: 5399
		public abstract void m001517();

		// Token: 0x0600151C RID: 5404
		public abstract void m00151C();

		// Token: 0x06001521 RID: 5409
		public abstract void m001521();

		// Token: 0x06001526 RID: 5414
		public abstract void m001526();

		// Token: 0x0600152B RID: 5419
		public abstract void m00152B();

		// Token: 0x06001530 RID: 5424
		public abstract void m001530();

		// Token: 0x06001535 RID: 5429
		public abstract void m001535();

		// Token: 0x06001538 RID: 5432
		public abstract void m001538();

		// Token: 0x06001558 RID: 5464
		public abstract void m001558();

		// Token: 0x0600155D RID: 5469
		public abstract void mp001389();

		// Token: 0x0600155E RID: 5470
		public abstract void mp00138A();
	}
}
