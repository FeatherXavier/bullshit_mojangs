﻿using System;

// Token: 0x020001DE RID: 478
internal class Class6
{
	// Token: 0x06001539 RID: 5433 RVA: 0x0000C188 File Offset: 0x0000A388
	internal static RuntimeTypeHandle CustomizeComposer(int token)
	{
		return Class6.m_PropertyAuthentication.GetRuntimeTypeHandleFromMetadataToken(token);
	}

	// Token: 0x0600153A RID: 5434 RVA: 0x0000C195 File Offset: 0x0000A395
	internal static RuntimeFieldHandle PushComposer(int token)
	{
		return Class6.m_PropertyAuthentication.GetRuntimeFieldHandleFromMetadataToken(token);
	}

	// Token: 0x04000A89 RID: 2697
	internal static ModuleHandle m_PropertyAuthentication = typeof(Class6).Assembly.GetModules()[0].ModuleHandle;
}
