﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;
using System.Windows.Markup;

[assembly: AssemblyVersion("2.2.0.9")]
[assembly: AssemblyFileVersion("2.2.0.9")]
[assembly: Guid("fc6bb5fb-fe5c-4b25-84d7-2effb821c4bd")]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: NeutralResourcesLanguage("")]
[assembly: RootNamespace("PCL")]
[assembly: AssemblyTitle("Plain Craft Launcher 2 启动器")]
[assembly: AssemblyDescription("Minecraft 启动器 (制作：龙腾猫跃)")]
[assembly: AssemblyCompany("")]
[assembly: ComVisible(false)]
[assembly: AssemblyConfiguration("PCL2 Config Mark")]
[assembly: AssemblyCopyright("Copyright © 龙腾猫跃 2016-2021. All Rights Reserved.")]
[assembly: AssemblyProduct("Plain Craft Launcher 2")]
